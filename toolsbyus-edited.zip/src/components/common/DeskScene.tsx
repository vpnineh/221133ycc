"use client";
import React, { useEffect, useRef } from "react";
import Link from "next/link";
import { Jost } from "next/font/google";

// 🟢 فونت Jost — وزن 500 (Medium)
const jost = Jost({
  subsets: ["latin"],
  weight: ["500"],
  display: "swap",
});
const FONT = jost.style.fontFamily;

/**
 * Ultra-lightweight morphing text — single DOM node, zero React re-renders.
 */
const MonitorText = () => {
  const elRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = elRef.current;
    if (!el) return;

    const texts = [
      "Files processed in your browser",
      "Nothing leaves your device",
      "No account required",
      "Always free",
    ];

    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.textContent = texts[0];
      return;
    }

    let index = 0;
    let isVisible = true;
    let locked = false;

    const cycle = () => {
      if (locked || !isVisible) return;
      locked = true;

      el.style.opacity = "0";
      el.style.transform = "translateY(-6px)";

      setTimeout(() => {
        index = (index + 1) % texts.length;
        el.textContent = texts[index];
        el.style.transform = "translateY(6px)";
        void el.offsetWidth;
        el.style.opacity = "1";
        el.style.transform = "translateY(0)";
        locked = false;
      }, 320);
    };

    const id = setInterval(cycle, 4000);

    const obs = new IntersectionObserver(
      ([e]) => {
        isVisible = e.isIntersecting;
      },
      { threshold: 0.1 }
    );
    obs.observe(el);

    return () => {
      clearInterval(id);
      obs.disconnect();
    };
  }, []);

  return (
    <div
      ref={elRef}
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "0 18px",
        boxSizing: "border-box",
        fontSize: "16px",
        fontWeight: 500,
        lineHeight: 1.25,
        textAlign: "center",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        color: "currentColor",
        fontFamily: FONT,
        fontFeatureSettings: "'kern' 1, 'liga' 1",
        fontVariantNumeric: "tabular-nums",
        textRendering: "optimizeLegibility",
        WebkitFontSmoothing: "antialiased",
        MozOsxFontSmoothing: "grayscale",
        letterSpacing: "0.01em",
        transition:
          "opacity 0.32s cubic-bezier(0.4, 0, 0.2, 1), transform 0.32s cubic-bezier(0.4, 0, 0.2, 1)",
        willChange: "opacity, transform",
      }}
    >
      Files processed in your browser
    </div>
  );
};

/** 🟢 لیبل یکپارچه‌ی گره‌ها با فونت Jost 500 */
const NodeLabel: React.FC<{ x: number; y: number; children: React.ReactNode }> = ({
  x,
  y,
  children,
}) => (
  <text
    x={x}
    y={y}
    textAnchor="middle"
    fill="currentColor"
    fontSize="14"
    fontWeight="500"
    letterSpacing="1.4"
    style={{ fontFamily: FONT }}
  >
    {children}
  </text>
);

export const DeskScene: React.FC<{ className?: string }> = ({ className = "" }) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    const svg = svgRef.current;
    if (!svg) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const beams = Array.from(svg.querySelectorAll<SVGPathElement>(".beam-path"));
    if (!beams.length) return;

    let lastIndex = -1;
    let timer: ReturnType<typeof setTimeout> | null = null;
    let isVisible = true;
    let isRunning = false;
    let currentOnEnd: (() => void) | null = null;

    const pickRandomIndex = (): number => {
      if (beams.length < 2) return 0;
      let next = 0;
      do {
        next = Math.floor(Math.random() * beams.length);
      } while (next === lastIndex);
      return next;
    };

    const scheduleNext = () => {
      if (timer) clearTimeout(timer);
      timer = isVisible ? setTimeout(fireBeam, 400) : null;
    };

    const fireBeam = () => {
      if (!isVisible || isRunning) return;
      isRunning = true;

      lastIndex = pickRandomIndex();
      const beam = beams[lastIndex];

      beam.classList.remove("is-active");
      void beam.getBoundingClientRect();
      beam.classList.add("is-active");

      currentOnEnd = () => {
        beam.removeEventListener("animationend", currentOnEnd!);
        beam.classList.remove("is-active");
        isRunning = false;
        currentOnEnd = null;
        scheduleNext();
      };

      beam.addEventListener("animationend", currentOnEnd);
    };

    let observer: IntersectionObserver | null = null;
    if ("IntersectionObserver" in window) {
      observer = new IntersectionObserver(
        ([entry]) => {
          isVisible = entry.isIntersecting;
          if (isVisible) {
            if (!isRunning && !timer) fireBeam();
          } else {
            if (timer) clearTimeout(timer);
            timer = null;
          }
        },
        { threshold: 0.2 }
      );
      observer.observe(svg);
    }

    const handleVisibilityChange = () => {
      if (document.hidden) {
        isVisible = false;
        if (timer) clearTimeout(timer);
        timer = null;
        beams.forEach((b) => b.classList.remove("is-active"));
        isRunning = false;
      } else {
        isVisible = true;
        if (!isRunning && !timer) fireBeam();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    fireBeam();

    return () => {
      if (timer) clearTimeout(timer);
      if (observer) observer.disconnect();
      document.removeEventListener("visibilitychange", handleVisibilityChange);

      if (currentOnEnd && lastIndex >= 0) {
        beams[lastIndex].removeEventListener("animationend", currentOnEnd);
        currentOnEnd = null;
      }

      beams.forEach((b) => b.classList.remove("is-active"));
      isRunning = false;
      initRef.current = false;
    };
  }, []);

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 920 610"
      className={className}
      fill="none"
      aria-label="ToolsByUs interactive workstation overview"
      role="img"
    >
      <defs>
        <style>{`
          .beam-path {
            stroke-linecap: round;
            stroke-linejoin: round;
            fill: none;
            stroke: var(--accent-solid, #f0541e);
            stroke-width: 3.2px;
            filter: drop-shadow(0 0 6px rgba(240, 84, 30, 0.8));
            stroke-dasharray: 24 100;
            stroke-dashoffset: 24;
            opacity: 0;
            pointer-events: none;
          }
          .beam-path.is-active {
            animation: beam-flow 1.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
          }
          @keyframes beam-flow {
            0%   { stroke-dashoffset: 24;   opacity: 0; }
            15%  { opacity: 1; }
            85%  { opacity: 1; }
            100% { stroke-dashoffset: -100; opacity: 0; }
          }
          @media (prefers-reduced-motion: reduce) {
            .beam-path { animation: none !important; opacity: 0 !important; }
          }
        `}</style>
      </defs>

      {/* 1. Base Static Guide Connectors — anchors moved outward (164 / 756) */}
      <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" opacity="0.85">
        <path d="M164 130h66q14 0 14 14v92q0 14 14 14h42" />
        <path d="M164 282h136" />
        <path d="M164 415h46q14 0 14-14v-73q0-14 14-14h62" />
        <path d="M460 176v37" />
        <path d="M756 130h-66q-14 0-14 14v92q0 14-14 14h-42" />
        <path d="M756 282h-136" />
        <path d="M756 415h-46q-14 0-14-14v-73q0-14-14-14h-62" />
      </g>

      {/* 2. Sequential Traveling Beams */}
      <g aria-hidden="true" pointerEvents="none">
        <path id="beam-pdf" d="M164 130h66q14 0 14 14v92q0 14 14 14h42" pathLength="100" className="beam-path" />
        <path id="beam-text" d="M164 282h136" pathLength="100" className="beam-path" />
        <path id="beam-encode" d="M164 415h46q14 0 14-14v-73q0-14 14-14h62" pathLength="100" className="beam-path" />
        <path id="beam-color" d="M460 176v37" pathLength="100" className="beam-path" />
        <path id="beam-image" d="M756 130h-66q-14 0-14 14v92q0 14-14 14h-42" pathLength="100" className="beam-path" />
        <path id="beam-json" d="M756 282h-136" pathLength="100" className="beam-path" />
        <path id="beam-generate" d="M756 415h-46q-14 0-14-14v-73q0-14-14-14h-62" pathLength="100" className="beam-path" />
      </g>

      {/* 3. Anchor Points & Monitor Terminal Ports */}
      <g stroke="var(--accent-solid)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="164" cy="130" r="4.5" fill="var(--bg)" />
        <circle cx="164" cy="282" r="4.5" fill="var(--bg)" />
        <circle cx="164" cy="415" r="4.5" fill="var(--bg)" />
        <circle cx="460" cy="176" r="4.5" fill="var(--bg)" />
        <circle cx="756" cy="130" r="4.5" fill="var(--bg)" />
        <circle cx="756" cy="282" r="4.5" fill="var(--bg)" />
        <circle cx="756" cy="415" r="4.5" fill="var(--bg)" />
        <path d="M307 250h14M307 282h14M307 314h14" />
        <path d="M453 213h14" />
        <path d="M599 250h14M599 282h14M599 314h14" />
      </g>

      {/* 4. Central Workstation */}
      <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        <rect x="300" y="213" width="320" height="225" rx="10" fill="var(--bg)" />
        <path d="M313 227h294v180H313Z" />
        <path d="M300 420h320M442 438v31M478 438v31M418 472h84" />
        <circle cx="460" cy="220" r="1.5" fill="currentColor" stroke="none" />

        {/* Morphing text on monitor */}
        <foreignObject x="320" y="230" width="280" height="46">
          <MonitorText />
        </foreignObject>

        <path d="M205 475h510l44 65H161ZM161 540v16h598v-16M183 556v40M205 556v40M715 556v40M737 556v40" fill="var(--bg)" />
        <path d="M229 474v-37M229 457q-27-4-27-31 24 3 27 31ZM229 442q22-3 23-28-21 3-23 28ZM229 470q23-2 31-23-23-1-31 23Z" />
        <path d="M212 473h36l-6 32q-13 7-24 0Z" fill="var(--bg)" />
        <ellipse cx="230" cy="473" rx="18" ry="4" fill="var(--bg)" />
        <path d="M646 479v34q17 9 33 0v-34M679 487h4q15 0 10 15-3 8-14 6" fill="var(--bg)" />
        <ellipse cx="662.5" cy="479" rx="16.5" ry="5" fill="var(--bg)" />
        <path d="m704 471-5-36 5-2 8 38M714 471l6-42 5 1-7 41M699 471h24v27q-12 6-24 0Z" fill="var(--bg)" />
        <path d="M328 493h264l13 30H315Z" fill="var(--bg)" />
        <path d="M334 501h38M329 511h39M548 501h38M550 511h40" />
        <path d="M442 382v30M478 382v30" />
        <path d="M460 407q-64 0-83 40l-30 65 25 15 13-21 4 52h142l4-52 13 21 25-15-30-65q-19-40-83-40Z" fill="var(--bg)" />
        <path d="M420 339q-8-9-8 5t12 20M500 339q8-9 8 5t-12 20" fill="var(--bg)" />
        <path d="M418 302q-5 12 1 47 6 35 23 42l18-5 18 5q19-12 23-48 2-20-3-30l5 2q-6-35-43-37-15 0-23 11l-5-7-3 11Z" fill="var(--bg)" />
        <path d="m384 595 9-102q2-31 34-31h66q32 0 34 31l9 102" fill="var(--bg)" />
        <path d="M397 490q4-19 30-19h66q26 0 30 19" />
      </g>

      {/* 5. 7 Interactive Satellite Nodes */}

      {/* 🟢 LEFT COLUMN — shifted 24px further left */}
      <g transform="translate(-24,0)">
        <Link href="/pdf-tools" className="hero-node-link" aria-label="PDF Tools">
          <rect className="node-hitbox" x="78" y="58" width="102" height="124" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M94 94h36l16 16v44q0 4-4 4H94q-4 0-4-4V98q0-4 4-4Z" fill="var(--bg)" />
            <path d="M130 94v16h16" fill="var(--accent-soft)" />
            <path d="M104 120h26M104 130h18M104 140h22" strokeWidth="1.8" />
            <rect x="94" y="164" width="52" height="8" rx="4" />
            <path d="M98 168h34" strokeWidth="3.2" />
            <path d="m154 165 4 4 8-8" stroke="var(--accent-solid)" />
          </g>
          <NodeLabel x={120} y={78}>PDF</NodeLabel>
        </Link>

        <Link href="/text-tools" className="hero-node-link" aria-label="Text Tools">
          <rect className="node-hitbox" x="78" y="220" width="102" height="106" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M90 258h80M90 270h55M90 282h28M90 294h80M90 306h62" />
            <rect x="116" y="278" width="50" height="9" rx="4.5" fill="var(--accent-soft)" stroke="var(--accent-solid)" strokeWidth="1.8" />
            <path d="M120 282.5h42" strokeWidth="1.8" />
            <path d="m156 298 3 13 4-4 5-1Z" fill="var(--accent-solid)" stroke="var(--accent-solid)" strokeWidth="1.5" />
          </g>
          <NodeLabel x={130} y={240}>TEXT</NodeLabel>
        </Link>

        <Link href="/encode-tools" className="hero-node-link" aria-label="Encoding Tools">
          <rect className="node-hitbox" x="78" y="362" width="102" height="88" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <rect x="88" y="396" width="34" height="38" rx="5" fill="var(--bg)" />
            <path d="M94 407h20M94 415h14M94 423h18" strokeWidth="1.8" />
            <rect x="136" y="396" width="34" height="38" rx="5" fill="var(--bg)" />
            <path d="M150 410v-4q0-3 3-3t3 3v4" strokeWidth="1.8" />
            <rect x="146" y="410" width="14" height="11" rx="2.5" fill="var(--accent-soft)" stroke="var(--accent-solid)" strokeWidth="1.8" />
            <circle cx="153" cy="415.5" r="1" fill="var(--accent-solid)" stroke="none" />
            <path d="M142 426h22" strokeWidth="1.8" />
            <path d="M125 408h8m-3-3 3 3-3 3" stroke="var(--accent-solid)" strokeWidth="1.8" />
            <path d="M133 422h-8m3-3-3 3 3 3" strokeWidth="1.8" />
          </g>
          <NodeLabel x={129} y={380}>ENCODE</NodeLabel>
        </Link>
      </g>

      {/* CENTER — COLOR (unchanged) */}
      <Link href="/color-tools" className="hero-node-link" aria-label="Color Tools">
        <rect className="node-hitbox" x="404" y="54" width="112" height="112" rx="14" />
        <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="460" cy="98" r="16" />
          <circle cx="448" cy="116" r="16" />
          <circle cx="472" cy="116" r="16" />
          <circle cx="460" cy="110" r="4.5" fill="var(--accent-solid)" stroke="none" />
          <rect x="412" y="140" width="96" height="14" rx="7" fill="var(--bg)" stroke="currentColor" strokeWidth="2" />
          <path d="M436 143v8M484 143v8" stroke="currentColor" strokeWidth="1.6" opacity="0.45" />
          <circle cx="460" cy="147" r="7" fill="var(--bg)" stroke="var(--accent-solid)" strokeWidth="2.4" />
          <circle cx="460" cy="147" r="2.5" fill="var(--accent-solid)" stroke="none" />
        </g>
        <NodeLabel x={460} y={72}>COLOR</NodeLabel>
      </Link>

      {/* 🟢 RIGHT COLUMN — shifted 24px further right */}
      <g transform="translate(24,0)">
        <Link href="/image-tools" className="hero-node-link" aria-label="Image Tools">
          <rect className="node-hitbox" x="740" y="58" width="104" height="124" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <rect x="750" y="94" width="90" height="66" rx="4" fill="var(--bg)" />
            <rect x="750" y="94" width="8" height="8" fill="var(--bg)" />
            <rect x="750" y="152" width="8" height="8" fill="var(--bg)" />
            <rect x="832" y="152" width="8" height="8" fill="var(--bg)" />
            <circle cx="836" cy="98" r="4.5" fill="var(--accent-solid)" stroke="var(--accent-solid)" />
            <circle cx="774" cy="112" r="6" stroke="var(--accent-solid)" />
            <path d="m756 150 18-20 15 14 18-26 27 32" />
          </g>
          <NodeLabel x={795} y={78}>IMAGE</NodeLabel>
        </Link>

        <Link href="/json-tools" className="hero-node-link" aria-label="JSON Tools">
          <rect className="node-hitbox" x="740" y="220" width="104" height="106" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M764 262q-7 0-7 7v6q0 7-7 7 7 0 7 7v6q0 7 7 7" stroke="var(--accent-solid)" strokeWidth="2.6" />
            <path d="M820 262q7 0 7 7v6q0 7 7 7-7 0-7 7v6q0 7-7 7" stroke="var(--accent-solid)" strokeWidth="2.6" />
            <path d="M772 270v24" strokeWidth="1.8" />
            <path d="M772 270h24M772 282h34M772 294h20" strokeWidth="1.8" />
            <g fill="var(--accent-solid)" stroke="none">
              <circle cx="798" cy="270" r="2.5" />
              <circle cx="808" cy="282" r="2.5" />
              <circle cx="794" cy="294" r="2.5" />
            </g>
          </g>
          <NodeLabel x={792} y={240}>JSON</NodeLabel>
        </Link>

        <Link href="/generate-tools" className="hero-node-link" aria-label="Generator Tools">
          <rect className="node-hitbox" x="740" y="362" width="104" height="88" rx="14" />
          <g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <rect x="750" y="396" width="90" height="42" rx="6" fill="var(--bg)" />
            <rect x="756" y="402" width="9" height="9" rx="1.5" strokeWidth="1.8" />
            <rect x="759" y="405" width="3" height="3" fill="currentColor" stroke="none" />
            <rect x="769" y="402" width="9" height="9" rx="1.5" strokeWidth="1.8" />
            <rect x="772" y="405" width="3" height="3" fill="currentColor" stroke="none" />
            <rect x="756" y="415" width="9" height="9" rx="1.5" strokeWidth="1.8" />
            <rect x="759" y="418" width="3" height="3" fill="currentColor" stroke="none" />
            <rect x="772" y="417" width="4" height="4" rx="1" fill="var(--accent-solid)" stroke="none" />
            <path d="M784 402v30" stroke="var(--border-strong)" strokeWidth="1.2" strokeDasharray="2 2" />
            <path d="M792 404v26M796 404v26M800 404v26M805 404v26M810 404v26M815 404v26M820 404v26M825 404v26" strokeWidth="1.8" />
            <path d="M796 404v26M810 404v26" strokeWidth="3" />
            <path d="M830 400v6m-3-3h6" stroke="var(--accent-solid)" strokeWidth="1.8" />
          </g>
          <NodeLabel x={795} y={380}>GENERATE</NodeLabel>
        </Link>
      </g>
    </svg>
  );
};

export default DeskScene;