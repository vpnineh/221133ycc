/**
 * Pre-compresses all static assets in `out/` with Brotli and Gzip.
 *
 * Running pre-compression at build time ensures:
 * 1. 100% lossless compression at maximum levels (Brotli quality 11, Gzip level 9).
 * 2. Zero runtime CPU penalty on CDNs / static servers (Nginx, Caddy, Cloudflare, AWS CloudFront, etc.).
 * 3. The homepage hero SVG (embedded inline in index.html) and all vector/script/style
 *    assets transfer with maximum compression efficiency (up to 80%+ smaller).
 *
 * Run: node scripts/compress-assets.mjs
 */
import fs from "fs";
import path from "path";
import zlib from "zlib";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(__dirname, "..", "out");

if (!fs.existsSync(outDir)) {
  console.error("compress-assets: out/ is missing. Run `next build` first.");
  process.exit(1);
}

const COMPRESSIBLE_EXTENSIONS = new Set([
  ".html",
  ".svg",
  ".js",
  ".mjs",
  ".css",
  ".json",
  ".webmanifest",
  ".xml",
  ".txt",
]);

function collectFiles(dir) {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...collectFiles(fullPath));
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (COMPRESSIBLE_EXTENSIONS.has(ext)) {
        results.push(fullPath);
      }
    }
  }
  return results;
}

const files = collectFiles(outDir);
let totalOriginalBytes = 0;
let totalGzipBytes = 0;
let totalBrotliBytes = 0;

console.log(`\nCompressing ${files.length} static assets with Brotli (q=11) & Gzip (level=9)...`);

const highlights = [];

for (const file of files) {
  const relPath = path.relative(outDir, file);
  const content = fs.readFileSync(file);
  const origSize = content.length;

  if (origSize === 0) continue;

  // Gzip level 9
  const gz = zlib.gzipSync(content, {
    level: zlib.constants.Z_BEST_COMPRESSION,
  });
  fs.writeFileSync(`${file}.gz`, gz);

  // Brotli quality 11, lgwin 22
  const br = zlib.brotliCompressSync(content, {
    params: {
      [zlib.constants.BROTLI_PARAM_QUALITY]: 11,
      [zlib.constants.BROTLI_PARAM_LGWIN]: 22,
    },
  });
  fs.writeFileSync(`${file}.br`, br);

  totalOriginalBytes += origSize;
  totalGzipBytes += gz.length;
  totalBrotliBytes += br.length;

  if (relPath === "index.html" || relPath.endsWith(".svg")) {
    const gzRatio = (((origSize - gz.length) / origSize) * 100).toFixed(1);
    const brRatio = (((origSize - br.length) / origSize) * 100).toFixed(1);
    highlights.push({
      file: relPath,
      orig: origSize,
      gz: gz.length,
      br: br.length,
      gzRatio,
      brRatio,
    });
  }
}

console.log("\nHighlighted Core Assets (Homepage Hero & SVGs):");
console.log("------------------------------------------------------------------");
for (const h of highlights) {
  console.log(
    ` ${h.file.padEnd(20)}: ${(h.orig / 1024).toFixed(1)} KB -> Gzip: ${(h.gz / 1024).toFixed(1)} KB (-${h.gzRatio}%) | Brotli: ${(h.br / 1024).toFixed(1)} KB (-${h.brRatio}%)`
  );
}

const totalGzSaved = (((totalOriginalBytes - totalGzipBytes) / totalOriginalBytes) * 100).toFixed(1);
const totalBrSaved = (((totalOriginalBytes - totalBrotliBytes) / totalOriginalBytes) * 100).toFixed(1);

console.log("------------------------------------------------------------------");
console.log(
  `Total: ${(totalOriginalBytes / (1024 * 1024)).toFixed(2)} MB -> Gzip: ${(totalGzipBytes / (1024 * 1024)).toFixed(2)} MB (-${totalGzSaved}%) | Brotli: ${(totalBrotliBytes / (1024 * 1024)).toFixed(2)} MB (-${totalBrSaved}%)\n`
);
