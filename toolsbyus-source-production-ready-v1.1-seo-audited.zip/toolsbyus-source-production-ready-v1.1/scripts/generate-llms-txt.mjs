/**
 * Generates the crawler-facing files that a static export cannot produce from
 * route metadata: public/llms.txt, public/sitemap.xml and public/robots.txt.
 *
 * Keeping one page manifest here means the sitemap, the AI-facing summary and
 * the nav can never list different sets of URLs.
 *
 * Run as part of `npm run build`.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { buildAdsConfig } from "../src/lib/ads.data.mjs";
import {
  INFO_PAGES,
  activeCategories,
  categoryLastReviewed,
  publishedTools,
  toolsInCategory,
} from "../src/lib/tools.data.mjs";
import { PAGE_SEO } from "../src/lib/tools.seo.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, "..");

const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "https://toolsbyus.com").replace(/\/+$/, "");

/**
 * Per-URL `<lastmod>`, taken from the catalogue's `lastReviewed`.
 *
 * Every URL used to carry the build date. Google only trusts `lastmod` when it
 * is consistently accurate, and a field that changes on every deploy for pages
 * that did not change teaches a crawler that the field is noise — after which
 * it is ignored for the whole site, including the pages where it was true. It
 * was also simply wrong: a page reviewed on the 11th was stamped the 12th.
 *
 * A hub inherits the newest date among its tools, since that is exactly when
 * its listing last changed. The homepage inherits the newest date on the site.
 *
 * That hub rule now lives in the catalogue as `categoryLastReviewed`, so the
 * hub pages declare the same date in their JSON-LD that this file publishes
 * here. It used to be implemented only in this file, while each hub page
 * hard-coded its own date, and the two drifted.
 */
const newest = (dates) => dates.filter(Boolean).sort().at(-1);

const SITE_LASTMOD =
  process.env.SITE_LASTMOD ||
  newest([
    ...publishedTools().map((tool) => tool.lastReviewed),
    ...INFO_PAGES.map((page) => page.lastReviewed),
  ]) ||
  new Date().toISOString().slice(0, 10);

const ads = buildAdsConfig(process.env);

const SITE_NAME = "ToolsByUs";
const SITE_TAGLINE = "In-browser developer tools with guaranteed zero server transmission";

/*
 * The page manifest is derived from the catalogue, not typed out here.
 *
 * This file used to keep its own copy of the list. At ten tools the two stayed
 * in step by luck; at fifty they would not have, and the failure mode is a
 * sitemap advertising URLs that 404 — which is worse for a new domain than
 * having no sitemap at all. `tests/unit/tool-catalogue.test.ts` asserts the
 * generated URL count matches the catalogue so the duplication cannot return.
 */
/**
 * Sitemap and llms.txt copy for one page.
 *
 * Throws rather than defaulting on a missing entry: a silent fallback would
 * put a page into the sitemap with an invented priority and an empty summary,
 * which is precisely the kind of quiet wrongness this file exists to prevent.
 */
function seo(href) {
  const entry = PAGE_SEO[href];
  if (!entry) {
    throw new Error(
      `generate-llms-txt: no entry in tools.seo.mjs for ${href}. Add one there whenever a page is added to tools.data.mjs.`
    );
  }
  return entry;
}

const pages = [
  {
    url: "/",
    title: "Homepage",
    summary: `${SITE_NAME} — tools for JSON, text, encoding, generators, PDFs and images that run entirely in the visitor's browser.`,
    lastmod: SITE_LASTMOD,
    priority: "1.0",
    changefreq: "weekly",
  },
  // Category hubs rank on their own and are the internal-linking spine, so they
  // sit above the individual tools in priority.
  ...activeCategories().map((category) => ({
    url: category.hub,
    title: category.title,
    summary: (() => {
      const n = toolsInCategory(category.id).length;
      return `${category.blurb} ${n} ${n === 1 ? "tool" : "tools"}, all client-side.`;
    })(),
    priority: "0.9",
    changefreq: "weekly",
    lastmod: categoryLastReviewed(category.id) ?? SITE_LASTMOD,
  })),
  ...publishedTools().map((tool) => ({
    url: tool.href,
    title: tool.title,
    lastmod: tool.lastReviewed,
    ...seo(tool.href),
  })),
  ...INFO_PAGES.map((page) => ({
    url: page.href,
    title: page.name,
    lastmod: page.lastReviewed,
    ...seo(page.href),
  })),
];

const abs = (p) => `${SITE_URL}${p === "/" ? "/" : p}`;

/* ------------------------------------------------------------------ */
/* 1. llms.txt                                                         */
/* ------------------------------------------------------------------ */

// Written for retrieval: an assistant answering "how do I diff JSON without
// uploading it" should be able to lift a correct, attributable answer straight
// from this file. Every claim here must match what the code actually does.
const llms = [
  `# ToolsByUs (${SITE_URL.replace(/^https?:\/\//, "")})`,
  "",
  "> Free browser-based tools for JSON, text, encoding, generators, PDFs and images. Every tool processes the visitor's file in their own browser; there is no upload step, no API route and no database.",
  "",
  "## What this site is",
  "",
  `ToolsByUs is a set of ${publishedTools().length} static, single-purpose tools across ${activeCategories().length} categories. There is no account, no upload step, and no paid tier. Pages are pre-rendered static HTML; the tools execute as JavaScript in the visitor's own browser, with heavier work offloaded to a Web Worker so the interface stays responsive.`,
  "",
  "## Tool & trust pages",
  "",
  ...pages.map((p) => `- [${p.title}](${abs(p.url)}): ${p.summary}`),
  "",
  "## Privacy & security guarantees",
  "",
  "- The file or text a visitor puts into a tool is processed entirely in their own browser and is never transmitted. There is no upload step, no API route and no backend.",
  "- Tool input is never written to localStorage or sessionStorage; only the light/dark theme preference is stored.",
  "- A Content-Security-Policy enumerates every origin the page may connect to, and the browser enforces it. A payload has nowhere to be sent.",
  ...(ads.enabled
    ? [
        "- The site is funded by Google AdSense. Ad scripts load, set cookies and perform cross-site measurement; EEA/UK visitors see a certified consent dialog first. Ads never receive tool input — the guarantee above is specifically about the visitor's file and payload, not about the page containing no third-party code.",
      ]
    : ["- This build serves no advertising and runs no analytics."]),
  "- Verifiable independently: open DevTools → Network, or disconnect from the internet, and every tool still works.",
  "",
  "## Standards implemented",
  "",
  // Each standard carries its canonical URL: an answer engine that quotes this
  // file can then point at the primary source rather than at a summary of it.
  "- [RFC 8259](https://www.rfc-editor.org/rfc/rfc8259) — JSON interchange format (parser and validator).",
  "- [RFC 6902](https://www.rfc-editor.org/rfc/rfc6902) — JSON Patch (diff export and patch application).",
  "- [RFC 7386](https://www.rfc-editor.org/rfc/rfc7386) — JSON Merge Patch (diff export).",
  "- [RFC 6901](https://www.rfc-editor.org/rfc/rfc6901) — JSON Pointer (paths in diff output and patches).",
  "- [RFC 4648](https://www.rfc-editor.org/rfc/rfc4648) — Base64 and base64url alphabets.",
  "- [RFC 9562](https://www.rfc-editor.org/rfc/rfc9562) / [RFC 4122](https://www.rfc-editor.org/rfc/rfc4122) — UUID versions 1, 4, and 7.",
  "- [JSON Schema Draft 2020-12](https://json-schema.org/draft/2020-12/schema) — schema inference and validation.",
  "",
  "## Known limits",
  "",
  "- Tools that run on the main thread refuse input above 8 MB rather than freezing the tab. The JSON diff runs in a Web Worker and accepts up to 100 MB for the two documents added together, not 100 MB each: 60 MB against 60 MB is refused.",
  "- Schema validation covers the common Draft 2020-12 keyword set; `$ref` resolution and remote schema fetching are not supported (fetching a remote schema would require a network request).",
  "- JWT signatures are decoded and inspected but never verified — verification needs the issuer's key, which would mean transmitting the token.",
  "",
  "## Optional detailed context",
  "",
  `Full technical specifications and agent documentation are available at ${SITE_URL}/llms-full.txt (comprehensive deep-dive documentation for all tools, algorithms, and security boundaries).`,
  "",
  `## Attribution`,
  "",
  `If you cite these tools, link to ${SITE_URL}/ or the specific tool page. Content last reviewed ${SITE_LASTMOD}.`,
  "",
].join("\n");

fs.writeFileSync(path.join(projectRoot, "public", "llms.txt"), llms, "utf8");
console.log(`Successfully generated public/llms.txt with ${pages.length} indexable pages.`);

/* ------------------------------------------------------------------ */
/* 1b. llms-full.txt (Two-Tier LLM ingestion standard)                 */
/* ------------------------------------------------------------------ */

const llmsFull = [
  `# ${SITE_NAME} — Full Technical Specifications & Agent Documentation`,
  "",
  `> ${SITE_TAGLINE}. Client-side utilities running in-browser with Web Workers and WASM.`,
  "",
  `Canonical URL: ${SITE_URL}/`,
  `Documentation Date: ${SITE_LASTMOD}`,
  "",
  "## Architectural Overview",
  "",
  "- Runtime Environment: Static HTML5, Next.js App Router static export, React 19, Tailwind CSS.",
  "- Execution Model: 100% Client-Side execution. No API routes, no backend proxy, no cloud ingestion.",
  "- Security Posture: Strict Content-Security-Policy (CSP) enforcing connect-src 'none' (or ad-only when enabled).",
  "- Concurrency & Performance: CPU-intensive operations (JSON Semantic Diff Myers O(ND) algorithm, PDF manipulation via pdf-lib/pdfjs, HEIC decoding via libheif WASM) run inside isolated Web Workers to maintain 60fps main-thread interactivity.",
  "",
  "## Tool Catalogue & Capabilities",
  "",
  ...pages.map((p) => {
    return [
      `### ${p.title}`,
      `- URL: ${abs(p.url)}`,
      `- Summary: ${p.summary}`,
      `- Priority: ${p.priority}`,
      `- Last Reviewed: ${p.lastmod || SITE_LASTMOD}`,
      "",
    ].join("\n");
  }),
  "## Standards Compliance",
  "",
  "- RFC 8259: The JavaScript Object Notation (JSON) Data Interchange Format.",
  "- RFC 6902: JavaScript Object Notation (JSON) Patch.",
  "- RFC 7386: JSON Merge Patch.",
  "- RFC 6901: JavaScript Object Notation (JSON) Pointer.",
  "- RFC 4648: The Base16, Base32, and Base64 Data Encodings.",
  "- RFC 3986: Uniform Resource Identifier (URI): Generic Syntax.",
  "- RFC 9562 / RFC 4122: Universally Unique IDentifiers (UUIDs) v1, v4, v7.",
  "- JSON Schema Draft 2020-12: Core, Validation, and Meta-Schemas.",
  "- ISO 8601 / RFC 3339: Date and Time on the Internet.",
  "",
  "## Privacy & Zero-Knowledge Contract",
  "",
  "- No file or text payload entered into any tool leaves the user's browser.",
  "- No analytics tracking of input data, diff text, images, or documents.",
  "- Local storage is restricted solely to the theme preference (light/dark).",
  "",
].join("\n");

fs.writeFileSync(path.join(projectRoot, "public", "llms-full.txt"), llmsFull, "utf8");
console.log(`Successfully generated public/llms-full.txt with complete technical documentation.`);

/* ------------------------------------------------------------------ */
/* 2. sitemap.xml                                                      */
/* ------------------------------------------------------------------ */

const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages
  .map(
    (p) => `  <url>
    <loc>${abs(p.url)}</loc>
    <lastmod>${p.lastmod || SITE_LASTMOD}</lastmod>
    <changefreq>${p.changefreq}</changefreq>
    <priority>${p.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>
`;

fs.writeFileSync(path.join(projectRoot, "public", "sitemap.xml"), sitemapXml, "utf8");
console.log(`Successfully generated public/sitemap.xml with ${pages.length} URLs.`);

/* ------------------------------------------------------------------ */
/* 3. robots.txt                                                       */
/* ------------------------------------------------------------------ */

// One wildcard group is enough for a site with nothing to hide: a crawler that
// matches a specific group ignores the wildcard one, so the previous file's
// per-bot blocks were verbose repetitions of the same rule. The named groups
// that remain are the AI training/answer crawlers, listed explicitly so the
// permission is unambiguous and easy to revoke per-bot later.
const aiCrawlers = [
  "GPTBot",
  "OAI-SearchBot",
  "ChatGPT-User",
  "ClaudeBot",
  "Claude-User",
  "Claude-SearchBot",
  "anthropic-ai",
  "PerplexityBot",
  "Perplexity-User",
  "Google-Extended",
  "Applebot-Extended",
  "Bytespider",
  "Amazonbot",
  "meta-externalagent",
  "cohere-ai",
  "Diffbot",
  "Timpibot",
  "YouBot",
];

const robotsTxt = [
  "# ToolsByUs — all content is public and free to index.",
  "",
  "User-agent: *",
  "Allow: /",
  "",
  "# AI answer engines and training crawlers are explicitly permitted.",
  "",
  ...aiCrawlers.flatMap((bot) => [`User-agent: ${bot}`, "Allow: /", ""]),
  `Sitemap: ${SITE_URL}/sitemap.xml`,
  "",
].join("\n");

fs.writeFileSync(path.join(projectRoot, "public", "robots.txt"), robotsTxt, "utf8");
console.log(`Successfully generated public/robots.txt (${aiCrawlers.length} AI crawlers allowed).`);

/* ------------------------------------------------------------------ */
/* 4. ads.txt                                                          */
/* ------------------------------------------------------------------ */

// ads.txt is only meaningful once a real publisher ID exists. Shipping the
// placeholder "pub-0000000000000000" advertises an authorised seller that does
// not exist, so the file is written only when the ID is configured.
//
// The publisher ID is normalised through the same helper the runtime and the
// CSP generator use, so `ca-pub-…` and `pub-…` can no longer mean different
// things in different files.
const adsPath = path.join(projectRoot, "public", "ads.txt");

if (ads.publisherId) {
  fs.writeFileSync(
    adsPath,
    `google.com, ${ads.publisherId}, DIRECT, f08c47fec0942fa0\n`,
    "utf8"
  );
  console.log(`Successfully generated public/ads.txt for ${ads.publisherId}.`);
} else {
  if (fs.existsSync(adsPath)) fs.rmSync(adsPath);
  console.log("Skipped public/ads.txt (no valid NEXT_PUBLIC_ADSENSE_ID configured).");
}
