/**
 * Serves the static export for local checks and Playwright runs.
 *
 * Crucially it applies the `/*` rules from out/_headers, so the CSP is actually
 * exercised. Without that, an end-to-end run passes locally and the deployed
 * site — where the host does apply those headers — breaks on a policy the tests
 * never saw.
 */
import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const outDir = path.resolve(__dirname, "..", "out");

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

/**
 * Parse `_headers` into ordered (pattern, headers) blocks.
 *
 * It used to read only the `/*` block, which was fine while that was the only
 * one carrying anything the tests looked at. It is not fine now: the CSP is
 * deliberately narrowed for `/_next/static/*`, and a harness that ignores
 * path blocks would have told us the narrowing worked when it had not been
 * applied at all. The whole reason this server exists is to serve the same
 * headers the host will.
 *
 * Matching follows the Netlify and Cloudflare Pages rule: every block whose
 * pattern matches applies, in file order, and a later block's value replaces an
 * earlier one for the same header name.
 */
function loadHeaderBlocks() {
  const headersFile = path.join(outDir, "_headers");
  if (!fs.existsSync(headersFile)) return [];

  const blocks = [];
  let current = null;
  for (const rawLine of fs.readFileSync(headersFile, "utf8").split("\n")) {
    const line = rawLine.trimEnd();
    if (!line.trim() || line.trim().startsWith("#")) continue;

    if (!/^\s/.test(line)) {
      current = { pattern: line.trim(), headers: {} };
      blocks.push(current);
      continue;
    }
    if (!current) continue;

    const separator = line.indexOf(":");
    if (separator === -1) continue;
    current.headers[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
  }
  return blocks;
}

/** `/*`, `/dir/*` and `/*.ext` are the only shapes this file uses. */
function patternMatches(pattern, urlPath) {
  if (pattern === urlPath) return true;
  if (pattern.startsWith("/*.")) return urlPath.endsWith(pattern.slice(2));
  if (pattern.endsWith("/*")) return urlPath.startsWith(pattern.slice(0, -1));
  if (pattern === "/*") return true;
  return false;
}

/**
 * Blocks, re-read whenever `_headers` changes on disk.
 *
 * Reading once at startup is the obvious thing and it cost an afternoon.
 * Playwright is configured with `reuseExistingServer: true`, so a server left
 * running from an earlier build keeps serving that build's CSP hash list — and
 * a stale hash list does not fail loudly. It blocks Next's hydration script,
 * React never attaches, and every test fails waiting for a control that the
 * static HTML shows but that does nothing. Nothing in the output says "CSP";
 * you have to open a browser console to find out.
 *
 * An mtime check per request is a stat syscall on a local file, which is
 * nothing next to being confidently wrong.
 */
let cachedBlocks = null;
let cachedMtimeMs = -1;

function headersFor(urlPath) {
  const headersFile = path.join(outDir, "_headers");
  let mtimeMs = -1;
  try {
    mtimeMs = fs.statSync(headersFile).mtimeMs;
  } catch {
    // No _headers at all: serve without them, and keep checking.
  }
  if (cachedBlocks === null || mtimeMs !== cachedMtimeMs) {
    cachedBlocks = loadHeaderBlocks();
    cachedMtimeMs = mtimeMs;
  }

  const result = {};
  for (const block of cachedBlocks) {
    if (patternMatches(block.pattern, urlPath)) Object.assign(result, block.headers);
  }
  return result;
}

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(req.url.split("?")[0]);

  // Refuse to serve outside the export root.
  const requested = path.normalize(path.join(outDir, urlPath === "/" ? "index.html" : urlPath));
  if (!requested.startsWith(outDir)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  // The export emits both `about.html` and an `about/` directory, so test for a
  // *file* rather than mere existence — otherwise the directory wins and every
  // tool route 404s.
  const isFile = (p) => fs.existsSync(p) && fs.statSync(p).isFile();

  let filePath = requested;
  if (!isFile(filePath)) {
    if (isFile(filePath + ".html")) {
      filePath = filePath + ".html";
    } else if (isFile(path.join(filePath, "index.html"))) {
      filePath = path.join(filePath, "index.html");
    }
  }

  if (isFile(filePath)) {
    const ext = path.extname(filePath);
    const acceptEncoding = req.headers["accept-encoding"] || "";
    let servePath = filePath;
    let contentEncoding = null;

    if (acceptEncoding.includes("br") && isFile(filePath + ".br")) {
      servePath = filePath + ".br";
      contentEncoding = "br";
    } else if (acceptEncoding.includes("gzip") && isFile(filePath + ".gz")) {
      servePath = filePath + ".gz";
      contentEncoding = "gzip";
    }

    const headers = {
      ...headersFor(urlPath),
      "Content-Type": mimeTypes[ext] || "application/octet-stream",
      "Cache-Control": "no-cache",
    };
    if (contentEncoding) {
      headers["Content-Encoding"] = contentEncoding;
      headers["Vary"] = "Accept-Encoding";
    }

    res.writeHead(200, headers);
    fs.createReadStream(servePath).pipe(res);
    return;
  }

  const notFoundPath = path.join(outDir, "404.html");
  if (fs.existsSync(notFoundPath)) {
    res.writeHead(404, { ...headersFor(urlPath), "Content-Type": "text/html; charset=utf-8" });
    fs.createReadStream(notFoundPath).pipe(res);
  } else {
    res.writeHead(404, headersFor(urlPath));
    res.end("Not Found");
  }
});

const PORT = Number(process.env.PORT) || 3030;
server.listen(PORT, () => {
  const applied = Object.keys(headersFor("/index.html")).length;
  // Reflect the actual bind, not an assumption: without an explicit host Node
  // binds every interface (both stacks), so the address printed here used to be
  // wrong about which loopback name would reach it — harmless to the socket,
  // misleading to a human pointing curl at it.
  const addr = server.address();
  const shown =
    typeof addr === "object" && addr
      ? addr.family === "IPv6"
        ? `[${addr.address}]:${addr.port}`
        : `${addr.address}:${addr.port}`
      : `port ${PORT}`;
  console.log(
    `Static server running on http://${shown} (also reachable as http://localhost:${PORT}) ` +
      `(${applied} header${applied === 1 ? "" : "s"} applied from out/_headers)`
  );
});
