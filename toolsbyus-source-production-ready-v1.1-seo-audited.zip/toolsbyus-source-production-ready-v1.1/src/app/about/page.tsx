import React from "react";
import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { absoluteUrl } from "../../lib/site";
import Breadcrumb from "@/components/common/Breadcrumb";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import PrivacyBadge from "@/components/common/PrivacyBadge";
import { ADS } from "../../lib/ads";
import { infoPageLastReviewed } from "../../lib/tools";
import Link from "next/link";

export const metadata: Metadata = buildToolMetadata({
  path: "/about",
  title: "About — Browser Tools and How We Check Them",
  socialTitle: "About & Architecture",
  description:
    "How ToolsByUs processes PDFs, images, color, text and JSON in your browser, with documented limits, test coverage and a way to report problems.",
});

export default function AboutPage() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      name: "About ToolsByUs",
      url: absoluteUrl("/about"),
      description:
        "How ToolsByUs builds and checks its browser-based file and data tools.",
      // The page shows a review date; without this the date was a claim only a
      // reader could see. Same catalogue value as the visible stamp.
      dateModified: infoPageLastReviewed("/about"),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "About",
          item: absoluteUrl("/about"),
        },
      ],
    },
  ];

  return (
    <div className="shell max-w-3xl py-8 space-y-8">
      <SchemaJsonLd schemas={jsonLdData} />

      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "About", href: "/about" },
        ]}
      />

      <div className="space-y-3">
        {/* Wraps, because the H1 is now set at the same size as every other
            page's and a 320px row cannot hold it beside a chip. */}
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3">
          <h1 className="min-w-0 text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[2.75rem]">
            About toolsbyus.com
          </h1>
          <PrivacyBadge />
        </div>
        {/* A deck, not a section. As an <h2> it outranked the six sections
            below and demoted all of them to <h3>, so the outline read as six
            subsections of a subtitle. */}
        <p className="max-w-[68ch] text-sm text-foreground-muted sm:text-base">
          Built on one premise: the file you are working on belongs in your browser, not on
          somebody else&apos;s server.
        </p>
      </div>

      <div className="space-y-6">
        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="why-local-processing" className="text-sm font-semibold tracking-tight text-foreground">
            Why local processing
          </h2>
          <p>
            Files and data can contain private information. ToolsByUs offers local processing
            for PDFs, images, color, text and JSON, so a file-processing server is not required.
          </p>
          <p>
            Before using any tool with sensitive material, try it with a sample and review its
            limitations. Follow your organization&apos;s data-handling requirements.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="architecture" className="text-sm font-semibold tracking-tight text-foreground">
            How ToolsByUs Is Architected
          </h2>
          <p>
            The guarantee is narrow and precise, which is what makes it worth anything:
            <strong> the content you put into a tool is never transmitted</strong>. The processing code reads the file locally and does not send its contents to a processing API.
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li>
              <strong>100% Static Export:</strong> The entire application is pre-rendered into static HTML,
              CSS, and client-side JavaScript bundles using Next.js <code>output: &apos;export&apos;</code>.
            </li>
            <li>
              <strong>Zero Backend Infrastructure:</strong> There are no serverless functions, no API
              routes, no Node.js backend processes, no database connections, and no authentication endpoints.
            </li>
            <li>
              <strong>Edge CDN Delivery:</strong> The build produces static files that can be served by an edge CDN. Hosting still handles ordinary connection metadata.
            </li>
            <li>
              <strong>Client-Side Isolation:</strong> Every parsing, validation, diffing, encoding, and schema
              generation algorithm runs entirely within your device&apos;s local CPU and V8/SpiderMonkey
              JavaScript engine.
            </li>
            <li>
              <strong>Dedicated Web Workers:</strong> Heavy work — a large semantic diff, a PDF
              merge, an image re-encode — runs in an isolated Web Worker under a 100 MB ceiling. The
              work still takes the time it takes; what the worker buys is a tab that stays
              responsive while it happens, instead of one that freezes.
            </li>
          </ul>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="open-architectural-mechanics" className="text-sm font-semibold tracking-tight text-foreground">
            Open Architectural Mechanics
          </h2>
          <p>
            Unlike black-box utilities, ToolsByUs uses transparent, standards-compliant engines:
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li>
              <strong>Iterative Stack Parser:</strong> Hand-rolled iterative parser capable of traversing
              10,000 nested brackets without hitting browser call-stack overflow limitations.
            </li>
            <li>
              <strong>Semantic Diff Engine:</strong> Key-order-invariant comparison engine supporting{" "}
              <a
                href="https://www.rfc-editor.org/rfc/rfc6902"
                className="text-accent hover:underline"
                rel="noopener"
              >
                RFC 6902
              </a>{" "}
              JSON Patch and{" "}
              <a
                href="https://www.rfc-editor.org/rfc/rfc7386"
                className="text-accent hover:underline"
                rel="noopener"
              >
                RFC 7386
              </a>{" "}
              JSON Merge Patch specifications.
            </li>
            <li>
              <strong>
                <a
                  href="https://json-schema.org/draft/2020-12/schema"
                  className="text-accent hover:underline"
                  rel="noopener"
                >
                  JSON Schema Draft 2020-12
                </a>:
              </strong>{" "}
              Real-time schema inference engine with automated format detection (UUID, email, date-time,
              uri, IPv4).
            </li>
            <li>
              <strong>
                <a
                  href="https://www.rfc-editor.org/rfc/rfc9562"
                  className="text-accent hover:underline"
                  rel="noopener"
                >
                  RFC 9562
                </a>{" "}
                Monotonic UUID Generator:
              </strong>{" "}
              Browser cryptographic random generators for UUID v4 and database-optimized B-tree
              sequential UUID v7.
            </li>
          </ul>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="funding" className="text-sm font-semibold tracking-tight text-foreground">
            How this is paid for, and what that does not change
          </h2>
          <p>
            {ADS.enabled
              ? "The site is funded by advertising. Ad scripts run on these pages, set cookies, and measure across sites — that is what advertising does, and pretending otherwise would make every other sentence here less trustworthy."
              : "Advertising is disabled in this build. Analytics is configured separately; the privacy page reflects the current settings."}
          </p>
          <p>
            The tools do not include input contents in network requests. Third-party scripts running in the page have access to the page environment; a static export or CSP alone does not isolate input from those scripts. Any enabled integration must be reviewed by the operator. The{" "}
            <Link href="/privacy" className="text-accent hover:underline">
              privacy page
            </Link>{" "}
            sets out exactly which origins the browser is permitted to talk to, and how to check.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="editorial-standards" className="text-sm font-semibold tracking-tight text-foreground">
            How these pages are written and reviewed
          </h2>
          <p>
            Every tool page carries a <em>last reviewed</em> date. It is worth saying what that
            date actually means here, because on most sites it means the day a script touched the
            file.
          </p>
          <ul className="list-disc list-inside space-y-1">
            <li>
              <strong>The tool is built before the page is written.</strong> The explanatory prose
              describes behaviour that already exists in the code, which is why it tends to be
              about edge cases: those are what surface while implementing the thing.
            </li>
            <li>
              <strong>Claims are tested, not asserted.</strong> The &ldquo;nothing is
              uploaded&rdquo; claim is enforced by a Content-Security-Policy of{" "}
              <code>connect-src &apos;self&apos;</code> and checked by an automated test that fails
              the build if any request carries a body. Numbers quoted in the copy — size ceilings,
              page counts, output dimensions — are asserted in the test suite against real files.
            </li>
            <li>
              <strong>Limits are documented rather than hidden.</strong> Where a tool cannot do
              something — schema <code>$ref</code> resolution, JWT signature verification, PDF
              password recovery, HEIC encoding — the page says so and explains why, instead of
              failing quietly.
            </li>
            <li>
              <strong>A page is revised when its tool changes.</strong> The review date comes from
              the same catalogue entry that generates the navigation and the sitemap, so a page
              cannot claim a freshness its record does not support.
            </li>
          </ul>
          <p>
            If something on this site is wrong, that is worth more to us than it is to you:{" "}
            <a href="mailto:security@toolsbyus.com" className="text-accent hover:underline">
              security@toolsbyus.com
            </a>{" "}
            reaches the people who maintain it.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h2 id="engineering-philosophy" className="text-sm font-semibold tracking-tight text-foreground">
            The Engineering Philosophy
          </h2>
          <p>
            ToolsByUs is maintained by developers who build distributed systems, microservices, and web
            applications. We built the tools we wished existed: fast, zero-latency, private, and fully
            functional offline.
          </p>
          <div className="pt-2">
            <Link
              href="/privacy"
              className="text-accent font-bold hover:underline"
            >
              Read our Technical Privacy Guarantee &rarr;
            </Link>
          </div>
        </div>
      </div>

      <section
        id="editorial-process"
        aria-labelledby="maintainers"
        className="scroll-mt-24 space-y-4 border-t border-border pt-8"
      >
        <h2 id="maintainers" className="text-2xl font-semibold tracking-tight">
          Who maintains the tools, and how are they checked?
        </h2>
        <p>ToolsByUs is the publisher of this collection. Tool documentation describes the implemented behavior, input limits and known edge cases. Each tool links to related operations and displays its content review date.</p>
        <p>The source includes unit tests for processing engines, browser tests for representative workflows, and build checks for links, metadata, structured data and security headers. Automated checks are useful evidence; they cannot guarantee every possible file or browser will work.</p>
        <p>To report an incorrect result, include the tool URL, browser version, reproduction steps and a small non-sensitive example. Do not send private documents or credentials. Contact <a href="mailto:security@toolsbyus.com" className="text-accent underline">security@toolsbyus.com</a> for security or privacy concerns.</p>
        <p>Review dates describe content checks. A shared layout change does not imply that every processing algorithm or article was independently reviewed on that date.</p>
      </section>

      <ReviewedStamp href="/about" />
    </div>
  );
}
