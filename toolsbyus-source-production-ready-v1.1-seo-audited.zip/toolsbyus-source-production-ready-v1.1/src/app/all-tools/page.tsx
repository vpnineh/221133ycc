import type { Metadata } from "next";
import Link from "next/link";
import { buildToolMetadata } from "../../lib/metadata";
import { absoluteUrl, SITE_NAME } from "../../lib/site";
import Breadcrumb from "@/components/common/Breadcrumb";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import { CATEGORIES, TOOLS, infoPageLastReviewed, toolsInCategory } from "../../lib/tools";
import { AllToolsClient } from "./AllToolsClient";

const TOOL_COUNT = TOOLS.length;

export const metadata: Metadata = buildToolMetadata({
  path: "/all-tools",
  // The count stays out of the title: it changes with the catalogue, and a
  // title that goes stale in a SERP is worse than one that never named it.
  title: "All Tools — Every One Runs in Your Browser",
  socialTitle: "All Tools",
  description: `Every tool on ToolsByUs in one filterable list: JSON, XML, YAML, CSV, text, PDF and image utilities that run entirely in your browser.`,
});

export default function AllToolsPage() {
  const tools = TOOLS;

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "CollectionPage",
        "@id": `${absoluteUrl("/all-tools")}#page`,
        url: absoluteUrl("/all-tools"),
        name: `All ${TOOL_COUNT} tools`,
        description: `The complete catalogue of ${SITE_NAME} utilities, every one of them running in the visitor's browser.`,
        // The page shows a review date; without this the date was a claim only a
        // reader could see. Same catalogue value as the visible stamp.
        dateModified: infoPageLastReviewed("/all-tools"),
        isPartOf: { "@id": `${absoluteUrl("/")}#website` },
      },
      {
        "@type": "ItemList",
        "@id": `${absoluteUrl("/all-tools")}#list`,
        numberOfItems: tools.length,
        itemListElement: tools.map((tool, index) => ({
          "@type": "ListItem",
          position: index + 1,
          name: tool.title,
          description: tool.description,
          url: absoluteUrl(tool.href),
        })),
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: absoluteUrl("/") },
          { "@type": "ListItem", position: 2, name: "All tools", item: absoluteUrl("/all-tools") },
        ],
      },
    ],
  };

  return (
    <div className="shell space-y-8 py-8">
      <SchemaJsonLd schemas={[jsonLd]} />

      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "All tools", href: "/all-tools" },
        ]}
      />

      <header className="space-y-3">
        <h1 className="text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[2.75rem]">
          All {TOOL_COUNT} tools
        </h1>
        <p className="max-w-[68ch] border-l-2 border-accent-line pl-4 text-sm leading-relaxed text-foreground-muted sm:text-[0.9375rem]">
          Everything on the site, in one list you can filter. All of it runs in the browser tab you
          already have open: your payload, your document and your photograph are read, transformed
          and written back locally, and the page&apos;s Content-Security-Policy sets{" "}
          <code className="rounded-pill bg-surface-elevated px-2 text-2xs">
            connect-src &apos;self&apos;
          </code>
          , so an upload would be refused by the browser rather than merely not attempted.
        </p>
      </header>

      <AllToolsClient />

      <section aria-labelledby="by-category" className="space-y-3 pt-2">
        <h2
          id="by-category"
          className="text-sm font-semibold tracking-tight text-foreground"
        >
          Prefer a category page?
        </h2>
        <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.filter((category) => toolsInCategory(category.id).length > 0).map(
            (category) => (
              <li key={category.id}>
                <Link
                  href={category.hub}
                  className="block rounded-lg border border-border bg-surface p-3 transition-colors hover:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <span className="text-sm font-semibold tracking-tight text-foreground">
                    {category.title}
                  </span>
                  <span className="mt-1 block text-xs text-foreground-muted">{category.blurb}</span>
                </Link>
              </li>
            )
          )}
        </ul>
      </section>

      <ReviewedStamp href="/all-tools" />
    </div>
  );
}
