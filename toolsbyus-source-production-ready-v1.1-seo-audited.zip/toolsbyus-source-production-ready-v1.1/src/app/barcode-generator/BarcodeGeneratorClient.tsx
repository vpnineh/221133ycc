"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Icon } from "../../components/common/Icon";
import { relatedTools } from "../../lib/tools";
import {
  BarcodeError,
  encodeBarcode,
  printedWidthMm,
  renderSvg,
  SYMBOLOGIES,
  type EncodedBarcode,
  type Symbology,
} from "../../lib/barcode";

/**
 * The smallest module width each standard allows, in millimetres.
 *
 * Printing below it is the single most common reason a symbol that looks
 * perfect on screen will not scan: ink spreads on contact, the spaces close,
 * and the scanner's edge detector stops finding transitions. ITF-14 is the
 * strictest because it is printed straight onto corrugated board, which spreads
 * more than a label does.
 */
const MINIMUM_X_MM: Record<Symbology, number> = {
  code128: 0.25,
  ean13: 0.264,
  ean8: 0.264,
  upca: 0.264,
  upce: 0.264,
  code39: 0.19,
  itf14: 0.495,
};

const EXAMPLES: Record<Symbology, string> = {
  code128: "SHIP-4417-A",
  ean13: "590123412345",
  ean8: "9638507",
  upca: "03600029145",
  upce: "0360002",
  code39: "AB-1234",
  itf14: "1234567890123",
};

/** Bars, in millimetres, at the on-screen module width. */
const BAR_HEIGHT_PX = 80;

export const BarcodeGeneratorClient: React.FC = () => {
  const [symbology, setSymbology] = useState<Symbology>("code128");
  const [value, setValue] = useState("");
  const [moduleWidthMm, setModuleWidthMm] = useState(0.33);
  const [showText, setShowText] = useState(true);

  const info = SYMBOLOGIES.find((entry) => entry.id === symbology)!;

  const result = useMemo<{ encoded: EncodedBarcode } | { error: string }>(() => {
    if (!value.trim()) return { error: "Type a value or click Try Example to encode." };
    try {
      return { encoded: encodeBarcode(value.trim(), symbology) };
    } catch (error) {
      return {
        error:
          error instanceof BarcodeError
            ? error.message
            : "That value could not be encoded in this symbology.",
      };
    }
  }, [value, symbology]);

  const encoded = "encoded" in result ? result.encoded : null;

  const svg = useMemo(
    () =>
      encoded
        ? renderSvg(encoded, { moduleWidth: 2, barHeight: BAR_HEIGHT_PX, showText })
        : "",
    [encoded, showText]
  );

  const widthMm = encoded ? printedWidthMm(encoded, moduleWidthMm) : 0;
  const minimumX = MINIMUM_X_MM[symbology];
  const tooNarrow = moduleWidthMm < minimumX;

  /** The SVG again, but sized in millimetres so a printer honours it. */
  const printSvg = useMemo(() => {
    if (!encoded) return "";
    // 1mm is 96/25.4 CSS px. Emitting the geometry in px and the outer size in
    // mm is what makes the file print at the real width instead of at whatever
    // the placing application decides.
    const pxPerMm = 96 / 25.4;
    return renderSvg(encoded, {
      moduleWidth: moduleWidthMm * pxPerMm,
      barHeight: 18 * pxPerMm,
      showText,
      fontSize: 3.2 * pxPerMm,
    });
  }, [encoded, moduleWidthMm, showText]);

  const download = (contents: string, extension: string) => {
    const blob = new Blob([contents], { type: "image/svg+xml" });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = `${encoded?.text ?? "barcode"}.${extension}`;
    link.click();
    URL.revokeObjectURL(href);
  };

  /**
   * PNG, drawn module by module rather than by rasterising the SVG.
   *
   * Loading an SVG into an `Image` is asynchronous and needs a blob round trip;
   * a barcode is a row of rectangles that canvas draws exactly. Drawing at
   * eight device pixels per module also guarantees every bar edge lands on a
   * whole pixel, which is the difference between a crisp symbol and a blurred
   * one that will not scan.
   */
  const downloadPng = () => {
    if (!encoded) return;
    const scale = 8;
    const quiet = encoded.quietZone;
    const guardExtra = encoded.guards.length > 0 ? scale * 5 : 0;
    const fontSize = 14 * (scale / 2);
    const textGap = showText ? fontSize + 6 : 0;

    const canvas = document.createElement("canvas");
    canvas.width = (encoded.modules.length + quiet * 2) * scale;
    canvas.height = BAR_HEIGHT_PX * (scale / 2) + guardExtra + textGap + 8;
    const context = canvas.getContext("2d");
    if (!context) return;

    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#000000";

    const guardSet = new Set(encoded.guards);
    const barHeight = BAR_HEIGHT_PX * (scale / 2);
    encoded.modules.forEach((module, index) => {
      if (module !== 1) return;
      const height = barHeight + (guardSet.has(index) ? guardExtra : 0);
      context.fillRect((quiet + index) * scale, 0, scale, height);
    });

    if (showText) {
      context.font = `${fontSize}px ui-monospace, SFMono-Regular, Menlo, monospace`;
      context.textAlign = "center";
      context.fillText(encoded.display, canvas.width / 2, canvas.height - 8);
    }

    canvas.toBlob((blob) => {
      if (!blob) return;
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = `${encoded.text}.png`;
      link.click();
      URL.revokeObjectURL(href);
    });
  };

  return (
    <ToolShell
      slug="barcode-generator"
      keyword="Barcode Generator"
      directAnswer="Barcode Generator encodes a value as Code 128, EAN-13, EAN-8, UPC-A, Code 39 or ITF-14 and gives you an SVG or PNG. The encoders — check digits, Code 128's set switching, EAN's parity encoding of the thirteenth digit — all run in your browser, and the output carries the quiet zones and guard bars the standards require, which is what decides whether a scanner reads it."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "Barcode Generator", url: "/barcode-generator" },
      ]}
      seoDescription="Generate Code 128, EAN-13, EAN-8, UPC-A, Code 39 and ITF-14 barcodes as SVG or PNG. Check digits calculated, quiet zones included, print width in millimetres, all in your browser."
      howItWorks={{
        inputTitle: "A value and a symbology",
        outputTitle: "A scannable symbol",
        exampleInput: `EAN-13
590123412345`,
        exampleOutput: `5901234123457
             ↑ check digit

quiet zone   11 modules each side
modules      95
width        30.1mm at X = 0.264mm`,
        algorithmExplanation: (
          <>
            <p>
              A barcode is a number written in the width of bars and spaces, and the encoding is
              specific to the symbology. The tool picks the right one for what you are making and
              refuses the combinations that cannot work — you cannot put letters in an EAN, and it
              says so rather than silently dropping them.
            </p>
            <h3>Code 128, and why it is the default</h3>
            <p>
              Code 128 encodes the whole of ASCII in three overlapping character sets, and switching
              between them mid-symbol is part of the encoding. Set C is the reason it is so
              efficient for numbers: it packs two digits into one symbol character, so a 20-digit
              value takes 10 characters instead of 20. This encoder switches into set C when a run
              of digits makes it worthwhile — six at the start of the value, four in the middle —
              which is the trade-off point where the switch character pays for itself.
            </p>
            <h3>The thirteenth digit of an EAN-13 is not a bar</h3>
            <p>
              EAN-13 has 95 modules and they encode twelve digits, not thirteen. The first digit is
              carried by the *parity pattern* of the six on the left: each of them is encoded as
              either odd or even parity, and which of the six possible patterns appears is what
              spells the leading digit. It is a genuinely clever piece of 1970s design — it made
              EAN-13 a superset of the existing 12-digit UPC-A without changing the width of the
              symbol — and it is the part a hand-rolled encoder almost always gets wrong.
            </p>
            <h3>Check digits</h3>
            <p>
              EAN, UPC and ITF-14 all use the same modulo-10 scheme: weight the digits alternately
              by 3 and 1, sum them, and the check digit is whatever brings the total to a multiple
              of ten. Type the twelve digits of an EAN-13 and the thirteenth is calculated and shown
              — if you already have it, the tool checks yours rather than replacing it, and tells
              you if it does not match. Code 128 has its own weighted checksum which is part of the
              symbol and never printed.
            </p>
            <h3>Quiet zones are not margin</h3>
            <p>
              The blank space either side of the bars is part of the symbol, and it is the most
              frequently destroyed part of it. A scanner uses it to find where the code begins; with
              a logo or a fold or a box edge inside it, read rates fall off sharply. The standards
              set it per symbology — 11 modules for EAN-13, 10 for Code 128 — and it is included in
              everything downloaded here, which is exactly why the file has &ldquo;too much white
              space&rdquo; around it. Do not crop it.
            </p>
            <h3>Why the output is SVG by default</h3>
            <p>
              Because a barcode is printed far more often than it is displayed, and a raster image
              at the wrong resolution is the other common reason a symbol fails. The bars land on
              fractional device pixels, the printer smears the edges, and the widths the scanner
              measures are no longer the widths you encoded. Vector output has no resolution to get
              wrong, and the downloaded SVG is sized in millimetres so a print pipeline reproduces
              it at the module width you chose.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "Symbologies, and what each is for",
        rows: [
          ...SYMBOLOGIES.map((entry) => ({
            parameter: entry.label,
            type: entry.accepts,
            defaultVal: `${entry.quietZone} modules`,
            description: entry.usedFor,
          })),
          {
            parameter: "Module width (X)",
            type: "mm",
            defaultVal: "0.33",
            description:
              "The width of the narrowest bar, and the number that sets everything else. Minimums: 0.264mm for retail EAN and UPC, 0.495mm for ITF-14 on corrugated board.",
          },
          {
            parameter: "Quiet zone",
            type: "modules",
            defaultVal: "included",
            description:
              "Blank space that is part of the symbol rather than margin around it. Cropping it is the most common reason a printed code stops scanning.",
          },
        ],
      }}
      faqs={[
        {
          question: "Which barcode type should I use?",
          answer:
            "Code 128 for anything internal — shipping labels, asset tags, warehouse locations — because it takes any ASCII text at any length and packs digits two to a character. EAN-13 for a retail product sold outside North America, UPC-A inside it, and both require a GS1 company prefix you have to buy; you cannot invent the number. ITF-14 for the outer case or pallet. Code 39 only when the scanner or the industry demands it: it is bulky and encodes a restricted character set, but very old readers handle nothing else.",
        },
        {
          question: "Can I make my own EAN-13 for a product I sell?",
          answer:
            "You can generate a valid symbol here, but the number itself has to be allocated. An EAN-13 begins with a GS1 company prefix issued to your business, and retailers verify it against the GS1 registry — a made-up number will encode and scan and then fail at the point it matters. For internal stock control where nothing leaves your own system, Code 128 with your own scheme is the honest answer and costs nothing.",
        },
        {
          question: "How is the check digit calculated?",
          answer:
            "For EAN, UPC and ITF-14 it is modulo 10: take the digits, weight them alternately by 3 and 1 from the right, add them up, and the check digit is the amount that brings the total up to the next multiple of ten. Type the twelve digits of an EAN-13 here and the thirteenth appears; paste all thirteen and this tool verifies yours instead of overwriting it. Code 128 has a different, weighted checksum that is encoded into the symbol and never printed underneath.",
        },
        {
          question: "Why does my printed barcode not scan?",
          answer:
            "Three causes, in order of frequency. The quiet zone has been cropped or something has been placed inside it — that blank space is part of the symbol. The module width is below the minimum, so ink spread closes the spaces; retail EAN and UPC need 0.264mm and ITF-14 on corrugated board needs 0.495mm. Or it was printed from a low-resolution raster image, where the bar edges do not land on whole pixels. Download the SVG, keep the white space, and check the width in millimetres shown on this page.",
        },
        {
          question: "Can a barcode hold a URL or a phone number?",
          answer:
            "Code 128 can hold any ASCII text, so a URL will encode — but a linear barcode is a poor carrier for one. It gets very wide very quickly, and the scanners that read a URL usefully are phone cameras, which read QR codes far better than they read 1D symbols. If the target is a phone, use the QR code generator on this site instead. Use a barcode when a dedicated scanner is reading it.",
        },
        {
          question: "Is anything uploaded when I generate a barcode?",
          answer:
            "No. The encoders run in this tab, and the SVG and PNG are produced here too. That matters more than it sounds for this tool in particular: the values people encode are order numbers, serial numbers and internal asset tags, and sending those to a stranger's server to have some rectangles drawn is a poor trade. The site's Content-Security-Policy sets connect-src 'self', so the browser would block an upload even if something tried.",
        },
      ]}
      relatedTools={relatedTools("/barcode-generator").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="grid gap-8 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] lg:gap-12">
        {/* ---- Controls ------------------------------------------------- */}
        <div className="space-y-6">
          <section>
            <h2 className="text-sm font-medium text-foreground-muted">Symbology</h2>
            <div role="radiogroup" aria-label="Symbology" className="mt-2 flex flex-wrap gap-2">
              {SYMBOLOGIES.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  role="radio"
                  aria-checked={symbology === entry.id}
                  onClick={() => {
                    setSymbology(entry.id);
                    setValue(EXAMPLES[entry.id]);
                  }}
                  className={`cursor-pointer rounded-pill px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] ${
                    symbology === entry.id
                      ? "bg-accent-solid text-accent-on"
                      : "bg-surface-elevated text-foreground-muted hover:text-foreground"
                  }`}
                >
                  {entry.label}
                </button>
              ))}
            </div>
            <p className="mt-2 text-sm text-foreground-muted">{info.usedFor}.</p>
          </section>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <label htmlFor="barcode-value" className="block text-sm text-foreground-muted">
                Value <span className="text-foreground-subtle">— {info.accepts}</span>
              </label>
              <button
                type="button"
                onClick={() => setValue(EXAMPLES[symbology])}
                className="flex items-center gap-1 text-xs font-mono text-accent hover:text-accent cursor-pointer pointer-coarse:min-h-[44px]"
              >
                <Icon name="sparkles" size="sm" className="text-accent" />
                Try Example
              </button>
            </div>
            <input
              id="barcode-value"
              type="text"
              value={value}
              onChange={(event) => setValue(event.target.value)}
              placeholder={EXAMPLES[symbology]}
              spellCheck={false}
              autoComplete="off"
              autoCapitalize="characters"
              aria-invalid={"error" in result && value.trim() !== ""}
              aria-describedby={"error" in result && value.trim() !== "" ? "barcode-error" : undefined}
              className={`w-full min-w-0 rounded-lg bg-surface-elevated px-3 py-2.5 font-mono text-base text-foreground outline-none focus-visible:ring-2 focus-visible:ring-accent ${
                "error" in result && value.trim() !== "" ? "ring-2 ring-inset ring-danger" : ""
              }`}
            />
            {"error" in result && value.trim() !== "" && (
              <p id="barcode-error" role="status" className="mt-2 text-sm text-danger">
                {result.error}
              </p>
            )}
          </div>

          <label className="block">
            <span className="flex items-baseline justify-between text-sm text-foreground-muted">
              Module width (X)
              <span className="font-mono text-foreground">{moduleWidthMm.toFixed(3)} mm</span>
            </span>
            <input
              type="range"
              min={0.15}
              max={1}
              step={0.005}
              value={moduleWidthMm}
              onChange={(event) => setModuleWidthMm(Number(event.target.value))}
              className="mt-2 w-full accent-accent-solid"
            />
            <span className="mt-1 block text-xs text-foreground-subtle">
              The width of the narrowest bar when printed. {info.label} needs at least{" "}
              {minimumX.toFixed(3)} mm.
            </span>
          </label>

          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={showText}
              onChange={(event) => setShowText(event.target.checked)}
              className="mt-0.5 h-5 w-5 flex-none cursor-pointer accent-accent-solid"
            />
            <span className="text-sm">
              <span className="font-medium text-foreground">Print the value underneath</span>
              <span className="mt-0.5 block text-foreground-muted">
                The human-readable line. Retail symbols are required to carry it — it is what a
                cashier types when the scan fails.
              </span>
            </span>
          </label>
        </div>

        {/* ---- Output --------------------------------------------------- */}
        <div className="min-w-0 space-y-6">
          {encoded ? (
            <>
              <div className="flex justify-center overflow-x-auto rounded-xl bg-white p-6">
                {/* The markup is generated from the module array in this repo;
                    no part of it comes from the field. */}
                <div dangerouslySetInnerHTML={{ __html: svg }} />
              </div>

              {tooNarrow && (
                <p role="status" className="rounded-lg bg-surface-elevated p-4 text-sm text-foreground-muted">
                  <strong className="font-medium text-foreground">
                    {moduleWidthMm.toFixed(3)} mm is below the {minimumX.toFixed(3)} mm minimum for{" "}
                    {info.label}.
                  </strong>{" "}
                  It will look correct on screen and may well fail at the scanner: ink spreads on
                  contact and closes the narrow spaces. Raise the module width, or accept a symbol
                  that only works on a good printer and a clean surface.
                </p>
              )}

              <dl className="grid grid-cols-2 gap-4 rounded-lg bg-surface-elevated p-4 text-sm sm:grid-cols-4">
                {[
                  ["Encoded", encoded.text],
                  ["Modules", String(encoded.modules.length)],
                  ["Quiet zone", `${encoded.quietZone} each side`],
                  ["Printed width", `${widthMm.toFixed(1)} mm`],
                ].map(([label, detail]) => (
                  <div key={label} className="min-w-0">
                    <dt className="text-xs text-foreground-subtle">{label}</dt>
                    <dd className="mt-0.5 truncate font-mono text-foreground" title={detail}>
                      {detail}
                    </dd>
                  </div>
                ))}
              </dl>

              {encoded.text !== value.trim().toUpperCase() &&
                encoded.text.length > value.trim().length && (
                  <p className="text-sm text-foreground-muted">
                    The check digit{" "}
                    <code className="font-mono text-foreground">
                      {encoded.text[encoded.text.length - 1]}
                    </code>{" "}
                    was calculated and appended, so the full encoded value is{" "}
                    <code className="font-mono text-foreground">{encoded.text}</code>.
                  </p>
                )}

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => download(printSvg, "svg")}
                  className="inline-flex cursor-pointer items-center gap-1.5 rounded-pill bg-accent-solid px-5 py-2.5 text-sm font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  <Icon name="download" size="sm" />
                  Download SVG
                </button>
                <button
                  type="button"
                  onClick={downloadPng}
                  className="inline-flex cursor-pointer items-center gap-1.5 rounded-pill bg-surface-elevated px-5 py-2.5 text-sm font-medium text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  <Icon name="download" size="sm" />
                  PNG
                </button>
              </div>

              <p className="max-w-[62ch] text-sm text-foreground-subtle">
                The SVG is sized in millimetres at the module width above, so a print pipeline
                reproduces it at the real size. Both files include the quiet zones — the white space
                around the bars is part of the symbol, and cropping it is the commonest way to break
                a barcode that was fine on screen.
              </p>
            </>
          ) : (
            <div className="flex min-h-[16rem] items-center justify-center rounded-xl bg-surface-elevated p-6 text-center text-sm text-foreground-muted">
              {"error" in result ? result.error : "Type a value to encode."}
            </div>
          )}
        </div>
      </div>
    </ToolShell>
  );
};
