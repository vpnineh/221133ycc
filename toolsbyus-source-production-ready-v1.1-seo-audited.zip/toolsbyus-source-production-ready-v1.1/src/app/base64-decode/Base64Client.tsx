"use client";

import { usePageFileDrop } from "../../components/tools/usePageFileDrop";
import { useFileReader } from "../../components/tools/useFileReader";
import React, { useState, useTransition, useId } from "react";
import {
  encodeBase64,
  decodeBase64,
  inspectJwt,
  Base64Alphabet,
  TextEncoding,
} from "@/lib/base64";

function guessMimeType(bytes: Uint8Array): { mime: string; ext: string } {
  if (bytes.length >= 4) {
    // PNG: 89 50 4E 47
    if (
      bytes[0] === 0x89 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x4e &&
      bytes[3] === 0x47
    ) {
      return { mime: "image/png", ext: "png" };
    }
    // JPEG: FF D8 FF
    if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
      return { mime: "image/jpeg", ext: "jpg" };
    }
    // PDF: %PDF (25 50 44 46)
    if (
      bytes[0] === 0x25 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x44 &&
      bytes[3] === 0x46
    ) {
      return { mime: "application/pdf", ext: "pdf" };
    }
    // ZIP: PK.. (50 4B 03 04)
    if (
      bytes[0] === 0x50 &&
      bytes[1] === 0x4b &&
      bytes[2] === 0x03 &&
      bytes[3] === 0x04
    ) {
      return { mime: "application/zip", ext: "zip" };
    }
  }
  if (bytes.length >= 2) {
    // GZIP: 1F 8B
    if (bytes[0] === 0x1f && bytes[1] === 0x8b) {
      return { mime: "application/gzip", ext: "gz" };
    }
  }
  return { mime: "application/octet-stream", ext: "bin" };
}

function generateHexDump(bytes: Uint8Array, maxBytes = 4096): string {
  const slice = bytes.subarray(0, maxBytes);
  const lines: string[] = [];
  for (let i = 0; i < slice.length; i += 16) {
    const chunk = slice.subarray(i, i + 16);
    const offset = i.toString(16).padStart(8, "0");
    const hexPart = Array.from(chunk)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(" ")
      .padEnd(47, " ");
    const asciiPart = Array.from(chunk)
      .map((b) => (b >= 32 && b <= 126 ? String.fromCharCode(b) : "."))
      .join("");
    lines.push(`${offset}  ${hexPart}  |${asciiPart}|`);
  }
  if (bytes.length > maxBytes) {
    lines.push(`... [truncated, total ${bytes.length} bytes]`);
  }
  return lines.join("\n");
}

export default function Base64Client() {
  const [mode, setMode] = useState<"decode" | "encode">("decode");
  const [input, setInput] = useState<string>("");
  const [alphabet, setAlphabet] = useState<Base64Alphabet>("standard");
  const [encoding, setEncoding] = useState<TextEncoding>("utf-8");
  const [outputView, setOutputView] = useState<"text" | "hex">("text");
  const [copied, setCopied] = useState(false);
  const [, startTransition] = useTransition();

  const inputId = useId();

  // Computed results
  const jwtInfo = mode === "decode" ? inspectJwt(input) : { isJwt: false };

  let decodedResult: { text: string; bytes: Uint8Array; error?: string } = {
    text: "",
    bytes: new Uint8Array(0),
  };
  let encodedResult = "";

  if (mode === "decode") {
    decodedResult = decodeBase64(input, encoding);
  } else {
    encodedResult = encodeBase64(input, alphabet, encoding);
  }

  const hexDump = mode === "decode" ? generateHexDump(decodedResult.bytes) : "";
  const detectedMime = mode === "decode" ? guessMimeType(decodedResult.bytes) : null;

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleDownloadBinary = () => {
    if (!detectedMime || decodedResult.bytes.length === 0) return;
    const blob = new Blob([decodedResult.bytes as unknown as BlobPart], { type: detectedMime.mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `decoded-file.${detectedMime.ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const { readFile, cancelRead, fileError } = useFileReader(result => {
    const marker = result.indexOf(";base64,");
    if (marker !== -1) {
      startTransition(() => { setInput(result.slice(marker + 8)); setMode("decode"); });
    }
  }, "dataURL");
  React.useEffect(() => { cancelRead(); }, [input, mode, cancelRead]);

  const { ref: dropRef, dragging } = usePageFileDrop(files => readFile(files[0]));

  return (
    <div ref={dropRef} className="space-y-6">
      {dragging && <div role="status" className="pointer-events-none fixed inset-3 z-[100] flex items-center justify-center rounded-xl border-2 border-accent bg-background/95 p-6 text-xl font-semibold">Drop a file to load as Base64</div>}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setMode("decode")}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
              mode === "decode"
                ? "bg-surface text-foreground shadow-pop"
                : "bg-surface text-foreground hover:bg-surface-elevated"
            }`}
          >
            Decode Mode
          </button>
          <button
            type="button"
            onClick={() => setMode("encode")}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
              mode === "encode"
                ? "bg-surface text-foreground shadow-pop"
                : "bg-surface text-foreground hover:bg-surface-elevated"
            }`}
          >
            Encode Mode
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-mono text-foreground-muted flex items-center gap-1.5">
            Charset:
            <select
              value={encoding}
              onChange={(e) => setEncoding(e.target.value as TextEncoding)}
              className="rounded-lg bg-surface-elevated px-3 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
            >
              <option value="utf-8">UTF-8</option>
              <option value="ascii">ASCII</option>
              <option value="utf-16le">UTF-16 LE</option>
            </select>
          </label>

          {mode === "encode" && (
            <label className="text-xs font-mono text-foreground-muted flex items-center gap-1.5">
              Alphabet:
              <select
                value={alphabet}
                onChange={(e) => setAlphabet(e.target.value as Base64Alphabet)}
                className="rounded-lg bg-surface-elevated px-3 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
              >
                <option value="standard">Standard (+ / =)</option>
                <option value="url-safe">URL-Safe (- _ no pad)</option>
              </select>
            </label>
          )}

        </div>
      </div>

      {/* JWT Notification Banner */}
      {jwtInfo.isJwt && (
        <div className="p-4 bg-accent-soft border border-accent rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-accent">
              <span className="w-2 h-2 rounded-full bg-accent-solid" />
              JSON Web Token (JWT) Detected
            </span>
            {jwtInfo.payload?.exp && (
              <span className="text-xs font-mono text-foreground-muted">
                Expires:{" "}
                <span className="font-semibold text-foreground">
                  {new Date(jwtInfo.payload.exp * 1000).toUTCString()}
                </span>{" "}
                {/* Read from the inspection result rather than calling Date.now()
                    here: an impure call during render makes the output depend on
                    when React happens to re-render. */}
                <span className={jwtInfo.isExpired ? "text-danger" : "text-accent"}>
                  ({jwtInfo.isExpired ? "Expired" : "Valid"})
                </span>
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="text-xs font-mono font-semibold text-foreground-muted mb-1">
                Header
              </div>
              <pre className="overflow-x-auto rounded-lg bg-surface-elevated p-3 font-mono text-xs text-accent">
                {JSON.stringify(jwtInfo.header, null, 2)}
              </pre>
            </div>
            <div>
              <div className="text-xs font-mono font-semibold text-foreground-muted mb-1">
                Payload Claims
              </div>
              <pre className="overflow-x-auto rounded-lg bg-surface-elevated p-3 font-mono text-xs text-accent">
                {JSON.stringify(jwtInfo.payload, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Editor & Output Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Pane */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label
              htmlFor={inputId}
              className="text-2xs text-foreground-subtle"
            >
              {mode === "decode" ? "Base64 Input Payload" : "Plaintext Input to Encode"}
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  cancelRead();
                  setInput(
                    mode === "decode"
                      ? "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFsaWNlIEVuZ2luZWVyIiwiaWF0IjoxNTE2MjM5MDIyLCJleHAiOjE5MTYyMzkwMjJ9.4pcPyMD09olUV_Alwywh5i14ncPQ44U35UjjW5_XXn8"
                      : "Hello from ToolsByUs! Fast, secure and 100% browser-based."
                  );
                }}
                className="inline-flex items-center gap-1 rounded bg-accent-soft px-2 py-0.5 text-xs font-mono text-accent hover:bg-accent-solid hover:text-on-accent transition-colors"
              >
                Try Example
              </button>
              <label className="text-xs font-mono text-accent hover:text-accent cursor-pointer">
                Upload File
                <input
                  type="file"
                  onChange={event => { readFile(event.target.files?.[0]); event.target.value = ""; }}
                  className="sr-only"
                />
              </label>
              <button
                type="button"
                onClick={() => { cancelRead(); setInput(""); }}
                className="text-xs font-mono text-foreground-muted hover:text-foreground"
              >
                Clear
              </button>
            </div>
          </div>
          {fileError && <p role="alert" className="text-sm text-danger">{fileError}</p>}
          <textarea
            id={inputId}
            value={input}
            onChange={(e) => { cancelRead(); setInput(e.target.value); }}
            placeholder={
              mode === "decode"
                ? "Paste Base64 string, URL-safe Base64, or JWT here..."
                : "Type or paste text to encode into Base64..."
            }
            rows={14}
            className="w-full resize-y rounded-lg bg-surface-elevated p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
            spellCheck={false}
          />
          <div className="text-xs font-mono text-foreground-muted flex justify-between">
            <span>Length: {input.length} chars</span>
            <span>Est. Bytes: {new TextEncoder().encode(input).length} B</span>
          </div>
        </div>

        {/* Output Pane */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xs text-foreground-subtle">
                {mode === "decode" ? "Decoded Result" : "Encoded Base64 Output"}
              </span>
              {mode === "decode" && (
                <div className="inline-flex rounded-pill bg-surface p-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setOutputView("text")}
                    className={`px-2 py-0.5 rounded ${
                      outputView === "text"
                        ? "bg-surface text-foreground shadow-pop font-semibold"
                        : "text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    Text
                  </button>
                  <button
                    type="button"
                    onClick={() => setOutputView("hex")}
                    className={`px-2 py-0.5 rounded ${
                      outputView === "hex"
                        ? "bg-surface text-foreground shadow-pop font-semibold"
                        : "text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    Hex Dump
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {mode === "decode" && decodedResult.bytes.length > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadBinary}
                  className="rounded-pill bg-surface px-3.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-border"
                >
                  Download .{detectedMime?.ext}
                </button>
              )}
              <button
                type="button"
                onClick={() =>
                  handleCopy(
                    mode === "decode"
                      ? outputView === "hex"
                        ? hexDump
                        : decodedResult.text
                      : encodedResult
                  )
                }
                className="rounded-pill bg-accent-solid px-4 py-1.5 text-xs font-semibold text-accent-on transition-colors hover:bg-accent-hover"
              >
                {copied ? "Copied!" : "Copy Output"}
              </button>
            </div>
          </div>

          {mode === "decode" && decodedResult.error ? (
            <div className="p-4 bg-danger-soft border border-danger rounded-lg text-danger font-mono text-xs">
              {decodedResult.error}
            </div>
          ) : (
            <pre className="h-[336px] w-full select-all overflow-auto whitespace-pre-wrap rounded-lg bg-surface-elevated p-3 font-mono text-xs">
              {mode === "decode"
                ? outputView === "hex"
                  ? hexDump
                  : decodedResult.text || "(empty result)"
                : encodedResult || "(empty result)"}
            </pre>
          )}

          <div className="text-xs font-mono text-foreground-muted flex justify-between">
            <span>
              {mode === "decode"
                ? `Decoded Size: ${decodedResult.bytes.length} bytes`
                : `Encoded Size: ${encodedResult.length} characters`}
            </span>
            {mode === "decode" && detectedMime && (
              <span>Detected Type: {detectedMime.mime}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
