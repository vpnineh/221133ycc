import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryLastReviewed, categoryOf } from "@/lib/tools";
import { CONTENT_LAST_REVIEWED } from "@/lib/site";

const CATEGORY = categoryOf("encode")!;
/*
 * The same date the sitemap publishes for this URL: the newest review date
 * among the tools listed below. Hard-coded, it disagreed with its own
 * <lastmod> on the two hubs whose newest tool was reviewed after this date.
 */
const LAST_REVIEWED = categoryLastReviewed(CATEGORY.id) ?? CONTENT_LAST_REVIEWED;

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "Encoding Tools — Base64, JWT, Hashes, URLs",
  socialTitle: "Encoding Tools",
  description:
    "Base64 and URL-safe Base64, encode and decode, with binary download and correct UTF-8 handling. Runs in your browser — a token you paste is never transmitted.",
});

export default function EncodeToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These encoding tools convert between text, binary and their transport-safe representations. Everything runs in your browser, which matters more here than anywhere else on the site: the strings people decode are usually credentials, and pasting one into a server-side decoder is how it ends up in a log."
      faqs={[
        {
          question: "Is it safe to decode a token here?",
          answer:
            "Safer than anywhere that does it on a server, because the decoding happens in your own browser and the string is never transmitted. Open DevTools, switch to the Network panel and paste a token — no request carries it. That said, treat any credential you have pasted into any browser tab as one you should rotate if the machine is not yours.",
        },
        {
          question: "What is the difference between Base64 and URL-safe Base64?",
          answer:
            "They differ in two characters of the alphabet. Standard Base64 (RFC 4648 §4) uses + and /, which both have meaning inside a URL and get mangled by percent-encoding. URL-safe Base64 (§5) substitutes - and _ so the string survives being put in a query parameter or a path segment, and usually drops the = padding as well. JWTs use the URL-safe variant, which is why pasting a JWT segment into a standard decoder often fails.",
        },
        {
          question: "Why does my decoded text show replacement characters?",
          answer:
            "Because the bytes are not UTF-8 text. Base64 encodes arbitrary bytes; it carries no information about what those bytes mean. If the payload is a PNG, a protobuf message or a gzip stream, interpreting it as text produces mojibake. Use the binary download instead — the decoder hands you the actual bytes as a file rather than guessing at an encoding.",
        },
        {
          question: "Does encoding to Base64 make data secure?",
          answer:
            "No, and this is worth being blunt about because it is a recurring source of real breaches. Base64 is an encoding, not encryption: it is fully reversible by anyone, with no key. It exists to move binary data through channels that only accept text. A Base64 string in a config file or a URL should be treated as plainly visible.",
        },
        {
          question: "Is there a size limit?",
          answer:
            "8 MB of input, which is the main-thread ceiling used across the site. Base64 expands data by roughly a third, so an 8 MB binary produces about 10.7 MB of text. Above the ceiling the tool declines with a clear message rather than locking the tab.",
        },
      ]}
      intro={
        <>
          <p>
            Encoding is the least glamorous category here and the one where a bad tool does the most
            damage. The strings people decode in a hurry are, overwhelmingly, secrets: a bearer
            token from a failing request, a Kubernetes secret, a basic-auth header, a signed cookie,
            a session identifier from a support ticket. Every one of those is a live credential at
            the moment you paste it.
          </p>
          <p>
            Most online decoders post that string to a server. Even the well-intentioned ones write
            it to an access log, and an access log is exactly the kind of file that gets shipped to
            a third-party aggregator and retained for ninety days. The tool solved your problem in
            two seconds and quietly created a much larger one.
          </p>
          <p>
            Doing it in the browser removes that entirely. There is no request to trust, because
            there is no request — the decoder is JavaScript in the page you already have open, and
            you can confirm it in the Network panel in the time it takes to read this paragraph.
          </p>
          <p>
            The other thing a decoder has to get right is that Base64 does not describe its own
            contents. It is a mapping from bytes to text, and the bytes underneath might be UTF-8,
            might be a PNG, might be a gzip stream, might be a protobuf message. A decoder that
            always renders the result as a string is lying to you a meaningful fraction of the time,
            so these tools decode to bytes first and let you choose: view as text, or download the
            actual binary and open it with something that understands it.
          </p>
          <p>
            The alphabet matters too. Standard Base64 and URL-safe Base64 differ in two characters
            and in whether padding is present, and getting that wrong is the single most common
            reason a decode fails. Rather than making you work it out, the decoder accepts both,
            tolerates missing padding, and tells you which variant it detected.
          </p>
          <p>
            Encoding is frequently a step rather than a destination. If the decoded result is JSON —
            which, for tokens and config blobs, it usually is — take it straight to the{" "}
            <Link href="/json-formatter">JSON Formatter</Link> to make it readable, or the{" "}
            <Link href="/json-validator">JSON Validator</Link> if it does not parse. If you need an
            identifier rather than a conversion, the{" "}
            <Link href="/uuid-generator">UUID Generator</Link> is next door.
          </p>
        </>
      }
    />
  );
}
