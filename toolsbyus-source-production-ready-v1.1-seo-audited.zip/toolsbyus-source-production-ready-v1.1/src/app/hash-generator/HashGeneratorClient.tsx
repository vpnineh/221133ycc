"use client";

import React, { useEffect, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { checkbox, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import {
  ALGORITHMS,
  algorithmInfo,
  hashText,
  hmac,
  toBase64,
  toHex,
  type HashAlgorithm,
} from "../../lib/hash";
import { relatedTools } from "../../lib/tools";

const STATUS_STYLE: Record<string, string> = {
  broken: "text-del",
  legacy: "text-mod",
  secure: "text-add",
  "not-a-hash": "text-foreground-subtle",
};

const STATUS_LABEL: Record<string, string> = {
  broken: "broken",
  legacy: "legacy",
  secure: "current",
  "not-a-hash": "checksum",
};

const SAMPLE = "The quick brown fox jumps over the lazy dog";

export const HashGeneratorClient: React.FC = () => {
  const [input, setInput] = useState("");
  const [encoding, setEncoding] = useState<"hex" | "base64">("hex");
  const [uppercase, setUppercase] = useState(false);
  const [useHmac, setUseHmac] = useState(false);
  const [key, setKey] = useState("secret");
  const [digests, setDigests] = useState<Record<string, string>>({});

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      const next: Record<string, string> = {};
      for (const algorithm of ALGORITHMS) {
        try {
          const canHmac = algorithm.id !== "MD5" && algorithm.id !== "CRC32";
          const bytes =
            useHmac && canHmac
              ? await hmac(key, input, algorithm.id as Exclude<HashAlgorithm, "MD5" | "CRC32">)
              : await hashText(input, algorithm.id);
          const rendered = encoding === "hex" ? toHex(bytes) : toBase64(bytes);
          next[algorithm.id] =
            useHmac && !canHmac
              ? "— HMAC is not offered for this algorithm"
              : uppercase && encoding === "hex"
                ? rendered.toUpperCase()
                : rendered;
        } catch (error) {
          next[algorithm.id] = `error: ${(error as Error).message}`;
        }
      }
      if (!cancelled) setDigests(next);
    };

    void run();
    return () => {
      cancelled = true;
    };
  }, [input, encoding, uppercase, useHmac, key]);

  return (
    <ToolShell
      wide
      slug="hash-generator"
      keyword="Hash Generator"
      directAnswer="Hash Generator computes MD5, SHA-1, SHA-256, SHA-384, SHA-512, CRC32 and HMAC in your browser. Every result carries the algorithm's security status, because the single most consequential fact about MD5 and SHA-1 is that both are broken — and a tool that offers them without saying so is part of the problem."
      breadcrumbs={[
        { name: "Encoding Tools", url: "/encode-tools" },
        { name: "Hash Generator", url: "/hash-generator" },
      ]}
      seoDescription="Generate MD5, SHA-1, SHA-256, SHA-384, SHA-512, CRC32 and HMAC hashes in the browser. Hex or base64 output, UTF-8 input, security status shown for each algorithm. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A hash maps any input to a fixed-length value such that finding two inputs with the
              same output should be infeasible. &ldquo;Should be&rdquo; is doing a lot of work in
              that sentence, and which algorithms still satisfy it is the most useful thing this page
              can tell you.
            </p>
            <h3>MD5 and SHA-1 are broken, and it is not theoretical</h3>
            <p>
              MD5 collisions can be produced on a laptop in seconds, and were used in the wild: the
              Flame malware forged a Microsoft code-signing certificate with an MD5 collision in
              2012. SHA-1 fell in 2017 when Google and CWI produced two PDFs with the same digest,
              and the cost has dropped since. Neither is acceptable for a signature, for integrity
              against an adversary, or for deduplicating input you do not control. Both are fine as
              non-security checksums, and both are still everywhere, which is why they are here.
            </p>
            <h3>A hash is not a password hash</h3>
            <p>
              SHA-256 is designed to be fast — billions of operations per second on a GPU — and speed
              is precisely wrong for a password, where the defence is being slow enough that guessing
              costs more than the password is worth. Storing SHA-256 of a password, salted or not,
              means an attacker with the database tries the entire common-password list in minutes.
              The right tools are bcrypt, scrypt and Argon2, all of which have a deliberate cost
              factor. Nothing on this page is a password hash.
            </p>
            <h3>HMAC is not &ldquo;hash the key and the message&rdquo;</h3>
            <p>
              The obvious construction, <code>H(key || message)</code>, is broken on any
              Merkle–Damgård hash — which includes MD5, SHA-1 and SHA-256. An attacker who knows the
              digest and the key&apos;s length can append data and compute a valid digest for the
              extended message without ever seeing the key. This is the length-extension attack, and
              it is why HMAC exists as a separate primitive with its nested inner and outer hashes.
              SHA-384 and SHA-512/256 are immune by construction, being truncated.
            </p>
            <h3>The encoding of the input changes the hash</h3>
            <p>
              Hashing is defined over bytes, not characters, so the digest of{" "}
              <code>caf&eacute;</code> depends on whether the accented character is the two UTF-8
              bytes <code>C3 A9</code> or the single Latin-1 byte <code>E9</code>. This page uses
              UTF-8 throughout, which is what every current system means. A signature that verifies
              locally and fails in production is very often this.
            </p>
            <h3>CRC32 is not a hash at all</h3>
            <p>
              It is an error-detecting checksum designed for transmission faults, and it is trivial
              to construct a collision on purpose. With only 32 bits it also collides by accident
              after roughly 65,000 inputs, by the birthday bound. Correct for catching a corrupted
              download; wrong for anything else.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `abc`,
        outputTitle: "Digests",
        exampleOutput: `MD5     900150983cd24fb0d6963f7d28e17f72   broken
SHA-1   a9993e364706816aba3e25717850c26c9cd0d89d  broken
SHA-256 ba7816bf8f01cfea414140de5dae2223b0…      current`,
      }}
      referenceTable={{
        title: "Algorithms and status",
        rows: ALGORITHMS.map((algorithm) => ({
          parameter: algorithm.label,
          type: `${algorithm.bits}-bit`,
          defaultVal: STATUS_LABEL[algorithm.status],
          description: algorithm.note,
        })).concat([
          {
            parameter: "HMAC",
            type: "keyed",
            defaultVal: "SHA family only",
            description:
              "A keyed construction that resists length extension, unlike hashing a key and a message together. Offered for the SHA algorithms; MD5 and CRC32 are excluded because HMAC over a broken hash is a broken MAC.",
          },
          {
            parameter: "Input encoding",
            type: "UTF-8",
            defaultVal: "always",
            description:
              "Hashing is defined over bytes. A digest of the same text differs between UTF-8 and Latin-1, which is a recurring cause of signatures that verify locally and fail in production.",
          },
          {
            parameter: "Output",
            type: "hex or base64",
            defaultVal: "hex",
            description:
              "The same bytes in two renderings. Hex is what command-line tools print; base64 is what many HTTP headers carry.",
          },
        ]),
      }}
      faqs={[
        {
          question: "Can I use this to hash passwords?",
          answer:
            "No — and this is the most important answer on the page. Every algorithm here is designed to be fast, and speed is exactly what you do not want for a password: an attacker with your database and a GPU tries billions of candidates per second. Use bcrypt, scrypt or Argon2, all of which have a tunable cost factor that makes each guess expensive. Salting a SHA-256 helps against rainbow tables and does nothing against a modern cracking rig.",
        },
        {
          question: "Is MD5 really broken? It is still everywhere.",
          answer:
            "Both are true. Collisions are practical — you can produce two files with the same MD5 on a laptop — and MD5 collisions were used in a real attack to forge a Microsoft code-signing certificate. It remains everywhere as a non-security checksum, in ETags and file-integrity checks against accidental corruption, and that use is fine. What is not fine is anything where an adversary chooses the input.",
        },
        {
          question: "Why does my digest differ from another tool's?",
          answer:
            "Almost always the input, not the algorithm. Check for a trailing newline — a file ends with one and a text box usually does not, and a single byte changes everything. Then check the encoding: this page uses UTF-8, and a tool defaulting to Latin-1 will give a different digest for any non-ASCII character. Finally check whether the other tool hashed the file's bytes or its base64 representation.",
        },
        {
          question: "What is HMAC for?",
          answer:
            "Proving that a message came from someone holding a shared secret and was not modified. It is what signs a webhook payload, an API request and a session cookie. The reason it is a distinct primitive rather than just hashing the key with the message is length extension: with most hashes, knowing H(key || message) lets an attacker compute a valid digest for a longer message without the key. HMAC's nested construction prevents that.",
        },
        {
          question: "Which SHA should I use?",
          answer:
            "SHA-256 unless you have a reason otherwise — it is the default everywhere, well analysed and fast enough. SHA-512 is genuinely faster on 64-bit hardware despite the longer output. SHA-384 is SHA-512 truncated, which makes it immune to length extension, and is the right pick if you are building something that hashes a secret directly rather than using HMAC.",
        },
        {
          question: "Is my input uploaded?",
          answer:
            "No. SHA hashing uses the browser's built-in SubtleCrypto; MD5 and CRC32 are implemented in JavaScript on this page because SubtleCrypto deliberately refuses to implement MD5. Nothing leaves the tab, which matters because the things people hash are frequently API secrets, tokens and file contents.",
        },
      ]}
      relatedTools={relatedTools("/hash-generator").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Output</span>
            <div className={segmentTrack} role="group" aria-label="Output encoding">
              {(["hex", "base64"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setEncoding(value)}
                  aria-pressed={encoding === value}
                  className={segment(encoding === value)}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>

          {encoding === "hex" && (
            <label
              htmlFor="hash-upper"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="hash-upper"
                type="checkbox"
                checked={uppercase}
                onChange={(e) => setUppercase(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>Uppercase</span>
            </label>
          )}

          <label
            htmlFor="hash-hmac"
            className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
          >
            <input
              id="hash-hmac"
              type="checkbox"
              checked={useHmac}
              onChange={(e) => setUseHmac(e.target.checked)}
              className={checkbox}
            />
            <span className={fieldLabel}>HMAC</span>
          </label>

          {useHmac && (
            <div className="flex items-center gap-2">
              <label htmlFor="hash-key" className={fieldLabel}>
                Key
              </label>
              <input
                id="hash-key"
                type="text"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                spellCheck={false}
                className={`${field} w-44`}
              />
            </div>
          )}
        </div>

        <CodePane
          label="Input"
          value={input}
          onChange={setInput}
          placeholder="Type or paste anything…"
          height={140}
          onLoadExample={() => setInput(SAMPLE)}
        />

        <div className="overflow-x-auto rounded-lg border border-border bg-surface">
          <table className="w-full min-w-[40rem] border-collapse text-left font-mono text-xs">
            <caption className="sr-only">Digests</caption>
            <thead>
              <tr className="border-b border-border">
                <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                  Algorithm
                </th>
                <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                  Status
                </th>
                <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                  Digest
                </th>
              </tr>
            </thead>
            <tbody>
              {ALGORITHMS.map((algorithm) => {
                const info = algorithmInfo(algorithm.id);
                return (
                  <tr key={algorithm.id} className="border-b border-border last:border-0">
                    <th
                      scope="row"
                      className="whitespace-nowrap px-3 py-2 text-left font-medium text-foreground"
                    >
                      {algorithm.label}
                      <span className="ml-2 text-2xs font-normal text-foreground-subtle">
                        {algorithm.bits}
                      </span>
                    </th>
                    <td className={`whitespace-nowrap px-3 py-2 ${STATUS_STYLE[info.status]}`}>
                      {STATUS_LABEL[info.status]}
                    </td>
                    <td className="break-all px-3 py-2 text-foreground">
                      {digests[algorithm.id] ?? "…"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <Notice tone="warn">
          None of these is a password hash. SHA-256 is designed to be fast, which is exactly wrong
          for a password: an attacker with your database tries billions of candidates per second.
          Use bcrypt, scrypt or Argon2, which have a deliberate cost factor.
        </Notice>
      </div>
    </ToolShell>
  );
};
