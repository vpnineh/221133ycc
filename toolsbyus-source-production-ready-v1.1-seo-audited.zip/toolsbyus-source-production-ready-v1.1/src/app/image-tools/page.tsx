import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryLastReviewed, categoryOf } from "@/lib/tools";
import { CONTENT_LAST_REVIEWED } from "@/lib/site";

const CATEGORY = categoryOf("image")!;
/*
 * The same date the sitemap publishes for this URL: the newest review date
 * among the tools listed below. Hard-coded, it disagreed with its own
 * <lastmod> on the two hubs whose newest tool was reviewed after this date.
 */
const LAST_REVIEWED = categoryLastReviewed(CATEGORY.id) ?? CONTENT_LAST_REVIEWED;

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "Image Tools — Compress, Resize, Convert, Crop",
  socialTitle: "Image Tools",
  description:
    "Compress, resize, convert and crop images in your browser. No upload, no account, no watermark — the photo never leaves the tab it was dropped in.",
});

export default function ImageToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These image tools run entirely in your browser, using the same JPEG, PNG and WebP codecs your browser already uses to display and save images. Your photo is decoded, edited and encoded in this tab and never uploaded — the page's Content-Security-Policy sets connect-src 'self', so the browser itself would block an upload attempt."
      faqs={[
        {
          question: "Why do these tools not upload my images?",
          answer:
            "Because they do not need to. Your browser already contains JPEG, PNG and WebP codecs written in C, with hardware acceleration, used every time it displays or saves a picture. A server round trip adds latency, a queue, a size limit set by someone else's bandwidth bill, and a copy of your photograph on a machine you do not control. Doing the work locally is faster and removes the copy.",
        },
        {
          question: "Is the quality as good as a desktop application?",
          answer:
            "For these operations, yes — they use the same codecs. Where a naive browser tool does lose quality is in scaling: drawing a 4000-pixel image straight into a 400-pixel canvas makes the browser sample a handful of source pixels per destination pixel and ignore the rest, which aliases fine detail rather than averaging it. These tools step down by halves instead, which is what an image library does internally, so the result is as sharp as the source allows.",
        },
        {
          question: "Does this work with HEIC photos from an iPhone?",
          answer:
            "Yes. HEIC wraps HEVC, which is patent-encumbered, so Chrome and Firefox refuse to decode it while Safari can. When the browser refuses a file whose bytes are a HEIF container, a WebAssembly build of libheif is downloaded and does the decoding locally. It is about two megabytes and is fetched only in that case, so nobody converting a JPEG pays for it.",
        },
        {
          question: "Is there a file size limit or a watermark?",
          answer:
            "No watermark, ever — there is no paid tier here, so there is nothing to restrict you into buying. The limits are 100 MB per file, 250 MB in total and 100 files per selection, and they come from what a browser tab can hold rather than from a paywall: a 12-megapixel photo is 48 MB of raw pixels once decoded, and several of those at once is what actually kills a mobile browser.",
        },
        {
          question: "What happens to EXIF data and GPS coordinates?",
          answer:
            "They are dropped. Every tool here decodes to raw pixels and re-encodes from them, and metadata blocks are not carried across — so camera model, timestamp and location do not survive into the output. That is usually exactly what you want before posting a photo publicly. The one tag that is honoured rather than discarded is orientation: it is applied to the pixels, so a photo taken sideways comes out upright instead of losing its tag and falling over.",
        },
        {
          question: "Do these tools work offline?",
          answer:
            "Yes. Load a page once and it keeps working with the network disconnected, because there is nothing on the other end to talk to — the site is a static export with no API routes, and the codecs are your browser's own. The single exception is the first HEIC conversion, which has to download the libheif decoder; after that it is cached like any other asset.",
        },
      ]}
      intro={
        <>
          <p>
            Every free image tool asks you to upload. It is presented as the obvious way to do
            things — drag your file here, we will send you a link — and for a stock photograph it
            genuinely does not matter. For the images people actually compress and convert it
            matters a great deal, because those are photographs of their children, scans of
            documents, screenshots of work in progress, and pictures taken inside their homes.
          </p>
          <p>
            Uploading one means a full-resolution copy now exists on a server you do not control,
            complete with whatever the camera wrote into it — including, on a phone photograph, the
            GPS coordinates of where it was taken. It is in the access log, the backup, the object
            store. The reassuring sentence about files being deleted after an hour describes an
            intention, not a mechanism anyone outside the company can verify.
          </p>
          <p>
            The upload is also unnecessary, which is the part worth dwelling on. Your browser
            already contains decoders and encoders for JPEG, PNG and WebP, written in C and
            hardware-accelerated, used every single time it displays or saves an image. Sending a
            photograph across the internet so that a server can run the same codecs and send it back
            adds latency, a queue and a size limit, and buys nothing at all.
          </p>
          <p>
            So these tools do it here. The photo is decoded with <code>createImageBitmap</code>,
            drawn into a canvas, and encoded with <code>canvas.toBlob</code> — three pieces of your
            own browser, running in this tab. There is no request to inspect and no endpoint to
            trust, and if you would rather check than take that on faith, the Network panel in
            DevTools settles it in ten seconds.
          </p>
          <p>
            The privacy claim is enforced rather than promised: the site is served with a
            Content-Security-Policy including <code>connect-src &apos;self&apos;</code>, which tells
            the browser to refuse any request to another origin. If a future bug or a compromised
            dependency tried to upload your photograph, the browser would block it before anything
            left the machine.
          </p>
          <p>
            One thing genuinely does require more than the browser has. HEIC — the format an iPhone
            saves photos in — wraps HEVC, whose decoders are patent-licensed, and Chrome and Firefox
            have declined to ship one. Rather than showing a broken page to most visitors, the{" "}
            <Link href="/heic-to-jpg">HEIC to JPG</Link> tool carries a WebAssembly build of libheif
            and loads it on demand: about two megabytes, fetched only when the browser has already
            refused a file, so nobody converting a JPEG pays for it.
          </p>
          <p>
            If you are not sure where to start:{" "}
            <Link href="/compress-image">Compress Image</Link> when a form is rejecting your file
            for being too large, <Link href="/resize-image">Resize Image</Link> when the dimensions
            rather than the quality are the problem,{" "}
            <Link href="/convert-image">Convert Image</Link> to move between JPG, PNG, WebP and
            AVIF, and <Link href="/crop-image">Crop Image</Link> when a platform would otherwise
            centre-crop your photograph badly.
          </p>
        </>
      }
    />
  );
}
