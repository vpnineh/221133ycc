"use client";

import React, { useState, useMemo, useDeferredValue } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SizeNotice } from "../../components/tools/SizeNotice";
import { RepairPanel } from "../../components/tools/RepairPanel";
import { checkMainThreadSize } from "../../lib/limits";
import { CodePane } from "../../components/tools/CodePane";
import { formatJson } from "../../lib/json/formatter";
import { FormatOptions } from "../../lib/json/types";
import { checkbox, field } from "../../components/common/controls";

const DEFAULT_SAMPLE = JSON.stringify({
  apiEndpoint: "https://gateway.toolsbyus.com/v1/metrics",
  activeSessions: 1420,
  clusterStatus: "OPERATIONAL",
  datacenter: {
    name: "us-east-dc3",
    racks: 64,
    powerRedundancy: true
  },
  supportedProtocols: ["HTTP/1.1", "HTTP/2", "HTTP/3", "gRPC"],
  rateLimits: {
    burst: 1000,
    sustainedPerSecond: 250
  }
});

export const JsonBeautifierClient: React.FC = () => {
  const [inputRaw, setInputRaw] = useState("");

  // Heavy derivation runs against a deferred copy so a multi-megabyte paste
  // does not block keystrokes: React keeps the textarea responsive and catches
  // the results up at lower priority.
  const inputRawDeferred = useDeferredValue(inputRaw);
  const [indent, setIndent] = useState<number | "tab">(2);
  const [sortKeys, setSortKeys] = useState(true);
  const [escapeUnicode, setEscapeUnicode] = useState(false);

  const formatOptions: FormatOptions = useMemo(
    () => ({
      indent,
      sortKeys,
      escapeUnicode,
    }),
    [indent, sortKeys, escapeUnicode]
  );

  // Refuse oversized input before it blocks the main thread — the reference
  // table on this page documents the same ceiling.
  const sizeCheck = useMemo(() => checkMainThreadSize(inputRawDeferred), [inputRawDeferred]);

  const formatResult = useMemo(() => {
    if (!inputRawDeferred.trim()) {
      return { success: true, formatted: "" };
    }
    if (sizeCheck.exceeded) {
      return { success: false as const, error: sizeCheck.message ?? "Input too large" };
    }
    return formatJson(inputRawDeferred, formatOptions);
  }, [inputRawDeferred, formatOptions, sizeCheck]);

  return (
    <ToolShell
      wide
      slug="json-beautifier"
      keyword="JSON Beautifier"
      directAnswer="JSON Beautifier transforms unformatted, minified, or disorganized JSON data into visually clean, human-readable code. It provides customizable indentation levels (2 spaces, 4 spaces, or tabs), alphabetical key sorting for visual scanning, unicode escape controls, and comment tolerance while executing entirely inside your browser."
      seoDescription="Beautify and pretty-print JSON documents with custom indentation widths, key sorting, and zero server transmission."
      breadcrumbs={[{ name: "JSON Beautifier", url: "/json-beautifier" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              In modern API architectures, logs, network traces, and webhook payloads arrive as continuous single-line strings. Reading and auditing minified text by hand creates severe cognitive fatigue and increases the likelihood of overlooking security flaws, missing tokens, or malformed data types.
            </p>
            <p>
              The ToolsByUs JSON Beautifier re-establishes visual hierarchy through structured AST deserialization and disciplined indentation generation:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Predictable Lexical Sorting:</strong> Enabling <code>Sort Keys</code> alphabetizes object properties across every level of the document hierarchy. This standardizes property locations and makes visual scanning instantaneous during code review or troubleshooting.</li>
              <li><strong>Configurable Indentation Widths:</strong> Two spaces is the JavaScript convention, four is the norm in Python and much of the backend world, and a hardware tab lets each reader pick their own width. None is more correct than the others; the only wrong answer is mixing them in one file.</li>
              <li><strong>Bracket Style & Delimiter Formatting:</strong> Choose between traditional compact opening brackets (K&R style on the same line) and expanded formatting that maximizes vertical scanability for deeply nested collection arrays.</li>
              <li><strong>Safe Unicode Escaping:</strong> Choose whether non-ASCII characters (such as multilingual strings, emojis, or international currency symbols) are preserved in native UTF-8 or escaped to safe <code>\uXXXX</code> hexadecimal escape sequences under RFC 8259 Section 7.</li>
              <li><strong>JSONC Comment Stripping:</strong> Tolerates developer comments (<code>{"//"}</code> and <code>{"/* */"}</code>) often found in configuration files like <code>tsconfig.json</code> or VS Code settings, converting them into standard RFC-compliant JSON.</li>
              <li><strong>Local Computation Guarantee:</strong> Beautification occurs 100% in-browser. Proprietary payloads, API tokens, and customer records never cross the wire.</li>
            </ul>
            <p>
              The beautifier operates by parsing input text into an AST, traversing nodes recursively with depth tracking, emitting spaces or tabs according to configured indent widths, inserting newlines between object pairs and array items, and appending matching closing brackets at matching indentation levels.
            </p>
          </>
        ),
        inputTitle: "Minified Unformatted Input",
        exampleInput: `{"id":42,"title":"Log Event","active":true,"tags":["prod","payment"]}`,
        exampleOutput: `{\n  "active": true,\n  "id": 42,\n  "tags": [\n    "prod",\n    "payment"\n  ],\n  "title": "Log Event"\n}`,
      }}
      referenceTable={{
        title: "Beautifier Configuration & Display Settings",
        rows: [
          {
            parameter: "Indentation: 2 Spaces",
            type: "Formatting Style",
            defaultVal: "2 spaces",
            description: "Standard web and TypeScript convention that minimizes horizontal scrolling on deeply nested trees.",
          },
          {
            parameter: "Indentation: 4 Spaces",
            type: "Formatting Style",
            defaultVal: "4 spaces",
            description: "High-contrast visual indentation favored in backend systems, Python, and command-line terminals.",
          },
          {
            parameter: "Indentation: Tab",
            type: "Formatting Style",
            defaultVal: "\\t",
            description: "Hardware tab characters allowing individual developers to customize tab widths in their local IDEs.",
          },
          {
            parameter: "Sort Keys",
            type: "Normalization",
            defaultVal: "true",
            description: "Alphabetically sorts all dictionary keys at every nesting level for consistent visual scanning and reproducible output.",
          },
          {
            parameter: "Escape Unicode",
            type: "Encoding Option",
            defaultVal: "false",
            description: "Encodes characters outside ASCII into \\uXXXX hex sequences for ASCII-only legacy transport layers.",
          },
          {
            parameter: "JSONC Comment Stripping",
            type: "Syntax Recovery",
            defaultVal: "Active",
            description: "Strips single-line and multi-line comments from JSONC inputs without corrupting string literals containing slashes.",
          },
          {
            parameter: "Input Ceiling",
            type: "Performance Limit",
            defaultVal: "8 MB",
            description: "Enforced, not aspirational. Formatting runs on the main thread, so a larger paste is refused with an explanation rather than freezing the tab. Above 2 MB a caution appears. For larger documents use JSON Diff, which processes in a Web Worker.",
          },
        ],
      }}
      faqs={[
        {
          question: "What is the difference between a beautifier and a formatter?",
          answer:
            "While both share the core serialization engine, a beautifier emphasizes visual ergonomics, readability, and human comprehension (such as alphabetized key sorting, clear contrast, and bracket layout options), whereas a formatter focuses on strict syntactic conformance, JSONC comment stripping, and CLI formatting conventions.",
        },
        {
          question: "Why should I sort JSON keys alphabetically?",
          answer:
            "In JSON (RFC 8259), key order is arbitrary. When inspecting complex payloads with dozens of keys, having keys alphabetized allows developers to quickly scan for specific fields without searching the entire object, and ensures git commits don't show false diff churn caused by random key serialization order.",
        },
        {
          question: "How does the beautifier handle tabs vs spaces?",
          answer:
            "You can choose 2 spaces, 4 spaces, or hard tab characters. Spaces ensure identical rendering across every editor, while tabs respect each engineer's personal editor tab-width preference.",
        },
        {
          question: "Can I paste JSON with comments into the beautifier?",
          answer:
            "Yes! The beautifier tolerates single-line (//) and multi-line (/* */) comments, cleanly stripping them while preserving valid RFC 8259 syntax on output, and alerts you if comments were stripped.",
        },
        {
          question: "When should I enable Unicode escaping?",
          answer:
            "Enable Unicode escaping when sending JSON payloads to legacy backend APIs or protocols that only support 7-bit ASCII transmission. For modern HTTP APIs, native UTF-8 is recommended.",
        },
        {
          question: "Is my beautified data uploaded to any server?",
          answer:
            "No. All parsing and formatting logic executes strictly in your local browser runtime. Zero bytes are uploaded, ensuring full GDPR and internal security compliance.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Format and indent JSON with comment stripping and indentation options.",
        },
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Strict RFC 8259 syntax checker with exact caret error pointing.",
        },
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Semantic AST comparison tool with Web Worker processing.",
        },
        {
          href: "/json-minifier",
          title: "JSON Minifier",
          description: "Strip dead whitespace and calculate gzip size reduction percentages.",
        },
      ]}
    >
      <div className="space-y-4">
        <SizeNotice check={sizeCheck} />

        {/* Pasting malformed JSON here is common — offer the fix instead of
            just refusing to format it. */}
        {!formatResult.success && !sizeCheck.exceeded && (
          <RepairPanel value={inputRaw} onApply={setInputRaw} />
        )}
        {/* Beautifier Options Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-border bg-surface text-xs font-mono">
          <div className="flex flex-wrap items-center gap-4">
            {/* Indent size */}
            <div className="flex items-center gap-1.5">
              <label htmlFor="indent-beautify" className="text-foreground-muted font-semibold">
                Indent:
              </label>
              <select
                id="indent-beautify"
                value={indent}
                onChange={(e) => {
                  const val = e.target.value;
                  setIndent(val === "tab" ? "tab" : parseInt(val, 10));
                }}
                className={field}
              >
                <option value={2}>2 Spaces</option>
                <option value={4}>4 Spaces</option>
                <option value="tab">Tabs</option>
              </select>
            </div>

            {/* Sort Keys */}
            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted">
              <input
                type="checkbox"
                checked={sortKeys}
                onChange={(e) => setSortKeys(e.target.checked)}
                className={checkbox}
              />
              <span>Sort Keys Alphabetically</span>
            </label>

            {/* Unicode Escaping */}
            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted">
              <input
                type="checkbox"
                checked={escapeUnicode}
                onChange={(e) => setEscapeUnicode(e.target.checked)}
                className={checkbox}
              />
              <span>Escape Unicode (\\uXXXX)</span>
            </label>
          </div>

          {formatResult.hadComments && (
            <span className="text-warn text-xs flex items-center gap-1">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
              <span>JSONC comments were stripped for standard RFC 8259 output</span>
            </span>
          )}
        </div>

        {/* Panes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CodePane
            label="Input Raw JSON"
            value={inputRaw}
            onChange={setInputRaw}
            placeholder="Paste unformatted JSON here..."
            error={
              inputRaw.trim() && !formatResult.success
                ? {
                    message: formatResult.error || "Syntax error",
                    line: formatResult.line,
                    column: formatResult.column,
                    caretSnippet: formatResult.caretSnippet,
                  }
                : undefined
            }
            onLoadExample={() => setInputRaw(DEFAULT_SAMPLE)}
          />
          <CodePane
            label="Beautified Output"
            value={formatResult.formatted || ""}
            onChange={() => {}}
            readOnly
          />
        </div>
      </div>
    </ToolShell>
  );
};
