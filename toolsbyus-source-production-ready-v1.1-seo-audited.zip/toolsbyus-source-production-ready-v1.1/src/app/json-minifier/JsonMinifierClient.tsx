"use client";

import React, { useState, useMemo, useDeferredValue, useEffect } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SizeNotice } from "../../components/tools/SizeNotice";
import { checkMainThreadSize } from "../../lib/limits";
import { CodePane } from "../../components/tools/CodePane";
import { minifyJson, measureGzipSize } from "../../lib/json/minifier";
import { Icon } from "../../components/common/Icon";

const DEFAULT_SAMPLE = JSON.stringify(
  {
    transactionIdentification: "tx_99818273645",
    transactionTimestamp: "2026-09-09T02:00:00.000Z",
    transactionStatusCode: "SETTLED_SUCCESSFULLY",
    processingGatewayRoutingKey: "us-east-1a-primary",
    merchantAccountIdentifier: "acct_8827361524",
    clientApplicationMetadata: {
      clientIpAddressV4: "198.51.100.42",
      userAgentHeaderString: "ToolsByUs-API-Client/2.4.0",
      sessionAuthenticationTokenHash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    },
    paymentLedgerEntries: [
      {
        transactionIdentification: "tx_99818273645",
        transactionStatusCode: "SETTLED_SUCCESSFULLY",
        entryAmountInCents: 15400,
        currencyCodeIso4217: "USD",
        settlementTimestamp: "2026-09-09T02:00:01.120Z",
      },
      {
        transactionIdentification: "tx_99818273645",
        transactionStatusCode: "SETTLED_SUCCESSFULLY",
        entryAmountInCents: 450,
        currencyCodeIso4217: "USD",
        settlementTimestamp: "2026-09-09T02:00:01.125Z",
      },
    ],
  },
  null,
  2
);

export const JsonMinifierClient: React.FC = () => {
  const [inputRaw, setInputRaw] = useState("");

  // Heavy derivation runs against a deferred copy so a multi-megabyte paste
  // does not block keystrokes: React keeps the textarea responsive and catches
  // the results up at lower priority.
  const inputRawDeferred = useDeferredValue(inputRaw);

  const sizeCheck = useMemo(() => checkMainThreadSize(inputRawDeferred), [inputRawDeferred]);

  const minifyData = useMemo(() => {
    if (!inputRawDeferred.trim()) {
      return { success: true, result: undefined, keySuggestions: [] };
    }
    if (sizeCheck.exceeded) {
      return { success: false as const, error: sizeCheck.message ?? "Input too large" };
    }
    return minifyJson(inputRawDeferred);
  }, [inputRawDeferred, sizeCheck]);

  const stats = minifyData.result;
  const minified = stats?.minified;

  // Prefer the browser's real gzip encoder over the entropy heuristic, so the
  // figure shown is the actual wire size rather than an approximation.
  const [exactGzipBytes, setExactGzipBytes] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    // Always resolve asynchronously — including the "no input" case — so the
    // effect never calls setState synchronously during commit.
    Promise.resolve(minified ? measureGzipSize(minified) : null).then((size) => {
      if (!cancelled) setExactGzipBytes(size);
    });
    return () => {
      cancelled = true;
    };
  }, [minified]);

  return (
    <ToolShell
      wide
      slug="json-minifier"
      keyword="JSON Minifier"
      directAnswer="JSON Minifier strips all redundant whitespace, indentation, newlines, and JSONC comments from JSON payloads while strictly preserving RFC 8259 syntax integrity. It reports before-and-after byte counts, percentage size reduction, the real gzip wire size measured by your browser, and key-shortening frequency analysis to optimize HTTP payload transfer."
      seoDescription="Compress JSON documents by stripping whitespace, measuring real gzip wire size, and analyzing key frequency compression opportunities."
      breadcrumbs={[{ name: "JSON Minifier", url: "/json-minifier" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              In production web applications and microservices, JSON payloads often contain 20% to 55% redundant whitespace introduced by pretty-printers, code formatters, or developer indentation. This dead weight directly inflates network transit latency, consumes egress bandwidth, and slows JSON.parse deserialization times.
            </p>
            <p>
              The ToolsByUs minification engine performs full lexical tokenization:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Zero Syntax Corruption:</strong> Whitespace within quoted string literals is preserved verbatim, while structural whitespace (spaces around colons, commas, and brackets) is completely stripped.</li>
              <li><strong>Comment Stripping:</strong> Tolerates and strips single-line (<code>{"//"}</code>) and multi-line (<code>{"/* */"}</code>) comments commonly present in JSONC configuration files.</li>
              <li><strong>Real Gzip Measurement:</strong> The minified output is compressed with the browser&apos;s own <code>{'CompressionStream("gzip")'}</code> encoder, so the reported wire size is measured, not modelled. Browsers without that API fall back to a Shannon-entropy approximation, and the label says which figure you are looking at.</li>
              <li><strong>Key-Shortening Analytics:</strong> Inspects recurring property names. When long property keys (e.g. <code>transactionIdentification</code>) repeat across hundreds of array entries, the report calculates exact byte savings achievable by shortening them.</li>
            </ul>
          </>
        ),
        inputTitle: "Uncompressed Formatted JSON",
        exampleInput: `{\n  "status": "ok",\n  "code": 200\n}`,
        exampleOutput: `{"status":"ok","code":200}`,
      }}
      referenceTable={{
        title: "Minification Metrics & Compression Parameters",
        rows: [
          {
            parameter: "Whitespace Stripping",
            type: "Rule",
            defaultVal: "RFC 8259",
            description: "Removes spaces, tabs, CR, and LF outside of string literals.",
          },
          {
            parameter: "JSONC Comments",
            type: "Sanitizer",
            defaultVal: "Stripped",
            description: "Detects and strips // and /* */ comments without damaging string contents.",
          },
          {
            parameter: "Gzip Size",
            type: "Metric",
            defaultVal: "Measured",
            description: "Compressed with the browser's native gzip encoder. Falls back to an entropy estimate (shown as \"~\") where CompressionStream is unavailable.",
          },
          {
            parameter: "Key Shortening",
            type: "Analytics",
            defaultVal: "Reported",
            description: "Catalogs repeated keys longer than 3 characters and computes potential byte savings.",
          },
        ],
      }}
      faqs={[
        {
          question: "How does minification reduce API response latency?",
          answer:
            "Minification directly reduces the raw byte payload transferred over TCP/QUIC packets. For payloads spanning multiple MTU frames (1500 bytes), dropping dead whitespace reduces the number of round-trips and lowers browser parsing CPU cycles.",
        },
        {
          question: "Does minifying JSON affect data types or float precision?",
          answer:
            "No. The minifier operates strictly on JSON syntax tokens. String literals, numbers, decimal precisions, and boolean values remain identical down to the bit.",
        },
        {
          question: "Why does the tool show a Gzip size?",
          answer:
            "Almost all production web servers (Nginx, Cloudflare, Envoy) apply gzip or brotli compression to JSON responses, so an uncompressed byte count overstates what actually crosses the network. The figure shown is produced by your browser's own gzip encoder via the CompressionStream API, which means it is the real compressed size rather than a model of it. On a browser without that API the tool falls back to an entropy-based approximation and prefixes the number with a tilde.",
        },
        {
          question: "Is my minified JSON processed on a server?",
          answer:
            "Never. All parsing, minification, and compression analytics execute 100% locally in your browser memory. No data is ever sent to any remote server.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Format and beautify minified JSON with customizable indentation and key sorting.",
        },
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Check JSON syntax against RFC 8259 with exact line and column caret tracking.",
        },
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Semantic AST diff comparison with Web Worker and RFC 6902 Patch support.",
        },
        {
          href: "/base64-decode",
          title: "Base64 & JWT Decoder",
          description: "Encode and decode standard and URL-safe Base64 with binary file download.",
        },
      ]}
    >
      <div className="space-y-5">
        <SizeNotice check={sizeCheck} />
        {/* Metrics Summary Card */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-lg border border-border bg-surface font-mono text-xs">
            <div className="p-2.5 rounded-lg bg-background border border-border">
              <span className="text-foreground-muted block mb-1">Original Size</span>
              <span className="text-sm font-bold text-foreground">
                {stats.originalBytes > 1024 ? `${(stats.originalBytes / 1024).toFixed(1)} KB` : `${stats.originalBytes} B`}
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-background border border-border">
              <span className="text-foreground-muted block mb-1">Minified Size</span>
              <span className="text-sm font-bold text-accent">
                {stats.minifiedBytes > 1024 ? `${(stats.minifiedBytes / 1024).toFixed(1)} KB` : `${stats.minifiedBytes} B`}
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-background border border-border">
              <span className="text-foreground-muted block mb-1">Size Reduction</span>
              <span className="text-sm font-bold text-accent">
                -{stats.reductionPercent}%
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-background border border-border">
              <span className="text-foreground-muted block mb-1">
                {exactGzipBytes !== null ? "Gzip (measured)" : "Gzip (estimated)"}
              </span>
              <span
                className="text-sm font-bold text-accent"
                title={
                  exactGzipBytes !== null
                    ? "Compressed with the browser's native gzip encoder."
                    : "Entropy-based approximation; this browser has no CompressionStream API."
                }
              >
                {(() => {
                  const bytes = exactGzipBytes ?? stats.estimatedGzipBytes;
                  const prefix = exactGzipBytes !== null ? "" : "~";
                  return bytes > 1024
                    ? `${prefix}${(bytes / 1024).toFixed(1)} KB`
                    : `${prefix}${bytes} B`;
                })()}
              </span>
            </div>
          </div>
        )}

        {/* Input / Output Panes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CodePane
            label="Original JSON (Paste Here)"
            value={inputRaw}
            onChange={setInputRaw}
            placeholder="Paste JSON to minify..."
            error={inputRaw.trim() && minifyData.error ? { message: minifyData.error, line: minifyData.line, column: minifyData.column, caretSnippet: minifyData.caretSnippet } : undefined}
            onLoadExample={() => setInputRaw(DEFAULT_SAMPLE)}
          />
          <CodePane
            label="Minified Output (Zero Whitespace)"
            value={stats?.minified || ""}
            onChange={() => {}}
            readOnly
          />
        </div>

        {/* Key-Shortening Report */}
        {minifyData.keySuggestions && minifyData.keySuggestions.length > 0 && (
          <div className="p-4 rounded-lg border border-border bg-surface font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-border pb-2">
              <h2 className="font-bold text-foreground flex items-center gap-2">
                <Icon name="bolt" size="md" className="text-warn" />
                <span>Key-Shortening Compression Analysis</span>
              </h2>
              <span className="text-2xs text-foreground-muted">
                Top repeated long property keys in your payload
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="text-foreground-muted border-b border-border">
                  <tr>
                    <th className="py-2 px-3">Property Key</th>
                    <th className="py-2 px-3">Occurrences</th>
                    <th className="py-2 px-3">Total Bytes</th>
                    <th className="py-2 px-3">Potential Savings</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border text-foreground-muted">
                  {minifyData.keySuggestions.slice(0, 6).map((item, idx) => (
                    <tr key={idx} className="hover:bg-surface-elevated">
                      <td className="py-2 px-3 font-semibold text-accent">
                        &quot;{item.originalKey}&quot;
                      </td>
                      <td className="py-2 px-3">{item.count}×</td>
                      <td className="py-2 px-3">{item.currentBytes} B</td>
                      <td className="py-2 px-3 text-accent font-semibold">
                        ~{item.potentialSavedBytes} B ({Math.round((item.potentialSavedBytes / item.currentBytes) * 100)}%)
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </ToolShell>
  );
};
