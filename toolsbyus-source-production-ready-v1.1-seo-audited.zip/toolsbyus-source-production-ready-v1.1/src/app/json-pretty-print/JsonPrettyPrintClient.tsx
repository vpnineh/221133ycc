"use client";

import React, { useDeferredValue, useMemo, useState } from "react";
import Link from "next/link";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { SizeNotice } from "../../components/tools/SizeNotice";
import { Notice } from "../../components/common/Notice";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { checkMainThreadSize } from "../../lib/limits";
import { formatJson, type FormatResult } from "../../lib/json/formatter";
import { PRETTY_PRINT_RECIPES } from "../../lib/json/recipes";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `{"order":"ord_1041","customer":{"name":"Ada Lovelace","email":"ada@example.com","country":"GB"},"lines":[{"sku":"KB-87","qty":1,"price":89.5},{"sku":"MSE-2","qty":2,"price":29.5}],"total":148.5,"currency":"GBP","paid":true,"note":"Deliver to the café on Rue Lafayette"}`;

export const JsonPrettyPrintClient: React.FC = () => {
  const [input, setInput] = useState("");
  const [indent, setIndent] = useState<number | "tab">(2);
  const [sortKeys, setSortKeys] = useState(false);
  const [recipeId, setRecipeId] = useState(PRETTY_PRINT_RECIPES[0].id);

  // The heavy work runs against a deferred copy, so a multi-megabyte paste
  // does not block keystrokes in the textarea.
  const deferred = useDeferredValue(input);
  const sizeCheck = useMemo(() => checkMainThreadSize(deferred), [deferred]);

  const result = useMemo((): FormatResult => {
    if (!deferred.trim()) {
      return { success: true, formatted: "" };
    }
    if (sizeCheck.exceeded) {
      return { success: false, error: sizeCheck.message ?? "Input too large" };
    }
    return formatJson(deferred, { indent, sortKeys, escapeUnicode: false });
  }, [deferred, indent, sortKeys, sizeCheck]);

  const recipe = PRETTY_PRINT_RECIPES.find((entry) => entry.id === recipeId)!;

  return (
    <ToolShell
      wide
      slug="json-pretty-print"
      keyword="JSON Pretty Print"
      directAnswer="JSON Pretty Print formats JSON with indentation and line breaks so a human can read it. Paste a document below to do it here, or take the one line that does it in your own language — JavaScript, Python, Go, Java, C#, PHP, Ruby, Rust, jq or PowerShell — each with the default that catches people out, because every one of these APIs has one."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON Pretty Print", url: "/json-pretty-print" },
      ]}
      seoDescription="Pretty-print JSON in the browser, and copy the exact code that does it in JavaScript, Python, Go, Java, C#, PHP, Ruby, Rust, jq or PowerShell — with each language's surprising default explained."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Pretty-printing JSON means one thing: parse the document, then write it back out
              with a newline after every comma and a level of indentation per level of nesting.
              The bytes are equivalent — a parser cannot tell the two apart — but one of them is
              readable and the other is a wall.
            </p>

            <h3>Two different questions, one page</h3>
            <p>
              People searching for this want one of two things. Either a box to paste a payload
              into, which is the panel above; or the line of code that does it inside a program
              they are writing, which is the picker below it. This page answers both, because
              being sent to a formatting widget when you needed{" "}
              <code>json.dumps(obj, indent=2)</code> is a waste of a click.
            </p>

            <h3>Every language has a default that surprises somebody</h3>
            <p>
              This is the part worth knowing, and it is why the recipes here carry a note each
              rather than being a list of one-liners. Python escapes every non-ASCII character
              unless you pass <code>ensure_ascii=False</code>, so <code>café</code> arrives as{" "}
              <code>caf\u00e9</code>. Go escapes <code>&lt;</code>, <code>&gt;</code> and{" "}
              <code>&amp;</code> because the output might once have gone into a{" "}
              <code>&lt;script&gt;</code> tag. PHP escapes forward slashes, so every URL in your
              output looks broken. PowerShell&apos;s <code>ConvertTo-Json</code> truncates
              anything nested more than two levels deep and does not warn you — it just replaces
              the rest with a type name and carries on.
            </p>
            <p>
              And in JavaScript, the mistake is in the call itself:{" "}
              <code>JSON.stringify(value, 2)</code> looks right, compiles, runs, and returns the
              minified string, because the second argument is the replacer function and the third
              is the indent.
            </p>

            <h3>Sorting keys is a separate decision</h3>
            <p>
              Alphabetising keys makes two versions of the same document diffable, which is the
              whole reason to do it — without it, a serialiser that emits keys in insertion order
              produces a diff full of moves. It is off by default here because it changes the
              document&apos;s order, and for a config file or a lockfile that order sometimes
              carries meaning.
            </p>

            <h3>Indentation, and what to pick</h3>
            <p>
              Two spaces is the web and JavaScript convention and keeps deeply nested documents
              on screen. Four is the norm in Python and much of the backend world. Tabs let each
              reader choose their own width, which is the strongest argument for them and the
              reason some projects insist on it. None of the three is more correct than the
              others; the only wrong answer is mixing them within one file.
            </p>

            <h3>This does not change what the data means</h3>
            <p>
              Whitespace between tokens is not significant in JSON, so pretty-printing is
              reversible and lossless — run the output through a minifier and you get the input
              back, byte for byte, unless you also sorted the keys. What it does change is size:
              indentation can add 20–40% to a document, which matters on the wire and does not
              matter at all in a log you are reading.
            </p>
            <p>
              If the document does not parse, nothing here can format it, and the error below
              names the line and column. <Link href="/json-validator">JSON Validator</Link> will
              also offer to repair the usual causes — a trailing comma, a single quote, an
              unquoted key.
            </p>

            <h3>Nothing is uploaded</h3>
            <p>
              The parse and the re-serialise both happen in this tab, in JavaScript that is
              already loaded. The payloads people pretty-print are API responses and log lines,
              which routinely contain tokens and customer records, and the page&apos;s
              Content-Security-Policy sets <code>connect-src &apos;self&apos;</code> — so the
              browser would block an upload rather than merely not attempting one.
            </p>
          </>
        ),
        inputTitle: "Minified",
        exampleInput: `{"id":42,"tags":["prod","payment"],"ok":true}`,
        outputTitle: "Pretty-printed",
        exampleOutput: `{
  "id": 42,
  "tags": [
    "prod",
    "payment"
  ],
  "ok": true
}`,
      }}
      referenceTable={{
        title: "One line per language",
        rows: [
          {
            parameter: "JavaScript",
            type: "JSON.stringify",
            defaultVal: "built in",
            description:
              "JSON.stringify(value, null, 2). The second argument is the replacer — passing 2 there does nothing at all.",
          },
          {
            parameter: "Python",
            type: "json.dumps",
            defaultVal: "stdlib",
            description:
              "json.dumps(obj, indent=2). Add ensure_ascii=False or every non-ASCII character is escaped.",
          },
          {
            parameter: "jq",
            type: "shell",
            defaultVal: "—",
            description:
              "jq . file.json, and jq -S . to sort keys. Before jq 1.7, large integers were silently altered.",
          },
          {
            parameter: "Command line",
            type: "python3 -m json.tool",
            defaultVal: "—",
            description: "Present on almost every machine, with --indent, --sort-keys and --no-ensure-ascii.",
          },
          {
            parameter: "Go",
            type: "encoding/json",
            defaultVal: "stdlib",
            description:
              "json.MarshalIndent for a value, json.Indent for bytes you already have. Both escape angle brackets.",
          },
          {
            parameter: "Java",
            type: "Jackson",
            defaultVal: "—",
            description:
              "writerWithDefaultPrettyPrinter(). Its default prints arrays on one line until you set an array indenter.",
          },
          {
            parameter: "C#",
            type: "System.Text.Json",
            defaultVal: ".NET Core 3+",
            description:
              "JsonSerializerOptions { WriteIndented = true }. Escapes far more than the specification requires.",
          },
          {
            parameter: "PHP",
            type: "json_encode",
            defaultVal: "built in",
            description:
              "JSON_PRETTY_PRINT, plus JSON_UNESCAPED_SLASHES and JSON_UNESCAPED_UNICODE, which you almost always want.",
          },
          {
            parameter: "Ruby",
            type: "JSON.pretty_generate",
            defaultVal: "stdlib",
            description: "Not the same as to_json, which stays compact.",
          },
          {
            parameter: "Rust",
            type: "serde_json",
            defaultVal: "—",
            description:
              "to_string_pretty. Value sorts keys unless the preserve_order feature is enabled.",
          },
          {
            parameter: "PowerShell",
            type: "ConvertTo-Json",
            defaultVal: "built in",
            description:
              "Defaults to -Depth 2 and silently truncates below it. Always pass -Depth explicitly.",
          },
        ],
      }}
      faqs={[
        {
          question: "How do I pretty print JSON in JavaScript?",
          answer:
            "JSON.stringify(value, null, 2). The three arguments are the value, a replacer, and the indent — so the mistake everyone makes once is JSON.stringify(value, 2), which puts 2 in the replacer slot, does nothing, and returns the minified string. Pass \"\\t\" instead of 2 for tabs. Be aware of what stringify quietly discards along the way: undefined values and functions vanish from objects and become null inside arrays, a Map or Set becomes {}, and a BigInt throws.",
        },
        {
          question: "How do I pretty print JSON in Python?",
          answer:
            "json.dumps(obj, indent=2). The default that catches people is ensure_ascii=True, which escapes every non-ASCII character — \"café\" comes out as \"caf\\u00e9\", valid and unreadable. Pass ensure_ascii=False to keep UTF-8, and open any output file with encoding=\"utf-8\" when you do. sort_keys=True alphabetises, which is what makes two dumps diffable.",
        },
        {
          question: "How do I pretty print JSON from the command line?",
          answer:
            "jq . file.json if jq is installed; python3 -m json.tool file.json if it is not, which covers almost every machine with Python on it. jq adds sorting with -S, a configurable indent with --indent, and compaction with -c. One caution: up to jq 1.6, numbers were parsed as doubles, so a 64-bit ID could come back silently changed — jq 1.7 preserves unmodified number literals, so check the version before piping identifiers through it.",
        },
        {
          question: "Is pretty-printed JSON still valid JSON?",
          answer:
            "Yes. Whitespace between tokens carries no meaning in JSON, so an indented document and a minified one parse to exactly the same value — RFC 8259 allows space, tab, newline and carriage return anywhere between structural tokens. The only difference is size: indentation typically adds 20–40%, which is worth removing before sending a payload over the wire and worth keeping in anything a person reads.",
        },
        {
          question: "What is the difference between pretty print, format and beautify?",
          answer:
            "Nothing, as verbs — they all mean adding whitespace so the structure is visible. The three pages here differ in what else they do. This one pairs the formatter with the code to do it in each language. JSON Formatter has the full option set: JSONC comment stripping, key sorting, Unicode escaping. JSON Beautifier is aimed at the specific job of turning a minified blob back into something readable. Pick whichever matches what you came for.",
        },
        {
          question: "Why does my pretty-printed output have \\u escapes in it?",
          answer:
            "Because the serialiser escaped non-ASCII characters, and several do it by default. Python's json.dumps has ensure_ascii=True; C#'s System.Text.Json escapes anything its HTML-safe encoder dislikes; PHP escapes non-ASCII unless told otherwise. All of it is valid JSON and none of it is readable. The fix is one argument in each case — ensure_ascii=False, UnsafeRelaxedJsonEscaping, JSON_UNESCAPED_UNICODE — and the picker above shows it for whichever language you are in.",
        },
        {
          question: "Is my JSON uploaded to a server?",
          answer:
            "No. Parsing and re-serialising happen in this tab, in JavaScript already loaded on the page, and there is no endpoint on the other end to send anything to. That matters here more than it might sound: the documents people pretty-print are API responses and log lines, which routinely carry tokens, session identifiers and customer records. The page is served with connect-src 'self', so the browser itself blocks any request to another origin.",
        },
      ]}
      relatedTools={relatedTools("/json-pretty-print").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Indent</span>
            <div className={segmentTrack} role="group" aria-label="Indent">
              {([2, 4, "tab"] as const).map((value) => (
                <button
                  key={String(value)}
                  type="button"
                  onClick={() => setIndent(value)}
                  aria-pressed={indent === value}
                  className={segment(indent === value)}
                >
                  {value === "tab" ? "Tab" : `${value} spaces`}
                </button>
              ))}
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={sortKeys}
              onChange={(event) => setSortKeys(event.target.checked)}
              className={checkbox}
            />
            <span className={fieldLabel}>Sort keys</span>
          </label>
        </div>

        <SizeNotice check={sizeCheck} />

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label="JSON"
            value={input}
            onChange={setInput}
            placeholder="Paste a minified document"
            error={
              !input.trim() || result.success
                ? undefined
                : {
                    message: result.error ?? "This document does not parse as JSON.",
                    line: result.line,
                    column: result.column,
                    caretSnippet: result.caretSnippet,
                  }
            }
            height={320}
            onLoadExample={() => setInput(SAMPLE)}
          />
          <CodePane
            label="Pretty-printed"
            value={result.formatted ?? ""}
            onChange={() => undefined}
            readOnly
            height={320}
          />
        </div>

        <section
          aria-label="Pretty print in your language"
          className="space-y-3 rounded-lg border border-border bg-surface p-3"
        >
          <div className="flex flex-wrap items-center gap-2">
            <span className={fieldLabel}>In your language</span>
            <div className={segmentTrack} role="group" aria-label="Language">
              {PRETTY_PRINT_RECIPES.map((entry) => (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => setRecipeId(entry.id)}
                  aria-pressed={recipeId === entry.id}
                  className={segment(recipeId === entry.id)}
                >
                  {entry.language}
                </button>
              ))}
            </div>
          </div>

          <p className="font-mono text-2xs text-foreground-subtle">{recipe.note}</p>

          <CodePane
            label={`${recipe.language} — pretty print`}
            value={recipe.code}
            onChange={() => undefined}
            readOnly
            height={200}
          />

          <Notice tone="warn" title="The default that catches people out">
            {recipe.gotcha}
          </Notice>
        </section>
      </div>
    </ToolShell>
  );
};
