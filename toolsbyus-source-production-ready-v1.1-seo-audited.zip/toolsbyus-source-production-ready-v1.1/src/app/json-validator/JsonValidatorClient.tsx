"use client";

import React, { useState, useMemo, useDeferredValue } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SizeNotice } from "../../components/tools/SizeNotice";
import { RepairPanel } from "../../components/tools/RepairPanel";
import { checkMainThreadSize } from "../../lib/limits";
import { CodePane } from "../../components/tools/CodePane";
import { validateJson } from "../../lib/json/validator";

const DEFAULT_SAMPLE = JSON.stringify(
  {
    schemaVersion: "3.2.0",
    serviceRegistry: [
      {
        clusterId: "cls_us_east_1",
        endpoint: "https://ingress.toolsbyus.com/v1",
        heartbeatIntervalSec: 15,
        healthy: true,
      },
      {
        clusterId: "cls_eu_west_1",
        endpoint: "https://ingress.eu.toolsbyus.com/v1",
        heartbeatIntervalSec: 15,
        healthy: true,
      },
    ],
    telemetryConfig: {
      metricsSampleRate: 1.0,
      tracingEnabled: false,
    },
  },
  null,
  2
);

export const JsonValidatorClient: React.FC = () => {
  const [inputRaw, setInputRaw] = useState("");

  // Heavy derivation runs against a deferred copy so a multi-megabyte paste
  // does not block keystrokes: React keeps the textarea responsive and catches
  // the results up at lower priority.
  const inputRawDeferred = useDeferredValue(inputRaw);

  const sizeCheck = useMemo(() => checkMainThreadSize(inputRawDeferred), [inputRawDeferred]);

  const validation = useMemo(() => {
    if (!inputRawDeferred.trim()) {
      return {
        isValid: false,
        explanation: "",
      };
    }
    if (sizeCheck.exceeded) {
      // Report the refusal through the normal result shape so the existing
      // error surface renders it; SizeNotice explains the reason above.
      return {
        isValid: false,
        explanation: sizeCheck.message ?? "Input too large to validate on the main thread.",
      };
    }
    return validateJson(inputRawDeferred);
  }, [inputRawDeferred, sizeCheck]);

  return (
    <ToolShell
      wide
      slug="json-validator"
      keyword="JSON Validator"
      directAnswer="JSON Validator performs strict RFC 8259 syntax validation directly in your browser without transmitting your payload over the network. It pinpoints the precise line and column of syntax errors with a visual caret pointer, plain-English diagnosis, and specific classification for trailing commas, single quotes, unquoted keys, mismatched brackets, BOMs, and word-processor smart quotes."
      seoDescription="Validate JSON against RFC 8259 with exact line and column caret tracking, plain-English diagnosis, and malformed syntax classification."
      breadcrumbs={[{ name: "JSON Validator", url: "/json-validator" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Standard browser <code>JSON.parse()</code> implementations surface notoriously unhelpful error messages, such as <em>&quot;Unexpected token in JSON at position 4812&quot;</em>. This raw exception forces developers to manually count byte offsets and guess which quote, comma, or bracket is misplaced.
            </p>
            <p>
              The ToolsByUs validator implements a dedicated non-recursive lexical scanner and token validator that tracks line numbers, column positions, delimiter nesting stacks, and character lookaheads according to RFC 8259:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Zero Raw Exceptions:</strong> Exceptions are caught and translated into actionable diagnostic reports with exact caret snippets pointing at the offending character on the exact line and column.</li>
              <li><strong>Explicit Error Classification:</strong> Accurately identifies trailing commas, unquoted object keys, single quote delimiters, missing separating commas, and mismatched brackets (e.g. closing an array with a curly brace).</li>
              <li><strong>Smart Quotes & BOM Detection:</strong> Catches subtle invisible UTF-8 Byte Order Marks (0xFEFF) and curly smart quotes (<code>&ldquo;</code>, <code>&rdquo;</code>) frequently introduced when copying JSON from rich-text editors or word processors.</li>
              <li><strong>Strict Number Grammar:</strong> Rejects IEEE 754 non-finite numbers like <code>NaN</code>, <code>Infinity</code>, and leading zeroes in numbers (such as <code>012</code>) which violate RFC 8259 Section 6.</li>
              <li><strong>10,000 Depth Protection:</strong> Employs an iterative finite-state machine that validates deeply nested structures without encountering browser call stack overflow.</li>
            </ul>
            <p>
              The parser works by maintaining a state machine that transitions between <code>BEFORE_KEY</code>, <code>AFTER_KEY</code>, <code>COLON</code>, <code>BEFORE_VALUE</code>, and <code>AFTER_VALUE</code> states while verifying that opening structural brackets (<code>[</code> and <code>&#123;</code>) match their exact closing counterparts in last-in-first-out order.
            </p>
          </>
        ),
        inputTitle: "Malformed Input Example",
        exampleInput: `{\n  'service': "auth",\n  "active": true,\n}`,
        exampleOutput: `Line 2, Column 3:\n  'service': "auth",\n  ^\nError: Single quotes are not allowed in JSON. Use double quotes (").\nRecommendation: Replace single quotes with double quotes.`,
      }}
      referenceTable={{
        title: "RFC 8259 Error Diagnostics & Classification",
        rows: [
          {
            parameter: "TRAILING_COMMA",
            type: "Syntax Error",
            defaultVal: "Forbidden",
            description: "Trailing comma preceding } or ]. While valid in JavaScript/JSON5, it violates RFC 8259 Section 4.",
          },
          {
            parameter: "SINGLE_QUOTES",
            type: "Syntax Error",
            defaultVal: "Forbidden",
            description: "Single quotes (') wrapping strings or property keys. JSON requires standard ASCII double quotes (\").",
          },
          {
            parameter: "UNQUOTED_KEY",
            type: "Syntax Error",
            defaultVal: "Forbidden",
            description: "Object property identifiers without double quotes (e.g. { name: 'value' }).",
          },
          {
            parameter: "MISSING_COMMA",
            type: "Syntax Error",
            defaultVal: "Forbidden",
            description: "Consecutive object key-value pairs or array members without an intervening comma delimiter.",
          },
          {
            parameter: "MISMATCHED_BRACKET",
            type: "Structure Error",
            defaultVal: "Forbidden",
            description: "Mismatched container delimiters, such as closing an array with a curly brace ( ] vs } ).",
          },
          {
            parameter: "SMART_QUOTES",
            type: "Encoding Error",
            defaultVal: "Detected",
            description: "Word-processor typographical quotes (“ ”). Automatically diagnosed with column location and fix.",
          },
          {
            parameter: "BOM (Byte Order Mark)",
            type: "Encoding Error",
            defaultVal: "0xFEFF",
            description: "Leading UTF-8 byte order mark prohibited by RFC 8259 Section 8.1 in network interchanges.",
          },
          {
            parameter: "NAN_INFINITY_REJECTED",
            type: "Number Grammar",
            defaultVal: "Forbidden",
            description: "NaN, Infinity, and -Infinity are not valid JSON numeric tokens under RFC 8259 Section 6.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why does valid JavaScript object syntax fail JSON validation?",
          answer:
            "JSON (RFC 8259) is an interchange format, not a programming language. Features permitted in JavaScript—such as trailing commas, single-quoted strings, unquoted property keys, comments, and NaN values—are explicitly forbidden by the JSON standard to ensure cross-language interoperability between Python, Go, Java, C++, and Rust parsers.",
        },
        {
          question: "What does the caret pointer indicate?",
          answer:
            "The caret (^) points directly to the character column where the lexical parser encountered an unexpected character or illegal sequence, helping you locate the exact syntax break even in multi-megabyte payloads.",
        },
        {
          question: "How does the validator detect smart quotes?",
          answer:
            "When text is copied from documentation tools, blog posts, or email clients, ASCII double quotes (\") are frequently converted into typographical curly quotes (Unicode U+201C and U+201D). The validator explicitly detects these Unicode code points and advises replacing them with standard double quotes.",
        },
        {
          question: "Why does JSON reject comments?",
          answer:
            "Douglas Crockford intentionally removed comments from the original JSON specification to prevent parsers from holding processing directives or pragmas, ensuring JSON remained purely a data-interchange format. For configuration files supporting comments, use JSONC.",
        },
        {
          question: "How are duplicate keys handled under RFC 8259?",
          answer:
            "RFC 8259 specifies that object keys should be unique. While some native parsers silently overwrite earlier values with later ones, ToolsByUs highlights duplicate keys with diagnostic warnings to prevent subtle data-loss bugs.",
        },
        {
          question: "Is my validated payload sent to any backend?",
          answer:
            "No. Parsing, token checking, and validation happen 100% client-side inside your browser. No data ever leaves your computer, guaranteed by our zero-backend architecture.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Format and indent valid JSON payloads with key sorting and comment handling.",
        },
        {
          href: "/json-minifier",
          title: "JSON Minifier",
          description: "Strip dead whitespace and calculate gzip size reduction percentages.",
        },
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Semantic comparison tool ignoring key order with RFC 6902 Patch support.",
        },
        {
          href: "/json-editor",
          title: "JSON Editor",
          description: "Interactive synchronized tree and text editor with JSONPath query search.",
        },
      ]}
    >
      <div className="space-y-5">
        <SizeNotice check={sizeCheck} />
        {/* Status Header */}
        {!inputRaw.trim() ? (
          <div className="p-4 rounded-lg border border-border bg-surface font-mono text-xs flex flex-wrap items-center justify-between gap-3 text-foreground-muted">
            <div className="flex items-center gap-2 font-bold text-sm">
              <span className="w-3 h-3 rounded-full flex-none bg-border" />
              <span>Awaiting Input — Paste a JSON document or click &ldquo;Try Example&rdquo;</span>
            </div>
          </div>
        ) : (
          <div
            className={`p-4 rounded-lg border font-mono text-xs flex flex-wrap items-center justify-between gap-3 ${
              validation.isValid
                ? "bg-accent-soft border-accent-line text-accent"
                : "bg-danger-soft border-danger text-danger"
            }`}
          >
            <div className="flex items-center gap-2 font-bold text-sm">
              <span
                className={`w-3 h-3 rounded-full flex-none ${
                  validation.isValid ? "bg-accent-solid" : "bg-danger-soft "
                }`}
              />
              <span>
                {validation.isValid
                  ? "Valid RFC 8259 JSON Document"
                  : `Invalid JSON Syntax — ${validation.error?.errorType || "Syntax Error"}`}
              </span>
            </div>

            {validation.isValid && validation.stats && (
              <div className="flex flex-wrap items-center gap-3 text-foreground-muted text-xs">
                <span>{validation.stats.objectCount} objects</span>
                <span>•</span>
                <span>{validation.stats.arrayCount} arrays</span>
                <span>•</span>
                <span>{validation.stats.keyCount} keys</span>
                <span>•</span>
                <span>{validation.stats.lineCount} lines</span>
                <span>•</span>
                <span>{validation.stats.byteCount} bytes</span>
              </div>
            )}
          </div>
        )}

        {/* Offer a mechanical fix for exactly the faults just diagnosed. */}
        {inputRaw.trim() && !validation.isValid && !sizeCheck.exceeded && (
          <RepairPanel value={inputRaw} onApply={setInputRaw} />
        )}

        {/* Input Pane with Caret Error Snippet */}
        <CodePane
          label="JSON Document to Validate"
          value={inputRaw}
          onChange={setInputRaw}
          placeholder="Paste JSON document to validate..."
          error={inputRaw.trim() ? validation.error : undefined}
          height={400}
          onLoadExample={() => setInputRaw(DEFAULT_SAMPLE)}
        />

        {/* Diagnostic Explanation & Recommendation (when invalid) */}
        {inputRaw.trim() && !validation.isValid && validation.explanation && (
          <div className="p-4 rounded-lg border border-danger bg-surface font-mono text-xs space-y-3">
            <h3 className="font-bold text-danger flex items-center gap-2">
              <span>Diagnosis & Actionable Fix:</span>
            </h3>
            <p className="text-foreground-muted text-sm leading-relaxed">{validation.explanation}</p>
            {validation.recommendation && (
              <div className="p-3 rounded bg-surface-elevated border border-border text-accent text-xs">
                <strong>Recommended action:</strong> {validation.recommendation}
              </div>
            )}
          </div>
        )}
      </div>
    </ToolShell>
  );
};
