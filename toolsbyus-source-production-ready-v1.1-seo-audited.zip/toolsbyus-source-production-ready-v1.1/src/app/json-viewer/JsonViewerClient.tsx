"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { JsonTreeView } from "../../components/tools/JsonTreeView";
import { Notice } from "../../components/common/Notice";
import { segment, segmentTrack } from "../../components/common/controls";
import { parseJson } from "../../lib/json/parser";
import { relatedTools } from "../../lib/tools";

const SAMPLE = JSON.stringify(
  {
    requestId: "req_9f21ac",
    status: 200,
    durationMs: 143,
    service: { name: "checkout-api", version: "4.2.1", region: "eu-west-1" },
    order: {
      id: "ord_1041",
      currency: "GBP",
      total: 148.5,
      customer: { id: "cus_77", name: "Ada Lovelace", vip: true, deletedAt: null },
      lines: [
        { sku: "WID-1", qty: 2, unit: 24, tax: { rate: 0.2, included: false } },
        { sku: "WID-9", qty: 1, unit: 100.5, tax: { rate: 0.2, included: false } },
      ],
      flags: ["priority", "gift"],
    },
    upstream: [
      { name: "inventory", ms: 31, cached: false },
      { name: "pricing", ms: 12, cached: true },
      { name: "payments", ms: 88, cached: false },
    ],
  },
  null,
  2
);

export const JsonViewerClient: React.FC = () => {
  const [raw, setRaw] = useState("");
  const [view, setView] = useState<"tree" | "text">("tree");

  const parsed = useMemo(() => parseJson(raw), [raw]);

  // Keep the last document that parsed, so editing mid-keystroke does not blank
  // the tree on every intermediate broken state.
  const [lastGood, setLastGood] = useState(() => (parsed.success ? parsed.data : null));
  if (parsed.success && parsed.data !== lastGood) setLastGood(parsed.data);

  return (
    <ToolShell
      wide
      slug="json-viewer"
      keyword="JSON Viewer"
      directAnswer="JSON Viewer renders a document as a collapsible tree in your browser. The tree is virtualized over a flattened row list, so a fifty-thousand-node API response opens and scrolls at the same speed as a small one, and every row carries the RFC 6901 pointer that addresses it."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON Viewer", url: "/json-viewer" },
      ]}
      seoDescription="View JSON as a collapsible tree in your browser. Virtualized for large documents, with search, copyable JSON Pointers and type-coloured values. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A JSON viewer is judged entirely by how it behaves on a document that is too big to
              read as text — which is the only reason anyone opens one. Most fail there, and they
              fail for the same structural reason: they render the tree as nested components, one
              per node. That is the obvious implementation and it means a fifty-thousand-node
              response produces fifty thousand DOM elements, of which perhaps forty are on screen.
              Scrolling becomes janky, expanding a branch re-renders its whole subtree, and the tab
              starts consuming hundreds of megabytes.
            </p>
            <p>
              This viewer flattens the document into an array of rows first — each one carrying its
              depth, its type, its child count, and the index at which its subtree ends — and then
              renders only the rows inside the viewport. The DOM holds around fifty elements
              regardless of document size, so a large file opens as quickly as a small one.
            </p>
            <p>
              Recording where each subtree ends is what makes collapsing cheap. Hiding a branch is a
              single index skip rather than a walk over everything inside it, so collapsing the root
              of a 50,000-node document costs one comparison instead of fifty thousand. The same
              structure makes search sensible: matches are found across the whole document, not just
              the expanded part, and every ancestor on the path to a match is kept, because a value
              without its path tells you nothing.
            </p>
            <p>
              Flattening is iterative, with an explicit stack rather than recursion. A recursive walk
              overflows the JavaScript call stack somewhere around ten thousand levels of nesting,
              and a document that deep is precisely the document someone brings to a viewer because
              nothing else will open it. There is a test at twenty thousand levels.
            </p>
            <p>
              Each row shows the RFC 6901 JSON Pointer that addresses it — <code>/order/lines/0/sku</code>{" "}
              — and copies it on click. That is the string you paste into a JSON Patch, a{" "}
              <code>jq</code> path, a test assertion or a bug report, and having it exact removes
              the most tedious step of working with an unfamiliar response.
            </p>
          </>
        ),
        inputTitle: "Document",
        exampleInput: `{"order":{"lines":[{"sku":"WID-1","qty":2}]}}`,
        outputTitle: "Tree",
        exampleOutput: `▾ root            { 1 }
  ▾ order         { 1 }
    ▾ lines       [ 1 ]
      ▾ 0         { 2 }
          sku     "WID-1"     /order/lines/0/sku
          qty     2           /order/lines/0/qty`,
      }}
      referenceTable={{
        title: "Viewer behaviour and limits",
        rows: [
          {
            parameter: "Initial depth",
            type: "levels",
            defaultVal: "2",
            description:
              "Containers deeper than this start collapsed, so a large document opens as a readable overview rather than forty thousand lines. Expand all is one press away.",
          },
          {
            parameter: "Virtualization",
            type: "viewport only",
            defaultVal: "—",
            description:
              "Around fifty rows exist in the DOM at any moment, whatever the document size. This is the difference between a viewer that opens a 20 MB response and one that hangs the tab.",
          },
          {
            parameter: "Search",
            type: "substring",
            defaultVal: "case-insensitive",
            description:
              "Matches keys and rendered values across the entire document, including collapsed branches, and keeps every ancestor of a match so the path stays visible.",
          },
          {
            parameter: "JSON Pointer",
            type: "RFC 6901",
            defaultVal: "shown per row",
            description:
              "Click to copy. Keys containing / or ~ are escaped as ~1 and ~0, so the pointer is correct rather than merely plausible.",
          },
          {
            parameter: "Type colours",
            type: "string, number, boolean, null",
            defaultVal: "—",
            description:
              "Scalars are coloured by type, so a numeric string \"42\" is visibly different from the number 42 — a distinction that causes a surprising share of integration bugs.",
          },
          {
            parameter: "Editing",
            type: "not supported",
            defaultVal: "—",
            description:
              "This is a viewer. For editing values, renaming keys and reordering arrays, use the JSON Editor, which keeps a text pane and a tree in sync.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "Parsing runs on the main thread. Above the ceiling the tool declines rather than freezing. The tree itself handles far more nodes than the parser ceiling permits.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will it open a really large file?",
          answer:
            "Up to the 8 MB parse ceiling, yes, and the tree is not the bottleneck — it renders only what is on screen, so node count barely affects it. The limit is the parse step, which runs on the main thread and is declined above 8 MB rather than attempted, because attempting it locks the tab.",
        },
        {
          question: "What is the /order/lines/0/sku next to each row?",
          answer:
            "The RFC 6901 JSON Pointer that addresses that node. Click it to copy. It is the path you paste into a JSON Patch operation, a test assertion, or a bug report, and having it exact — including the ~0 and ~1 escapes for keys containing ~ and / — removes the most error-prone part of describing where something is.",
        },
        {
          question: "Can I edit values here?",
          answer:
            "No, deliberately. A viewer that also edits has to reconcile two sources of truth on every keystroke, which is why the JSON Editor is a separate tool: it keeps a text pane and a tree synchronised, with undo. Keeping this one read-only is what lets it stay fast on documents the editor would struggle with.",
        },
        {
          question: "Why is my number shown in a different colour from my string?",
          answer:
            "Scalars are coloured by type. It matters more than it sounds: the string \"42\" and the number 42 look identical in raw text and behave completely differently downstream. A quoted value being a string where an integer was expected is a recurring cause of integration failures, and colour makes it visible at a glance.",
        },
        {
          question: "Does search look inside collapsed branches?",
          answer:
            "Yes. The search runs over the whole flattened document rather than the visible rows, so a match buried in a collapsed subtree is found and shown along with the ancestors that lead to it. Clear the query and the tree returns to whatever you had expanded.",
        },
        {
          question: "Is the document uploaded?",
          answer:
            "No. It is parsed and rendered by JavaScript in the tab you already have open. Open DevTools, go to the Network panel and paste a response — nothing carrying it leaves. The documents people need a viewer for are usually production API responses, which is exactly the material that should not pass through an unknown server to be made readable.",
        },
      ]}
      relatedTools={relatedTools("/json-viewer").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className={segmentTrack} role="group" aria-label="View">
            <button
              type="button"
              onClick={() => setView("tree")}
              aria-pressed={view === "tree"}
              className={segment(view === "tree")}
            >
              Tree
            </button>
            <button
              type="button"
              onClick={() => setView("text")}
              aria-pressed={view === "text"}
              className={segment(view === "text")}
            >
              Text
            </button>
          </div>
          <span className="font-mono text-2xs text-foreground-subtle">
            Rows show the RFC 6901 pointer; click one to copy it.
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label="JSON document"
            value={raw}
            onChange={setRaw}
            placeholder="Paste a JSON document…"
            height={460}
            error={raw.trim() && !parsed.success ? parsed.error : undefined}
            onLoadExample={() => setRaw(SAMPLE)}
          />

          <div>
            {view === "tree" ? (
              lastGood !== null ? (
                <JsonTreeView value={lastGood} height={460} />
              ) : (
                <div className="flex h-[460px] items-center justify-center rounded-lg border border-border bg-surface p-6 text-center text-xs text-foreground-muted">
                  Paste a valid JSON document or click &ldquo;Try Example&rdquo; to see its tree.
                </div>
              )
            ) : (
              <CodePane
                label="Formatted"
                value={lastGood !== null ? JSON.stringify(lastGood, null, 2) : ""}
                onChange={() => undefined}
                readOnly
                height={460}
              />
            )}
          </div>
        </div>

        {raw.trim() && !parsed.success && lastGood !== null && (
          <Notice tone="warn">
            The document does not currently parse, so the tree still shows the last version that
            did. The editor pane above points at the exact line and column.
          </Notice>
        )}
      </div>
    </ToolShell>
  );
};
