import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryLastReviewed, categoryOf } from "@/lib/tools";
import { CONTENT_LAST_REVIEWED } from "@/lib/site";

const CATEGORY = categoryOf("pdf")!;
/*
 * The same date the sitemap publishes for this URL: the newest review date
 * among the tools listed below. Hard-coded, it disagreed with its own
 * <lastmod> on the two hubs whose newest tool was reviewed after this date.
 */
const LAST_REVIEWED = categoryLastReviewed(CATEGORY.id) ?? CONTENT_LAST_REVIEWED;

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "PDF Tools — 11 Tools That Never Upload a File",
  socialTitle: "PDF Tools",
  description:
    "Merge, split, rotate, reorder and convert PDFs in your browser. No upload, no sign-up, no watermark — the only version that is safe for a contract.",
});

export default function PdfToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These PDF tools run entirely in your browser. Your document is read, edited and written back in this tab — it is never uploaded, and the page's Content-Security-Policy sets connect-src 'self', so the browser itself would block an upload attempt. That distinction matters because the PDFs people need to edit are contracts, payslips, medical letters and passport scans."
      faqs={[
        {
          question: "How do I know my PDF is not being uploaded?",
          answer:
            "Check rather than trust. Open DevTools, switch to the Network panel, and run any tool here: no request carrying your file appears. Then note that the page is served with a Content-Security-Policy of connect-src 'self' — the browser refuses any request to another origin, so even a compromised script could not send your document anywhere. That is a guarantee enforced by the browser, not a promise in a privacy policy.",
        },
        {
          question: "Why does it matter where a PDF is processed?",
          answer:
            "Because of what PDFs contain. A leaflet does not need protecting; a signed contract, a set of payslips, a medical report or a passport scan for a visa application does. Uploading one hands a complete copy to a company whose retention policy you have not read and whose staff can open it. \"Files deleted after one hour\" is a sentence on a page, not a mechanism you can verify.",
        },
        {
          question: "Is there a file size limit or a watermark?",
          answer:
            "No watermark, ever — there is no paid tier here to upsell, so there is nothing to restrict you into buying. The size limit is 100 MB per file and 250 MB in total, and it is your browser's memory rather than a paywall: a PDF is held in memory several times over during a structural edit, and a larger file would exhaust the tab and lose your work. The tool declines instead.",
        },
        {
          question: "Can these tools open a password-protected PDF?",
          answer:
            "Only if you supply the password. A PDF with a user password is genuinely encrypted, and no tool can read it without the password — any site that claims to remove one is either uploading your file to a cracking service or simply lying. What the unlocker does handle is an owner-password document, where the content is readable but permissions are restricted, and a user-password document where you type the password yourself.",
        },
        {
          question: "Do they work offline?",
          answer:
            "Yes. Load a tool page once and it keeps working with the network disconnected — there is nothing on the other end to talk to. The site is a static export with no API routes, and the PDF engine is JavaScript already running in your tab. Disconnect your Wi-Fi and merge two files if you want to confirm it.",
        },
        {
          question: "Why is there no PDF to Word converter?",
          answer:
            "Because a good one is not achievable in a browser, and a bad one is worse than none. A PDF describes where glyphs sit on a page; it usually has no paragraphs, no tables and no reading order. Reconstructing a Word document from that requires layout analysis that guesses, and the output arrives as a mess of text boxes that is harder to edit than retyping. Shipping one would earn traffic and bounces in equal measure, so it is deliberately absent.",
        },
      ]}
      intro={
        <>
          <p>
            Search for a PDF tool and every result asks you to upload your file. The transaction is
            presented as unremarkable — drag it here, we will email you a link — and for a takeaway
            menu it genuinely is. For the documents people actually need to merge and split it is
            not remotely unremarkable, because those documents are contracts with signatures on
            them, payslips with salaries on them, medical letters, tax returns, and passport scans
            attached to visa applications.
          </p>
          <p>
            Uploading one means a complete copy now exists on a server you do not control. It is in
            their access log, their backup, their object store, and their incident report if there
            ever is one. The reassuring line about files being deleted after an hour describes an
            intention, not a mechanism you can check, and it says nothing about who could read the
            file during that hour.
          </p>
          <p>
            These tools take the upload out of the transaction entirely. The page you load is static
            HTML and JavaScript; when you drop a PDF, it is parsed by code already running in your
            tab, edited there, and written back to a file your browser saves locally. There is no
            request to inspect and no endpoint to trust — and if you would rather not take that on
            faith, the Network panel in DevTools settles it in ten seconds.
          </p>
          <p>
            The privacy claim is enforced rather than promised. The site is served with a
            Content-Security-Policy that includes <code>connect-src &apos;self&apos;</code>, which
            tells the browser to block any network request to another origin. If a future bug or a
            compromised dependency tried to upload your document, the browser would refuse before
            anything left the machine.
          </p>
          <p>
            Doing the work locally also makes it faster and more reliable. There is no queue, no
            round trip and no file size limit imposed by someone else&apos;s bandwidth bill, so a 40
            MB merge takes as long as your laptop needs and no longer. Each operation runs in a Web
            Worker, so the tab stays responsive and the progress bar actually moves — on the main
            thread, a browser cannot paint at all while JavaScript is running, which is why so many
            in-browser tools appear to hang.
          </p>
          <p>
            A note on what is missing: there is no PDF-to-Word converter, and that is a decision
            rather than an omission. A PDF records where glyphs sit on a page, not what the
            paragraphs and tables were before it was printed. Reconstructing an editable document
            from that is guesswork, and the guesses are visibly wrong often enough that the result
            takes longer to fix than to retype. The same reasoning applies to password cracking,
            which is not implemented and will not be.
          </p>
          <p>
            If you are not sure where to start: <Link href="/merge-pdf">Merge PDF</Link> to combine
            several files, <Link href="/split-pdf">Split PDF</Link> to pull pages out,{" "}
            <Link href="/rotate-pdf">Rotate PDF</Link> for a scan that came in sideways, and{" "}
            <Link href="/pdf-to-jpg">PDF to JPG</Link> when you need an image rather than a
            document.
          </p>
        </>
      }
    />
  );
}
