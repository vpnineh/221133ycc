import React from "react";
import type { Metadata } from "next";
import Link from "next/link";
import { buildToolMetadata } from "../../lib/metadata";
import { absoluteUrl } from "../../lib/site";
import { ADS } from "../../lib/ads";
import { infoPageLastReviewed } from "../../lib/tools";
import Breadcrumb from "@/components/common/Breadcrumb";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import PrivacyBadge from "@/components/common/PrivacyBadge";

const analyticsEnabled = Boolean(process.env.NEXT_PUBLIC_ANALYTICS_SRC);

export const metadata: Metadata = buildToolMetadata({
  path: "/privacy",
  title: "Privacy Policy — What Never Leaves Your Browser",
  socialTitle: "Privacy Policy",
  description:
    "What ToolsByUs does and does not send anywhere. Your file and your payload are processed in your browser and are never transmitted — verify it in the Network panel.",
});

/**
 * A bordered section. Repeated six times; declared once.
 *
 * `id` names the heading so the section can be linked and quoted directly —
 * these six answers (what is guaranteed, how to verify it, what is stored) are
 * the ones an answer engine extracts from this page.
 */
const Card: React.FC<{
  title: string;
  id?: string;
  children: React.ReactNode;
  tone?: "accent" | "plain";
}> = ({ title, id, children, tone = "plain" }) => (
  <section
    aria-labelledby={id}
    className={`space-y-3 rounded-lg border p-4 ${
      tone === "accent" ? "border-accent-line bg-accent-soft" : "border-border bg-surface"
    }`}
  >
    <h2
      id={id}
      className={`font-mono text-sm font-bold ${tone === "accent" ? "text-accent" : "text-foreground"}`}
    >
      {title}
    </h2>
    <div className="space-y-3 text-sm leading-relaxed text-foreground-muted">{children}</div>
  </section>
);

const Key: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <kbd className="rounded-pill bg-surface-elevated px-2 py-0.5 text-2xs text-foreground-muted">
    {children}
  </kbd>
);

export default function PrivacyPage() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: "Privacy Policy",
      url: absoluteUrl("/privacy"),
      description:
        "How ToolsByUs processes your data: client-side only, with no transmission of file or payload content.",
      // The page shows a review date; without this the date was a claim only a
      // reader could see. Same catalogue value as the visible stamp.
      dateModified: infoPageLastReviewed("/privacy"),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: absoluteUrl("/") },
        { "@type": "ListItem", position: 2, name: "Privacy Policy", item: absoluteUrl("/privacy") },
      ],
    },
  ];

  return (
    <div className="shell max-w-3xl space-y-8 py-8">
      <SchemaJsonLd schemas={jsonLdData} />

      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Privacy Policy", href: "/privacy" },
        ]}
      />

      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3">
          <h1 className="text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[2.75rem]">
            Privacy Policy
          </h1>
          <PrivacyBadge />
        </div>
        <p className="max-w-[68ch] text-sm text-foreground-muted sm:text-base">
          The short version: the file or text you put into a tool is processed by your own browser
          and is never sent anywhere.
        </p>
      </div>

      <div className="space-y-5">
        <Card id="guaranteed" tone="accent" title="What is guaranteed">
          <p>
            <strong className="text-foreground">
              Your file and your payload never leave your browser.
            </strong>{" "}
            Every tool on this site — JSON, text, PDF, image — runs as JavaScript inside the tab you
            already have open. There is no upload step, no API route, no storage bucket and no file-processing backend. Page assets are served over the network, while the tools process input locally.
          </p>
          <p>
            That applies to the whole input: the JSON you paste, the PDF you drop, the image you
            crop, the JWT you decode. None of it is read by us, transmitted, logged, or retained.
          </p>
        </Card>

        <Card id="verify-it-yourself" title="How to verify it yourself">
          <p>
            You do not have to take this on trust. It is observable in about thirty seconds:
          </p>
          <ol className="list-inside list-decimal space-y-2">
            <li>
              <strong className="text-foreground">Open DevTools.</strong> <Key>F12</Key>, or{" "}
              <Key>Cmd + Option + I</Key> on macOS, or <Key>Ctrl + Shift + I</Key> on Windows and
              Linux.
            </li>
            <li>
              <strong className="text-foreground">Go to the Network panel</strong> and tick
              &ldquo;Preserve log&rdquo;, then clear it.
            </li>
            <li>
              <strong className="text-foreground">Use a tool with sample data.</strong> Paste a large
              JSON document, merge two PDFs, decode a JWT, compress an image.
            </li>
            <li>
              <strong className="text-foreground">Watch the panel.</strong> No request carries your
              content from the tool. App code, fonts, workers and codecs can still load over the network.
              {ADS.enabled || analyticsEnabled ? " Optional advertising or analytics can add requests; inspect their behavior separately." : " This build has no advertising or analytics enabled."}
            </li>
            <li>
              <strong className="text-foreground">Disconnect the network.</strong> Turn off Wi-Fi or
              switch on Airplane mode after running the operation once. Processing can continue with loaded resources; a new tool, first-use codec or page reload may still need a connection.
            </li>
          </ol>
        </Card>

        <Card id="security-policy" title="What the security policy does">
          <p>The production build generates a Content-Security-Policy (CSP) in its hosting headers. The host must apply those headers. The policy restricts script and connection origins, hashes executable inline scripts, blocks object embedding and prevents framing.</p>
          <p>Same-origin requests remain allowed so the app can load workers and codecs. Advertising and analytics, when configured, add allowed origins. CSP reduces exposure; it does not prove that input cannot be read by a script already permitted to run in the page.</p>
          <p>The tools themselves do not upload input. An operator enabling third-party scripts must review their behavior and required consent configuration. Check the document response headers in DevTools to verify that the deployed host applies the generated policy.</p>
        </Card>

        <Card id="local-storage" title="What is stored in your browser">
          <p>
            No file content and no payload is written to persistent storage — not to{" "}
            <code>localStorage</code>, not to <code>sessionStorage</code>, not to IndexedDB. Closing the tab releases the application state. Downloaded files, copied clipboard content and browser or operating-system recovery features are outside this storage policy.
          </p>
          <div className="overflow-x-auto rounded border border-border">
            <table className="min-w-full divide-y divide-border text-xs">
              <caption className="sr-only">Keys written to localStorage</caption>
              <thead className="bg-surface-elevated">
                <tr className="text-left">
                  <th scope="col" className="p-2 font-mono text-2xs text-foreground-subtle">
                    Key
                  </th>
                  <th scope="col" className="p-2 font-mono text-2xs text-foreground-subtle">
                    Purpose
                  </th>
                  <th scope="col" className="p-2 font-mono text-2xs text-foreground-subtle">
                    Value
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr>
                  <th scope="row" className="p-2 text-left font-medium text-foreground">
                    ycd_theme
                  </th>
                  <td className="p-2">Remembers light or dark mode</td>
                  <td className="p-2 font-mono">&quot;dark&quot; | &quot;light&quot;</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p>That is the complete list.</p>
        </Card>

        <Card id="third-parties" title="Third parties">
          <ul className="list-inside list-disc space-y-3">
            <li>
              <strong className="text-foreground">Hosting and CDN.</strong> The site is served as
              static files from an edge CDN, which processes ordinary connection metadata — IP
              address and request timestamp — in order to deliver the HTML, CSS and JavaScript. It
              never sees your tool input, because your tool input is never part of a request.
            </li>

            {ADS.enabled ? (
              <li>
                <strong className="text-foreground">Google AdSense.</strong> This site is funded by
                advertising. Google and its partners load scripts, set cookies, and may use device
                identifiers and browsing behaviour to select and measure ads, including across other
                sites. This is standard advertising behaviour and it is the reason the claim on this
                page is specifically about <em>your file and your payload</em> rather than about the
                page as a whole. Google&rsquo;s use of data is described in its{" "}
                <a
                  href="https://policies.google.com/technologies/ads"
                  rel="noopener noreferrer nofollow"
                  target="_blank"
                >
                  advertising technologies policy
                </a>
                . The operator must configure any required consent platform before enabling advertising; the presence of an ad publisher ID alone does not implement consent.
              </li>
            ) : (
              <li>
                <strong className="text-foreground">Advertising.</strong> This build serves no
                advertisements and loads no ad scripts. The codebase contains an optional AdSense
                placement that stays inert unless a publisher ID and ad-unit IDs are configured at
                build time. If that changes, this page changes with it — the text you are reading is
                generated from the same build-time configuration the ad code reads, so the two
                cannot disagree.
              </li>
            )}

            {analyticsEnabled ? (
              <li>
                <strong className="text-foreground">Analytics.</strong> An analytics script is enabled in this build. Its exact data collection, cookies and retention depend on the configured provider. The tools do not intentionally send input to it; the operator must verify the provider settings and publish any required disclosures.
              </li>
            ) : (
              <li>
                <strong className="text-foreground">Analytics.</strong> None. No Google Analytics, no
                Mixpanel, no PostHog, no Sentry, no session recording, no error-tracking SDK.
              </li>
            )}
          </ul>
        </Card>

        <Card id="contact" title="Contact">
          <p>
            Questions about this policy, or a security disclosure:{" "}
            <a href="mailto:security@toolsbyus.com" className="font-medium text-accent">security@toolsbyus.com</a>
          </p>
          <p className="text-xs">
            Last updated September 2026. Applies to all pages on toolsbyus.com. See also the{" "}
            <Link href="/terms">terms of service</Link> and the{" "}
            <Link href="/about">architecture notes</Link>.
          </p>
        </Card>
      </div>

      <ReviewedStamp href="/privacy" />
    </div>
  );
}
