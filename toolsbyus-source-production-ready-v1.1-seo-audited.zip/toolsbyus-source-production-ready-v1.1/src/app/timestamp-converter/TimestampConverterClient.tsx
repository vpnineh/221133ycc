"use client";

import React, { useMemo, useState, useSyncExternalStore } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Notice } from "../../components/common/Notice";
import { btnCompact, field, fieldLabel } from "../../components/common/controls";
import { Icon } from "../../components/common/Icon";
import {
  parseInstant,
  representations,
  localZone,
  COMMON_ZONES,
  NOTABLE_INSTANTS,
} from "../../lib/time";
import { useNow } from "../../lib/use-now";
import { relatedTools } from "../../lib/tools";

/** Only used as the reference point for `now` and relative expressions. */
const EPOCH_FALLBACK = 0;

/**
 * The visitor's own time zone, read without breaking hydration.
 *
 * `useSyncExternalStore` is the only correct way to use a value the server
 * cannot know: React renders `getServerSnapshot` on the server *and* on the
 * hydration pass, so both produce identical markup, then switches to the client
 * value. The zone never changes during a session, so the subscribe function has
 * nothing to do.
 */
const subscribeNever = () => () => {};
const serverZone = () => "UTC";

export const TimestampConverterClient: React.FC = () => {
  const [input, setInput] = useState("");
  // The server has no locale, so the initial value must be stable. The real
  // zone is read lazily on the first client render.
  const [zone, setZone] = useState("UTC");
  const now = useNow(1000);

  const parsed = useMemo(
    () => parseInstant(input, now === EPOCH_FALLBACK ? Date.UTC(2026, 8, 11) : now),
    [input, now]
  );
  const rows = useMemo(
    /*
     * `now` is passed in rather than read inside, so the "Relative" row is a
     * function of props on both sides of hydration. A `new Date()` in there
     * made the row depend on when the page was rendered, which on a static
     * export means build time on the server and load time in the browser.
     */
    () =>
      parsed.ok
        ? representations(
            parsed.value.date,
            zone,
            new Date(now === EPOCH_FALLBACK ? Date.UTC(2026, 8, 11) : now)
          )
        : [],
    [parsed, zone, now]
  );

  /*
   * The visitor's own zone is prepended after mount, never during render.
   *
   * `useMemo` runs on the first client render too, which is the hydration
   * render — so calling `Intl.DateTimeFormat().resolvedOptions()` there
   * produced a different <option> list from the one the server emitted, and
   * React threw a text-content mismatch (#418) on every load outside UTC. The
   * page still worked, which is exactly why nobody noticed: hydration recovers
   * by re-rendering the subtree, and the only trace is a console error.
   *
   * The list is therefore identical on both sides for one render, and grows a
   * moment later on the client where reading the zone is legal.
   */
  const local = useSyncExternalStore(subscribeNever, localZone, serverZone);
  const zones = useMemo(
    () => (COMMON_ZONES.includes(local) ? COMMON_ZONES : [local, ...COMMON_ZONES]),
    [local]
  );

  return (
    <ToolShell
      slug="timestamp-converter"
      keyword="Unix Timestamp Converter"
      directAnswer="Unix Timestamp Converter turns a timestamp into every useful spelling of the same instant, and the other way round. The unit is detected from magnitude and stated: the same integer is a moment in 1970 or in 2026 depending on whether it counts seconds or milliseconds, and a converter that guesses silently produces a date that looks plausible and is wrong by a factor of a thousand."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "Timestamp Converter", url: "/timestamp-converter" },
      ]}
      seoDescription="Convert Unix timestamps to dates and back in the browser. Seconds, milliseconds, microseconds and nanoseconds detected automatically, ISO 8601 in any time zone, relative times and ISO week numbers."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The arithmetic is trivial. Working out what the number in front of you actually
              represents is not, and that is where the mistakes happen.
            </p>
            <h3>A Unix timestamp carries no units</h3>
            <p>
              <code>1757577600</code> is seconds since 1970 and lands in September 2026. Read as
              milliseconds it lands in January 1970. Read as microseconds, twenty minutes after
              midnight on 1 January 1970. Nothing in the value says which, so the unit is inferred
              from magnitude — ten digits or fewer is seconds, eleven to thirteen is milliseconds,
              and so on — and the inference is shown next to the result rather than applied
              silently. That distinction matters: an inference you can see is a fact you can
              override.
            </p>
            <h3>Year 2038 is not hypothetical</h3>
            <p>
              A signed 32-bit <code>time_t</code> runs out at 03:14:07 UTC on 19 January 2038, when
              it overflows to 1901. Modern operating systems moved to 64 bits years ago, but
              embedded firmware, old file formats and some database columns did not, and code that
              stores a timestamp in an <code>INT</code> column has the same ceiling. It is in the
              examples below because it is worth testing against.
            </p>
            <h3>A time zone offset belongs to the instant, not the zone</h3>
            <p>
              London is <code>+00:00</code> in January and <code>+01:00</code> in July, so
              &ldquo;Europe/London&rdquo; does not identify an offset — it identifies a set of rules
              for deriving one from a date. The ISO output here reads the offset for your specific
              instant from the platform&apos;s time zone database rather than computing it, which is
              what makes it correct across a daylight-saving boundary. Anything that hard-codes an
              offset is wrong twice a year.
            </p>
            <h3>Unix time has no leap seconds</h3>
            <p>
              A Unix timestamp is defined as the number of non-leap seconds since the epoch, which
              means it cannot represent one. When a leap second is inserted, implementations either
              repeat a value or smear the extra second across a day. So the difference between two
              Unix timestamps is not exactly the elapsed physical time — off by 27 seconds since
              1972, which matters for almost nothing and matters enormously for the few things it
              matters for.
            </p>
            <h3>ISO week numbers are not what people expect</h3>
            <p>
              Under ISO 8601 a week starts on Monday and week 1 is the one containing the first
              Thursday, so 1 January is sometimes in week 52 or 53 of the previous year. This is
              why a dashboard can show a week 53 that another shows as week 1, and both are right
              under different rules.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `1757577600`,
        outputTitle: "Resolved",
        exampleOutput: `unit      seconds (10 digits or fewer)
ISO       2025-09-11T08:00:00.000Z
RFC 2822  Thu, 11 Sep 2025 08:00:00 GMT
relative  in 1 year`,
      }}
      referenceTable={{
        title: "Accepted input and output",
        rows: [
          {
            parameter: "10 digits or fewer",
            type: "seconds",
            defaultVal: "detected",
            description:
              "The classic Unix epoch unit, and what almost every API and database means by a timestamp.",
          },
          {
            parameter: "11 to 13 digits",
            type: "milliseconds",
            defaultVal: "detected",
            description:
              "What JavaScript's Date.now returns, and what most JSON APIs written in JavaScript emit.",
          },
          {
            parameter: "14 to 16 digits",
            type: "microseconds",
            defaultVal: "detected",
            description: "Postgres internal timestamps and Python's time.time_ns divided by a thousand.",
          },
          {
            parameter: "17 or more digits",
            type: "nanoseconds",
            defaultVal: "detected",
            description: "Go's time.UnixNano and Prometheus exposition format.",
          },
          {
            parameter: "ISO 8601",
            type: "date string",
            defaultVal: "accepted",
            description:
              "2026-09-11T08:00:00Z and its variants. An ISO string without a zone is read as local time by the platform, which is a genuine ambiguity in the format rather than a choice made here.",
          },
          {
            parameter: "Relative",
            type: "expression",
            defaultVal: "accepted",
            description:
              "`3 days ago`, `2 hours`, `now`. Month and year are approximations, because neither has a fixed length.",
          },
          {
            parameter: "Time zone",
            type: "IANA name",
            defaultVal: "your local zone",
            description:
              "The offset is read from the platform's database for that specific instant, so it is correct on both sides of a daylight-saving change.",
          },
          {
            parameter: "ISO week",
            type: "1 to 53",
            defaultVal: "computed",
            description:
              "Weeks start on Monday; week 1 contains the first Thursday. 1 January can therefore be in week 52 or 53 of the previous year.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did my timestamp resolve to 1970?",
          answer:
            "You almost certainly pasted seconds into something expecting milliseconds, or the other way round. This tool detects the unit from the magnitude and tells you which it chose, so check that line first. A ten-digit number is seconds; a thirteen-digit number is milliseconds. Multiplying or dividing by a thousand is the whole fix.",
        },
        {
          question: "Seconds or milliseconds — which should my API use?",
          answer:
            "Seconds, unless you genuinely need sub-second precision, and say which in your documentation either way. Seconds is what Unix, most databases and most languages mean by a timestamp; milliseconds is what JavaScript means. The bugs come from the boundary between them, so the useful discipline is to name the unit in the field itself: created_at_ms rather than created_at.",
        },
        {
          question: "What actually happens in 2038?",
          answer:
            "A signed 32-bit time_t overflows at 03:14:07 UTC on 19 January 2038 and wraps to December 1901. 64-bit systems are fine and have been for years; what is not fine is embedded firmware that will still be running, file formats with a 32-bit field, and database columns typed INT rather than BIGINT. The last of those is the one most likely to be in your codebase right now.",
        },
        {
          question: "Why is my ISO string an hour out?",
          answer:
            "Usually daylight saving. An offset is a property of a specific instant, not of a zone: London is +00:00 in January and +01:00 in July. This tool reads the offset from the platform's time zone database for your exact instant, so it changes across the boundary — which is correct, and which is why a hard-coded offset is wrong for half the year.",
        },
        {
          question: "Does Unix time include leap seconds?",
          answer:
            "No, by definition — it counts non-leap seconds, which means it has no way to represent one. When a leap second is inserted, systems either repeat a timestamp value or smear the extra second across the day. The practical consequence is that subtracting two Unix timestamps gives you elapsed civil time, not elapsed physical time; they have differed by 27 seconds since 1972.",
        },
        {
          question: "Is my timestamp uploaded?",
          answer:
            "No. Every conversion here is arithmetic plus the browser's own Intl time zone database, running in the tab you already have open. There is nothing about converting a date that needs a server, and the timestamps people convert usually come out of production logs.",
        },
      ]}
      relatedTools={relatedTools("/timestamp-converter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          {/* The field is the widest control on the page. Fixed at 256px it
              pushed a 360px phone sideways by two pixels, which reads as the
              whole page drifting under a thumb. It now takes the row on a
              phone and its fixed width from `sm` up. */}
          <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
            <label htmlFor="ts-input" className={fieldLabel}>
              Timestamp or date
            </label>
            <input
              id="ts-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="e.g. 1757577600 or 2026-09-11"
              spellCheck={false}
              className={`${field} w-full min-w-0 sm:w-64`}
            />
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="ts-zone" className={fieldLabel}>
              Zone
            </label>
            <select
              id="ts-zone"
              value={zone}
              onChange={(e) => setZone(e.target.value)}
              className={`${field} w-48`}
            >
              {zones.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => {
              setInput(String(Math.floor(Date.now() / 1000)));
              setZone(localZone());
            }}
            className={btnCompact}
          >
            Now, here
          </button>

          <button
            type="button"
            onClick={() => {
              setInput("1757577600");
              setZone("UTC");
            }}
            className={`${btnCompact} text-accent hover:text-accent`}
          >
            <Icon name="sparkles" size="sm" className="mr-1 text-accent" />
            Try Example
          </button>

          {now !== EPOCH_FALLBACK && (
            <span className="ml-auto font-mono text-2xs text-foreground-subtle">
              now: {Math.floor(now / 1000)}
            </span>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {NOTABLE_INSTANTS.map((instant) => (
            <button
              key={instant.label}
              type="button"
              onClick={() => setInput(instant.value)}
              title={instant.note}
              className={btnCompact}
            >
              {instant.label}
            </button>
          ))}
        </div>

        {!input.trim() ? (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border p-12 text-center text-foreground-muted font-mono text-xs">
            <p>Enter a timestamp or ISO date above, or click &ldquo;Now, here&rdquo; or &ldquo;Try Example&rdquo;.</p>
          </div>
        ) : !parsed.ok ? (
          <Notice tone="danger">{parsed.error}</Notice>
        ) : (
          <>
            {parsed.value.detected && (
              <Notice tone="info">
                Read as <strong>{parsed.value.detected.unit}</strong>. {parsed.value.detected.reason}
              </Notice>
            )}

            <div className="overflow-x-auto rounded-lg border border-border bg-surface">
              <table className="w-full min-w-[36rem] border-collapse text-left font-mono text-xs">
                <caption className="sr-only">Representations of the same instant</caption>
                <thead>
                  <tr className="border-b border-border">
                    <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                      Format
                    </th>
                    <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                      Value
                    </th>
                    <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                      Note
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.label} className="border-b border-border last:border-0">
                      <th
                        scope="row"
                        className="whitespace-nowrap px-3 py-2 text-left font-medium text-foreground"
                      >
                        {row.label}
                      </th>
                      <td className="break-all px-3 py-2 text-foreground">{row.value}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-foreground-subtle">
                        {row.note ?? ""}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </ToolShell>
  );
};
