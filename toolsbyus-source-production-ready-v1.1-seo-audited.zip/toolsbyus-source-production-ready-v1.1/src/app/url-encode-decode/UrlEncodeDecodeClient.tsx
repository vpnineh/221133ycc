"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import {
  encodeUrl,
  decodeUrl,
  inspectUrl,
  detectEncodingDepth,
  URL_DEFAULTS,
  type UrlMode,
} from "../../lib/url";
import { relatedTools } from "../../lib/tools";

const SAMPLE = "https://example.com/search?q=a + b&lang=fr&tag=café#résultats";

const MODES: Array<{ id: UrlMode; label: string; hint: string }> = [
  { id: "component", label: "Component", hint: "encodeURIComponent: a query value or a path segment" },
  { id: "uri", label: "Full URL", hint: "encodeURI: keeps : / ? # & = intact" },
  { id: "form", label: "Form", hint: "application/x-www-form-urlencoded: space becomes +" },
  { id: "base64url", label: "base64url", hint: "RFC 4648 §5: - and _ instead of + and /, no padding" },
];

export const UrlEncodeDecodeClient: React.FC = () => {
  const [input, setInput] = useState("");
  const [direction, setDirection] = useState<"encode" | "decode">("encode");
  const [mode, setMode] = useState<UrlMode>("component");
  const [strict, setStrict] = useState(false);
  const [encodeEverything, setEncodeEverything] = useState(false);

  const result = useMemo(() => {
    if (direction === "encode") {
      return {
        output: encodeUrl(input, {
          ...URL_DEFAULTS,
          mode,
          strictRfc3986: strict,
          encodeEverything,
        }),
        notes: [] as string[],
        error: undefined as string | undefined,
      };
    }
    const decoded = decodeUrl(input, mode);
    return { output: decoded.value, notes: decoded.notes, error: decoded.error };
  }, [input, direction, mode, strict, encodeEverything]);

  const depth = useMemo(() => detectEncodingDepth(input), [input]);
  const parts = useMemo(() => inspectUrl(input), [input]);

  return (
    <ToolShell
      wide
      slug="url-encode-decode"
      keyword="URL Encoder and Decoder"
      directAnswer="URL Encoder and Decoder percent-encodes and decodes text in your browser. The mode matters more than it looks: in a query string a space is +, in a path it is %20, and decoding a form body with the wrong one turns &ldquo;a + b&rdquo; into &ldquo;a   b&rdquo; without any error."
      breadcrumbs={[
        { name: "Encoding Tools", url: "/encode-tools" },
        { name: "URL Encode / Decode", url: "/url-encode-decode" },
      ]}
      seoDescription="Percent-encode and decode URLs in the browser. Component, full-URL, form and base64url modes, strict RFC 3986 encoding, double-encoding detection and a URL component breakdown."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              &ldquo;URL encoding&rdquo; names three different encodings, and picking the wrong one
              produces a bug that never throws.
            </p>
            <h3>Percent-encoding is not form-encoding</h3>
            <p>
              RFC 3986 percent-encoding writes a space as <code>%20</code>. The
              <code>application/x-www-form-urlencoded</code> format — what a query string and a form
              POST body actually use — writes it as <code>+</code>, which means a literal plus has to
              be written <code>%2B</code>. Decode a form body with{" "}
              <code>decodeURIComponent</code> and the <code>+</code> survives untouched, so the
              search &ldquo;a + b&rdquo; arrives as &ldquo;a + b&rdquo; when the user typed a plus,
              and as &ldquo;a+b&rdquo; when they typed spaces. One of those is wrong and neither
              raises an error.
            </p>
            <h3>encodeURIComponent leaves five characters the RFC reserves</h3>
            <p>
              <code>!</code>, <code>&apos;</code>, <code>(</code>, <code>)</code> and <code>*</code>{" "}
              are reserved by RFC 3986 and left alone by <code>encodeURIComponent</code>. Usually
              harmless; not harmless when a signature is computed over the encoded form, which is why
              every AWS SigV4 and OAuth 1.0a library ships its own encoder. The strict option encodes
              them.
            </p>
            <h3>Each URL component has its own rules</h3>
            <p>
              A path may contain <code>/</code>; a query value may not contain an unencoded{" "}
              <code>&amp;</code> or it splits into two parameters. That is the difference between
              component mode and full-URL mode: the first encodes everything that is not unreserved,
              the second preserves the characters that give a URL its structure. Encoding a whole URL
              with <code>encodeURIComponent</code> produces a string that is no longer a URL.
            </p>
            <h3>Double-encoding, and how to see it</h3>
            <p>
              <code>%2520</code> is a space that went through an encoder twice: the <code>%</code> of{" "}
              <code>%20</code> was itself encoded as <code>%25</code>. It reads as &ldquo;%20&rdquo;
              to a person skimming a log and produces a literal <code>%20</code> in the decoded
              value. The tool counts how many decode passes the input survives, so a stray extra
              layer is visible rather than mysterious.
            </p>
            <h3>Splitting a URL uses the platform&apos;s parser</h3>
            <p>
              The component breakdown comes from the browser&apos;s own <code>URL</code>
              implementation rather than a regular expression, because URL parsing has enough edge
              cases — userinfo, IPv6 literals, default ports, percent-encoded hosts — that the WHATWG
              algorithm already in the platform is both shorter and more correct than any pattern.
              Duplicate query keys are preserved in order, since plenty of APIs give them meaning.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `q=a + b`,
        outputTitle: "Encoded",
        exampleOutput: `component: q%3Da%20%2B%20b
form:      q%3Da+%2B+b`,
      }}
      referenceTable={{
        title: "Modes and behaviour",
        rows: [
          {
            parameter: "Component",
            type: "encodeURIComponent",
            defaultVal: "default",
            description:
              "For one query value or one path segment. Encodes everything except A–Z a–z 0–9 - _ . ~ and the five characters below.",
          },
          {
            parameter: "Full URL",
            type: "encodeURI",
            defaultVal: "—",
            description:
              "For a whole URL. Keeps : / ? # [ ] @ ! $ & ' ( ) * + , ; = so the URL stays a URL. Using component mode here destroys the structure.",
          },
          {
            parameter: "Form",
            type: "x-www-form-urlencoded",
            defaultVal: "—",
            description:
              "For a query string or a POST body. A space is +, a literal + is %2B. Decoding correctly requires undoing + before percent-decoding, or a literal plus becomes a space.",
          },
          {
            parameter: "base64url",
            type: "RFC 4648 §5",
            defaultVal: "—",
            description:
              "The URL-safe base64 alphabet: - and _ rather than + and /, with padding stripped. What JWT segments use.",
          },
          {
            parameter: "Strict RFC 3986",
            type: "boolean",
            defaultVal: "off",
            description:
              "Also encodes ! ' ( ) *, which encodeURIComponent leaves alone. Required when the encoded form feeds a signature.",
          },
          {
            parameter: "Encode everything",
            type: "boolean",
            defaultVal: "off",
            description:
              "Percent-encodes every byte including unreserved ones. Ugly, valid, and occasionally the only thing a fussy gateway accepts.",
          },
          {
            parameter: "Character set",
            type: "UTF-8",
            defaultVal: "always",
            description:
              "Non-ASCII is encoded as its UTF-8 bytes, one %XX each, which is what every current browser and server expects.",
          },
          {
            parameter: "Malformed input",
            type: "reported",
            defaultVal: "with position",
            description:
              "decodeURIComponent throws a bare URIError. The offending sequence is located and named instead.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why is my space a + instead of %20?",
          answer:
            "Because you are in form mode, which is correct for a query string or a form POST body — that format defines a space as +. In a path segment or a fragment, a space is %20 and a + is a literal plus. Both encodings are correct; using the wrong one for the position is what corrupts the value.",
        },
        {
          question: "encodeURI or encodeURIComponent?",
          answer:
            "encodeURIComponent for one piece — a query value, a path segment, a fragment. encodeURI for a whole URL you want to remain a URL. The test is simple: if the text you are encoding contains characters that are structural (a ?, a &, a /) and you want them to keep working, you need encodeURI; if you want them to become data, you need encodeURIComponent.",
        },
        {
          question: "What is %2520 and how did I get it?",
          answer:
            "A space, encoded twice. The first pass made %20; the second encoded that % as %25, giving %2520. It usually means a value was encoded by application code and then again by a framework or a proxy. The depth counter above shows how many passes your input survives, so you can tell whether one layer is too many.",
        },
        {
          question: "Why are !'()* not encoded?",
          answer:
            "encodeURIComponent deliberately leaves them, even though RFC 3986 reserves them. It is almost always harmless — until the encoded string is the input to a signature, where the signer and the verifier must agree byte for byte. That is why AWS SigV4 and OAuth 1.0a both specify their own encoder. Turn on strict mode if you are in that situation.",
        },
        {
          question: "Is base64url the same as base64?",
          answer:
            "Same algorithm, different alphabet. base64 uses + and /, which are both meaningful in a URL, so base64url swaps them for - and _ and drops the = padding, which is meaningful in a query string. A JWT is three base64url segments joined by dots, which is why a JWT can be pasted straight into a URL and a base64 blob cannot.",
        },
        {
          question: "Is my input uploaded?",
          answer:
            "No. Encoding and decoding are string operations that run in your browser — open the Network panel and watch while you type. It matters here because URLs people need to decode are frequently signed callback URLs, OAuth redirects and session tokens, which is to say credentials in a form that looks harmless.",
        },
      ]}
      relatedTools={relatedTools("/url-encode-decode").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className={segmentTrack} role="group" aria-label="Direction">
            {(["encode", "decode"] as const).map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setDirection(value)}
                aria-pressed={direction === value}
                className={segment(direction === value)}
              >
                {value === "encode" ? "Encode" : "Decode"}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Mode</span>
            <div className={segmentTrack} role="group" aria-label="Mode">
              {MODES.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setMode(option.id)}
                  aria-pressed={mode === option.id}
                  title={option.hint}
                  className={segment(mode === option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {direction === "encode" && mode !== "base64url" && (
            <>
              <label
                htmlFor="url-strict"
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id="url-strict"
                  type="checkbox"
                  checked={strict}
                  onChange={(e) => setStrict(e.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>Strict !&apos;()*</span>
              </label>
              <label
                htmlFor="url-everything"
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id="url-everything"
                  type="checkbox"
                  checked={encodeEverything}
                  onChange={(e) => setEncodeEverything(e.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>Every byte</span>
              </label>
            </>
          )}

          {depth > 0 && (
            <span className="ml-auto font-mono text-2xs text-foreground-subtle">
              {depth === 1 ? "encoded once" : `encoded ${depth} times`}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label={direction === "encode" ? "Plain text" : "Encoded"}
            value={input}
            onChange={setInput}
            placeholder="Paste a URL or a value…"
            height={200}
            error={result.error ? { message: result.error } : undefined}
            onLoadExample={() => setInput(SAMPLE)}
          />
          <CodePane
            label={direction === "encode" ? "Encoded" : "Plain text"}
            value={result.output}
            onChange={() => undefined}
            readOnly
            height={200}
          />
        </div>

        {result.notes.map((note) => (
          <Notice key={note} tone="info">
            {note}
          </Notice>
        ))}

        {depth > 1 && (
          <Notice tone="warn">
            This value survives {depth} decode passes, so it was encoded {depth} times. A{" "}
            <code>%2520</code> in a log is a space that went through an encoder twice — usually
            because application code encoded a value that a framework or proxy then encoded again.
          </Notice>
        )}

        {"url" in parts && (
          <div className="overflow-x-auto rounded-lg border border-border bg-surface">
            <table className="w-full min-w-[32rem] border-collapse text-left font-mono text-xs">
              <caption className="sr-only">URL components</caption>
              <thead>
                <tr className="border-b border-border">
                  <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                    Component
                  </th>
                  <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                    Value
                  </th>
                </tr>
              </thead>
              <tbody>
                {(
                  [
                    ["protocol", parts.url.protocol],
                    ["hostname", parts.url.hostname],
                    ["port", parts.url.port || "(default)"],
                    ["pathname", parts.url.pathname],
                    ["hash", parts.url.hash || "(none)"],
                  ] as const
                ).map(([name, value]) => (
                  <tr key={name} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap px-3 py-1.5 text-foreground-subtle">{name}</td>
                    <td className="px-3 py-1.5 text-foreground">{value}</td>
                  </tr>
                ))}
                {parts.url.params.map((param, index) => (
                  <tr key={`${param.key}-${index}`} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap px-3 py-1.5 text-move">?{param.key}</td>
                    <td className="px-3 py-1.5 text-foreground">{param.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </ToolShell>
  );
};
