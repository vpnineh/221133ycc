"use client";

import React, { useState, useEffect, useId } from "react";
import {
  generateBatch,
  inspectUuid,
  UuidVersion,
  UuidInspection,
} from "@/lib/uuid";

export default function UuidClient() {
  const [activeTab, setActiveTab] = useState<"generator" | "inspector">("generator");
  const [version, setVersion] = useState<UuidVersion>("v4");
  const [count, setCount] = useState<number>(10);
  const [uppercase, setUppercase] = useState<boolean>(false);
  const [hyphens, setHyphens] = useState<boolean>(true);
  const [quotes, setQuotes] = useState<boolean>(false);
  const [braces, setBraces] = useState<boolean>(false);
  const [separator, setSeparator] = useState<"newline" | "comma" | "json">("newline");

  // Seeded on mount, not during render.
  //
  // A lazy useState initializer runs during the static prerender *and* again on
  // the client, producing two different random batches — a guaranteed hydration
  // mismatch (React #418), and a build that bakes one fixed set of UUIDs into
  // the HTML every visitor briefly sees. Generating in an effect keeps the
  // server output deterministic and gives each visitor fresh values.
  const [output, setOutput] = useState<string>("");

  useEffect(() => {
    // Intentional: the value must come from the crypto RNG on the client only,
    // which is exactly the "synchronize with an external system" case an effect
    // is for. Computing it during render is what caused the mismatch above.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setOutput(
      generateBatch("v4", 10, {
        uppercase: false,
        hyphens: true,
        quotes: false,
        braces: false,
        separator: "newline",
      })
    );
    // Mount only: later batches come from the Generate button.
  }, []);

  const [inspectInput, setInspectInput] = useState<string>("");
  const [copied, setCopied] = useState<boolean>(false);

  const customCountId = useId();
  const inspectId = useId();

  const handleGenerate = () => {
    const res = generateBatch(version, count, {
      uppercase,
      hyphens,
      quotes,
      braces,
      separator,
    });
    setOutput(res);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleDownload = (format: "txt" | "json") => {
    const blob = new Blob([output], {
      type: format === "json" ? "application/json" : "text/plain",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `uuids-${version}-${Date.now()}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // The label reports what is actually on screen, not the quantity currently
  // selected in the dropdown — those differ until Generate is pressed again.
  const generatedCount =
    separator === "json"
      ? (output.match(/"/g)?.length ?? 0) / 2
      : output.trim()
        ? output.trim().split(separator === "comma" ? "," : "\n").length
        : 0;

  const inspection: UuidInspection = inspectUuid(inspectInput);

  return (
    <div className="space-y-6">
      {/* Top bar with mode selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setActiveTab("generator")}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
              activeTab === "generator"
                ? "bg-surface text-foreground shadow-pop"
                : "bg-surface text-foreground hover:bg-surface-elevated"
            }`}
          >
            Bulk Generator
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("inspector")}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
              activeTab === "inspector"
                ? "bg-surface text-foreground shadow-pop"
                : "bg-surface text-foreground hover:bg-surface-elevated"
            }`}
          >
            Inspect UUID
          </button>
        </div>

      </div>

      {activeTab === "generator" ? (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="rounded-xl bg-surface-elevated p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Version */}
              <div className="space-y-1.5">
                <span className="text-xs font-mono font-semibold text-foreground-muted block">
                  UUID Version
                </span>
                <div className="flex rounded-pill bg-surface p-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setVersion("v4")}
                    className={`flex-1 py-1.5 rounded text-center transition-colors ${
                      version === "v4"
                        ? "bg-surface text-foreground shadow-pop font-semibold"
                        : "text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    v4 (Random)
                  </button>
                  <button
                    type="button"
                    onClick={() => setVersion("v7")}
                    className={`flex-1 py-1.5 rounded text-center transition-colors ${
                      version === "v7"
                        ? "bg-surface text-foreground shadow-pop font-semibold"
                        : "text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    v7 (Time-Ordered)
                  </button>
                  <button
                    type="button"
                    onClick={() => setVersion("v1")}
                    className={`flex-1 py-1.5 rounded text-center transition-colors ${
                      version === "v1"
                        ? "bg-surface text-foreground shadow-pop font-semibold"
                        : "text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    v1 (Gregorian)
                  </button>
                </div>
              </div>

              {/* Quantity */}
              <div className="space-y-1.5">
                <span className="text-xs font-mono font-semibold text-foreground-muted block">
                  Quantity ({count})
                </span>
                <div className="flex items-center gap-2">
                  <select
                    value={[1, 5, 10, 25, 50, 100, 500, 1000].includes(count) ? count : "custom"}
                    onChange={(e) => {
                      if (e.target.value !== "custom") {
                        setCount(Number(e.target.value));
                      }
                    }}
                    className="flex-1 rounded-lg bg-surface px-3 py-1.5 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
                  >
                    <option value={1}>1 UUID</option>
                    <option value={5}>5 UUIDs</option>
                    <option value={10}>10 UUIDs</option>
                    <option value={25}>25 UUIDs</option>
                    <option value={50}>50 UUIDs</option>
                    <option value={100}>100 UUIDs</option>
                    <option value={500}>500 UUIDs</option>
                    <option value={1000}>1,000 UUIDs</option>
                    <option value="custom">Custom count...</option>
                  </select>
                  <label htmlFor={customCountId} className="sr-only">
                    Custom count
                  </label>
                  <input
                    id={customCountId}
                    type="number"
                    min={1}
                    max={5000}
                    value={count}
                    onChange={(e) =>
                      setCount(Math.min(5000, Math.max(1, Number(e.target.value) || 1)))
                    }
                    className="w-20 rounded-lg bg-surface px-2.5 py-1.5 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
                  />
                </div>
              </div>

              {/* Formatting Toggles */}
              <div className="space-y-1.5">
                <span className="text-xs font-mono font-semibold text-foreground-muted block">
                  Formatting Options
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={uppercase}
                      onChange={(e) => setUppercase(e.target.checked)}
                      className="rounded border-border text-accent focus:ring-accent"
                    />
                    <span>Uppercase</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={hyphens}
                      onChange={(e) => setHyphens(e.target.checked)}
                      className="rounded border-border text-accent focus:ring-accent"
                    />
                    <span>Hyphens</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={quotes}
                      onChange={(e) => setQuotes(e.target.checked)}
                      className="rounded border-border text-accent focus:ring-accent"
                    />
                    <span>Quotes &quot;</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={braces}
                      onChange={(e) => setBraces(e.target.checked)}
                      className="rounded border-border text-accent focus:ring-accent"
                    />
                    <span>Braces &#123;&#125;</span>
                  </label>
                </div>
              </div>

              {/* Separator / Array Output */}
              <div className="space-y-1.5">
                <span className="text-xs font-mono font-semibold text-foreground-muted block">
                  Delimiter Format
                </span>
                <select
                  value={separator}
                  onChange={(e) =>
                    setSeparator(e.target.value as "newline" | "comma" | "json")
                  }
                  className="w-full rounded-lg bg-surface px-3 py-1.5 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
                >
                  <option value="newline">Newline separated</option>
                  <option value="comma">Comma separated (, )</option>
                  <option value="json">JSON Array format</option>
                </select>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-border">
              <button
                type="button"
                onClick={handleGenerate}
                className="rounded-pill bg-accent-solid px-5 py-2 text-sm font-semibold text-accent-on transition-colors hover:bg-accent-hover"
              >
                Generate New Batch
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleDownload("txt")}
                  className="rounded-pill bg-surface px-3.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-border"
                >
                  Download .txt
                </button>
                <button
                  type="button"
                  onClick={() => handleDownload("json")}
                  className="rounded-pill bg-surface px-3.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-border"
                >
                  Download .json
                </button>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="rounded-pill bg-accent-solid px-4 py-1.5 text-xs font-semibold text-accent-on transition-colors hover:bg-accent-hover"
                >
                  {copied ? "Copied!" : "Copy All"}
                </button>
              </div>
            </div>
          </div>

          {/* Output Display */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-2xs text-foreground-subtle">
                Generated UUID Output ({generatedCount} total)
              </span>
            </div>
            <pre className="h-80 w-full select-all overflow-auto whitespace-pre rounded-lg bg-surface-elevated p-4 font-mono text-xs leading-relaxed sm:text-sm">
              {output}
            </pre>
          </div>
        </div>
      ) : (
        /* Inspector Tab */
        <div className="space-y-6">
          <div className="rounded-xl bg-surface-elevated p-4 space-y-3">
            <label
              htmlFor={inspectId}
              className="block text-2xs text-foreground-subtle"
            >
              Paste any UUID (with or without hyphens, curly braces, or uppercase)
            </label>
            <div className="flex gap-2">
              <input
                id={inspectId}
                type="text"
                value={inspectInput}
                onChange={(e) => setInspectInput(e.target.value)}
                placeholder="e.g. 018f4305-64bc-72e2-9bd8-5e26ec0373ab"
                className="flex-1 rounded-lg bg-surface px-3 py-2 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
              />
              <button
                type="button"
                onClick={() => setInspectInput("018f4305-64bc-72e2-9bd8-5e26ec0373ab")}
                className="rounded-pill bg-surface px-4 py-2 text-xs font-medium text-accent transition-colors hover:bg-border"
              >
                Try Example (v7)
              </button>
            </div>
          </div>

          {inspection.isValid ? (
            <div className="overflow-hidden rounded-lg bg-surface-elevated divide-y divide-border font-mono text-sm">
              <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-2 bg-surface-elevated">
                <span className="text-xs font-semibold text-foreground-muted uppercase">
                  Normalized Standard Form
                </span>
                <span className="md:col-span-2 text-accent font-bold">
                  {inspection.normalized}
                </span>
              </div>

              <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-2">
                <span className="text-xs font-semibold text-foreground-muted uppercase">
                  UUID Version
                </span>
                <div className="md:col-span-2">
                  <span className="font-bold text-foreground">
                    Version {inspection.version}
                  </span>
                  <span className="text-xs text-foreground-muted block mt-0.5">
                    {inspection.versionName}
                  </span>
                </div>
              </div>

              <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-2">
                <span className="text-xs font-semibold text-foreground-muted uppercase">
                  Variant Spec
                </span>
                <span className="md:col-span-2 text-foreground font-semibold">
                  {inspection.variant}
                </span>
              </div>

              {inspection.timestamp && (
                <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-2 bg-accent-soft">
                  <span className="text-xs font-semibold text-foreground-muted uppercase">
                    Embedded Timestamp
                  </span>
                  <div className="md:col-span-2 space-y-1">
                    <span className="font-bold text-accent">
                      {inspection.timestampIso} (UTC)
                    </span>
                    <span className="text-xs text-foreground-muted block">
                      Local: {inspection.timestamp.toString()}
                    </span>
                    <span className="text-xs text-foreground-muted block">
                      Unix Milliseconds: {inspection.timestamp.getTime()}
                    </span>
                  </div>
                </div>
              )}

              <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-2">
                <span className="text-xs font-semibold text-foreground-muted uppercase">
                  Entropy / Random Bits
                </span>
                <span className="md:col-span-2 text-foreground">
                  {inspection.randomBits} bits of cryptographically secure pseudo-random entropy
                </span>
              </div>
            </div>
          ) : !inspectInput.trim() ? (
            <div className="rounded-lg border border-dashed border-border p-8 text-center text-foreground-muted font-mono text-xs">
              Paste a UUID above or click &ldquo;Try Example (v7)&rdquo; to inspect its RFC 9562 structure and timestamp.
            </div>
          ) : (
            <div className="p-4 bg-danger-soft border border-danger rounded-lg text-danger font-mono text-sm">
              Invalid UUID format. {inspection.details || "Must be 32 hexadecimal digits."}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
