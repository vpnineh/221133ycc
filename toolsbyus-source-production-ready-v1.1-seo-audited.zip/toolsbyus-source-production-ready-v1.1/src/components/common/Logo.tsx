import React from "react";

/**
 * The mark: a toolbox, in a rounded square.
 *
 * A toolbox rather than a wrench, because the name is not "one tool" — it is a
 * set of them, and a box with a handle is the one silhouette that says "a set"
 * at 16 pixels. A wrench at that size is a diagonal smudge, and a wrench
 * crossed with a screwdriver is two diagonal smudges.
 *
 * What this replaced, and why. The previous mark set "TBU" as three drawn
 * letters with the T's crossbar cut into a spanner's jaws. Two things were
 * wrong with it, and the second is the one that matters. The cut turned the T
 * into a glyph a reader tries and fails to name — at menu-bar size it reads as
 * a Y with a nick in it — and, worse, the mark *was* the name, so the site's
 * own name never appeared in its own header. An initialism nobody has seen
 * before is not a brand, it is a puzzle; a mark beside the words is how a name
 * gets learned.
 *
 * So: an icon, and then the name in type beside it. The icon carries the
 * colour, which is why it is the site's accent rather than an outline — a
 * header needs one small saturated thing to anchor it, and an outlined badge in
 * a bar full of outlined controls anchors nothing.
 *
 * Drawn as paths on a 32-unit grid rather than set in the brand face, so the
 * mark is identical in a favicon, on a share card and on a printed sticker, and
 * does not change shape when a font licence does. The glyph is painted in the
 * page colour and the cuts in it are painted in the accent, so the whole thing
 * is two colours and survives being shrunk, printed in one ink, or placed on a
 * dark page.
 *
 * Keep in step with public/favicon.svg, public/icon.svg and the `mark()`
 * function in scripts/generate-images.mjs, which are the same artwork at 32,
 * 64 and 24 units with hex literals instead of tokens.
 */
export const LogoMark: React.FC<{ className?: string }> = ({ className = "" }) => (
  <span
    className={`inline-flex flex-none items-center justify-center rounded-lg border border-border bg-surface-elevated p-1 text-accent-solid shadow-sm ${className}`}
    aria-hidden="true"
  >
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.3"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-full w-full"
    >
      <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
    </svg>
  </span>
);

/**
 * The lockup used in the chrome: mark, then the name.
 *
 * The name is live text rather than outlines, which is the right trade here and
 * not the usual one. A wordmark is normally drawn so it cannot reflow — but
 * this one sits in a 4.5rem bar next to a nav that has to survive 360px, and
 * live text is what lets it inherit the page's own family, its own weight and
 * its own colour tokens in both themes. The font is self-hosted and declared
 * `display: block`, so there is no flash of a second face to reflow around.
 *
 * "ByUs" takes the accent. It is the half of the name that is the claim —
 * these are tools built by people, for the browser — and two tones are what
 * keep a nine-letter run of camel case from reading as one long word. It is one
 * text node with no space in it, so there is no point for the name to wrap at:
 * "Tools" over "ByUs" is a break that would read as a mistake, and a bar this
 * tight is exactly where it would happen.
 */
export const Logo: React.FC<{ className?: string }> = ({ className = "" }) => (
  <span className={`flex items-center gap-2.5 ${className}`}>
    <LogoMark className="h-[1.75rem] w-[1.75rem]" />
    <span className="text-[1.3125rem] font-bold leading-none tracking-[-0.032em] text-foreground">
      Tools<span className="text-accent">ByUs</span>
    </span>
  </span>
);

export default Logo;
