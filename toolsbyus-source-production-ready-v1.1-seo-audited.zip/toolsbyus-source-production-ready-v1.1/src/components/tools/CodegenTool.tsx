"use client";

import React, { useMemo, useState } from "react";
import { CodePane } from "./CodePane";
import { Notice } from "../common/Notice";
import { checkbox, field, fieldLabel, segment, segmentTrack } from "../common/controls";
import { parseJson } from "../../lib/json/parser";
import {
  generate,
  CSHARP_DEFAULTS,
  GO_DEFAULTS,
  JAVA_DEFAULTS,
  PYTHON_DEFAULTS,
  TYPESCRIPT_DEFAULTS,
  type CSharpOptions,
  type GoOptions,
  type JavaOptions,
  type PythonOptions,
  type Target,
  type TypeScriptOptions,
} from "../../lib/codegen";
import { pascalCase } from "../../lib/codegen/model";

/**
 * The shared surface behind the five `/json-to-<language>` tools.
 *
 * They differ only in which emitter runs and which options are offered, and the
 * hard part — inferring one type model that all five agree on — is upstream in
 * `lib/codegen`. Giving each page its own copy of the paste-infer-render loop
 * would mean five places to fix the next bug in it.
 */

/** Above this the inference starts costing more than a paste is worth. */
const MAX_INPUT_BYTES = 2 * 1024 * 1024;

const SAMPLE = JSON.stringify(
  {
    id: 9007199254740991,
    email: "ada@example.com",
    created_at: "2026-09-11T08:14:22Z",
    active: true,
    balance: 148.5,
    deleted_at: null,
    address: { line1: "5 Analytical Way", city: "London", postcode: "E1 6AN" },
    roles: ["admin", "billing"],
    orders: [
      { ref: "ord_1041", total: 24, shipped: true },
      { ref: "ord_1042", total: 100.5, shipped: false, note: "gift wrap" },
    ],
  },
  null,
  2
);

interface CodegenToolProps {
  target: Target;
  /** Default name for the root type, e.g. `Root` or `User`. */
  defaultRootName?: string;
}

export const CodegenTool: React.FC<CodegenToolProps> = ({ target, defaultRootName = "Root" }) => {
  const [raw, setRaw] = useState("");
  const [rootName, setRootName] = useState(defaultRootName);

  const [tsOptions, setTsOptions] = useState<TypeScriptOptions>(TYPESCRIPT_DEFAULTS);
  const [goOptions, setGoOptions] = useState<GoOptions>(GO_DEFAULTS);
  const [pyOptions, setPyOptions] = useState<PythonOptions>(PYTHON_DEFAULTS);
  const [csOptions, setCsOptions] = useState<CSharpOptions>(CSHARP_DEFAULTS);
  const [javaOptions, setJavaOptions] = useState<JavaOptions>(JAVA_DEFAULTS);

  const oversized = new Blob([raw]).size > MAX_INPUT_BYTES;
  const parsed = useMemo(() => (oversized ? null : parseJson(raw)), [raw, oversized]);

  const result = useMemo(() => {
    if (!parsed?.success) return null;
    // An empty name would produce `interface  {`, so fall back rather than
    // emitting a file that does not compile.
    const name = pascalCase(rootName.trim() || defaultRootName);
    switch (target) {
      case "typescript":
        return generate(parsed.data, name, { target, options: tsOptions });
      case "go":
        return generate(parsed.data, name, { target, options: goOptions });
      case "python":
        return generate(parsed.data, name, { target, options: pyOptions });
      case "csharp":
        return generate(parsed.data, name, { target, options: csOptions });
      case "java":
        return generate(parsed.data, name, { target, options: javaOptions });
    }
  }, [parsed, rootName, defaultRootName, target, tsOptions, goOptions, pyOptions, csOptions, javaOptions]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
        <div className="flex items-center gap-2">
          <label htmlFor="root-name" className={fieldLabel}>
            Root type
          </label>
          <input
            id="root-name"
            type="text"
            value={rootName}
            onChange={(e) => setRootName(e.target.value)}
            spellCheck={false}
            className={`${field} w-36`}
          />
        </div>

        {target === "typescript" && (
          <TypeScriptControls options={tsOptions} onChange={setTsOptions} />
        )}
        {target === "go" && <GoControls options={goOptions} onChange={setGoOptions} />}
        {target === "python" && <PythonControls options={pyOptions} onChange={setPyOptions} />}
        {target === "csharp" && <CSharpControls options={csOptions} onChange={setCsOptions} />}
        {target === "java" && <JavaControls options={javaOptions} onChange={setJavaOptions} />}

        {result && (
          <span className="ml-auto self-center font-mono text-2xs text-foreground-subtle">
            {result.names.length} type{result.names.length === 1 ? "" : "s"} · root{" "}
            {result.rootExpression}
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <CodePane
          label="Sample JSON"
          value={raw}
          onChange={setRaw}
          placeholder="Paste a JSON response or click 'Try Example'…"
          height={480}
          onLoadExample={() => setRaw(SAMPLE)}
          error={parsed && !parsed.success ? parsed.error : undefined}
        />
        <CodePane
          label="Generated code"
          value={result?.code ?? ""}
          onChange={() => undefined}
          readOnly
          height={480}
          placeholder="Paste valid JSON to generate types."
        />
      </div>

      {oversized && (
        <Notice tone="warn">
          That sample is above the 2 MB ceiling. Type inference reads every value, so a larger
          document would lock the tab for seconds without producing a better answer — a few hundred
          representative records describe the shape as well as a million do.
        </Notice>
      )}

      <Notice tone="info">
        Paste more than one record if you have them. A field present in some records and absent from
        others is only detectable across samples, and it is the difference between a type that
        matches your data and one that matches your first row.
      </Notice>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Per-target option controls                                                 */
/* -------------------------------------------------------------------------- */

interface Toggle {
  id: string;
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  title?: string;
}

const Toggles: React.FC<{ items: Toggle[] }> = ({ items }) => (
  <>
    {items.map((item) => (
      <label
        key={item.id}
        htmlFor={item.id}
        title={item.title}
        className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
      >
        <input
          id={item.id}
          type="checkbox"
          checked={item.checked}
          onChange={(e) => item.onChange(e.target.checked)}
          className={checkbox}
        />
        <span className={fieldLabel}>{item.label}</span>
      </label>
    ))}
  </>
);

const Segments: React.FC<{
  label: string;
  options: Array<{ value: string; label: string }>;
  value: string;
  onChange: (value: string) => void;
}> = ({ label, options, value, onChange }) => (
  <div className="flex items-center gap-2">
    <span className={fieldLabel}>{label}</span>
    <div className={segmentTrack} role="group" aria-label={label}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onChange(option.value)}
          aria-pressed={value === option.value}
          className={segment(value === option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  </div>
);

const TypeScriptControls: React.FC<{
  options: TypeScriptOptions;
  onChange: (value: TypeScriptOptions) => void;
}> = ({ options, onChange }) => (
  <>
    <Segments
      label="Shape"
      value={options.useInterfaces ? "interface" : "type"}
      onChange={(value) => onChange({ ...options, useInterfaces: value === "interface" })}
      options={[
        { value: "interface", label: "interface" },
        { value: "type", label: "type" },
      ]}
    />
    <Toggles
      items={[
        {
          id: "ts-readonly",
          label: "readonly",
          checked: options.readonly,
          onChange: (readonly) => onChange({ ...options, readonly }),
        },
        {
          id: "ts-export",
          label: "export",
          checked: options.exported,
          onChange: (exported) => onChange({ ...options, exported }),
        },
        {
          id: "ts-camel",
          label: "camelCase keys",
          title: "Renames snake_case keys and records the original in a comment.",
          checked: options.camelCaseKeys,
          onChange: (camelCaseKeys) => onChange({ ...options, camelCaseKeys }),
        },
      ]}
    />
  </>
);

const GoControls: React.FC<{ options: GoOptions; onChange: (value: GoOptions) => void }> = ({
  options,
  onChange,
}) => (
  <>
    <div className="flex items-center gap-2">
      <label htmlFor="go-package" className={fieldLabel}>
        Package
      </label>
      <input
        id="go-package"
        type="text"
        value={options.packageName}
        onChange={(e) => onChange({ ...options, packageName: e.target.value })}
        spellCheck={false}
        className={`${field} w-28`}
      />
    </div>
    <Toggles
      items={[
        {
          id: "go-pointer",
          label: "pointers",
          title: "Optional fields become pointers, so an absent key differs from the zero value.",
          checked: options.pointerForOptional,
          onChange: (pointerForOptional) => onChange({ ...options, pointerForOptional }),
        },
        {
          id: "go-omitempty",
          label: "omitempty",
          checked: options.omitEmpty,
          onChange: (omitEmpty) => onChange({ ...options, omitEmpty }),
        },
        {
          id: "go-jsonnumber",
          label: "json.Number",
          title: "Keeps the literal digits instead of rounding through float64.",
          checked: options.useJSONNumber,
          onChange: (useJSONNumber) => onChange({ ...options, useJSONNumber }),
        },
      ]}
    />
  </>
);

const PythonControls: React.FC<{
  options: PythonOptions;
  onChange: (value: PythonOptions) => void;
}> = ({ options, onChange }) => (
  <>
    <Segments
      label="Shape"
      value={options.style}
      onChange={(style) => onChange({ ...options, style: style as PythonOptions["style"] })}
      options={[
        { value: "dataclass", label: "dataclass" },
        { value: "typeddict", label: "TypedDict" },
        { value: "pydantic", label: "pydantic" },
      ]}
    />
    <Toggles
      items={[
        {
          id: "py-snake",
          label: "snake_case",
          checked: options.snakeCaseKeys,
          onChange: (snakeCaseKeys) => onChange({ ...options, snakeCaseKeys }),
        },
        {
          id: "py-modern",
          label: "X | None",
          title: "Python 3.10+ union syntax instead of Optional[X].",
          checked: options.modernOptional,
          onChange: (modernOptional) => onChange({ ...options, modernOptional }),
        },
      ]}
    />
  </>
);

const CSharpControls: React.FC<{
  options: CSharpOptions;
  onChange: (value: CSharpOptions) => void;
}> = ({ options, onChange }) => (
  <>
    <Segments
      label="Shape"
      value={options.style}
      onChange={(style) => onChange({ ...options, style: style as CSharpOptions["style"] })}
      options={[
        { value: "class", label: "class" },
        { value: "record", label: "record" },
      ]}
    />
    <div className="flex items-center gap-2">
      <label htmlFor="cs-namespace" className={fieldLabel}>
        Namespace
      </label>
      <input
        id="cs-namespace"
        type="text"
        value={options.namespaceName}
        onChange={(e) => onChange({ ...options, namespaceName: e.target.value })}
        spellCheck={false}
        className={`${field} w-32`}
      />
    </div>
    <Toggles
      items={[
        {
          id: "cs-stj",
          label: "System.Text.Json",
          title: "Off uses Newtonsoft.Json attributes instead.",
          checked: options.systemTextJson,
          onChange: (systemTextJson) => onChange({ ...options, systemTextJson }),
        },
        {
          id: "cs-nullable",
          label: "nullable",
          checked: options.nullableEnabled,
          onChange: (nullableEnabled) => onChange({ ...options, nullableEnabled }),
        },
      ]}
    />
  </>
);

const JavaControls: React.FC<{ options: JavaOptions; onChange: (value: JavaOptions) => void }> = ({
  options,
  onChange,
}) => (
  <>
    <Segments
      label="Shape"
      value={options.style}
      onChange={(style) => onChange({ ...options, style: style as JavaOptions["style"] })}
      options={[
        { value: "record", label: "record" },
        { value: "pojo", label: "POJO" },
      ]}
    />
    <div className="flex items-center gap-2">
      <label htmlFor="java-package" className={fieldLabel}>
        Package
      </label>
      <input
        id="java-package"
        type="text"
        value={options.packageName}
        onChange={(e) => onChange({ ...options, packageName: e.target.value })}
        placeholder="com.example"
        spellCheck={false}
        className={`${field} w-36`}
      />
    </div>
    <Toggles
      items={[
        {
          id: "java-jackson",
          label: "Jackson",
          checked: options.jackson,
          onChange: (jackson) => onChange({ ...options, jackson }),
        },
        {
          id: "java-box",
          label: "box optionals",
          title: "An optional int becomes Integer, so a missing key is not deserialized as 0.",
          checked: options.boxPrimitives,
          onChange: (boxPrimitives) => onChange({ ...options, boxPrimitives }),
        },
      ]}
    />
  </>
);
