"use client";

import React from "react";
import { ColorInput, ValueRow, useColorField, useCopy } from "./ColorParts";
import { Icon } from "../common/Icon";
import {
  rgbToHsl,
  rgbToHsv,
  toCmykString,
  toHex,
  toHslString,
  toOklchString,
  toRgbString,
  type Rgb,
} from "../../lib/color";

/**
 * The interactive half of every colour conversion page.
 *
 * There are six of these pages and they share one surface, because the
 * arithmetic is the same in all of them and maintaining six copies of a
 * conversion is how one of them ends up wrong. What is *not* shared is the
 * writing: each page carries its own explanation, its own worked example and
 * its own questions, because a person searching "hex to rgb" and a person
 * searching "hsl to hex" want different sentences, and a template that gave
 * them the same paragraph with two words swapped would deserve to rank for
 * neither.
 */

export type Fmt = "hex" | "rgb" | "hsl" | "hsv" | "oklch" | "cmyk";

const LABEL: Record<Fmt, string> = {
  hex: "HEX",
  rgb: "RGB",
  hsl: "HSL",
  hsv: "HSV",
  oklch: "OKLCH",
  cmyk: "CMYK",
};

function render(color: Rgb, format: Fmt): string {
  switch (format) {
    case "hex":
      return toHex(color);
    case "rgb":
      return toRgbString(color);
    case "hsl":
      return toHslString(color);
    case "hsv": {
      const { h, s, v } = rgbToHsv(color);
      return `hsv(${Math.round(h)} ${s.toFixed(1)}% ${v.toFixed(1)}%)`;
    }
    case "oklch":
      return toOklchString(color);
    case "cmyk":
      return toCmykString(color);
  }
}

/**
 * The conversion, one step at a time.
 *
 * This is the part people came for on a page called "hex to rgb": not the
 * answer — a browser devtools panel gives them that — but *why* `ff` is 255.
 * Shown as three concrete lines with the actual digits, because an abstract
 * formula is exactly what they already failed to follow somewhere else.
 */
const Working: React.FC<{ color: Rgb; from: Fmt; to: Fmt }> = ({ color, from, to }) => {
  const r = Math.round(color.r);
  const g = Math.round(color.g);
  const b = Math.round(color.b);
  const hex = toHex(color, { alpha: "never" }).slice(1);
  const hsl = rgbToHsl(color);

  let lines: string[] = [];
  let caption = "";

  if (from === "hex" && (to === "rgb" || to === "hsl")) {
    caption = "Each pair of hex digits is one channel in base 16.";
    lines = [
      `${hex.slice(0, 2)}  →  ${parseInt(hex.slice(0, 2), 16)}   (${Number(`0x${hex[0]}`)} × 16 + ${Number(`0x${hex[1]}`)})`,
      `${hex.slice(2, 4)}  →  ${parseInt(hex.slice(2, 4), 16)}   (${Number(`0x${hex[2]}`)} × 16 + ${Number(`0x${hex[3]}`)})`,
      `${hex.slice(4, 6)}  →  ${parseInt(hex.slice(4, 6), 16)}   (${Number(`0x${hex[4]}`)} × 16 + ${Number(`0x${hex[5]}`)})`,
    ];
  } else if (to === "hex") {
    caption = "Each channel becomes two hex digits: the whole 16s, then the remainder.";
    lines = [
      `${String(r).padStart(3)}  →  ${hex.slice(0, 2)}   (${Math.floor(r / 16)} × 16 + ${r % 16})`,
      `${String(g).padStart(3)}  →  ${hex.slice(2, 4)}   (${Math.floor(g / 16)} × 16 + ${g % 16})`,
      `${String(b).padStart(3)}  →  ${hex.slice(4, 6)}   (${Math.floor(b / 16)} × 16 + ${b % 16})`,
    ];
  } else if (to === "hsl") {
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    caption = "HSL comes from the largest and smallest channel, and the gap between them.";
    lines = [
      `max ${max} / 255 = ${(max / 255).toFixed(3)}`,
      `min ${min} / 255 = ${(min / 255).toFixed(3)}`,
      `lightness = (max + min) / 2 = ${hsl.l.toFixed(1)}%`,
      `chroma = max − min = ${((max - min) / 255).toFixed(3)}  →  saturation ${hsl.s.toFixed(1)}%`,
    ];
  }

  if (lines.length === 0) return null;

  return (
    <div className="rounded-lg bg-surface-elevated p-5">
      <h3 className="text-[0.9375rem] font-semibold text-foreground">The arithmetic</h3>
      <p className="mt-1 text-sm text-foreground-muted">{caption}</p>
      <pre className="mt-3 overflow-x-auto font-mono text-sm leading-relaxed text-foreground-muted">
        {lines.join("\n")}
      </pre>
    </div>
  );
};

interface Props {
  from: Fmt;
  to: Fmt;
  /** Starting value, in the `from` syntax. */
  initial: string;
  /** Every format worth showing under the headline answer. */
  also?: Fmt[];
}

export const ColorConvertSurface: React.FC<Props> = ({
  from,
  to,
  initial,
  also = ["hex", "rgb", "hsl", "oklch"],
}) => {
  const field = useColorField("");
  const { copied, copy } = useCopy();
  const color = field.color;

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] lg:gap-12">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-foreground-muted">{LABEL[from]} input</span>
          <button
            type="button"
            onClick={() => field.setText(initial)}
            className="flex items-center gap-1 text-xs font-mono text-accent hover:text-accent cursor-pointer pointer-coarse:min-h-[44px]"
          >
            <Icon name="sparkles" size="sm" className="text-accent" />
            Try Example ({initial})
          </button>
        </div>
        <ColorInput
          label={`${LABEL[from]} value`}
          value={field.text}
          onChange={field.setText}
          parsed={color}
          placeholder={initial}
        />
        {color && (
          <div
            className="h-32 rounded-xl"
            style={{ backgroundColor: toHex(color) }}
            aria-label={`A swatch of ${toHex(color)}`}
            role="img"
          />
        )}
      </div>

      <div className="min-w-0 space-y-6">
        {color ? (
          <>
            <div className="rounded-xl bg-surface-elevated p-6">
              <p className="text-sm text-foreground-muted">{LABEL[to]}</p>
              <div className="mt-2 flex flex-wrap items-center gap-4">
                <code className="min-w-0 break-all font-mono text-2xl font-medium text-foreground sm:text-3xl">
                  {render(color, to)}
                </code>
                <button
                  type="button"
                  onClick={() => copy(render(color, to))}
                  className="ml-auto cursor-pointer rounded-pill bg-accent-solid px-5 py-2.5 text-sm font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  {copied === render(color, to) ? "Copied" : "Copy"}
                </button>
              </div>
            </div>

            <Working color={color} from={from} to={to} />

            <div>
              <h3 className="mb-1 text-[0.9375rem] font-semibold text-foreground">
                The same colour, every other way
              </h3>
              {also
                .filter((format) => format !== to)
                .map((format) => (
                  <ValueRow
                    key={format}
                    label={LABEL[format]}
                    value={render(color, format)}
                    copied={copied}
                    onCopy={copy}
                    note={
                      format === "cmyk" ? (
                        <span className="text-xs text-foreground-subtle">approximate</span>
                      ) : undefined
                    }
                  />
                ))}
            </div>
          </>
        ) : (
          <p className="rounded-xl bg-surface-elevated p-8 text-base text-foreground-muted">
            Enter a colour on the left. This accepts hex with or without the hash,{" "}
            <code className="font-mono text-foreground">rgb()</code>,{" "}
            <code className="font-mono text-foreground">hsl()</code>,{" "}
            <code className="font-mono text-foreground">oklch()</code> and the CSS colour names.
          </p>
        )}
      </div>
    </div>
  );
};
