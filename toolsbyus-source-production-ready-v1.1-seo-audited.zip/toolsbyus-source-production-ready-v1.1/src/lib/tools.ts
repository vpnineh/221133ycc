/**
 * Typed view of the tool catalogue.
 *
 * The data lives in `tools.data.mjs` as plain ESM so the build scripts can
 * import it without a transpile step — `scripts/generate-llms-txt.mjs` used to
 * keep its own copy of the page list, which is how a sitemap ends up listing a
 * URL that does not exist. This file adds the types and the derived views the
 * app uses; it adds no second source of truth.
 */
import type { IconName } from "../components/common/Icon";
import { CONTENT_LAST_REVIEWED } from "./site";
import {
  CATEGORIES as RAW_CATEGORIES,
  TOOLS as RAW_TOOLS,
  INFO_PAGES as RAW_INFO_PAGES,
  TOOL_GROUPS as RAW_TOOL_GROUPS,
  categoryLastReviewed as RAW_CATEGORY_LAST_REVIEWED,
} from "./tools.data.mjs";

export type ToolCategory =
  | "pdf"
  | "image"
  | "color"
  | "json"
  | "text"
  | "encode"
  | "generate";

export interface Category {
  id: ToolCategory;
  /** Short label for navigation. */
  label: string;
  /** Hub page route, e.g. `/json-tools`. */
  hub: string;
  /** Hub page `<h1>`. */
  title: string;
  /** One line under the hub heading and in the nav. */
  blurb: string;
}

export interface Tool {
  href: string;
  /** Short name used in navigation. */
  name: string;
  /** Full page title, used where there is room. */
  title: string;
  /** Badge shown in menus and on cards. */
  tag: string;
  /** One line describing what it does — also the palette's search text. */
  description: string;
  /** Extra search terms so the palette finds a tool by what it is called elsewhere. */
  keywords: string[];
  category: ToolCategory;
  /** Sub-heading within the category. */
  group: string;
  icon: IconName;
  /** Verb phrase for the card's action row: what pressing this actually does. */
  action: string;
  /** Omitted from nav, hubs, palette and sitemap while false. */
  published: boolean;
  /** Per-tool review date, emitted as JSON-LD `dateModified`. */
  lastReviewed: string;
}

export interface InfoPage {
  href: string;
  name: string;
  description: string;
  /** Feeds the sitemap's <lastmod> and the visible review stamp. */
  lastReviewed: string;
}

/**
 * Sitemap and llms.txt copy, in `tools.seo.mjs` rather than in the catalogue.
 *
 * Read only by the build script. It is typed here so the test that keeps the
 * two files in step can check it, and deliberately not re-exported as data:
 * importing it from a component would put several kilobytes of prose back into
 * the chunk every page loads, which is the whole reason it was moved out.
 */
export interface PageSeo {
  summary: string;
  priority: string;
  changefreq: string;
}

export const CATEGORIES = RAW_CATEGORIES as Category[];
export const TOOL_GROUPS = RAW_TOOL_GROUPS as string[];
export const INFO_PAGES = RAW_INFO_PAGES as InfoPage[];

/** Every catalogue entry, including ones not yet live. */
export const ALL_TOOLS = RAW_TOOLS as Tool[];

/**
 * Live tools. Everything user-facing and crawler-facing reads this: an entry
 * can sit in the catalogue with `published: false` while its page is being
 * written without appearing in the nav or the sitemap.
 */
export const TOOLS: Tool[] = ALL_TOOLS.filter((tool) => tool.published);

export const TOOL_COUNT = TOOLS.length;

/** Categories with at least one live tool, so no hub page is ever empty. */
export const ACTIVE_CATEGORIES: Category[] = CATEGORIES.filter((category) =>
  TOOLS.some((tool) => tool.category === category.id)
);

export function toolsInCategory(categoryId: ToolCategory): Tool[] {
  return TOOLS.filter((tool) => tool.category === categoryId);
}

/**
 * The review date a hub page should declare. Identical to the value the sitemap
 * publishes for that URL, because both call the same catalogue function.
 */
export function categoryLastReviewed(categoryId: ToolCategory): string | undefined {
  return RAW_CATEGORY_LAST_REVIEWED(categoryId);
}

/**
 * The review date for a page that carries no tool of its own — All Tools,
 * About, Privacy, Terms.
 *
 * `ReviewedStamp` already resolved the date this way for the visible line while
 * those same pages emitted JSON-LD with no `dateModified` at all, so a reader
 * saw a review date that no machine-readable node confirmed. Both now read this
 * function, and the visible date and the schema date cannot drift apart.
 */
export function infoPageLastReviewed(href: string): string {
  return INFO_PAGES.find((page) => page.href === href)?.lastReviewed ?? CONTENT_LAST_REVIEWED;
}

export function categoryOf(categoryId: ToolCategory): Category | undefined {
  return CATEGORIES.find((category) => category.id === categoryId);
}

export function toolByHref(href: string): Tool | undefined {
  return ALL_TOOLS.find((tool) => tool.href === href);
}

/** Live tools in a category, bucketed by group in catalogue order. */
export function groupedToolsInCategory(
  categoryId: ToolCategory
): Array<{ group: string; tools: Tool[] }> {
  const tools = toolsInCategory(categoryId);
  return TOOL_GROUPS.map((group) => ({
    group,
    tools: tools.filter((tool) => tool.group === group),
  })).filter((entry) => entry.tools.length > 0);
}

/** Every live tool bucketed by category, for the homepage index and the footer. */
export const TOOLS_BY_CATEGORY: Array<{ category: Category; tools: Tool[] }> =
  ACTIVE_CATEGORIES.map((category) => ({
    category,
    tools: toolsInCategory(category.id),
  }));

/**
 * Related tools chosen by proximity rather than round-robin: same group first,
 * then the rest of the category, then the flagship of each other category.
 * A page that links to four genuinely adjacent tools is worth more than one
 * that links to four arbitrary ones, and this keeps that true as the catalogue
 * grows without every page hand-maintaining its own list.
 */
export function relatedTools(href: string, limit = 4): Tool[] {
  const self = toolByHref(href);
  if (!self) return TOOLS.slice(0, limit);

  const sameGroup = TOOLS.filter(
    (t) => t.href !== href && t.category === self.category && t.group === self.group
  );
  const sameCategory = TOOLS.filter(
    (t) => t.href !== href && t.category === self.category && t.group !== self.group
  );
  const otherCategories = ACTIVE_CATEGORIES.filter((c) => c.id !== self.category)
    .map((c) => toolsInCategory(c.id)[0])
    .filter((t): t is Tool => Boolean(t));

  const seen = new Set<string>([href]);
  const out: Tool[] = [];
  for (const tool of [...sameGroup, ...sameCategory, ...otherCategories]) {
    if (seen.has(tool.href)) continue;
    seen.add(tool.href);
    out.push(tool);
    if (out.length === limit) break;
  }
  return out;
}
