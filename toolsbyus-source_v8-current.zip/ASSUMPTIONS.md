# Project Assumptions & Design Decisions — toolsbyus.com

This document records all decisions made during development, justifying design choices and dependency selection.

---

### 1. Numeric Equality (JSON Semantics)
- **Decision:** In standard JSON (RFC 8259) and JavaScript IEEE 754 float representation, `1.0` and `1` have identical numeric values (`1.0 === 1`). The semantic diff engine evaluates numbers by numeric value; thus `{"a": 1.0}` and `{"a": 1}` are semantically identical.
- **Rationale:** Semantic diffing compares parsed AST data structures, not raw text formatting. Any formatting differences (such as trailing zeros in floating-point representations) are captured by the text diff tool (`/diff-checker`) and the formatters.

### 2. Mobile Responsive Diff Viewport (375px / 768px / 1024px / 1440px)
- **Decision:** On screens below 768px (mobile devices), the default diff view automatically switches to a stacked / unified view with a segmented toggle to switch to side-by-side with horizontal scrolling.
- **Rationale:** Rendering two 50% split columns on a 375px display reduces readable code width to less than 150px per side (under 20 monospace characters), making code unreadable and causing severe text-wrapping bugs.

### 3. Font Selection (current)
- Geist and Geist Mono use `next/font/google`. Builds fetch fonts and emit same-origin assets; visitors do not fetch these fonts from Google.
- A clean build needs access to the font provider or a populated cache. Requests for fonts on the site's own origin are expected.

### 4. Zero Dependencies Policy (<200 lines)
- **Decision:** All core logic is hand-rolled in pure TypeScript without external runtime npm packages:
  - `src/lib/json/`: Hand-rolled iterative parser with exact line/column tracking, caret generation, and specific malformed syntax detection (BOM, smart quotes, trailing commas, unquoted keys, single quotes).
  - `src/lib/diff/`: Hand-rolled semantic diff engine, key-order normalization, configurable array matching (index, key, structural similarity), type change tagging, and subtree move detection.
  - `src/lib/diff/patch-rfc6902.ts`: Hand-rolled RFC 6902 JSON Patch export and apply with exact deep-equality roundtrip.
  - `src/lib/diff/merge-patch-rfc7386.ts`: Hand-rolled RFC 7386 JSON Merge Patch export.
  - `src/lib/diff/text-diff.ts`: Hand-rolled Myers diff algorithm for line, word, and character text diffs.
  - `src/lib/schema/`: Hand-rolled JSON Schema Draft 2020-12 inference and validator.
  - `src/lib/base64/`: Hand-rolled base64 standard & URL-safe encoder/decoder with UTF-8/UTF-16 support and JWT inspection.
  - `src/lib/uuid/`: Hand-rolled UUID v4 (`crypto.randomUUID`), v1 (timestamp/MAC imitation), and v7 (Unix millisecond timestamp + monotonic counter) generators and inspector.
- **Rationale:** Guarantees zero supply-chain risk, zero telemetry, minimal bundle size, and total control over memory limits.

#### 4a. Scoped Exception for Phase B File Tools
- **Decision:** The PDF and image tools may use vetted, permissively licensed, client-side-only libraries. A PDF cross-reference table or a JPEG entropy coder is not something to hand-roll: the correctness bar is a decade of edge cases in other people's documents, and a subtly wrong implementation corrupts a file the user cannot get back.
- **Conditions, all of which apply to every library admitted under this exception:**
  - Pinned to an exact version in `package.json` — no `^`, no `~`.
  - Loaded via dynamic `import()` inside the worker or the client component that needs it, never in the shared graph, so a person who only uses `/json-diff` never downloads a PDF parser.
  - Incapable of network access under the deployed CSP. `connect-src 'self'` is enforced by the generated `_headers` and verified by `scripts/verify-csp.mjs`; a library that tried to phone home would be blocked by the browser, not merely by policy.
  - Permissive licence (MIT, Apache-2.0, BSD) recorded below — with one documented exception, `libheif-js`, whose terms are set out with it.
- **Admitted libraries:**
  - `pdf-lib` (MIT) — structural PDF operations: merge, split, rotate, delete and reorder pages, watermark, image embedding. Pure JavaScript, no WASM.
  - `pdfjs-dist` (Apache-2.0) — rendering PDF pages to a canvas and extracting the text layer. Mozilla's own renderer, which is the same code Firefox ships.
  - `libheif-js` (**LGPL-3.0**) — decoding HEIC. The only library here that is not permissively licensed, and the only one admitted for something the browser genuinely cannot do rather than something it would do worse. HEIC wraps HEVC, whose decoders are patent-licensed; Safari ships one because Apple licenses HEVC for the whole OS, and Chrome and Firefox do not. Without this, `/heic-to-jpg` would fail for most of the people who open it, which is worse than not shipping the tool.
    - **Licence compliance:** used entirely unmodified, at a pinned version, loaded as its own chunk via dynamic `import()` — LGPL §4's separate-and-replaceable condition, which is the clause that makes an LGPL library usable here at all. The upstream source is <https://github.com/catdad-experiments/libheif-js> and the licence text ships inside the package. Nothing in this repository is derived from it.
    - **Cost containment:** the import fires only after `createImageBitmap` has already refused a file *and* its `ftyp` box says HEIF, so a visitor converting a JPEG never fetches it, a Safari user never fetches it, and `scripts/check-bundle-size.mjs` asserts it is not in the graph any page loads. Measured: 0 of 69 exported pages reference the chunk.
    - **Build used:** `libheif-wasm/libheif-bundle.mjs`, which carries its WebAssembly inline as base64. No second request and no `.wasm` asset to place correctly in a static export; compiling from memory is permitted by the site's `script-src 'wasm-unsafe-eval'`, where a fetched binary would have to survive `connect-src 'self'`.
- **What the exception does not cover:** the zero-dependency rule continues to apply in full to `src/lib/json`, `src/lib/diff`, `src/lib/schema`, `src/lib/base64`, `src/lib/uuid`, `src/lib/yaml`, `src/lib/xml`, `src/lib/csv`, `src/lib/codegen`, `src/lib/qr`, `src/lib/hash`, `src/lib/cron`, `src/lib/format` and `src/lib/images`. Everything a developer tool does is still hand-rolled, including the QR encoder's Reed–Solomon and the MD5 that SubtleCrypto refuses to provide. The image tools deliberately decline the obvious dependency: the `@jsquash/*` WASM codecs are excellent and are megabytes, and the browser already contains JPEG, PNG and WebP codecs written in C with hardware acceleration. `src/lib/images/index.ts` uses those instead, and the one format they cannot handle is the one exception above.
- **Rationale:** A documented, bounded exception is honest. Silently breaking a stated policy — or, worse, keeping the policy and shipping a hand-rolled PDF parser that mangles a contract — is not.

### 5. Web Worker Lifecycle & LCP Protection
- **Decision:** The Web Worker (`src/workers/diff.worker.ts`) is instantiated asynchronously inside the browser environment after the component mounts.
- **Rationale:** In Next.js static export (`output: 'export'`), worker scripts must not run during static pre-rendering, and worker initialization must not block initial paint or Largest Contentful Paint (LCP).

### 6. Storage & Settings Persistence
- **Decision:** Only theme preference (`dark` | `light`) and tool configuration settings (e.g. array match mode, indent size) are stored in `localStorage`. User payload content is never stored in any persistent storage or URL query parameters.
- **Rationale:** Fulfills Section 6 ("Privacy is the product").
