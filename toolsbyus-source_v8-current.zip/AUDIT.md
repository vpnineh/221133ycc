# Historical production readiness audit

See `RELEASE-v8.md` for the current revision. Earlier claims and findings below
are retained as project history and were not all reverified in this revision.

Review of three candidate codebases for toolsbyus.com, selection of one, and
the defects fixed to bring it to a shippable state.

Date: 2026-09-09

---

## 1. Which source was chosen

Three builds were supplied.

| | **YCD 3.8 v1.1** (chosen) | YCD 3.1pro v1.1 | toolsbyus-qwencoder v1.1 |
| --- | --- | --- | --- |
| Framework | Next.js App Router, static export | Next.js App Router, static export | Vite SPA + React Router |
| HTML for crawlers | Full page prerendered | Full page prerendered | **Empty `<div id="root">`** |
| Per-page title / description / canonical | Yes | Yes | **No — one shared title for all 14 routes** |
| Structured data | `@graph` with Org, WebSite, WebPage, WebApplication, Breadcrumb, FAQ | Same | Partial, no FAQPage |
| JSON parser | Hand-written iterative RFC 8259 scanner with line/column | Same | **Regex heuristics over raw text** |
| Web Worker | Real (`src/workers/diff.worker.ts`) | Real | **Claimed in copy, does not exist** |
| Tests | 42 unit + 4 e2e suites | Same | **None** |
| Source size | ~11k lines | ~11k lines | ~7k lines |
| Dependencies | 3 runtime | 3 runtime | 16 runtime, **13 never imported** |

**YCD 3.8 was chosen.** It and 3.1pro share an identical library layer and page
structure; the only differences are UI-level, and 3.8 is a strict superset —
drag-and-drop file loading, word-wrap toggle, a Prettify action, clearer copy
feedback, custom scrollbars. Nothing in 3.1pro was missing from it.

The Vite SPA was not competitive for a content-and-SEO-driven tool site:

- **Crawlers see an empty page.** No SSR or prerendering, so the served HTML is a
  bare mount point. Google can render JS, but most AI crawlers (GPTBot,
  ClaudeBot, PerplexityBot) do not — the entire GEO surface would be zero.
- **No per-route metadata.** Every one of its 14 routes shipped the same
  `<title>`, description and canonical, so they compete with each other.
- **Its JSON engine gives wrong answers.** The parser scans with regexes rather
  than parsing: smart-quote detection is not string-aware, so a legitimate
  curly quote inside a string value is reported as invalid JSON; duplicate-key
  detection matches `"key":` anywhere in the text, so `[{"id":1},{"id":2}]`
  is falsely reported as having a duplicate key.
- **Its copy describes software that isn't there.** The FAQ states processing
  runs in a Web Worker; there is no worker in the codebase.
- **13 unused runtime dependencies**, including `@supabase/supabase-js` — a
  backend SDK on a site whose entire promise is having no backend. Dead weight
  and unnecessary supply-chain surface.

---

## 2. Defects found and fixed in the chosen source

Everything below reproduced against the shipped code. Each has a regression test.

### Security

**Prototype pollution via JSON Patch — exploitable.**
`applyJsonPatch` walked pointer segments with unguarded bracket access, so a
pasted patch of `[{"op":"add","path":"/__proto__/x","value":"y"}]` — or the
`constructor/prototype` variant, which was also confirmed — wrote to
`Object.prototype` and corrupted every object in the page.
*Fixed:* `src/lib/safe-object.ts` centralizes the guards; unsafe pointer
segments are rejected at parse time, and every write goes through
`Object.defineProperty` rather than bracket assignment.

**Crash on `__proto__` in schema inference.**
`inferSchemaFromSamples` accumulated keys in object literals, so a payload
containing `"__proto__"` read back `Object.prototype` and threw
`TypeError: keyValues[k].push is not a function`.
*Fixed:* accumulators are `Map`s.

**A Content-Security-Policy that would have blanked the site.**
No CSP existed. The first version added one — and it would have blocked Next's
own inline RSC bootstrap scripts, rendering a white page in production while
passing every local check.
*Fixed:* `scripts/generate-csp.mjs` runs *after* `next build`, hashes the inline
scripts the export actually contains, and `scripts/verify-csp.mjs` fails the
build if any would be blocked. `script-src` is a hash allowlist with no
`'unsafe-inline'`. `connect-src 'self'` makes the privacy claim enforceable by
the browser rather than merely asserted.

**Build errors were suppressed.**
`next.config.ts` set `typescript.ignoreBuildErrors` and
`eslint.ignoreDuringBuilds` to `true`, so the build shipped whatever compiled.
*Fixed:* both removed; the build fails on a real error.

**Dependency vulnerabilities: 7 (1 critical, 2 high) → 0.**
Next 15 → 16 and Vitest 2 → 5. Both clean-built and pass the full suite.

**JSON-LD injection surface.** `JSON.stringify` output was written into a
`<script>` via `dangerouslySetInnerHTML` with no escaping, so a `</script>` in
any future dynamic field would break out of the element.
*Fixed:* `<`, `>`, `&` are escaped as unicode sequences.

### Correctness

**The validator accepted invalid JSON.** `{"a":1} {"b":2}` parsed successfully,
silently discarding the second document. RFC 8259 allows exactly one top-level
value — and this is a validator.
*Fixed:* trailing content is rejected with position information.

**The parser dropped `__proto__` keys.** `{"__proto__": 1, "a": 2}` parsed to
`{a: 2}` — different from `JSON.parse`, and silent data loss.

**`required` was satisfied from the prototype chain.** Schema validation used
`key in obj`, so `required: ["toString"]` passed against every object.

**Format validation false-negatives.** Validation asked "what format does this
string look like?" and compared to the declared one, so a valid `date` failed
because the detector reported `date-time` first.
*Fixed:* per-format predicates; the schema's named format is checked directly.

**`enum` used reference equality**, so object members never matched. Now deep.

**Schema validation covered ~15% of Draft 2020-12** while the pages advertised
full compliance. Added `minLength`/`maxLength`/`pattern`, the numeric bounds and
`multipleOf`, `minItems`/`maxItems`/`uniqueItems`/`prefixItems`,
`additionalProperties`, `patternProperties`, `minProperties`/`maxProperties`,
`dependentRequired`, `const`, and the `allOf`/`anyOf`/`oneOf`/`not` combinators.
Remaining gaps (`$ref`, remote schemas) are now stated in README and `llms.txt`
rather than implied away.

**Type widening discarded structure.** `[{"a":1}, null]` inferred
`{"type":["null","object"]}` with the object's properties thrown away.

**Base64 rejected line-wrapped input** — i.e. MIME, PEM, and anything copied out
of a terminal — because `atob` throws on embedded newlines.

**Base64 UTF-16LE overflowed the stack** on inputs over ~100k characters:
`String.fromCharCode(...units)` spreads every code unit as an argument.
*Fixed:* chunked conversion, plus alphabet and padding validation with real
error messages.

**RFC 6902 conformance:** `copy`/`move` from a non-existent path silently
inserted `undefined`; `replace` created missing members; array indices accepted
leading zeros; `move` into its own subtree was permitted; `remove`/`move` on the
document root fell through to undefined behaviour. All now rejected per spec.

**The diff worker could hang the UI forever.** No `onerror`, no
`onmessageerror`, no timeout, and a module worker blocked by CSP fails
*asynchronously* — so the constructor's `try/catch` never fired and the fallback
never ran. A blocked worker left the page on "processing" permanently.
*Fixed:* error and timeout handling, automatic fallback to main-thread
computation, and a run counter so a superseded run's late reply is ignored.

### Performance

**The diff engine was O(depth²).** Each node copied its full path array and
re-serialized its JSON Pointer, so work grew quadratically with nesting: 8,000
levels took **4.1 seconds**.
*Fixed:* nodes carry `key` + `depth` and an incrementally-built pointer.
**8,000 levels now takes 11ms** — a ~375× improvement, and linear. A scaling
test guards it.

**Move detection was O(removed × added × subtree size)**, deep-comparing every
combination. Now bucketed by a canonical key, with the deep compare only
confirming a bucket hit.

**Similarity array matching had no bound** — an unbounded quadratic pass with a
deep comparison inside. Now falls back to index matching past 400×400.

**The editor allocated hundreds of megabytes per keystroke.** `CodePane`
computed `new TextEncoder().encode(value)` and `value.split("\n")` on every
render, uncached, with two panes per page. On a multi-megabyte document this was
the dominant cost of the UI locking up.
*Fixed:* allocation-free counting, memoized.

**A documented limit that did not exist.** The beautifier's reference table
advertised a "50 MB memory ceiling"; no such check was in the code, and pasting
a large file simply froze the tab. Measurement showed 20 MB takes ~16s and 60 MB
~49s in a controlled `<textarea>` — 50 MB was never achievable.
*Fixed:* `src/lib/limits.ts` enforces a measured **8 MB** ceiling on main-thread
tools with a clear refusal, a caution above 2 MB, and `useDeferredValue` so
typing stays responsive. The documented figure now matches the enforced one.

### SEO

- **Tool pages had no `og:image`.** Next replaces rather than merges
  `openGraph`, so every page that set its own title dropped the layout's image —
  `twitter:card` was `summary_large_image` with no image to show.
- **No favicon, icons, or OG image existed at all**, and the Organization
  JSON-LD pointed `logo` at `/icon.svg`, which 404'd. Generated a real
  1200×630 PNG card plus SVG and PNG icons and a web manifest.
- **Duplicate `<meta name="viewport">`** on every page.
- **The 404 rendered two `<header>` and two `<footer>` landmarks**, carried the
  site's root title, and set a canonical pointing at the homepage.
- **Titles double-suffixed** the brand once a title template was added; all 14
  rewritten to fit within the ~60-character SERP limit.
- **The origin was hard-coded in 18 places** across pages, JSON-LD and the
  sitemap, and had already drifted (`…com` vs `…com/`). Centralized in
  `src/lib/site.ts`, overridable via `NEXT_PUBLIC_SITE_URL`.
- **`ads.txt` declared `pub-0000000000000000`** — an authorised seller that does
  not exist. Now generated only when a real publisher ID is configured.

### GEO (AI answer engines)

- **Four of every five FAQ answers were invisible to crawlers.** The accordion
  rendered only the expanded item, so a statically exported page shipped one
  answer and hid the rest behind hydration — precisely the content an AI crawler
  that does not execute JavaScript would want. Rebuilt on `<details>`: every
  answer is in the served HTML, and it is keyboard accessible without JS.
- **`llms.txt` rewritten** for retrieval: what the site is, the standards it
  implements, the privacy guarantees and *how they are enforced*, plus an
  explicit "known limits" section. A retrieval system can lift a correct,
  attributable answer from it.
- **`robots.txt`** now names 18 AI crawlers explicitly rather than four.

### Accessibility

- **The "All Tools" menu was unreachable by keyboard** — CSS `:hover` only, with
  an `aria-haspopup` and nothing behind it (WCAG 2.1.1). Rebuilt as a real
  disclosure: click/Enter toggles, Escape closes and restores focus, outside
  click and focus-out close it, with correct `aria-expanded`/`aria-controls`.
- **No skip link** on any page (WCAG 2.4.1). Added as the first focusable
  element.
- The theme toggle rendered a placeholder narrower than the real button, shifting
  the header on hydration; it also mirrored DOM state into `useState` inside an
  effect. Rewritten with `useSyncExternalStore`, which is the correct primitive
  for reading external state without a hydration flash, plus `aria-pressed` and
  OS-preference following.
- Mobile nav given a labelled `<nav>` landmark, list semantics and
  `aria-expanded`.

### Correctness of claims (E-E-A-T)

- The homepage said **"every operation executes in isolated Web Workers"**. Only
  the JSON diff uses a worker; the other nine tools run on the main thread.
- The minifier presented an **entropy heuristic as a gzip measurement**
  ("Fast and accurate LZ77 + Huffman"). Replaced with the browser's native
  `CompressionStream('gzip')` — a real measurement — falling back to the
  heuristic only where the API is absent, with the label saying which is shown.
- The privacy policy stated the site **displays Google AdSense**. It does not:
  ads are opt-in and disabled by default. The policy now says so, documents what
  turning them on would require (disclosure and EU/UK consent), and explains how
  the CSP makes the no-egress claim verifiable.
- `AdSlot` never called `adsbygoogle.push({})`, so even with an ID configured the
  unit could never fill.

### React correctness

- **The UUID page had a guaranteed hydration mismatch (React #418).** The first
  batch was generated in a `useState` initializer, which runs during the static
  prerender *and* again on the client — different values every time. It also
  baked one fixed set of UUIDs into the HTML that every visitor saw first.
- `Date.now()` was called during render on the Base64 page (impure render).
- The JSON editor derived its parse result in an effect, rendering twice per
  keystroke; moved to `useMemo`, preserving the "keep the last valid tree while
  mid-edit" behaviour the page's FAQ promises.

---

## 3. Verification

| Gate | Result |
| --- | --- |
| `tsc --noEmit` | 0 errors |
| `eslint .` | 0 errors, 0 warnings |
| `npm audit` | 0 vulnerabilities |
| Unit tests | 83 passing (was 42) |
| End-to-end tests | 27 passing (was 17) |
| `next build` | Succeeds with type checking and linting enabled |
| CSP verification | All 48 inline scripts across 16 pages allowed |

End-to-end tests run against the real static export served **with the production
security headers applied**, so the CSP is exercised rather than assumed. Every
page is checked for CSP violations, console errors and hydration failures.

---

# Round two: UI/UX, features, and GEO

A second pass focused on what a developer actually experiences, driven by the
GEO criteria from the installed `seo-geo` skill and by measuring the built site
rather than reading it.

## Mobile was broken, not merely cramped

Measured at 390px on a touch device:

- **The "Copy" button sat entirely off the right edge of the pane** and "Clear"
  was clipped. Both were inside an `overflow-hidden` container, so they were not
  even reachable by scrolling — the controls simply did not exist on a phone.
  Page-level overflow checks had reported "ok", which is why this survived: the
  clipping was internal.
- **All 10 editor buttons were 26px tall**, against the 44px touch-target
  minimum (WCAG 2.5.5).

Fixed by letting the toolbar wrap and adding a `pointer-coarse` Tailwind variant
— targeting the *input device* rather than viewport width, since a touchscreen
laptop needs the larger target and a narrow desktop window does not. Verified:
0 clipped, 0 off-screen, 0 under 44px.

## Features a developer would choose the site for

**One-click JSON repair.** The validator already classified faults precisely —
trailing comma, single quotes, unquoted key, smart quotes, BOM, Python literals
— and then left the developer to fix them by hand. That diagnosis is now
actionable: a preview of every change, then apply.

The implementation is a tokenizer, not a set of regexes, and the reason is
recorded in the file: a comma inside `"a, b"` is data while the same character
before `}` is a syntax error, and `//` inside `'https://x.dev'` is a URL. My
first attempt *was* a pass pipeline and it corrupted exactly that input — comment
stripping ran before quote normalization, so `//path` inside a single-quoted
string was eaten. Repair now tokenizes once into a loose JSON superset, and
every decision is made about tokens where context is unambiguous. Nothing is
reported as repaired unless the real parser accepts the output.

Covered by 22 tests including 600 property-based cases: 300 valid documents must
come back byte-identical, and 300 deliberately broken ones must round-trip to the
original value.

**Command palette (⌘K / Ctrl+K, or `/`).** Ten tools is more than a nav bar
holds, and a developer who knows where they are going should not reach for the
mouse. Fuzzy-ranked, keyboard-driven, with a visible header trigger so it is
discoverable without knowing the shortcut.

Ranking took two corrections, both found by testing rather than assumption:
a linear score with a word-boundary bonus ranked "JSON Minifier" above "JSON
Schema Generator" for `schm`, so contiguous runs are now scored quadratically;
and a scattered match on a *name* beat a literal match in *keywords*, so
substring hits now take precedence. 11 of 12 probe queries rank as intended; the
twelfth (`diff` → "Diff Checker" before "JSON Diff") is a prefix match and
defensible, so the scorer was left alone rather than over-fitted.

## GEO, measured before and after

| Criterion | Before | After |
| --- | --- | --- |
| Question-form H2 headings across the 10 tool pages | **0** | **21** |
| Pages skipping a heading level | 3 | 0 |
| Pages with a direct-answer block | 7 of 10 | 10 of 10 |
| Headings leaking a literal `#` into extracted text | all | 0 |
| `datePublished` in JSON-LD | absent | present |

Three pages (`json-formatter`, `base64-decode`, `uuid-generator`) did not use
`ToolShell`: they marked their tagline up as an `<h2>` and then jumped to `<h3>`
for real sections, so the document outline was wrong and they carried no direct
answer. The decorative `#` beside each heading was a real `<span>`, which meant
the extracted text read "# How It Works" — it is now a CSS pseudo-element and
outside the text entirely.

## Consistency

The tool list existed in four places — header, footer, homepage grid and the
crawler-file generator — and had already drifted, with a hard-coded "All Tools
(10)" and "10 / 10 Offline Capable" next to independently maintained arrays.
There is now one catalogue in `src/lib/tools.ts` that all of them read.

## Round two verification

| Gate | Result |
| --- | --- |
| `tsc --noEmit` | 0 errors |
| `eslint .` | 0 errors, 0 warnings |
| `npm audit` | 0 vulnerabilities |
| Unit tests | **105** passing (was 83) |
| End-to-end tests | **33** passing (was 27) |
| CSP verification | all 48 inline scripts allowed |

The React compiler's lint rules caught three genuine render-purity bugs in the
new palette during this round — a mutated variable during render, and ref reads
reachable from render — all fixed rather than suppressed.

## 4. Left undone

- `src/lib/diff/three-way-diff.ts` is exported from the diff barrel but imported
  by nothing, has no tests, and still uses the recursive path-copying pattern
  removed elsewhere. It is tree-shaken out of the bundle. It should either get
  tests and the same treatment, or be deleted.
- The remaining `any` usages are confined to the JSON-traversal internals, where
  values genuinely are dynamically typed and are narrowed at runtime. The ESLint
  rule is scoped off for exactly those files and enforced everywhere else.
- Ads remain disabled. Enabling them is a deliberate three-step process
  documented in the README; do not just set the environment variable.

---

# Round three: the UI/UX rewrite

The brief for this round was blunt — the interface was rejected outright and had
to be rewritten, using the installed `ui-ux-pro-max` design intelligence, for an
audience that is almost entirely developers; then, mid-round, an explicit
constraint: no heavy animation, no `backdrop-filter`, nothing that makes the
page heavy.

The design-system query
(`"developer tool json debugging minimal" --design-system --variance 3 --motion 2
--density 8`) returned Minimalism/Swiss, a dense 8-step spacing scale, subtle
motion, and a mono+sans type split. That is the direction implemented below,
with one deliberate departure recorded at the end.

## What was actually wrong

The screenshot that opened the round showed three defects at once, and looking
for their causes found several more that were invisible on screen.

### Nav labels wrapped mid-phrase

"JSON Diff" rendered as "JSON" over "Diff". The header carried four promoted
tools *and* an All-Tools menu *and* a 420px privacy pill in one row. Fixed by
promoting one tool, moving the rest into a grouped disclosure, and shrinking the
pill to a two-word chip; every label now carries `whitespace-nowrap`. Guarded by
a test that measures rendered label height against its line box at five widths.

### The same guarantee was stated twice, ten pixels apart

The full-sentence privacy badge rendered in the header *and* again in the page
hero. Two copies of one claim read as marketing rather than as a guarantee. The
header chip now appears from `lg` up and the in-page badge below it — exactly
one is visible at any width. Verified by deliberately reintroducing the
duplicate and watching the new test fail (`1024px renders 2 privacy badges`).

### Every paragraph was monospace

Including the explanations, the FAQ answers, and all of `/about`, `/privacy` and
`/terms`, which set `font-mono` on the whole page. Monospace is slower to read
at body size and flattened the distinction between what the page *says* and what
the payload *says*. Type is now split by job.

### 74 utility classes had never done anything

Tailwind 3 cannot compute an alpha from `var(--surface)`, so every
`bg-surface/75`, `border-border/60` and `bg-background/90` in the codebase was
silently dropped at build time. Among them was the sticky header's own
background: it had **no** background colour, only `backdrop-blur`, so page
content scrolled visibly underneath it. Removing the blur — which the brief
asked for anyway — would have made that worse, not better, without also giving
the header a real surface.

### The typography plugin was never installed

`prose prose-slate dark:prose-invert max-w-none` appeared on the long-form
sections of three pages. `@tailwindcss/typography` is not a dependency, so those
classes styled nothing — except `max-w-none`, which is a real utility, and which
switched *off* the measure. The result was 1400px-wide paragraphs on a desktop
monitor.

### "Home / Home / Privacy Policy"

Six pages passed a `Home` crumb into a `Breadcrumb` that already renders one
unconditionally. Fixed in the component so both calling conventions work.

### Contrast the redesign itself got wrong

`tests/unit/design-tokens.test.ts` was written to check the new palette and
immediately failed on three of its own tokens: `--text-subtle` reached only
4.16:1 (light) and 4.43:1 (dark) against `--surface-2` — which is precisely
where it is used most, in status bars, gutters and table headers — and
`--border-strong`, the hover boundary on every control, sat at 1.49:1 on white.
All three token values were changed. This is the class of defect that is
invisible to a human eye reviewing screenshots and to every other test in the
suite.

### An accessible-name regression introduced mid-round

The rewritten pane toolbar hid its button labels below `sm` with `hidden`,
leaving five controls on a phone with no accessible name at all. Changed to
`sr-only sm:not-sr-only` so the name stays in the DOM at every width. The
touch-target minimum, briefly lowered to 36px, was restored to the site's own
44px standard after the existing mobile test caught it.

## What was rebuilt

| Surface | Before | After |
| --- | --- | --- |
| Homepage | Centred marketing hero, one flat 10-card grid | Claim on the left, a static worked example of a semantic diff on the right, then a tool index grouped by the four jobs a developer arrives wanting to do |
| Header | 64px, blurred, wrapping | 56px, solid, grouped Tools disclosure, non-wrapping |
| Code pane | Textarea + text-button row | Line-number gutter synced to scroll, live `Ln/Col`, Tab-to-indent with block indent/outdent and an `Esc`-then-`Tab` escape hatch, undo-preserving edits, jump-to-error-line |
| Diff list | Click-only rows | Arrow/Home/End navigation on one composite tab stop, five per-theme hues, glyph + word alongside every colour |
| Modals | `alert()` for two failure paths | `Notice`, an inline status/alert component |
| Tool pages | Full-width mono prose | 68-character sans measure, mono chrome |

`Icon.tsx` replaced every ad-hoc inline SVG and two glyphs-as-icons (`⚡`, `✕`)
with one set on a single 24px grid at a single 1.5 stroke — and deliberately not
with an icon package, which would ship thousands of glyphs to use twenty.

## Weight, measured

The brief asked for a light site, so the numbers are the point:

| | Before | After |
| --- | --- | --- |
| CSS (raw) | 36,899 B | 34,067 B |
| CSS (gzip) | — | 7,236 B |
| Homepage HTML (gzip) | 9,509 B | 15,944 B |
| Web fonts | 0 B | 31,340 B (one file, `display: swap`) |
| First-load JS (gzip) | ~183 KB | ~183 KB — unchanged |

The HTML grew because the homepage now carries a real tool index and a worked
example instead of three sentences. JS did not move: no runtime dependency was
added, and the icon set is inline SVG.

The one font is the deliberate departure from the design-system output, which
recommended pairing JetBrains Mono with IBM Plex Sans. Measured, that pairing
cost **40,240 B** of additional woff2 on the critical path of every page — more
than the mono itself — to replace San Francisco, Segoe UI and Roboto with a face
of comparable quality. The split that carries the readability win is mono for
code and sans for prose; the platform delivers the sans half for nothing.

`backdrop-filter`, `@keyframes`, running `animation`, hover transforms and glow
shadows are all gone, and an e2e test greps the shipped stylesheet to keep them
gone.

## Round three verification

- 155 unit tests (50 of them new, on the token contrast arithmetic)
- 39 Playwright tests (6 new, on nav wrapping, badge duplication, CSS paint
  budget, font origin, breadcrumbs and gutter alignment)
- `tsc --noEmit`: 0 errors. `eslint .`: 0 problems. `npm audit`: 0 vulnerabilities
- CSP regenerated and verified across all 48 inline scripts on 16 pages
- The zero-network privacy gate still passes, confirming the self-hosted font
  introduces no third-party request

### The badge rule, applied consistently

Widening the duplicate-badge test from one route to four found the same defect
on six more pages: `/about`, `/privacy`, `/terms`, `/uuid-generator`,
`/base64-decode` and `/json-formatter` each render their own badge outside
`ToolShell`, and the homepage showed the header chip alongside its own
full-sentence hero badge. The rule is now uniform — the header chip appears from
`lg` up and everywhere except the homepage, which leads with the full sentence;
the in-page badge appears below `lg`. Exactly one is visible on every route at
every width, and the test checks four routes at four widths.

---

## Phase B: file tools

The spec asked for PDF and image tools, which is a different kind of work from
everything before it. A JSON tool that is subtly wrong shows you the wrong
output. A file tool that is subtly wrong hands back a document that opens in one
reader and not another, or a photograph that is quietly the wrong colour, and
the user often finds out much later.

### What was built

Twelve PDF tools and six image tools, plus two category hubs. The PDF work runs
in a Web Worker with `pdf-lib` for structural edits and `pdf.js` for rendering
and text extraction. The image work uses no library at all: the browser already
contains JPEG, PNG and WebP codecs written in C with hardware acceleration, and
shipping WebAssembly copies of them would cost every visitor several seconds of
download to do the same job worse.

### Defects found in this phase's own code, before shipping

- **`removePage` does not remove a page's content.** The first delete-pages
  implementation took the page out of the page tree, which leaves its text in
  the file for any extractor to find. The page copy said "really gone" and the
  code did not deliver it. The `delete` case was removed from the worker
  entirely; deletion now copies the survivors into a new document, which is the
  only version that matches the claim.

- **Transparency encoded as black.** A fresh canvas is transparent and JPEG has
  no alpha channel, so converting a transparent PNG to JPEG produced a black
  rectangle. Fixed by painting a background first, with the colour exposed as a
  control rather than hard-coded white — a logo built for a dark site needs a
  dark background, and white would be just as wrong.

- **Aliasing on large reductions.** The first resize drew straight from source to
  target, which samples a handful of source pixels per destination pixel and
  ignores the rest. Replaced with repeated halving.

- **Portrait photos came out sideways.** `createImageBitmap` ignores the EXIF
  orientation tag unless asked to honour it.

- **Page size derived from pixels.** Rebuilding a PDF from page images rendered
  at 150 DPI produced seventeen-inch pages, because the page box was taken from
  the pixel count instead of the original point box.

- **React error #185 in production only.** `useNow` passed an inline `subscribe`
  to `useSyncExternalStore` that also notified synchronously, so React
  resubscribed forever. Rewritten as a module-level store.

### Two claims that were checked rather than asserted

**"Nothing is uploaded."** The e2e suite fails if any request carries a body
while a PDF merge or an image conversion runs. It also asserts that the 2 MB
HEIC decoder is not fetched by a tool that does not need it, since two megabytes
nobody asked for is its own kind of broken promise.

**"The conversion is correct."** The image tests generate their own PNGs with a
hand-rolled encoder, drive the real UI, and read the downloaded result back into
a canvas to sample actual pixels — that a transparent PNG converted to JPG is
white and not black, that a crop takes the region it was asked for, that a 20×
reduction preserves a gradient rather than flattening it. The PDF tests parse
the downloaded document back and check page counts, rotation angles and page
geometry in points.

### The dependency decision, stated plainly

`libheif-js` is LGPL-3.0 — the only non-permissive dependency in the project.
HEIC wraps HEVC, whose decoders are patent-licensed, and Chrome and Firefox
refuse to ship one. The choice for a HEIC converter was a real decoder or a page
that fails for most of the people who open it, and a tool that fails for most of
its visitors is worse than no tool. It is used unmodified, pinned, dynamically
linked, documented in `ASSUMPTIONS.md` §4a with its licence terms and upstream
source, and verified absent from the chunk every page loads: 0 of 70 exported
pages reference it.

### What is not covered by tests, and why

**HEIC decoding itself.** No HEIC encoder exists in this build environment, so
there is no way to generate a fixture to decode. Network access to fetch a
sample is restricted. What *is* tested is the container sniffing — an `ftyp` box
is a header rather than an image, so it can be constructed by hand — and that is
also where the interesting mistakes are, since the decision to download a
two-megabyte decoder hangs on it. The decode path is written against libheif's
documented API and its own type declarations, and is exercised manually, but it
is not in CI. Saying so here is more useful than a test that mocks the decoder
and proves nothing.

**AVIF encoding.** Feature-detected at runtime by encoding a 1×1 image, because
availability differs by browser and has changed twice. The detection is tested;
the encode is only tested where the test browser supports it.

### A footgun fixed in the harness

`scripts/serve-static.mjs` read `out/_headers` once at startup. Playwright is
configured with `reuseExistingServer: true`, so a run after a rebuild served the
*previous* build's CSP hash list — which does not fail loudly. It blocks Next's
hydration script, React never attaches, and every test times out waiting for a
control that the static HTML is already displaying. Nothing in the output
mentions CSP; it takes a browser console to find. The file is now re-read when
its mtime changes.

### Weight

Eight tools were added while the shared bundle went *down*, from 188.3 KB to
184.9 KB gzipped. Sitemap `priority`, `changefreq` and the llms.txt `summary`
moved out of the tool catalogue into `tools.seo.mjs`: nothing in the browser had
ever read them, but the catalogue is imported by the header, footer and command
palette, so several kilobytes of prose were downloaded by every visitor to
render a menu that never displays it. A test asserts the two files list the same
hrefs in both directions, so the split cannot drift into a sitemap that 404s.
The budget was tightened from 190 KB to 186 KB to keep catching growth.

### Phase B verification

- 809 unit tests, 179 Playwright tests, all passing
- `tsc --noEmit`: 0 errors. `eslint .`: 0 problems
- CSP regenerated and verified across 212 inline scripts on 70 pages
- Shared JS 184.9 KB gzip against a 186 KB budget; largest route-only payload
  23.9 KB against a 120 KB budget
- 58 published tools, and the sitemap, `llms.txt` and every rendered route
  derived from one catalogue that the suite checks against what is actually
  served
