# ToolsByUs

Browser-based tools for JSON, text, PDF, images and colors. The current catalogue
contains 71 tools in seven categories. Processing runs locally in the browser,
without an application backend. Ads and analytics are optional build settings
and disabled by default; authorized third-party scripts require separate review.

See `RELEASE-v8.md` for the current changes, validation results and remaining
browser checks. `AUDIT.md` records earlier project history.

| Category | Tools | Examples |
| --- | --- | --- |
| PDF | 11 | Merge, split, rotate, compress, PDF ↔ image |
| Image | 6 | Compress, resize, convert, crop, HEIC, Base64 |
| Color | 12 | Picker, conversion, contrast, wheel, gradients |
| JSON | 19 | Formatter, validator, diff, schema, code generators |
| Text | 12 | Diff, formatters, case conversion, XML and YAML |
| Encode | 4 | Base64, JWT inspection, URL encoding, hashes |
| Generate | 7 | UUID, lorem ipsum, cron, QR, barcode, timestamps, number bases |

## For the impatient

- **⌘K / Ctrl+K** (or `/`) opens the command palette from any page — fuzzy
  search across every tool.
- **Paste broken JSON** into the validator or beautifier and press **Fix it**.
  Trailing commas, single quotes, bare keys, smart quotes, JSONC comments and
  Python literals are repaired in one step, with every change shown first.
- Drop a file anywhere on a page that accepts files. In two-input tools, the
  focused input receives it; dropping directly on a pane targets that pane.

## Stack

| Concern | Choice |
| --- | --- |
| Framework | Next.js 16 (App Router), `output: "export"` |
| UI | React 19, Tailwind CSS 3 |
| Type | Geist and Geist Mono, fetched at build time and served from the site by `next/font` |
| Icons | Hand-drawn inline SVG set (`components/common/Icon.tsx`) — no icon package |
| Language | TypeScript, `strict: true` |
| Unit tests | Vitest |
| Browser tests | Playwright |
| Output | Pre-rendered static HTML — deployable to any static host |
| Runtime dependencies | React, Next, and three libraries loaded on demand (below) |

Everything a developer tool does here is hand-written, including the JSON
parser, the YAML parser, the QR encoder's Reed–Solomon arithmetic and the MD5
that `SubtleCrypto` refuses to provide. Three exceptions exist, all for file
formats where a hand-rolled implementation would corrupt something a user
cannot get back, and all `import()`ed only by the page that needs them so they
never enter the shared bundle:

| Library | Licence | Used by | Weight |
| --- | --- | --- | --- |
| `pdf-lib` | MIT | Structural PDF edits, in a Web Worker | Loaded per PDF tool |
| `pdfjs-dist` | Apache-2.0 | Rendering pages and reading the text layer | Loaded per rendering tool |
| `libheif-js` | LGPL-3.0 | HEIC decoding, which no browser but Safari can do | ~2 MB, and only after a native decode has already failed |

`scripts/check-bundle-size.mjs` asserts none of them reach the chunk every page
loads. `ASSUMPTIONS.md` §4a records the conditions, including the LGPL terms.

Every route is prerendered to HTML at build time. Content, headings, FAQ answers
and JSON-LD are all present in the served markup, so a crawler that does not
execute JavaScript still sees the full page.

## Getting started

```bash
npm ci
npm run dev          # http://localhost:3000
```

## Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Next dev server |
| `npm run build` | Crawler files → static build → CSP, SEO and bundle checks |
| `npm run check` | `tsc --noEmit` and ESLint |
| `npm test` | Vitest unit suite |
| `npm run test:e2e` | Playwright, against the built export served with production headers |
| `npm run generate:llms` | Rewrites `llms.txt`, `sitemap.xml`, `robots.txt`, `ads.txt` |
| `npm run generate:csp` | Writes `out/_headers`, deriving the CSP hash list from the export (run after `next build`) |
| `npm run verify:csp` | Fails if any inline script in `out/` would be blocked |
| `npm run verify:seo` | Fails on crawler-facing defects in the export: unparsable JSON-LD, a missing canonical, an incomplete WebApplication node, an image without alt |
| `npm run generate:images` | Generates the sharing image and PNG icons from native SVG with Sharp; no browser required |

The full pre-deploy gate:

```bash
npm run check && npm test && npm run build && npm run test:e2e
```

## Deploying

`npm run build` writes a self-contained static site to `out/`. Upload it to
Netlify, Cloudflare Pages, or any host that understands the `_headers` and
`_redirects` conventions.

**`out/_headers` must be served.** It carries the Content-Security-Policy, HSTS,
and the cache rules. On a host that ignores `_headers`, port those headers to
the host’s supported header configuration. Verify the deployed response headers;
generating a file does not prove the host applies it.

### Environment variables

| Variable | Effect |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Canonical origin. Defaults to `https://toolsbyus.com`. Set this for a preview deployment so canonicals, JSON-LD and the sitemap point at the right host. |
| `SITE_LASTMOD` | Fallback date for aggregate pages; tools use their actual catalogue review dates. |
| `NEXT_PUBLIC_ADSENSE_ID` | Enables the ad placements. Unset by default — see below. |

### CSP and the build order

The policy allowlists inline scripts by SHA-256 hash rather than using
`'unsafe-inline'`. A static export contains inline scripts the app does not
author — Next's own RSC bootstrap payloads — whose content changes on every
build. So `generate-csp` runs **after** `next build`, hashes what the export
actually contains, and `verify-csp` then fails the build if anything would be
blocked.

Consequence: **`_headers` is build output, not source.** It is written only into
`out/`, never into `public/`, and is git-ignored — a committed copy would carry
hashes from an older build, and `next build` would copy that stale file into the
export. Change the generator instead, and rebuild.

If you add an inline `<script>`, the next build picks it up automatically. If you
add an external script host, widen the relevant directive in
`scripts/generate-csp.mjs` — otherwise the browser will block it and the failure
will only appear in production.

### Enabling ads

Ads are off by default, and the copy on `/privacy` says so. Turning them on is
three deliberate steps:

1. Set `NEXT_PUBLIC_ADSENSE_ID` (format `pub-XXXXXXXXXXXXXXXX`) and rebuild. The
   build regenerates `ads.txt` and widens the CSP to the AdSense hosts.
2. Update the "Advertising" section of `src/app/privacy/page.tsx` — it currently
   states, accurately, that no ads are served.
3. Add a consent mechanism for EU/UK visitors. Ad networks set cookies and do
   cross-site measurement; running them without consent is a compliance problem,
   not just a copy problem.

## Layout

```
src/
  app/              One directory per route. page.tsx holds metadata + static
                    content; *Client.tsx holds the interactive tool.
  components/
    common/         Header, Footer, FAQ, breadcrumbs, JSON-LD, theme toggle
    common/Icon.tsx      The whole icon set, one 24px grid, one 1.5 stroke
    common/Notice.tsx    The one inline-message component (info/success/warn/danger)
    common/controls.ts   Shared button, field and segmented-control classes
    diff/           Diff-specific UI (toolbar, summary bar, virtualized list)
    tools/          ToolShell page template, the code pane, and the file-tool
                    scaffolding: FileDropZone, CropCanvas, ImageResults,
                    useImageBatch, usePdfWorker
  lib/
    json/           Hand-written RFC 8259 parser, formatter, minifier, validator
    json/repair.ts  Tokenizer-based repair for malformed JSON
    json/recipes.ts Language-native pretty-print snippets and their gotchas
    diff/           Semantic diff, RFC 6902 patch, RFC 7386 merge patch, text diff
    schema/         Draft 2020-12 inference and validation
    base64/         Base64, base64url, JWT inspection
    uuid/           UUID v1 / v4 / v7 generation and inspection
    yaml/           YAML 1.2 parser and emitter, alias-budgeted
    xml/            XML ↔ JSON with balance checking
    csv/            RFC 4180 reader and writer
    codegen/        Type inference and emitters for TS, Go, Python, C#, Java
    format/         SQL, CSS and HTML tokenizers and formatters
    hash/           MD5, CRC32 and HMAC by hand; SHA via SubtleCrypto
    qr/             ISO/IEC 18004 encoder, Reed–Solomon and mask scoring
    cron/           Cron parsing and next-run computation
    regex/          Pattern explanation and ReDoS risk analysis
    numbers/, time/, text/, url/   Base conversion, instants, case, URI parts
    files/          Size ceilings, page-range parsing, download handling
    images/         Decode, stepped downscale, encode, target-size search
    images/heic.ts  Container sniffing and the on-demand libheif loader
    pdfjs/          Cached pdf.js loader and DPI arithmetic
    safe-object.ts  Prototype-pollution guards used everywhere untrusted keys land
    site.ts         Canonical origin and brand strings — single source of truth
    tools.ts        The tool catalogue — nav, homepage, palette and sitemap read this
    tools.seo.mjs   Sitemap and llms.txt copy, kept out of the client bundle
    limits.ts       Input-size ceilings for main-thread tools
    metadata.ts     Per-page metadata builder
  types/            Declarations for dependencies that ship none
  workers/          Diff, regex and PDF Web Workers, and their clients
scripts/            Build-time generators for crawler files, headers, and images
tests/unit/         Vitest
tests/e2e/          Playwright
```

## Design system

Everything visual resolves to a token in `src/app/globals.css`, and every token
is defined in **both** themes. A colour that exists in only one theme is how a
border goes invisible or a label becomes unreadable after a theme switch, so
`tests/unit/design-tokens.test.ts` reads the real values out of the stylesheet
and checks the contrast arithmetic — against the page background *and* against
`--surface-2`, where toolbars, status bars and table heads live.

| Rule | Why |
| --- | --- |
| Mono for code, sans for prose | Geist serves interface text and prose; Geist Mono serves code and payloads. |
| `--accent` ≠ `--accent-solid` | Separate readable orange text from the brighter brand fill; both themes define their own tokens. |
| No `backdrop-filter`, no keyframes | The filter makes the compositor re-blur a live snapshot of the page every frame; running animation keeps it awake on a page people leave open all day. An e2e test greps the shipped CSS for both. |
| Colour is never the only signal | Every diff row carries a glyph and a word alongside its hue. |
| `pointer-coarse`, not a width breakpoint | Screen width is a poor proxy for "finger". A 28px control is fine under a mouse at any size and awkward under a thumb at any size. |
| One shadow, used for menus only | Cards get a border instead: cheaper to paint and sharper at this density. |

`components/common/controls.ts` holds the shared button, field and
segmented-control classes. Ten tool pages previously each spelled out their own,
which is how the same control ended up 26px tall on one page and 34px on
another.

## Engineering notes

A few decisions that are easy to undo by accident:

- **Traversal is iterative, never recursive.** The diff engine, the JSON parser
  and the schema validator all use explicit worklists. The site advertises deep
  payload support, and recursion would stack-overflow on exactly those inputs.
  `tests/unit/security.test.ts` validates a 20,000-level document to hold this.

- **JSON Pointers are built incrementally.** Materializing each node's path as an
  array made the diff O(depth²) — 8,000 levels took about four seconds. Nodes now
  carry `key` + `depth` and an already-built `jsonPointer`. There is a scaling
  test in `tests/unit/robustness.test.ts`; keep it.

- **Untrusted keys never reach bracket assignment.** Anything writing a key that
  came from user input goes through `lib/safe-object.ts`. A pasted JSON Patch is
  attacker-controlled input, and `/__proto__/x` or `/constructor/prototype/x`
  used to pollute `Object.prototype`.

- **FAQ answers use `<details>`, not React state.** A state-driven accordion only
  renders the open item, which meant a statically exported page shipped one
  answer and hid the rest behind hydration.

- **Nothing random or time-dependent during render.** The UUID page generated its
  first batch in a `useState` initializer, which ran at build time and again on
  hydration — different values, guaranteed mismatch.

- **JSON repair is a tokenizer, never regexes.** A comma inside `"a, b"` is data;
  the same character before `}` is a syntax error. `//` inside a URL is not a
  comment. Independent scanning passes cannot work either, because stripping
  comments needs to know where strings are and normalizing quotes needs to know
  where comments are. `src/lib/json/repair.ts` tokenizes once and decides on
  tokens; a pass-pipeline version of this corrupted real payloads.

- **There is one tool catalogue.** `src/lib/tools.ts` feeds the header, footer,
  homepage grid and command palette. They previously kept four copies, which had
  already drifted. Its sitemap and llms.txt prose lives in `tools.seo.mjs`
  instead, because the catalogue is in the chunk every page loads and nothing in
  the browser has ever read those fields. `tests/unit/tool-catalogue.test.ts`
  asserts the two files list the same hrefs **in both directions**, so the split
  cannot drift into a sitemap advertising a URL that 404s.

- **Touch targets key off `pointer-coarse`, not screen width.** A touchscreen
  laptop needs a 44px target; a narrow desktop window does not.

- **Images are downscaled in halving steps.** Drawing a 4000px image straight
  into a 400px canvas makes the browser sample a handful of source pixels per
  destination pixel and ignore the other ninety-odd, which aliases fine texture
  into moiré rather than blurring it gracefully. `src/lib/images/index.ts`
  halves repeatedly until within a factor of two of the target. A one-line
  `drawImage` is the version that looks correct and is not.

- **A background is painted before encoding to a format with no alpha.** A fresh
  canvas is transparent and JPEG has no alpha channel, so an unpainted canvas
  encodes as black. This is behind almost every "my converted image came out
  black" report on the internet, and the e2e suite samples real pixels out of a
  real conversion to hold it.

- **EXIF orientation is applied, not dropped.** `createImageBitmap` ignores the
  orientation tag unless passed `imageOrientation: "from-image"`. Leave it out
  and every portrait photo from a phone comes out on its side.

- **File tools terminate their worker on every new run.** A superseded PDF
  operation is not merely useless — it is still holding a copy of a 40 MB
  document, so leaving it alive doubles the memory cost of each retry. A run
  counter also discards late replies, which otherwise let a slow merge land
  after a fast one and hand back the wrong file.

- **Images are processed one at a time, not with `Promise.all`.** Eight
  12-megapixel photos decoded concurrently is eight 48 MB bitmaps alive at once,
  which is how a phone browser kills the tab. Sequential is barely slower and
  keeps peak memory at a single image.

- **`useNow` is a module-level store.** The first version passed an inline
  `subscribe` to `useSyncExternalStore` that also notified synchronously, so
  React resubscribed forever — React error #185 in production only. A stable
  `subscribe`, a cached snapshot and no synchronous notify are all load-bearing.

- **Page size is carried in points, not pixels.** Rebuilding a PDF from rendered
  page images has to use the original point box; sizing the page from the pixel
  count turns an A4 sheet rendered at 150 DPI into a seventeen-inch page. The
  e2e suite parses the output and checks the geometry.

## Standards implemented

RFC 8259 (JSON), RFC 6901 (JSON Pointer), RFC 6902 (JSON Patch), RFC 7386 (JSON
Merge Patch), RFC 4180 (CSV), RFC 4648 (Base64/base64url), RFC 4122 and RFC 9562
(UUID v1/v4/v7), RFC 7515 and RFC 7519 (JOSE/JWT, decode only), RFC 3986 (URI),
RFC 1321 (MD5), RFC 4231 (HMAC test vectors), JSON Schema Draft 2020-12,
YAML 1.2 core schema, ISO/IEC 18004 (QR Code), ISO 32000 (PDF, via pdf-lib and
pdf.js), ISO/IEC 23008-12 (HEIF container sniffing).

### Known limits

Stated plainly, because the tools claim standards compliance:

- Schema validation covers the common Draft 2020-12 keyword set. `$ref`
  resolution and remote schema fetching are not supported — fetching a remote
  schema would require a network request the CSP forbids by design.
- JWT signatures are decoded and inspected but never verified. Verification needs
  the issuer's key, which would mean transmitting the token.
- The diff refuses payload pairs above a combined 100 MB rather than exhausting
  tab memory.
- Similarity-mode array matching falls back to index matching beyond 400×400
  elements, where the pairwise scoring pass costs more than it returns.
- YAML parsing implements the 1.2 core schema. Anchors and aliases are supported
  under an expansion budget; merge keys (`<<`) and custom tags are not.
- There is no PDF-to-Word converter, deliberately. A PDF records where glyphs
  sit on a page, not what the paragraphs and tables were; reconstructing an
  editable document from that is guesswork whose output takes longer to fix than
  retyping. Nor is there any password cracking: a user-password PDF is genuinely
  encrypted, and the unlocker handles owner-password restrictions and documents
  whose password you supply.
- AVIF **encoding** is offered only where the browser can actually do it, tested
  by encoding a 1×1 image rather than sniffing the user agent. Firefox and
  Safari currently cannot.
- HEIC decoding is covered by unit tests for the container sniffing only. No
  HEIC encoder exists in this build environment to generate a fixture with, so
  the decode path itself is verified against libheif's API contract rather than
  against a real file in CI. Recorded in `AUDIT.md` rather than left implicit.
