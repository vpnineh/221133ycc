import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypeScript from "eslint-config-next/typescript";

/**
 * eslint-config-next 16 ships a native flat config, so the previous FlatCompat
 * bridge is no longer needed — and in fact crashes ("Converting circular
 * structure to JSON") when asked to wrap it.
 */
const eslintConfig = [
  {
    ignores: [
      "node_modules/**",
      ".next/**",
      "out/**",
      "next-env.d.ts",
      "playwright-report/**",
      "test-results/**",
      // Vendored agent tooling, not project source. Its scripts are CommonJS
      // and Python and are maintained upstream, so linting them only produces
      // noise nobody here can act on.
      ".agents/**",
    ],
  },
  ...nextCoreWebVitals,
  ...nextTypeScript,

  // The JSON engines walk values whose shape is unknown until runtime: they
  // branch on getJsonType()/typeof and cast at the point of use. Modelling that
  // as `unknown` would mean a cast at every access without adding real safety,
  // so `any` is the deliberate choice *in these files only* — everywhere else
  // the rule stays an error.
  {
    files: [
      "src/lib/diff/semantic-diff.ts",
      "src/lib/diff/patch-rfc6902.ts",
      "src/lib/diff/three-way-diff.ts",
      "src/lib/schema/infer.ts",
      "src/lib/base64/index.ts",
      "src/app/json-editor/JsonEditorClient.tsx",
    ],
    rules: {
      "@typescript-eslint/no-explicit-any": "off",
    },
  },

  // Tests construct deliberately malformed values to prove the engines reject
  // them; typing those inputs precisely would defeat the point of the test.
  {
    files: ["tests/**/*.ts"],
    rules: {
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-unused-vars": ["warn", { argsIgnorePattern: "^_" }],
    },
  },

  // Playwright's custom-fixture API is `test.extend({ page: async ({ page },
  // use) => ... })` — its `use` is a fixture callback, not the React hook of
  // the same name. The rules-of-hooks heuristic cannot tell them apart, so the
  // exemption is scoped to the one file that contains fixture definitions.
  {
    files: ["tests/e2e/fixtures.ts"],
    rules: {
      "react-hooks/rules-of-hooks": "off",
    },
  },
];

export default eslintConfig;
