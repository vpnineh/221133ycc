import { defineConfig, devices } from "@playwright/test";

/**
 * Set CHROMIUM_PATH to use a Chromium already present on the machine (CI images
 * often ship one whose revision does not match the Playwright package). Left
 * unset, Playwright uses its own managed download as usual.
 */
const executablePath = process.env.CHROMIUM_PATH || undefined;

export default defineConfig({
  testDir: "./tests/e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 2,
  reporter: "list",
  use: {
    baseURL: "http://localhost:3030",
    trace: "on-first-retry",
  },
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        ...(executablePath ? { launchOptions: { executablePath } } : {}),
      },
    },
  ],
  webServer: {
    // Serves out/ with the generated security headers applied, so the suite
    // exercises the same CSP the deployed site will send.
    command: "node scripts/serve-static.mjs",
    url: "http://localhost:3030",
    reuseExistingServer: true,
    timeout: 30000,
  },
});
