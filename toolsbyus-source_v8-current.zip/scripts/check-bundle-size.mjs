/**
 * Fails the build if the JavaScript every page loads grows past its budget.
 *
 * Next 16 with Turbopack no longer prints the per-route size table, so the
 * number nobody was watching is the one that matters most: the chunks common
 * to *every* route are paid on the first view of any page, and Phase B's WASM
 * codecs are exactly the kind of thing that leaks into the shared graph when a
 * dynamic import is accidentally made static.
 *
 * "Shared" is computed as the intersection of the script URLs across every
 * exported page, which is the real definition rather than an approximation.
 * Sizes are gzipped, because that is what crosses the wire.
 *
 * Run: npm run check:bundle   (wired into `npm run build`, post-export)
 */
import fs from "fs";
import path from "path";
import zlib from "zlib";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const outDir = path.join(projectRoot, "out");

/**
 * Budget for the shared graph, gzipped.
 *
 * The spec's target is ~120 KB. The current baseline is well above it and is
 * almost entirely React plus the Next App Router runtime, which no amount of
 * application-side care removes. Setting the gate at the fantasy number would
 * mean a build that is red from the day it lands, which is a gate nobody reads.
 * It is pinned just above today's measurement instead, so it catches *growth* —
 * the thing it can actually prevent — and is tightened whenever real weight
 * comes out. Override with BUNDLE_BUDGET_KB to experiment.
 *
 * Roughly 153 KB of the figure is React plus the App Router runtime and moves
 * only when they do. Most of the rest is the tool catalogue, which the command
 * palette needs on every route and which therefore grows with the product: each
 * tool costs about 250 bytes gzipped in names, descriptions and search
 * keywords. That is real weight buying a real feature, so the budget is raised
 * deliberately when the catalogue grows and tightened when anything else does.
 * Its prose — sitemap summaries and priorities — was moved out to
 * `tools.seo.mjs` precisely because that part buys nothing in the browser.
 */
const BUDGET_KB = Number(process.env.BUNDLE_BUDGET_KB || 190);

/** Budget for any single route's own chunks, over and above the shared graph. */
const ROUTE_BUDGET_KB = Number(process.env.ROUTE_BUNDLE_BUDGET_KB || 120);

function collectHtmlFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  const found = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...collectHtmlFiles(full));
    else if (entry.name.endsWith(".html")) found.push(full);
  }
  return found;
}

const htmlFiles = collectHtmlFiles(outDir);
if (htmlFiles.length === 0) {
  console.error("check-bundle-size: no exported HTML in out/. Run after `next build`.");
  process.exit(1);
}

/** @type {Map<string, Set<string>>} page -> script urls */
const perPage = new Map();
for (const file of htmlFiles) {
  const html = fs.readFileSync(file, "utf8");
  const urls = new Set(
    [...html.matchAll(/<script[^>]+src="(\/_next\/static\/[^"]+\.js)"/g)].map((m) => m[1])
  );
  perPage.set(path.relative(outDir, file), urls);
}

// The 404 page is an outlier by design and not part of the browsing path.
const pages = [...perPage.entries()].filter(([name]) => !/^(404|_not-found)\.html$/.test(name));

/** Chunks present on every page. */
const shared = [...pages[0][1]].filter((url) => pages.every(([, urls]) => urls.has(url)));

const gzipSize = (url) => {
  const file = path.join(outDir, url.replace(/^\//, ""));
  if (!fs.existsSync(file)) return 0;
  return zlib.gzipSync(fs.readFileSync(file)).length;
};

const sharedBytes = shared.reduce((sum, url) => sum + gzipSize(url), 0);
const sharedKb = sharedBytes / 1024;

/** Largest route-specific payload, i.e. what a page costs beyond the shared graph. */
let worstRoute = { name: "", kb: 0 };
for (const [name, urls] of pages) {
  const ownBytes = [...urls]
    .filter((url) => !shared.includes(url))
    .reduce((sum, url) => sum + gzipSize(url), 0);
  const kb = ownBytes / 1024;
  if (kb > worstRoute.kb) worstRoute = { name, kb };
}

console.log(
  `check-bundle-size: shared ${sharedKb.toFixed(1)} KB gzip across ${pages.length} pages ` +
    `(budget ${BUDGET_KB} KB); largest route-only payload ${worstRoute.kb.toFixed(1)} KB ` +
    `on ${worstRoute.name || "n/a"} (budget ${ROUTE_BUDGET_KB} KB).`
);

const failures = [];
if (sharedKb > BUDGET_KB) {
  failures.push(
    `shared first-load JS is ${sharedKb.toFixed(1)} KB gzip, over the ${BUDGET_KB} KB budget. ` +
      `Something that should be route-specific has entered the shared graph — check for a ` +
      `static import of a heavy module that was meant to be dynamic().`
  );
}
if (worstRoute.kb > ROUTE_BUDGET_KB) {
  failures.push(
    `${worstRoute.name} ships ${worstRoute.kb.toFixed(1)} KB gzip of its own, over the ` +
      `${ROUTE_BUDGET_KB} KB budget. Load heavy engines on first use rather than on mount.`
  );
}

if (failures.length) {
  console.error("\ncheck-bundle-size FAILED:");
  for (const f of failures) console.error(`  - ${f}`);
  process.exit(1);
}
