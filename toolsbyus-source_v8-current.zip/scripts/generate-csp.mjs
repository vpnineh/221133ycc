/**
 * Generates the deployed `_headers` file, including a Content-Security-Policy
 * whose script-src is a hash allowlist rather than 'unsafe-inline'.
 *
 * This has to run AFTER `next build`, over the exported HTML, because a static
 * export ships inline scripts we do not author: the theme initialiser in
 * layout.tsx plus Next's own RSC bootstrap payloads (`self.__next_f.push(...)`),
 * which are regenerated with different content on every build. Hashing only the
 * theme script produced a policy that looked strict and would have blocked the
 * framework's own bootstrap — a white page in production.
 *
 * `<script type="application/ld+json">` blocks are skipped: a non-JavaScript
 * MIME type is data, not a script block, so script-src never applies to them.
 *
 * Run: npm run generate:csp   (wired into `npm run build`, post-export)
 *
 * ---------------------------------------------------------------------------
 * WHY THE POLICY IS EMITTED PER PAGE
 *
 * The first version hashed every inline script across the whole export and put
 * the union — one global `/*` block — on every response. At 85 pages that union
 * reached 625 hashes, the header measured 34,109 bytes on the wire, and the
 * consequences were real:
 *
 *  - Node's fetch (undici) aborts any response whose single header exceeds
 *    16 KB. Playwright's webServer health check and every `fetch()`-based
 *    monitor got `UND_ERR_HEADERS_OVERFLOW`, so the e2e suite could not start
 *    the local server at all — and any uptime check using Node's own fetch
 *    would have reported the production site as down while browsers worked.
 *  - Every page visitor downloaded hashes for the 84 pages they did not visit,
 *    on every HTML request, before any content. At ~54 bytes a hash that is
 *    tens of kilobytes of dead weight on each page load.
 *
 * The export is flat (every page is `/name.html`), so per-page blocks are also
 * cheap and unambiguous: one block per page, no overlapping patterns. Overlap
 * matters — CSP headers from multiple matching blocks are *combined* by
 * browsers, and for script-src the combination is an intersection of
 * capabilities, not a union: a page under both `/x.html` and `/*` would run
 * only scripts allowed by BOTH policies, and the intersection of two different
 * hash lists is empty. So the global block deliberately carries everything
 * except the script hash list, and only the page block carries hashes.
 *
 * The per-page size arithmetic that makes this the right shape, not just a
 * working one: the busiest page (json-tools) needs 45 hashes (~2.4 KB), the
 * quietest 11 (~0.6 KB), average 14 (~0.8 KB). The global block was sending
 * the 34 KB worst case to every visitor; the page block sends each page its
 * own ~2.4 KB worst case and never more than it needs.
 */
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import {
  buildAdsConfig,
  AD_SCRIPT_HOSTS,
  AD_FRAME_HOSTS,
  AD_IMAGE_HOSTS,
  AD_CONNECT_HOSTS,
} from "../src/lib/ads.data.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const outDir = path.join(projectRoot, "out");

/** Recursively collect every .html file in the export. */
function collectHtmlFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  const found = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...collectHtmlFiles(full));
    else if (entry.name.endsWith(".html")) found.push(full);
  }
  return found;
}

/**
 * Executable inline scripts only: no `src`, and either no type or a JavaScript
 * MIME type. Everything else (JSON-LD, importmap, speculationrules) is data.
 */
const SCRIPT_RE = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
const JS_TYPES = new Set(["", "module", "text/javascript", "application/javascript"]);

function inlineScriptHashes(html) {
  const hashes = new Set();
  for (const match of html.matchAll(SCRIPT_RE)) {
    const attrs = match[1] || "";
    const body = match[2] || "";
    if (/\bsrc\s*=/i.test(attrs)) continue;
    if (!body.trim()) continue;

    const typeMatch = attrs.match(/\btype\s*=\s*["']?([^"'\s>]*)/i);
    const type = (typeMatch ? typeMatch[1] : "").toLowerCase();
    if (!JS_TYPES.has(type)) continue;

    hashes.add(crypto.createHash("sha256").update(body, "utf8").digest("base64"));
  }
  return hashes;
}

const htmlFiles = collectHtmlFiles(outDir);

if (htmlFiles.length === 0) {
  console.warn(
    "generate-csp: no exported HTML found in out/. Run this after `next build`, " +
      "or the policy will omit the framework's inline bootstrap hashes."
  );
}

// Ads are opt-in and only count as enabled for a well-formed publisher ID, so
// a typo in the env var leaves the policy locked down rather than half-open.
// The host lists live in src/lib/ads.data.mjs alongside the runtime config, so
// the policy cannot drift from what the page actually loads.
const ads = buildAdsConfig(process.env);
const adsEnabled = ads.enabled;

// Analytics is a separate opt-in from ads: a privacy-preserving counter is a
// reasonable thing to run without also serving advertising.
const analyticsHost = (process.env.NEXT_PUBLIC_ANALYTICS_SRC || "").trim();
let analyticsOrigin = "";
if (analyticsHost) {
  try {
    analyticsOrigin = new URL(analyticsHost).origin;
  } catch {
    console.warn(
      `generate-csp: NEXT_PUBLIC_ANALYTICS_SRC is not a valid URL (${analyticsHost}); ignoring.`
    );
  }
}

const extra = (list) => (list.length ? ` ${list.join(" ")}` : "");
const scriptExtras = [...(adsEnabled ? AD_SCRIPT_HOSTS : []), ...(analyticsOrigin ? [analyticsOrigin] : [])];
const connectExtras = [...(adsEnabled ? AD_CONNECT_HOSTS : []), ...(analyticsOrigin ? [analyticsOrigin] : [])];

/**
 * The directive list WITHOUT the per-page hash list.
 *
 * `script-src` here allows only same-origin external scripts plus the
 * `wasm-unsafe-eval` the image codecs need. The inline-script capability comes
 * entirely from the hashes each page block appends — which is why this base
 * must never gain 'unsafe-inline' and must never ship alone on a page URL.
 */
const baseDirectives = [
  "default-src 'self'",
  `script-src 'self' 'wasm-unsafe-eval'${extra(scriptExtras)}`,
  // Next injects small inline <style> blocks during static export, so styles
  // specifically need 'unsafe-inline'. Style injection is not a script vector.
  "style-src 'self' 'unsafe-inline'",
  `img-src 'self' data: blob:${extra(adsEnabled ? AD_IMAGE_HOSTS : [])}`,
  "font-src 'self' data:",
  // The tools themselves have no reason to reach the network, and nothing here
  // lets them: the only widenings are the ad stack and an optional analytics
  // endpoint, both of which the operator opts into explicitly. A payload still
  // has nowhere to go, which is what keeps "your file never leaves the browser"
  // enforced by the browser rather than merely asserted.
  `connect-src 'self'${extra(connectExtras)}`,
  "worker-src 'self' blob:",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  `frame-src ${adsEnabled ? AD_FRAME_HOSTS.join(" ") : "'none'"}`,
  "upgrade-insecure-requests",
];

const pageCsp = (hashList) => baseDirectives.map((d) => (d.startsWith("script-src ") ? `${d} ${hashList}` : d)).join("; ");

/** The global policy: page policy minus any hash list. Never carries hashes — see above. */
const globalCsp = baseDirectives.join("; ");

// One block per page, sorted for a stable, diff-able file. Sorted by URL path,
// not by the file path, so `/` (index.html) lands in its natural place.
const pageBlocks = htmlFiles
  .map((file) => {
    const rel = path.relative(outDir, file).split(path.sep).join("/");
    const urlPath = rel === "index.html" ? "/" : `/${rel.slice(0, -".html".length)}`;
    const hashes = inlineScriptHashes(fs.readFileSync(file, "utf8"));
    return { urlPath, hashes };
  })
  .sort((a, b) => (a.urlPath === "/" ? -1 : b.urlPath === "/" ? 1 : a.urlPath.localeCompare(b.urlPath)));

let maxHashes = 0;
let maxPage = "";
const pageBlockText = pageBlocks
  .map(({ urlPath, hashes }) => {
    const hashList = [...hashes].sort().map((h) => `'sha256-${h}'`).join(" ");
    if (hashes.size > maxHashes) {
      maxHashes = hashes.size;
      maxPage = urlPath;
    }
    return `${urlPath}\n  Content-Security-Policy: ${pageCsp(hashList)}`;
  })
  .join("\n\n");

const totalHashes = pageBlocks.reduce((sum, page) => sum + page.hashes.size, 0);

/**
 * The policy for static assets, which is the page policy minus the hash list.
 *
 * Two things make this worth having and one makes it dangerous.
 *
 * Worth having: the per-page hash lists mean the largest page policy is about
 * 2.5 KB — but an asset would still receive whatever block matched it first
 * with hashes in it. It also gets a one-line policy that permits nothing,
 * which is the correct one for a file that should never fetch anything of its
 * own.
 *
 * Dangerous: a Web Worker inherits its CSP from the response that delivered its
 * *script*, not from the page that started it. The first version of this used
 * `default-src 'none'`, which is correct for a stylesheet and fatal for a
 * worker — every PDF operation, the regex timeout and the diff engine stopped
 * working, and only the end-to-end suite noticed. So this keeps every directive
 * the workers actually need and drops the hashes, which a worker cannot use:
 * it has no inline scripts to allow.
 */
const assetCsp = baseDirectives.join("; ");

const headers = `# Generated by scripts/generate-csp.mjs — do not edit by hand.
# The script-src hash lists are derived from the exported HTML, so they must be
# regenerated whenever the build output changes. Run: npm run build
#
# Shape of this file:
#   1. A global block with the security and cache headers every response gets,
#      including a CSP that allows NO inline script (no hash list).
#   2. One block per page adding that page's own hash list. Pages are flat and
#      the patterns never overlap, so no page matches two CSP blocks — two
#      matching blocks would INTERSECT their script-src capabilities and block
#      everything inline.
#   3. Cache and asset rules at the bottom, which may overlap by design: CSP
#      is deliberately absent from every later matching block, and none of
#      them set a header the global block already set to a different value.

/*
  Content-Security-Policy: ${globalCsp}
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=(), interest-cohort=()
  Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
  Cross-Origin-Opener-Policy: same-origin
  Cross-Origin-Resource-Policy: same-origin
  X-DNS-Prefetch-Control: off

${pageBlockText}

# Fingerprinted build output is safe to cache forever.
#
# It also gets the page policy minus the hash list. A CSP on a subresource
# governs that resource as a document, and these are never loaded as documents,
# so a hash list would be pure weight — and the largest page's list is not
# small. The hash-free policy permits nothing this file should ever do itself.
/_next/static/*
  Cache-Control: public, max-age=31536000, immutable
  Content-Security-Policy: ${assetCsp}

/*.png
  Cache-Control: public, max-age=604800

/*.svg
  Cache-Control: public, max-age=604800

# HTML must revalidate so a deploy is picked up immediately.
/*.html
  Cache-Control: public, max-age=0, must-revalidate

/
  Cache-Control: public, max-age=0, must-revalidate

# Crawler-facing files change with content; keep them fresh.
/robots.txt
  Cache-Control: public, max-age=3600

/sitemap.xml
  Cache-Control: public, max-age=3600

/llms.txt
  Cache-Control: public, max-age=3600
`;

// Written only into the export, never into public/.
//
// The hash lists describe one specific build, so a copy sitting in public/ is
// stale the moment the next build runs — and worse, `next build` would copy
// that stale file into out/. Anyone running the build without this generator
// would then deploy a policy whose hashes match nothing, and every page would
// come up blank. Keeping the file build-output-only makes that impossible, and
// keeps a generated artifact out of version control.
if (!fs.existsSync(outDir)) {
  console.error(
    "generate-csp: out/ does not exist. This must run after `next build` — " +
      "see the build script in package.json."
  );
  process.exit(1);
}
fs.writeFileSync(path.join(outDir, "_headers"), headers, "utf8");

// True size of the largest page's header, measured from what was written.
let maxBlockBytes = 0;
for (const block of pageBlocks) {
  const bytes = Buffer.byteLength(
    `Content-Security-Policy: ${pageCsp([...block.hashes].sort().map((h) => `'sha256-${h}'`).join(" "))}`,
    "utf8"
  );
  if (bytes > maxBlockBytes) maxBlockBytes = bytes;
}

console.log(
  `Successfully generated _headers: ${totalHashes} inline-script hash(es) across ` +
    `${pageBlocks.length} per-page CSP block(s) (largest ${maxHashes} hashes on ${maxPage}, ` +
    `~${(maxBlockBytes / 1024).toFixed(1)} KB header), ads ${adsEnabled ? "enabled" : "disabled"}` +
    `${analyticsOrigin ? `, analytics ${analyticsOrigin}` : ""}.`
);

if (maxBlockBytes > 8 * 1024) {
  console.warn(
    "generate-csp: a page's CSP header exceeds 8 KB. undici (Node's fetch) refuses " +
      "any single header over 16 KB; keep an eye on this as the catalogue grows."
  );
}

if (ads.misconfigured) {
  console.warn(
    "generate-csp: NEXT_PUBLIC_ADSENSE_ID is set but neither NEXT_PUBLIC_AD_UNIT_TOP " +
      "nor NEXT_PUBLIC_AD_UNIT_MID is. Slots render nothing until a numeric ad-unit " +
      "ID from the AdSense dashboard is supplied."
  );
}
