/** Generate brand assets from one SVG and the live catalogue.
 * No browser or network required. npm run generate:images */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";
import { publishedTools, activeCategories } from "../src/lib/tools.data.mjs";

const publicDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../public");
const mark = fs.readFileSync(path.join(publicDir, "favicon.svg"), "utf8");
const tools = publishedTools();
for (const [size, file] of [[512, "icon-512.png"], [192, "icon-192.png"], [180, "apple-touch-icon.png"], [32, "favicon-32.png"], [16, "favicon-16.png"]]) {
  await sharp(Buffer.from(mark)).resize(size, size).png().toFile(path.join(publicDir, file));
  console.log(`Generated ${file} from favicon.svg`);
}
fs.writeFileSync(path.join(publicDir, "icon.svg"), mark);
const glyph = mark.replace(/<svg[^>]*>/, '<svg x="80" y="64" width="48" height="48" viewBox="0 0 32 32">');
const categories = activeCategories().map((c, i) => `<text x="${80+i*149}" y="537" font-size="18" fill="#a7a7ad">${c.label} <tspan fill="#f5f5f7">${tools.filter(t=>t.category===c.id).length}</tspan></text>`).join("");
const social = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
<rect width="1200" height="630" fill="#1d1d1f"/>${glyph}
<g font-family="Arial, Helvetica, sans-serif" fill="#f5f5f7">
<text x="144" y="98" font-size="30" font-weight="700">Tools<tspan fill="#ff9466">ByUs</tspan></text>
<text x="80" y="235" font-size="68" font-weight="700">Everyday files.</text>
<text x="80" y="315" font-size="68" font-weight="700">A little less work.</text>
<text x="80" y="394" font-size="26" fill="#b9b9bf">${tools.length} free tools. Process files in your browser.</text>
<path d="M80 484h1040" stroke="#444449"/>${categories}
</g></svg>`;
await sharp(Buffer.from(social)).png().toFile(path.join(publicDir, "og-image.png"));
console.log(`Generated og-image.png with ${tools.length} tools across ${activeCategories().length} categories`);
