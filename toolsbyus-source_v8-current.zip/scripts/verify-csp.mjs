/**
 * Fails the build if the generated CSP would block any inline script that the
 * exported HTML actually ships.
 *
 * A CSP that looks strict but blocks the framework's own bootstrap is worse
 * than no CSP: the site renders blank and the failure only shows up in a real
 * browser. This checks the policy against the artefact before it deploys.
 *
 * Run: npm run verify:csp   (wired into `npm run build`)
 *
 * Since generate-csp moved to per-page blocks, this reads the file the way a
 * host and the browser do: for each page, gather every block whose pattern
 * matches that page's URL, then check the page's inline scripts against the
 * hash-bearing CSP among them. It also asserts the structural properties the
 * per-page scheme depends on — every page covered by exactly one hash-bearing
 * block, no 'unsafe-inline' anywhere in a script-src, and no header size a
 * strict client (undici caps a single header at 16 KB) would refuse.
 */
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const outDir = path.join(projectRoot, "out");

function collectHtmlFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  const found = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...collectHtmlFiles(full));
    else if (entry.name.endsWith(".html")) found.push(full);
  }
  return found;
}

const headersPath = path.join(outDir, "_headers");
if (!fs.existsSync(headersPath)) {
  console.error("verify-csp: out/_headers is missing. Run the full build first.");
  process.exit(1);
}

/** Parse `_headers` into ordered (pattern, headers) blocks — same rules as serve-static.mjs. */
function loadHeaderBlocks() {
  const blocks = [];
  let current = null;
  for (const rawLine of fs.readFileSync(headersPath, "utf8").split("\n")) {
    const line = rawLine.trimEnd();
    if (!line.trim() || line.trim().startsWith("#")) continue;
    if (!/^\s/.test(line)) {
      current = { pattern: line.trim(), headers: {} };
      blocks.push(current);
      continue;
    }
    if (!current) continue;
    const separator = line.indexOf(":");
    if (separator === -1) continue;
    current.headers[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
  }
  return blocks;
}

/** `/*`, `/dir/*` and `/*.ext` are the only shapes generate-csp writes. */
function patternMatches(pattern, urlPath) {
  if (pattern === urlPath) return true;
  if (pattern.startsWith("/*.") && pattern !== "/*") return urlPath.endsWith(pattern.slice(2));
  if (pattern.endsWith("/*")) return urlPath.startsWith(pattern.slice(0, -1));
  return false;
}

const blocks = loadHeaderBlocks();

const SCRIPT_RE = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
const JS_TYPES = new Set(["", "module", "text/javascript", "application/javascript"]);

function hashesIn(policy) {
  return new Set([...policy.matchAll(/'sha256-([A-Za-z0-9+/=]+)'/g)].map((m) => m[1]));
}

const problems = [];
let checked = 0;

for (const file of collectHtmlFiles(outDir)) {
  const rel = path.relative(outDir, file).split(path.sep).join("/");
  const urlPath = rel === "index.html" ? "/" : `/${rel.slice(0, -".html".length)}`;

  const matching = blocks.filter((block) => patternMatches(block.pattern, urlPath));
  const cspPolicies = matching
    .map((block) => block.headers["Content-Security-Policy"])
    .filter(Boolean);

  if (cspPolicies.length === 0) {
    problems.push(`${urlPath}: no CSP header in _headers matches this page at all`);
    continue;
  }

  for (const policy of cspPolicies) {
    const scriptSrc = policy.split(";").find((d) => d.trim().startsWith("script-src")) ?? "";
    if (scriptSrc.includes("'unsafe-inline'")) {
      problems.push(`${urlPath}: a matching CSP allows 'unsafe-inline' in script-src`);
    }
    const byteLength = Buffer.byteLength(`Content-Security-Policy: ${policy}`, "utf8");
    if (byteLength > 16 * 1024) {
      problems.push(
        `${urlPath}: a matching CSP header is ${byteLength} bytes — undici (Node's fetch) ` +
          `refuses any single header over 16 KB, and Playwright's health check dies on it`
      );
    }
  }

  // The browser intersects script-src across every matching policy. The global
  // block ships no hashes by design, so exactly one hash-bearing block must
  // cover each page: zero means the page's inline scripts are blocked outright,
  // two means the intersection of two different lists is empty — same result.
  const hashBearing = cspPolicies.filter((p) => hashesIn(p).size > 0);
  if (hashBearing.length === 0) {
    problems.push(`${urlPath}: every matching CSP block has an empty script-src hash list`);
    continue;
  }
  if (hashBearing.length > 1) {
    problems.push(
      `${urlPath}: ${hashBearing.length} matching CSP blocks carry hash lists — browsers ` +
        `intersect them, and the intersection of two different lists blocks everything`
    );
    continue;
  }

  const allowed = hashesIn(hashBearing[0]);

  const html = fs.readFileSync(file, "utf8");
  for (const match of html.matchAll(SCRIPT_RE)) {
    const attrs = match[1] || "";
    const body = match[2] || "";
    if (/\bsrc\s*=/i.test(attrs) || !body.trim()) continue;

    const type = (attrs.match(/\btype\s*=\s*["']?([^"'\s>]*)/i)?.[1] ?? "").toLowerCase();
    if (!JS_TYPES.has(type)) continue;

    checked++;
    const hash = crypto.createHash("sha256").update(body, "utf8").digest("base64");
    if (!allowed.has(hash)) {
      problems.push(
        `${urlPath}: inline script (${body.length} chars) sha256-${hash} is not in this ` +
          `page's policy\n    starts: ${body.slice(0, 70).replace(/\s+/g, " ")}`
      );
    }
  }
}

// Structural check: the generator must never emit two hash-bearing page blocks
// for the same URL. The bare `/` cache block below them is intentionally a
// second `/` pattern — it sets no CSP, so it cannot narrow a policy.
const pagePatterns = blocks
  .filter((b) => b.headers["Content-Security-Policy"] && hashesIn(b.headers["Content-Security-Policy"]).size > 0)
  .map((b) => b.pattern);
const seen = new Map();
for (const pattern of pagePatterns) {
  if (seen.has(pattern)) problems.push(`_headers has a duplicate hash-bearing page block for ${pattern}`);
  seen.set(pattern, true);
}

if (problems.length > 0) {
  console.error(`verify-csp: ${problems.length} problem(s) with the generated policy:\n`);
  for (const p of problems) console.error("  - " + p);
  console.error("\nRegenerate with: npm run generate:csp");
  process.exit(1);
}

console.log(
  `verify-csp: OK — all ${checked} inline script(s) across the export are allowed by ` +
    `their own page's hash list; no unsafe-inline, no header over 16 KB.`
);
