/**
 * Fails the build on the crawler-facing defects that no other check catches.
 *
 * The unit suite checks the catalogue, the end-to-end suite checks what a
 * browser does with a page, and `verify-csp` checks the policy. Nothing looked
 * at the *served markup* as a crawler or an answer engine reads it — and that
 * is where this site's entire strategy lives. The defects it exists to catch
 * are all silent: a JSON-LD block that stopped parsing, a page that lost its
 * canonical in a refactor, a WebApplication node that forgot to say the tool is
 * free, an image that shipped without alt text.
 *
 * Severity decides whether the build stops. CRITICAL and HIGH are things that
 * cost indexing or misstate a fact; MEDIUM and LOW are reported and allowed, so
 * the gate stays something people read rather than something they route around.
 *
 * Run: npm run verify:seo   (wired into `npm run build`, post-export)
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { publishedTools, activeCategories } from "../src/lib/tools.data.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(path.resolve(__dirname, ".."), "out");

if (!fs.existsSync(outDir)) {
  console.error("verify-seo: out/ is missing. This must run after `next build`.");
  process.exit(1);
}

/** 404 is noindex by design and is not part of the browsing path. */
const pages = fs
  .readdirSync(outDir)
  .filter((file) => file.endsWith(".html") && !/^(404|_not-found)/.test(file))
  .map((file) => path.join(outDir, file));

/** The homepage leads with its hero; a review stamp there is noise. */
const NO_STAMP_NEEDED = new Set(["index"]);

const issues = [];
const report = (page, level, message) => issues.push({ page, level, message });

const origin = (process.env.NEXT_PUBLIC_SITE_URL || "https://toolsbyus.com").replace(/\/+$/, "");
const sitemap = fs.readFileSync(path.join(outDir, "sitemap.xml"), "utf8");
const locations = [...sitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map(m => m[1]);
const knownRoutes = new Set(pages.map(file => path.basename(file, ".html") === "index" ? "/" : `/${path.basename(file, ".html")}`));
const seenTitles = new Map();
const seenDescriptions = new Map();
const decode = value => value.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
const plain = value => decode(value.replace(/<!--[\s\S]*?-->/g, "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
for (const loc of locations) {
  if (!loc.startsWith(origin + "/") || !knownRoutes.has(loc.slice(origin.length))) report("sitemap", "HIGH", `unknown or off-origin URL: ${loc}`);
}
if (new Set(locations).size !== locations.length) report("sitemap", "HIGH", "duplicate URLs");
const robots = fs.readFileSync(path.join(outDir, "robots.txt"), "utf8");
if (!robots.includes(`Sitemap: ${origin}/sitemap.xml`)) report("robots", "HIGH", "sitemap origin drift");

const counts = { directAnswer: 0, questionH2: 0, faq: 0, stamp: 0 };

for (const file of pages) {
  const name = path.basename(file, ".html");
  const html = fs.readFileSync(file, "utf8");

  /* ---- Structured data -------------------------------------------------- */
  const blocks = [
    ...html.matchAll(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g),
  ].map((match) => match[1]);

  if (blocks.length === 0) report(name, "HIGH", "no JSON-LD at all");

  for (const block of blocks) {
    let parsed;
    try {
      // The serializer escapes < > & as unicode so a payload cannot close the
      // script element early; undo that before parsing.
      parsed = JSON.parse(
        block.replace(/\\u003c/g, "<").replace(/\\u003e/g, ">").replace(/\\u0026/g, "&")
      );
    } catch (error) {
      report(name, "CRITICAL", `JSON-LD does not parse: ${error.message}`);
      continue;
    }

    const nodes = Array.isArray(parsed) ? parsed : (parsed["@graph"] ?? [parsed]);
    for (const node of nodes) {
      if (!node["@type"]) {
        report(name, "MEDIUM", "JSON-LD node with no @type");
        continue;
      }

      if (node["@type"] === "WebApplication") {
        for (const required of ["name", "applicationCategory", "offers"]) {
          if (!node[required]) report(name, "HIGH", `WebApplication missing ${required}`);
        }
        if (!node.featureList) report(name, "LOW", "WebApplication has no featureList");
      }

      if (node["@type"] === "FAQPage") {
        counts.faq++;
        for (const question of node.mainEntity ?? []) {
          if (!question.acceptedAnswer?.text) {
            report(name, "HIGH", "FAQ question with no answer text");
          }
        }
      }

      if (node["@type"] === "BreadcrumbList") {
        const positions = (node.itemListElement ?? []).map((item) => item.position);
        if (positions.some((position, index) => position !== index + 1)) {
          report(name, "MEDIUM", "BreadcrumbList positions are not 1..n in order");
        }
      }
    }
  }

  /* ---- Crawler basics --------------------------------------------------- */
  if (!/rel="canonical"/.test(html)) report(name, "CRITICAL", "no canonical");
  if (/content="noindex/i.test(html)) report(name, "CRITICAL", "noindex on an indexable page");
  if (!/property="og:image"/.test(html)) report(name, "HIGH", "no og:image");
  if (!/name="twitter:card"/.test(html)) report(name, "MEDIUM", "no twitter:card");

  const h1Count = [...html.matchAll(/<h1[^>]*>/g)].length;
  if (h1Count !== 1) report(name, "HIGH", `${h1Count} H1 elements`);

  for (const image of html.matchAll(/<img\b([^>]*)>/g)) {
    if (!/\balt=/.test(image[1])) report(name, "HIGH", "img without alt");
  }

  /* ---- Exact metadata, internal targets and sitemap parity ------------ */
  const route = name === "index" ? "/" : `/${name}`;
  const expectedUrl = origin + route;
  const canonical = [...html.matchAll(/<link\b[^>]*rel="canonical"[^>]*href="([^"]+)"[^>]*>/g)];
  if (canonical.length !== 1 || new URL(decode(canonical[0]?.[1] ?? origin)).href !== new URL(expectedUrl).href) report(name, "HIGH", "canonical does not match its route");
  if (!locations.includes(expectedUrl)) report(name, "HIGH", "page missing from sitemap");
  const title = plain(html.match(/<title>([\s\S]*?)<\/title>/)?.[1] ?? "");
  const description = decode(html.match(/<meta name="description" content="([^"]*)"/)?.[1] ?? "");
  for (const [value, seen, label] of [[title, seenTitles, "title"], [description, seenDescriptions, "description"]]) {
    if (!value) report(name, "HIGH", `empty ${label}`);
    if (seen.has(value)) report(name, "HIGH", `duplicate ${label} with ${seen.get(value)}`);
    seen.set(value, name);
  }
  const visibleHtml = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/g, "");
  for (const match of visibleHtml.matchAll(/<a\b[^>]*href="([^"]+)"/g)) {
    const href = decode(match[1]);
    if (!href.startsWith("/") && !href.startsWith(origin + "/") && !href.startsWith("#")) continue;
    const url = new URL(href, expectedUrl);
    if (url.origin !== origin) continue;
    const target = url.pathname === "/" ? "index" : url.pathname.slice(1).replace(/\/$/, "");
    const targetFile = path.join(outDir, `${target}.html`);
    if (!fs.existsSync(targetFile)) {
      if (!fs.existsSync(path.join(outDir, url.pathname))) report(name, "HIGH", `broken internal link ${href}`);
      continue;
    }
    if (url.hash) {
      const targetHtml = fs.readFileSync(targetFile, "utf8");
      if (!targetHtml.includes(`id="${decodeURIComponent(url.hash.slice(1))}"`)) report(name, "HIGH", `missing anchor ${href}`);
    }
  }
  for (const block of blocks) {
    let data; try { data = JSON.parse(block); } catch { continue; }
    for (const node of (Array.isArray(data) ? data : data["@graph"] ?? [data])) {
      if (["WebPage", "WebApplication", "CollectionPage", "AboutPage"].includes(node["@type"]) && node.url !== expectedUrl) report(name, "HIGH", "schema URL disagrees with canonical");
      if (node.dateModified && !visibleHtml.includes(`dateTime="${node.dateModified}"`) && !visibleHtml.includes(`datetime="${node.dateModified}"`)) report(name, "HIGH", "schema date has no matching visible review date");
      if (node["@type"] === "FAQPage") for (const question of node.mainEntity ?? []) {
        if (!plain(visibleHtml).includes(question.name.replace(/\s+/g, " ").trim())) report(name, "HIGH", "schema FAQ question absent from content");
        if (!plain(visibleHtml).includes((question.acceptedAnswer?.text ?? "").replace(/\s+/g, " ").trim())) report(name, "HIGH", "schema FAQ answer differs from content");
      }
      if (node["@type"] === "ItemList" && node.numberOfItems !== undefined && node.numberOfItems !== node.itemListElement?.length) report(name, "HIGH", "ItemList count drift");
    }
  }
  if (name === "index") {
    for (const category of activeCategories()) {
      const panel = visibleHtml.match(new RegExp(`<div[^>]*id="panel-${category.id}"[^>]*>([\\s\\S]*?)</ul>`))?.[1] ?? "";
      const expected = publishedTools().filter(t => t.category === category.id);
      for (const tool of expected) if (!panel.includes(`href="${tool.href}"`)) report(name, "HIGH", `homepage category ${category.id} omits ${tool.href}`);
    }
  }

  /* ---- What an answer engine extracts ----------------------------------- */
  // The 40-60 word answer under the H1, which is what gets quoted.
  if (/<p class="[^"]*border-l-2[^"]*">[\s\S]{80,900}?<\/p>/.test(html)) counts.directAnswer++;

  const headings = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/g)].map((match) =>
    match[1].replace(/<!--[\s\S]*?-->/g, "").replace(/<[^>]+>/g, "").trim()
  );
  if (headings.some((heading) => heading.endsWith("?"))) counts.questionH2++;

  if (/<time [^>]*datetime=/i.test(html)) counts.stamp++;
  else if (!NO_STAMP_NEEDED.has(name)) report(name, "MEDIUM", "no visible <time> review stamp");
}

console.log(
  `verify-seo: ${pages.length} pages — ${counts.directAnswer} with a direct answer, ` +
    `${counts.questionH2} with a question heading, ${counts.faq} with FAQ schema, ` +
    `${counts.stamp} with a visible review date.`
);

const bySeverity = { CRITICAL: [], HIGH: [], MEDIUM: [], LOW: [] };
for (const issue of issues) bySeverity[issue.level].push(issue);

for (const level of ["CRITICAL", "HIGH", "MEDIUM", "LOW"]) {
  const list = bySeverity[level];
  if (list.length === 0) continue;

  const grouped = new Map();
  for (const issue of list) {
    grouped.set(issue.message, [...(grouped.get(issue.message) ?? []), issue.page]);
  }
  console.log(`  ${level}:`);
  for (const [message, affected] of grouped) {
    console.log(
      `    ${message} — ${affected.length} page(s): ${affected.slice(0, 8).join(", ")}` +
        (affected.length > 8 ? ` …and ${affected.length - 8} more` : "")
    );
  }
}

const blocking = bySeverity.CRITICAL.length + bySeverity.HIGH.length;
if (blocking > 0) {
  console.error(
    `\nverify-seo FAILED: ${blocking} issue(s) at CRITICAL or HIGH. These cost indexing or ` +
      `misstate something about the page, so the build stops here.`
  );
  process.exit(1);
}
