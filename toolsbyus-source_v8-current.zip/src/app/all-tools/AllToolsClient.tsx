"use client";

import React, { useDeferredValue, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Icon } from "../../components/common/Icon";
import { field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { CATEGORIES, TOOLS, type Tool, type ToolCategory } from "../../lib/tools";

/**
 * The full directory: every tool on one page, filterable without a round trip.
 *
 * The site had no such page, which is a real gap at fifty-eight tools. The
 * header menu shows six per category and a "more" link; the category hubs each
 * show one category; the command palette is excellent and invisible to anyone
 * who has not learned it exists. Someone arriving from a search result had no
 * way to see the whole thing at once.
 *
 * Every tool is rendered into the HTML and then *hidden* by the filter, rather
 * than the list being built from state. Two reasons: a crawler that does not
 * run JavaScript sees all fifty-eight links and their descriptions, and the
 * filter costs nothing because it is toggling a class rather than reconciling a
 * list. This is also why the counts are computed from the full catalogue rather
 * than from what is currently visible.
 */

const ALL = "all" as const;
type Filter = typeof ALL | ToolCategory;

/** Fields a query is matched against, lowercased once per tool. */
function haystack(tool: Tool): string {
  return `${tool.name} ${tool.title} ${tool.description} ${tool.keywords.join(" ")} ${
    tool.href
  }`.toLowerCase();
}

export const AllToolsClient: React.FC = () => {
  const tools = TOOLS;
  const index = useMemo(
    () => new Map<string, string>(tools.map((tool) => [tool.href, haystack(tool)])),
    [tools]
  );

  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>(ALL);
  const searchRef = useRef<HTMLInputElement>(null);

  // The list is small enough that this is instant, but deferring keeps typing
  // smooth on a low-end phone, where 58 nodes re-styling per keystroke is not
  // free.
  const deferredQuery = useDeferredValue(query);

  const terms = useMemo(
    () => deferredQuery.toLowerCase().split(/\s+/).filter(Boolean),
    [deferredQuery]
  );

  const matches = useMemo(() => {
    const set = new Set<string>();
    for (const tool of tools) {
      if (filter !== ALL && tool.category !== filter) continue;
      const text = index.get(tool.href) ?? "";
      // Every term must appear somewhere — "pdf split" and "split pdf" both
      // find the same tool, which a substring match on the whole query would
      // not.
      if (terms.every((term) => text.includes(term))) set.add(tool.href);
    }
    return set;
  }, [tools, index, filter, terms]);

  const grouped = useMemo(
    () =>
      CATEGORIES.map((category) => ({
        category,
        tools: tools.filter((tool) => tool.category === category.id),
      })).filter((group) => group.tools.length > 0),
    [tools]
  );

  const active = query.trim() !== "" || filter !== ALL;

  return (
    <div className="space-y-6">
      {/* Sticks under the site bar, which is 4.5rem tall — `top-14` was left
          over from a 3.5rem header and parked this strip 16px too high, so it
          overlapped the chrome instead of meeting it. The background is solid
          rather than 95% opaque: without a backdrop filter, which this site
          does not use, a translucent bar just shows the list scrolling
          through it. */}
      <div className="sticky top-[4.5rem] z-20 -mx-4 border-b border-border bg-background px-4 pb-3 pt-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-foreground-subtle">
              <Icon name="search" size="md" />
            </span>
            <input
              ref={searchRef}
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Filter by name, format or what you are trying to do"
              aria-label="Filter tools"
              autoComplete="off"
              spellCheck={false}
              className={`${field} h-10 w-full pl-9 pr-9 text-sm`}
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  setQuery("");
                  searchRef.current?.focus();
                }}
                aria-label="Clear filter"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 cursor-pointer rounded p-1.5 text-foreground-subtle transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                <Icon name="close" size="sm" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto">
            <span className={`${fieldLabel} flex-none`}>Category</span>
            <div className={`${segmentTrack} flex-none`} role="group" aria-label="Filter by category">
              <button
                type="button"
                onClick={() => setFilter(ALL)}
                aria-pressed={filter === ALL}
                className={segment(filter === ALL)}
              >
                All {tools.length}
              </button>
              {grouped.map(({ category, tools: inCategory }) => (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => setFilter(category.id)}
                  aria-pressed={filter === category.id}
                  className={segment(filter === category.id)}
                >
                  {category.label} {inCategory.length}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Announced rather than merely displayed: a filter that silently empties
            a list is disorienting without sight of it. */}
        <p role="status" aria-live="polite" className="mt-2 font-mono text-2xs text-foreground-subtle">
          {active
            ? `${matches.size} of ${tools.length} tools match`
            : `${tools.length} tools, all running in your browser`}
        </p>
      </div>

      {matches.size === 0 && (
        <p className="rounded-lg border border-border bg-surface px-4 py-6 text-center text-sm text-foreground-muted">
          Nothing matches <span className="font-mono text-foreground">{query}</span>. The filter
          searches names, descriptions and the alternative names each tool is known by — so try the
          file format you have, or the one you want.
        </p>
      )}

      {grouped.map(({ category, tools: inCategory }) => {
        const visible = inCategory.filter((tool) => matches.has(tool.href));
        if (visible.length === 0) return null;

        return (
          <section key={category.id} aria-labelledby={`group-${category.id}`}>
            <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2 border-b border-border pb-2">
              <h2
                id={`group-${category.id}`}
                className="text-sm font-semibold tracking-tight text-foreground"
              >
                {category.title}
                <span className="ml-2 font-normal text-foreground-subtle">{visible.length}</span>
              </h2>
              <Link
                href={category.hub}
                className="flex items-center gap-1 text-2xs text-accent transition-colors hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                {category.blurb}
                <Icon name="arrowRight" size="sm" />
              </Link>
            </div>

            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
              {inCategory.map((tool) => (
                <li key={tool.href} hidden={!matches.has(tool.href)}>
                  <Link
                    href={tool.href}
                    className="group flex h-full gap-3 rounded-lg border border-border bg-surface p-3 transition-colors hover:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  >
                    <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded border border-border bg-surface-elevated text-accent">
                      <Icon name={tool.icon} size="md" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                        <span className="text-sm font-semibold tracking-tight text-foreground">
                          {tool.name}
                        </span>
                        <span className="rounded-pill bg-surface-elevated px-2 text-2xs text-foreground-subtle">
                          {tool.tag}
                        </span>
                      </span>
                      <span className="mt-1 block text-xs leading-relaxed text-foreground-muted">
                        {tool.description}
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
};
