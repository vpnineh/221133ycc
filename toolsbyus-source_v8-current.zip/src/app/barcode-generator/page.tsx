import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { BarcodeGeneratorClient } from "./BarcodeGeneratorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/barcode-generator",
  title: "Barcode Generator — Code 128, EAN and UPC",
  socialTitle: "Barcode Generator",
  description:
    "Generate Code 128, EAN-13, EAN-8, UPC-A, Code 39 and ITF-14 barcodes as SVG or PNG. Check digits calculated, quiet zones kept, print width in millimetres.",
});

export default function BarcodeGeneratorPage() {
  return <BarcodeGeneratorClient />;
}
