import React from "react";
import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import {
  absoluteUrl,
  SITE_NAME,
  CONTENT_FIRST_PUBLISHED,
  CONTENT_LAST_REVIEWED,
} from "../../lib/site";
import FaqSection from "@/components/common/FaqSection";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import { ToolPageFrame } from "@/components/tools/ToolPageFrame";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import Base64Client from "./Base64Client";
import Link from "next/link";

export const metadata: Metadata = buildToolMetadata({
  path: "/base64-decode",
  title: "Base64 Encode and Decode — Text and Files",
  socialTitle: "Base64",
  description:
    "Free Base64 decoder and encoder. Decode to text, hex or binary download, handle URL-safe input, and inspect JWT headers and claims — all in your browser.",
});

const faqs = [
  {
    question: "How does Base64 encoding represent binary data as ASCII text?",
    answer:
      "Base64 operates on 24-bit chunks of binary data, which corresponds to 3 standard 8-bit bytes. These 24 bits are partitioned into four 6-bit groups (since 2^6 = 64). Each 6-bit integer (ranging from 0 to 63) maps directly to a predefined index table consisting of uppercase A-Z (0-25), lowercase a-z (26-51), digits 0-9 (52-61), plus '+' (62), and '/' (63). If the input byte length is not divisible by 3, the final block is padded with zero bits, and '=' padding characters are appended to satisfy the 4-character alignment constraint.",
  },
  {
    question: "What is the difference between standard Base64 and URL-safe Base64?",
    answer:
      "Standard Base64 according to RFC 4648 uses '+' (index 62) and '/' (index 63), and pad characters '='. In URLs, filenames, and HTTP query strings, '+' denotes a space, and '/' acts as a path delimiter, which causes parsing ambiguities or requires percentage escaping. RFC 4648 Section 5 defines URL-safe Base64 (base64url), replacing '+' with '-' (hyphen) and '/' with '_' (underscore), while often omitting trailing '=' padding characters altogether. JWTs (RFC 7519) strictly mandate the URL-safe base64url alphabet without padding.",
  },
  {
    question: "Can I decode Base64 data containing sensitive passwords or tokens here safely?",
    answer:
      "Yes, completely. ToolsByUs executes 100% locally within your browser's V8 JavaScript engine. Zero network requests, zero API calls, zero telemetry, and zero server logging occur when you paste or process payloads. You can disconnect your internet connection or inspect your browser's DevTools Network panel to independently verify zero data transmission.",
  },
  {
    question: "How does the tool automatically detect and inspect JSON Web Tokens (JWT)?",
    answer:
      "A standard JWT consists of three base64url-encoded parts separated by period '.' delimiters: header, payload, and signature. When you paste an input containing two periods separating base64url strings, the parser decodes the first two segments. If both segments parse into valid JSON containing typical JWT properties such as 'alg', 'typ', or registered claims ('exp', 'sub', 'iat'), the tool immediately displays decoded JSON cards alongside human-readable expiration dates.",
  },
  {
    question: "How does the binary file download guess MIME types and file extensions?",
    answer:
      "When decoding Base64 back into raw Uint8Array bytes, the decoder reads the file's 'magic bytes' (initial header signature). For instance, PNG files begin with 0x89 0x50 0x4E 0x47 ('\\x89PNG'), JPEG begins with 0xFF 0xD8 0xFF, PDF begins with 0x25 0x50 0x44 0x46 ('%PDF'), and ZIP begins with 0x50 0x4B 0x03 0x04 ('PK'). Based on these magic signatures, the browser synthesizes a typed Blob for direct local download.",
  },
];

export default function Base64Page() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "@id": `${absoluteUrl("/base64-decode")}#webpage`,
      url: absoluteUrl("/base64-decode"),
      name: "Base64 Decode & Encode",
      inLanguage: "en",
      datePublished: CONTENT_FIRST_PUBLISHED,
      dateModified: CONTENT_LAST_REVIEWED,
      author: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
      publisher: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
    },
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      name: "Base64 Decode & Encode",
      url: absoluteUrl("/base64-decode"),
      description:
        "Decode and encode Base64 payloads, strings, files, and JWTs entirely in-browser with zero telemetry and total privacy.",
      applicationCategory: "DeveloperApplication",
      operatingSystem: "Any",
      browserRequirements: "Requires a modern browser with JavaScript enabled",
      // These three pages predate ToolShell and build their own graph, so they
      // were the only tools on the site not declaring that they are free — the
      // signal an aggregator or an AI answer reads to say "no sign-up".
      isAccessibleForFree: true,
      offers: {
        "@type": "Offer",
        price: "0",
        priceCurrency: "USD",
        availability: "https://schema.org/InStock",
      },
      featureList: [
        "Standard and URL-safe (RFC 4648 §5) alphabets",
        "Binary output downloaded as a file",
        "UTF-8 and Latin-1 text handling",
        "JWT header and payload inspection",
        "Runs entirely in the browser, no upload",
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Base64 Decode",
          item: absoluteUrl("/base64-decode"),
        },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: f.answer,
        },
      })),
    },
  ];

  return (
    <>
      <SchemaJsonLd schemas={jsonLdData} />

      <ToolPageFrame
        keyword="Base64 Decode & Encode"
        category="encode"
        breadcrumbs={[
          { label: "Base64 Decode & Encode", href: "/base64-decode" },
        ]}
        directAnswer={
          <>
            Base64 Decode & Encode converts text and binary data between raw bytes and the RFC 4648 Base64 and base64url alphabets, handles line-wrapped MIME input, and automatically detects JSON Web Tokens to show their header and claims. Everything runs locally; tokens are decoded, never transmitted.
          </>
        }
        tool={<Base64Client />}
      >


      {/* Technical Documentation Section (>= 700 words) */}
      <section className="space-y-5">
        <h2 className="heading-hash">
          How does Base64 encoding work?
        </h2>

        <p className="text-sm text-foreground-muted leading-relaxed">
          Base64 is one of the foundational encoding algorithms of computer networking and modern web
          systems, specified formally in <strong>RFC 4648</strong> (and historically in RFC 1421 and
          RFC 2045). Its primary purpose is not encryption or obfuscation, but rather safe binary-to-text
          serialization. Many legacy protocols—notably early SMTP email systems, HTTP header parsers,
          and XML document schemas—were originally engineered to transmit 7-bit ASCII characters reliably.
          When raw 8-bit binary payloads such as JPEG images, compiled WebAssembly modules, cryptographic keys,
          or encrypted blocks are transmitted across arbitrary gateways, unprintable control characters
          (such as NULL bytes, CR, LF, or byte sequences with the high bit set) can be misinterpreted or
          stripped by intermediate proxies. Base64 resolves this vulnerability by projecting any sequence
          of arbitrary 8-bit bytes into a universally recognized 64-character subset of ASCII printable characters.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          The 24-Bit to 32-Bit Transformation Pipeline
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          The underlying arithmetic of Base64 is remarkably elegant and mathematically deterministic.
          The encoder processes the input byte stream in sequential blocks of 3 bytes (24 bits). Because
          each standard Base64 character represents 6 bits of information (\(2^6 = 64\)), each 24-bit block
          is cleanly partitioned into exactly four 6-bit indices. Each index (a number ranging from 0 to 63)
          corresponds to an entry in the standard Base64 lookup table:
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-1 font-mono">
          <li>Indices 0 through 25 represent uppercase letters <code>A</code> through <code>Z</code></li>
          <li>Indices 26 through 51 represent lowercase letters <code>a</code> through <code>z</code></li>
          <li>Indices 52 through 61 represent numerals <code>0</code> through <code>9</code></li>
          <li>Index 62 represents the plus symbol <code>+</code></li>
          <li>Index 63 represents the forward slash <code>/</code></li>
        </ul>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Because 3 input bytes (24 bits) produce 4 output characters (32 bits), Base64 encoding inherently
          introduces a constant 33.33% payload expansion ratio (\(\frac{4}{3}\)). When combined with
          potential line wrapping or URL escaping, the resulting footprint is always roughly one-third
          larger than the source binary data. For small tokens, cryptographic signatures, or inline images,
          this overhead is negligible compared to the interoperability guarantees it provides.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Padding Rules and Tail-End Byte Alignment
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Because real-world payloads rarely have byte lengths that are exact multiples of 3, the Base64
          specification specifies rigorous padding semantics using the equals sign (<code>=</code>):
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-2">
          <li className="text-sm text-foreground-muted">
            <strong>Remainder of 1 Byte (8 bits):</strong> When an input stream terminates with a single
            unpaired byte, those 8 bits are padded on the right with four zero bits to create a 12-bit
            sequence. This yields two 6-bit Base64 characters. To preserve the mandatory 4-character block
            boundary, two padding characters (<code>==</code>) are appended at the end.
          </li>
          <li className="text-sm text-foreground-muted">
            <strong>Remainder of 2 Bytes (16 bits):</strong> When an input stream terminates with two
            unpaired bytes, those 16 bits are padded with two zero bits to create an 18-bit sequence. This
            yields three 6-bit Base64 characters. A single padding character (<code>=</code>) is appended
            to complete the 4-character block.
          </li>
        </ul>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Standard Base64 vs. URL-Safe Base64 (base64url)
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Standard RFC 4648 Base64 relies on <code>+</code> and <code>/</code> for indices 62 and 63.
          However, within URI path segments, query strings, and form-urlencoded POST requests, both of
          these characters possess reserved syntactical meanings. In URIs, <code>+</code> represents an
          encoded whitespace character, while <code>/</code> denotes structural directory hierarchy. If
          standard Base64 strings are placed directly in URLs without percent-encoding (e.g. <code>%2B</code>
          and <code>%2F</code>), backend web servers frequently corrupt the payload before decoding.
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed">
          To eliminate this hazard, RFC 4648 Section 5 standardized the <strong>URL-Safe Alphabet</strong> (often
          abbreviated as <code>base64url</code>). In this variant, <code>+</code> is replaced with <code>-</code>
          (hyphen) and <code>/</code> is replaced with <code>_</code> (underscore). Trailing equals-sign
          padding is dropped too, because the length of the string modulo 4 provides
          sufficient mathematical information to reconstruct missing bits upon decoding. Modern web standards—most
          prominently JSON Web Tokens (RFC 7519), WebAuthn credentials, and OAuth 2.0 PKCE code verifiers—mandate
          the base64url specification exclusively.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Anatomy of JSON Web Tokens (JWT)
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          A JSON Web Token (RFC 7519) is a compact, URL-safe means of representing signed claims between two
          parties. Every JWT is structured into three distinct base64url segments separated by ASCII periods:
        </p>
        <div className="bg-surface p-4 rounded-lg border border-border font-mono text-xs space-y-2">
          <p className="text-accent font-bold">1. Header (base64url): Declares algorithm and token type (e.g. {`{"alg": "HS256", "typ": "JWT"}`})</p>
          <p className="text-accent font-bold">2. Payload (base64url): Contains identity claims, issuer (iss), subject (sub), and expiration timestamp (exp)</p>
          <p className="text-warn font-bold">3. Signature: Cryptographic hash or signature verifying that the header and payload have not been tampered with</p>
        </div>
        <p className="text-sm text-foreground-muted leading-relaxed">
          The ToolsByUs Base64 tool automatically evaluates the token geometry of any pasted string.
          When three period-delimited segments with valid JSON structures are encountered, it immediately
          renders an inspection interface detailing human-readable dates and claim breakdowns without sending
          secret JWTs over any network.
        </p>
      </section>

      {/* Keyboard Shortcuts Reference */}
      <section className="rounded-xl bg-surface p-6 space-y-4">
        <h2 className="heading-hash">
          Which keyboard shortcuts does the Base64 decoder support?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Tab / Shift+Tab</span>
            <span className="text-foreground-muted">Cycle between input textarea, mode toggles, and copy buttons</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Ctrl + Enter / Cmd + Enter</span>
            <span className="text-foreground-muted">Instantly focus output result and activate hex view</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Escape</span>
            <span className="text-foreground-muted">Deselect active editor and clear transient selections</span>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FaqSection faqs={faqs} />

      {/* Related Tools */}
      <section className="space-y-4">
        <h2 className="heading-hash">
          Which related tools should I use next?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link
            href="/json-editor"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Editor & Tree Viewer &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Inspect decoded JSON tokens in an interactive collapsible tree view.
            </p>
          </Link>
          <Link
            href="/json-validator"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Validator & Repair &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Diagnose syntax faults and auto-repair corrupted payload strings.
            </p>
          </Link>
          <Link
            href="/diff-checker"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              Diff Checker &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Compare base64 decoded plaintext files or configuration scripts side by side.
            </p>
          </Link>
        </div>
      </section>

      <ReviewedStamp href="/base64-decode" />
      </ToolPageFrame>
    </>
  );

}
