"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { checkbox, fieldLabel } from "../../components/common/controls";
import { convertCase, splitWords, CASE_EXAMPLES, CASE_DEFAULTS } from "../../lib/text/case";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `userFirstName
XMLHttpRequest
API_BASE_URL
order-line-item
2fa_backup_codes`;

export const CaseConverterClient: React.FC = () => {
  const [input, setInput] = useState(SAMPLE);
  const [localeAware, setLocaleAware] = useState(false);
  const [preserveAcronyms, setPreserveAcronyms] = useState(false);

  const lines = useMemo(() => input.split("\n"), [input]);

  const results = useMemo(
    () =>
      CASE_EXAMPLES.map((style) => ({
        ...style,
        output: lines
          .map((line) =>
            line.trim() === ""
              ? ""
              : convertCase(line, {
                  ...CASE_DEFAULTS,
                  style: style.style,
                  localeAware,
                  preserveAcronyms,
                })
          )
          .join("\n"),
      })),
    [lines, localeAware, preserveAcronyms]
  );

  const firstWords = useMemo(
    () => (lines[0]?.trim() ? splitWords(lines[0]) : []),
    [lines]
  );

  return (
    <ToolShell
      wide
      slug="case-converter"
      keyword="Case Converter"
      directAnswer="Case Converter rewrites identifiers between camelCase, PascalCase, snake_case, kebab-case, CONSTANT_CASE and nine more, in your browser. The conversion is trivial; the hard part is splitting the input into words — XMLHttpRequest is three words, user2fa is three, and a converter that gets those wrong produces output nobody wants."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "Case Converter", url: "/case-converter" },
      ]}
      seoDescription="Convert text between camelCase, PascalCase, snake_case, kebab-case, CONSTANT_CASE, Title Case and more in the browser. Correct word splitting for acronyms and digits, Unicode aware."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Every naming convention is the same list of words rendered differently, so converting
              between them is one problem — splitting the input into words — followed by a trivial
              join. Converters differ entirely in the first step.
            </p>
            <h3>Three word boundaries, in order of how often they are missed</h3>
            <p>
              A lower-to-upper transition is the obvious one: <code>userName</code> is two words. An
              acronym followed by a word is the one most converters get wrong:{" "}
              <code>XMLHttpRequest</code> is <code>XML Http Request</code>, not one word and not
              eight. A letter-to-digit transition is the one nobody thinks about:{" "}
              <code>user2fa</code> is <code>user 2 fa</code>, which is why{" "}
              <code>user2fa</code> becomes <code>user_2_fa</code> rather than{" "}
              <code>user2fa</code>.
            </p>
            <p>
              Separators — space, underscore, hyphen, dot, slash — are all treated identically, which
              is what lets the tool accept input in any convention without being told which. You do
              not pick a source format, because there is nothing to pick.
            </p>
            <h3>The Turkish I</h3>
            <p>
              <code>&quot;I&quot;.toLocaleLowerCase()</code> is <code>&quot;ı&quot;</code> — a
              dotless i — in Turkish and Azeri, not <code>&quot;i&quot;</code>. That is correct for
              those languages and catastrophic for code: every case-insensitive comparison against
              an ASCII string fails, and an identifier named <code>ID</code> becomes something a
              compiler does not recognise. So casing here is locale-independent by default, with
              locale-aware casing available for prose, where it is the right answer.
            </p>
            <h3>Prose styles change capitalisation, not structure</h3>
            <p>
              Sentence case and Title case operate on the text rather than on its words: punctuation,
              spacing and existing acronyms survive. Title case keeps minor words — a, an, the, of,
              to and the rest — lowercase unless they are first or last, which is the rule most
              English style guides share even though they disagree about the list.
            </p>
            <h3>Acronym preservation is a genuine choice</h3>
            <p>
              <code>user_id</code> to PascalCase is <code>UserId</code> or <code>UserID</code>
              depending on your language&apos;s conventions — Go&apos;s style guide requires the
              second, C#&apos;s requires the first for two-letter acronyms and the first for longer
              ones. Neither is wrong, so it is a toggle rather than a decision made for you.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `XMLHttpRequest`,
        outputTitle: "Converted",
        exampleOutput: `words        XML | Http | Request
camelCase    xmlHttpRequest
snake_case   xml_http_request
CONSTANT     XML_HTTP_REQUEST
kebab-case   xml-http-request`,
      }}
      referenceTable={{
        title: "Styles",
        rows: CASE_EXAMPLES.map((style) => ({
          parameter: style.label,
          type: style.style,
          defaultVal: style.example,
          description: describeStyle(style.style),
        })),
      }}
      faqs={[
        {
          question: "Why did XMLHttpRequest split into three words?",
          answer:
            "Because it is three. The rule is that an all-caps run followed by a capital and a lowercase letter ends a word at the boundary: XMLH-ttp becomes XML | Http. Without it you get either one word — xmlhttprequest — or eight, with every capital starting a new one: x_m_l_http_request. Both are wrong and both are common.",
        },
        {
          question: "Do I need to tell it what format my input is in?",
          answer:
            "No, and there is deliberately no option for it. Every separator is treated alike and every case boundary is detected, so camelCase, snake_case, kebab-case, dot.case and plain prose all split into the same word list. Mixed input works too, which matters when you are converting a list someone assembled from three codebases.",
        },
        {
          question: "Why is there a locale option for lowercasing?",
          answer:
            'Because "I".toLocaleLowerCase() is "ı" — a dotless i — in Turkish and Azeri. That is linguistically correct and disastrous for identifiers: an ASCII comparison against "id" fails, and code that lowercases user input to compare it against a keyword stops working for Turkish users. The option is off by default because the usual job here is code, and on for prose in those languages.',
        },
        {
          question: "UserId or UserID?",
          answer:
            "It depends on the language. Go's style guide requires UserID and capitalises every initialism — APIURL, HTTPServer. C# and Java use UserId, capitalising only the first letter of an acronym longer than two characters. Neither is more correct; use whichever matches the code around it, which is why this is a toggle.",
        },
        {
          question: "Can it convert a whole file of identifiers?",
          answer:
            "One per line, yes — each line is converted independently, so you can paste a column out of a schema or a config and get the whole thing back. It is not a code-aware rename: it does not know which words in a line are identifiers and which are syntax, so it converts the whole line as one name.",
        },
        {
          question: "Is my text uploaded?",
          answer:
            "No. It is string manipulation, running in your browser. The identifiers people convert describe internal systems — table names, field names, feature flags — which is not secret exactly, and is also not something to hand to an unknown server for no reason.",
        },
      ]}
      relatedTools={relatedTools("/case-converter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          {[
            {
              id: "case-locale",
              label: "Locale-aware casing",
              checked: localeAware,
              onChange: setLocaleAware,
              title: "Turns I into ı in Turkish. Right for prose, wrong for identifiers.",
            },
            {
              id: "case-acronyms",
              label: "Preserve acronyms",
              checked: preserveAcronyms,
              onChange: setPreserveAcronyms,
              title: "UserID rather than UserId, which is what Go's style guide requires.",
            },
          ].map((toggle) => (
            <label
              key={toggle.id}
              htmlFor={toggle.id}
              title={toggle.title}
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id={toggle.id}
                type="checkbox"
                checked={toggle.checked}
                onChange={(e) => toggle.onChange(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>{toggle.label}</span>
            </label>
          ))}

          {firstWords.length > 0 && (
            <span className="ml-auto font-mono text-2xs text-foreground-subtle">
              first line splits as {firstWords.join(" · ")}
            </span>
          )}
        </div>

        <CodePane
          label="Input (one identifier per line)"
          value={input}
          onChange={setInput}
          placeholder="Paste identifiers, one per line…"
          height={180}
        />

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {results.map((result) => (
            <div key={result.style} className="rounded-lg border border-border bg-surface">
              <div className="flex items-center justify-between border-b border-border px-3 py-1.5">
                <span className="font-mono text-2xs uppercase tracking-wide text-foreground-subtle">
                  {result.label}
                </span>
                <button
                  type="button"
                  onClick={() => void navigator.clipboard.writeText(result.output).catch(() => {})}
                  className="cursor-pointer rounded px-1.5 font-mono text-2xs text-foreground-subtle transition-colors hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  copy
                </button>
              </div>
              <pre className="overflow-x-auto px-3 py-2 font-mono text-xs text-foreground">
                {result.output || " "}
              </pre>
            </div>
          ))}
        </div>

        {localeAware && (
          <Notice tone="warn">
            Locale-aware casing follows your browser&apos;s language. In Turkish and Azeri that turns{" "}
            <code>I</code> into <code>ı</code> rather than <code>i</code>, which breaks every
            case-insensitive comparison against an ASCII string. Correct for prose; wrong for
            identifiers.
          </Notice>
        )}
      </div>
    </ToolShell>
  );
};

function describeStyle(style: string): string {
  const notes: Record<string, string> = {
    camel: "JavaScript and Java variables and functions. First word lowercase, the rest capitalised.",
    pascal: "Type names in almost every language: classes, interfaces, React components.",
    snake: "Python and Ruby identifiers, and SQL column names on Postgres.",
    constant: "Environment variables and compile-time constants in C, Java, Go and JavaScript.",
    kebab: "URLs, CSS custom properties and class names, npm package names. Not a legal identifier in most languages.",
    train: "HTTP header names — Content-Type, X-Request-Id — which are case-insensitive but conventionally written this way.",
    dot: "Nested configuration keys, i18n message keys, and Java package-style namespaces.",
    path: "URL path segments and file paths built from a name.",
    sentence: "Prose. Capitalises the first letter of each sentence and leaves the rest alone, so existing acronyms survive.",
    title: "Headings. Minor words stay lowercase unless first or last.",
    lower: "The whole string lowercased, punctuation and spacing untouched.",
    upper: "The whole string uppercased.",
    alternating: "Alternating case, character by character.",
    inverse: "Every letter's case flipped.",
  };
  return notes[style] ?? "";
}
