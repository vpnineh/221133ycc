import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CaseConverterClient } from "./CaseConverterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/case-converter",
  title: "Case Converter — camelCase, snake_case, 12 More",
  socialTitle: "Case Converter",
  description:
    "Convert between camelCase, PascalCase, snake_case, kebab-case, CONSTANT_CASE and more in your browser. Splits XMLHttpRequest into three words, not one.",
});

export default function CaseConverterPage() {
  return <CaseConverterClient />;
}
