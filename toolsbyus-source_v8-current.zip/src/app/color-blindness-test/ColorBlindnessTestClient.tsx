"use client";

import { usePageFileDrop } from "../../components/tools/usePageFileDrop";
import { MAX_FILE_BYTES } from "../../lib/files";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Icon } from "../../components/common/Icon";
import { relatedTools } from "../../lib/tools";
import {
  CVD_TYPES,
  parseColor,
  simulateCvd,
  simulateCvdPixels,
  toHex,
  type Cvd,
} from "../../lib/color";
import {
  findConfusionPair,
  jitterLightness,
  layoutPlate,
  PLATES,
  type PlateType,
} from "../../lib/color/plates";

const PLATE_SIZE = 300;

/**
 * Pairs are searched for once, not once per plate.
 *
 * `findConfusionPair` scans a few hundred thousand hue combinations, which is
 * milliseconds but is not free, and the answer for a given deficiency never
 * changes. Computing it lazily and caching keeps it off the page-load path
 * entirely — nothing here runs until somebody starts the test.
 */
const pairCache = new Map<PlateType, ReturnType<typeof findConfusionPair>>();
function pairFor(type: PlateType) {
  const cached = pairCache.get(type);
  if (cached) return cached;
  const found = findConfusionPair(type);
  pairCache.set(type, found);
  return found;
}

/**
 * Draws one plate.
 *
 * The digits are rendered to an offscreen canvas and read back as a mask,
 * rather than described as vector outlines: it means the figure is whatever the
 * visitor's own font draws, it handles two-digit answers without any layout
 * arithmetic, and there is no set of hand-traced number shapes to get subtly
 * wrong.
 */
function drawPlate(
  canvas: HTMLCanvasElement,
  answer: string,
  type: PlateType | null,
  seed: number
): void {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = PLATE_SIZE * dpr;
  canvas.height = PLATE_SIZE * dpr;
  const context = canvas.getContext("2d");
  if (!context) return;
  context.scale(dpr, dpr);
  context.clearRect(0, 0, PLATE_SIZE, PLATE_SIZE);

  // ---- The figure mask --------------------------------------------------
  const mask = document.createElement("canvas");
  mask.width = PLATE_SIZE;
  mask.height = PLATE_SIZE;
  const maskContext = mask.getContext("2d", { willReadFrequently: true });
  if (!maskContext) return;
  maskContext.fillStyle = "#000";
  maskContext.font = `bold ${PLATE_SIZE * 0.52}px ui-sans-serif, system-ui, sans-serif`;
  maskContext.textAlign = "center";
  maskContext.textBaseline = "middle";
  maskContext.fillText(answer, PLATE_SIZE / 2, PLATE_SIZE / 2);
  const maskData = maskContext.getImageData(0, 0, PLATE_SIZE, PLATE_SIZE).data;

  const inFigure = (nx: number, ny: number) => {
    const x = Math.floor(nx * PLATE_SIZE);
    const y = Math.floor(ny * PLATE_SIZE);
    if (x < 0 || y < 0 || x >= PLATE_SIZE || y >= PLATE_SIZE) return false;
    return maskData[(y * PLATE_SIZE + x) * 4 + 3] > 128;
  };

  // ---- Colours ----------------------------------------------------------
  // A control plate is drawn in a pair nobody confuses, so a miss means the
  // screen, the lighting or the instructions rather than colour vision.
  const pair = type
    ? pairFor(type)
    : {
        figure: parseColor("#b3261e")!,
        ground: parseColor("#d8d8d0")!,
        separation: 0,
        residual: 0,
      };

  for (const dot of layoutPlate(PLATE_SIZE, inFigure, seed)) {
    const base = dot.inFigure ? pair.figure : pair.ground;
    context.beginPath();
    context.arc(dot.x, dot.y, dot.r, 0, Math.PI * 2);
    context.fillStyle = toHex(jitterLightness(base, dot.jitter));
    context.fill();
  }
}

type Answer = { plate: number; given: string; correct: boolean };

export const ColorBlindnessTestClient: React.FC = () => {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [entry, setEntry] = useState("");
  const [started, setStarted] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const plate = PLATES[index];
  const finished = index >= PLATES.length;

  useEffect(() => {
    if (!started || finished || !canvasRef.current) return;
    drawPlate(canvasRef.current, plate.answer, plate.type, plate.seed);
  }, [started, finished, plate]);

  const submit = useCallback(() => {
    const given = entry.trim();
    setAnswers((previous) => [
      ...previous,
      { plate: index, given, correct: given === plate.answer },
    ]);
    setEntry("");
    setIndex((previous) => previous + 1);
  }, [entry, index, plate]);

  /**
   * What the answers indicate — stated as an indication, because that is all it
   * is. The controls are checked first: if those were missed, nothing else in
   * the result is worth reading.
   */
  const result = useMemo(() => {
    if (!finished) return null;
    const controlsMissed = answers.filter(
      (answer) => PLATES[answer.plate].type === null && !answer.correct
    ).length;

    const missedBy = (type: PlateType) =>
      answers.filter((answer) => PLATES[answer.plate].type === type && !answer.correct).length;
    const totalFor = (type: PlateType) => PLATES.filter((p) => p.type === type).length;

    const redGreen = missedBy("deuteranopia") + missedBy("protanopia");
    const redGreenTotal = totalFor("deuteranopia") + totalFor("protanopia");
    const blueYellow = missedBy("tritanopia");
    const blueYellowTotal = totalFor("tritanopia");

    return { controlsMissed, redGreen, redGreenTotal, blueYellow, blueYellowTotal };
  }, [finished, answers]);

  return (
    <ToolShell
      slug="color-blindness-test"
      keyword="Color Blindness Test"
      directAnswer="Color Blindness Test shows eight plates of coloured dots with a number hidden in them, where the number is separated from its background only by colour and not by brightness. The plates are generated here rather than scanned from the Ishihara set, and their colours are chosen by simulating each deficiency and keeping the pairs that collapse under it. It is a screening indication on an uncalibrated screen, not a diagnosis."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "Color Blindness Test", url: "/color-blindness-test" },
      ]}
      seoDescription="Take a colour blindness test for red-green and blue-yellow vision with plates generated in your browser, then see any colour or image as it appears with protanopia, deuteranopia, tritanopia or achromatopsia."
      howItWorks={{
        inputTitle: "What you see",
        outputTitle: "What it indicates",
        exampleInput: `8 plates
2 controls everyone reads
4 red-green
2 blue-yellow`,
        exampleOutput: `controls   2 / 2 read
red-green  4 / 4 read
blue-yellow 2 / 2 read

No indication of a deficiency.`,
        algorithmExplanation: (
          <>
            <p>
              A pseudo-isochromatic plate hides a figure in a field of dots where the figure and
              the ground differ only in hue. Someone whose colour vision separates those two hues
              reads the number immediately; someone whose does not sees an even field. The dots
              vary in size and tone so the figure cannot be found by shape, edge or brightness —
              which is what makes it a test of colour rather than of eyesight.
            </p>
            <h3>Why these plates are generated rather than scanned</h3>
            <p>
              The Ishihara plates are a specific copyrighted set from 1917, and the scans
              circulating online have been through a scanner, a compression pass and whatever
              colour profile the page was saved with. By the time one reaches your screen the exact
              hues it depends on have moved, which is most of the reason online colour-vision tests
              disagree with each other. Nothing here is reproduced from that set.
            </p>
            <h3>How the colours are chosen</h3>
            <p>
              Not from a table. For each deficiency the page searches hue pairs and keeps the one
              that is furthest apart in OKLab <em>before</em> simulation and closest together{" "}
              <em>after</em> it, using the same Machado matrices the simulator below uses. A pair
              qualifies only if the two colours land on top of each other for that deficiency.
            </p>
            <p>
              That search is why protanopia and deuteranopia get different plates. Both are
              red-green deficiencies and it is tempting to treat them as one, but the classic
              pink-and-green deutan pair stays clearly separable under protanopia — so a test using
              one pair for &ldquo;red-green&rdquo; would miss protans entirely. The pair it finds
              for protanopia is a violet and a blue, which looks nothing like what you would
              expect and is exactly what the simulation says.
            </p>
            <h3>The control plates</h3>
            <p>
              The first and last plates use colours nobody confuses. They are not filler: if those
              are missed, the problem is the screen, the room light or the instructions, and the
              rest of the result should be thrown away rather than reported. Any test without them
              is reporting confidently on data it has not checked.
            </p>
            <h3>What this cannot tell you</h3>
            <p>
              Severity, and the difference between full dichromacy and the far more common
              anomalous trichromacy. It also cannot correct for your screen: uncalibrated displays
              vary enough that a borderline result may be about the monitor. A clinical diagnosis
              uses an anomaloscope under controlled lighting, and if the result here matters to you
              — for a licence, a job, a medical question — that is the test to ask for.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "The four types, and who has them",
        rows: [
          {
            parameter: "Deuteranomaly",
            type: "green, reduced",
            defaultVal: "≈5% of men",
            description:
              "The most common form by a wide margin. The green cone is shifted rather than missing, so reds and greens are muddled but not identical.",
          },
          {
            parameter: "Deuteranopia",
            type: "green, absent",
            defaultVal: "≈1.1% of men",
            description: "No green cone at all. Red and green collapse to a shared yellow-brown.",
          },
          {
            parameter: "Protanopia",
            type: "red, absent",
            defaultVal: "≈1.0% of men",
            description:
              "No red cone. Reds darken as well as shifting, so red text on a dark background can disappear entirely.",
          },
          {
            parameter: "Tritanopia",
            type: "blue, absent",
            defaultVal: "≈0.01%",
            description:
              "No blue cone. Blue and green converge and yellow reads as pink. Not sex-linked, so it affects men and women equally.",
          },
          {
            parameter: "Achromatopsia",
            type: "no colour",
            defaultVal: "≈0.003%",
            description:
              "Complete absence of colour vision. The honest test of whether a design still works on lightness alone.",
          },
          {
            parameter: "Overall",
            type: "—",
            defaultVal: "8% / 0.5%",
            description:
              "About one man in twelve and one woman in two hundred has some form. The genes for the red and green cones are on the X chromosome, which is why.",
          },
          {
            parameter: "Plates here",
            type: "8",
            defaultVal: "2 controls",
            description:
              "Four red-green and two blue-yellow, bracketed by two plates everyone should read.",
          },
          {
            parameter: "Diagnosis",
            type: "—",
            defaultVal: "anomaloscope",
            description:
              "A clinical test under controlled lighting. Nothing on an uncalibrated screen replaces it.",
          },
        ],
      }}
      faqs={[
        {
          question: "How accurate is an online colour blindness test?",
          answer:
            "Good enough to tell you whether to see an optometrist, and not good enough for anything else. Your screen is not calibrated, the ambient light is unknown, and a borderline result may be about the monitor rather than your eyes. This test at least generates its plates from the actual simulation rather than using a scanned image that has been through compression and a colour profile, and it brackets the result with control plates so an obviously invalid run can be discarded. It still cannot tell you severity, and it cannot distinguish full dichromacy from the much more common anomalous form.",
        },
        {
          question: "What does it mean if I miss the red-green plates but read the rest?",
          answer:
            "It is consistent with a red-green deficiency — deuteranomaly or deuteranopia if the greens confuse, protan if the reds also look darker than expected. That is about one man in twelve. It is worth confirming with an optometrist, particularly if you work with colour-coded information or are applying for a licence that tests for it. It is also worth knowing that most people with it navigate the world without difficulty and discover it in a test like this one.",
        },
        {
          question: "Why are your plates different from the Ishihara ones I have seen?",
          answer:
            "Because these are generated, not reproduced. The Ishihara set is copyrighted, and the scans circulating online have lost the colour accuracy the test depends on. These plates pick their colours by simulating each deficiency and keeping pairs that collapse under it, which means they are correct for the simulation rather than correct in 1917 and degraded since. A side effect: the protanopia plates use a violet and a blue rather than the red and green you would expect, because that is the pair the simulation says protanopia cannot separate.",
        },
        {
          question: "Can colour blindness be cured or corrected?",
          answer:
            "No, and the tinted glasses sold for it do not correct it either — they increase the separation between some confusable colours at the cost of distorting others, which some people find useful and many do not. Nothing restores a missing cone type. Gene therapy has restored colour vision in animal models and is not a clinical treatment for humans.",
        },
        {
          question: "How do I design something that works for colour-blind users?",
          answer:
            "Never let colour be the only carrier of meaning. A red and green status dot becomes two identical dots for one man in twelve; add a shape, an icon or a word and it works for everyone. Keep contrast high, because deficiency reduces the separation you have to work with. And check your work with the simulator below — pasting your own chart or interface into it is faster than reasoning about it, and considerably more convincing.",
        },
        {
          question: "Does this send my answers or my image anywhere?",
          answer:
            "No. The plates are drawn in this tab, your answers are held in the page and forgotten when you close it, and an image dropped into the simulator is decoded by your own browser. There is no server here to receive any of it.",
        },
      ]}
      relatedTools={relatedTools("/color-blindness-test").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-12">
        {/* ================= The test ================= */}
        <section aria-labelledby="plate-test-heading">
          <h2
            id="plate-test-heading"
            className="mb-1 text-lg font-semibold tracking-tight text-foreground"
          >
            The plate test
          </h2>
          <p className="mb-6 max-w-[62ch] text-sm leading-relaxed text-foreground-muted">
            Eight plates. Type the number you see, or leave it empty if you cannot see one. There
            is no time limit and no score to beat — an honest answer is the only useful one.
          </p>

          {!started ? (
            <div className="rounded-xl bg-surface-elevated p-8 text-center">
              <p className="mx-auto max-w-[46ch] text-base leading-relaxed text-foreground-muted">
                Sit at a normal distance in ordinary room light, with your screen at its usual
                brightness and any night-shift or blue-light filter turned off — those change the
                colours the test depends on.
              </p>
              <button
                type="button"
                onClick={() => setStarted(true)}
                className="mt-6 cursor-pointer rounded-pill bg-accent-solid px-7 py-3.5 text-base font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
              >
                Start the test
              </button>
            </div>
          ) : finished && result ? (
            <div className="rounded-xl bg-surface-elevated p-6 sm:p-8">
              <h3 className="text-xl font-semibold tracking-tight text-foreground">
                {result.controlsMissed > 0
                  ? "This run is not readable"
                  : result.redGreen === 0 && result.blueYellow === 0
                    ? "No indication of a colour vision deficiency"
                    : "Some plates were missed"}
              </h3>

              {result.controlsMissed > 0 ? (
                <p className="mt-2 max-w-[58ch] text-base leading-relaxed text-foreground-muted">
                  {result.controlsMissed} of the control plates was missed. Those use colours nobody
                  confuses, so the problem is the screen, the room light or the instructions rather
                  than colour vision — the rest of this run should be ignored. Try again with any
                  colour filter turned off.
                </p>
              ) : (
                <>
                  <dl className="mt-5 grid gap-4 sm:grid-cols-2">
                    {[
                      {
                        label: "Red-green plates",
                        missed: result.redGreen,
                        total: result.redGreenTotal,
                        note: "Protanopia and deuteranopia. About one man in twelve.",
                      },
                      {
                        label: "Blue-yellow plates",
                        missed: result.blueYellow,
                        total: result.blueYellowTotal,
                        note: "Tritanopia. Rare, and not sex-linked.",
                      },
                    ].map((row) => (
                      <div
                        key={row.label}
                        className={`rounded-lg p-4 ${row.missed === 0 ? "bg-add-soft" : "bg-warn-soft"}`}
                      >
                        <dt className="text-sm text-foreground-muted">{row.label}</dt>
                        <dd className="mt-1 text-lg font-semibold text-foreground">
                          {row.total - row.missed} of {row.total} read
                        </dd>
                        <p className="mt-1 text-sm text-foreground-muted">{row.note}</p>
                      </div>
                    ))}
                  </dl>
                  <p className="mt-5 max-w-[58ch] text-sm leading-relaxed text-foreground-muted">
                    {result.redGreen === 0 && result.blueYellow === 0
                      ? "Every plate was read correctly, which is what normal colour vision looks like on this test. It cannot rule out a mild anomaly — that needs a clinical test."
                      : "Missing plates on one axis is consistent with a deficiency on that axis. This is a screening indication on an uncalibrated screen, not a diagnosis; an optometrist can confirm it in a few minutes with an anomaloscope."}
                  </p>
                </>
              )}

              <button
                type="button"
                onClick={() => {
                  setAnswers([]);
                  setIndex(0);
                  setEntry("");
                }}
                className="mt-6 cursor-pointer rounded-pill bg-surface px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
              >
                Take it again
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-6">
              <p role="status" className="text-sm text-foreground-subtle">
                Plate {index + 1} of {PLATES.length}
              </p>
              <canvas
                ref={canvasRef}
                width={PLATE_SIZE}
                height={PLATE_SIZE}
                role="img"
                aria-label={`Plate ${index + 1}: a circle of coloured dots with a number hidden in it`}
                className="rounded-full bg-surface-elevated"
                style={{ width: PLATE_SIZE, height: PLATE_SIZE, maxWidth: "100%" }}
              />
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  submit();
                }}
                className="flex w-full max-w-sm flex-wrap items-end gap-3"
              >
                <div className="min-w-0 flex-1">
                  <label
                    htmlFor="plate-answer"
                    className="mb-2 block text-sm text-foreground-muted"
                  >
                    What number do you see?
                  </label>
                  <input
                    id="plate-answer"
                    type="text"
                    inputMode="numeric"
                    value={entry}
                    onChange={(event) => setEntry(event.target.value)}
                    autoComplete="off"
                    className="w-full rounded-lg bg-surface-elevated px-4 py-3 text-center font-mono text-xl text-foreground outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  />
                </div>
                <button
                  type="submit"
                  className="cursor-pointer rounded-pill bg-accent-solid px-6 py-3 text-sm font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  Next
                </button>
              </form>
              <button
                type="button"
                onClick={submit}
                className="cursor-pointer text-sm text-foreground-subtle underline underline-offset-4 transition-colors hover:text-foreground"
              >
                I cannot see a number
              </button>
            </div>
          )}
        </section>

        {/* ================= The simulator ================= */}
        <Simulator />
      </div>
    </ToolShell>
  );
};

/* ------------------------------------------------------------------------- */

/**
 * The simulator, which is the half of this page a designer came for.
 *
 * Takes a colour or an image and shows it as each deficiency sees it, using the
 * same Machado matrices as the plates. The image path draws to a canvas and
 * transforms the pixel buffer locally. The 100 MB file limit applies; decoding
 * is also subject to the browser’s memory limits.
 */
const Simulator: React.FC = () => {
  const [text, setText] = useState("#00696f");
  const [image, setImage] = useState<ImageBitmap | null>(null);
  const [fileError, setFileError] = useState("");
  const loadId = useRef(0);
  useEffect(() => () => { loadId.current++; }, []);
  const color = parseColor(text);

  // An ImageBitmap holds decoded pixels off the JS heap, and the browser will
  // not reclaim it on garbage collection. Closing the previous one on replace
  // and on unmount is the difference between a tool you can use all afternoon
  // and one that degrades with every file.
  useEffect(() => () => image?.close(), [image]);

  const onFile = useCallback(async (file: File | undefined) => {
    if (!file) return;
    const request = ++loadId.current;
    setFileError("");
    if (!file.type.startsWith("image/")) { setFileError("Choose an image file."); return; }
    if (file.size > MAX_FILE_BYTES) { setFileError("This image exceeds the 100 MB limit."); return; }
    try {
      const bitmap = await createImageBitmap(file);
      if (request !== loadId.current) { bitmap.close(); return; }
      setImage(bitmap);
    } catch {
      if (request === loadId.current) setFileError("This image could not be decoded. Please try another image.");
    }
  }, []);

  const { ref: dropRef, dragging } = usePageFileDrop(files => { void onFile(files[0]); });

  return (
    <div ref={dropRef}>
    <section aria-labelledby="simulator-heading">
      {dragging && <div role="status" className="pointer-events-none fixed inset-3 z-[100] flex items-center justify-center rounded-xl border-2 border-accent bg-background/95 p-6 text-xl font-semibold">Drop an image to preview color vision</div>}
      <h2 id="simulator-heading" className="mb-1 text-lg font-semibold tracking-tight text-foreground">
        See it the way they do
      </h2>
      <p className="mb-6 max-w-[62ch] text-sm leading-relaxed text-foreground-muted">
        Paste a colour, or drop a screenshot of your chart or interface. Everything is decoded and
        transformed in this tab.
      </p>

      <div className="mb-6 flex flex-wrap items-end gap-4">
        <div className="min-w-0 flex-1 basis-56">
          <label htmlFor="sim-color" className="mb-2 block text-sm text-foreground-muted">
            A colour
          </label>
          <input
            id="sim-color"
            type="text"
            value={text}
            onChange={(event) => setText(event.target.value)}
            spellCheck={false}
            className="w-full rounded-lg bg-surface-elevated px-4 py-3 font-mono text-base text-foreground outline-none focus-visible:ring-2 focus-visible:ring-accent"
          />
        </div>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-pill bg-surface-elevated px-5 py-3 text-sm font-medium text-foreground transition-colors hover:bg-border focus-within:ring-2 focus-within:ring-accent pointer-coarse:min-h-[44px]">
          <Icon name="upload" size="md" className="text-foreground-subtle" />
          {image ? "Use a different image" : "Or drop an image"}
          <input
            type="file"
            accept="image/*"
            onChange={event => { void onFile(event.target.files?.[0]); event.target.value = ""; }}
            className="sr-only"
          />
        </label>
        {image && (
          <button
            type="button"
            onClick={() => {
              loadId.current++;
              setFileError("");
              setImage(null);
            }}
            className="cursor-pointer text-sm text-foreground-subtle underline underline-offset-4 hover:text-foreground"
          >
            Clear the image
          </button>
        )}
      </div>

      {fileError && <p role="alert" className="mb-4 text-sm text-danger">{fileError}</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[{ id: null, label: "Normal vision", blurb: "What you are seeing now." }, ...CVD_TYPES].map(
          (entry) => (
            <figure key={entry.label} className="min-w-0">
              {image ? (
                <SimulatedImage image={image} type={entry.id as Cvd | null} />
              ) : (
                <div
                  className="h-28 rounded-lg"
                  style={{
                    backgroundColor: color
                      ? toHex(entry.id ? simulateCvd(color, entry.id as Cvd) : color)
                      : "transparent",
                  }}
                />
              )}
              <figcaption className="mt-2">
                <span className="text-[0.9375rem] font-semibold text-foreground">
                  {entry.label}
                </span>
                {"prevalence" in entry && (
                  <span className="ml-2 font-mono text-2xs text-foreground-subtle">
                    {entry.prevalence}
                  </span>
                )}
                <span className="mt-0.5 block text-sm leading-relaxed text-foreground-muted">
                  {entry.blurb}
                </span>
              </figcaption>
            </figure>
          )
        )}
      </div>
    </section></div>
  );
};

const SimulatedImage: React.FC<{ image: ImageBitmap; type: Cvd | null }> = ({ image, type }) => {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    // Capped, because the preview is a few hundred pixels wide and decoding a
    // 48-megapixel photo into a canvas that size wastes both memory and time.
    const scale = Math.min(1, 480 / image.width);
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));

    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) return;
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    if (!type) return;

    const data = context.getImageData(0, 0, canvas.width, canvas.height);
    simulateCvdPixels(data.data, type);
    context.putImageData(data, 0, 0);
  }, [image, type]);

  return <canvas ref={ref} className="w-full rounded-lg bg-surface-elevated" />;
};
