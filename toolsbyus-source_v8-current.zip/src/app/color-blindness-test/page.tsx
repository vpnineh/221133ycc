import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ColorBlindnessTestClient } from "./ColorBlindnessTestClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/color-blindness-test",
  title: "Color Blindness Test — Plate Test and Simulator",
  socialTitle: "Color Blindness Test",
  description:
    "An eight-plate colour vision screening built from confusion pairs found by simulation, plus a simulator showing any colour or image as each deficiency sees it.",
});

export default function ColorBlindnessTestPage() {
  return <ColorBlindnessTestClient />;
}
