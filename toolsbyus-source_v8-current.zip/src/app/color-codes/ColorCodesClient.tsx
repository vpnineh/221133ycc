"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { useCopy, readableOn } from "../../components/tools/ColorParts";
import { Icon } from "../../components/common/Icon";
import { relatedTools } from "../../lib/tools";
import {
  COLOR_FAMILIES,
  NAMED_COLORS,
  contrastRatio,
  rgbToOklch,
  toHex,
  toHslString,
  toRgbString,
  type ColorFamily,
} from "../../lib/color";

const WHITE = { r: 255, g: 255, b: 255, a: 1 };
const BLACK = { r: 0, g: 0, b: 0, a: 1 };

type SortKey = "name" | "hue" | "lightness";

/**
 * Everything about a named colour is derived once, at module load.
 *
 * 148 rows times five conversions is not expensive, but it is expensive to do
 * inside a filter that re-runs on every keystroke — and the values never
 * change, so there is no reason to compute them more than once in the life of
 * the page.
 */
const ROWS = NAMED_COLORS.map((entry) => ({
  ...entry,
  hex: toHex(entry.color),
  rgb: toRgbString(entry.color),
  hsl: toHslString(entry.color),
  hue: rgbToOklch(entry.color).h,
  lightness: rgbToOklch(entry.color).l,
  onWhite: contrastRatio(entry.color, WHITE),
  onBlack: contrastRatio(entry.color, BLACK),
}));

export const ColorCodesClient: React.FC = () => {
  const [query, setQuery] = useState("");
  const [family, setFamily] = useState<ColorFamily | "all">("all");
  const [sort, setSort] = useState<SortKey>("name");
  const { copied, copy } = useCopy();

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const filtered = ROWS.filter((row) => {
      if (family !== "all" && row.family !== family) return false;
      if (needle === "") return true;
      // Matching the hex as well as the name is what makes this useful in the
      // other direction: paste #4169e1 and find out it is called royalblue.
      return row.name.includes(needle) || row.hex.includes(needle);
    });

    return [...filtered].sort((a, b) => {
      if (sort === "hue") return a.hue - b.hue || a.lightness - b.lightness;
      if (sort === "lightness") return b.lightness - a.lightness;
      return a.name.localeCompare(b.name);
    });
  }, [query, family, sort]);

  return (
    <ToolShell
      slug="color-codes"
      keyword="Color Codes"
      directAnswer="Color Codes is the full list of the 148 colour names CSS understands, each with its hex, RGB and HSL code and its contrast against white and black. Search by name or paste a hex value to find out what a colour is called, filter by family, and sort by hue or lightness to see the whole set arranged the way the eye reads it rather than alphabetically."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "Color Codes", url: "/color-codes" },
      ]}
      seoDescription="Every CSS colour name with its hex, RGB and HSL code — 148 colours, searchable by name or hex, filterable by family, sortable by hue or lightness, with contrast against white and black."
      howItWorks={{
        inputTitle: "A name, or a hex value",
        outputTitle: "Every code for it",
        exampleInput: "navy",
        exampleOutput: `hex        #000080
rgb        rgb(0 0 128)
hsl        hsl(240 100% 25.1%)
on white   15.30 : 1
on black   1.37 : 1`,
        algorithmExplanation: (
          <>
            <p>
              CSS has 148 colour keywords. They are not a system — they accumulated. Sixteen came
              from the original HTML 4 palette, which came from the VGA sixteen. Another 130
              arrived from the X11 window system&rsquo;s <code>rgb.txt</code>, a file assembled at
              MIT over the 1980s by people naming colours as they needed them. That is why there is
              both <code>gray</code> and <code>grey</code>, why <code>darkgray</code> is lighter
              than <code>gray</code>, and why <code>rebeccapurple</code> — added in 2014 in memory
              of Eric Meyer&rsquo;s daughter — is the only one with a story.
            </p>
            <h3>Why darkgray is lighter than gray</h3>
            <p>
              <code>gray</code> is <code>#808080</code>, the midpoint of the HTML 4 palette.{" "}
              <code>darkgray</code> is <code>#a9a9a9</code>, which is lighter. They came from
              different sources and were never reconciled, because by the time anyone noticed,
              changing either would have broken every page using it. It is the most reliable way to
              catch a colour tool that generated its table rather than reading the spec.
            </p>
            <h3>Sorting by hue rather than by name</h3>
            <p>
              Alphabetical order is useless for choosing a colour and perfect for finding one you
              can already name. Sorting by hue puts the list in the order the eye expects — the
              reds together, then the oranges, and so on round the wheel — which is the view that
              answers &ldquo;what else is near this?&rdquo;. The hue used is the OKLCh angle, not
              the HSL one, so the groupings match what the colours look like rather than what the
              arithmetic says.
            </p>
            <h3>The contrast columns</h3>
            <p>
              Each row carries its WCAG 2.x ratio against white and against black. That is the
              number that decides whether the colour can hold text, and it is the fastest way to
              rule out most of this list for anything other than decoration: of the 148, fewer than
              half reach 4.5:1 on white.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "About the keyword list",
        rows: [
          {
            parameter: "148",
            type: "count",
            defaultVal: "CSS Color 4",
            description:
              "The number of named colours, counting the greys spelled both ways as separate keywords. 147 is the figure usually quoted, from before rebeccapurple was added.",
          },
          {
            parameter: "gray / grey",
            type: "alias",
            defaultVal: "both valid",
            description:
              "Every grey keyword exists in both spellings and they are identical values. CSS accepts either, and always has.",
          },
          {
            parameter: "darkgray",
            type: "#a9a9a9",
            defaultVal: "—",
            description:
              "Lighter than gray (#808080). An artefact of merging the HTML 4 and X11 palettes, preserved because changing it would break existing pages.",
          },
          {
            parameter: "rebeccapurple",
            type: "#663399",
            defaultVal: "2014",
            description:
              "The only keyword added since the X11 import, in memory of Rebecca Meyer. An alias of the value her father used for it.",
          },
          {
            parameter: "aqua / cyan",
            type: "#00ffff",
            defaultVal: "identical",
            description:
              "Same value, two names, as are fuchsia and magenta. Both pairs survive from the two source palettes.",
          },
          {
            parameter: "transparent",
            type: "keyword",
            defaultVal: "rgba(0,0,0,0)",
            description:
              "Valid wherever a colour is, and not in this list because it has no value to look up.",
          },
          {
            parameter: "Contrast",
            type: "ratio",
            defaultVal: "vs #fff / #000",
            description:
              "WCAG 2.x ratio. 4.5:1 is the minimum for normal text; fewer than half of these keywords reach it on white.",
          },
          {
            parameter: "Hue sort",
            type: "OKLCh",
            defaultVal: "degrees",
            description:
              "Sorted by perceptual hue angle, not HSL — which is why red lands at 29° here rather than 0°.",
          },
        ],
      }}
      faqs={[
        {
          question: "What is the hex code for red?",
          answer:
            "#FF0000, which is rgb(255 0 0) and hsl(0 100% 50%). It is one of the original sixteen HTML 4 keywords. Worth knowing: pure #FF0000 is a very saturated red that vibrates against white and is hard to read as text — it reaches only 4.0:1 on white, which fails WCAG AA for body copy. Most interfaces want something closer to #C62828 or darker.",
        },
        {
          question: "What is the hex code for navy blue?",
          answer:
            "#000080. That is the CSS keyword navy: rgb(0 0 128), exactly half-intensity blue. It is very dark — 15.3:1 against white — which makes it excellent for text on a light background and nearly unreadable on a dark one. The lighter navy used in most brand palettes is usually around #1B3A6B rather than the keyword.",
        },
        {
          question: "Why is darkgray lighter than gray?",
          answer:
            "Because they came from different places. gray is #808080 from the HTML 4 palette; darkgray is #A9A9A9 from X11's rgb.txt. When CSS merged the two lists in the late 1990s, the conflict was already shipped in browsers, so it was preserved rather than fixed. It is the single best test of whether a colour reference was copied from the spec or generated by somebody's assumption.",
        },
        {
          question: "How many CSS colour names are there?",
          answer:
            "148 keywords, or 140 distinct colour values — the difference is the greys spelled two ways and the aqua/cyan and fuchsia/magenta pairs. The figure 147 that circulates predates rebeccapurple, which was added to the specification in 2014.",
        },
        {
          question: "Can I use a colour name instead of a hex code in CSS?",
          answer:
            "Yes, anywhere a colour is valid, and every browser has supported all of them for two decades. The practical argument against is that the names are not a system: there is no relationship between darkblue and blue that you can rely on, no consistent lightness scale, and nothing to interpolate along. For a design system you want values you generated; for a quick prototype or a debug outline, `outline: 2px solid hotpink` is faster to type than any hex.",
        },
        {
          question: "How do I find out what a hex colour is called?",
          answer:
            "Paste it into the search box. The filter matches hex values as well as names, so entering #4169e1 finds royalblue. If the value is not an exact keyword match nothing comes back — these are exact values, not nearest neighbours, and a tool that told you #4169e2 was 'royalblue' would be lying about a value you are about to paste into code.",
        },
      ]}
      relatedTools={relatedTools("/color-codes").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-5">
        {/* ---- Controls ------------------------------------------------ */}
        <div className="flex flex-wrap items-end gap-4">
          <div className="min-w-0 flex-1 basis-64">
            <label htmlFor="color-search" className="mb-2 block text-sm text-foreground-muted">
              Search by name or hex
            </label>
            <div className="flex items-center gap-3 rounded-lg bg-surface-elevated px-4 py-3">
              <Icon name="search" size="md" className="text-foreground-subtle" />
              <input
                id="color-search"
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="navy, #4169e1, salmon…"
                spellCheck={false}
                autoComplete="off"
                className="w-full min-w-0 border-0 bg-transparent text-base text-foreground outline-none"
              />
            </div>
          </div>

          <div>
            <label htmlFor="color-sort" className="mb-2 block text-sm text-foreground-muted">
              Sort
            </label>
            <select
              id="color-sort"
              value={sort}
              onChange={(event) => setSort(event.target.value as SortKey)}
              className="rounded-lg border-0 bg-surface-elevated px-4 py-3 text-base text-foreground outline-none pointer-coarse:min-h-[44px]"
            >
              <option value="name">Name, A to Z</option>
              <option value="hue">Hue, round the wheel</option>
              <option value="lightness">Lightness, light to dark</option>
            </select>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {(["all", ...COLOR_FAMILIES] as const).map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setFamily(option)}
              aria-pressed={family === option}
              className={`cursor-pointer rounded-pill px-4 py-2 text-sm font-medium capitalize transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] ${
                family === option
                  ? "bg-accent-soft text-accent"
                  : "bg-surface-elevated text-foreground-muted hover:text-foreground"
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        <p role="status" className="text-sm text-foreground-subtle">
          {rows.length} of {ROWS.length} colours
        </p>

        {/* ---- Table --------------------------------------------------- */}
        {rows.length === 0 ? (
          <p className="rounded-lg bg-surface-elevated p-8 text-center text-base text-foreground-muted">
            No colour name or hex value matches{" "}
            <code className="font-mono text-foreground">{query}</code>. These are exact values —
            nothing here is a nearest match.
          </p>
        ) : (
          <div className="overflow-x-auto rounded-lg bg-surface-elevated">
            <table className="w-full min-w-[46rem] border-collapse text-left text-sm">
              <caption className="sr-only">
                CSS colour names with their hex, RGB and HSL codes and contrast ratios
              </caption>
              <thead>
                <tr className="border-b border-border">
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Colour
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Name
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    HEX
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    RGB
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    HSL
                  </th>
                  <th scope="col" className="px-4 py-3 text-right text-xs font-semibold text-foreground-muted">
                    On white
                  </th>
                  <th scope="col" className="px-4 py-3 text-right text-xs font-semibold text-foreground-muted">
                    On black
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((row) => (
                  <tr key={row.name} className="transition-colors hover:bg-surface">
                    <td className="px-4 py-2">
                      <span
                        className="flex h-9 w-14 items-center justify-center rounded text-2xs"
                        style={{ backgroundColor: row.hex, color: readableOn(row.color) }}
                        aria-hidden="true"
                      >
                        Aa
                      </span>
                    </td>
                    <th scope="row" className="px-4 py-2 text-left font-medium text-foreground">
                      {row.name}
                    </th>
                    {[row.hex, row.rgb, row.hsl].map((value) => (
                      <td key={value} className="px-4 py-2">
                        <button
                          type="button"
                          onClick={() => copy(value)}
                          title={`Copy ${value}`}
                          className="cursor-pointer rounded font-mono text-xs text-foreground-muted transition-colors hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                        >
                          {copied === value ? "Copied" : value}
                        </button>
                      </td>
                    ))}
                    <td
                      className={`px-4 py-2 text-right font-mono text-xs ${
                        row.onWhite >= 4.5 ? "text-add" : "text-foreground-subtle"
                      }`}
                    >
                      {row.onWhite.toFixed(2)}
                    </td>
                    <td
                      className={`px-4 py-2 text-right font-mono text-xs ${
                        row.onBlack >= 4.5 ? "text-add" : "text-foreground-subtle"
                      }`}
                    >
                      {row.onBlack.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </ToolShell>
  );
};
