import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ColorCodesClient } from "./ColorCodesClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/color-codes",
  title: "Color Codes — CSS Color Names in HEX and RGB",
  socialTitle: "Color Codes",
  description:
    "Every CSS colour name with its HEX, RGB and HSL code, searchable, sortable and grouped by family, with the contrast of each against white and black.",
});

export default function ColorCodesPage() {
  return <ColorCodesClient />;
}
