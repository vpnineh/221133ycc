"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorConvertSurface } from "../../components/tools/ColorConvertSurface";
import { relatedTools } from "../../lib/tools";
import { NAMED_COLOR_COUNT } from "../../lib/color";

export const ColorConverterClient: React.FC = () => (
  <ToolShell
    slug="color-converter"
    keyword="Color Converter"
    directAnswer={`Color Converter reads a colour in any notation — hex with or without the hash, rgb(), hsl(), hsb(), oklch() or one of the ${NAMED_COLOR_COUNT} CSS colour names — and prints it back in all of them at once. It accepts both the comma and the space syntax, keeps alpha wherever the target format can hold it, and returns nothing rather than black when the input is not a colour it can read.`}
    breadcrumbs={[
      { name: "Color Tools", url: "/color-tools" },
      { name: "Color Converter", url: "/color-converter" },
    ]}
    seoDescription="Convert between HEX, RGB, HSL, HSV, OKLCH and CMYK in every direction. Accepts bare hex, both CSS syntaxes and colour names, keeps alpha, and runs entirely in your browser."
    howItWorks={{
      inputTitle: "Any notation",
      outputTitle: "All of them",
      exampleInput: `#ff8800
rgb(255, 136, 0)
hsl(32 100% 50%)
darkorange
FF8800`,
      exampleOutput: `hex    #ff8800
rgb    rgb(255 136 0)
hsl    hsl(32 100% 50%)
hsv    hsv(32 100% 100%)
oklch  oklch(0.7538 0.1751 55.94)
cmyk   cmyk(0% 47% 100% 0%)`,
      algorithmExplanation: (
        <>
          <p>
            Everything routes through sRGB. Whatever you type is parsed into three channels and an
            alpha, and every output is rendered from those. That is what makes the conversions
            consistent: there is one representation in the middle, not fifteen pairwise formulas
            that can disagree with each other.
          </p>
          <h3>What the parser accepts</h3>
          <p>
            Hex in three, four, six or eight digits, with or without the leading hash — bare hex
            matters because that is how values arrive from a spreadsheet or a design token file.
            Both CSS syntaxes: <code>rgb(255, 136, 0)</code> and{" "}
            <code>rgb(255 136 0 / 50%)</code>. Percentages, which in <code>rgb()</code> resolve
            against 255 rather than 100. <code>hsl()</code>, <code>hsb()</code>/<code>hsv()</code>,{" "}
            <code>oklch()</code>, and all {NAMED_COLOR_COUNT} CSS colour keywords.
          </p>
          <h3>What it does with something it cannot read</h3>
          <p>
            It says so. A colour tool that silently turns a typo into black is worse than one that
            refuses the input, because you get a swatch, believe it, and ship it. A hex of the
            wrong length — five digits, seven digits — is a typo and not a colour, and is rejected
            rather than padded into something plausible.
          </p>
          <h3>Which conversions are exact and which are not</h3>
          <p>
            Hex, RGB, HSL and HSV are the same three bytes in different coordinates. Those round
            trip exactly, limited only by how many decimals the output is printed to.
          </p>
          <p>
            OKLCH is exact in the other direction too, but it can describe colours sRGB cannot
            show. <code>oklch(0.7 0.3 140)</code> is a perfectly valid coordinate with no sRGB
            pixel behind it, and converting it clips — so two different OKLCH values can come back
            as the same hex. That is a property of the gamut, not a bug in the arithmetic.
          </p>
          <p>
            CMYK is the approximation. A real conversion needs an ICC profile for the press, the
            paper and the ink, and the same sRGB value becomes different ink percentages on coated
            stock than on newsprint. The figure here is the device-independent formula every online
            converter uses: right for picking a swatch, wrong for a press specification.
          </p>
        </>
      ),
    }}
    referenceTable={{
      title: "Formats, and how exact each conversion is",
      rows: [
        { parameter: "HEX", type: "in / out", defaultVal: "exact", description: "3, 4, 6 and 8 digits, with or without the hash. Case-insensitive." },
        { parameter: "RGB", type: "in / out", defaultVal: "exact", description: "Both syntaxes, integers or percentages, with alpha after a slash or as a fourth argument." },
        { parameter: "HSL", type: "in / out", defaultVal: "exact", description: "The same three bytes in polar coordinates. Hue wraps, so 370 is 10." },
        { parameter: "HSV / HSB", type: "in / out", defaultVal: "exact", description: "What most design tools are built on. Not valid CSS, so it is read but never the recommended output." },
        { parameter: "OKLCH", type: "in / out", defaultVal: "clips", description: "Perceptually uniform and wider than sRGB. A coordinate outside the gamut clips on the way back." },
        { parameter: "CMYK", type: "out", defaultVal: "approximate", description: "The device-independent formula. A printer will do the real conversion with their own profile." },
        { parameter: "Colour names", type: "in", defaultVal: `${NAMED_COLOR_COUNT}`, description: "Every CSS keyword, plus `transparent`." },
        { parameter: "Alpha", type: "0–1", defaultVal: "kept", description: "Preserved through every format that can express it. CMYK cannot, and drops it." },
      ],
    }}
    faqs={[
      {
        question: "What colour formats can I paste in?",
        answer:
          `Hex in three, four, six or eight digits with or without the hash; rgb() and rgba() in either the comma or the space syntax; hsl() and hsla(); hsb() or hsv(); oklch(); and any of the ${NAMED_COLOR_COUNT} CSS colour names. Percentages work wherever CSS allows them. If it parses, every other format appears immediately.`,
      },
      {
        question: "Why does my OKLCH value come back as a different colour?",
        answer:
          "Because OKLCH describes more colours than an sRGB screen can show. oklch(0.7 0.3 140) is a valid coordinate with no sRGB pixel behind it, so converting it clips chroma until it fits — and two different vivid OKLCH values can clip to the same hex. It is the gamut, not the arithmetic. If you need the in-gamut version, the picker on this site clamps rather than clips and tells you what it changed.",
      },
      {
        question: "Can I trust the CMYK numbers for print?",
        answer:
          "As a starting point, not as a specification. CMYK is device-dependent: the same sRGB value becomes different ink percentages on coated stock than on uncoated, and different again on a different press. No online converter can know which press. Send the printer the sRGB or the Pantone reference and let them convert with the profile for the job.",
      },
      {
        question: "What happens if I paste something that is not a colour?",
        answer:
          "Nothing is produced and the field says it could not read the input. That is deliberate. A converter that silently returns black on a typo hands you a swatch you have no reason to doubt, and hex of the wrong length — five or seven digits — is a typo, not a colour that needs padding.",
      },
      {
        question: "Is any of this sent to a server?",
        answer:
          "No. Every conversion here is arithmetic in this tab. The page makes no network request after it loads, which you can check by opening the network panel, or more simply by turning off your connection and watching it keep working.",
      },
    ]}
    relatedTools={relatedTools("/color-converter").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <ColorConvertSurface
      from="hex"
      to="rgb"
      initial="#ff8800"
      also={["hex", "rgb", "hsl", "hsv", "oklch", "cmyk"]}
    />
  </ToolShell>
);
