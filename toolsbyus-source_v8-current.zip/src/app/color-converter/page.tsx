import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ColorConverterClient } from "./ColorConverterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/color-converter",
  title: "Color Converter — HEX, RGB, HSL, HSV, OKLCH, CMYK",
  socialTitle: "Color Converter",
  description:
    "Convert between HEX, RGB, HSL, HSV, OKLCH and CMYK in every direction. Accepts bare hex, both CSS syntaxes and colour names, and keeps alpha.",
});

export default function Page() {
  return <ColorConverterClient />;
}
