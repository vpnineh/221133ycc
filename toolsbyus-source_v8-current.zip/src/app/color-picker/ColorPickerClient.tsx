"use client";

import React, { useMemo } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import {
  ColorInput,
  Swatch,
  ValueRow,
  useColorField,
  useCopy,
} from "../../components/tools/ColorParts";
import { relatedTools } from "../../lib/tools";
import {
  buildScale,
  harmonyOf,
  HARMONIES,
  namedFor,
  rgbToHsl,
  rgbToHsv,
  rgbToOklch,
  toCmykString,
  toHex,
  toHslString,
  toOklchString,
  toRgbString,
  type Rgb,
} from "../../lib/color";

const FALLBACK: Rgb = { r: 0, g: 105, b: 111, a: 1 };
const WHITE: Rgb = { r: 255, g: 255, b: 255, a: 1 };
const BLACK: Rgb = { r: 0, g: 0, b: 0, a: 1 };

export const ColorPickerClient: React.FC = () => {
  const field = useColorField("#00696f");
  const { copied, copy } = useCopy();
  const color = field.color ?? FALLBACK;

  const scale = useMemo(() => buildScale(color), [color]);
  const hsl = rgbToHsl(color);
  const hsv = rgbToHsv(color);
  const oklch = rgbToOklch(color);
  const name = namedFor(color);

  /** The CSS custom properties a design system would paste, as one block. */
  const scaleCss = useMemo(
    () =>
      scale
        .map((stop) => `  --brand-${stop.step}: ${toHex(stop.color)};`)
        .join("\n"),
    [scale]
  );

  return (
    <ToolShell
      slug="color-picker"
      keyword="Color Picker"
      directAnswer="Color Picker takes a colour — typed, pasted or sampled with your system's eyedropper — and reads it back as HEX, RGB, HSL, HSV, OKLCH and CMYK at once. It also builds an eleven-step tint and shade ramp in OKLCh, so every step keeps the hue it started with, and reports each step's contrast against white and black so you can see straight away which ones can carry text."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "Color Picker", url: "/color-picker" },
      ]}
      seoDescription="Pick a colour and get its HEX, RGB, HSL, HSV, OKLCH and CMYK values, an eleven-step tint and shade ramp, and colour harmonies — all computed in your browser."
      howItWorks={{
        inputTitle: "One colour",
        outputTitle: "Every representation of it",
        exampleInput: "#00696f",
        exampleOutput: `hex    #00696f
rgb    rgb(0 105 111)
hsl    hsl(183 100% 21.8%)
oklch  oklch(0.4849 0.0872 202.1)
cmyk   cmyk(100% 5% 0% 56%)`,
        algorithmExplanation: (
          <>
            <p>
              A colour on a screen is three numbers, and every format here is the same three numbers
              in different clothes. Hex and <code>rgb()</code> are the same value written in base 16
              and base 10. <code>hsl()</code> and <code>hsv()</code> are the same value in polar
              coordinates, which is why a hue slider exists. Those four are lossless round trips of
              each other, and this tool converts between them exactly.
            </p>
            <h3>Why the ramp is built in OKLCh</h3>
            <p>
              HSL has one useful property and one fatal one. The useful one is that a hue slider
              makes sense. The fatal one is that its lightness is not lightness:{" "}
              <code>hsl(60 100% 50%)</code> is a blinding yellow and{" "}
              <code>hsl(240 100% 50%)</code> is a near-black blue, and HSL calls them both 50%.
              Build a tint ramp by walking HSL lightness and you get a scale where the middle steps
              jump around in apparent brightness while the numbers march evenly.
            </p>
            <p>
              OKLCh does not have that problem. Its lightness axis tracks what the eye reports, so
              stepping down it produces a ramp that reads as even. Every step here is also checked
              against the sRGB gamut and pulled back in if it falls outside — without that, the most
              saturated steps clip to the same colour and the scale silently flattens at exactly the
              end a designer is looking at.
            </p>
            <h3>The eyedropper</h3>
            <p>
              The colour well next to the field opens your operating system&rsquo;s own picker,
              which on macOS, Windows and most Linux desktops includes an eyedropper that can sample
              any pixel on screen — including pixels in other applications. No page can do that on
              its own, which is why the native control is here rather than a canvas imitation of
              one. It cannot express transparency, so the text field carries alpha: type{" "}
              <code>#00696f80</code> and the well shows the opaque teal while the field keeps the
              50%.
            </p>
            <h3>CMYK, and what it is worth</h3>
            <p>
              The CMYK figures are the device-independent approximation, the same one every online
              converter uses. A real conversion needs an ICC profile for the press, the paper and
              the ink set, and the same sRGB value becomes different numbers on coated stock than on
              newsprint. Treat it as a starting point for a conversation with a printer, not as a
              specification to send them.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "Formats and what each is for",
        rows: [
          {
            parameter: "HEX",
            type: "#rrggbb",
            defaultVal: "6 digits",
            description:
              "The shortest form, and the only one that survives a paste into anything. 4 and 8 digits add alpha; 3 digits is shorthand for doubled pairs.",
          },
          {
            parameter: "RGB",
            type: "0–255",
            defaultVal: "rgb()",
            description:
              "The same three numbers in base 10. Modern syntax separates them with spaces and alpha with a slash; the comma form still works everywhere.",
          },
          {
            parameter: "HSL",
            type: "deg %, %",
            defaultVal: "hsl()",
            description:
              "Hue, saturation, lightness. Good for a hue slider, misleading for anything that depends on brightness — its lightness is not perceived lightness.",
          },
          {
            parameter: "HSV",
            type: "deg %, %",
            defaultVal: "hsb()",
            description:
              "Hue, saturation, value. What most colour pickers are built on, including Photoshop's. Not valid CSS.",
          },
          {
            parameter: "OKLCH",
            type: "0–1, 0–0.4, deg",
            defaultVal: "oklch()",
            description:
              "Perceptually uniform. Equal steps look equal, hue holds through a lightness change, and it is what CSS Color 4 uses. Supported in every current browser.",
          },
          {
            parameter: "CMYK",
            type: "0–100%",
            defaultVal: "naive",
            description:
              "The device-independent approximation. Useful for a rough print reference, not for a press specification — that needs an ICC profile.",
          },
          {
            parameter: "Scale",
            type: "50–950",
            defaultVal: "11 steps",
            description:
              "Tints and shades on a fixed lightness curve, with chroma tapering at both ends so the light steps are not fluorescent and the dark ones do not glow.",
          },
          {
            parameter: "Contrast",
            type: "ratio",
            defaultVal: "vs #fff / #000",
            description:
              "Each step's WCAG 2.x ratio against white and black, which is what decides whether text can sit on it.",
          },
        ],
      }}
      faqs={[
        {
          question: "How do I use an eyedropper to pick a colour from my screen?",
          answer:
            "Click the colour well beside the text field. That opens your operating system's own picker, which on macOS, Windows and most Linux desktops has an eyedropper that samples any pixel on screen, including in other applications. A web page cannot read pixels outside itself, so the native control is the only route to that — an in-page canvas picker can only sample an image you have already loaded.",
        },
        {
          question: "What is OKLCH and should I be using it instead of HSL?",
          answer:
            "OKLCH is a perceptually uniform colour space: equal numeric steps look like equal visual steps, and changing lightness does not shift the hue. HSL does neither, which is why an HSL-generated tint ramp has steps that look uneven even though the numbers are evenly spaced. Every current browser supports oklch() in CSS. Use HSL when you want a hue slider; use OKLCH when the value feeds a ramp, a mix, or any decision about brightness.",
        },
        {
          question: "Why do the tints in the ramp look different from lightening the hex value?",
          answer:
            "Because lightening a hex value means moving three sRGB channels towards 255, and that changes the hue as well as the lightness — most visibly in blues and purples, which drift towards grey. The ramp here moves lightness in OKLCh and holds hue and chroma, then pulls each step back into the sRGB gamut if it lands outside. That is what keeps step 100 and step 800 recognisably the same colour.",
        },
        {
          question: "Can I get a colour with transparency?",
          answer:
            "Yes. Type an 8-digit hex like #00696f80, or rgba(0 105 111 / 50%), and the alpha is kept through every conversion that has a place to put it. The native colour well cannot show transparency — it is a limitation of the control, not of this page — so it displays the opaque colour while the text field holds the real value.",
        },
        {
          question: "Is the CMYK conversion accurate enough to send to a printer?",
          answer:
            "No, and no online converter's is. CMYK is device-dependent: the same sRGB value becomes different ink percentages on coated stock than on uncoated, and different again on a different press. This is the standard device-independent approximation, which is right for picking a swatch and for talking to a printer about roughly what you mean. The printer will do the real conversion with the profile for their press.",
        },
        {
          question: "Does anything I pick get sent anywhere?",
          answer:
            "No. Every conversion here is arithmetic running in this tab. The page makes no network request after it loads — turn off your connection and the picker keeps working, which is the test worth running if you would rather check than take our word for it.",
        },
      ]}
      relatedTools={relatedTools("/color-picker").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="grid gap-8 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)] lg:gap-12">
        {/* ---- Pick ---------------------------------------------------- */}
        <div className="space-y-5">
          <ColorInput
            label="Colour"
            value={field.text}
            onChange={field.setText}
            parsed={field.color}
          />

          <div
            className="flex h-40 items-end rounded-xl p-4"
            style={{ backgroundColor: toHex(color) }}
          >
            {name && (
              <span
                className="rounded-pill bg-surface px-3 py-1 text-xs font-medium text-foreground"
                title="This value has a CSS keyword"
              >
                {name}
              </span>
            )}
          </div>

          <div>
            <ValueRow label="HEX" value={toHex(color)} copied={copied} onCopy={copy} />
            <ValueRow label="RGB" value={toRgbString(color)} copied={copied} onCopy={copy} />
            <ValueRow label="HSL" value={toHslString(color)} copied={copied} onCopy={copy} />
            <ValueRow
              label="HSV"
              value={`hsv(${Math.round(hsv.h)} ${hsv.s.toFixed(1)}% ${hsv.v.toFixed(1)}%)`}
              copied={copied}
              onCopy={copy}
            />
            <ValueRow label="OKLCH" value={toOklchString(color)} copied={copied} onCopy={copy} />
            <ValueRow
              label="CMYK"
              value={toCmykString(color)}
              copied={copied}
              onCopy={copy}
              note={
                <span className="text-xs text-foreground-subtle">approximate</span>
              }
            />
          </div>

          <dl className="grid grid-cols-3 gap-4 rounded-lg bg-surface-elevated p-4 text-sm">
            {[
              ["Hue", `${Math.round(hsl.h)}°`],
              ["Lightness", `${(oklch.l * 100).toFixed(0)}%`],
              ["Chroma", oklch.c.toFixed(3)],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs text-foreground-subtle">{label}</dt>
                <dd className="mt-0.5 font-mono text-foreground">{value}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* ---- Scale and harmony --------------------------------------- */}
        <div className="min-w-0 space-y-10">
          <section>
            <div className="mb-1 flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h2 className="text-lg font-semibold tracking-tight text-foreground">
                Tints and shades
              </h2>
              <button
                type="button"
                onClick={() => copy(`:root {\n${scaleCss}\n}`)}
                className="ml-auto cursor-pointer rounded-pill bg-surface-elevated px-4 py-1.5 text-xs font-medium text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
              >
                Copy as CSS variables
              </button>
            </div>
            <p className="mb-4 text-sm text-foreground-muted">
              Eleven steps on an OKLCh lightness curve. The ratios are against white and black — a
              step needs 4.5:1 to carry body text.
            </p>

            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-6">
              {scale.map((stop) => (
                <div key={stop.step}>
                  <Swatch
                    color={stop.color}
                    value={toHex(stop.color)}
                    caption={String(stop.step)}
                    copied={copied}
                    onCopy={copy}
                    className={`h-24 ${stop.isBase ? "ring-2 ring-accent ring-offset-2 ring-offset-surface" : ""}`}
                  />
                  <p className="mt-1.5 px-1 font-mono text-2xs text-foreground-subtle">
                    {stop.onWhite.toFixed(1)} / {stop.onBlack.toFixed(1)}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="mb-1 text-lg font-semibold tracking-tight text-foreground">
              Harmonies
            </h2>
            <p className="mb-4 text-sm text-foreground-muted">
              Hue rotated in OKLCh, so every colour in a scheme holds the lightness of the one it
              came from. Rotate in HSL instead and the yellow blinds you while the blue disappears.
            </p>

            <div className="space-y-5">
              {HARMONIES.map((harmony) => {
                const colors = harmonyOf(color, harmony.id);
                return (
                  <div key={harmony.id}>
                    <div className="mb-2 flex flex-wrap items-baseline gap-x-2">
                      <h3 className="text-[0.9375rem] font-semibold text-foreground">
                        {harmony.label}
                      </h3>
                      <p className="min-w-0 flex-1 text-sm text-foreground-subtle">
                        {harmony.blurb}
                      </p>
                    </div>
                    <div
                      className="grid gap-2"
                      style={{ gridTemplateColumns: `repeat(${colors.length}, minmax(0, 1fr))` }}
                    >
                      {colors.map((swatch, index) => (
                        <Swatch
                          key={`${harmony.id}-${index}`}
                          color={swatch}
                          value={toHex(swatch)}
                          copied={copied}
                          onCopy={copy}
                          className="h-20"
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section>
            <h2 className="mb-3 text-lg font-semibold tracking-tight text-foreground">
              On white, and on black
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                { bg: WHITE, label: "On white" },
                { bg: BLACK, label: "On black" },
              ].map((sample) => (
                <div
                  key={sample.label}
                  className="rounded-lg p-5"
                  style={{ backgroundColor: toHex(sample.bg), color: toHex(color) }}
                >
                  <p className="text-base leading-relaxed">
                    Body text in this colour, {sample.label.toLowerCase()}.
                  </p>
                  <p className="mt-2 text-xl font-bold">Large text.</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </ToolShell>
  );
};
