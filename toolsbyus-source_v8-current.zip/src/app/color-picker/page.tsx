import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ColorPickerClient } from "./ColorPickerClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/color-picker",
  title: "Color Picker — HEX, RGB, HSL, OKLCH and CMYK",
  socialTitle: "Color Picker",
  description:
    "Pick a colour and get its HEX, RGB, HSL, HSV, OKLCH and CMYK values, plus an eleven-step tint and shade ramp built in OKLCh with the contrast of every step.",
});

export default function ColorPickerPage() {
  return <ColorPickerClient />;
}
