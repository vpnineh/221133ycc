"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Swatch, useCopy } from "../../components/tools/ColorParts";
import { relatedTools } from "../../lib/tools";
import {
  clampToSrgbGamut,
  contrastRatio,
  HARMONIES,
  harmonyOf,
  isInSrgbGamut,
  namedFor,
  oklchToRgb,
  parseColor,
  rgbToOklch,
  toHex,
  toHslString,
  toRgbString,
  type Harmony,
  type Rgb,
} from "../../lib/color";

/**
 * The widest chroma the wheel's rim represents.
 *
 * sRGB's most saturated colours sit a little under 0.32 in OKLCh chroma, and
 * only in a few hues; 0.37 leaves the rim just outside the gamut everywhere, so
 * the ragged edge of the painted area *is* the sRGB boundary rather than a crop
 * of it. That edge is the most useful thing on this page: it shows at a glance
 * that a screen's colour space is not a disc, and that the yellows reach much
 * further out than the blues do.
 */
const MAX_CHROMA = 0.37;

/** CSS pixels. The backing store is scaled by the device pixel ratio. */
const WHEEL_SIZE = 300;

const WHITE: Rgb = { r: 255, g: 255, b: 255, a: 1 };
const BLACK: Rgb = { r: 0, g: 0, b: 0, a: 1 };

/** Where a colour sits on the wheel, in 0–1 across and down. */
function positionOf(color: Rgb): { left: number; top: number } {
  const { c, h } = rgbToOklch(color);
  const radius = Math.min(c / MAX_CHROMA, 1) / 2;
  const angle = (h * Math.PI) / 180;
  return { left: 0.5 + radius * Math.cos(angle), top: 0.5 - radius * Math.sin(angle) };
}

export const ColorWheelClient: React.FC = () => {
  const { copied, copy } = useCopy();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [hue, setHue] = useState(202);
  const [chroma, setChroma] = useState(0.15);
  const [lightness, setLightness] = useState(0.62);
  const [harmony, setHarmony] = useState<Harmony>("split-complementary");

  const base = useMemo(
    () => oklchToRgb(clampToSrgbGamut({ l: lightness, c: chroma, h: hue, a: 1 })),
    [lightness, chroma, hue]
  );
  const scheme = useMemo(() => harmonyOf(base, harmony), [base, harmony]);
  const name = namedFor(base);

  /*
   * Repaint the wheel whenever lightness changes.
   *
   * A slice at one lightness is the only honest way to draw this. The usual
   * "colour wheel" is a slice of HSL at 50% lightness, which is why its yellow
   * blinds you and its blue is nearly black — those are not the same lightness
   * and HSL only claims they are. Here every pixel genuinely has the lightness
   * on the slider, so moving round the rim changes the hue and nothing else.
   */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;

    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const pixels = Math.round(WHEEL_SIZE * ratio);
    canvas.width = pixels;
    canvas.height = pixels;

    const image = context.createImageData(pixels, pixels);
    const data = image.data;
    const centre = pixels / 2;

    for (let y = 0; y < pixels; y++) {
      for (let x = 0; x < pixels; x++) {
        const dx = (x + 0.5 - centre) / centre;
        const dy = (centre - y - 0.5) / centre;
        const radius = Math.hypot(dx, dy);
        const index = (y * pixels + x) * 4;

        if (radius > 1) continue; // Transparent: the panel shows through.

        const oklch = {
          l: lightness,
          c: radius * MAX_CHROMA,
          h: (Math.atan2(dy, dx) * 180) / Math.PI,
          a: 1,
        };

        // Out of gamut is left blank rather than clipped. Painting a clipped
        // colour there would draw a flat band of one hue and quietly claim the
        // screen can show it.
        if (!isInSrgbGamut(oklch)) continue;

        const { r, g, b } = oklchToRgb(oklch);
        data[index] = r;
        data[index + 1] = g;
        data[index + 2] = b;
        data[index + 3] = 255;
      }
    }

    context.putImageData(image, 0, 0);
  }, [lightness]);

  /** Turns a pointer position on the canvas into a hue and a chroma. */
  const pickAt = useCallback((event: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const dx = (event.clientX - rect.left - rect.width / 2) / (rect.width / 2);
    const dy = (rect.height / 2 - (event.clientY - rect.top)) / (rect.height / 2);
    const radius = Math.min(Math.hypot(dx, dy), 1);

    setHue((((Math.atan2(dy, dx) * 180) / Math.PI) + 360) % 360);
    setChroma(Number((radius * MAX_CHROMA).toFixed(3)));
  }, []);

  const onPointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    pickAt(event);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
    pickAt(event);
  };

  const schemeCss = useMemo(
    () =>
      scheme
        .map((color, index) => `  --scheme-${index + 1}: ${toHex(color)};`)
        .join("\n"),
    [scheme]
  );

  const clamped = !isInSrgbGamut({ l: lightness, c: chroma, h: hue, a: 1 });

  return (
    <ToolShell
      slug="color-wheel"
      keyword="Color Wheel"
      directAnswer="Color Wheel shows a slice of the OKLCh colour space at one lightness: hue runs around the rim, chroma runs out from the middle, and the ragged outer edge is the real boundary of what an sRGB screen can show. Pick a point and it returns the complementary, analogous, triadic, tetradic and split-complementary schemes, each rotated in OKLCh so every colour in a scheme holds the lightness it started from."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "Color Wheel", url: "/color-wheel" },
      ]}
      seoDescription="An interactive colour wheel that returns complementary, analogous, triadic and split-complementary schemes. Drawn in OKLCh at a fixed lightness, so the hues are actually comparable."
      howItWorks={{
        inputTitle: "A point on the wheel",
        outputTitle: "A scheme you can paste",
        exampleInput: `hue        202°
chroma     0.150
lightness  0.62`,
        exampleOutput: `split complementary

#00a2b4   base
#c48a2a   +150°
#d4739a   +210°`,
        algorithmExplanation: (
          <>
            <p>
              Every colour wheel you have used is a slice of a colour space, and which space it is
              decides whether the wheel tells you anything. The familiar one is a slice of HSL at
              50% lightness. Look at it: the yellow at the top is blinding and the blue at the
              bottom is almost black, and HSL calls them both 50% lightness. A scheme picked off
              that wheel is a set of colours that have nothing in common except an angle.
            </p>
            <p>
              This wheel is a slice of OKLCh, whose lightness axis tracks what the eye actually
              reports. At a given setting of the slider, every painted pixel has the same perceived
              lightness — so moving around the rim changes the hue and only the hue, and two colours
              opposite each other are genuinely a matched pair rather than one shouting over the
              other.
            </p>
            <h3>What the ragged edge is</h3>
            <p>
              The painted area is not a disc, and that is the most informative thing on the page.
              Chroma runs outwards from grey at the centre, and a pixel is only painted when the
              colour it describes exists in sRGB. The result is the true shape of the gamut at that
              lightness: yellows and greens reach a long way out, blues and violets stop early, and
              the whole figure shrinks towards a point as you drag the lightness slider to either
              extreme — because a very dark or very light colour cannot be very colourful.
            </p>
            <p>
              A wheel that filled the disc would be lying about that. It would paint the same
              clipped colour across the whole out-of-gamut region, and you would pick a value your
              screen cannot show and never be told.
            </p>
            <h3>How the schemes are computed</h3>
            <p>
              Each scheme is a set of hue rotations — 180° for complementary, ±30° for analogous,
              120° steps for triadic, 150° and 210° for split-complementary — applied in OKLCh with
              lightness and chroma held. If a rotated hue lands outside the gamut, its chroma is
              pulled back by binary search until it fits, which keeps the hue and the lightness
              exact and gives up only the saturation that was not available anyway.
            </p>
            <h3>Honest about what a scheme is worth</h3>
            <p>
              A harmony is an arithmetic relationship, not a design. Triadic gives you three hues
              120° apart; it does not tell you that two of them need to be muted to a tenth of their
              chroma before the third can be an accent. Interfaces are mostly built from one hue and
              a neutral ramp, with a second hue for a destructive action — the monochromatic option
              is closer to what real design systems ship than anything else on this list. Use the
              wheel to find the relationships and then throw most of the saturation away.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "The controls and what they change",
        rows: [
          { parameter: "Hue", type: "0–360°", defaultVal: "202", description: "The angle around the rim. In OKLCh, changing it holds the perceived lightness — which is the whole reason to use this space." },
          { parameter: "Chroma", type: "0–0.37", defaultVal: "0.15", description: "Distance from the grey centre. Not a percentage: it is an absolute measure, and the maximum available depends on both hue and lightness." },
          { parameter: "Lightness", type: "0–1", defaultVal: "0.62", description: "Which slice of the space is drawn. The painted area shrinks towards a point at both extremes because dark and light colours cannot hold much chroma." },
          { parameter: "Complementary", type: "+180°", defaultVal: "2 colours", description: "Maximum hue separation. Strong enough that it usually works as one accent against one dominant colour, not as a pair of equals." },
          { parameter: "Analogous", type: "±30°", defaultVal: "3 colours", description: "Neighbours. The quietest scheme and the safest for a whole interface, because nothing competes." },
          { parameter: "Triadic", type: "120° steps", defaultVal: "3 colours", description: "Even spacing. Balanced in theory; in practice two of the three want their chroma cut hard." },
          { parameter: "Split complementary", type: "+150°, +210°", defaultVal: "3 colours", description: "The opposite hue, split either side of it. Keeps most of the contrast and loses the vibration you get from an exact complement." },
          { parameter: "Monochromatic", type: "lightness only", defaultVal: "5 colours", description: "One hue at five lightnesses. Unglamorous, and what almost every shipped design system is actually built on." },
        ],
      }}
      faqs={[
        {
          question: "What is a colour wheel used for?",
          answer:
            "Finding colours that have a defined relationship to one you already have. Rotate the hue 180° and you have the maximum separation available; rotate 30° either side and you have neighbours that will not fight. It is a way of generating candidates quickly, not a way of choosing between them — that still takes a judgement about which colour carries the most weight and how much saturation the others should give up.",
        },
        {
          question: "What are complementary colours?",
          answer:
            "Two hues directly opposite each other on the wheel — 180° apart. They give the strongest hue contrast available, which is why the pairing works for an accent against a dominant colour and rarely works for two colours of equal area. At full saturation an exact complementary pair can also appear to shimmer along the edge where they meet; splitting the complement 30° either side keeps most of the contrast and removes that effect.",
        },
        {
          question: "Why does this wheel look different from the one I am used to?",
          answer:
            "Two reasons. It is drawn in OKLCh rather than HSL, so every colour in the slice has the same perceived lightness instead of merely the same number — the yellows are not brighter than the blues here. And it is not a full disc: a pixel is painted only where the colour exists in sRGB, so the outer edge is the actual gamut boundary. Filling the disc would mean painting clipped colours your screen cannot display.",
        },
        {
          question: "Why does the wheel shrink when I move the lightness slider?",
          answer:
            "Because the range of chroma a screen can show depends on lightness. At 50% there is a lot of room; at 95% nearly everything is a pale tint and the most colourful thing available is barely saturated at all; at 5% the same is true of the dark end. The shrinking figure is an accurate picture of that, and it is why a tint ramp that holds chroma constant across all eleven steps produces fluorescent lights and glowing darks.",
        },
        {
          question: "Which scheme should I pick for a website?",
          answer:
            "Probably monochromatic, plus a neutral grey ramp and one more hue for destructive actions. Interfaces carry far less colour than a scheme generator implies: the dominant colour is usually a background you barely notice, and the accent is a few hundred pixels of button. Analogous is the next safest. Triadic and tetradic generate good screenshots and demand a lot of restraint to ship.",
        },
        {
          question: "Does the wheel send my colours anywhere?",
          answer:
            "No. The wheel is painted pixel by pixel in this tab with a canvas, and every rotation is arithmetic here. The page makes no network request after it loads, and the site's Content-Security-Policy sets connect-src 'self', so the browser would refuse one if something tried.",
        },
      ]}
      relatedTools={relatedTools("/color-wheel").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="grid gap-8 lg:grid-cols-[minmax(0,19rem)_minmax(0,1fr)] lg:gap-12">
        {/* ---- The wheel ----------------------------------------------- */}
        <div className="space-y-5">
          <div className="relative mx-auto w-full max-w-[300px]">
            <canvas
              ref={canvasRef}
              role="img"
              aria-label={`Colour wheel at lightness ${(lightness * 100).toFixed(0)} percent. Use the hue, chroma and lightness sliders below to change the selection.`}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              className="block aspect-square w-full cursor-crosshair rounded-full"
            />

            {/* Every colour in the scheme, marked where it falls. */}
            {scheme.map((color, index) => {
              const { left, top } = positionOf(color);
              return (
                <span
                  key={`${harmony}-${index}`}
                  aria-hidden="true"
                  className="pointer-events-none absolute h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow-[0_0_0_1.5px_rgba(0,0,0,0.55)]"
                  style={{
                    left: `${left * 100}%`,
                    top: `${top * 100}%`,
                    backgroundColor: toHex(color),
                  }}
                />
              );
            })}
          </div>

          <div className="space-y-4">
            <label className="block">
              <span className="flex items-baseline justify-between text-sm text-foreground-muted">
                Hue
                <span className="font-mono text-foreground">{Math.round(hue)}°</span>
              </span>
              <input
                type="range"
                min={0}
                max={359}
                step={1}
                value={Math.round(hue)}
                onChange={(event) => setHue(Number(event.target.value))}
                className="mt-2 w-full accent-accent-solid"
              />
            </label>

            <label className="block">
              <span className="flex items-baseline justify-between text-sm text-foreground-muted">
                Chroma
                <span className="font-mono text-foreground">{chroma.toFixed(3)}</span>
              </span>
              <input
                type="range"
                min={0}
                max={MAX_CHROMA}
                step={0.005}
                value={chroma}
                onChange={(event) => setChroma(Number(event.target.value))}
                className="mt-2 w-full accent-accent-solid"
              />
            </label>

            <label className="block">
              <span className="flex items-baseline justify-between text-sm text-foreground-muted">
                Lightness
                <span className="font-mono text-foreground">{(lightness * 100).toFixed(0)}%</span>
              </span>
              <input
                type="range"
                min={0.05}
                max={0.98}
                step={0.01}
                value={lightness}
                onChange={(event) => setLightness(Number(event.target.value))}
                className="mt-2 w-full accent-accent-solid"
              />
            </label>
          </div>

          <div>
            <label htmlFor="wheel-hex" className="mb-2 block text-sm text-foreground-muted">
              Or start from a colour you have
            </label>
            <input
              id="wheel-hex"
              type="text"
              defaultValue=""
              placeholder="#00a2b4, rebeccapurple, rgb(…)"
              spellCheck={false}
              autoComplete="off"
              autoCapitalize="off"
              onChange={(event) => {
                const parsed = parseColor(event.target.value);
                if (!parsed) return;
                const oklch = rgbToOklch(parsed);
                setHue(oklch.h);
                setChroma(Math.min(oklch.c, MAX_CHROMA));
                setLightness(oklch.l);
              }}
              className="w-full min-w-0 rounded-lg bg-surface-elevated px-3 py-2.5 font-mono text-base text-foreground outline-none focus-visible:ring-2 focus-visible:ring-accent"
            />
          </div>

          {clamped && (
            <p role="status" className="text-sm text-foreground-subtle">
              That chroma is outside sRGB at this hue and lightness, so the swatches show the
              nearest colour your screen can display — {toHex(base)}.
            </p>
          )}
        </div>

        {/* ---- The scheme ---------------------------------------------- */}
        <div className="min-w-0 space-y-8">
          <section>
            <h2 className="text-lg font-semibold tracking-tight text-foreground">Scheme</h2>
            <div
              role="radiogroup"
              aria-label="Harmony"
              className="mt-3 flex flex-wrap gap-2"
            >
              {HARMONIES.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  role="radio"
                  aria-checked={harmony === option.id}
                  onClick={() => setHarmony(option.id)}
                  className={`cursor-pointer rounded-pill px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] ${
                    harmony === option.id
                      ? "bg-accent-solid text-accent-on"
                      : "bg-surface-elevated text-foreground-muted hover:text-foreground"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
            <p className="mt-3 max-w-[62ch] text-sm text-foreground-muted">
              {HARMONIES.find((option) => option.id === harmony)?.blurb}
            </p>
          </section>

          <section>
            <div className="mb-3 flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h2 className="text-lg font-semibold tracking-tight text-foreground">
                {scheme.length} colours
              </h2>
              <button
                type="button"
                onClick={() => copy(`:root {\n${schemeCss}\n}`)}
                className="ml-auto cursor-pointer rounded-pill bg-surface-elevated px-4 py-1.5 text-xs font-medium text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
              >
                Copy as CSS variables
              </button>
            </div>

            <div
              className="grid gap-2"
              style={{ gridTemplateColumns: `repeat(${Math.min(scheme.length, 3)}, minmax(0, 1fr))` }}
            >
              {scheme.map((color, index) => {
                const oklch = rgbToOklch(color);
                return (
                  <div key={`swatch-${index}`}>
                    <Swatch
                      color={color}
                      value={toHex(color)}
                      caption={index === 0 ? "Base" : `${Math.round(oklch.h)}°`}
                      copied={copied}
                      onCopy={copy}
                      className="h-28"
                    />
                    <p className="mt-1.5 px-1 font-mono text-2xs text-foreground-subtle">
                      {contrastRatio(color, WHITE).toFixed(1)} /{" "}
                      {contrastRatio(color, BLACK).toFixed(1)}
                    </p>
                  </div>
                );
              })}
            </div>
            <p className="mt-2 text-xs text-foreground-subtle">
              Ratios against white and black. A colour needs 4.5:1 to carry body text.
            </p>
          </section>

          <section>
            <h2 className="mb-3 text-lg font-semibold tracking-tight text-foreground">
              The colour you picked
            </h2>
            <dl className="grid grid-cols-2 gap-4 rounded-lg bg-surface-elevated p-4 text-sm sm:grid-cols-4">
              {[
                ["HEX", toHex(base)],
                ["RGB", toRgbString(base)],
                ["HSL", toHslString(base)],
                ["Name", name ?? "—"],
              ].map(([label, value]) => (
                <div key={label} className="min-w-0">
                  <dt className="text-xs text-foreground-subtle">{label}</dt>
                  <dd className="mt-0.5 truncate font-mono text-foreground" title={value}>
                    {value}
                  </dd>
                </div>
              ))}
            </dl>
          </section>

          <section>
            <h2 className="mb-3 text-lg font-semibold tracking-tight text-foreground">
              The scheme on a surface
            </h2>
            <div
              className="rounded-xl p-6"
              style={{
                backgroundColor: toHex(scheme[scheme.length - 1]),
                color: contrastRatio(WHITE, scheme[scheme.length - 1]) >= 4.5 ? "#ffffff" : "#000000",
              }}
            >
              <p className="text-base leading-relaxed">
                A paragraph on the last colour in the scheme, so you can see whether it can carry
                text at all before you commit to it.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {scheme.slice(0, 3).map((color, index) => (
                  <span
                    key={`chip-${index}`}
                    className="rounded-pill px-4 py-2 text-sm font-medium"
                    style={{
                      backgroundColor: toHex(color),
                      color: contrastRatio(WHITE, color) >= contrastRatio(BLACK, color)
                        ? "#ffffff"
                        : "#000000",
                    }}
                  >
                    {toHex(color)}
                  </span>
                ))}
              </div>
            </div>
          </section>
        </div>
      </div>
    </ToolShell>
  );
};
