import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ColorWheelClient } from "./ColorWheelClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/color-wheel",
  title: "Color Wheel — Complementary and Triadic Schemes",
  socialTitle: "Color Wheel",
  description:
    "An interactive colour wheel drawn in OKLCh at a fixed lightness, with the real sRGB gamut as its edge. Returns complementary, analogous and triadic schemes.",
});

export default function ColorWheelPage() {
  return <ColorWheelClient />;
}
