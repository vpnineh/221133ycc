"use client";

import React, { useEffect, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { ImageResults } from "../../components/tools/ImageResults";
import { useImageBatch } from "../../components/tools/useImageBatch";
import { Notice } from "../../components/common/Notice";
import {
  btnPrimary,
  field,
  fieldLabel,
  segment,
  segmentTrack,
} from "../../components/common/controls";
import { type AcceptedFile } from "../../lib/files";
import {
  canEncode,
  encodeToTargetBytes,
  fitWithin,
  formatOfFile,
  FORMAT_EXTENSION,
  renderAndEncode,
  type ImageFormat,
} from "../../lib/images";
import { applyPattern, stemOf } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

type Output = "keep" | ImageFormat;
type Mode = "quality" | "target";

export const CompressImageClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [mode, setMode] = useState<Mode>("quality");
  const [quality, setQuality] = useState(0.75);
  const [targetKb, setTargetKb] = useState(200);
  const [output, setOutput] = useState<Output>("keep");
  const [maxWidth, setMaxWidth] = useState("");
  const [avifAvailable, setAvifAvailable] = useState<boolean | null>(null);
  const [namePattern, setNamePattern] = useState("");
  const { state, run, reset } = useImageBatch();

  // Feature-detect AVIF once, rather than guessing from the user agent. The
  // answer differs between Chrome, Firefox and Safari and has changed twice.
  useEffect(() => {
    let live = true;
    void canEncode("avif").then((ok) => {
      if (live) setAvifAvailable(ok);
    });
    return () => {
      live = false;
    };
  }, []);

  const compress = () => {
    const limit = Number(maxWidth);
    const capped = Number.isFinite(limit) && limit > 0 ? limit : null;

    void run(files, async (decoded, file, position) => {
      const format: ImageFormat = output === "keep" ? formatOfFile(file) : output;
      const size = capped
        ? fitWithin({ width: decoded.width, height: decoded.height }, { width: capped })
        : { width: decoded.width, height: decoded.height };

      const name = applyPattern(
        namePattern.trim() || "{name}",
        { name: stemOf(file.name), n: position },
        FORMAT_EXTENSION[format]
      );

      if (mode === "target") {
        const result = await encodeToTargetBytes(
          decoded.bitmap,
          size,
          { format, background: "#ffffff" },
          targetKb * 1024
        );
        if (!result.reached) {
          throw new Error(
            `${file.name} could not be brought under ${targetKb} KB. Even at the lowest quality this encoder offers it is ${Math.round(
              result.blob.size / 1024
            )} KB, because the image is ${decoded.width} × ${decoded.height}. Set a maximum width as well — halving the dimensions cuts the pixel count to a quarter, which is the only lever left once quality is exhausted.`
          );
        }
        return { blob: result.blob, name, width: size.width, height: size.height };
      }

      const blob = await renderAndEncode(decoded.bitmap, size, {
        format,
        quality,
        background: "#ffffff",
      });
      return { blob, name, width: size.width, height: size.height };
    });
  };

  const busy = state.status === "running";
  const pngSelected =
    output === "png" || (output === "keep" && files.some((entry) => formatOfFile(entry.file) === "png"));

  return (
    <ToolShell
      slug="compress-image"
      keyword="Compress Image"
      directAnswer="Compress Image re-encodes JPG, PNG and WebP files in your browser, either at a quality you choose or down to a file size you name. The preview you see is the actual encoded result rather than a scaled-down copy of the original, so the artefacts a setting introduces are visible before you download anything."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "Compress Image", url: "/compress-image" },
      ]}
      seoDescription="Compress images in your browser by quality or to a target file size. Batch processing, real encoded previews, WebP and AVIF output, and nothing uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Image compression is a trade you make on purpose: throw away detail the eye is least
              likely to miss, in exchange for a file that transfers faster. What separates a good
              result from a bad one is not the tool — it is knowing which knob to turn, and being
              able to see the cost before you commit.
            </p>

            <h3>What &ldquo;quality&rdquo; actually controls</h3>
            <p>
              In JPEG, quality scales the quantisation table. The encoder converts each 8 × 8 block
              of pixels into frequency coefficients, then divides them by that table and rounds —
              the rounding is where information is permanently lost. A high number divides gently
              and keeps fine detail; a low one divides hard, and whole coefficients collapse to
              zero. That is why artefacts appear as blocks and as ringing around sharp edges: the
              lost coefficients were the high frequencies that made the edge sharp.
            </p>
            <p>
              WebP and AVIF work differently in detail — they are derived from video codecs and
              predict each block from its neighbours before coding the difference — but the shape of
              the trade-off is the same, and so is the advice below.
            </p>

            <h3>Useful settings</h3>
            <p>
              Between 0.75 and 0.85, JPEG is visually indistinguishable from the original for almost
              any photograph, at roughly a third of the size. Above 0.95 the file grows steeply for
              nothing a person can see. Below 0.6 the artefacts are obvious in flat areas — a clear
              sky is where they show first. Text and line art are the exception: any lossy setting
              smears the edges, and those images belong in PNG or WebP&apos;s lossless mode.
            </p>

            <h3>Compressing to a target size</h3>
            <p>
              There is no way to ask an encoder for &ldquo;about 200 KB&rdquo;. The resulting size
              depends on the picture — a flat screenshot at quality 0.9 might be 40 KB where a
              detailed photograph at the same setting is 900 KB — so the only honest method is to
              encode, measure, and adjust. This tool binary-searches the quality range, which lands
              inside your budget in about seven encodes rather than the twenty a linear walk needs.
            </p>
            <p>
              The search is deliberately biased downwards: the result returned is always the best
              one that <em>fit</em>, never the nearest one that did not. A tool asked for
              &ldquo;under 200 KB&rdquo; that hands back 214 KB has failed at the one thing it was
              asked to do — usually because the upload form on the other end will reject it.
            </p>

            <h3>When quality is not the right lever</h3>
            <p>
              If an image will be displayed 800 pixels wide, storing it at 4000 pixels wide costs
              twenty-five times the pixels and buys nothing. Resolution is a much blunter and more
              effective saving than quality, and it is the first thing to try when a target size is
              out of reach — which is why there is a maximum-width box here as well as a quality
              slider.
            </p>

            <h3>Why re-compressing a JPEG twice is a bad idea</h3>
            <p>
              JPEG compression is not idempotent. Each pass re-quantises coefficients that were
              already quantised, on a block grid that may no longer line up, so artefacts accumulate
              — this is generation loss, the same effect as photocopying a photocopy. Compress from
              the original whenever you have it, and choose a lower quality once rather than a
              moderate quality three times.
            </p>

            <h3>Where the work happens</h3>
            <p>
              In this tab. The decode uses <code>createImageBitmap</code> and the encode uses the
              browser&apos;s own <code>canvas.toBlob</code>, which are the same C implementations
              your browser uses to display and save images anywhere else. Nothing is uploaded, and
              the page&apos;s Content-Security-Policy sets <code>connect-src &apos;self&apos;</code>,
              so an upload would be refused by the browser rather than merely not attempted.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `holiday.jpg — 4.2 MB
4032 x 3024, quality 0.75
max width 1600`,
        outputTitle: "Output",
        exampleOutput: `holiday.jpg — 268 KB
1600 x 1200
-94%`,
      }}
      referenceTable={{
        title: "Settings",
        rows: [
          {
            parameter: "Quality 0.9–1.0",
            type: "quality",
            defaultVal: "—",
            description:
              "Visually lossless and large. Worth it only when the image will be edited again afterwards.",
          },
          {
            parameter: "Quality 0.75–0.85",
            type: "quality",
            defaultVal: "0.75",
            description:
              "Indistinguishable from the original for most photographs, at roughly a third of the size. The default for a reason.",
          },
          {
            parameter: "Quality 0.5–0.7",
            type: "quality",
            defaultVal: "—",
            description:
              "Visible artefacts in flat areas such as sky. Acceptable for a thumbnail, not for a hero image.",
          },
          {
            parameter: "Target size",
            type: "KB",
            defaultVal: "200",
            description:
              "Binary-searches quality for the best result that fits. Always lands under the budget, never over.",
          },
          {
            parameter: "Max width",
            type: "pixels",
            defaultVal: "none",
            description:
              "Scales down first, preserving aspect ratio. Never enlarges. The strongest saving available.",
          },
          {
            parameter: "Same as source",
            type: "format",
            defaultVal: "default",
            description:
              "Keeps JPG as JPG and PNG as PNG. Note that a PNG re-encoded as PNG often grows.",
          },
          {
            parameter: "WebP",
            type: "format",
            defaultVal: "—",
            description:
              "Typically 25–35% smaller than JPEG at the same visible quality, with transparency. Supported by every current browser.",
          },
          {
            parameter: "AVIF",
            type: "format",
            defaultVal: "—",
            description:
              "Smaller again than WebP, especially at low quality. Encoding is slow and unavailable in some browsers, which this page detects rather than assumes.",
          },
        ],
      }}
      faqs={[
        {
          question: "What quality setting should I use?",
          answer:
            "0.8 for anything that matters and 0.75 for the web generally. Both are visually indistinguishable from the original on a photograph while cutting the file to roughly a third. Going above 0.95 grows the file steeply for detail nobody can see; going below 0.6 produces blocking in flat areas like skies and halos around text. If the image is a screenshot or a diagram, quality is the wrong lever entirely — use PNG or lossless WebP.",
        },
        {
          question: "Why did my PNG get bigger instead of smaller?",
          answer:
            "Because PNG is lossless, so a quality slider does nothing, and re-encoding it just re-runs the same compression with different tuning than whatever wrote it originally — often less aggressive tuning. If a PNG is large it is usually a photograph that should not have been a PNG in the first place: convert it to JPEG or WebP and it will typically fall by 80% or more. PNG is the right format for screenshots, logos and anything with sharp edges or transparency.",
        },
        {
          question: "Can it hit an exact file size?",
          answer:
            "It can get under one, which is what the requirement usually is. Encoders take a quality setting, not a size, and the size that results depends entirely on the picture — so this tool encodes, measures, and adjusts, binary-searching the quality range until it finds the best result that fits. It never returns something over your budget. If it cannot fit even at the lowest quality, it says so and suggests reducing the dimensions, because at that point pixels rather than quality are the problem.",
        },
        {
          question: "Is JPEG, WebP or AVIF the right output?",
          answer:
            "WebP is the best default now: 25–35% smaller than JPEG at the same visible quality, supported by every browser in current use, and it handles transparency. JPEG when the recipient is a system you do not control — an old CMS, a printing service, an email client. AVIF when size matters more than anything and you know the destination accepts it; it beats WebP by another 20–30%, but encoding is slow and not every browser can even produce it, which this page checks before offering it.",
        },
        {
          question: "Does compressing an image twice make it smaller?",
          answer:
            "It makes it worse. JPEG compression is not idempotent: the second pass re-quantises coefficients that were already quantised, on a block grid that may no longer align, and the damage accumulates. This is generation loss — the same reason a photocopy of a photocopy degrades. Always compress from the original, and pick a lower quality once rather than a moderate quality repeatedly.",
        },
        {
          question: "Are my photos uploaded anywhere?",
          answer:
            "No. The decode and the encode both use your browser's own image pipeline, running in this tab, and the files never leave your machine. You can verify it rather than believe it: open DevTools, watch the Network panel, and compress a batch — nothing is sent. The page is also served with connect-src 'self', so the browser would block an upload even if some future bug attempted one.",
        },
        {
          question: "Is metadata like GPS location removed?",
          answer:
            "Yes, as a side effect of how this works. The image is decoded to pixels and re-encoded from them, and EXIF blocks — camera model, timestamp, GPS coordinates — are not carried across. Orientation is the one tag that is honoured rather than dropped: it is applied to the pixels during decoding, so a photo taken sideways comes out the right way up rather than losing the tag and turning on its side.",
        },
      ]}
      relatedTools={relatedTools("/compress-image").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={["image/*", ".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif", ".bmp"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          multiple
          label="Drop images here"
          disabled={busy}
        />

        {files.length > 0 && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Mode</span>
              <div className={segmentTrack} role="group" aria-label="Compression mode">
                <button
                  type="button"
                  onClick={() => setMode("quality")}
                  aria-pressed={mode === "quality"}
                  className={segment(mode === "quality")}
                >
                  Quality
                </button>
                <button
                  type="button"
                  onClick={() => setMode("target")}
                  aria-pressed={mode === "target"}
                  className={segment(mode === "target")}
                >
                  Target size
                </button>
              </div>
            </div>

            {mode === "quality" ? (
              <div className="flex items-center gap-2">
                <label htmlFor="compress-quality" className={fieldLabel}>
                  Quality
                </label>
                <input
                  id="compress-quality"
                  type="range"
                  min={10}
                  max={100}
                  value={Math.round(quality * 100)}
                  onChange={(event) => setQuality(Number(event.target.value) / 100)}
                  className="w-32 accent-accent-solid"
                />
                <span className="w-8 font-mono text-2xs text-foreground-subtle">
                  {Math.round(quality * 100)}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <label htmlFor="compress-target" className={fieldLabel}>
                  Under
                </label>
                <input
                  id="compress-target"
                  type="number"
                  min={5}
                  max={20000}
                  value={targetKb}
                  onChange={(event) => setTargetKb(Math.max(5, Number(event.target.value) || 5))}
                  className={`${field} w-20`}
                />
                <span className="font-mono text-2xs text-foreground-subtle">KB</span>
              </div>
            )}

            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Format</span>
              <div className={segmentTrack} role="group" aria-label="Output format">
                {(["keep", "jpeg", "webp", "avif"] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setOutput(value)}
                    aria-pressed={output === value}
                    disabled={value === "avif" && avifAvailable === false}
                    className={`${segment(output === value)} disabled:cursor-not-allowed disabled:opacity-40`}
                    title={
                      value === "avif" && avifAvailable === false
                        ? "This browser cannot encode AVIF."
                        : undefined
                    }
                  >
                    {value === "keep" ? "Same" : value === "jpeg" ? "JPG" : value.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="compress-max-width" className={fieldLabel}>
                Max width
              </label>
              <input
                id="compress-max-width"
                type="number"
                min={16}
                value={maxWidth}
                onChange={(event) => setMaxWidth(event.target.value)}
                placeholder="none"
                className={`${field} w-24`}
              />
            </div>

            <button type="button" onClick={compress} disabled={busy} className={btnPrimary}>
              {busy ? "Compressing…" : `Compress ${files.length} image${files.length === 1 ? "" : "s"}`}
            </button>
          </div>
        )}

        {mode === "quality" && pngSelected && (
          <Notice tone="info">
            A quality setting does nothing to a PNG — it is lossless, so the slider is ignored and
            the file may well come out larger than it went in. If the image is a photograph, choose
            WebP or JPG above and expect it to fall by 80% or more. If it is a screenshot or a logo,
            PNG is already the right format and a maximum width is the only real saving available.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            mode="pattern"
            defaultStem="{name}"
            extension={output === "keep" ? "jpg" : FORMAT_EXTENSION[output]}
            sample={{ name: stemOf(files[0].file.name), n: 1 }}
            tokens={["name", "n", "date"]}
            value={namePattern}
            onChange={setNamePattern}
          />
        )}

        <ImageResults state={state} transparent={output === "png" || output === "keep"} />
      </div>
    </ToolShell>
  );
};
