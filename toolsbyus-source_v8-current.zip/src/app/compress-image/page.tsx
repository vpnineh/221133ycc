import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CompressImageClient } from "./CompressImageClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/compress-image",
  title: "Compress Image — Hit an Exact File Size",
  socialTitle: "Compress Image",
  description:
    "Compress JPG, PNG and WebP by quality or to a target file size, in your browser. The preview is the real encoded result, so you see the cost first.",
});

export default function CompressImagePage() {
  return <CompressImageClient />;
}
