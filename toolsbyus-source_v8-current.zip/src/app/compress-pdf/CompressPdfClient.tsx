"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { FileResult } from "../../components/tools/FileResult";
import { usePdfWorker } from "../../components/tools/usePdfWorker";
import { Notice } from "../../components/common/Notice";
import {
  btnPrimary,
  checkbox,
  fieldLabel,
  segment,
  segmentTrack,
} from "../../components/common/controls";
import { formatBytes, type AcceptedFile } from "../../lib/files";
import { stemOf, withStem } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { loadPdfJs, scaleForDpi, canvasToBlob } from "../../lib/pdfjs/load";
import { relatedTools } from "../../lib/tools";

type Mode = "lossless" | "raster";

export const CompressPdfClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [mode, setMode] = useState<Mode>("lossless");
  const [dpi, setDpi] = useState(120);
  const [quality, setQuality] = useState(0.6);
  const [stripMetadata, setStripMetadata] = useState(true);
  const [rasterising, setRasterising] = useState<{ done: number; total: number } | null>(null);
  const [rasterError, setRasterError] = useState<string | null>(null);
  const [outputName, setOutputName] = useState("");
  const { state, run, reset } = usePdfWorker();

  const file = files[0]?.file;
  const defaultStem = file ? `${stemOf(file.name)}-compressed` : "compressed";
  const chosenName = () => withStem(outputName.trim() || defaultStem, "pdf");

  const compressLossless = async () => {
    if (!file) return;
    setRasterError(null);
    const buffer = await file.arrayBuffer();
    run(
      {
        type: "compress",
        file: buffer,
        name: chosenName(),
        stripMetadata,
      },
      [buffer]
    );
  };

  /**
   * Renders every page to a JPEG, then rebuilds the document from those images.
   *
   * The rendering has to happen here rather than in the worker: pdf.js spawns
   * its own worker and draws onto a canvas, and a nested worker with canvas
   * access is not something to rely on across browsers. Each canvas is released
   * as soon as its page is encoded, which is what keeps a two-hundred-page scan
   * inside the tab's memory.
   */
  const compressRaster = async () => {
    if (!file) return;
    setRasterError(null);
    reset();

    try {
      const pdfjs = await loadPdfJs();
      const data = new Uint8Array(await file.arrayBuffer());
      const document_ = await pdfjs.getDocument({ data }).promise;

      const images: Array<{ bytes: ArrayBuffer; type: string }> = [];
      const sizes: Array<[number, number]> = [];
      setRasterising({ done: 0, total: document_.numPages });

      for (let pageNumber = 1; pageNumber <= document_.numPages; pageNumber++) {
        const page = await document_.getPage(pageNumber);
        // The page box at scale 1 is its size in PDF points, which is what the
        // rebuilt page must be — not the pixel count at the render scale.
        const box = page.getViewport({ scale: 1 });
        const viewport = page.getViewport({ scale: scaleForDpi(dpi) });

        const canvas = document.createElement("canvas");
        canvas.width = Math.floor(viewport.width);
        canvas.height = Math.floor(viewport.height);
        const context = canvas.getContext("2d");
        if (!context) throw new Error("This browser did not provide a 2D canvas context.");

        // JPEG has no alpha, and a PDF page has no background of its own.
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({ canvasContext: context, viewport }).promise;

        const blob = await canvasToBlob(canvas, "image/jpeg", quality);
        images.push({ bytes: await blob.arrayBuffer(), type: "image/jpeg" });
        sizes.push([box.width, box.height]);

        canvas.width = 0;
        canvas.height = 0;
        page.cleanup();
        setRasterising({ done: pageNumber, total: document_.numPages });
      }

      await document_.destroy();
      setRasterising(null);

      run(
        {
          type: "rasterToPdf",
          images,
          sizes,
          name: chosenName(),
        },
        images.map((image) => image.bytes)
      );
    } catch (caught) {
      setRasterising(null);
      setRasterError(caught instanceof Error ? caught.message : String(caught));
    }
  };

  const busy = state.status === "running" || rasterising !== null;

  // The saving, once there is a result to compare against.
  const resultBytes =
    state.status === "done" ? state.files.reduce((sum, entry) => sum + entry.bytes, 0) : null;
  const saving =
    resultBytes !== null && file && file.size > 0
      ? Math.round(((file.size - resultBytes) / file.size) * 100)
      : null;

  return (
    <ToolShell
      slug="compress-pdf"
      keyword="Compress PDF"
      directAnswer="Compress PDF makes a document smaller in your browser, two different ways. A lossless rebuild drops the unreachable objects that accumulate in an edited file and repacks the rest, keeping the text selectable. A rasterising pass re-renders every page as an image, which shrinks a scan dramatically and destroys its text layer — so the page tells you which one your file actually needs."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Compress PDF", url: "/compress-pdf" },
      ]}
      seoDescription="Compress a PDF in your browser with a lossless structural rebuild or a rasterising pass for scans. Honest about what each one saves and what it costs. No upload."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              &ldquo;Compress PDF&rdquo; is not one operation. A PDF&apos;s size can come from very
              different places, and the fix for one does nothing for the others — which is why a
              single magic button so often returns a file the same size as the one you gave it, or a
              file whose text has silently stopped being searchable.
            </p>

            <h3>Where the bytes actually are</h3>
            <p>
              In a scanned document, essentially all of them are in page images. In a report
              exported from a word processor, they are usually in embedded font subsets and in
              structural overhead. In a file that has been edited and re-saved a dozen times, a
              surprising share is in material that is no longer referenced at all: PDF supports
              incremental saving, where each edit appends to the file rather than rewriting it, so
              previous revisions can still be sitting in the bytes.
            </p>

            <h3>The lossless rebuild</h3>
            <p>
              This copies every page into a brand-new document. Copying walks the object graph from
              the page tree, so only what is actually reachable comes across — old revisions,
              orphaned fonts, images belonging to deleted pages and abandoned annotations are simply
              not visited. The result is then written with object streams, which pack the many small
              dictionaries describing pages, fonts and links into compressed streams rather than
              plain text.
            </p>
            <p>
              Nothing is re-encoded. Text stays selectable and searchable, vector art stays vector,
              images are untouched. On a heavily edited file this can remove a large fraction; on a
              file that was written cleanly in the first place it removes almost nothing, and this
              page reports the real number rather than a flattering one.
            </p>

            <h3>The rasterising pass</h3>
            <p>
              This renders each page with pdf.js — Mozilla&apos;s engine, the one Firefox uses — and
              rebuilds the document from those images as JPEGs. For a scan the difference is
              enormous: a 200 MB scan at 600 DPI becomes a few megabytes at 120 DPI with no visible loss,
              because the original resolution was far beyond what the content justified.
            </p>
            <p>
              It is also destructive in a way worth stating plainly. The text layer is gone. The
              document is no longer searchable, no longer selectable, no longer readable by a screen
              reader, and links stop working. For a scan there was no text layer to lose and this
              costs nothing. For a text document it turns a good file into a bad one, which is why
              it is not the default.
            </p>

            <h3>Choosing a resolution</h3>
            <p>
              120 DPI is legible on screen and prints acceptably. 150 DPI is comfortable for
              printing. 200 and above rarely earns its size for a scan of ordinary text. The
              JPEG quality matters just as much: 0.6 is the sweet spot for scanned text, where
              artefacts sit in the paper texture and nobody notices them.
            </p>

            <h3>What this tool will not claim</h3>
            <p>
              It will not promise a percentage. Any site advertising &ldquo;up to 90% smaller&rdquo;
              is quoting the rasterising case for a high-resolution scan and applying it to
              everything. If your PDF is already efficient, the honest answer is that it cannot get
              much smaller without losing something, and that is what you will be told here.
            </p>

            <h3>Everything happens in this tab</h3>
            <p>
              The rebuild runs in a Web Worker with pdf-lib; the rendering uses pdf.js, also in your
              browser. The document is never uploaded, and the page&apos;s
              Content-Security-Policy sets <code>connect-src &apos;self&apos;</code>, so an upload
              would be blocked by the browser rather than merely not attempted. For contracts,
              payslips and medical letters — the documents people most often need to shrink for an
              upload form — that is the only arrangement that makes sense.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `scan.pdf — 48.2 MB
12 pages at 600 DPI
mode: rasterise, 120 DPI, q0.6`,
        outputTitle: "Output",
        exampleOutput: `scan-compressed.pdf — 2.1 MB
-96%
text layer: none (there was none)`,
      }}
      referenceTable={{
        title: "Modes and settings",
        rows: [
          {
            parameter: "Lossless rebuild",
            type: "mode",
            defaultVal: "default",
            description:
              "Copies reachable objects into a fresh document and repacks with object streams. Text and vectors untouched.",
          },
          {
            parameter: "Rasterise",
            type: "mode",
            defaultVal: "—",
            description:
              "Re-renders pages as JPEGs. Huge saving on scans; permanently removes the text layer.",
          },
          {
            parameter: "120 DPI",
            type: "resolution",
            defaultVal: "default",
            description: "Legible on screen, acceptable in print. The right default for a scan.",
          },
          {
            parameter: "150 DPI",
            type: "resolution",
            defaultVal: "—",
            description: "Comfortable for printing. Roughly 1.5× the size of 120.",
          },
          {
            parameter: "200 DPI",
            type: "resolution",
            defaultVal: "—",
            description: "Rarely worth it for ordinary text. Nearly three times the size of 120.",
          },
          {
            parameter: "JPEG quality",
            type: "0.3 – 0.9",
            defaultVal: "0.6",
            description:
              "0.6 suits scanned text — artefacts hide in the paper texture. Raise it for photographs.",
          },
          {
            parameter: "Strip metadata",
            type: "checkbox",
            defaultVal: "on",
            description:
              "Drops title, author and producer. A few hundred bytes, and one less thing leaking who made the file.",
          },
          {
            parameter: "Page size",
            type: "preserved",
            defaultVal: "—",
            description:
              "The rebuilt page keeps its original size in points, so an A4 page prints as A4 whatever DPI was used.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did the lossless mode barely change my file size?",
          answer:
            "Because your PDF was already efficient. The lossless rebuild removes objects nothing references and repacks the structural dictionaries — that is a large win on a file edited and re-saved many times, and close to nothing on a file written cleanly by a modern exporter. It also does not touch images, so it cannot help a scan at all. If the bytes are in page images, the rasterising mode is the only thing that will move the number, and it has a real cost.",
        },
        {
          question: "Will compressing make my PDF text unsearchable?",
          answer:
            "Only in rasterising mode, and there it definitely will. Rasterising replaces each page with a picture of itself, so text stops being text: no searching, no selecting, no screen reader, no working links. For a scanned document that is free, because there was no text layer to begin with. For a report exported from a word processor it is a serious loss, which is why the lossless rebuild is the default and rasterising is a deliberate choice.",
        },
        {
          question: "What DPI should I use for a scan?",
          answer:
            "120 for something that will be read on screen and occasionally printed — it is legible and it is usually a 90%+ reduction from a 600 DPI scan. 150 if printing matters. Above 200 you are storing detail that the scanner's optics and the paper itself did not really contain. Pair it with JPEG quality around 0.6: scanned text hides compression artefacts in its paper texture better than almost any other content.",
        },
        {
          question: "Can it compress a password-protected PDF?",
          answer:
            "Not while it is encrypted. A PDF with a user password cannot be read at all without that password, so there is nothing to rebuild. Use the PDF unlocker first with the password you have. If you do not have it, no tool can help — and any site claiming otherwise is either uploading your file to a cracking service or simply lying about what it does.",
        },
        {
          question: "Is there a size limit?",
          answer:
            "100 MB per file, which is your browser's memory rather than a paywall. A PDF is held in memory several times over during a rebuild — parsed graph, new graph, serialised output — so a larger file would exhaust the tab and lose the work. Rasterising a very long document is the heaviest case, and each page's canvas is released as soon as its image is encoded specifically so that it remains possible.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. The rebuild runs in a Web Worker in this tab using pdf-lib, and the rendering uses pdf.js, also locally. Open DevTools and watch the Network panel while you compress — nothing carries your file. The page is served with connect-src 'self', so the browser itself would refuse an upload attempt.",
        },
      ]}
      relatedTools={relatedTools("/compress-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".pdf", "application/pdf"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
            setRasterError(null);
          }}
          label="Drop a PDF here"
          disabled={busy}
        />

        {file && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Mode</span>
              <div className={segmentTrack} role="group" aria-label="Compression mode">
                <button
                  type="button"
                  onClick={() => setMode("lossless")}
                  aria-pressed={mode === "lossless"}
                  className={segment(mode === "lossless")}
                >
                  Lossless
                </button>
                <button
                  type="button"
                  onClick={() => setMode("raster")}
                  aria-pressed={mode === "raster"}
                  className={segment(mode === "raster")}
                >
                  Rasterise
                </button>
              </div>
            </div>

            {mode === "raster" ? (
              <>
                <div className="flex items-center gap-2">
                  <span className={fieldLabel}>DPI</span>
                  <div className={segmentTrack} role="group" aria-label="Resolution">
                    {[100, 120, 150, 200].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setDpi(value)}
                        aria-pressed={dpi === value}
                        className={segment(dpi === value)}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <label htmlFor="pdf-quality" className={fieldLabel}>
                    Quality
                  </label>
                  <input
                    id="pdf-quality"
                    type="range"
                    min={30}
                    max={90}
                    value={Math.round(quality * 100)}
                    onChange={(event) => setQuality(Number(event.target.value) / 100)}
                    className="w-28 accent-accent-solid"
                  />
                  <span className="w-8 font-mono text-2xs text-foreground-subtle">
                    {Math.round(quality * 100)}
                  </span>
                </div>
              </>
            ) : (
              <label className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={stripMetadata}
                  onChange={(event) => setStripMetadata(event.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>Strip metadata</span>
              </label>
            )}

            <span className="font-mono text-2xs text-foreground-subtle">
              in: {formatBytes(file.size)}
            </span>

            <button
              type="button"
              onClick={() => void (mode === "raster" ? compressRaster() : compressLossless())}
              disabled={busy}
              className={btnPrimary}
            >
              {busy ? "Compressing…" : "Compress"}
            </button>
          </div>
        )}

        {mode === "raster" && file && (
          <Notice tone="warn">
            Rasterising replaces every page with a picture of itself. The document stops being
            searchable and selectable, screen readers can no longer read it, and links stop working
            — permanently, in the output file. For a scan that costs nothing, because there was no
            text layer to lose, and the saving is usually enormous. For a document exported from a
            word processor, use the lossless mode instead.
          </Notice>
        )}

        {rasterising && (
          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-2 flex items-baseline justify-between gap-3">
              <span className="text-xs text-foreground">
                Rendering page {rasterising.done + 1} of {rasterising.total} at {dpi} DPI
              </span>
              <span className="font-mono text-2xs text-foreground-subtle">
                {Math.round((rasterising.done / rasterising.total) * 100)}%
              </span>
            </div>
            <div
              role="progressbar"
              aria-valuenow={Math.round((rasterising.done / rasterising.total) * 100)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Rendering progress"
              className="h-1.5 overflow-hidden rounded-full bg-surface-elevated"
            >
              <div
                className="h-full bg-accent-solid"
                style={{
                  width: `${Math.max((rasterising.done / rasterising.total) * 100, 2)}%`,
                }}
              />
            </div>
          </div>
        )}

        {rasterError && <Notice tone="danger">{rasterError}</Notice>}

        {saving !== null && saving < 3 && mode === "lossless" && (
          <Notice tone="info">
            This file was already efficiently written — the rebuild found little to remove, so the
            result is {saving <= 0 ? "no smaller" : `only ${saving}% smaller`}. That is the honest
            answer rather than a failure: a lossless pass cannot shrink a document whose bytes are
            in its images. If it is a scan, the rasterising mode is the only thing that will change
            the number.
          </Notice>
        )}

        {file && (
          <OutputName
            defaultStem={defaultStem}
            extension="pdf"
            value={outputName}
            onChange={setOutputName}
          />
        )}

        <FileResult state={state} />
      </div>
    </ToolShell>
  );
};
