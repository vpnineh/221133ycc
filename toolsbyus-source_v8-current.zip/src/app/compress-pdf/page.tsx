import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CompressPdfClient } from "./CompressPdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/compress-pdf",
  title: "Compress PDF — Lossless or Rasterised",
  socialTitle: "Compress PDF",
  description:
    "Make a PDF smaller in your browser: a lossless rebuild that keeps text selectable, or a rasterising pass for scans. Honest about what each costs.",
});

export default function CompressPdfPage() {
  return <CompressPdfClient />;
}
