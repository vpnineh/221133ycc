"use client";

import React, { useMemo } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorInput, ValueRow, useColorField, useCopy } from "../../components/tools/ColorParts";
import { Icon } from "../../components/common/Icon";
import { relatedTools } from "../../lib/tools";
import {
  apcaLc,
  composite,
  contrastRatio,
  nudgeToContrast,
  toHex,
  wcagVerdict,
  type Rgb,
} from "../../lib/color";

const FALLBACK: Rgb = { r: 0, g: 0, b: 0, a: 1 };
const WHITE: Rgb = { r: 255, g: 255, b: 255, a: 1 };

/**
 * The four thresholds a real audit is measured against.
 *
 * Stated as the size they apply to rather than as bare numbers, because "4.5:1"
 * means nothing without "for text below 18.66px" — and picking the wrong row is
 * the commonest way a page passes a checker and fails an audit.
 */
const LEVELS = [
  {
    key: "normalAA",
    label: "Normal text, AA",
    threshold: 4.5,
    detail: "Body copy: under 18.66px, or under 14px bold. WCAG 1.4.3.",
  },
  {
    key: "normalAAA",
    label: "Normal text, AAA",
    threshold: 7,
    detail: "The enhanced level for the same sizes. WCAG 1.4.6.",
  },
  {
    key: "largeAA",
    label: "Large text, AA",
    threshold: 3,
    detail: "18.66px and up, or 14px and up bold. WCAG 1.4.3.",
  },
  {
    key: "uiAA",
    label: "Interface, AA",
    threshold: 3,
    detail: "Icons, focus rings, input borders, chart keys. WCAG 1.4.11.",
  },
] as const;

/** APCA's own guidance, expressed as what the number is good enough for. */
function apcaGuidance(lc: number): string {
  const magnitude = Math.abs(lc);
  if (magnitude >= 90) return "Any size, including thin weights and long body copy.";
  if (magnitude >= 75) return "Body text at 18px and up in a normal weight.";
  if (magnitude >= 60) return "Headlines and short text at 24px, or 16px bold.";
  if (magnitude >= 45) return "Large headlines only — 36px and up, or 24px bold.";
  if (magnitude >= 30) return "Not for text. Borders, dividers and disabled states.";
  return "Not readable. Treat this as invisible.";
}

export const ContrastCheckerClient: React.FC = () => {
  const foreground = useColorField("#6d6d74");
  const background = useColorField("#ffffff");
  const { copied, copy } = useCopy();

  const fg = foreground.color ?? FALLBACK;
  const bg = background.color ?? WHITE;

  const verdict = useMemo(() => wcagVerdict(fg, bg), [fg, bg]);
  const lc = useMemo(() => apcaLc(fg, bg), [fg, bg]);

  // Only computed when it is needed, because it walks up to a thousand
  // candidate lightnesses and there is no reason to do that on a pair that
  // already passes.
  const suggestion = useMemo(
    () => (verdict.normalAA ? null : nudgeToContrast(fg, bg, 4.5)),
    [fg, bg, verdict.normalAA]
  );

  // What the browser will actually paint, which is what the ratio is measured
  // against. Only worth showing when it differs from what was typed.
  const composited = fg.a < 1 ? composite(fg, bg) : null;

  const ratio = verdict.ratio;
  const ratioText = `${ratio.toFixed(2)}:1`;

  return (
    <ToolShell
      slug="contrast-checker"
      keyword="Contrast Checker"
      directAnswer="Contrast Checker measures a text colour against its background and reports the WCAG 2.2 ratio, which levels it passes, and the APCA lightness contrast alongside. It composites a translucent foreground before measuring — the reason most checkers disagree with the browser — and when a pair fails it finds the nearest passing colour by moving lightness in OKLCh, so the result keeps the hue you started with."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "Contrast Checker", url: "/contrast-checker" },
      ]}
      seoDescription="Check colour contrast against WCAG 2.2 AA and AAA for normal text, large text and interface components, with APCA reported alongside and a suggested passing colour that keeps your hue."
      howItWorks={{
        inputTitle: "The two colours",
        outputTitle: "What is reported",
        exampleInput: `foreground  #6d6d74
background  #ffffff`,
        exampleOutput: `ratio        4.55 : 1
normal AA    pass   (needs 4.5)
normal AAA   fail   (needs 7)
large AA     pass   (needs 3)
APCA         Lc 63.4`,
        algorithmExplanation: (
          <>
            <p>
              Contrast is a ratio between two relative luminances. Each channel is taken out of its
              sRGB encoding — the piecewise transfer function from IEC 61966-2-1, not a plain
              gamma of 2.2 — then weighted 0.2126 red, 0.7152 green, 0.0722 blue, which is roughly
              how much each contributes to what the eye reads as brightness. The two luminances go
              into <code>(lighter + 0.05) / (darker + 0.05)</code>, and the 0.05 is a flare
              allowance standing in for the light your screen is reflecting off the room.
            </p>
            <h3>Why a translucent colour needs compositing first</h3>
            <p>
              A colour at 50% alpha has no contrast ratio of its own. What a reader sees is the
              blend of it and whatever is behind it, so the blend is what gets measured. Checkers
              that skip this step report the ratio of the unblended colour, which is always better
              than the truth — and it is the single most common reason a tool disagrees with the
              browser&rsquo;s own inspector.
            </p>
            <h3>Where WCAG 2.x is known to be wrong</h3>
            <p>
              The 2.x formula was never derived from readability research; it is a simple luminance
              ratio, and it fails in both directions. It passes some light grey on white that
              nobody can read, and fails some dark pairs that are perfectly legible. It also treats
              black-on-white and white-on-black as identical at 21:1, when light text on a dark
              background is measurably harder to read at the same ratio.
            </p>
            <p>
              APCA is the model behind the WCAG 3 draft. It is polarity-aware — the sign of the
              number tells you which way round the pair is — and returns a lightness contrast
              value, Lc, rather than a ratio. It is reported here <em>alongside</em> the 2.x ratio
              and never instead of it, because conformance is still measured against 2.x and a tool
              that quietly swapped the metric would tell people they had passed an audit they had
              not.
            </p>
            <h3>How the suggestion is found</h3>
            <p>
              When a pair fails, the nearest passing colour is found by walking lightness in OKLCh
              and holding hue and chroma. Walking sRGB channels instead drifts the hue as the
              colour darkens, so the suggestion comes back a different colour from the one in your
              palette. The search moves away from the background first — darker on a light page,
              lighter on a dark one — so a dark brand colour stays dark instead of flipping to
              near-white.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "Thresholds and what they apply to",
        rows: [
          {
            parameter: "4.5:1",
            type: "AA",
            defaultVal: "1.4.3",
            description:
              "Normal text: anything below 18.66px (14pt), or below 24px (18pt) if bold. The level nearly every legal requirement points at.",
          },
          {
            parameter: "3:1",
            type: "AA",
            defaultVal: "1.4.3",
            description:
              "Large text: 18.66px and up, or 14px and up when bold. Measured at the rendered size, not the CSS declaration on a parent.",
          },
          {
            parameter: "7:1",
            type: "AAA",
            defaultVal: "1.4.6",
            description:
              "Enhanced contrast for normal text. Rarely required outside public-sector procurement, and hard to reach with a brand palette.",
          },
          {
            parameter: "3:1",
            type: "AA",
            defaultVal: "1.4.11",
            description:
              "Non-text: icons, focus indicators, input borders, chart series, the boundary of a button. Added in WCAG 2.1 and still the most-missed rule.",
          },
          {
            parameter: "Lc 60",
            type: "APCA",
            defaultVal: "draft",
            description:
              "Roughly where 16px bold or 24px normal becomes comfortable. APCA has no pass or fail — the number maps to a size and weight.",
          },
          {
            parameter: "Lc 90",
            type: "APCA",
            defaultVal: "draft",
            description: "Enough for any size and weight, including thin fonts and long body copy.",
          },
          {
            parameter: "alpha",
            type: "0–1",
            defaultVal: "1",
            description:
              "A translucent foreground is composited onto the background before measuring, because that is what the reader sees.",
          },
          {
            parameter: "Disabled text",
            type: "—",
            defaultVal: "exempt",
            description:
              "WCAG exempts inactive controls from 1.4.3 entirely. Legal to leave illegible, and still worth fixing.",
          },
        ],
      }}
      faqs={[
        {
          question: "What contrast ratio do I need to pass WCAG?",
          answer:
            "4.5:1 for normal text and 3:1 for large text, at level AA. Large means 18.66px and up, or 14px and up when bold. Level AAA raises those to 7:1 and 4.5:1. Separately, WCAG 1.4.11 requires 3:1 for anything non-text that carries meaning — icons, focus rings, input borders — which is the rule most audits find failing.",
        },
        {
          question: "Why does this show a different ratio from another checker?",
          answer:
            "Almost always alpha. A foreground below 100% opacity has no ratio of its own: what a reader sees is that colour blended with the background, so the blend is what gets measured. This tool composites first; several popular checkers do not, and report a better ratio than the page actually has. If both colours are opaque and the numbers still differ, one of the two is applying a plain 2.2 gamma instead of the sRGB piecewise transfer function.",
        },
        {
          question: "Is 4.5:1 enough for a 14px font?",
          answer:
            "It is what AA requires, and it is thin. 4.5:1 was set as a minimum, not a target, and at 14px in a light weight on a phone in daylight it is genuinely hard. If the text matters, aim past 7:1 or increase the size. APCA is more useful here than the 2.x ratio, because it ties the number to a size and weight rather than treating all text the same.",
        },
        {
          question: "Should I use APCA or WCAG 2.x?",
          answer:
            "Both, for different purposes. WCAG 2.x is what conformance is measured against today, so it is what you report. APCA is the better guide to whether something is actually readable, and it is the direction the standard is going. Where they disagree — usually light greys on white, or mid-tones on dark — APCA is the one to trust with your eyes.",
        },
        {
          question: "Does contrast apply to disabled buttons and placeholder text?",
          answer:
            "Disabled controls are exempt from WCAG 1.4.3 outright. Placeholder text is not: it is text, it carries information, and it needs 4.5:1 like any other body copy. The common pattern of grey placeholder text at around 2.5:1 fails, and it fails on exactly the people who most need the hint.",
        },
        {
          question: "Does this work on a colour with transparency?",
          answer:
            "Yes. Enter an 8-digit hex or an rgba value and the foreground is composited onto the background before the ratio is computed, which is what the browser paints. The composited colour is shown so you can see the value the ratio actually refers to.",
        },
      ]}
      relatedTools={relatedTools("/contrast-checker").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="grid gap-6 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] lg:gap-10">
        {/* ---- Inputs ------------------------------------------------- */}
        <div className="space-y-5">
          <ColorInput
            label="Text colour"
            value={foreground.text}
            onChange={foreground.setText}
            parsed={foreground.color}
            placeholder="#6d6d74"
          />
          <ColorInput
            label="Background colour"
            value={background.text}
            onChange={background.setText}
            parsed={background.color}
            placeholder="#ffffff"
          />

          <button
            type="button"
            onClick={() => {
              const a = foreground.text;
              foreground.setText(background.text);
              background.setText(a);
            }}
            className="inline-flex cursor-pointer items-center gap-2 rounded-pill bg-surface-elevated px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
          >
            <Icon name="swap" size="md" className="text-foreground-subtle" />
            Swap them
          </button>

          {composited && (
            <p className="rounded-lg bg-surface-elevated p-4 text-sm leading-relaxed text-foreground-muted">
              At {Math.round(fg.a * 100)}% opacity the browser paints{" "}
              <code className="font-mono text-foreground">{toHex(composited)}</code>. That is the
              colour measured below, because it is the colour a reader sees.
            </p>
          )}
        </div>

        {/* ---- Result ------------------------------------------------- */}
        <div className="min-w-0">
          <div
            className="rounded-xl p-6 sm:p-8"
            style={{ backgroundColor: toHex(bg), color: toHex(fg) }}
          >
            <p className="text-3xl font-semibold tracking-[-0.03em] sm:text-[2.5rem]">
              {ratioText}
            </p>
            <p className="mt-4 text-[1.0625rem] leading-relaxed">
              The quick brown fox jumps over the lazy dog. This paragraph is set at the size WCAG
              calls normal text.
            </p>
            <p className="mt-3 text-2xl font-bold leading-snug">And this is large text.</p>
          </div>

          <div className="mt-6 grid gap-2 sm:grid-cols-2">
            {LEVELS.map((level) => {
              const passes = verdict[level.key];
              return (
                <div
                  key={level.key}
                  className={`rounded-lg p-4 ${passes ? "bg-add-soft" : "bg-del-soft"}`}
                >
                  <div className="flex items-center gap-2">
                    <Icon
                      name={passes ? "check" : "close"}
                      size="md"
                      className={passes ? "text-add" : "text-del"}
                    />
                    <span className="text-[0.9375rem] font-semibold text-foreground">
                      {level.label}
                    </span>
                    <span
                      className={`ml-auto font-mono text-xs ${passes ? "text-add" : "text-del"}`}
                    >
                      {passes ? "Pass" : "Fail"} · {level.threshold}:1
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-foreground-muted">
                    {level.detail}
                  </p>
                </div>
              );
            })}
          </div>

          {/* APCA, second and clearly labelled as the other metric. */}
          <div className="mt-6 rounded-lg bg-surface-elevated p-5">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className="text-[0.9375rem] font-semibold text-foreground">
                APCA Lc {lc.toFixed(1)}
              </span>
              <span className="text-sm text-foreground-subtle">
                {lc < 0 ? "light text on dark" : "dark text on light"}
              </span>
            </div>
            <p className="mt-1.5 text-sm leading-relaxed text-foreground-muted">
              {apcaGuidance(lc)} APCA is the WCAG 3 draft model and has no pass or fail — the
              number maps to a size and weight.
            </p>
          </div>

          {suggestion && (
            <div className="mt-6 rounded-lg bg-surface-elevated p-5">
              <p className="text-[0.9375rem] font-semibold text-foreground">
                {suggestion.reached
                  ? "The nearest colour that passes AA"
                  : "The best this hue can reach on this background"}
              </p>
              <p className="mt-1.5 text-sm leading-relaxed text-foreground-muted">
                {suggestion.reached
                  ? "Found by moving lightness in OKLCh, so the hue is the one you started with."
                  : "Even at full black or white this hue cannot reach 4.5:1 here. The background has to change too."}
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <span
                  className="flex h-12 w-12 flex-none items-center justify-center rounded-lg"
                  style={{ backgroundColor: toHex(suggestion.color) }}
                  aria-hidden="true"
                />
                <button
                  type="button"
                  onClick={() => foreground.setText(toHex(suggestion.color))}
                  className="cursor-pointer rounded-pill bg-accent-solid px-5 py-2.5 text-sm font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  Use {toHex(suggestion.color)}
                </button>
                <span className="font-mono text-sm text-foreground-muted">
                  {contrastRatio(suggestion.color, bg).toFixed(2)}:1
                </span>
              </div>
            </div>
          )}

          <div className="mt-6">
            <ValueRow
              label="Ratio"
              value={ratioText}
              copied={copied}
              onCopy={copy}
            />
            <ValueRow label="Text" value={toHex(fg)} copied={copied} onCopy={copy} />
            <ValueRow label="Background" value={toHex(bg)} copied={copied} onCopy={copy} />
          </div>
        </div>
      </div>
    </ToolShell>
  );
};
