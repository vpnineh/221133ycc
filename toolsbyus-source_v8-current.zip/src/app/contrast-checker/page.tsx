import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ContrastCheckerClient } from "./ContrastCheckerClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/contrast-checker",
  title: "Contrast Checker — WCAG 2.2 AA, AAA and APCA",
  socialTitle: "Contrast Checker",
  description:
    "Check a text and background pair against WCAG 2.2 AA and AAA, see the APCA figure beside it, and get the nearest colour that passes without losing the hue.",
});

export default function ContrastCheckerPage() {
  return <ContrastCheckerClient />;
}
