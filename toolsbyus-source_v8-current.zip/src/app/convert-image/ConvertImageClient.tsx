"use client";

import React, { useEffect, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { ImageResults } from "../../components/tools/ImageResults";
import { useImageBatch } from "../../components/tools/useImageBatch";
import { Notice } from "../../components/common/Notice";
import { btnPrimary, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { type AcceptedFile } from "../../lib/files";
import {
  canEncode,
  FORMAT_EXTENSION,
  FORMAT_NOTES,
  renderAndEncode,
  type ImageFormat,
} from "../../lib/images";
import { applyPattern, stemOf } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

const FORMATS: ImageFormat[] = ["jpeg", "png", "webp", "avif"];
const LABEL: Record<ImageFormat, string> = { jpeg: "JPG", png: "PNG", webp: "WebP", avif: "AVIF" };

export const ConvertImageClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [format, setFormat] = useState<ImageFormat>("webp");
  const [quality, setQuality] = useState(0.85);
  const [background, setBackground] = useState("#ffffff");
  const [avifAvailable, setAvifAvailable] = useState<boolean | null>(null);
  const [namePattern, setNamePattern] = useState("");
  const { state, run, reset } = useImageBatch();

  useEffect(() => {
    let live = true;
    void canEncode("avif").then((ok) => {
      if (live) setAvifAvailable(ok);
    });
    return () => {
      live = false;
    };
  }, []);

  const convert = () => {
    void run(files, async (decoded, file, position) => {
      const blob = await renderAndEncode(
        decoded.bitmap,
        { width: decoded.width, height: decoded.height },
        { format, quality, background }
      );
      return {
        blob,
        name: applyPattern(
          namePattern.trim() || "{name}",
          { name: stemOf(file.name), n: position },
          FORMAT_EXTENSION[format]
        ),
        width: decoded.width,
        height: decoded.height,
      };
    });
  };

  const busy = state.status === "running";
  const losesAlpha = format === "jpeg";

  return (
    <ToolShell
      slug="convert-image"
      keyword="Convert Image"
      directAnswer="Convert Image changes an image between JPG, PNG, WebP and AVIF in your browser. The conversion uses the browser's own codecs, and the one thing tools usually get wrong — converting a transparent image to a format with no alpha channel — is handled by painting a background you choose rather than letting transparency encode as black."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "Convert Image", url: "/convert-image" },
      ]}
      seoDescription="Convert JPG, PNG, WebP and AVIF in the browser, in batches, with correct handling of transparency and a feature-detected AVIF encoder. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Converting an image is a decode followed by an encode. The source is turned into raw
              pixels, and those pixels are written out under a different set of rules. Nothing is
              translated directly between formats, which is why a conversion is never entirely free
              and why the choice of target matters.
            </p>

            <h3>The transparency trap</h3>
            <p>
              JPEG has no alpha channel. When a PNG with a transparent background is converted to
              JPEG, those pixels have to become <em>something</em>, and a canvas that has not been
              painted is transparent black — so they become black. This is behind almost every
              &ldquo;my logo came out on a black square&rdquo; report on the internet.
            </p>
            <p>
              The fix is one rectangle: fill the canvas with a chosen colour before drawing the
              image, so semi-transparent pixels composite against it properly instead of being
              interpreted as zero. That colour is a control here rather than a hard-coded white,
              because a logo built for a dark site needs a dark background and white would be just
              as wrong as black.
            </p>

            <h3>What each format is for</h3>
            <p>
              <strong>JPEG</strong> is lossy, universal, and has no transparency. It is built for
              continuous tone, which is why it is excellent on photographs and poor on text — its
              artefacts hide in detail and stand out against flat colour. Every device made in the
              last thirty years opens it, which is still the reason to choose it.
            </p>
            <p>
              <strong>PNG</strong> is lossless and keeps transparency. Screenshots, logos, diagrams
              and anything with sharp edges belong here; a lossy format smears exactly the edges
              that make them readable. The cost is size: a photograph as PNG is often ten times the
              JPEG.
            </p>
            <p>
              <strong>WebP</strong> is typically 25–35% smaller than JPEG at the same visible
              quality, supports transparency, and has a lossless mode that usually beats PNG. It is
              supported by every browser in current use and is the sensible default for the web now.
            </p>
            <p>
              <strong>AVIF</strong> is smaller again — often 20–30% below WebP — and noticeably
              better at low bit rates, where JPEG falls apart. The costs are encoding time and
              availability: not every browser can produce one. This page tests that by encoding a
              1 × 1 image before offering the option, rather than guessing from the user agent,
              which would be wrong within a year.
            </p>

            <h3>Lossy to lossless does not undo the loss</h3>
            <p>
              Converting a JPEG to PNG produces a lossless copy of an image that has already lost
              information. The artefacts are now preserved perfectly and the file is several times
              larger. It is occasionally the right move — if the image is about to be edited
              repeatedly, a lossless intermediate stops the damage compounding — but it is not a
              way to recover quality, and nothing is.
            </p>

            <h3>Going the other way costs a generation</h3>
            <p>
              Converting a JPEG to another JPEG, or to WebP, re-quantises data that was already
              quantised. Each pass adds artefacts on a block grid that may not line up with the
              previous one. Convert from the original whenever you have it.
            </p>

            <h3>What happens to metadata</h3>
            <p>
              Because the pipeline goes through raw pixels, EXIF blocks do not survive: camera model,
              timestamp and GPS coordinates are all dropped. For most uses that is a feature — a
              photo posted online carries its location otherwise. The single tag that is honoured
              rather than discarded is orientation, which is applied to the pixels during decoding
              so that a sideways-shot photo comes out upright.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `logo.png — 148 KB
transparent background
target: JPG, background #ffffff`,
        outputTitle: "Output",
        exampleOutput: `logo.jpg — 22 KB
white composited behind
alpha channel dropped`,
      }}
      referenceTable={{
        title: "Formats",
        rows: [
          {
            parameter: "JPG",
            type: "lossy",
            defaultVal: "—",
            description: FORMAT_NOTES.jpeg,
          },
          {
            parameter: "PNG",
            type: "lossless",
            defaultVal: "—",
            description: FORMAT_NOTES.png,
          },
          {
            parameter: "WebP",
            type: "lossy / lossless",
            defaultVal: "default",
            description: FORMAT_NOTES.webp,
          },
          {
            parameter: "AVIF",
            type: "lossy",
            defaultVal: "—",
            description: FORMAT_NOTES.avif,
          },
          {
            parameter: "Quality",
            type: "0.1 – 1.0",
            defaultVal: "0.85",
            description: "Applies to JPG, WebP and AVIF. PNG ignores it, being lossless.",
          },
          {
            parameter: "Background",
            type: "colour",
            defaultVal: "#ffffff",
            description:
              "Painted behind the image when the target has no alpha channel. Prevents transparency encoding as black.",
          },
          {
            parameter: "HEIC input",
            type: "supported",
            defaultVal: "—",
            description:
              "Decoded with libheif, loaded only when a HEIC is dropped. See the HEIC to JPG tool for detail.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did my PNG turn black when converted to JPG?",
          answer:
            "Because JPEG has no alpha channel, and a transparent pixel drawn onto an unpainted canvas is transparent black — so the encoder writes black. It is the most common bug in browser image conversion and it has a one-line fix: paint a background before drawing the image. This tool does that, and lets you pick the colour, because a logo designed for a dark site needs a dark background and white would be just as wrong.",
        },
        {
          question: "Which format should I convert to?",
          answer:
            "WebP for the web: 25–35% smaller than JPEG at the same visible quality, transparency included, supported by every current browser. JPG when the destination is a system you do not control — an old CMS, a print service, an email client. PNG for screenshots, logos and diagrams, where lossless matters more than size. AVIF when size is critical and you know the recipient can read it.",
        },
        {
          question: "Will converting to PNG improve my JPEG?",
          answer:
            "No. It makes a perfect lossless copy of an image that has already lost information, at several times the file size — the JPEG artefacts are preserved in full fidelity. Nothing can recover detail a lossy encoder discarded. Converting to PNG is worth doing only when the image is about to be edited repeatedly and you want to stop the damage compounding across saves.",
        },
        {
          question: "Can it convert HEIC files?",
          answer:
            "Yes. If the browser refuses the file and its bytes are a HEIF container, a WebAssembly build of libheif is loaded to decode it — and only then, so nobody converting a JPEG pays for that download. Safari decodes HEIC natively and never needs it at all. There is a dedicated HEIC to JPG page with more detail about why this is necessary.",
        },
        {
          question: "Is there a limit on how many images I can convert?",
          answer:
            "100 files per selection, 100 MB per file and 250 MB in total — limits set by what a browser tab can hold rather than by a paywall, since everything runs on your machine. Files are processed one at a time instead of in parallel, deliberately: several large bitmaps alive at once is what actually kills a mobile tab.",
        },
        {
          question: "Does the conversion strip EXIF and GPS data?",
          answer:
            "Yes, as an unavoidable consequence of decoding to pixels and re-encoding from them. Camera model, timestamp and GPS coordinates do not survive, which is usually what you want before posting an image publicly. Orientation is the exception: it is applied to the pixels rather than dropped, so a photo taken sideways is upright in the output instead of falling over.",
        },
      ]}
      relatedTools={relatedTools("/convert-image").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={["image/*", ".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif", ".gif", ".bmp"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          multiple
          label="Drop images here"
          disabled={busy}
        />

        {files.length > 0 && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Convert to</span>
              <div className={segmentTrack} role="group" aria-label="Target format">
                {FORMATS.map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setFormat(value)}
                    aria-pressed={format === value}
                    disabled={value === "avif" && avifAvailable === false}
                    className={`${segment(format === value)} disabled:cursor-not-allowed disabled:opacity-40`}
                    title={
                      value === "avif" && avifAvailable === false
                        ? "This browser cannot encode AVIF."
                        : FORMAT_NOTES[value]
                    }
                  >
                    {LABEL[value]}
                  </button>
                ))}
              </div>
            </div>

            {format !== "png" && (
              <div className="flex items-center gap-2">
                <label htmlFor="convert-quality" className={fieldLabel}>
                  Quality
                </label>
                <input
                  id="convert-quality"
                  type="range"
                  min={10}
                  max={100}
                  value={Math.round(quality * 100)}
                  onChange={(event) => setQuality(Number(event.target.value) / 100)}
                  className="w-32 accent-accent-solid"
                />
                <span className="w-8 font-mono text-2xs text-foreground-subtle">
                  {Math.round(quality * 100)}
                </span>
              </div>
            )}

            {losesAlpha && (
              <div className="flex items-center gap-2">
                <label htmlFor="convert-background" className={fieldLabel}>
                  Background
                </label>
                <input
                  id="convert-background"
                  type="color"
                  value={background}
                  onChange={(event) => setBackground(event.target.value)}
                  className="h-7 w-10 cursor-pointer rounded border border-border bg-surface p-0.5"
                />
                <input
                  type="text"
                  aria-label="Background colour hex value"
                  value={background}
                  onChange={(event) => setBackground(event.target.value)}
                  spellCheck={false}
                  className={`${field} w-24`}
                />
              </div>
            )}

            <button type="button" onClick={convert} disabled={busy} className={btnPrimary}>
              {busy ? "Converting…" : `Convert ${files.length} image${files.length === 1 ? "" : "s"}`}
            </button>
          </div>
        )}

        {losesAlpha && files.length > 0 && (
          <Notice tone="info">
            JPG has no alpha channel, so any transparency is composited against the background
            colour above. Leave it white for most things; set it to your page colour if the image is
            a logo that will sit on a coloured background. Choosing WebP or PNG instead keeps the
            transparency intact.
          </Notice>
        )}

        {/* Gated on a file being present so it appears with the controls rather
            than on its own a moment after load. The AVIF check is an async
            encode, so an ungated notice inserts itself into a settled page and
            pushes everything below it down — a layout shift for information
            nobody has asked for yet. */}
        {avifAvailable === false && files.length > 0 && (
          <Notice tone="warn">
            This browser can display AVIF but cannot encode it, so that option is disabled. That is
            a limitation of the browser rather than of this page — Chromium-based browsers can
            encode AVIF from a canvas, Firefox and Safari currently cannot. WebP is available
            everywhere and gets most of the way there.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            mode="pattern"
            defaultStem="{name}"
            extension={FORMAT_EXTENSION[format]}
            sample={{ name: stemOf(files[0].file.name), n: 1 }}
            tokens={["name", "n", "date"]}
            value={namePattern}
            onChange={setNamePattern}
          />
        )}

        <ImageResults state={state} transparent={format === "png" || format === "webp"} />
      </div>
    </ToolShell>
  );
};
