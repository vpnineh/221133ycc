import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ConvertImageClient } from "./ConvertImageClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/convert-image",
  title: "Convert Image — JPG, PNG, WebP and AVIF",
  socialTitle: "Convert Image",
  description:
    "Convert JPG, PNG, WebP and AVIF in your browser. Transparency is composited against a colour you pick, so a converted PNG never comes out black.",
});

export default function ConvertImagePage() {
  return <ConvertImageClient />;
}
