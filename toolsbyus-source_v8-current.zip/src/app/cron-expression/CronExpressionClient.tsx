"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Notice } from "../../components/common/Notice";
import { btnCompact, field, fieldLabel } from "../../components/common/controls";
import { parseCron, nextRuns, frequencySummary, CRON_EXAMPLES } from "../../lib/cron";
import { useNow } from "../../lib/use-now";
import { relatedTools } from "../../lib/tools";

export const CronExpressionClient: React.FC = () => {
  const [expression, setExpression] = useState("0 9 * * 1-5");
  // Zero on the server, so the markup does not name a moment the browser will
  // disagree with a millisecond later. Ticking once a minute: the next fire
  // time does not need second-by-second precision.
  const now = useNow(60_000);

  const parsed = useMemo(() => parseCron(expression), [expression]);
  const runs = useMemo(
    () => (parsed.ok && now !== 0 ? nextRuns(parsed.value, new Date(now), 10) : []),
    [parsed, now]
  );

  return (
    <ToolShell
      wide
      slug="cron-expression"
      keyword="Cron Expression Parser"
      directAnswer="Cron Expression Parser explains a schedule in English and lists its next ten runs, in your browser. It states the rule that catches almost everyone: when both day-of-month and day-of-week are restricted, cron ORs them — so 0 0 13 * 5 fires on the 13th or on any Friday, and is not Friday the 13th."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "Cron Expression", url: "/cron-expression" },
      ]}
      seoDescription="Parse and explain cron expressions in the browser. Supports 5, 6 and 7 fields, names, steps, wrapping ranges and @daily shorthands, with the next ten fire times computed in UTC."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Cron is five numbers and yet it is reliably misread. Three things account for almost
              all of it.
            </p>
            <h3>The two day fields are ORed, not ANDed</h3>
            <p>
              Every other pair of fields intersects: <code>0 9 * 6 *</code> is nine o&apos;clock in
              June, hour <em>and</em> month. The day fields do not. When both day-of-month and
              day-of-week are restricted, the job runs if <em>either</em> matches. So{" "}
              <code>0 0 13 * 5</code> fires on the 13th of every month <em>and</em> on every Friday —
              roughly five times a month, not once or twice a year. This is in POSIX and in Vixie
              cron&apos;s manual page and it still surprises people, which is why the explanation
              here spells it out rather than describing the fields separately.
            </p>
            <p>
              When one of the two is <code>*</code>, the other decides alone, which is why{" "}
              <code>0 0 * * 5</code> is straightforwardly every Friday.
            </p>
            <h3>Next-run calculation is a search that must terminate</h3>
            <p>
              <code>0 0 31 2 *</code> asks for midnight on 31 February, which never happens. A
              minute-by-minute scan takes 2.6 million iterations to reach a one-year limit and give
              up; a scan with no limit never gives up at all. The search here skips by the largest
              unit it can rule out — a month that does not match advances to the first of the next
              month, not through its days — so an impossible schedule is proven impossible in a few
              hundred steps.
            </p>
            <h3>Everything here is UTC, deliberately</h3>
            <p>
              A cron job scheduled in a zone with daylight saving genuinely runs twice on one night a
              year and not at all on another: when the clock goes back, 01:30 happens twice; when it
              goes forward, 02:30 does not happen. Different cron implementations handle that
              differently, and some do not handle it at all. Computing in UTC and saying so is
              honest; silently applying your browser&apos;s zone would produce times that look
              authoritative and are wrong twice a year.
            </p>
            <h3>Field counts and dialects</h3>
            <p>
              Five fields is standard Unix cron. Six usually means seconds first, which is what
              Quartz, Spring and node-cron do — although a few schedulers put a year last instead,
              which is genuinely ambiguous and resolved here in favour of seconds. Seven fields is
              Quartz with both. The parser accepts month and day names, wrapping ranges like{" "}
              <code>FRI-MON</code> and <code>22-2</code>, <code>?</code> as a wildcard, both{" "}
              <code>0</code> and <code>7</code> for Sunday, and the <code>@daily</code> family of
              shorthands.
            </p>
            <p>
              <code>@reboot</code> is recognised and explained rather than parsed: it has no
              schedule, so there is no next run to compute.
            </p>
          </>
        ),
        inputTitle: "Expression",
        exampleInput: `0 0 13 * 5`,
        outputTitle: "Explained",
        exampleOutput: `At 00:00, on day 13 of the month OR on Friday
— cron ORs these two fields rather than
intersecting them, so this is not
"Friday the 13th". UTC.`,
      }}
      referenceTable={{
        title: "Syntax",
        rows: [
          {
            parameter: "*",
            type: "wildcard",
            defaultVal: "every value",
            description:
              "In a day field it also means 'let the other day field decide', which is what makes the OR rule tractable.",
          },
          {
            parameter: "*/n",
            type: "step",
            defaultVal: "—",
            description:
              "Every nth value from the field's minimum. */15 in minutes is 0, 15, 30, 45 — not 'every 15 minutes from now'.",
          },
          {
            parameter: "a-b",
            type: "range",
            defaultVal: "—",
            description:
              "Inclusive. A wrapping range is accepted: 22-2 in hours is 22, 23, 0, 1, 2, and FRI-MON is the weekend.",
          },
          {
            parameter: "a,b,c",
            type: "list",
            defaultVal: "—",
            description: "Any mix of single values, ranges and steps, comma-separated.",
          },
          {
            parameter: "n/m",
            type: "step from n",
            defaultVal: "—",
            description: "5/6 in hours is 5, 11, 17, 23 — from 5 to the maximum, in steps of 6.",
          },
          {
            parameter: "Names",
            type: "JAN-DEC, SUN-SAT",
            defaultVal: "accepted",
            description: "Case-insensitive, and usable in ranges: JAN-MAR, MON-FRI.",
          },
          {
            parameter: "0 and 7",
            type: "Sunday",
            defaultVal: "both",
            description:
              "Every implementation accepts both, and almost no documentation mentions it in the same place as anything else.",
          },
          {
            parameter: "?",
            type: "wildcard",
            defaultVal: "Quartz",
            description: "Treated as *. Quartz uses it to mean 'no specific value' in a day field.",
          },
          {
            parameter: "Field count",
            type: "5, 6 or 7",
            defaultVal: "5",
            description:
              "Five is standard Unix. Six is read as seconds-first, which is what Quartz, Spring and node-cron mean. Seven is Quartz with a year.",
          },
          {
            parameter: "@daily and friends",
            type: "shorthand",
            defaultVal: "expanded",
            description:
              "@yearly @annually @monthly @weekly @daily @midnight @hourly. @reboot has no schedule and is explained rather than parsed.",
          },
          {
            parameter: "Time zone",
            type: "UTC",
            defaultVal: "always",
            description:
              "A local-time schedule genuinely runs twice on one night a year and not at all on another. Computing in UTC and saying so beats producing confidently wrong local times.",
          },
        ],
      }}
      faqs={[
        {
          question: "Does 0 0 13 * 5 run on Friday the 13th?",
          answer:
            "No — it runs on the 13th of every month and on every Friday. Cron ORs the two day fields rather than intersecting them, which is the opposite of what every other pair of fields does and the single most common cron misunderstanding. For Friday the 13th specifically, you need a day-of-month restriction plus a check inside the job itself; cron cannot express the intersection.",
        },
        {
          question: "What does */15 actually mean?",
          answer:
            "Every value divisible by 15 within the field, starting from the field's minimum — so in minutes it is 0, 15, 30 and 45. It is not 'every fifteen minutes from when I deployed'. That distinction matters when you combine it with an hour restriction: 0 */2 * * * runs at 00:00, 02:00, 04:00 and so on, not two hours after each previous run.",
        },
        {
          question: "Why are all the times UTC?",
          answer:
            "Because a local-time schedule is genuinely ambiguous twice a year. When the clock goes back, 01:30 occurs twice and some implementations run the job twice; when it goes forward, 02:30 does not occur and some implementations skip it entirely. Behaviour differs between cron implementations. Showing UTC and saying so is honest; quietly applying your browser's zone would produce authoritative-looking times that are wrong for two days a year.",
        },
        {
          question: "Five, six or seven fields?",
          answer:
            "Five for Unix cron, crontab and most CI schedulers. Six for Quartz, Spring's @Scheduled and node-cron, where the extra field goes first and is seconds. Seven for Quartz with a year at the end. Six fields is genuinely ambiguous — a few schedulers put the year last instead — and this parser reads it as seconds-first, which is far more common.",
        },
        {
          question: "Why does my expression show no runs?",
          answer:
            "It can never fire. The usual cause is a day-of-month and month combination that does not exist — 0 0 31 2 * asks for 31 February — or a year restriction already in the past. The search looks five years ahead before concluding this, so an empty list means genuinely impossible rather than merely distant.",
        },
        {
          question: "Is my expression uploaded?",
          answer:
            "No. Parsing and the next-run search both run in your browser. A cron expression is not a secret, but it does describe your infrastructure's rhythm, and there is no reason for that to reach a server that has no use for it.",
        },
      ]}
      relatedTools={relatedTools("/cron-expression").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className="flex flex-1 items-center gap-2">
            <label htmlFor="cron-input" className={fieldLabel}>
              Expression
            </label>
            <input
              id="cron-input"
              type="text"
              value={expression}
              onChange={(e) => setExpression(e.target.value)}
              spellCheck={false}
              className={`${field} min-w-[12rem] flex-1`}
            />
          </div>
          {parsed.ok && runs.length > 1 && (
            <span className="font-mono text-2xs text-foreground-subtle">
              {frequencySummary(runs)}
            </span>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {CRON_EXAMPLES.map((example) => (
            <button
              key={example.expression}
              type="button"
              onClick={() => setExpression(example.expression)}
              title={example.expression}
              className={btnCompact}
            >
              {example.label}
            </button>
          ))}
        </div>

        {!parsed.ok ? (
          <Notice tone="danger">{parsed.error}</Notice>
        ) : (
          <>
            <div className="rounded-lg border border-accent-line bg-accent-soft p-3">
              <p className="text-sm text-foreground">{parsed.value.description}</p>
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <div className="overflow-x-auto rounded-lg border border-border bg-surface">
                <table className="w-full border-collapse text-left font-mono text-xs">
                  <caption className="sr-only">Fields</caption>
                  <thead>
                    <tr className="border-b border-border">
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        Field
                      </th>
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        Written
                      </th>
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        Matches
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsed.value.fields.map((fieldEntry) => (
                      <tr key={fieldEntry.name} className="border-b border-border last:border-0">
                        <th
                          scope="row"
                          className="whitespace-nowrap px-3 py-1.5 text-left font-medium text-foreground"
                        >
                          {fieldEntry.name}
                        </th>
                        <td className="whitespace-nowrap px-3 py-1.5 text-move">
                          {fieldEntry.raw}
                        </td>
                        <td className="px-3 py-1.5 text-foreground-subtle">
                          {fieldEntry.wildcard
                            ? "every value"
                            : fieldEntry.values.length > 12
                              ? `${fieldEntry.values.length} values`
                              : fieldEntry.values.join(", ")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="overflow-x-auto rounded-lg border border-border bg-surface">
                <table className="w-full border-collapse text-left font-mono text-xs">
                  <caption className="sr-only">Next runs</caption>
                  <thead>
                    <tr className="border-b border-border">
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        #
                      </th>
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        Next run (UTC)
                      </th>
                      <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                        Day
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {runs.length === 0 && now !== 0 ? (
                      <tr>
                        <td colSpan={3} className="px-3 py-3 text-foreground-muted">
                          This expression never fires in the next five years.
                        </td>
                      </tr>
                    ) : (
                      runs.map((run, index) => (
                        <tr key={run.toISOString()} className="border-b border-border last:border-0">
                          <td className="px-3 py-1.5 text-foreground-subtle">{index + 1}</td>
                          <td className="whitespace-nowrap px-3 py-1.5 text-foreground">
                            {run.toISOString().replace("T", " ").replace(".000Z", "")}
                          </td>
                          <td className="whitespace-nowrap px-3 py-1.5 text-foreground-subtle">
                            {run.toUTCString().slice(0, 3)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {!parsed.value.fields[2].wildcard && !parsed.value.fields[4].wildcard && (
              <Notice tone="warn">
                Both day fields are restricted, so cron <strong>ORs</strong> them: this runs on the
                listed days of the month <em>or</em> on the listed weekdays, not on days that satisfy
                both. Cron cannot express the intersection — for &ldquo;Friday the 13th&rdquo; you
                need a day-of-month schedule plus a check inside the job.
              </Notice>
            )}
          </>
        )}
      </div>
    </ToolShell>
  );
};
