import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CronExpressionClient } from "./CronExpressionClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/cron-expression",
  title: "Cron Expression Parser — Next Runs Explained",
  socialTitle: "Cron Expression",
  description:
    "Explain a cron expression in English and list its next runs, in your browser. States the rule everyone gets wrong: the two day fields are ORed, not ANDed.",
});

export default function CronExpressionPage() {
  return <CronExpressionClient />;
}
