"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { CropCanvas, centredRect, type CropRect } from "../../components/tools/CropCanvas";
import { Notice } from "../../components/common/Notice";
import {
  btnPrimary,
  btnSecondary,
  field,
  fieldLabel,
  segment,
  segmentTrack,
} from "../../components/common/controls";
import { downloadBlob, formatBytes, type AcceptedFile } from "../../lib/files";
import {
  cropAndEncode,
  decodeImage,
  formatOfFile,
  FORMAT_EXTENSION,
  type ImageFormat,
} from "../../lib/images";
import { stemOf, withStem } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

const RATIOS: { label: string; value: number | null; note: string }[] = [
  { label: "Free", value: null, note: "Any rectangle." },
  { label: "1:1", value: 1, note: "Avatars, product shots, most social posts." },
  { label: "4:3", value: 4 / 3, note: "The classic camera and screen ratio." },
  { label: "3:2", value: 3 / 2, note: "35mm film, and most DSLR sensors." },
  { label: "16:9", value: 16 / 9, note: "Video, and wide banners." },
  { label: "1.91:1", value: 1.91, note: "Open Graph link previews." },
];

interface Loaded {
  bitmap: ImageBitmap;
  url: string;
  width: number;
  height: number;
  file: File;
}

export const CropImageClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [rect, setRect] = useState<CropRect>({ x: 0, y: 0, width: 0, height: 0 });
  const [aspect, setAspect] = useState<number | null>(null);
  const [output, setOutput] = useState<"keep" | ImageFormat>("keep");
  const [quality, setQuality] = useState(0.9);
  const [outputName, setOutputName] = useState("");
  const [result, setResult] = useState<{ blob: Blob; url: string; name: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Everything held here is outside the JavaScript heap — a bitmap and two
  // object URLs — so the cleanup is explicit rather than left to the collector.
  const loadedRef = useRef<Loaded | null>(null);
  const resultUrlRef = useRef<string | null>(null);

  const release = useCallback(() => {
    if (loadedRef.current) {
      loadedRef.current.bitmap.close();
      URL.revokeObjectURL(loadedRef.current.url);
      loadedRef.current = null;
    }
    if (resultUrlRef.current) {
      URL.revokeObjectURL(resultUrlRef.current);
      resultUrlRef.current = null;
    }
  }, []);

  useEffect(() => release, [release]);

  const load = useCallback(
    async (next: AcceptedFile[]) => {
      release();
      setLoaded(null);
      setResult(null);
      setError(null);
      setFiles(next);

      const file = next[0]?.file;
      if (!file) return;

      try {
        const decoded = await decodeImage(file);
        const entry: Loaded = {
          bitmap: decoded.bitmap,
          url: URL.createObjectURL(file),
          width: decoded.width,
          height: decoded.height,
          file,
        };
        loadedRef.current = entry;
        setLoaded(entry);
        setRect(centredRect(decoded.width, decoded.height, aspect));
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : String(caught));
      }
    },
    [aspect, release]
  );

  const chooseAspect = (value: number | null) => {
    setAspect(value);
    if (loaded) setRect(centredRect(loaded.width, loaded.height, value));
  };

  const crop = async () => {
    if (!loaded) return;
    setBusy(true);
    setError(null);
    try {
      const format: ImageFormat = output === "keep" ? formatOfFile(loaded.file) : output;
      const blob = await cropAndEncode(loaded.bitmap, rect, {
        format,
        quality,
        background: "#ffffff",
      });
      if (resultUrlRef.current) URL.revokeObjectURL(resultUrlRef.current);
      const url = URL.createObjectURL(blob);
      resultUrlRef.current = url;
      setResult({
        blob,
        url,
        name: withStem(
          outputName.trim() ||
            `${stemOf(loaded.file.name)}-${Math.round(rect.width)}x${Math.round(rect.height)}`,
          FORMAT_EXTENSION[format]
        ),
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : String(caught));
    } finally {
      setBusy(false);
    }
  };

  const setNumber = (key: keyof CropRect) => (value: string) => {
    if (!loaded) return;
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return;
    setRect((current) => {
      const next = { ...current, [key]: Math.max(0, Math.round(parsed)) };
      next.width = Math.min(next.width, loaded.width - next.x);
      next.height = Math.min(next.height, loaded.height - next.y);
      return next;
    });
  };

  return (
    <ToolShell
      slug="crop-image"
      keyword="Crop Image"
      directAnswer="Crop Image trims an image to a rectangle you drag or type, in your browser. The crop is stored in the photo's own pixel coordinates rather than in the size of the preview on screen, so the result is exact at any window size, and cropping is lossless in the sense that it discards pixels rather than re-sampling the ones it keeps."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "Crop Image", url: "/crop-image" },
      ]}
      seoDescription="Crop images in the browser by dragging or by exact pixel values, with aspect-ratio presets for avatars, thumbnails and Open Graph previews. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Cropping is the one image operation that costs nothing in quality. Every other edit
              re-samples or re-quantises pixels; a crop simply keeps a rectangle of them and throws
              the rest away. The pixels that survive are the pixels you started with, drawn at a
              one-to-one scale into a smaller canvas.
            </p>

            <h3>Why the rectangle is measured in source pixels</h3>
            <p>
              The preview on this page is whatever width the layout gives it — smaller on a phone,
              larger on a desktop, different again after a window resize. If the crop rectangle were
              stored in those screen pixels, the same drag would produce a different result
              depending on the browser window, and rounding would land on a different boundary each
              time.
            </p>
            <p>
              So the rectangle is kept in the image&apos;s own coordinates and the preview is
              projected from it. Drag the same corner on a phone and on a monitor and you get the
              same crop, and the numeric boxes show the real pixel values rather than a scaled
              approximation.
            </p>

            <h3>Aspect ratios, and why they are worth locking</h3>
            <p>
              Most places an image ends up expect a particular shape, and they will crop it
              themselves if you do not: a square for an avatar, 1.91:1 for a link preview, 16:9 for
              video. Choosing the crop yourself is the difference between a portrait with the
              subject in the frame and one that a platform&apos;s centre-crop has beheaded. With a
              ratio locked, dragging any corner keeps the shape and only the size changes.
            </p>

            <h3>The rule-of-thirds guides</h3>
            <p>
              The lines across the crop box divide it into nine. Placing a subject on one of the
              intersections, rather than dead centre, is the oldest compositional advice there is —
              it works because a centred subject flattens the image and an off-centre one leaves the
              eye somewhere to travel. The guides cost nothing to draw and they are there because a
              crop is a compositional decision, not just a size one.
            </p>

            <h3>Where quality does get involved</h3>
            <p>
              The crop itself is lossless, but writing the result out is not — if the output is JPEG
              or WebP, the kept pixels are re-encoded, and that is a generation of lossy compression
              on top of whatever the source already had. The quality control here defaults high for
              that reason. Cropping a PNG to a PNG is lossless end to end.
            </p>

            <h3>What happens to a transparent image</h3>
            <p>
              Transparency survives a crop into PNG or WebP. Into JPEG it cannot — there is no alpha
              channel — so transparent areas are composited against white before encoding, which is
              what stops them coming out black.
            </p>

            <h3>Everything stays on your machine</h3>
            <p>
              The image is decoded with <code>createImageBitmap</code>, drawn into a canvas at the
              crop rectangle, and encoded with <code>canvas.toBlob</code>. All three are the
              browser&apos;s own code, running in this tab. The photo is never uploaded, and the
              page&apos;s Content-Security-Policy sets <code>connect-src &apos;self&apos;</code>, so
              the browser would refuse to send it anywhere even if something tried.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `portrait.jpg
3024 x 4032
ratio locked 1:1`,
        outputTitle: "Output",
        exampleOutput: `portrait-3024x3024.jpg
3024 x 3024
pixels kept, not resampled`,
      }}
      referenceTable={{
        title: "Options",
        rows: RATIOS.map((ratio) => ({
          parameter: ratio.label,
          type: "aspect ratio",
          defaultVal: ratio.value === null ? "default" : "—",
          description: ratio.note,
        })).concat([
          {
            parameter: "X / Y / W / H",
            type: "pixels",
            defaultVal: "—",
            description:
              "The crop rectangle in the image's own coordinates. Typed values and dragged ones are the same numbers.",
          },
          {
            parameter: "Quality",
            type: "0.1 – 1.0",
            defaultVal: "0.9",
            description:
              "Applies when the output is JPG or WebP. High by default, because the crop itself loses nothing and the encode should not either.",
          },
          {
            parameter: "Same as source",
            type: "format",
            defaultVal: "default",
            description: "PNG in, PNG out — which keeps the whole operation lossless.",
          },
        ]),
      }}
      faqs={[
        {
          question: "Does cropping reduce image quality?",
          answer:
            "The crop itself does not — it keeps a rectangle of the original pixels untouched and discards the rest, with no re-sampling at all. What can cost quality is writing the result out: if the output format is JPEG or WebP, the kept pixels are re-encoded, which is one more generation of lossy compression. Crop a PNG to a PNG and the whole operation is lossless. The quality slider here defaults to 0.9 precisely so the encode does not undo what the crop preserved.",
        },
        {
          question: "How do I crop to an exact size in pixels?",
          answer:
            "Type into the X, Y, Width and Height boxes — they are the crop rectangle in the image's own coordinates, and they are the same numbers the drag handles produce. Setting Width and Height gives you an exact output size; X and Y position the rectangle. If you need a specific shape rather than a specific size, lock an aspect ratio and drag instead.",
        },
        {
          question: "What aspect ratio should I use?",
          answer:
            "1:1 for avatars and most social posts; 1.91:1 for Open Graph link previews, which is what appears when someone shares a URL; 16:9 for video thumbnails and wide banners; 4:3 or 3:2 for photographs, which is what cameras natively produce. Choosing the crop yourself matters because the destination will crop it for you otherwise, usually from the centre and usually badly.",
        },
        {
          question: "Can I crop several images at once?",
          answer:
            "Not here, and that is deliberate. A crop rectangle is specific to what is in the frame — the same coordinates applied to twenty photos would cut the subject out of most of them. Batch operations that genuinely apply uniformly, like resizing or converting, do take multiple files; cropping is a per-image decision, so this tool takes one image and gives you the controls to make that decision properly.",
        },
        {
          question: "Why does the crop box snap back when I drag past the edge?",
          answer:
            "Because the rectangle is clamped to the image: a crop cannot include area that does not exist. With an aspect ratio locked, hitting one edge also constrains the other dimension, since the shape has to be preserved — so the box stops growing rather than becoming the wrong shape. Switch to Free if you want the rectangle to follow the pointer without that constraint.",
        },
        {
          question: "Is the image uploaded to crop it?",
          answer:
            "No. It is decoded, drawn into a canvas and encoded entirely in this tab using the browser's own image code. You can confirm it in the Network panel of DevTools: cropping produces no requests at all. The page is also served with connect-src 'self', which means the browser itself blocks any attempt to send data to another origin.",
        },
      ]}
      relatedTools={relatedTools("/crop-image").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={["image/*", ".jpg", ".jpeg", ".png", ".webp", ".avif", ".heic", ".heif"]}
          files={files}
          onChange={(next) => void load(next)}
          label="Drop an image here"
          disabled={busy}
        />

        {error && <Notice tone="danger">{error}</Notice>}

        {loaded && (
          <>
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2">
              <span className={fieldLabel}>Ratio</span>
              <div className={segmentTrack} role="group" aria-label="Aspect ratio">
                {RATIOS.map((ratio) => (
                  <button
                    key={ratio.label}
                    type="button"
                    onClick={() => chooseAspect(ratio.value)}
                    aria-pressed={aspect === ratio.value}
                    title={ratio.note}
                    className={segment(aspect === ratio.value)}
                  >
                    {ratio.label}
                  </button>
                ))}
              </div>
              <span className="ml-auto font-mono text-2xs text-foreground-subtle">
                source {loaded.width} × {loaded.height}
              </span>
            </div>

            <CropCanvas
              src={loaded.url}
              naturalWidth={loaded.width}
              naturalHeight={loaded.height}
              rect={rect}
              onChange={setRect}
              aspect={aspect}
            />

            <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
              {(
                [
                  ["x", "X"],
                  ["y", "Y"],
                  ["width", "W"],
                  ["height", "H"],
                ] as const
              ).map(([key, label]) => (
                <div key={key} className="flex items-center gap-2">
                  <label htmlFor={`crop-${key}`} className={fieldLabel}>
                    {label}
                  </label>
                  <input
                    id={`crop-${key}`}
                    type="number"
                    min={0}
                    value={Math.round(rect[key])}
                    onChange={(event) => setNumber(key)(event.target.value)}
                    className={`${field} w-20`}
                  />
                </div>
              ))}

              <div className="flex items-center gap-2">
                <span className={fieldLabel}>Format</span>
                <div className={segmentTrack} role="group" aria-label="Output format">
                  {(["keep", "jpeg", "png", "webp"] as const).map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setOutput(value)}
                      aria-pressed={output === value}
                      className={segment(output === value)}
                    >
                      {value === "keep" ? "Same" : value === "jpeg" ? "JPG" : value.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {output !== "png" && (
                <div className="flex items-center gap-2">
                  <label htmlFor="crop-quality" className={fieldLabel}>
                    Quality
                  </label>
                  <input
                    id="crop-quality"
                    type="range"
                    min={10}
                    max={100}
                    value={Math.round(quality * 100)}
                    onChange={(event) => setQuality(Number(event.target.value) / 100)}
                    className="w-24 accent-accent-solid"
                  />
                  <span className="w-8 font-mono text-2xs text-foreground-subtle">
                    {Math.round(quality * 100)}
                  </span>
                </div>
              )}

              <button type="button" onClick={() => void crop()} disabled={busy} className={btnPrimary}>
                {busy ? "Cropping…" : "Crop"}
              </button>
              <button
                type="button"
                onClick={() => chooseAspect(aspect)}
                className={btnSecondary}
              >
                Reset region
              </button>
            </div>
          </>
        )}

        {loaded && (
          <OutputName
            defaultStem={`${stemOf(loaded.file.name)}-${Math.round(rect.width)}x${Math.round(
              rect.height
            )}`}
            extension={output === "keep" ? "jpg" : FORMAT_EXTENSION[output]}
            value={outputName}
            onChange={setOutputName}
          />
        )}

        {result && (
          <div className="flex flex-wrap items-center gap-3 rounded-lg border border-add/40 bg-surface p-3">
            {/* A blob URL this page just encoded. */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={result.url}
              alt="Cropped result"
              className="h-24 w-24 rounded border border-border bg-checkerboard object-contain"
            />
            <div className="min-w-0 flex-1">
              <p className="truncate font-mono text-xs text-foreground">{result.name}</p>
              <p className="font-mono text-2xs text-foreground-subtle">
                {Math.round(rect.width)} × {Math.round(rect.height)} ·{" "}
                {formatBytes(result.blob.size)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => downloadBlob(result.blob, result.name)}
              className={btnPrimary}
            >
              Download
            </button>
          </div>
        )}
      </div>
    </ToolShell>
  );
};
