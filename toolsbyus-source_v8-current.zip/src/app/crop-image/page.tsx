import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CropImageClient } from "./CropImageClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/crop-image",
  title: "Crop Image — Drag or Type an Exact Region",
  socialTitle: "Crop Image",
  description:
    "Crop an image by dragging or by exact pixel values, in your browser. Ratio presets for avatars, thumbnails and link previews, with thirds guides.",
});

export default function CropImagePage() {
  return <CropImageClient />;
}
