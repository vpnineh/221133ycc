"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatCss, minifyCss, analyseCss, CSS_DEFAULTS } from "../../lib/format/css";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `/*! ToolsByUs theme — a licence comment survives minification */
:root{--accent:#15803d;--radius:6px}
:is(.card,.panel) > .title,h2.title{font-size:1.125rem;font-weight:600;color:var(--accent)}
.card{background:url(https://example.com/bg.png) no-repeat;border-radius:var(--radius);padding:1rem 1.25rem}
.card::after{content:"}";display:block}
@media (min-width:40em){.card{padding:1.5rem 2rem}@supports (backdrop-filter:blur(2px)){.card{border:0}}}
`;

export const CssFormatterClient: React.FC = () => {
  const [mode, setMode] = useState<"format" | "minify">("format");
  const [indent, setIndent] = useState(2);
  const [selectorPerLine, setSelectorPerLine] = useState(true);
  const [blankLineBetweenRules, setBlankLineBetweenRules] = useState(true);
  const [keepComments, setKeepComments] = useState(true);

  const transform = (input: string): TransformOutcome => {
    if (!input.trim()) return { output: "" };
    const stats = analyseCss(input);

    if (mode === "minify") {
      const result = minifyCss(input, true);
      return {
        output: result.output,
        stats: [
          { label: "Original", value: `${result.originalBytes.toLocaleString("en-GB")} B` },
          { label: "Minified", value: `${result.minifiedBytes.toLocaleString("en-GB")} B` },
          { label: "Saved", value: `${result.savedPercent}%` },
        ],
      };
    }

    return {
      output: formatCss(input, {
        ...CSS_DEFAULTS,
        indent,
        selectorPerLine,
        blankLineBetweenRules,
        keepComments,
      }),
      stats: [
        { label: "Rules", value: String(stats.rules) },
        { label: "Declarations", value: String(stats.declarations) },
        { label: "Custom props", value: String(stats.customProperties) },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="css-formatter"
      keyword="CSS Formatter and Minifier"
      directAnswer="CSS Formatter re-indents and minifies a stylesheet in your browser. It tokenises rather than parses, which is what lets unknown at-rules and syntax newer than the tool pass through unchanged — a parser rejects what it does not recognise, and for a formatter, preserving something it does not understand is always better than deleting it."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "CSS Formatter", url: "/css-formatter" },
      ]}
      seoDescription="Format and minify CSS in the browser. Handles nested at-rules, custom properties, :is() selector lists and url() values correctly, and keeps licence comments when minifying."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Formatting CSS is mostly about knowing where a thing begins and ends, and there are
              four places where the naive answer is wrong.
            </p>
            <h3>A brace is not always a block</h3>
            <p>
              <code>content: &quot;&#125;&quot;</code> contains a closing brace inside a string, and{" "}
              <code>{"/* } */"}</code> contains one inside a comment. Splitting on braces without
              tracking those states produces a formatter that mangles any stylesheet with a
              pseudo-element counter or a commented-out rule in it. The sample above contains both,
              deliberately.
            </p>
            <h3>A colon is not always a property separator</h3>
            <p>
              <code>background: url(https://example.com/x.png)</code> has a colon inside the value,
              and a custom property&apos;s value can contain anything at all — that is what makes
              custom properties useful. The split is at the first colon that is not inside
              parentheses.
            </p>
            <h3>A comma is not always a selector separator</h3>
            <p>
              <code>:is(a, b) span</code> is one selector containing a comma, and{" "}
              <code>:nth-child(2n of .x, .y)</code> is another. Splitting a selector list on a bare
              comma breaks both. The split is at the top level only, which also keeps{" "}
              <code>rgb(0, 0, 0)</code> intact in a value.
            </p>
            <h3>A tokeniser outlives a parser</h3>
            <p>
              CSS gains syntax constantly: nesting, <code>@container</code>, <code>@layer</code>,{" "}
              <code>:has()</code>, relative colour syntax. A parser has to model each one and rejects
              anything it does not know, which means it breaks on CSS that browsers already accept. A
              tokeniser only needs to know where strings, comments, blocks and semicolons are, and
              that has been stable since CSS 1. Unknown syntax is passed through rather than dropped,
              which is the only behaviour a formatter can responsibly have.
            </p>
            <h3>Minification keeps a licence comment</h3>
            <p>
              <code>{"/*! … */"}</code> is the convention for a comment a minifier must preserve, and it
              usually carries a licence — stripping it may actually breach the terms the stylesheet
              was distributed under. Everything else goes. The last semicolon before a closing brace
              also goes, since it is separating a declaration from nothing.
            </p>
            <p>
              What minification here does <em>not</em> do is rewrite values: no shortening{" "}
              <code>#ffffff</code> to <code>#fff</code>, no merging rules, no reordering. Those are
              real wins and they are also where a minifier becomes a compiler with a bug surface. For
              a build pipeline, use a real minifier; this is for making a stylesheet small enough to
              paste.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `a,b{color:red;margin:0}`,
        outputTitle: "Formatted",
        exampleOutput: `a,
b {
  color: red;
  margin: 0;
}`,
      }}
      referenceTable={{
        title: "Options and handling",
        rows: [
          {
            parameter: "Indent",
            type: "spaces",
            defaultVal: "2",
            description: "Applied per nesting level, so a rule inside a media query indents twice.",
          },
          {
            parameter: "Selector per line",
            type: "boolean",
            defaultVal: "on",
            description:
              "Each selector in a comma-separated list on its own line. Splits at the top level only, so :is(a, b) stays intact.",
          },
          {
            parameter: "Blank line between rules",
            type: "boolean",
            defaultVal: "on",
            description: "A blank line after each top-level rule, which makes a long stylesheet scannable.",
          },
          {
            parameter: "Keep comments",
            type: "boolean",
            defaultVal: "on",
            description:
              "Multi-line comments keep their internal shape rather than being re-flowed, because ASCII-art section banners are common and re-flowing destroys them.",
          },
          {
            parameter: "Strings",
            type: "preserved",
            defaultVal: "—",
            description:
              'content: "}" contains a closing brace. Tracking string state is what stops that ending the block.',
          },
          {
            parameter: "url()",
            type: "consumed whole",
            defaultVal: "—",
            description:
              "An unquoted url() can contain characters that would otherwise be structural, including colons and parentheses in a data URI.",
          },
          {
            parameter: "At-rules",
            type: "nested",
            defaultVal: "—",
            description:
              "@media, @supports, @layer, @container and anything newer. Unknown at-rules are passed through rather than dropped.",
          },
          {
            parameter: "Minify",
            type: "whitespace only",
            defaultVal: "—",
            description:
              "Collapses whitespace and removes the last semicolon in a block. Does not rewrite values or merge rules — those are a build step's job, not a paste-box's.",
          },
          {
            parameter: "Licence comments",
            type: "/*! … */",
            defaultVal: "kept",
            description:
              "Preserved when minifying, by the convention every minifier follows. Stripping one may breach the licence it carries.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will it break my nested CSS or @container queries?",
          answer:
            "No, and that is the point of tokenising rather than parsing. The formatter only needs to know where strings, comments and blocks begin and end — it does not need to understand what an at-rule means. Syntax newer than the tool passes through unchanged, which is the opposite of what a parser does when it meets something it does not recognise.",
        },
        {
          question: "Why does the minified output still have a comment in it?",
          answer:
            "Because it starts with /*! rather than /*. That is the convention every minifier honours for a comment that must survive, and it almost always carries a licence — stripping it can breach the terms the stylesheet was distributed under. Ordinary block comments are removed.",
        },
        {
          question: "Why does minifying save less than a real build tool?",
          answer:
            "Because this only removes whitespace. A production minifier also shortens colours, merges duplicate rules, drops overridden declarations and rewrites shorthand — each of which is a genuine saving and also a transformation that can change behaviour if it gets an edge case wrong. For a build pipeline use a real minifier; this is for making a stylesheet small enough to paste somewhere.",
        },
        {
          question: "Why did my selector list not split at every comma?",
          answer:
            "Because some of those commas are inside a functional pseudo-class. :is(.card, .panel) is one selector that happens to contain a comma, and splitting there produces two selectors that are both invalid. The split is at the top level only — the same rule that keeps rgb(0, 0, 0) intact in a value.",
        },
        {
          question: "Does it validate my CSS?",
          answer:
            "No. It will format a stylesheet with a misspelled property or an invalid value without complaining, because a formatter that rejected unknown properties would reject every vendor prefix and every new feature. If you need validation, the browser's own DevTools flags unknown properties in the Styles panel, which is a more reliable signal than any static list.",
        },
        {
          question: "Is my stylesheet uploaded?",
          answer:
            "No. Tokenising and formatting run in your browser. That matters less for CSS than for a payload, but it matters some: a stylesheet from an unreleased product describes the product, and a stylesheet from an internal tool describes the internal tool.",
        },
      ]}
      relatedTools={relatedTools("/css-formatter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="CSS"
        outputLabel={mode === "minify" ? "Minified" : "Formatted"}
        inputPlaceholder="Paste a stylesheet…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName={mode === "minify" ? "styles.min.css" : "styles.css"}
        height={400}
        options={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className={segmentTrack} role="group" aria-label="Mode">
              {(["format", "minify"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  aria-pressed={mode === value}
                  className={segment(mode === value)}
                >
                  {value === "format" ? "Format" : "Minify"}
                </button>
              ))}
            </div>

            {mode === "format" && (
              <>
                <div className="flex items-center gap-2">
                  <span className={fieldLabel}>Indent</span>
                  <div className={segmentTrack} role="group" aria-label="Indent">
                    {[2, 4].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setIndent(value)}
                        aria-pressed={indent === value}
                        className={segment(indent === value)}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>

                {[
                  {
                    id: "css-selectors",
                    label: "Selector per line",
                    checked: selectorPerLine,
                    onChange: setSelectorPerLine,
                  },
                  {
                    id: "css-blank",
                    label: "Blank line between rules",
                    checked: blankLineBetweenRules,
                    onChange: setBlankLineBetweenRules,
                  },
                  {
                    id: "css-comments",
                    label: "Keep comments",
                    checked: keepComments,
                    onChange: setKeepComments,
                  },
                ].map((toggle) => (
                  <label
                    key={toggle.id}
                    htmlFor={toggle.id}
                    className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
                  >
                    <input
                      id={toggle.id}
                      type="checkbox"
                      checked={toggle.checked}
                      onChange={(e) => toggle.onChange(e.target.checked)}
                      className={checkbox}
                    />
                    <span className={fieldLabel}>{toggle.label}</span>
                  </label>
                ))}
              </>
            )}
          </div>
        }
      />
    </ToolShell>
  );
};
