import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CssFormatterClient } from "./CssFormatterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/css-formatter",
  title: "CSS Formatter — Format, Minify and Analyse",
  socialTitle: "CSS Formatter",
  description:
    "Format and minify CSS in your browser. Tokenised rather than parsed, so unknown at-rules and new syntax pass through unchanged instead of being dropped.",
});

export default function CssFormatterPage() {
  return <CssFormatterClient />;
}
