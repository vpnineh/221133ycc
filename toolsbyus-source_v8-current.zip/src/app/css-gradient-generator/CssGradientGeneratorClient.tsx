"use client";

import React, { useCallback, useMemo, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { useCopy } from "../../components/tools/ColorParts";
import { Icon } from "../../components/common/Icon";
import { relatedTools } from "../../lib/tools";
import { mix, parseColor, toHex, type Rgb } from "../../lib/color";

type GradientKind = "linear" | "radial" | "conic";

interface Stop {
  id: number;
  text: string;
  /** Percent along the gradient line. */
  position: number;
}

const BLACK: Rgb = { r: 0, g: 0, b: 0, a: 1 };

/** How many stops the sRGB fallback is written with. */
const FALLBACK_STOPS = 12;

const KINDS: Array<{ id: GradientKind; label: string; blurb: string }> = [
  {
    id: "linear",
    label: "Linear",
    blurb: "Colour changes along a straight line at the angle you set. The one you want nine times out of ten.",
  },
  {
    id: "radial",
    label: "Radial",
    blurb: "Colour changes outwards from a point. Good for a spotlight or a vignette, bad as a page background.",
  },
  {
    id: "conic",
    label: "Conic",
    blurb: "Colour changes around a point like a pie chart. Used for dials, loading rings and colour pickers.",
  },
];

/** The gradient's stop list, sorted and written as CSS. */
function stopList(stops: Stop[], colors: Rgb[]): string {
  return stops
    .map((stop, index) => ({ hex: toHex(colors[index]), position: stop.position }))
    .sort((a, b) => a.position - b.position)
    .map((stop) => `${stop.hex} ${stop.position}%`)
    .join(", ");
}

/** Samples the OKLab-interpolated ramp at one point, 0–100. */
function sampleAt(sorted: Array<{ color: Rgb; position: number }>, at: number): Rgb {
  if (at <= sorted[0].position) return sorted[0].color;
  const last = sorted[sorted.length - 1];
  if (at >= last.position) return last.color;

  for (let index = 0; index < sorted.length - 1; index++) {
    const from = sorted[index];
    const to = sorted[index + 1];
    if (at < from.position || at > to.position) continue;
    const span = to.position - from.position;
    // Two stops at the same position are a hard colour break, which is a real
    // technique — keep it rather than dividing by zero.
    if (span === 0) return to.color;
    return mix(from.color, to.color, (at - from.position) / span);
  }

  return last.color;
}

export const CssGradientGeneratorClient: React.FC = () => {
  const { copied, copy } = useCopy();
  const nextId = useRef(3);

  const [kind, setKind] = useState<GradientKind>("linear");
  const [angle, setAngle] = useState(135);
  const [oklab, setOklab] = useState(true);
  const [stops, setStops] = useState<Stop[]>([
    { id: 1, text: "#00696f", position: 0 },
    { id: 2, text: "#f5c518", position: 100 },
  ]);

  const colors = useMemo(() => stops.map((stop) => parseColor(stop.text) ?? BLACK), [stops]);

  const sorted = useMemo(
    () =>
      stops
        .map((stop, index) => ({ color: colors[index], position: stop.position }))
        .sort((a, b) => a.position - b.position),
    [stops, colors]
  );

  /** The gradient as CSS, with or without the interpolation hint. */
  const build = useCallback(
    (inOklab: boolean, list: string) => {
      const hint = inOklab ? " in oklab" : "";
      if (kind === "linear") return `linear-gradient(${angle}deg${hint}, ${list})`;
      if (kind === "radial") return `radial-gradient(circle at center${hint}, ${list})`;
      return `conic-gradient(from ${angle}deg at center${hint}, ${list})`;
    },
    [kind, angle]
  );

  const list = useMemo(() => stopList(stops, colors), [stops, colors]);

  const modern = build(oklab, list);
  const srgb = build(false, list);

  /**
   * The same ramp written as plain sRGB stops, sampled in OKLab.
   *
   * `in oklab` needs a 2023-or-later browser. Rather than telling you to accept
   * a different-looking gradient in anything older, this writes the OKLab curve
   * out as twelve ordinary stops: the browser then interpolates short sRGB
   * segments between points that are already on the right curve, which is
   * visually indistinguishable and works everywhere back to 2011.
   */
  const fallback = useMemo(() => {
    if (sorted.length < 2) return list;
    const sampled: string[] = [];
    for (let index = 0; index < FALLBACK_STOPS; index++) {
      const at = (index / (FALLBACK_STOPS - 1)) * 100;
      sampled.push(`${toHex(sampleAt(sorted, at))} ${at.toFixed(1)}%`);
    }
    return sampled.join(", ");
  }, [sorted, list]);

  const fallbackCss = build(false, fallback);

  const css = oklab
    ? `background: ${fallbackCss};\nbackground: ${modern};`
    : `background: ${srgb};`;

  const addStop = () => {
    const id = ++nextId.current;
    setStops((current) => {
      const positions = current.map((stop) => stop.position).sort((a, b) => a - b);
      // Drop it in the widest gap, which is where a person almost always wants
      // one — rather than at 50%, on top of whatever is already there.
      let bestAt = 50;
      let widest = -1;
      for (let index = 0; index < positions.length - 1; index++) {
        const gap = positions[index + 1] - positions[index];
        if (gap > widest) {
          widest = gap;
          bestAt = positions[index] + gap / 2;
        }
      }
      const sampledColor = current.length >= 2 ? toHex(sampleAt(sorted, bestAt)) : "#888888";
      return [...current, { id, text: sampledColor, position: Math.round(bestAt) }];
    });
  };

  const update = (id: number, patch: Partial<Stop>) =>
    setStops((current) => current.map((stop) => (stop.id === id ? { ...stop, ...patch } : stop)));

  const remove = (id: number) =>
    setStops((current) => (current.length <= 2 ? current : current.filter((stop) => stop.id !== id)));

  return (
    <ToolShell
      slug="css-gradient-generator"
      keyword="CSS Gradient Generator"
      directAnswer="CSS Gradient Generator builds a linear, radial or conic gradient and gives you the CSS. It interpolates in OKLab rather than sRGB, which is what stops a blue-to-yellow gradient turning grey in the middle, and it writes the result twice: once as a modern `in oklab` gradient and once as the same curve sampled into twelve plain stops, so older browsers get the same picture."
      breadcrumbs={[
        { name: "Color Tools", url: "/color-tools" },
        { name: "CSS Gradient Generator", url: "/css-gradient-generator" },
      ]}
      seoDescription="Build linear, radial and conic CSS gradients with OKLab interpolation and an automatic sRGB fallback. Live preview, unlimited stops, and everything computed in your browser."
      howItWorks={{
        inputTitle: "Stops and a direction",
        outputTitle: "The CSS, twice",
        exampleInput: `linear, 135°
#00696f  0%
#f5c518  100%`,
        exampleOutput: `background: linear-gradient(135deg, #00696f 0.0%,
  #2a7767 9.1%, #4b855c 18.2%, …);
background: linear-gradient(135deg in oklab,
  #00696f 0%, #f5c518 100%);`,
        algorithmExplanation: (
          <>
            <p>
              A gradient is a rule for producing every colour between two others, and the whole
              question is which space it does the producing in. The default is sRGB, and sRGB
              interpolation has one famous failure: the midpoint of two saturated colours from
              opposite sides of the wheel is not a colour between them, it is a desaturated sludge.
              Blue to yellow goes grey. Red to green goes brown. It is not a browser bug — it is
              what averaging three gamma-encoded channels does.
            </p>
            <h3>Why OKLab fixes it</h3>
            <p>
              OKLab is a perceptual space: its three axes are roughly lightness, green-to-red and
              blue-to-yellow, and distances in it match distances the eye reports. Averaging two
              colours there gives the colour a person would name as halfway between them, because
              that is what the space was constructed to do. CSS Color 4 lets you ask for it directly
              with <code>in oklab</code>, and every current browser supports it.
            </p>
            <h3>What the fallback is doing</h3>
            <p>
              <code>in oklab</code> arrived in browsers in 2023. Rather than leaving anything older
              with a visibly different gradient, this tool samples the OKLab curve at twelve points
              and writes them out as ordinary colour stops. The old browser then interpolates in
              sRGB — but only across short segments whose endpoints are already on the correct
              curve, and over a segment that short the two spaces do not visibly disagree. Both
              declarations are emitted, in that order, so a browser that understands the second uses
              it and one that does not keeps the first.
            </p>
            <h3>The other thing that goes wrong with gradients</h3>
            <p>
              Banding. A gradient across a wide area steps through a limited number of 8-bit values,
              and on a large flat surface you can see the steps as stripes. Nothing in the CSS can
              fix it, because the display is genuinely out of values; what fixes it is a small
              amount of noise over the top — a tiled PNG of a few hundred bytes at 3% opacity, or an
              SVG <code>feTurbulence</code> layer. If your hero gradient looks striped, that is what
              you are looking at, and no amount of extra colour stops will help.
            </p>
            <h3>And a word about using them at all</h3>
            <p>
              A gradient behind text is a contrast problem: the ratio changes across the element, so
              the corner that passes and the corner that fails are both real. If text has to sit on
              one, check the extremes rather than the middle, or put the text on a solid panel over
              the gradient.
            </p>
          </>
        ),
      }}
      referenceTable={{
        title: "What each control does",
        rows: [
          { parameter: "Linear", type: "angle", defaultVal: "135deg", description: "0deg points up, 90deg points right. The angle is the direction the colours travel, not the direction the line leans." },
          { parameter: "Radial", type: "circle at center", defaultVal: "—", description: "Colours run outwards from the middle. `circle` keeps it round in a non-square box; the default `ellipse` stretches with the element." },
          { parameter: "Conic", type: "from angle", defaultVal: "135deg", description: "Colours sweep around the centre. The basis of every CSS pie chart and dial, and of the hue ring in a colour picker." },
          { parameter: "in oklab", type: "keyword", defaultVal: "on", description: "Interpolate perceptually. Supported since 2023 — Chrome 111, Safari 16.2, Firefox 113. Turn it off to see what a plain gradient does with the same stops." },
          { parameter: "Fallback", type: "12 stops", defaultVal: "auto", description: "The OKLab curve sampled into plain stops, emitted as the first of two declarations so older browsers match." },
          { parameter: "Stop position", type: "0–100%", defaultVal: "even", description: "Where on the gradient line the colour lands. Two stops at the same position make a hard edge rather than a blend." },
          { parameter: "Stop colour", type: "any notation", defaultVal: "—", description: "Hex, rgb(), hsl(), oklch() or a CSS colour name. Alpha is kept, and a gradient to `transparent` should specify the colour with alpha 0 rather than the keyword." },
          { parameter: "Stops", type: "2 or more", defaultVal: "2", description: "New stops land in the widest gap, taking the colour the curve already has there, so adding one does not change the gradient." },
        ],
      }}
      faqs={[
        {
          question: "How do I make a CSS gradient?",
          answer:
            "Set `background: linear-gradient(135deg, #00696f, #f5c518)` — an angle followed by two or more colours. 0deg runs bottom to top and 90deg runs left to right. Add a percentage after a colour to pin it to a position on the line, use `radial-gradient` for colours radiating from a point and `conic-gradient` for colours sweeping around one. This page writes all three, with the interpolation fix and a fallback, from whatever stops you set.",
        },
        {
          question: "Why does my gradient go grey in the middle?",
          answer:
            "Because the browser is averaging gamma-encoded sRGB channels, and the average of two saturated colours from opposite sides of the colour wheel is a desaturated one. Blue to yellow is the classic case. Adding `in oklab` after the angle fixes it — the interpolation then happens in a perceptual space where the midpoint is the colour you would name as halfway. For older browsers, use the twelve-stop fallback this tool emits alongside it.",
        },
        {
          question: "Is `in oklab` safe to use in production?",
          answer:
            "Yes, with the fallback. It shipped in Chrome 111, Safari 16.2 and Firefox 113, which covers the overwhelming majority of traffic in 2026. Anything older ignores the whole declaration as invalid — which is why the plain-stop version is emitted first: CSS takes the last declaration it understands, so old browsers keep the fallback and new ones take the OKLab version. Neither ever sees a broken background.",
        },
        {
          question: "Why does my gradient have visible stripes?",
          answer:
            "That is banding, and it is a display limitation rather than a CSS one. Across a large area a gradient has to step through a limited set of 8-bit values, and the steps become visible as bands — worst on subtle dark gradients, which is where the values are furthest apart perceptually. More colour stops will not help because the values simply do not exist. A faint noise texture over the top does: a tiled PNG at about 3% opacity, or an SVG feTurbulence layer.",
        },
        {
          question: "Can I put text on a gradient?",
          answer:
            "You can, but the contrast ratio is different at every point, so 'it passes' is not a single fact about the element. Check the lightest point and the darkest point the text actually crosses, and treat the worse of the two as the real ratio. Where the range is wide, the practical answer is to put the text on a solid or semi-opaque panel over the gradient rather than directly on it.",
        },
        {
          question: "How do I fade a gradient to transparent?",
          answer:
            "Not with the `transparent` keyword. In several engines it resolves to transparent black, so fading a red to it travels through dark muddy pinks. Use the same colour with zero alpha instead — `#ff0000` to `#ff000000`, or `rgb(255 0 0 / 0)` — and the hue holds all the way down. Interpolating in OKLab reduces the effect but does not remove the reason for it.",
        },
      ]}
      relatedTools={relatedTools("/css-gradient-generator").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-8">
        {/* ---- Preview ------------------------------------------------- */}
        <div
          className="h-48 w-full rounded-xl sm:h-64"
          role="img"
          aria-label={`Preview of ${modern}`}
          style={{ background: modern }}
        />

        <div className="grid gap-8 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] lg:gap-12">
          {/* ---- Controls ---------------------------------------------- */}
          <div className="space-y-6">
            <section>
              <h2 className="text-sm font-medium text-foreground-muted">Type</h2>
              <div role="radiogroup" aria-label="Gradient type" className="mt-2 flex flex-wrap gap-2">
                {KINDS.map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    role="radio"
                    aria-checked={kind === option.id}
                    onClick={() => setKind(option.id)}
                    className={`cursor-pointer rounded-pill px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] ${
                      kind === option.id
                        ? "bg-accent-solid text-accent-on"
                        : "bg-surface-elevated text-foreground-muted hover:text-foreground"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-sm text-foreground-muted">
                {KINDS.find((option) => option.id === kind)?.blurb}
              </p>
            </section>

            {kind !== "radial" && (
              <label className="block">
                <span className="flex items-baseline justify-between text-sm text-foreground-muted">
                  {kind === "conic" ? "Start angle" : "Angle"}
                  <span className="font-mono text-foreground">{angle}°</span>
                </span>
                <input
                  type="range"
                  min={0}
                  max={360}
                  step={1}
                  value={angle}
                  onChange={(event) => setAngle(Number(event.target.value))}
                  className="mt-2 w-full accent-accent-solid"
                />
              </label>
            )}

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={oklab}
                onChange={(event) => setOklab(event.target.checked)}
                className="mt-0.5 h-5 w-5 flex-none cursor-pointer accent-accent-solid"
              />
              <span className="text-sm">
                <span className="font-medium text-foreground">Interpolate in OKLab</span>
                <span className="mt-0.5 block text-foreground-muted">
                  Stops the middle of the gradient going grey. A twelve-stop sRGB fallback is
                  emitted alongside it, so nothing older shows a different picture.
                </span>
              </span>
            </label>

            <section>
              <div className="mb-3 flex items-baseline justify-between">
                <h2 className="text-sm font-medium text-foreground-muted">
                  Stops ({stops.length})
                </h2>
                <button
                  type="button"
                  onClick={addStop}
                  className="inline-flex cursor-pointer items-center gap-1.5 rounded-pill bg-surface-elevated px-4 py-1.5 text-xs font-medium text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  <Icon name="plus" size="sm" />
                  Add a stop
                </button>
              </div>

              <ul className="space-y-3">
                {stops.map((stop, index) => {
                  const invalid = parseColor(stop.text) === null;
                  return (
                    <li key={stop.id} className="rounded-lg bg-surface-elevated p-3">
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          aria-label={`Stop ${index + 1} colour`}
                          value={toHex(colors[index], { alpha: "never" })}
                          onChange={(event) => update(stop.id, { text: event.target.value })}
                          className="h-10 w-10 flex-none cursor-pointer rounded border-0 bg-transparent p-0 [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded [&::-webkit-color-swatch]:border-0"
                        />
                        <input
                          type="text"
                          aria-label={`Stop ${index + 1} value`}
                          aria-invalid={invalid}
                          value={stop.text}
                          onChange={(event) => update(stop.id, { text: event.target.value })}
                          spellCheck={false}
                          autoComplete="off"
                          autoCapitalize="off"
                          className={`w-full min-w-0 rounded bg-transparent px-2 py-1.5 font-mono text-sm text-foreground outline-none ${
                            invalid ? "ring-2 ring-inset ring-danger" : ""
                          }`}
                        />
                        <button
                          type="button"
                          onClick={() => remove(stop.id)}
                          disabled={stops.length <= 2}
                          aria-label={`Remove stop ${index + 1}`}
                          className="flex-none cursor-pointer rounded p-2 text-foreground-subtle transition-colors hover:text-danger focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Icon name="trash" size="sm" />
                        </button>
                      </div>
                      <div className="mt-2 flex items-center gap-3">
                        <input
                          type="range"
                          min={0}
                          max={100}
                          step={1}
                          aria-label={`Stop ${index + 1} position`}
                          value={stop.position}
                          onChange={(event) =>
                            update(stop.id, { position: Number(event.target.value) })
                          }
                          className="w-full accent-accent-solid"
                        />
                        <span className="w-12 flex-none text-right font-mono text-xs text-foreground-subtle">
                          {stop.position}%
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          </div>

          {/* ---- Output ------------------------------------------------ */}
          <div className="min-w-0 space-y-8">
            <section>
              <div className="mb-3 flex flex-wrap items-baseline gap-x-3">
                <h2 className="text-lg font-semibold tracking-tight text-foreground">CSS</h2>
                <button
                  type="button"
                  onClick={() => copy(css)}
                  className="ml-auto inline-flex cursor-pointer items-center gap-1.5 rounded-pill bg-accent-solid px-5 py-2.5 text-sm font-medium text-accent-on transition-colors hover:bg-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px]"
                >
                  <Icon name={copied === css ? "check" : "copy"} size="sm" />
                  {copied === css ? "Copied" : "Copy CSS"}
                </button>
              </div>
              <pre className="overflow-x-auto rounded-lg bg-surface-elevated p-4 font-mono text-xs leading-relaxed text-foreground">
                <code>{css}</code>
              </pre>
              {oklab && (
                <p className="mt-2 text-xs text-foreground-subtle">
                  Two declarations, in that order. A browser that understands{" "}
                  <code>in oklab</code> takes the second; anything older keeps the first and gets
                  the same curve written out as plain stops.
                </p>
              )}
            </section>

            <section>
              <h2 className="mb-1 text-lg font-semibold tracking-tight text-foreground">
                The difference the space makes
              </h2>
              <p className="mb-4 max-w-[62ch] text-sm text-foreground-muted">
                The same stops, interpolated two ways. The gap is widest when the two colours sit on
                opposite sides of the wheel — try a blue and a yellow.
              </p>
              <div className="space-y-3">
                {[
                  { label: "sRGB — the default", value: srgb },
                  { label: "OKLab — in oklab", value: build(true, list) },
                  { label: "The 12-stop fallback", value: fallbackCss },
                ].map((sample) => (
                  <div key={sample.label}>
                    <p className="mb-1.5 text-xs text-foreground-subtle">{sample.label}</p>
                    <div className="h-16 w-full rounded-lg" style={{ background: sample.value }} />
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      </div>
    </ToolShell>
  );
};
