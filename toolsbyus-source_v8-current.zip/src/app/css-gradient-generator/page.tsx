import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CssGradientGeneratorClient } from "./CssGradientGeneratorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/css-gradient-generator",
  title: "CSS Gradient Generator — Linear, Radial and Conic",
  socialTitle: "CSS Gradient Generator",
  description:
    "Build a linear, radial or conic CSS gradient with OKLab interpolation, so the middle does not go grey, and copy it with a twelve-stop sRGB fallback.",
});

export default function CssGradientGeneratorPage() {
  return <CssGradientGeneratorClient />;
}
