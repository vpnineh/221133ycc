"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, field, fieldLabel } from "../../components/common/controls";
import { csvToJson, type CsvParseOptions, type Delimiter } from "../../lib/csv";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `id,customer.name,customer.email,total,currency,tags[0],tags[1],shipped
ord_1041,Ada Lovelace,ada@example.com,148.5,GBP,priority,gift,true
ord_1042,Grace Hopper,grace@example.com,92,USD,standard,,false
ord_1043,"Hopper, G.",g@example.com,17.25,USD,"needs ""care""",,true`;

export const CsvToJsonClient: React.FC = () => {
  const [options, setOptions] = useState<CsvParseOptions>({
    delimiter: "auto",
    hasHeader: true,
    inferTypes: true,
    expandPaths: true,
    skipEmptyRows: true,
    omitEmpty: true,
  });
  const [indent, setIndent] = useState(2);

  const transform = useCallback(
    (input: string): TransformOutcome => {
      const result = csvToJson(input, options);
      if (!result.success) {
        return {
          output: "",
          error: `Line ${result.error.line}, column ${result.error.column}: ${result.error.message}`,
        };
      }

      const json = JSON.stringify(result.data.records, null, indent);
      return {
        output: json,
        warnings: result.data.warnings,
        stats: [
          { label: "Records", value: String(result.data.records.length) },
          { label: "Columns", value: String(result.data.columns.length) },
          { label: "Bytes", value: String(new Blob([json]).size) },
          {
            label: "Delimiter",
            value: options.delimiter === "auto" ? "auto" : options.delimiter === "\t" ? "tab" : options.delimiter,
          },
        ],
      };
    },
    [options, indent]
  );

  return (
    <ToolShell
      wide
      slug="csv-to-json"
      keyword="CSV to JSON"
      directAnswer="CSV to JSON parses a spreadsheet export into an array of records in your browser. It reads RFC 4180 properly — quoted fields containing commas, newlines and escaped quotes all survive — infers scalar types, and rebuilds nested objects and arrays from dotted or bracketed column names."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "CSV to JSON", url: "/csv-to-json" },
      ]}
      seoDescription="Convert CSV to JSON in your browser. RFC 4180 parsing with quoted fields and embedded newlines, automatic delimiter detection, type inference, and nested objects rebuilt from column paths."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The naive implementation of this conversion is one line —{" "}
              <code>line.split(&quot;,&quot;)</code> — and it is wrong for a large fraction of real
              files. A CSV field may be quoted, and a quoted field may contain the delimiter, a
              literal newline, and doubled quotes standing for a single one. Splitting on commas
              turns <code>&quot;Hopper, G.&quot;</code> into two fields and shifts every column after
              it by one, which corrupts the record rather than failing on it.
            </p>
            <p>
              So the parser here is an explicit state machine over the character stream, tracking
              whether it is inside a quoted region, exactly as RFC 4180 describes. It also handles
              the things the RFC does not mention but real files contain: a UTF-8 byte-order mark
              before the first column name, CRLF and bare LF line endings mixed in one file, a
              trailing newline that would otherwise produce a phantom empty record, and a stray
              quote in the middle of an unquoted field, which Excel writes and which is taken
              literally rather than treated as fatal.
            </p>
            <p>
              Delimiter detection counts candidates in the header line — comma, semicolon, tab,
              pipe — but only outside quoted regions. A file whose header is{" "}
              <code>name,description</code> with semicolons inside the quoted descriptions would
              otherwise be split on the wrong character, which is the kind of bug that looks like
              corrupt data rather than a wrong setting.
            </p>
            <p>
              Type inference is deliberately conservative. A cell matching the JSON number grammar
              becomes a number, <code>true</code>/<code>false</code> become booleans, and{" "}
              <code>null</code> becomes null. Everything else stays a string — including{" "}
              <code>007</code>, because the grammar forbids leading zeros and a part number must not
              be renumbered, and including integers beyond 2<sup>53</sup>, because converting those
              drops digits outright.
            </p>
            <p>
              Finally, column names that look like paths are treated as paths:{" "}
              <code>customer.name</code> rebuilds a nested object, <code>tags[0]</code> rebuilds an
              array. Because those names come from the file, they are untrusted input being used to
              index an object — a column called <code>a.__proto__.polluted</code> is a
              prototype-pollution payload, and it is refused rather than followed.
            </p>
          </>
        ),
        inputTitle: "CSV in",
        exampleInput: `id,user.name,tags[0],tags[1]
1,Ada,a,b
2,"Hopper, G.",c,`,
        outputTitle: "JSON out",
        exampleOutput: `[
  { "id": 1, "user": { "name": "Ada" }, "tags": ["a", "b"] },
  { "id": 2, "user": { "name": "Hopper, G." }, "tags": ["c"] }
]`,
      }}
      referenceTable={{
        title: "Parsing options and edge cases",
        rows: [
          {
            parameter: "Delimiter",
            type: "auto | , ; tab |",
            defaultVal: "auto",
            description:
              "Auto counts candidates in the header line, ignoring anything inside quotes. Override it when a file's header is unrepresentative of its body.",
          },
          {
            parameter: "Header row",
            type: "boolean",
            defaultVal: "true",
            description:
              "Row one supplies the keys. With it off, keys are column1, column2 and so on. A blank header cell also falls back to a positional name so the record is never missing a key.",
          },
          {
            parameter: "Infer types",
            type: "boolean",
            defaultVal: "true",
            description:
              "Applies the JSON number grammar plus true/false/null. \"007\", \"+1\", \"0x10\" and \"1,5\" stay strings. Turn it off when every column must remain text — an ID column full of digits is the usual reason.",
          },
          {
            parameter: "Expand paths",
            type: "boolean",
            defaultVal: "true",
            description:
              "Rebuilds nesting from customer.name and tags[0]. With it off you get a flat object whose keys are the literal column names, which is what you want when a column is genuinely called \"user.name\".",
          },
          {
            parameter: "Empty cells",
            type: "omit | keep",
            defaultVal: "omit",
            description:
              "CSV cannot distinguish an absent field from an empty string. Omitting is the better default because the column set is a union: a record that simply lacks tags[1] is written as an empty cell exactly like one whose tags[1] is \"\".",
          },
          {
            parameter: "Quoted fields",
            type: "RFC 4180",
            defaultVal: "—",
            description:
              "A quoted field may contain the delimiter, CR, LF and doubled quotes. An unterminated quote is a hard error with a line and column, because silently truncating would produce plausible, wrong output.",
          },
          {
            parameter: "Ragged rows",
            type: "warning",
            defaultVal: "—",
            description:
              "A row with the wrong number of fields is kept, not dropped: missing fields are omitted and extra ones ignored, with a warning saying how many rows were affected.",
          },
          {
            parameter: "Duplicate columns",
            type: "warning",
            defaultVal: "rightmost wins",
            description:
              "Matches spreadsheet import behaviour. Warned about explicitly, because silently discarding a column the user can see in the file is worse than saying so.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why does my file convert wrongly when a field contains a comma?",
          answer:
            "It should not — this parser tracks quoting properly, so \"Hopper, G.\" stays one field. If a converter splits it into two, it is splitting on commas without regard to quotes, which is the single most common CSV bug. If it happens here, check whether the field is actually quoted in the source file: an unquoted comma is genuinely ambiguous and no parser can recover it.",
        },
        {
          question: "My ID column has leading zeros and they keep disappearing.",
          answer:
            "Not here — \"007\" stays a string, because the JSON number grammar forbids leading zeros and that rule is exactly what protects part numbers, postcodes and account references. If zeros are disappearing, it happened in the spreadsheet before export: Excel strips them on import unless the column is set to Text. If you want every column kept as text, turn off Infer types.",
        },
        {
          question: "What does customer.name in a header do?",
          answer:
            "It rebuilds a nested object: {\"customer\":{\"name\":\"…\"}}. Bracketed names like tags[0] rebuild arrays. This is the inverse of what JSON to CSV writes, so a document survives a round trip through a spreadsheet. If your columns are genuinely named with dots and you want them literal, turn off Expand paths.",
        },
        {
          question: "Can it handle a file with newlines inside a field?",
          answer:
            "Yes, provided the field is quoted, which RFC 4180 requires. An address or a comment spanning several lines is common in exports and is handled correctly. What cannot be handled is an unquoted newline mid-record, because nothing distinguishes it from the end of the row.",
        },
        {
          question: "How large a file can I convert?",
          answer:
            "Up to 8 MB. The conversion runs on the main thread, and past that ceiling it is declined with a message rather than attempted, because attempting it locks the tab. Nothing is uploaded at any size — the file is read by your browser and never sent anywhere.",
        },
        {
          question: "Is my spreadsheet data sent to a server?",
          answer:
            "No. Parsing happens in the page you already have open. That matters for this tool specifically, because a CSV export is usually real records — customers, orders, payroll — and sending one to an unknown endpoint to reformat it is a disclosure you cannot undo. Open the Network panel and watch while you paste.",
        },
      ]}
      relatedTools={relatedTools("/csv-to-json").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="CSV"
        outputLabel="JSON"
        inputPlaceholder="Paste a CSV export…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="records.json"
        options={
          <>
            <div className="flex items-center gap-2">
              <label htmlFor="delimiter" className={fieldLabel}>
                Delimiter
              </label>
              <select
                id="delimiter"
                className={`${field} cursor-pointer`}
                value={options.delimiter}
                onChange={(e) =>
                  setOptions({ ...options, delimiter: e.target.value as Delimiter | "auto" })
                }
              >
                <option value="auto">Detect</option>
                <option value=",">Comma</option>
                <option value=";">Semicolon</option>
                <option value="&#9;">Tab</option>
                <option value="|">Pipe</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="indent" className={fieldLabel}>
                Indent
              </label>
              <select
                id="indent"
                className={`${field} cursor-pointer`}
                value={indent}
                onChange={(e) => setIndent(Number(e.target.value))}
              >
                <option value={2}>2 spaces</option>
                <option value={4}>4 spaces</option>
                <option value={0}>Minified</option>
              </select>
            </div>

            {(
              [
                ["hasHeader", "First row is a header"],
                ["inferTypes", "Infer types"],
                ["expandPaths", "Expand paths"],
                ["omitEmpty", "Omit empty cells"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground"
              >
                <input
                  type="checkbox"
                  className={checkbox}
                  checked={options[key]}
                  onChange={(e) => setOptions({ ...options, [key]: e.target.checked })}
                />
                {label}
              </label>
            ))}
          </>
        }
      />
    </ToolShell>
  );
};
