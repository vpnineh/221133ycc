import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { CsvToJsonClient } from "./CsvToJsonClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/csv-to-json",
  title: "CSV to JSON — RFC 4180 Converter, No Upload",
  socialTitle: "CSV to JSON",
  description:
    "Convert CSV to JSON in your browser. RFC 4180 quoting, embedded newlines, delimiter detection and nested objects rebuilt from column paths.",
});

export default function CsvToJsonPage() {
  return <CsvToJsonClient />;
}
