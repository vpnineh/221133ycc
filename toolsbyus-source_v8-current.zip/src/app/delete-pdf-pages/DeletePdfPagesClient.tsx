"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SinglePdfTool } from "../../components/tools/SinglePdfTool";
import { Notice } from "../../components/common/Notice";
import { field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parsePageRange, formatPageRange } from "../../lib/files";
import { withStem } from "../../lib/files/naming";
import { relatedTools } from "../../lib/tools";

export const DeletePdfPagesClient: React.FC = () => {
  const [range, setRange] = useState("1");
  const [mode, setMode] = useState<"remove" | "keep">("remove");

  return (
    <ToolShell
      slug="delete-pdf-pages"
      keyword="Delete PDF Pages"
      directAnswer="Delete PDF Pages removes pages from a document in your browser. The removed content is genuinely absent from the output — the remaining pages are copied into a new document rather than the originals being hidden — so nothing you deleted can be extracted from the file afterwards."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Delete PDF Pages", url: "/delete-pdf-pages" },
      ]}
      seoDescription="Remove pages from a PDF in your browser. Deleted content is absent from the output rather than hidden, so it cannot be recovered with a text extractor. No upload, no watermark."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The interesting question about deleting a page is not how to do it. It is whether the
              page is gone.
            </p>
            <h3>Removed from the page tree is not removed from the file</h3>
            <p>
              A PDF is an object graph. Taking a page out of the page tree makes it stop appearing
              in a reader, and leaves its content stream, its text, and any images it referenced
              sitting in the file as unreferenced objects. Anyone running a text extractor over the
              result gets the deleted page back, complete.
            </p>
            <p>
              This is not a theoretical failure. It is the same class of mistake as redacting a
              document by drawing black rectangles over it, which has repeatedly put unredacted
              names in the news, and it is why every serious document workflow says &ldquo;flatten
              and re-export&rdquo; rather than &ldquo;delete and save&rdquo;.
            </p>
            <p>
              So deletion here is done by construction: the pages you keep are copied into a new
              document with their dependency graph, and the ones you removed are simply never
              referenced. Nothing carries them over, so nothing can recover them. You can check by
              running a text extractor over the result — the deleted words are not there.
            </p>
            <h3>Keep or remove, whichever is shorter to type</h3>
            <p>
              Removing pages 1 to 3 of a 200-page document and keeping pages 1 to 3 of it are
              opposite operations, and which one is less typing depends entirely on the document.
              Both are here for that reason and no other.
            </p>
            <h3>A document with no pages is not a document</h3>
            <p>
              Removing every page produces a file that most readers refuse to open — a PDF is
              required to have at least one page. Rather than writing one and letting you discover
              that later, the operation is refused with an explanation.
            </p>
            <h3>Indices, and the order they are applied in</h3>
            <p>
              Pages are removed highest-index first. Removing page 2 shifts every later page down by
              one, so an implementation that removes in ascending order deletes the wrong pages after
              the first — a bug that produces a plausible-looking document missing the wrong
              content, which is the worst kind.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `report.pdf (24 pages)
remove: 1, 3-5, 24`,
        outputTitle: "Output",
        exampleOutput: `trimmed.pdf (19 pages)
removed pages copied nowhere,
so their text is not in the file`,
      }}
      referenceTable={{
        title: "Options and behaviour",
        rows: [
          {
            parameter: "Remove these",
            type: "mode",
            defaultVal: "default",
            description: "The listed pages come out; everything else stays, in its original order.",
          },
          {
            parameter: "Keep only these",
            type: "mode",
            defaultVal: "—",
            description:
              "The inverse. Less typing when you want a handful of pages out of a long document.",
          },
          {
            parameter: "1, 3-5, 24",
            type: "range list",
            defaultVal: "—",
            description:
              "Print-dialogue syntax. One-based, commas separate parts, a hyphen makes a range, an open end runs to the document's edge.",
          },
          {
            parameter: "Deleted content",
            type: "absent",
            defaultVal: "always",
            description:
              "Kept pages are copied into a new document. Removing a page from the page tree of a copy would leave its text recoverable by any extractor.",
          },
          {
            parameter: "Removing everything",
            type: "refused",
            defaultVal: "—",
            description:
              "A PDF needs at least one page. The operation is declined rather than producing a file readers reject.",
          },
          {
            parameter: "Order",
            type: "preserved",
            defaultVal: "—",
            description: "Surviving pages keep their relative order. For rearranging, use the reorder tool.",
          },
          {
            parameter: "Bookmarks",
            type: "not carried",
            defaultVal: "—",
            description:
              "Destinations would point at pages that no longer exist, producing an outline that looks fine until clicked.",
          },
        ],
      }}
      faqs={[
        {
          question: "Is the deleted content really gone, or just hidden?",
          answer:
            "Gone. The pages you keep are copied into a brand-new document; the removed ones are never referenced, so nothing carries their text or images across. This is worth verifying in any tool you use — run a text extractor over the output and search for a phrase from a deleted page. If it comes back, that tool hid the page rather than removing it, and you have just emailed someone the thing you deleted.",
        },
        {
          question: "Is this a substitute for redaction?",
          answer:
            "For a whole page, yes — the page is genuinely absent. For part of a page, absolutely not. Removing a sentence from a page requires editing its content stream, and drawing a black rectangle over text leaves the text underneath, selectable and extractable. That mistake has put unredacted names in court filings and newspapers more than once. Proper redaction needs a tool built for it.",
        },
        {
          question: "Which is faster, remove or keep?",
          answer:
            "They do the same amount of work; the difference is how much you type. Pulling three pages out of a 200-page document is easier to express as \"keep 4, 17, 132\" than as a list of the other 197. Pick whichever describes your intent in fewer characters — the result is identical either way.",
        },
        {
          question: "Why can I not delete every page?",
          answer:
            "Because a PDF with no pages is not a valid PDF, and most readers refuse to open one. Rather than write a file you would discover was broken later, the operation is declined. If you want an empty document for some reason, a one-page blank is the usable version of that.",
        },
        {
          question: "Will the remaining pages be renumbered?",
          answer:
            "Their positions change — the page after a deleted one moves up — but any page numbers printed on the page itself are part of its content and do not change, because nothing re-renders the page. A 24-page report with pages 1-3 removed becomes a 21-page file whose first page still says \"4\" on it. Repaginating is a layout operation, not a PDF one.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. Pages are removed in this tab and the result is saved locally. The page's Content-Security-Policy sets connect-src 'self', so an upload would be blocked by the browser. This matters more here than on most tools: you are deleting something, which usually means the thing you are deleting is exactly what should not be sent anywhere.",
        },
      ]}
      relatedTools={relatedTools("/delete-pdf-pages").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <SinglePdfTool
        runLabel={() => (mode === "remove" ? "Remove pages" : "Keep only these")}
        controls={(info) => {
          const parsed = parsePageRange(range, info.pageCount);
          const surviving =
            parsed.error === undefined
              ? mode === "remove"
                ? Array.from({ length: info.pageCount }, (_unused, index) => index).filter(
                    (index) => !parsed.pages.includes(index)
                  )
                : parsed.pages
              : [];

          return (
            <div className="space-y-3">
              <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
                <div className={segmentTrack} role="group" aria-label="Mode">
                  {(
                    [
                      ["remove", "Remove these"],
                      ["keep", "Keep only these"],
                    ] as const
                  ).map(([value, label]) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setMode(value)}
                      aria-pressed={mode === value}
                      className={segment(mode === value)}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <label htmlFor="delete-range" className={fieldLabel}>
                    Pages
                  </label>
                  <input
                    id="delete-range"
                    type="text"
                    value={range}
                    onChange={(event) => setRange(event.target.value)}
                    placeholder="1, 3-5, 24"
                    spellCheck={false}
                    className={`${field} w-44`}
                  />
                </div>

                <span className="font-mono text-2xs text-foreground-subtle">
                  {parsed.error ?? `${surviving.length} of ${info.pageCount} pages remain`}
                </span>
              </div>

              {!parsed.error && surviving.length === 0 && (
                <Notice tone="warn">
                  That would leave no pages at all, and a PDF with no pages is not a document any
                  reader will open.
                </Notice>
              )}

              {!parsed.error && surviving.length > 0 && surviving.length < info.pageCount && (
                <Notice tone="info">
                  Keeping pages {formatPageRange(surviving)}. The removed pages are copied nowhere,
                  so their text will not be in the output file.
                </Notice>
              )}
            </div>
          );
        }}
        naming={{ mode: "single", defaultStem: (stem) => `${stem}-trimmed` }}
        operation={async (info, file, stem) => {
          const parsed = parsePageRange(range, info.pageCount);
          if (parsed.error) return { blocked: parsed.error };

          const all = Array.from({ length: info.pageCount }, (_unused, index) => index);
          const keep =
            mode === "remove" ? all.filter((index) => !parsed.pages.includes(index)) : parsed.pages;

          if (keep.length === 0) {
            return {
              blocked:
                "That would remove every page. A PDF needs at least one, and readers refuse a file with none.",
            };
          }

          // Copying the survivors into a fresh document is what makes the
          // removed content genuinely absent, rather than merely unreferenced
          // in a copy of the original.
          return {
            type: "reorder",
            file: await file.arrayBuffer(),
            order: keep,
            name: withStem(stem, "pdf"),
          };
        }}
      />
    </ToolShell>
  );
};
