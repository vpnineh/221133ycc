import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { DeletePdfPagesClient } from "./DeletePdfPagesClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/delete-pdf-pages",
  title: "Delete PDF Pages — Removed, Not Just Hidden",
  socialTitle: "Delete PDF Pages",
  description:
    "Remove pages from a PDF in your browser. The deleted content is genuinely gone from the file rather than hidden, and nothing is uploaded.",
});

export default function DeletePdfPagesPage() {
  return <DeletePdfPagesClient />;
}
