"use client";

import React, { useState, useMemo } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { computeTextDiff, TextDiffOptions } from "../../lib/diff/text-diff";
import { TextDiffGranularity } from "../../lib/diff/types";
import { Icon } from "../../components/common/Icon";
import { btnCompact, btnPrimary, btnSecondary, checkbox, field } from "../../components/common/controls";

const DEFAULT_OLD = `# API Gateway Configuration v1.2
server {
    listen 80;
    server_name api.toolsbyus.com;

    # Rate limiting zone
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=100r/s;

    location /v1/payloads {
        proxy_pass http://backend_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_connect_timeout 3s;
        proxy_read_timeout 10s;
    }
}`;

const DEFAULT_NEW = `# API Gateway Configuration v1.3
server {
    listen 443 ssl http2;
    server_name api.toolsbyus.com;

    # Enhanced rate limiting zone
    limit_req_zone $binary_remote_addr zone=api_limit:20m rate=250r/s;

    location /v1/payloads {
        proxy_pass http://backend_cluster_ssl;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_connect_timeout 5s;
        proxy_read_timeout 15s;
    }

    location /healthz {
        return 200 "OK";
    }
}`;

export const DiffCheckerClient: React.FC = () => {
  const [oldText, setOldText] = useState(DEFAULT_OLD);
  const [newText, setNewText] = useState(DEFAULT_NEW);
  const [granularity, setGranularity] = useState<TextDiffGranularity>("line");
  const [ignoreWhitespace, setIgnoreWhitespace] = useState(false);
  const [ignoreCase, setIgnoreCase] = useState(false);
  const [viewMode, setViewMode] = useState<"split" | "unified">("split");
  const [patchModalOpen, setPatchModalOpen] = useState(false);

  const diffOptions: TextDiffOptions = useMemo(
    () => ({
      granularity,
      ignoreWhitespace,
      ignoreCase,
    }),
    [granularity, ignoreWhitespace, ignoreCase]
  );

  const diffResult = useMemo(() => {
    return computeTextDiff(oldText, newText, diffOptions);
  }, [oldText, newText, diffOptions]);

  const handleExportPatch = () => {
    setPatchModalOpen(true);
  };

  return (
    <ToolShell
      wide
      slug="diff-checker"
      keyword="Diff Checker"
      directAnswer="Diff Checker is a high-speed, client-side textual comparison engine executing the Myers difference algorithm directly in your browser. It supports line, word, and character granularity, unified and side-by-side views, whitespace and case normalization toggles, and instant unified diff patch generation with zero external network transmission."
      seoDescription="Compare text, code, and markdown with side-by-side and unified diff views. Line, word, and character granularity with unified diff patch export."
      breadcrumbs={[{ name: "Diff Checker", url: "/diff-checker" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The ToolsByUs text diff engine is based on Eugene W. Myers&apos; seminal paper <em>&quot;An O(ND) Difference Algorithm and Its Variations&quot;</em>. The algorithm models the problem of computing the shortest edit script (SES) as finding a shortest path in an edit graph spanning from coordinates (0, 0) to (N, M).
            </p>
            <p>
              By tracking the furthest reaching paths along diagonals <code>k = x - y</code> for each edit distance <code>D</code>, Myers diff discovers the minimum number of insertions and deletions necessary to transform the original text into the target text. When applied at the <strong>word level</strong>, the engine performs a secondary diff on modified lines to precisely isolate word-level deletions and insertions.
            </p>
            <p>
              Unlike server-side tools that transmit your source files, proprietary configs, or confidential logs to a remote database, ToolsByUs runs the entire Myers edit matrix directly in local browser memory.
            </p>
          </>
        ),
        inputTitle: "Original vs Modified Sample",
        exampleInput: `// Original:\nconst port = 8080;\n\n// Modified:\nconst port = 3000;`,
        exampleOutput: `// Unified Diff:\n@@ -1,1 +1,1 @@\n-const port = 8080;\n+const port = 3000;`,
      }}
      referenceTable={{
        title: "Text Diff Options & Performance Parameters",
        rows: [
          {
            parameter: "Granularity: line",
            type: "Mode",
            defaultVal: "Default",
            description: "Splits text on newline boundaries. Fast O(ND) execution ideal for code, config, and scripts.",
          },
          {
            parameter: "Granularity: word",
            type: "Mode",
            defaultVal: "Optional",
            description: "Splits lines into word tokens. Modified lines highlight word-level insertions and deletions.",
          },
          {
            parameter: "Granularity: char",
            type: "Mode",
            defaultVal: "Optional",
            description: "Splits strings into individual character units. Pinpoints typos, hashes, and base64 strings.",
          },
          {
            parameter: "Ignore Whitespace",
            type: "Toggle",
            defaultVal: "false",
            description: "Normalizes consecutive spaces and tabs so indentation adjustments do not trigger changes.",
          },
          {
            parameter: "Ignore Case",
            type: "Toggle",
            defaultVal: "false",
            description: "Compares text case-insensitively, useful for SQL queries, HTTP headers, or HTML tags.",
          },
          {
            parameter: "Unified Diff Export",
            type: "Format",
            defaultVal: "Standard",
            description: "Exports standard unified diff format compatible with git apply, patch(1), and review tools.",
          },
        ],
      }}
      faqs={[
        {
          question: "How does the Myers diff algorithm work?",
          answer:
            "The Myers diff algorithm finds the shortest sequence of additions and deletions to convert sequence A into sequence B. It operates by exploring diagonal paths across an edit grid, guaranteeing mathematical minimality of the resulting diff output.",
        },
        {
          question: "Can I export a unified diff patch file?",
          answer:
            "Yes. Clicking 'Export Unified Patch' produces a standard unified patch document with '---' and '+++' headers and '@@ -start,len +start,len @@' hunk ranges that can be copied or fed directly to standard UNIX patch or git apply utilities.",
        },
        {
          question: "How does word-level diffing help code reviews?",
          answer:
            "Standard line diffs highlight the entire line even if only a single character or variable name changed. Our word-level diff engine compares modified lines token by token, highlighting only the specific tokens that were altered within that line.",
        },
        {
          question: "Are my documents saved or cached on any server?",
          answer:
            "No. ToolsByUs has no backend server or database. All diff calculations run strictly inside your browser. No files, logs, or text are ever uploaded.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Compare JSON documents with AST semantic invariance and array key matching.",
        },
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Validate JSON syntax against RFC 8259 with exact caret reporting.",
        },
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Beautify and indent JSON payloads with comment support and key sorting.",
        },
        {
          href: "/base64-decode",
          title: "Base64 & JWT Decoder",
          description: "Encode and decode standard and URL-safe Base64 with binary file download.",
        },
      ]}
    >
      <div className="space-y-4">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-border bg-surface text-xs font-mono">
          <div className="flex flex-wrap items-center gap-3">
            {/* Granularity */}
            <div className="flex items-center gap-1.5">
              <label htmlFor="granularity-select" className="text-foreground-muted font-semibold">
                Granularity:
              </label>
              <select
                id="granularity-select"
                value={granularity}
                onChange={(e) => setGranularity(e.target.value as TextDiffGranularity)}
                className={field}
              >
                <option value="line">Line-by-Line</option>
                <option value="word">Word-by-Word</option>
                <option value="char">Character-by-Character</option>
              </select>
            </div>

            {/* Ignore Whitespace */}
            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted hover:text-foreground-muted">
              <input
                type="checkbox"
                checked={ignoreWhitespace}
                onChange={(e) => setIgnoreWhitespace(e.target.checked)}
                className={checkbox}
              />
              <span>Ignore Whitespace</span>
            </label>

            {/* Ignore Case */}
            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted hover:text-foreground-muted">
              <input
                type="checkbox"
                checked={ignoreCase}
                onChange={(e) => setIgnoreCase(e.target.checked)}
                className={checkbox}
              />
              <span>Ignore Case</span>
            </label>

            {/* View Mode Toggle */}
            <div className="flex items-center rounded bg-surface-elevated p-0.5 border border-border">
              <button
                type="button"
                onClick={() => setViewMode("split")}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  viewMode === "split"
                    ? "bg-surface-elevated text-foreground font-semibold"
                    : "text-foreground-muted hover:text-foreground"
                }`}
              >
                Side-by-Side
              </button>
              <button
                type="button"
                onClick={() => setViewMode("unified")}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  viewMode === "unified"
                    ? "bg-surface-elevated text-foreground font-semibold"
                    : "text-foreground-muted hover:text-foreground"
                }`}
              >
                Unified
              </button>
            </div>
          </div>

          <div>
            <button
              type="button"
              onClick={handleExportPatch}
              className={btnCompact}
            >
              Export Unified Patch
            </button>
          </div>
        </div>

        {/* Input Panes */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CodePane
            label="Original Text (Base)"
            value={oldText}
            onChange={setOldText}
            placeholder="Paste original text or code..."
          />
          <CodePane
            label="Modified Text (Target)"
            value={newText}
            onChange={setNewText}
            placeholder="Paste modified text or code..."
          />
        </div>

        {/* Summary Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-border bg-surface text-xs font-mono">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-foreground-muted">Metrics:</span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-accent-soft text-accent border border-accent-line">
              <span className="font-bold">+</span>
              <span>{diffResult.summary.addedLines} added</span>
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-danger-soft text-danger border border-danger">
              <span className="font-bold">-</span>
              <span>{diffResult.summary.removedLines} removed</span>
            </span>
            <span className="text-foreground-muted">
              {diffResult.summary.unchangedLines} unchanged
            </span>
          </div>
        </div>

        {/* Text Diff Viewer */}
        <div
          className="border border-border rounded-lg bg-background font-mono text-xs overflow-auto select-text focus:outline-none"
          style={{ maxHeight: 520 }}
          tabIndex={0}
          role="region"
          aria-label="Text Diff Viewer"
        >
          {diffResult.lines.map((l) => {
            const isAdded = l.type === "added";
            const isRemoved = l.type === "removed";
            const isModified = l.type === "modified";

            const rowBg = isAdded
              ? "bg-accent-soft text-accent"
              : isRemoved
              ? "bg-danger-soft text-danger"
              : isModified
              ? "bg-warn-soft text-foreground"
              : "text-foreground-muted hover:bg-surface";

            const glyph = isAdded ? "+" : isRemoved ? "-" : isModified ? "≠" : " ";

            if (viewMode === "split") {
              return (
                <div
                  key={l.id}
                  className={`grid grid-cols-2 border-b border-border ${rowBg}`}
                >
                  {/* Left half */}
                  <div className="flex items-start border-r border-border px-2 py-1 overflow-x-auto">
                    <span className="w-8 text-right text-foreground-muted select-none mr-2 font-mono">
                      {l.leftLineNum ?? " "}
                    </span>
                    <span className="font-bold mr-2 text-danger select-none">
                      {isRemoved || isModified ? "-" : " "}
                    </span>
                    <span className="whitespace-pre flex-1">
                      {isModified && l.words ? (
                        l.words.map((w, i) => (
                          <span
                            key={i}
                            className={
                              w.type === "removed"
                                ? "bg-danger-soft text-danger px-0.5 rounded"
                                : ""
                            }
                          >
                            {w.value}
                          </span>
                        ))
                      ) : (
                        l.leftText ?? ""
                      )}
                    </span>
                  </div>

                  {/* Right half */}
                  <div className="flex items-start px-2 py-1 overflow-x-auto">
                    <span className="w-8 text-right text-foreground-muted select-none mr-2 font-mono">
                      {l.rightLineNum ?? " "}
                    </span>
                    <span className="font-bold mr-2 text-accent select-none">
                      {isAdded || isModified ? "+" : " "}
                    </span>
                    <span className="whitespace-pre flex-1">
                      {isModified && l.words ? (
                        l.words.map((w, i) => (
                          <span
                            key={i}
                            className={
                              w.type === "added"
                                ? "bg-accent-soft text-accent px-0.5 rounded font-semibold"
                                : ""
                            }
                          >
                            {w.value}
                          </span>
                        ))
                      ) : (
                        l.rightText ?? ""
                      )}
                    </span>
                  </div>
                </div>
              );
            }

            // Unified view
            return (
              <div
                key={l.id}
                className={`flex items-start border-b border-border px-2 py-1 ${rowBg}`}
              >
                <div className="w-16 flex-none flex items-center justify-between text-foreground-muted select-none mr-3">
                  <span className="w-7 text-right">{l.leftLineNum ?? " "}</span>
                  <span className="w-7 text-right">{l.rightLineNum ?? " "}</span>
                </div>
                <span className="font-bold mr-2 select-none">{glyph}</span>
                <span className="whitespace-pre flex-1">
                  {l.rightText || l.leftText || " "}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Unified Patch Modal */}
      {patchModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-scrim p-4"
        >
          <div className="w-full max-w-2xl rounded-lg border border-border bg-surface p-5 flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-border">
              <h3 className="text-sm font-bold text-foreground font-mono">Unified Diff Patch</h3>
              <button
                type="button"
                onClick={() => setPatchModalOpen(false)}
                className="inline-flex h-8 w-8 cursor-pointer items-center justify-center rounded border border-border bg-surface text-foreground-muted transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:h-11 pointer-coarse:w-11"
                aria-label="Close dialog"
              >
                <Icon name="close" size="md" />
              </button>
            </div>

            <div className="py-3 flex-1 overflow-hidden">
              <textarea
                value={diffResult.unifiedPatch}
                readOnly
                className="w-full h-72 p-3 rounded bg-background font-mono text-xs text-accent border border-border resize-none focus:outline-none leading-relaxed select-all"
              />
            </div>

            <div className="pt-3 border-t border-border flex items-center justify-between">
              <span className="text-2xs text-foreground-muted font-mono">
                Standard git/UNIX compatible unified diff patch.
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    await navigator.clipboard.writeText(diffResult.unifiedPatch);
                    setPatchModalOpen(false);
                  }}
                  className={btnPrimary}
                >
                  Copy Patch & Close
                </button>
                <button
                  type="button"
                  onClick={() => setPatchModalOpen(false)}
                  className={btnSecondary}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </ToolShell>
  );
};
