import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { DiffCheckerClient } from "./DiffCheckerClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/diff-checker",
  title: "Diff Checker — Compare Text Side by Side",
  socialTitle: "Diff Checker",
  description:
    "Compare text, code, and markdown with side-by-side and unified diff views. Line, word, and character granularity with unified diff patch export.",
});

export default function DiffCheckerPage() {
  return <DiffCheckerClient />;
}
