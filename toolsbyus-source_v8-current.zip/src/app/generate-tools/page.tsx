import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryOf } from "@/lib/tools";

const CATEGORY = categoryOf("generate")!;
const LAST_REVIEWED = "2026-09-11";

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "Generator Tools — UUIDs, QR Codes, Lorem Ipsum",
  socialTitle: "Generator Tools",
  description:
    "Generate UUIDs in bulk — v4, v7 and v1 — using your browser's own cryptographic random source, and inspect the version, variant and timestamp of existing ones.",
});

export default function GenerateToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These generators produce identifiers and placeholder values in your browser. Randomness comes from the Web Crypto API — the same cryptographic source the platform uses for keys — rather than from Math.random or from a server that has now seen every identifier it issued you."
      faqs={[
        {
          question: "Should I use UUID v4 or v7 for a database primary key?",
          answer:
            "v7 for anything that goes into an indexed column. v4 is 122 bits of randomness, so consecutive inserts land at random points in a B-tree index: every insert dirties a different page, the index fragments, and write throughput degrades measurably as the table grows. v7 puts a 48-bit millisecond timestamp in the high bits, so newly generated values sort near each other and inserts append to the same region of the index. v4 remains the right choice when the identifier is public and must not leak creation time.",
        },
        {
          question: "Are these UUIDs actually random, or is it a seeded PRNG?",
          answer:
            "They come from crypto.getRandomValues(), the Web Crypto API's cryptographically secure generator, which draws from the operating system's entropy pool. That is the same source used for key material, and it is categorically different from Math.random(), which is a fast non-cryptographic PRNG whose output is predictable from a handful of prior values.",
        },
        {
          question: "What is RFC 9562 and does it change anything?",
          answer:
            "RFC 9562, published in May 2024, replaced RFC 4122 as the UUID standard. It kept v1 and v4 unchanged and added the time-ordered versions v6, v7 and v8. In practice the change that matters is v7 becoming a standard rather than a collection of incompatible vendor extensions such as ULID and KSUID.",
        },
        {
          question: "Can I generate a lot at once?",
          answer:
            "Yes — bulk generation goes up to 10,000 per batch, with output as plain lines, quoted strings, a JSON array or a delimiter of your choice, ready to paste into a seed file or a fixture. Generation is synchronous and near-instant; the practical limit is what you can paste, not what the browser can produce.",
        },
        {
          question: "Can I check what an existing UUID is?",
          answer:
            "Yes. Paste one into the inspector and it reports the version, the variant, and — for v1, v6 and v7 — the embedded timestamp decoded to a readable date. That is the fastest way to find out whether the identifiers in a table are time-ordered, and whether they leak a creation time you did not intend to publish.",
        },
      ]}
      intro={
        <>
          <p>
            A generator seems like the one kind of tool where it could not possibly matter where the
            work happens. It matters twice.
          </p>
          <p>
            The first reason is that a server-side generator has seen every identifier it gave you.
            If those become primary keys, API keys, invitation tokens or anything else with
            authority attached, a third party now holds a list of them. That is unlikely to be
            exploited and is still an entirely avoidable exposure, because the browser has a
            perfectly good cryptographic random source built in.
          </p>
          <p>
            The second is quality. A depressing number of online generators call{" "}
            <code>Math.random()</code>, which is a fast non-cryptographic PRNG. Its output is
            uniform enough to look random and is predictable from a short run of prior values. For
            a test fixture that is harmless. For anything that gates access it is a vulnerability,
            and nothing in the output distinguishes the two cases. These tools use{" "}
            <code>crypto.getRandomValues()</code> exclusively.
          </p>
          <p>
            The choice between UUID versions is the decision most worth getting right, and it is
            usually made by accident. v4 — pure randomness — is the default almost everywhere, and
            it is a poor primary key at scale for a structural reason: random values scatter across
            a B-tree index, so every insert touches a different page, the cache hit rate collapses
            and the index fragments. Teams generally discover this as a slow, unexplained
            degradation in write throughput somewhere past the first few million rows.
          </p>
          <p>
            v7 fixes it by putting a millisecond timestamp in the leading 48 bits, so identifiers
            generated near each other in time sort near each other, and inserts append to the hot
            end of the index. It is the right default for database keys under RFC 9562. The
            trade-off is real and worth stating: a v7 identifier publishes its own creation time to
            anyone who can read it, so for a public-facing identifier where that is sensitive, v4
            is still correct.
          </p>
          <p>
            v1 is included for completeness and for reading legacy data. It encodes a timestamp and,
            in its original form, the generating machine&rsquo;s MAC address — which is why it fell
            out of favour, and why being able to inspect one is more useful than being able to
            create one. If you need to convert a generated value into another representation, the{" "}
            <Link href="/base64-decode">Base64 tool</Link> is next door, and{" "}
            <Link href="/json-formatter">JSON Formatter</Link> will tidy a seed file you have
            pasted identifiers into.
          </p>
        </>
      }
    />
  );
}
