import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HashGeneratorClient } from "./HashGeneratorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/hash-generator",
  title: "Hash Generator — SHA-256, MD5, CRC32, HMAC",
  socialTitle: "Hash Generator",
  description:
    "Compute MD5, SHA-1, SHA-256, SHA-512, CRC32 and HMAC in your browser, with each algorithm's security status shown beside the result.",
});

export default function HashGeneratorPage() {
  return <HashGeneratorClient />;
}
