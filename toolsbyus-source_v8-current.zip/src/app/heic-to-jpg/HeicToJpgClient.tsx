"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { ImageResults } from "../../components/tools/ImageResults";
import { useImageBatch } from "../../components/tools/useImageBatch";
import { Notice } from "../../components/common/Notice";
import { btnPrimary, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { type AcceptedFile } from "../../lib/files";
import { fitWithin, FORMAT_EXTENSION, renderAndEncode, type ImageFormat } from "../../lib/images";
import { applyPattern, stemOf } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

export const HeicToJpgClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [format, setFormat] = useState<ImageFormat>("jpeg");
  const [quality, setQuality] = useState(0.85);
  const [maxWidth, setMaxWidth] = useState("");
  const [namePattern, setNamePattern] = useState("");
  const { state, run, reset } = useImageBatch();

  const convert = () => {
    const limit = Number(maxWidth);
    const capped = Number.isFinite(limit) && limit > 0 ? limit : null;

    void run(files, async (decoded, file, position) => {
      const size = capped
        ? fitWithin({ width: decoded.width, height: decoded.height }, { width: capped })
        : { width: decoded.width, height: decoded.height };

      const blob = await renderAndEncode(decoded.bitmap, size, {
        format,
        quality,
        background: "#ffffff",
      });
      return {
        blob,
        name: applyPattern(
          namePattern.trim() || "{name}",
          { name: stemOf(file.name), n: position },
          FORMAT_EXTENSION[format]
        ),
        width: size.width,
        height: size.height,
      };
    });
  };

  const busy = state.status === "running";

  return (
    <ToolShell
      slug="heic-to-jpg"
      keyword="HEIC to JPG"
      directAnswer="HEIC to JPG converts the photos an iPhone takes into a format everything else can open, in your browser. Chrome and Firefox cannot decode HEIC themselves, so this page loads a real HEVC decoder — compiled to WebAssembly, fetched only when you drop a HEIC file — and runs it locally. Your photos are not uploaded."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "HEIC to JPG", url: "/heic-to-jpg" },
      ]}
      seoDescription="Convert HEIC and HEIF photos from an iPhone to JPG or PNG in the browser, in batches, with a local WebAssembly decoder and no upload."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              HEIC is what an iPhone has saved photos as since iOS 11 in 2017. It is a good format —
              roughly half the size of JPEG at the same quality — and it is also the reason so many
              people find a folder of files that nothing on their Windows laptop will open.
            </p>

            <h3>Why your browser cannot open a HEIC</h3>
            <p>
              HEIC is a container: HEIF on the outside, HEVC — the video codec also known as H.265 —
              on the inside. HEVC is covered by patent pools that charge for decoder
              implementations, and Chrome and Firefox have declined to ship one for images. Safari
              can, because Apple already licenses HEVC for the whole operating system. So on a Mac
              or an iPhone your HEIC files open everywhere, and on Windows or Android the same files
              are unreadable without extra software.
            </p>

            <h3>What this page does instead</h3>
            <p>
              It carries its own decoder. libheif — the reference open-source HEIF implementation —
              compiled to WebAssembly, running inside this tab. When you drop a file, the browser is
              asked to decode it first; if it refuses and the bytes really are a HEIF container, the
              decoder is downloaded and does the job. Roughly two megabytes, fetched once, and only
              for people who actually need it: convert a JPEG here and none of it is loaded, and
              Safari users never need it at all because their browser can already do this natively.
            </p>
            <p>
              The decoded pixels then go through the same path as every other image on this site —
              a canvas, and the browser&apos;s own JPEG or PNG encoder.
            </p>

            <h3>Detection is by content, not by filename</h3>
            <p>
              A file&apos;s extension is a claim, not evidence. A <code>.heic</code> that is
              actually a JPEG is common — some tools rename rather than convert — and the reverse
              happens on every share sheet that does the same thing backwards. So the check here
              reads the <code>ftyp</code> box at the start of the file, which is where an ISO base
              media container declares what it is, and looks at both the major brand and the
              compatible-brands list: an iPhone writes <code>heic</code>, a Google Photos export
              writes <code>mif1</code> with <code>heic</code> further down the list.
            </p>

            <h3>Orientation, which is where these conversions usually go wrong</h3>
            <p>
              A phone held sideways records the image the way the sensor read it plus a note saying
              which way is up. A converter that ignores the note produces a folder of photos lying
              on their sides. The rotation is applied to the pixels here before encoding, so the
              output needs no note and is upright everywhere.
            </p>

            <h3>Live Photos and bursts</h3>
            <p>
              A HEIC can hold more than one image — a Live Photo carries its still frame alongside a
              short video, and a burst holds a sequence. The first top-level image is the one the
              camera roll shows and is the one converted here. The video part of a Live Photo is not
              an image and is not extracted.
            </p>

            <h3>The privacy point is not incidental</h3>
            <p>
              HEIC files are almost always personal photographs, complete with the GPS coordinates
              of where they were taken. Every &ldquo;free HEIC converter&rdquo; that asks you to
              upload is asking for a copy of your camera roll, with locations attached. Because this
              runs locally, nothing is transmitted — and re-encoding drops the EXIF block, so the
              JPEG that comes out does not carry the location the HEIC went in with.
            </p>

            <h3>Stopping the problem at source</h3>
            <p>
              On an iPhone: Settings → Camera → Formats → <em>Most Compatible</em> makes the camera
              save JPEG directly. You lose some file-size efficiency and gain never having to think
              about this again. There is also Settings → Photos → Transfer to Mac or PC →{" "}
              <em>Automatic</em>, which converts on the way out over a cable.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `IMG_4021.HEIC — 2.1 MB
4032 x 3024, portrait
ftyp brand: heic`,
        outputTitle: "Output",
        exampleOutput: `IMG_4021.jpg — 1.4 MB
3024 x 4032 (rotation applied)
EXIF and GPS not carried over`,
      }}
      referenceTable={{
        title: "Details",
        rows: [
          {
            parameter: "JPG",
            type: "output",
            defaultVal: "default",
            description:
              "Opens everywhere, including software written thirty years ago. The right answer for a photo you need to send someone.",
          },
          {
            parameter: "PNG",
            type: "output",
            defaultVal: "—",
            description:
              "Lossless, and several times larger for a photograph. Worth it only if the image will be edited further.",
          },
          {
            parameter: "WebP",
            type: "output",
            defaultVal: "—",
            description:
              "Smaller than JPG at the same quality and supported by every current browser — but not by every desktop application.",
          },
          {
            parameter: "Quality",
            type: "0.1 – 1.0",
            defaultVal: "0.85",
            description: "Applies to JPG and WebP. 0.85 is visually indistinguishable from the HEIC.",
          },
          {
            parameter: "Max width",
            type: "pixels",
            defaultVal: "none",
            description:
              "Optional. An iPhone photo is 4032 pixels wide, which is more than most destinations need.",
          },
          {
            parameter: "Decoder",
            type: "libheif (WASM)",
            defaultVal: "—",
            description:
              "About 2 MB, loaded only after the browser has refused the file. Safari never needs it.",
          },
          {
            parameter: "Orientation",
            type: "applied",
            defaultVal: "—",
            description: "Rotation is baked into the pixels, so the output is upright everywhere.",
          },
          {
            parameter: "EXIF / GPS",
            type: "dropped",
            defaultVal: "—",
            description: "Re-encoding from pixels does not carry metadata across.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why can't Windows or Chrome open my iPhone photos?",
          answer:
            "HEIC wraps HEVC, the H.265 video codec, and HEVC decoders are patent-licensed. Apple licenses HEVC for its whole operating system, so Safari and macOS open HEIC natively; Chrome and Firefox have chosen not to ship a decoder, and older Windows installations need a paid codec pack from the Microsoft Store. Nothing is wrong with your files — the format is simply not free to implement.",
        },
        {
          question: "How does this page convert HEIC if Chrome cannot?",
          answer:
            "It brings its own decoder. libheif, the open-source reference implementation, compiled to WebAssembly and run inside the tab. It is about two megabytes, which is why it is downloaded only after the browser has already refused the file — nobody converting a JPEG pays for it, and Safari users never need it at all. Once loaded it decodes to raw pixels, and the browser's own JPEG encoder takes it from there.",
        },
        {
          question: "Are my photos uploaded?",
          answer:
            "No, and on this tool that matters more than most. HEIC files are camera-roll photographs, usually carrying the GPS coordinates of where they were taken; a converter that asks you to upload is asking for exactly that. Everything here happens in your browser. You can watch the Network panel while you convert — the only request is the decoder itself, and no photo data leaves the machine. The page is served with connect-src 'self', so an upload would be blocked by the browser.",
        },
        {
          question: "Will the converted photo lose quality?",
          answer:
            "A little, unavoidably: HEIC is already lossy, and re-encoding to JPEG is a second lossy pass. At quality 0.85 the difference is not visible on a photograph — you would need to compare pixel values to find it. The JPEG will typically be larger than the HEIC despite that, because HEIC is genuinely a more efficient format. Choose PNG if you want no second loss at all, and accept a much larger file.",
        },
        {
          question: "Can I convert a whole folder at once?",
          answer:
            "Yes — select or drop as many as you like, up to 100 files and 250 MB in total. They are converted one after another rather than simultaneously, which keeps memory use to a single photo at a time; a dozen 12-megapixel images decoded in parallel is what kills a phone browser. The decoder is loaded once for the whole batch.",
        },
        {
          question: "Does the JPEG still contain my location?",
          answer:
            "No. The conversion decodes to raw pixels and encodes from them, and EXIF metadata — including GPS coordinates, camera model and timestamp — is not carried across. The one thing that is preserved is orientation, and it is preserved by being applied: the rotation is baked into the pixels, so the photo is upright rather than relying on a tag that has been dropped.",
        },
        {
          question: "How do I stop my iPhone making HEIC files?",
          answer:
            "Settings → Camera → Formats → Most Compatible. The camera then saves JPEG directly and you never see this problem again, at the cost of roughly double the storage per photo. There is also Settings → Photos → Transfer to Mac or PC → Automatic, which converts photos as they are copied over a cable while keeping the originals as HEIC on the phone.",
        },
      ]}
      relatedTools={relatedTools("/heic-to-jpg").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".heic", ".heif", "image/heic", "image/heif", "image/*"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          multiple
          label="Drop HEIC photos here"
          disabled={busy}
        />

        {files.length > 0 && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Convert to</span>
              <div className={segmentTrack} role="group" aria-label="Output format">
                {(["jpeg", "png", "webp"] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setFormat(value)}
                    aria-pressed={format === value}
                    className={segment(format === value)}
                  >
                    {value === "jpeg" ? "JPG" : value.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {format !== "png" && (
              <div className="flex items-center gap-2">
                <label htmlFor="heic-quality" className={fieldLabel}>
                  Quality
                </label>
                <input
                  id="heic-quality"
                  type="range"
                  min={10}
                  max={100}
                  value={Math.round(quality * 100)}
                  onChange={(event) => setQuality(Number(event.target.value) / 100)}
                  className="w-32 accent-accent-solid"
                />
                <span className="w-8 font-mono text-2xs text-foreground-subtle">
                  {Math.round(quality * 100)}
                </span>
              </div>
            )}

            <div className="flex items-center gap-2">
              <label htmlFor="heic-max-width" className={fieldLabel}>
                Max width
              </label>
              <input
                id="heic-max-width"
                type="number"
                min={16}
                value={maxWidth}
                onChange={(event) => setMaxWidth(event.target.value)}
                placeholder="none"
                className={`${field} w-24`}
              />
            </div>

            <button type="button" onClick={convert} disabled={busy} className={btnPrimary}>
              {busy ? "Converting…" : `Convert ${files.length} photo${files.length === 1 ? "" : "s"}`}
            </button>
          </div>
        )}

        {busy && (
          <Notice tone="info">
            The first HEIC in a batch takes a moment longer than the rest: the decoder is about two
            megabytes and is being fetched now. It is loaded once and reused for every file after
            this one.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            mode="pattern"
            defaultStem="{name}"
            extension={FORMAT_EXTENSION[format]}
            sample={{ name: stemOf(files[0].file.name), n: 1 }}
            tokens={["name", "n", "date"]}
            value={namePattern}
            onChange={setNamePattern}
          />
        )}

        <ImageResults state={state} />
      </div>
    </ToolShell>
  );
};
