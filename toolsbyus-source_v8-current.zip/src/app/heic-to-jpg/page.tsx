import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HeicToJpgClient } from "./HeicToJpgClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/heic-to-jpg",
  title: "HEIC to JPG — Open iPhone Photos Anywhere",
  socialTitle: "HEIC to JPG",
  description:
    "Convert iPhone HEIC photos to JPG or PNG in your browser. A real HEVC decoder runs locally, so it works in Chrome and Firefox too. No upload.",
});

export default function HeicToJpgPage() {
  return <HeicToJpgClient />;
}
