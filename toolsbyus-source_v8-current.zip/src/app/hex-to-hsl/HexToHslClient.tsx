"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorConvertSurface } from "../../components/tools/ColorConvertSurface";
import { relatedTools } from "../../lib/tools";

export const HexToHslClient: React.FC = () => (
  <ToolShell
    slug="hex-to-hsl"
    keyword="HEX to HSL Converter"
    directAnswer="HEX to HSL converts a hex colour into hue, saturation and lightness. The three channels are scaled to 0–1, then the largest and smallest of them produce the answer: lightness is their midpoint, saturation is how far apart they are, and hue is which channel is largest and by how much. The result is exact and reversible — but HSL's lightness is not the lightness your eye reports, which is worth knowing before you build anything on it."
    breadcrumbs={[
      { name: "Color Tools", url: "/color-tools" },
      { name: "HEX to HSL", url: "/hex-to-hsl" },
    ]}
    seoDescription="Convert a hex colour to hue, saturation and lightness in CSS syntax, with the max, min and chroma the formula runs on shown. Runs entirely in your browser."
    howItWorks={{
      inputTitle: "A hex colour",
      outputTitle: "Hue, saturation, lightness",
      exampleInput: "#ff8800",
      exampleOutput: `hsl(32 100% 50%)

max  255 / 255 = 1.000   (red)
min    0 / 255 = 0.000   (blue)
lightness = (1 + 0) / 2 = 50%
chroma    = 1 − 0 = 1.000 → saturation 100%`,
      algorithmExplanation: (
        <>
          <p>
            HSL is a different set of coordinates for the same three bytes. Scale each channel to
            0–1, find the largest and the smallest, and the rest follows: lightness is their
            midpoint, chroma is the gap between them, and hue is determined by which channel is
            largest and how the other two sit relative to it.
          </p>
          <h3>Where the hue number comes from</h3>
          <p>
            The wheel is divided into six 60° sectors, one per primary and secondary. If red is the
            largest channel you are in the red sector, and the position within it is set by how far
            green leads or trails blue. For <code>#ff8800</code>: red is the maximum, green is
            0.533, blue is 0, so the hue is (0.533 − 0) / 1 × 60 = 32°. Every hue calculation you
            have seen is this, written more compactly.
          </p>
          <h3>Saturation is relative, which surprises people</h3>
          <p>
            The same chroma produces a different saturation number depending on lightness, because
            the denominator changes: it is <code>chroma / (1 − |2L − 1|)</code>. A very dark or
            very light colour has little room for chroma, so a small absolute gap between channels
            reports as high saturation. That is why <code>#010200</code> comes back as 100%
            saturated — it is almost black, and within what is possible at that lightness it is as
            colourful as it gets.
          </p>
          <h3>HSL lightness is not perceived lightness</h3>
          <p>
            This is the thing worth taking away. <code>hsl(60 100% 50%)</code> is yellow and{" "}
            <code>hsl(240 100% 50%)</code> is blue, and HSL says both are 50% light. One is nearly
            white to the eye and the other nearly black. The formula weights all three channels
            equally, and the eye does not — green contributes about ten times more to perceived
            brightness than blue does.
          </p>
          <p>
            The practical consequence: a tint ramp built by stepping HSL lightness has steps that
            look uneven however even the numbers are, and a palette rotated through HSL hues comes
            out with some colours glaring and others invisible. If the value is feeding a ramp, a
            mix, or any judgement about brightness, use OKLCH — it is in the output below, and
            every current browser accepts it in CSS.
          </p>
        </>
      ),
    }}
    referenceTable={{
      title: "What each component means",
      rows: [
        { parameter: "Hue", type: "0–360deg", defaultVal: "0 = red", description: "Position on the wheel. 120 is green, 240 is blue. Wraps, so 370 and 10 are the same." },
        { parameter: "Saturation", type: "0–100%", defaultVal: "—", description: "Chroma relative to the most this lightness allows. 0% is grey at any hue." },
        { parameter: "Lightness", type: "0–100%", defaultVal: "—", description: "0% is black and 100% is white at every hue. 50% is where a hue is most saturated." },
        { parameter: "Alpha", type: "0–1", defaultVal: "1", description: "Written after a slash in modern syntax: hsl(32 100% 50% / 50%)." },
        { parameter: "hsl() vs hsla()", type: "—", defaultVal: "same", description: "hsl() takes alpha now. hsla() is a legacy alias and is not deprecated." },
        { parameter: "Grey", type: "S = 0", defaultVal: "—", description: "With no saturation the hue is arbitrary and carries no information. Reported as 0 here rather than as noise." },
        { parameter: "Round trip", type: "exact", defaultVal: "—", description: "Hex to HSL and back returns the same colour. The formula is a change of coordinates, not an approximation." },
        { parameter: "OKLCH", type: "alternative", defaultVal: "—", description: "Same idea — a hue angle, a chroma and a lightness — but with a lightness axis that matches what the eye reports." },
      ],
    }}
    faqs={[
      {
        question: "How do I convert hex to HSL by hand?",
        answer:
          "Convert the hex to three 0–255 channels, divide each by 255, then take the largest and smallest. Lightness is (max + min) / 2. Chroma is max − min; if it is zero the colour is grey and you are finished. Otherwise saturation is chroma / (1 − |2L − 1|), and hue comes from which channel was largest: red gives ((G − B) / chroma) × 60, green gives ((B − R) / chroma + 2) × 60, blue gives ((R − G) / chroma + 4) × 60.",
      },
      {
        question: "Why does a nearly black colour show 100% saturation?",
        answer:
          "Because HSL saturation is relative to the maximum chroma available at that lightness, not absolute. At 1% lightness there is almost no room for chroma at all, so a tiny difference between channels is as colourful as that lightness permits — and reports as 100%. It is behaving correctly; it is just measuring something other than what most people expect.",
      },
      {
        question: "Is HSL lightness the same as brightness?",
        answer:
          "No, and this is the trap. HSL weights the three channels equally, while the eye weights green far more than blue. hsl(60 100% 50%) and hsl(240 100% 50%) claim the same lightness; one is a blinding yellow and the other is nearly black. For anything that depends on perceived brightness — a tint scale, a contrast decision, a mix — OKLCH gives the right answer where HSL gives a plausible wrong one.",
      },
      {
        question: "Should I use HSL in CSS?",
        answer:
          "It is fine for what it is good at: nudging a hue, desaturating something, or writing a colour you want to be able to read at a glance. It is the wrong tool for generating a scale or interpolating between two colours, because its lightness axis is not perceptual. Those jobs want oklch(), which every current browser supports.",
      },
      {
        question: "Does converting hex to HSL lose precision?",
        answer:
          "The conversion itself is exact — it is a change of coordinates on the same three bytes. What loses precision is printing: hue rounded to a degree and saturation to a tenth of a percent will not always convert back to the identical hex. The values here are printed at enough precision to round-trip, and if you need a guaranteed exact round trip, keep the hex.",
      },
    ]}
    relatedTools={relatedTools("/hex-to-hsl").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <ColorConvertSurface from="hex" to="hsl" initial="#ff8800" />
  </ToolShell>
);
