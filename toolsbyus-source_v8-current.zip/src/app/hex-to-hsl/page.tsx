import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HexToHslClient } from "./HexToHslClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/hex-to-hsl",
  title: "HEX to HSL Converter — CSS Syntax",
  socialTitle: "HEX to HSL",
  description:
    "Convert a hex colour to hue, saturation and lightness in CSS syntax, with the max, min and chroma the formula runs on shown.",
});

export default function Page() {
  return <HexToHslClient />;
}
