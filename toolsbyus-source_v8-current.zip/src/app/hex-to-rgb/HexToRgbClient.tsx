"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorConvertSurface } from "../../components/tools/ColorConvertSurface";
import { relatedTools } from "../../lib/tools";

export const HexToRgbClient: React.FC = () => (
  <ToolShell
    slug="hex-to-rgb"
    keyword="HEX to RGB Converter"
    directAnswer="HEX to RGB splits a hex colour into its three decimal channels. Each pair of hex digits is one channel written in base 16, so #FF8800 is rgb(255 136 0). A four- or eight-digit hex carries a fourth pair for alpha, which comes out as a 0–1 value in rgba(). The conversion is exact in both directions — no colour is lost, because both notations describe the same three bytes."
    breadcrumbs={[
      { name: "Color Tools", url: "/color-tools" },
      { name: "HEX to RGB", url: "/hex-to-rgb" },
    ]}
    seoDescription="Convert a hex colour to rgb() or rgba(), with the base-16 arithmetic shown a digit at a time. Handles 3, 4, 6 and 8-digit hex, and runs entirely in your browser."
    howItWorks={{
      inputTitle: "A hex colour",
      outputTitle: "Its RGB channels",
      exampleInput: "#ff8800",
      exampleOutput: `rgb(255 136 0)

ff → 255   (15 × 16 + 15)
88 → 136   (8 × 16 + 8)
00 → 0     (0 × 16 + 0)`,
      algorithmExplanation: (
        <>
          <p>
            A hex colour is three bytes written in base 16. Each byte is one channel — red, green,
            blue — and holds a value from 0 to 255, which is exactly two hex digits, because 16²
            is 256. That is the entire conversion: read two characters, interpret them in base 16.
          </p>
          <h3>Reading a hex digit</h3>
          <p>
            The digits run 0–9 then a–f, where <code>a</code> is 10 and <code>f</code> is 15. The
            left digit is the number of sixteens and the right digit is the remainder, so{" "}
            <code>88</code> is 8×16 + 8 = 136 and <code>ff</code> is 15×16 + 15 = 255. Case does
            not matter: <code>#FF8800</code> and <code>#ff8800</code> are the same colour, and CSS
            has never distinguished them.
          </p>
          <h3>Three-digit hex, and why it is not a rounding</h3>
          <p>
            <code>#f80</code> is shorthand for <code>#ff8800</code> — each digit is doubled, not
            padded with a zero. That matters: doubling maps <code>f</code> to <code>ff</code> =
            255, the true maximum, while padding would give <code>f0</code> = 240 and every
            shorthand colour would come out slightly dark. The shorthand can only express the 4,096
            colours whose channel pairs happen to be doubles, which is why it survives for quick
            values like <code>#fff</code> and disappears from anything designed.
          </p>
          <h3>The fourth pair is alpha</h3>
          <p>
            CSS Color 4 added 4- and 8-digit hex, where the last pair is opacity on the same 0–255
            scale. <code>#ff880080</code> is <code>rgb(255 136 0 / 0.5)</code>, because 0x80 is
            128, and 128/255 is 0.502. The slight imprecision is inherent: alpha in CSS is a
            fraction and hex can only store 256 steps of it, so a value written as{" "}
            <code>0.5</code> in <code>rgba()</code> round-trips through hex as <code>0.502</code>.
          </p>
          <h3>Which syntax to write</h3>
          <p>
            Modern CSS separates the channels with spaces and the alpha with a slash —{" "}
            <code>rgb(255 136 0 / 50%)</code> — and <code>rgb()</code> now accepts alpha directly,
            so <code>rgba()</code> is a legacy alias kept for compatibility. The comma form still
            works in every browser and will continue to; there is no deprecation and no reason to
            rewrite a stylesheet over it. Both forms are produced here so you can paste whichever
            your codebase already uses.
          </p>
        </>
      ),
    }}
    referenceTable={{
      title: "Hex forms and what they mean",
      rows: [
        {
          parameter: "#rgb",
          type: "3 digits",
          defaultVal: "shorthand",
          description:
            "Each digit is doubled: #f80 is #ff8800. Only 4,096 colours can be written this way.",
        },
        {
          parameter: "#rgba",
          type: "4 digits",
          defaultVal: "shorthand",
          description: "The same doubling, with a fourth digit for alpha. #f808 is #ff880088.",
        },
        {
          parameter: "#rrggbb",
          type: "6 digits",
          defaultVal: "standard",
          description: "One byte per channel, 0–255 each. 16.7 million colours.",
        },
        {
          parameter: "#rrggbbaa",
          type: "8 digits",
          defaultVal: "CSS Color 4",
          description:
            "Alpha as a fourth byte. Supported everywhere current; falls back to opaque in very old browsers rather than being ignored.",
        },
        {
          parameter: "Case",
          type: "—",
          defaultVal: "ignored",
          description: "#FF8800 and #ff8800 are identical. Lower case is the common convention.",
        },
        {
          parameter: "rgb(r g b)",
          type: "modern",
          defaultVal: "spaces",
          description: "The current syntax. Alpha goes after a slash: rgb(255 136 0 / 50%).",
        },
        {
          parameter: "rgba(r,g,b,a)",
          type: "legacy",
          defaultVal: "commas",
          description:
            "Still valid everywhere and not deprecated. rgb() and rgba() are now the same function.",
        },
        {
          parameter: "Percentages",
          type: "0–100%",
          defaultVal: "allowed",
          description:
            "rgb(100% 53.3% 0%) is the same colour. Percentages resolve against 255, not 100.",
        },
      ],
    }}
    faqs={[
      {
        question: "How do I convert hex to RGB by hand?",
        answer:
          "Split the six digits into three pairs, then read each pair as base 16: the left digit is how many sixteens, the right is the remainder. So 88 is 8×16 + 8 = 136. The letters continue the count — a is 10, b is 11, up to f which is 15 — so ff is 15×16 + 15 = 255. Three pairs, three numbers, and that is the whole conversion.",
      },
      {
        question: "Is #f80 the same as #ff8800?",
        answer:
          "Yes. Three-digit hex doubles each digit rather than padding it with a zero, so #f80 expands to #ff8800. The doubling is what lets #fff mean pure white; if it padded instead, #fff would be #f0f0f0 and every shorthand would be slightly dark.",
      },
      {
        question: "How does alpha work in an 8-digit hex?",
        answer:
          "The last two digits are opacity on the same 0–255 scale as the colour channels, so #ff880080 is 0x80 = 128, which is 128/255 = 0.502 alpha. Because hex only has 256 steps, an alpha written as 0.5 in rgba() comes back as 0.502 through hex. That difference is invisible on screen and will show up if you compare strings.",
      },
      {
        question: "Should I use rgb() or rgba()?",
        answer:
          "rgb() — it takes alpha now, so rgba() is a legacy alias for the same function. Neither is deprecated and both work everywhere, so there is no reason to rewrite existing code. For new code, rgb(255 136 0 / 50%) is the current syntax.",
      },
      {
        question: "Why does my design tool show different RGB numbers for the same hex?",
        answer:
          "Almost always a colour profile. Hex is a value in a colour space, and if the document is tagged Display P3 or Adobe RGB rather than sRGB, the same three bytes describe a different colour and the tool may show you the sRGB equivalent instead of the raw numbers. This page treats hex as sRGB, which is what a browser does with it in CSS.",
      },
    ]}
    relatedTools={relatedTools("/hex-to-rgb").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <ColorConvertSurface from="hex" to="rgb" initial="#ff8800" />
  </ToolShell>
);
