import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HexToRgbClient } from "./HexToRgbClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/hex-to-rgb",
  title: "HEX to RGB Converter — With the Arithmetic Shown",
  socialTitle: "HEX to RGB",
  description:
    "Convert a hex colour to rgb() or rgba(), with the base-16 arithmetic shown a digit at a time. Handles 3, 4, 6 and 8-digit hex, and runs entirely in your browser.",
});

export default function Page() {
  return <HexToRgbClient />;
}
