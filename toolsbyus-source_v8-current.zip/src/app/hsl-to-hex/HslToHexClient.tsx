"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorConvertSurface } from "../../components/tools/ColorConvertSurface";
import { relatedTools } from "../../lib/tools";

export const HslToHexClient: React.FC = () => (
  <ToolShell
    slug="hsl-to-hex"
    keyword="HSL to HEX Converter"
    directAnswer="HSL to HEX turns a hue angle, a saturation and a lightness into a hex colour. Saturation and lightness set how far the colour reaches from grey; the hue angle decides which 60° sector of the wheel it lands in and therefore which channel is largest. The three channels come out as 0–255 values and each becomes two hex digits."
    breadcrumbs={[
      { name: "Color Tools", url: "/color-tools" },
      { name: "HSL to HEX", url: "/hsl-to-hex" },
    ]}
    seoDescription="Convert hue, saturation and lightness to a hex colour, with the sector arithmetic shown. Accepts both CSS syntaxes and runs entirely in your browser."
    howItWorks={{
      inputTitle: "Hue, saturation, lightness",
      outputTitle: "The hex colour",
      exampleInput: "hsl(32 100% 50%)",
      exampleOutput: `#ff8800

chroma      = (1 − |2 × 0.5 − 1|) × 1.00 = 1.000
sector      = 32 / 60 = 0.53   (red → yellow)
channels    = 1.000, 0.533, 0.000
→ 255, 136, 0  →  ff 88 00`,
      algorithmExplanation: (
        <>
          <p>
            The conversion runs in three steps. Chroma — how far the colour is from grey — comes
            from saturation and lightness together: <code>(1 − |2L − 1|) × S</code>. That factor is
            what makes chroma shrink towards both ends, because a colour at 5% or 95% lightness
            has very little room to be colourful.
          </p>
          <h3>The sector decides which channel wins</h3>
          <p>
            Divide the hue by 60 and you land in one of six sectors. Each sector has a fixed
            pattern: one channel at full chroma, one at zero, and one ramping between them
            according to how far through the sector you are. At 32° you are just over halfway from
            red towards yellow, so red is at full chroma, green is at 0.53 of it, and blue is at
            zero — which is the orange at the top of this page.
          </p>
          <h3>Then lightness moves the whole thing</h3>
          <p>
            The three values so far describe the colour at its most saturated. Adding{" "}
            <code>L − chroma / 2</code> to each shifts the set up or down to the lightness you
            asked for, without changing the differences between them — which is what keeps the hue
            constant as lightness changes.
          </p>
          <h3>Why you cannot reach every hex from every HSL</h3>
          <p>
            You can, in fact: HSL and sRGB describe exactly the same set of colours and the mapping
            is a bijection. What you cannot do is get back the same HSL numbers after a round trip,
            because hex has 16.7 million values and HSL as usually written — a whole-number hue and
            a tenth of a percent — has fewer. Two nearby HSL values can round to the same hex, and
            converting that hex back gives whichever of them the formula produces. If exactness
            matters, keep the hex.
          </p>
          <h3>A warning about building scales this way</h3>
          <p>
            A very common pattern is to take a brand colour, convert it to HSL, and generate a
            palette by stepping lightness from 95% down to 10%. It produces even numbers and uneven
            colours: HSL lightness weights all three channels equally, and the eye does not, so the
            yellows in the ramp look far lighter than the blues at the same number. If that is what
            you are here to do, generate the scale in OKLCh instead — it is what the picker on this
            site does, and the steps come out looking as even as they measure.
          </p>
        </>
      ),
    }}
    referenceTable={{
      title: "Inputs this accepts",
      rows: [
        { parameter: "hsl(32 100% 50%)", type: "modern", defaultVal: "spaces", description: "The current CSS syntax. The hue unit is optional; 32 and 32deg are the same." },
        { parameter: "hsl(32, 100%, 50%)", type: "legacy", defaultVal: "commas", description: "Still valid everywhere. Not deprecated, and no reason to rewrite it." },
        { parameter: "hsla(…)", type: "alias", defaultVal: "—", description: "The same function as hsl(), which now takes alpha directly." },
        { parameter: "Hue", type: "any number", defaultVal: "wraps", description: "370 is 10, and −30 is 330. The angle is modular, so out-of-range values are valid rather than errors." },
        { parameter: "Saturation 0%", type: "—", defaultVal: "grey", description: "Produces a grey at the given lightness, whatever the hue is set to." },
        { parameter: "Lightness 0% / 100%", type: "—", defaultVal: "black / white", description: "Both collapse every hue and saturation to the same colour." },
        { parameter: "Alpha", type: "0–1 or %", defaultVal: "1", description: "Appended as a fourth hex pair. 0.5 becomes 80." },
        { parameter: "Out of range", type: "—", defaultVal: "clamped", description: "Saturation and lightness are clamped to 0–100 rather than rejected, as CSS does." },
      ],
    }}
    faqs={[
      {
        question: "How do I convert HSL to hex by hand?",
        answer:
          "Compute chroma as (1 − |2L − 1|) × S with L and S as fractions. Divide the hue by 60 to find the sector, and compute the middle channel as chroma × (1 − |(hue/60 mod 2) − 1|). Assign chroma, that middle value and zero to red, green and blue according to the sector, add L − chroma/2 to all three, multiply by 255, and write each as two hex digits.",
      },
      {
        question: "Does hsl(32 100% 50%) always give the same hex?",
        answer:
          "Yes. The conversion is deterministic and the same in every browser and tool; hsl(32 100% 50%) is #ff8800 everywhere. What is not guaranteed is the return journey — converting #ff8800 back may give a hue of 31.9 depending on how the tool rounds, because hex holds more distinct values than a whole-number hue does.",
      },
      {
        question: "Why does changing lightness in HSL also seem to change the hue?",
        answer:
          "It does not change the hue number, but it changes what you see, because HSL's lightness axis is not perceptual. Moving from 50% to 70% lightness on a blue looks like a much smaller change than the same move on a yellow, so a set of colours that share a lightness number do not look like they share a lightness. Working in OKLCh removes the effect entirely.",
      },
      {
        question: "What is a good way to build a colour scale from one HSL value?",
        answer:
          "Not by stepping HSL lightness, which is the usual advice and produces visibly uneven steps. Convert to OKLCh, step its lightness on a curve, hold hue, and taper chroma at both ends so the light steps are not fluorescent and the dark ones do not glow. The colour picker on this site does exactly that and will hand you the eleven values and the CSS variables.",
      },
      {
        question: "Can I write a hue above 360 or below 0?",
        answer:
          "Yes, and CSS accepts it. The hue angle is modular, so 370deg is 10deg and −30deg is 330deg. It is genuinely useful in an animation or a generated palette where an angle is being incremented and you would rather not write the wrap-around yourself.",
      },
    ]}
    relatedTools={relatedTools("/hsl-to-hex").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <ColorConvertSurface from="hsl" to="hex" initial="hsl(32 100% 50%)" />
  </ToolShell>
);
