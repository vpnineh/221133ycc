import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HslToHexClient } from "./HslToHexClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/hsl-to-hex",
  title: "HSL to HEX Converter — CSS Syntax",
  socialTitle: "HSL to HEX",
  description:
    "Convert hue, saturation and lightness to a hex colour, with the sector arithmetic shown. Accepts both CSS syntaxes.",
});

export default function Page() {
  return <HslToHexClient />;
}
