"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatHtml, minifyHtml, analyseHtml, HTML_DEFAULTS } from "../../lib/format/html";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Order</title>
<style>.total{font-weight:600}</style></head>
<body><main class="order" data-id="1041" data-currency="GBP" aria-label="Order detail">
<h1>Order <b>1041</b> <i>(pending)</i></h1>
<!-- a single <img> with no alt is reported below -->
<img src="/logo.png" width="120"><hr>
<ul><li>Widget<li>Bracket</ul>
<pre>  indented
    exactly as written  </pre>
<script>if (a < b && c > d) { console.log("not markup"); }</script>
</main></body></html>`;

export const HtmlFormatterClient: React.FC = () => {
  const [mode, setMode] = useState<"format" | "minify">("format");
  const [indent, setIndent] = useState(2);
  const [attributeWrapCount, setAttributeWrapCount] = useState(4);
  const [preserveRawText, setPreserveRawText] = useState(true);
  const [keepComments, setKeepComments] = useState(true);

  const transform = (input: string): TransformOutcome => {
    if (!input.trim()) return { output: "" };
    const stats = analyseHtml(input);

    const output =
      mode === "minify"
        ? minifyHtml(input, keepComments)
        : formatHtml(input, {
            ...HTML_DEFAULTS,
            indent,
            attributeWrapCount,
            preserveRawText,
            keepComments,
          });

    const warnings: string[] = [];
    if (stats.missingAlt > 0) {
      warnings.push(
        `${stats.missingAlt} <img> element${stats.missingAlt === 1 ? " has" : "s have"} no alt attribute. A screen reader announces the filename instead, which is worse than silence — use alt="" for a decorative image.`
      );
    }
    if (stats.unclosed.length > 0) {
      warnings.push(
        `Unclosed element${stats.unclosed.length === 1 ? "" : "s"}: ${[...new Set(stats.unclosed)].join(", ")}. The browser will recover, but where it closes them is its choice rather than yours.`
      );
    }

    return {
      output,
      warnings,
      stats: [
        { label: "Elements", value: String(stats.elements) },
        { label: "Inline styles", value: String(stats.inlineStyles) },
        {
          label: mode === "minify" ? "Saved" : "Lines",
          value:
            mode === "minify"
              ? `${Math.round((1 - output.length / Math.max(input.length, 1)) * 100)}%`
              : String(output.split("\n").length),
        },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="html-formatter"
      keyword="HTML Formatter and Minifier"
      directAnswer="HTML Formatter re-indents and minifies markup in your browser. HTML is not XML, and formatting it as if it were corrupts documents in four specific ways — void elements, raw-text elements, optional closing tags and significant whitespace between inline elements — each of which this handles explicitly."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "HTML Formatter", url: "/html-formatter" },
      ]}
      seoDescription="Format and minify HTML in the browser. Handles void elements, script and pre content, omitted closing tags and inline whitespace correctly, and reports missing alt attributes."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Most HTML formatters are XML formatters with a different name, and each of the four
              differences between the two has produced a real bug.
            </p>
            <h3>Void elements do not open a scope</h3>
            <p>
              <code>&lt;br&gt;</code>, <code>&lt;img&gt;</code>, <code>&lt;input&gt;</code>,{" "}
              <code>&lt;hr&gt;</code> and ten others have no closing tag — not optionally, at all. A
              formatter that increases indentation on every opening tag pushes everything after the
              first <code>&lt;img&gt;</code> one level right and never recovers, so a page with
              twenty images ends up indented off the screen.
            </p>
            <h3>Script and style contain text, not markup</h3>
            <p>
              A <code>&lt;</code> inside a <code>&lt;script&gt;</code> is a less-than sign. Parsing
              it as a tag is how <code>if (a &lt; b)</code> becomes a mangled document, and it is why
              the sample above contains exactly that expression. The content of{" "}
              <code>&lt;script&gt;</code>, <code>&lt;style&gt;</code>,{" "}
              <code>&lt;textarea&gt;</code> and <code>&lt;title&gt;</code> is consumed whole, up to
              the matching close tag.
            </p>
            <h3>Whitespace between inline elements is rendered</h3>
            <p>
              <code>&lt;b&gt;a&lt;/b&gt; &lt;i&gt;b&lt;/i&gt;</code> renders as &ldquo;a b&rdquo;;
              without the space it renders as &ldquo;ab&rdquo;. A formatter that puts every element
              on its own line has inserted a space into every text flow in the document — the
              classic symptom is a stray gap before every full stop and after every link. Inline
              elements are therefore kept in a buffered run and only block elements start lines. The
              same rule is why <code>&lt;pre&gt;</code> content is never re-indented: there, the
              whitespace <em>is</em> the layout.
            </p>
            <h3>Closing tags are optional for several elements</h3>
            <p>
              <code>&lt;/li&gt;</code>, <code>&lt;/p&gt;</code>, <code>&lt;/td&gt;</code> and
              friends may be omitted, and plenty of hand-written HTML omits them. A formatter with a
              strict tag stack either rejects the document or unbalances its indentation. Here the
              stack unwinds through elements whose close is optional when it meets a close tag that
              does not match the top.
            </p>
            <h3>What the analysis reports</h3>
            <p>
              An <code>&lt;img&gt;</code> with no <code>alt</code> attribute is flagged, because a
              screen reader falls back to announcing the filename — which is worse than silence, and
              is why a decorative image needs <code>alt=&quot;&quot;</code> rather than no attribute
              at all. Unclosed elements are named: the browser will recover, but where it decides to
              close them is its choice rather than yours, and the two often differ.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `<div><br><p>text</p></div>`,
        outputTitle: "Formatted",
        exampleOutput: `<div>
  <br>
  <p>
    text
  </p>
</div>`,
      }}
      referenceTable={{
        title: "Options and HTML-specific handling",
        rows: [
          {
            parameter: "Indent",
            type: "spaces",
            defaultVal: "2",
            description: "Per nesting level. Void elements do not add a level.",
          },
          {
            parameter: "Attribute wrap",
            type: "count",
            defaultVal: "4",
            description:
              "Tags with at least this many attributes, or longer than 100 characters, put each attribute on its own line.",
          },
          {
            parameter: "Preserve raw text",
            type: "boolean",
            defaultVal: "on",
            description:
              "pre and textarea content is never touched, because its whitespace is rendered. script and style bodies are re-indented, which is safe.",
          },
          {
            parameter: "Void elements",
            type: "14 elements",
            defaultVal: "—",
            description:
              "area base br col embed hr img input link meta param source track wbr. None of them opens a scope.",
          },
          {
            parameter: "Raw-text elements",
            type: "script, style, textarea, title, pre",
            defaultVal: "—",
            description:
              "Content is text rather than markup. A < inside a script is a less-than sign, and parsing it as a tag corrupts the document.",
          },
          {
            parameter: "Inline elements",
            type: "kept in the flow",
            defaultVal: "—",
            description:
              "a, b, span, em, img and the rest stay on the line they were on, because a line break between them renders as a space.",
          },
          {
            parameter: "Optional close",
            type: "tolerated",
            defaultVal: "—",
            description:
              "li, p, td, tr, option and others may omit their closing tag. The stack unwinds rather than rejecting the document.",
          },
          {
            parameter: "Attribute quotes",
            type: "normalised",
            defaultVal: "double",
            description:
              "Unless the value contains a double quote, in which case single quotes are used. Boolean attributes keep their bare form.",
          },
          {
            parameter: "Minify",
            type: "whitespace",
            defaultVal: "—",
            description:
              "Collapses runs of whitespace but keeps a single space where inline elements meet, and preserves pre content. Conditional comments survive because they are markup to old IE.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why is my inline element not on its own line?",
          answer:
            "Because putting it there would change what the page renders. <b>a</b> <i>b</i> shows \"a b\"; without the space between the tags it shows \"ab\". A formatter that breaks every element onto its own line inserts a space into every text flow in the document, and the symptom is a stray gap before every full stop. Inline elements stay in the run they were in.",
        },
        {
          question: "Why was the content of my <pre> left alone?",
          answer:
            "Because in a <pre> the whitespace is the content. Re-indenting it changes what the reader sees, which is the opposite of formatting. The same applies to <textarea>, where the whitespace is the field's value. Script and style bodies are re-indented, because their whitespace is not rendered.",
        },
        {
          question: "My HTML has no closing </li> tags. Is that broken?",
          answer:
            "No — HTML allows omitting the closing tag for li, p, td, tr, option, thead and several others, and a lot of hand-written markup does. The formatter unwinds its stack when it meets a close tag that does not match the top, so the document formats correctly. Whether you should omit them is a style question; whether the parser copes is not.",
        },
        {
          question: "Why does it warn about a missing alt attribute?",
          answer:
            "Because an <img> with no alt makes a screen reader announce the filename — \"i-m-g underscore 4 0 2 1 dot p-n-g\" — which is worse than saying nothing. The fix for a decorative image is alt=\"\", which explicitly tells assistive technology to skip it. An absent attribute and an empty one mean different things, and only one of them is correct for decoration.",
        },
        {
          question: "Should I minify HTML?",
          answer:
            "Only as part of a build, and the win is smaller than you would guess once gzip or brotli is in play — compression already handles repeated whitespace very well. What minification is genuinely good for is email templates, where some clients reject large messages, and inline critical CSS, where the bytes are in the critical path.",
        },
        {
          question: "Is my markup uploaded?",
          answer:
            "No. Tokenising and formatting run in your browser, which you can confirm in the Network panel. Markup from a real application frequently carries data attributes, internal URLs and inline JSON with real content in it.",
        },
      ]}
      relatedTools={relatedTools("/html-formatter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="HTML"
        outputLabel={mode === "minify" ? "Minified" : "Formatted"}
        inputPlaceholder="Paste markup…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName={mode === "minify" ? "page.min.html" : "page.html"}
        height={400}
        options={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className={segmentTrack} role="group" aria-label="Mode">
              {(["format", "minify"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  aria-pressed={mode === value}
                  className={segment(mode === value)}
                >
                  {value === "format" ? "Format" : "Minify"}
                </button>
              ))}
            </div>

            {mode === "format" && (
              <>
                <div className="flex items-center gap-2">
                  <span className={fieldLabel}>Indent</span>
                  <div className={segmentTrack} role="group" aria-label="Indent">
                    {[2, 4].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setIndent(value)}
                        aria-pressed={indent === value}
                        className={segment(indent === value)}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={fieldLabel}>Wrap at</span>
                  <div className={segmentTrack} role="group" aria-label="Attribute wrap count">
                    {[3, 4, 6, 99].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setAttributeWrapCount(value)}
                        aria-pressed={attributeWrapCount === value}
                        className={segment(attributeWrapCount === value)}
                      >
                        {value === 99 ? "never" : `${value} attrs`}
                      </button>
                    ))}
                  </div>
                </div>

                <label
                  htmlFor="html-raw"
                  className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
                >
                  <input
                    id="html-raw"
                    type="checkbox"
                    checked={preserveRawText}
                    onChange={(e) => setPreserveRawText(e.target.checked)}
                    className={checkbox}
                  />
                  <span className={fieldLabel}>Preserve pre</span>
                </label>
              </>
            )}

            <label
              htmlFor="html-comments"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="html-comments"
                type="checkbox"
                checked={keepComments}
                onChange={(e) => setKeepComments(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>Keep comments</span>
            </label>
          </div>
        }
      />
    </ToolShell>
  );
};
