import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { HtmlFormatterClient } from "./HtmlFormatterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/html-formatter",
  title: "HTML Formatter — Indent, Minify and Inspect",
  socialTitle: "HTML Formatter",
  description:
    "Format and minify HTML in your browser, handling void elements, raw text, optional closing tags and significant inline whitespace correctly.",
});

export default function HtmlFormatterPage() {
  return <HtmlFormatterClient />;
}
