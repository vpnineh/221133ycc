"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatBytes, type AcceptedFile } from "../../lib/files";
import { relatedTools } from "../../lib/tools";

type Flavour = "uri" | "css" | "html" | "raw" | "json" | "markdown";

const FLAVOUR_LABEL: Record<Flavour, string> = {
  uri: "Data URI",
  css: "CSS",
  html: "HTML",
  raw: "Base64 only",
  json: "JSON",
  markdown: "Markdown",
};

/**
 * Above this, inlining is usually a mistake and the page says so.
 *
 * Not an arbitrary round number: a data URI cannot be cached separately, cannot
 * be loaded in parallel, and blocks the stylesheet or document it sits in from
 * finishing. Below a couple of kilobytes that costs less than a request would;
 * above about 10 KB it reliably costs more.
 */
const INLINE_WARNING_BYTES = 10 * 1024;

export const ImageToBase64Client: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [flavour, setFlavour] = useState<Flavour>("uri");
  const [base64, setBase64] = useState("");
  const [mime, setMime] = useState("image/png");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const urlRef = useRef<string | null>(null);

  const release = useCallback(() => {
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    }
  }, []);

  useEffect(() => release, [release]);

  const load = async (next: AcceptedFile[]) => {
    release();
    setPreviewUrl(null);
    setBase64("");
    setError(null);
    setFiles(next);

    const file = next[0]?.file;
    if (!file) return;

    try {
      setMime(file.type || guessMime(file.name));
      setBase64(await toBase64(file));
      const url = URL.createObjectURL(file);
      urlRef.current = url;
      setPreviewUrl(url);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : String(caught));
    }
  };

  const file = files[0]?.file;
  const dataUri = base64 ? `data:${mime};base64,${base64}` : "";
  const name = file?.name ?? "image";
  const output = base64 ? render(flavour, dataUri, base64, name) : "";
  const encodedBytes = new Blob([dataUri]).size;
  const overhead = file && file.size > 0 ? Math.round((encodedBytes / file.size - 1) * 100) : 0;

  return (
    <ToolShell
      wide
      slug="image-to-base64"
      keyword="Image to Base64"
      directAnswer="Image to Base64 turns an image file into a data URI you can paste directly into CSS, HTML, JSON or Markdown, with no separate file and no HTTP request. Encoding happens in your browser. The output is about 33% larger than the file, which the page shows you, because that cost is the whole reason to think before inlining."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "Image to Base64", url: "/image-to-base64" },
      ]}
      seoDescription="Convert an image to a base64 data URI in the browser, with ready-made CSS, HTML, JSON and Markdown snippets and an honest note on the size cost."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A data URI is a file inlined into the place that references it. Instead of{" "}
              <code>src=&quot;logo.png&quot;</code> pointing at something the browser must fetch, the
              bytes of the image are written into the attribute itself. No request, no second file,
              nothing that can 404.
            </p>

            <h3>Why base64 rather than the raw bytes</h3>
            <p>
              Because the places these strings go — a CSS file, an HTML attribute, a JSON value —
              are text, and a PNG is not. Its bytes include quotes, newlines, null bytes and
              everything else that would terminate a string or corrupt a document. Base64, defined
              in RFC 4648, maps every three bytes onto four characters drawn from a 64-symbol
              alphabet that is safe everywhere, padding with <code>=</code> when the input does not
              divide evenly.
            </p>
            <p>
              Four characters for every three bytes is where the 33% comes from. It is not overhead
              that a better encoder could remove; it is arithmetic.
            </p>

            <h3>When inlining is worth it</h3>
            <p>
              For small assets used immediately: an icon in a CSS rule, a 1 × 1 spacer, a logo in an
              HTML email where external images are blocked by default, a placeholder that must
              render before anything else loads. In all of these the request you save costs more
              than the 33% you spend — a request has DNS, connection setup and round-trip latency
              attached, and on a mobile connection that is tens of milliseconds for a file that
              would have transferred in one packet.
            </p>

            <h3>When it is a mistake</h3>
            <p>
              For anything large or reused. A data URI cannot be cached independently: inline a
              200 KB hero image in your stylesheet and every visitor downloads it again with every
              change to any rule in that file. It cannot be fetched in parallel either — it is part
              of the document, so it is downloaded before the document finishes, blocking the render
              it was supposed to speed up. And it cannot be lazy-loaded, resized by a CDN, or served
              as WebP to browsers that support it.
            </p>
            <p>
              The rough line is a couple of kilobytes. Under that, inlining usually wins; over about
              10 KB it usually loses, and this page says so when you cross it.
            </p>

            <h3>Content Security Policy</h3>
            <p>
              A strict CSP blocks data URIs unless you allow them. Images need{" "}
              <code>img-src &apos;self&apos; data:</code>; a font inlined the same way needs{" "}
              <code>font-src</code> to allow <code>data:</code> too. This is worth knowing before
              you inline something and find it missing only in production, where the CSP is
              enforced.
            </p>

            <h3>Base64 is not encryption</h3>
            <p>
              It is worth saying plainly, because the confusion is common: base64 is an encoding,
              reversible by anyone, with no key involved. Anything inlined this way is as readable
              as it was before. It hides nothing.
            </p>

            <h3>Where this runs</h3>
            <p>
              In your browser. The file is read with a <code>FileReader</code> and encoded locally —
              nothing is uploaded, which for an image you are about to embed in your own source code
              is the only sensible arrangement.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `icon.png — 1.2 KB
image/png`,
        outputTitle: "Output",
        exampleOutput: `data:image/png;base64,iVBORw0KGgo…
1.6 KB (+33%)
no HTTP request`,
      }}
      referenceTable={{
        title: "Output formats",
        rows: [
          {
            parameter: "Data URI",
            type: "data:…",
            defaultVal: "default",
            description: "The bare URI. Paste anywhere a URL is expected.",
          },
          {
            parameter: "CSS",
            type: "background-image",
            defaultVal: "—",
            description: "A rule ready to drop into a stylesheet.",
          },
          {
            parameter: "HTML",
            type: "<img>",
            defaultVal: "—",
            description: "An img element with the alt attribute left for you to fill in.",
          },
          {
            parameter: "JSON",
            type: "string",
            defaultVal: "—",
            description: "Properly quoted, for an API payload or a fixture file.",
          },
          {
            parameter: "Markdown",
            type: "![]()",
            defaultVal: "—",
            description: "Image syntax, for a README that must be self-contained.",
          },
          {
            parameter: "Base64 only",
            type: "no prefix",
            defaultVal: "—",
            description: "The encoded bytes alone, for a field that adds its own MIME type.",
          },
          {
            parameter: "Size cost",
            type: "+33%",
            defaultVal: "—",
            description: "Four output characters per three input bytes. Arithmetic, not overhead.",
          },
          {
            parameter: "CSP",
            type: "img-src data:",
            defaultVal: "—",
            description: "A strict policy blocks data URIs until this is allowed.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why is the base64 bigger than the image?",
          answer:
            "Because base64 represents three bytes with four characters, which is a 33% increase by construction. The alphabet has 64 symbols, so each character carries six bits; three bytes are twenty-four bits, which is exactly four characters. No encoder can do better while staying inside a text-safe alphabet. If size matters, compress the image before encoding it — that is where the savings are.",
        },
        {
          question: "Should I inline images as data URIs?",
          answer:
            "Small ones, yes: icons, spacers, a logo in an HTML email, anything under a couple of kilobytes that is needed immediately. The saved request usually costs more than the 33% you spend. Large ones, no: a data URI cannot be cached separately, cannot be downloaded in parallel, and blocks the document or stylesheet it sits in — so a 200 KB inlined hero image is re-downloaded on every change to the file containing it, and delays the render it was meant to accelerate.",
        },
        {
          question: "Does base64 encryption protect the image?",
          answer:
            "Base64 is not encryption. It is a reversible text encoding with no key, designed to move binary data through channels that only accept text. Anyone can decode it in a browser console in one line. It offers no confidentiality whatsoever, and treating it as though it did is a recurring source of real security incidents.",
        },
        {
          question: "Why is my data URI blocked by Content Security Policy?",
          answer:
            "Because a strict CSP treats data: as a source that must be allowed explicitly. For images you need img-src to include data:; for an inlined font, font-src needs it too. The failure is easy to miss in development, where CSP is often not enforced, and appears only in production — so check the policy before committing to inlining.",
        },
        {
          question: "Can I decode a data URI back to a file?",
          answer:
            "Yes. Everything after the comma is base64; decode it and you have the original bytes, byte for byte — the encoding is lossless in both directions. The Base64 Encode / Decode tool on this site handles the text side of that, and any browser will render a data URI pasted straight into the address bar.",
        },
        {
          question: "Is the image uploaded to encode it?",
          answer:
            "No. The file is read by your browser's FileReader and encoded in this tab; nothing is transmitted. That matters here in a small way that is easy to overlook — the images people base64-encode are usually assets from a project they are working on, and there is no reason for those to travel anywhere.",
        },
      ]}
      relatedTools={relatedTools("/image-to-base64").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={["image/*", ".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif", ".svg", ".ico"]}
          files={files}
          onChange={(next) => void load(next)}
          label="Drop an image here"
        />

        {error && <Notice tone="danger">{error}</Notice>}

        {base64 && file && (
          <>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border bg-surface px-3 py-2">
              {previewUrl && (
                /* A blob URL for a local file; next/image cannot take one. */
                /* eslint-disable-next-line @next/next/no-img-element */
                <img
                  src={previewUrl}
                  alt=""
                  className="h-10 w-10 rounded border border-border bg-checkerboard object-contain"
                />
              )}
              <span className="font-mono text-2xs text-foreground-subtle">
                {mime} · {formatBytes(file.size)} → {formatBytes(encodedBytes)}{" "}
                <span className="text-mod">(+{overhead}%)</span>
              </span>

              <div className={`${segmentTrack} ml-auto`} role="group" aria-label="Output format">
                {(Object.keys(FLAVOUR_LABEL) as Flavour[]).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setFlavour(value)}
                    aria-pressed={flavour === value}
                    className={segment(flavour === value)}
                  >
                    {FLAVOUR_LABEL[value]}
                  </button>
                ))}
              </div>
            </div>

            {file.size > INLINE_WARNING_BYTES && (
              <Notice tone="warn">
                {formatBytes(file.size)} is large for an inlined asset. A data URI cannot be cached
                separately from the file containing it, cannot be downloaded in parallel, and blocks
                that file from finishing — so this one would be re-fetched on every change to your
                stylesheet and would delay the render rather than speeding it up. Under a couple of
                kilobytes, inlining wins; at this size a normal <code>&lt;img&gt;</code> almost
                always beats it. Compressing the image first is the other option.
              </Notice>
            )}

            <CodePane
              label={FLAVOUR_LABEL[flavour]}
              value={output}
              onChange={() => undefined}
              readOnly
              height={220}
            />
          </>
        )}

        {!base64 && (
          <p className={`${fieldLabel} text-center`}>
            Drop a PNG, JPG, SVG or icon to get a data URI and ready-made snippets.
          </p>
        )}
      </div>
    </ToolShell>
  );
};

/**
 * Reads a file as base64.
 *
 * `FileReader.readAsDataURL` rather than a manual `btoa` over the bytes:
 * `btoa` works on a binary string, so a large image has to be turned into a
 * multi-megabyte JavaScript string one character at a time first, and
 * `String.fromCharCode(...bytes)` on a spread array blows the call stack
 * somewhere around a hundred thousand arguments. The browser's own reader does
 * it natively and correctly.
 */
async function toBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== "string") {
        reject(new Error("The file could not be read as a data URI."));
        return;
      }
      const comma = result.indexOf(",");
      resolve(comma === -1 ? "" : result.slice(comma + 1));
    };
    reader.onerror = () =>
      reject(new Error(`${file.name} could not be read. The browser reported an I/O error.`));
    reader.readAsDataURL(file);
  });
}

function guessMime(name: string): string {
  const lower = name.toLowerCase();
  if (lower.endsWith(".svg")) return "image/svg+xml";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".avif")) return "image/avif";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".ico")) return "image/x-icon";
  return "image/png";
}

/** Wraps the data URI in whichever syntax the user picked. */
export function render(flavour: Flavour, dataUri: string, raw: string, name: string): string {
  switch (flavour) {
    case "raw":
      return raw;
    case "css":
      return `.icon {\n  background-image: url("${dataUri}");\n  background-repeat: no-repeat;\n  background-size: contain;\n}`;
    case "html":
      return `<img src="${dataUri}" alt="" width="" height="" />`;
    case "json":
      return JSON.stringify({ name, dataUri }, null, 2);
    case "markdown":
      return `![${name}](${dataUri})`;
    default:
      return dataUri;
  }
}
