import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ImageToBase64Client } from "./ImageToBase64Client";

export const metadata: Metadata = buildToolMetadata({
  path: "/image-to-base64",
  title: "Image to Base64 — Data URI, CSS and HTML",
  socialTitle: "Image to Base64",
  description:
    "Turn an image into a base64 data URI in your browser, with CSS, HTML, JSON and Markdown snippets — and the 33% size cost stated plainly.",
});

export default function ImageToBase64Page() {
  return <ImageToBase64Client />;
}
