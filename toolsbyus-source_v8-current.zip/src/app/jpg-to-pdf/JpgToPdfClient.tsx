"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { FileResult } from "../../components/tools/FileResult";
import { usePdfWorker } from "../../components/tools/usePdfWorker";
import { Notice } from "../../components/common/Notice";
import { btnPrimary, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatBytes, type AcceptedFile } from "../../lib/files";
import { stemOf, withStem } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

const PAGE_SIZES = [
  { id: "a4", label: "A4" },
  { id: "letter", label: "Letter" },
  { id: "legal", label: "Legal" },
  { id: "a3", label: "A3" },
  { id: "a5", label: "A5" },
];

/**
 * Re-encodes anything pdf-lib cannot embed directly.
 *
 * A PDF can carry JPEG and PNG image data verbatim — the bytes go into the file
 * untouched, which is both lossless and instant. WebP, AVIF and HEIC cannot,
 * so they are decoded and re-encoded as JPEG, which does cost a generation of
 * quality. Saying so is better than silently producing a slightly worse image.
 */
async function toEmbeddable(file: File): Promise<{ bytes: ArrayBuffer; type: string; converted: boolean }> {
  if (/^image\/(jpeg|png)$/i.test(file.type) || /\.(jpe?g|png)$/i.test(file.name)) {
    return { bytes: await file.arrayBuffer(), type: file.type || "image/jpeg", converted: false };
  }

  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser did not provide a 2D canvas context.");
  // White behind the image: a transparent WebP encoded as JPEG would otherwise
  // come out with black where the transparency was.
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(bitmap, 0, 0);
  bitmap.close();

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", 0.92)
  );
  canvas.width = 0;
  canvas.height = 0;
  if (!blob) throw new Error(`${file.name} could not be converted to a format a PDF can embed.`);

  return { bytes: await blob.arrayBuffer(), type: "image/jpeg", converted: true };
}

export const JpgToPdfClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [pageSize, setPageSize] = useState("a4");
  const [fit, setFit] = useState<"page" | "image">("page");
  const [margin, setMargin] = useState(36);
  const [converted, setConverted] = useState<string[]>([]);
  const [outputName, setOutputName] = useState("");
  const { state, run, reset } = usePdfWorker();

  const defaultStem = files[0] ? stemOf(files[0].file.name) : "images";

  const build = async () => {
    setConverted([]);
    const prepared: Array<{ bytes: ArrayBuffer; type: string; name: string }> = [];
    const reEncoded: string[] = [];

    for (const entry of files) {
      const result = await toEmbeddable(entry.file);
      if (result.converted) reEncoded.push(entry.file.name);
      prepared.push({ bytes: result.bytes, type: result.type, name: entry.file.name });
    }

    setConverted(reEncoded);
    run(
      {
        type: "imagesToPdf",
        images: prepared,
        pageSize,
        margin,
        fit,
        name: withStem(outputName.trim() || defaultStem, "pdf"),
      },
      prepared.map((image) => image.bytes)
    );
  };

  const totalBytes = files.reduce((sum, entry) => sum + entry.file.size, 0);

  return (
    <ToolShell
      slug="jpg-to-pdf"
      keyword="JPG to PDF"
      directAnswer="JPG to PDF turns images into a PDF in your browser, one page each. JPEG and PNG data is embedded into the file byte for byte rather than re-encoded, so the images in the PDF are pixel-identical to the ones you started with — which is not true of tools that render each image to a canvas first."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "JPG to PDF", url: "/jpg-to-pdf" },
      ]}
      seoDescription="Convert JPG, PNG and WebP images to a PDF in your browser. Images are embedded losslessly, with page size, margin and fit options. Drag to reorder, nothing uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A PDF can carry JPEG and PNG data directly. The image bytes are written into the file
              unchanged and the page simply references them — which means the picture in the PDF is
              the picture you started with, not a re-compressed approximation of it.
            </p>
            <h3>Embedding versus re-encoding</h3>
            <p>
              The lazy implementation draws each image onto a canvas and encodes the canvas as a new
              JPEG. That works, and it costs a generation: JPEG is lossy, so decoding and
              re-encoding introduces artefacts even at high quality, and a photograph that has been
              through that twice starts to show it around edges and text.
            </p>
            <p>
              Here JPEG and PNG go in as-is. WebP, AVIF and HEIC cannot — the PDF format has no
              filter for them — so those are decoded and re-encoded as JPEG, and the tool tells you
              which files that happened to rather than leaving you to notice.
            </p>
            <h3>Fit to page, or page to image</h3>
            <p>
              <strong>Fit to page</strong> puts each image on a standard page — A4, Letter, whatever
              you choose — scaled to fit inside the margins and centred. It <em>contains</em> rather
              than covers: the whole image is visible and there are bands of white where the aspect
              ratios differ. Cropping someone&apos;s photograph to fill a page is a decision they did
              not ask for.
            </p>
            <p>
              <strong>Page per image</strong> makes each page exactly the size of its image, with no
              margins. This is the right answer for scanned documents, screenshots and anything
              where white bands would look like a mistake — and it produces a document whose pages
              are different sizes, which is perfectly legal and occasionally surprising.
            </p>
            <h3>Margins are in points</h3>
            <p>
              PDF measures in points: 72 to the inch. The default 36 points is half an inch, which
              is a conventional document margin. Zero is fine for a photo book.
            </p>
            <h3>Order is the order you set</h3>
            <p>
              Images become pages top to bottom, and the arrows reorder them. This matters more here
              than almost anywhere, because a file picker returns files in the operating
              system&apos;s order — which is alphabetical, so <code>IMG_10</code> lands before{" "}
              <code>IMG_2</code>.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `scan-1.jpg  (2480 × 3508)
scan-2.jpg  (2480 × 3508)
fit: page (A4), margin 36 pt`,
        outputTitle: "Output",
        exampleOutput: `images.pdf — 2 pages
JPEG data embedded byte for byte,
scaled to contain, centred`,
      }}
      referenceTable={{
        title: "Options and image handling",
        rows: [
          {
            parameter: "JPEG",
            type: "embedded",
            defaultVal: "lossless",
            description:
              "The image bytes go into the PDF unchanged. No re-encoding, so no second generation of JPEG artefacts.",
          },
          {
            parameter: "PNG",
            type: "embedded",
            defaultVal: "lossless",
            description: "Also carried verbatim, including transparency where the page shows through.",
          },
          {
            parameter: "WebP, AVIF, HEIC",
            type: "re-encoded",
            defaultVal: "to JPEG at 0.92",
            description:
              "A PDF has no filter for these. They are decoded and re-encoded, which costs a generation of quality — and the tool names the files it happened to.",
          },
          {
            parameter: "Fit to page",
            type: "mode",
            defaultVal: "default",
            description:
              "Scaled to fit inside the margins and centred on a standard page. Contains rather than covers, so nothing is cropped.",
          },
          {
            parameter: "Page per image",
            type: "mode",
            defaultVal: "—",
            description:
              "Each page exactly the size of its image, no margins. Right for scans and screenshots; produces pages of differing sizes.",
          },
          {
            parameter: "Page size",
            type: "A4 / Letter / Legal / A3 / A5",
            defaultVal: "A4",
            description: "Only applies in fit-to-page mode.",
          },
          {
            parameter: "Margin",
            type: "points",
            defaultVal: "36",
            description: "72 points to the inch, so 36 is half an inch. Zero for edge-to-edge.",
          },
          {
            parameter: "Order",
            type: "list order",
            defaultVal: "as dropped",
            description:
              "Reorderable with the arrows. A file picker sorts alphabetically, which puts IMG_10 before IMG_2.",
          },
          {
            parameter: "Transparency",
            type: "white behind",
            defaultVal: "when re-encoding",
            description:
              "A transparent WebP encoded as JPEG would come out black where the transparency was, so white is painted first.",
          },
        ],
      }}
      faqs={[
        {
          question: "Does converting to PDF reduce my image quality?",
          answer:
            "Not for JPEG or PNG — their data is written into the PDF byte for byte, so the image in the document is pixel-identical to the one you started with. WebP, AVIF and HEIC have no PDF equivalent and are re-encoded as JPEG, which does cost one generation; the tool lists which files that applied to rather than leaving you to spot it later.",
        },
        {
          question: "Why are there white bands around my photos?",
          answer:
            "Because fit-to-page contains the image rather than cropping it: the whole picture is visible, and where its aspect ratio differs from the page there is white. The alternative — filling the page — means cutting off the edges of someone's photograph, which is not a decision a converter should make quietly. Switch to page-per-image if you want no bands and no crop.",
        },
        {
          question: "Why is my PDF so much larger than the images?",
          answer:
            "It should not be by much — the image data is the same bytes plus a small amount of PDF structure. If it is dramatically larger, check whether your images are WebP or HEIC: those get re-encoded as JPEG at quality 0.92, which for a heavily compressed source can be bigger than the original. Converting them to JPEG yourself first, at whatever quality you want, gives you control over that trade.",
        },
        {
          question: "Can I put several images on one page?",
          answer:
            "No — one image per page, deliberately. Laying out multiple images per page is a design decision with many reasonable answers (grid, rows, captions, spacing) and no obvious default, and a tool that picks one for you gets it wrong most of the time. For a contact sheet, a word processor or a layout tool is the right instrument.",
        },
        {
          question: "My pages came out in the wrong order.",
          answer:
            "The file picker returned them that way. Operating systems sort file names alphabetically as text, so IMG_10.jpg comes before IMG_2.jpg — nine files in, the order goes wrong and stays wrong. The arrows in the file list reorder them; the PDF follows the list top to bottom.",
        },
        {
          question: "Are my images uploaded?",
          answer:
            "No. They are read, embedded and written into a PDF in this tab. The page's Content-Security-Policy sets connect-src 'self', so the browser itself blocks any request to another origin — which is worth knowing given that the images people convert to PDF are usually scans of documents, receipts and identity papers.",
        },
      ]}
      relatedTools={relatedTools("/jpg-to-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".jpg", ".jpeg", ".png", ".webp", ".avif", "image/*"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            setConverted([]);
            reset();
          }}
          multiple
          reorderable
          label="Drop images here"
          disabled={state.status === "running"}
        />

        {files.length > 0 && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Layout</span>
              <div className={segmentTrack} role="group" aria-label="Layout">
                {(
                  [
                    ["page", "Fit to page"],
                    ["image", "Page per image"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setFit(value)}
                    aria-pressed={fit === value}
                    className={segment(fit === value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {fit === "page" && (
              <>
                <div className="flex items-center gap-2">
                  <label htmlFor="pdf-size" className={fieldLabel}>
                    Page
                  </label>
                  <select
                    id="pdf-size"
                    value={pageSize}
                    onChange={(event) => setPageSize(event.target.value)}
                    className={`${field} w-28`}
                  >
                    {PAGE_SIZES.map((size) => (
                      <option key={size.id} value={size.id}>
                        {size.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <label htmlFor="pdf-margin" className={fieldLabel}>
                    Margin (pt)
                  </label>
                  <input
                    id="pdf-margin"
                    type="number"
                    min={0}
                    max={144}
                    value={margin}
                    onChange={(event) => setMargin(Math.max(0, Number(event.target.value) || 0))}
                    className={`${field} w-20`}
                  />
                </div>
              </>
            )}

            {state.status !== "running" && (
              <button type="button" onClick={() => void build()} className={btnPrimary}>
                Make a {files.length}-page PDF
              </button>
            )}

            <span className="font-mono text-2xs text-foreground-subtle">
              {formatBytes(totalBytes)} in
            </span>
          </div>
        )}

        {converted.length > 0 && (
          <Notice tone="info">
            A PDF has no filter for WebP, AVIF or HEIC, so {converted.length} file
            {converted.length === 1 ? " was" : "s were"} re-encoded as JPEG at quality 0.92:{" "}
            {converted.join(", ")}. JPEG and PNG files are embedded byte for byte and lose nothing.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            defaultStem={defaultStem}
            extension="pdf"
            value={outputName}
            onChange={setOutputName}
          />
        )}

        <FileResult state={state} />
      </div>
    </ToolShell>
  );
};
