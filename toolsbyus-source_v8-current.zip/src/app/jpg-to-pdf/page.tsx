import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JpgToPdfClient } from "./JpgToPdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/jpg-to-pdf",
  title: "JPG to PDF — Images to One PDF, No Upload",
  socialTitle: "JPG to PDF",
  description:
    "Turn JPG, PNG and WebP images into a PDF in your browser. Images are embedded rather than re-encoded, so nothing loses quality. Nothing is uploaded.",
});

export default function JpgToPdfPage() {
  return <JpgToPdfClient />;
}
