import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonBeautifierClient } from "./JsonBeautifierClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-beautifier",
  title: "JSON Beautifier — Make Minified JSON Readable",
  socialTitle: "JSON Beautifier",
  description:
    "Beautify and pretty-print JSON documents with custom indentation widths, key sorting, and zero server transmission.",
});

export default function JsonBeautifierPage() {
  return <JsonBeautifierClient />;
}
