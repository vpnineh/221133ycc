"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { DiffToolbar } from "../../components/diff/DiffToolbar";
import { DiffSummaryBar } from "../../components/diff/DiffSummaryBar";
import { VirtualizedDiffList } from "../../components/diff/VirtualizedDiffList";
import { DiffOptions, SemanticDiffResult, JsonPatch } from "../../lib/diff/types";
import { DiffWorkerClient } from "../../workers/worker-client";
import { createJsonPatch, applyJsonPatch } from "../../lib/diff/patch-rfc6902";
import { createJsonMergePatch } from "../../lib/diff/merge-patch-rfc7386";
import { parseJson } from "../../lib/json/parser";
import { serializeJson } from "../../lib/json/serializer";
import { Icon } from "../../components/common/Icon";
import { btnCompact, btnPrimary, btnSecondary } from "../../components/common/controls";
import { Notice } from "../../components/common/Notice";

const DEFAULT_LEFT = JSON.stringify(
  {
    service: "payment-gateway",
    version: "2.4.0",
    active: true,
    timeoutMs: 3000,
    features: ["card", "ach", "instant-settle"],
    endpoints: {
      primary: "https://api.gateway.internal/v2",
      failover: "https://failover.gateway.internal/v2",
    },
    accounts: [
      { id: "acc_101", name: "Production Pool", tier: "platinum", limits: { daily: 500000 } },
      { id: "acc_102", name: "Sandbox Pool", tier: "developer", limits: { daily: 5000 } },
    ],
  },
  null,
  2
);

const DEFAULT_RIGHT = JSON.stringify(
  {
    version: 2.5, // Type changed to number and bumped
    service: "payment-gateway", // Kept, different key order
    active: true,
    timeoutMs: 4500, // Value modified
    features: ["card", "instant-settle", "wire"], // Array modified
    endpoints: {
      primary: "https://api.gateway.internal/v2",
      backup: "https://failover.gateway.internal/v2", // Subtree key renamed
    },
    accounts: [
      { id: "acc_102", name: "Sandbox Pool", tier: "developer", limits: { daily: 10000 } }, // Reordered & daily limit updated
      { id: "acc_101", name: "Production Pool", tier: "platinum", limits: { daily: 500000 } },
      { id: "acc_103", name: "Enterprise Alpha", tier: "enterprise", limits: { daily: 2000000 } }, // Added object
    ],
    metadata: {
      migratedAt: "2026-09-09T00:00:00Z",
    },
  },
  null,
  2
);

export const JsonDiffClient: React.FC = () => {
  const [leftRaw, setLeftRaw] = useState(DEFAULT_LEFT);
  const [rightRaw, setRightRaw] = useState(DEFAULT_RIGHT);
  const [options, setOptions] = useState<DiffOptions>({
    arrayMatchMode: "key",
    arrayKey: "id",
    collapseUnchanged: false,
    contextDepth: 2,
  });
  const [viewMode, setViewMode] = useState<"split" | "unified">("split");

  const [diffResult, setDiffResult] = useState<SemanticDiffResult | null>(null);
  const [activeChangeIndex, setActiveChangeIndex] = useState<number>(-1);
  const [errorInfo, setErrorInfo] = useState<{ message: string; line?: number; column?: number; caretSnippet?: string } | null>(null);
  const [limitWarning, setLimitWarning] = useState<string | null>(null);
  const [durationMs, setDurationMs] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Patch Modals
  const [patchModalOpen, setPatchModalOpen] = useState(false);
  const [patchContent, setPatchContent] = useState("");
  const [patchModalTitle, setPatchModalTitle] = useState("");
  const [isApplyMode, setIsApplyMode] = useState(false);
  const [applyTarget, setApplyTarget] = useState<"left" | "right">("left");
  const [applyError, setApplyError] = useState<string | null>(null);
  // Replaces two alert() calls. A modal browser alert blocks the tab and
  // discards the context a developer needs to act on the message.
  const [patchError, setPatchError] = useState<string | null>(null);

  const workerClientRef = useRef<DiffWorkerClient | null>(null);

  useEffect(() => {
    workerClientRef.current = new DiffWorkerClient();
    return () => {
      workerClientRef.current?.terminate();
    };
  }, []);

  const runDiff = useCallback(() => {
    if (!workerClientRef.current) return;
    setErrorInfo(null);
    setLimitWarning(null);
    setIsProcessing(true);

    workerClientRef.current.runDiff(leftRaw, rightRaw, options, {
      onSuccess: (result, duration) => {
        setDiffResult(result);
        setDurationMs(duration);
        setIsProcessing(false);
        setActiveChangeIndex(-1);
      },
      onError: (err) => {
        setErrorInfo(err);
        setIsProcessing(false);
      },
      onLimitExceeded: (info) => {
        setLimitWarning(info.message);
        setIsProcessing(false);
      },
    });
  }, [leftRaw, rightRaw, options]);

  useEffect(() => {
    runDiff();
  }, [runDiff]);

  // Keyboard navigation: Alt + Down (next change), Alt + Up (prev change)
  const changeRowIndices = React.useMemo(() => {
    if (!diffResult) return [];
    const indices: number[] = [];
    diffResult.flatRows.forEach((row, idx) => {
      if (row.type !== "UNCHANGED") {
        indices.push(idx);
      }
    });
    return indices;
  }, [diffResult]);

  const handleNextChange = useCallback(() => {
    if (changeRowIndices.length === 0) return;
    const next = changeRowIndices.find((idx) => idx > activeChangeIndex);
    if (next !== undefined) {
      setActiveChangeIndex(next);
    } else {
      setActiveChangeIndex(changeRowIndices[0]);
    }
  }, [changeRowIndices, activeChangeIndex]);

  const handlePrevChange = useCallback(() => {
    if (changeRowIndices.length === 0) return;
    const prev = [...changeRowIndices].reverse().find((idx) => idx < activeChangeIndex);
    if (prev !== undefined) {
      setActiveChangeIndex(prev);
    } else {
      setActiveChangeIndex(changeRowIndices[changeRowIndices.length - 1]);
    }
  }, [changeRowIndices, activeChangeIndex]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key === "ArrowDown") {
        e.preventDefault();
        handleNextChange();
      } else if (e.altKey && e.key === "ArrowUp") {
        e.preventDefault();
        handlePrevChange();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleNextChange, handlePrevChange]);

  const handleExportPatch = () => {
    const parseL = parseJson(leftRaw);
    const parseR = parseJson(rightRaw);
    if (!parseL.success || !parseR.success) {
      const failed = parseL.success ? parseR : parseL;
      const side = parseL.success ? "Right" : "Left";
      setPatchError(
        `Both documents must parse as JSON before a patch can be generated. ${side} document: ` +
          (failed.success ? "unknown error" : failed.error.message)
      );
      return;
    }
    setPatchError(null);
    const patch = createJsonPatch(parseL.data, parseR.data);
    setPatchContent(JSON.stringify(patch, null, 2));
    setPatchModalTitle("RFC 6902 JSON Patch Document");
    setIsApplyMode(false);
    setPatchModalOpen(true);
  };

  const handleExportMergePatch = () => {
    const parseL = parseJson(leftRaw);
    const parseR = parseJson(rightRaw);
    if (!parseL.success || !parseR.success) {
      const failed = parseL.success ? parseR : parseL;
      const side = parseL.success ? "Right" : "Left";
      setPatchError(
        `Both documents must parse as JSON before a merge patch can be generated. ${side} document: ` +
          (failed.success ? "unknown error" : failed.error.message)
      );
      return;
    }
    setPatchError(null);
    const patch = createJsonMergePatch(parseL.data, parseR.data);
    setPatchContent(JSON.stringify(patch, null, 2));
    setPatchModalTitle("RFC 7386 JSON Merge Patch Document");
    setIsApplyMode(false);
    setPatchModalOpen(true);
  };

  const handleOpenApplyPatch = () => {
    setPatchContent("[\n  { \"op\": \"replace\", \"path\": \"/version\", \"value\": \"3.0.0\" }\n]");
    setPatchModalTitle("Apply RFC 6902 JSON Patch");
    setIsApplyMode(true);
    setApplyError(null);
    setPatchModalOpen(true);
  };

  const executeApplyPatch = () => {
    setApplyError(null);
    const docRaw = applyTarget === "left" ? leftRaw : rightRaw;
    const parseDoc = parseJson(docRaw);
    if (!parseDoc.success) {
      setApplyError(`Target document syntax error: ${parseDoc.error.message}`);
      return;
    }

    const parsePatch = parseJson(patchContent);
    if (!parsePatch.success) {
      setApplyError(`Patch syntax error: ${parsePatch.error.message}`);
      return;
    }

    if (!Array.isArray(parsePatch.data)) {
      setApplyError("RFC 6902 Patch must be a JSON array of operations.");
      return;
    }

    try {
      const patched = applyJsonPatch(parseDoc.data, parsePatch.data as unknown as JsonPatch);
      const formatted = serializeJson(patched, { indent: 2 });
      if (applyTarget === "left") {
        setLeftRaw(formatted);
      } else {
        setRightRaw(formatted);
      }
      setPatchModalOpen(false);
    } catch (err) {
      setApplyError(`Failed to apply patch: ${(err as Error).message}`);
    }
  };

  const handleSwap = () => {
    setLeftRaw(rightRaw);
    setRightRaw(leftRaw);
  };

  return (
    <ToolShell
      wide
      slug="json-diff"
      keyword="JSON Diff"
      directAnswer="JSON Diff is a client-side semantic comparison engine that parses JSON payloads into Abstract Syntax Trees, completely ignoring key ordering and insignificant whitespace. It features configurable array matching by primary key, distinct type-shift classification, Web Worker execution handling up to 100 MB of JSON without freezing the tab, and bi-directional RFC 6902 JSON Patch export and application."
      seoDescription="Compare JSON documents with semantic AST diffing. Key-order invariant, configurable array matching, Web Worker execution up to 100 MB, and RFC 6902 patch export."
      breadcrumbs={[{ name: "JSON Diff", url: "/json-diff" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Standard line-by-line diff tools (like classic Unix <code>diff</code>) fail on JSON because they compare serialized text instead of semantic data. In JSON, key order is explicitly arbitrary according to RFC 8259: <code>{"{\"a\":1,\"b\":2}"}</code> and <code>{"{\"b\":2,\"a\":1}"}</code> represent identical objects, yet textual diff engines flag them as contradictory lines.
            </p>
            <p>
              The ToolsByUs diff engine solves this by operating on parsed <strong>Abstract Syntax Trees (AST)</strong> inside an isolated <strong>Web Worker</strong>. It normalizes object keys lexicographically and implements three configurable array matching algorithms:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Index Matching:</strong> Aligns array elements strictly by ordinal position (default for primitive lists).</li>
              <li><strong>Key Matching:</strong> Correlates collection entities by an immutable identifier (e.g. <code>id</code> or <code>uuid</code>), ensuring reordered list items are detected as modifications or moves rather than spurious delete-and-add churn.</li>
              <li><strong>Structural Similarity:</strong> Uses bipartite maximum-weight matching to align objects with highest field correspondence.</li>
            </ul>
            <p>
              Scalar type changes (such as changing a string &quot;42&quot; to a numeric <code>42</code>) are recognized as distinct <code>TYPE_CHANGE</code> events rather than destructive replacement cycles.
            </p>
          </>
        ),
        inputTitle: "Left vs Right Sample",
        exampleInput: `// Left:\n{"id": 1, "tier": "free", "name": "Alpha"}\n\n// Right:\n{"name": "Alpha", "id": 1, "tier": "pro"}`,
        exampleOutput: `// Semantic Diff Result:\n- tier: "free" (Removed)\n+ tier: "pro" (Added)\n= id: 1 (Unchanged)\n= name: "Alpha" (Unchanged, key order ignored)`,
      }}
      referenceTable={{
        title: "Diff Engine Parameters & Behavior Specification",
        rows: [
          {
            parameter: "Key Order Invariance",
            type: "Invariant",
            defaultVal: "Always On",
            description: "Object keys are compared as mathematical sets. Differing key sequences produce zero diff churn.",
          },
          {
            parameter: "Array Match: index",
            type: "Mode",
            defaultVal: "Default",
            description: "Matches items strictly by zero-based index. Ideal for simple scalar arrays [1, 2, 3].",
          },
          {
            parameter: "Array Match: key",
            type: "Mode",
            defaultVal: "'id'",
            description: "Matches object items across arrays by user-defined primary key property. Prevents false additions on reorder.",
          },
          {
            parameter: "Array Match: similarity",
            type: "Mode",
            defaultVal: "Score > 0.4",
            description: "Heuristic structural matching based on shared keys and primitive scalar equality.",
          },
          {
            parameter: "Type Change Class",
            type: "Category",
            defaultVal: "Active",
            description: "Tagging type transitions ('1' -> 1) as distinct TYPE_CHANGE operations instead of delete+add.",
          },
          {
            parameter: "Memory Ceiling",
            type: "Limit",
            defaultVal: "100 MB",
            description: "Explicit in-worker payload ceiling guarding against browser tab out-of-memory crashes.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why doesn't key order matter in JSON diffing?",
          answer:
            "According to the official JSON specification (RFC 8259 Section 4), JSON objects are collections of unordered zero or more name/value pairs. Because JSON encoders (such as Python dictionaries or Go map iteration) serialize keys in non-deterministic orders, semantic diffing must normalize key orders to eliminate false differences.",
        },
        {
          question: "How does matching arrays by key work?",
          answer:
            "When dealing with arrays of database models or API records, items often change order or are deleted. By specifying a primary key like 'id' or 'uuid', the diff engine matches left and right objects having the same key value regardless of array position, accurately highlighting field mutations instead of reporting full array replacements.",
        },
        {
          question: "Can I generate an RFC 6902 JSON Patch from this diff?",
          answer:
            "Yes. ToolsByUs generates compliant RFC 6902 JSON Patch arrays (with operations 'add', 'remove', 'replace', and 'move') that can be copied with one click or applied directly to documents. The patch is guaranteed to round-trip: applying the generated patch to your original document produces the exact target document.",
        },
        {
          question: "Is my JSON payload sent to any backend server?",
          answer:
            "No. ToolsByUs is a zero-backend static website. Parsing, AST traversal, and diff generation execute 100% inside your browser's dedicated Web Worker thread. Network requests are completely disabled while documents are loaded, verified by strict automated E2E tests.",
        },
        {
          question: "How large of a JSON document can I diff without freezing the tab?",
          answer:
            "Because all heavy parsing and traversal run in a Web Worker and rows are rendered using virtualized scrolling (only elements visible in your viewport exist in the DOM), the interface stays responsive on documents up to the worker's 100 MB ceiling. A 50 MB pair still takes tens of seconds of real work — the difference is that you can scroll, type and cancel while it runs, instead of watching a frozen tab.",
        },
      ]}
      relatedTools={[
        {
          href: "/diff-checker",
          title: "Diff Checker",
          description: "Compare plain text, markdown, or raw source code at line, word, and character granularity.",
        },
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Validate JSON syntax against RFC 8259 with exact line/column caret reporting.",
        },
        {
          href: "/json-schema-generator",
          title: "JSON Schema Generator",
          description: "Infer Draft 2020-12 JSON Schema definitions from your JSON payloads automatically.",
        },
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Format and indent JSON with key sorting, JSONC comment handling, and unicode controls.",
        },
      ]}
    >
      {/* Interactive Tool Area (Above the fold) */}
      <div className="space-y-4">
        {/* Error / Warning Notice */}
        {limitWarning && (
          <Notice tone="warn" title="Memory ceiling reached:">
            {limitWarning}
          </Notice>
        )}

        {patchError && (
          <Notice
            tone="danger"
            title="Cannot build a patch:"
            action={
              <button
                type="button"
                onClick={() => setPatchError(null)}
                className={btnCompact}
              >
                Dismiss
              </button>
            }
          >
            {patchError}
          </Notice>
        )}

        {/* Toolbar */}
        <DiffToolbar
          options={options}
          onOptionsChange={setOptions}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          onExportPatch={handleExportPatch}
          onExportMergePatch={handleExportMergePatch}
          onOpenApplyPatch={handleOpenApplyPatch}
          onSwapDocuments={handleSwap}
        />

        {/* Input Panes (Two column split) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CodePane
            label="Left Document (Original / Base)"
            value={leftRaw}
            onChange={setLeftRaw}
            placeholder="Paste base JSON document..."
            error={errorInfo?.message.includes("Left") ? errorInfo : undefined}
          />
          <CodePane
            label="Right Document (Modified / Target)"
            value={rightRaw}
            onChange={setRightRaw}
            placeholder="Paste modified JSON document..."
            error={errorInfo?.message.includes("Right") ? errorInfo : undefined}
          />
        </div>

        {/* Summary Bar */}
        {diffResult && (
          <DiffSummaryBar
            summary={diffResult.summary}
            durationMs={durationMs}
            onNextChange={handleNextChange}
            onPrevChange={handlePrevChange}
          />
        )}

        {/* Virtualized Diff List */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-foreground-muted font-mono px-1">
            <span>
              {isProcessing
                ? "Computing semantic diff in Web Worker..."
                : diffResult
                ? `Showing ${diffResult.flatRows.length} virtualized rows (${diffResult.summary.total} differences found)`
                : "Awaiting input..."}
            </span>
            <span className="text-2xs text-foreground-muted">
              Shortcuts: <kbd className="px-1 py-0.5 rounded bg-surface-elevated border border-border">Alt+↓</kbd> next, <kbd className="px-1 py-0.5 rounded bg-surface-elevated border border-border">Alt+↑</kbd> prev
            </span>
          </div>

          <VirtualizedDiffList
            rows={diffResult?.flatRows || []}
            viewMode={viewMode}
            activeIndex={activeChangeIndex}
            onRowClick={(_row, index) => setActiveChangeIndex(index)}
          />
        </div>
      </div>

      {/* JSON Patch Modal */}
      {patchModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-scrim p-4"
        >
          <div className="w-full max-w-2xl rounded-lg border border-border bg-surface p-5 flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-border">
              <h3 className="text-sm font-bold text-foreground font-mono">{patchModalTitle}</h3>
              <button
                type="button"
                onClick={() => setPatchModalOpen(false)}
                className="inline-flex h-8 w-8 cursor-pointer items-center justify-center rounded border border-border bg-surface text-foreground-muted transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:h-11 pointer-coarse:w-11"
                aria-label="Close dialog"
              >
                <Icon name="close" size="md" />
              </button>
            </div>

            <div className="py-3 flex-1 overflow-hidden flex flex-col">
              {isApplyMode && (
                <div className="mb-3 flex items-center gap-3 text-xs font-mono text-foreground-muted">
                  <span>Target Document:</span>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="applyTarget"
                      value="left"
                      checked={applyTarget === "left"}
                      onChange={() => setApplyTarget("left")}
                    />
                    <span>Left Document</span>
                  </label>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="applyTarget"
                      value="right"
                      checked={applyTarget === "right"}
                      onChange={() => setApplyTarget("right")}
                    />
                    <span>Right Document</span>
                  </label>
                </div>
              )}

              <textarea
                value={patchContent}
                onChange={(e) => setPatchContent(e.target.value)}
                readOnly={!isApplyMode}
                className="w-full flex-1 p-3 rounded bg-background font-mono text-xs text-foreground border border-border resize-none focus:outline-none leading-relaxed"
                rows={14}
              />

              {applyError && (
                <div className="mt-2 p-2 rounded bg-danger-soft border border-danger text-danger text-xs font-mono">
                  {applyError}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-border flex items-center justify-between">
              <span className="text-2xs text-foreground-muted font-mono">
                {isApplyMode
                  ? "Applies RFC 6902 operations directly to the selected document."
                  : "One-click copyable valid RFC 6902 Patch."}
              </span>
              <div className="flex items-center gap-2">
                {!isApplyMode ? (
                  <button
                    type="button"
                    onClick={async () => {
                      await navigator.clipboard.writeText(patchContent);
                      setPatchModalOpen(false);
                    }}
                    className={btnPrimary}
                  >
                    Copy Patch & Close
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={executeApplyPatch}
                    className={btnPrimary}
                  >
                    Apply Patch
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setPatchModalOpen(false)}
                  className={btnSecondary}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </ToolShell>
  );
};
