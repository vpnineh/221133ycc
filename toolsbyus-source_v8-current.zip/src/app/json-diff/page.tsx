import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonDiffClient } from "./JsonDiffClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-diff",
  title: "JSON Diff — Compare Two JSON Files Online",
  socialTitle: "JSON Diff",
  description:
    "Compare JSON semantically: key-order invariant, configurable array matching, move detection, and RFC 6902 patch export. Runs in a Web Worker.",
});

export default function JsonDiffPage() {
  return <JsonDiffClient />;
}
