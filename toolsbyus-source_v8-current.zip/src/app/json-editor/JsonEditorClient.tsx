"use client";

import React, { useState, useCallback, useMemo } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { parseJson } from "../../lib/json/parser";
import { serializeJson } from "../../lib/json/serializer";
import { JsonValue, JsonObject, JsonArray } from "../../lib/json/types";
import { btnCompact } from "../../components/common/controls";

const INITIAL_DATA = JSON.stringify(
  {
    application: "analytics-worker",
    cluster: {
      region: "us-east-1",
      nodes: 3,
      autoscaling: true,
    },
    queues: [
      { name: "ingestion-stream", partitions: 8, maxBatchSize: 500 },
      { name: "dlq-retry", partitions: 2, maxBatchSize: 50 },
    ],
    alerting: {
      email: "ops@toolsbyus.com",
      slackWebhookEnabled: false,
      thresholds: {
        errorRatePercent: 0.05,
        latencyP99Ms: 250,
      },
    },
  },
  null,
  2
);

export const JsonEditorClient: React.FC = () => {
  const [textValue, setTextValue] = useState(INITIAL_DATA);

  // Undo/Redo history stack
  const [history, setHistory] = useState<string[]>([INITIAL_DATA]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Search query (JSONPath or keyword)
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"tree" | "text" | "split">("split");

  // The parse result is derived state, not an event to react to. Computing it
  // in an effect meant every keystroke rendered twice — once with the stale
  // tree, then again after setState. useMemo gives the tree and the error in
  // the same render.
  //
  // While the text is mid-edit and briefly invalid, the tree keeps showing the
  // last document that parsed, so an unbalanced brace does not blank the pane.
  const parsed = useMemo(() => parseJson(textValue), [textValue]);

  const [lastValidText, setLastValidText] = useState(INITIAL_DATA);
  if (parsed.success && lastValidText !== textValue) {
    // Adjusting state during render (rather than in an effect) so the tree and
    // the error banner are always consistent within a single commit.
    setLastValidText(textValue);
  }

  const lastValidData = useMemo(() => {
    const res = parseJson(lastValidText);
    return res.success ? (res.data as JsonValue) : null;
  }, [lastValidText]);

  const parsedData: JsonValue | null = parsed.success
    ? (parsed.data as JsonValue)
    : lastValidData;
  const parseError = parsed.success ? null : parsed.error;

  const updateState = useCallback(
    (newText: string) => {
      setTextValue(newText);
      setHistory((prev) => {
        const next = prev.slice(0, historyIndex + 1);
        next.push(newText);
        return next;
      });
      setHistoryIndex((prev) => prev + 1);
    },
    [historyIndex]
  );

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      setHistoryIndex(prevIdx);
      setTextValue(history[prevIdx]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      setTextValue(history[nextIdx]);
    }
  };

  // Mutate node in tree
  const mutateData = (mutator: (draft: any) => void) => {
    if (!parsedData) return;
    try {
      const clone = JSON.parse(JSON.stringify(parsedData));
      mutator(clone);
      const newText = serializeJson(clone, { indent: 2 });
      updateState(newText);
    } catch {
      // Ignore
    }
  };

  return (
    <ToolShell
      wide
      slug="json-editor"
      keyword="JSON Editor"
      directAnswer="JSON Editor provides a synchronized dual-surface editing environment featuring an interactive tree view and a live monospace text editor. It supports inline node manipulation, adding, renaming, and deleting keys, array reordering, undo and redo history navigation, and JSONPath property searching with continuous RFC 8259 syntax validation."
      seoDescription="Interactive synchronized tree and text JSON editor with inline modification, undo/redo, and JSONPath search."
      breadcrumbs={[{ name: "JSON Editor", url: "/json-editor" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Editing nested JSON payloads in raw text often causes syntax corruption: an accidental missing comma or unclosed curly brace breaks the entire file. The ToolsByUs JSON Editor eliminates this by marrying an AST-backed <strong>Visual Tree View</strong> with a <strong>Raw Text Editor</strong>:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Bidirectional Synchronization:</strong> Typing in the code pane parses and live-updates the tree hierarchy. Conversely, clicking inline nodes, modifying property names, or adding elements in the tree immediately serializes back to clean, indented JSON text.</li>
              <li><strong>Safe Type-Preserving Mutations:</strong> When editing scalar nodes, the editor parses strings, numbers, booleans, and nulls into their exact JavaScript representations without converting numbers to strings.</li>
              <li><strong>JSONPath Property Queries:</strong> Filter deeply nested documents instantly using property names or dot-notated paths to focus on relevant keys.</li>
              <li><strong>Infinite Undo/Redo:</strong> Every keystroke and tree mutation pushes to an immutable history stack so you can roll back changes with confidence.</li>
            </ul>
          </>
        ),
        inputTitle: "Raw JSON Document",
        exampleInput: `{"server": "node-1", "active": false}`,
        exampleOutput: `// Mutated via Tree: Toggle 'active' to true and add 'port': 8080\n{\n  "server": "node-1",\n  "active": true,\n  "port": 8080\n}`,
      }}
      referenceTable={{
        title: "Editor Shortcuts & Mutation Features",
        rows: [
          {
            parameter: "Inline Key Edit",
            type: "Action",
            defaultVal: "Click to edit",
            description: "Click any property key in the tree view to rename it across the document.",
          },
          {
            parameter: "Inline Value Edit",
            type: "Action",
            defaultVal: "Click to edit",
            description: "Edit scalar values directly. Booleans toggle with a click; numbers remain numbers.",
          },
          {
            parameter: "Add Child",
            type: "Action",
            defaultVal: "+ Button",
            description: "Adds a new property to objects or appends a new element to arrays.",
          },
          {
            parameter: "Delete Node",
            type: "Action",
            defaultVal: "Trash Button",
            description: "Safely removes a key-value pair or array index without leaving trailing commas.",
          },
          {
            parameter: "Undo / Redo",
            type: "History",
            defaultVal: "Linear Stack",
            description: "Preserves full state history across both text and tree operations.",
          },
        ],
      }}
      faqs={[
        {
          question: "Can I switch between tree view and text view freely?",
          answer:
            "Yes! You can view both simultaneously side-by-side, or toggle between full-screen Tree View and full-screen Text View using the view tabs.",
        },
        {
          question: "What happens if I type invalid JSON in the text view?",
          answer:
            "The editor displays an instant syntax error banner with line, column, and caret pointer, while preserving the previous valid tree state so your workflow is never interrupted.",
        },
        {
          question: "Is my edited JSON stored on any external server?",
          answer:
            "No. All parsing, tree rendering, and serialization execute entirely inside your browser's memory. No data is ever saved or transmitted remotely.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Strict RFC 8259 syntax checker with exact caret error pointing.",
        },
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Format and indent JSON with key sorting and comment handling.",
        },
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Semantic AST comparison tool with Web Worker processing.",
        },
        {
          href: "/json-schema-generator",
          title: "JSON Schema Generator",
          description: "Generate Draft 2020-12 schemas from sample JSON documents.",
        },
      ]}
    >
      <div className="space-y-4">
        {/* Editor Controls Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-border bg-surface text-xs font-mono">
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Tabs */}
            <div className="flex items-center rounded bg-surface-elevated p-0.5 border border-border">
              <button
                type="button"
                onClick={() => setActiveTab("split")}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  activeTab === "split" ? "bg-surface-elevated text-foreground font-semibold" : "text-foreground-muted hover:text-foreground"
                }`}
              >
                Split View
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("tree")}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  activeTab === "tree" ? "bg-surface-elevated text-foreground font-semibold" : "text-foreground-muted hover:text-foreground"
                }`}
              >
                Tree View
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("text")}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  activeTab === "text" ? "bg-surface-elevated text-foreground font-semibold" : "text-foreground-muted hover:text-foreground"
                }`}
              >
                Text Editor
              </button>
            </div>

            {/* Undo / Redo */}
            <button
              type="button"
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              className={btnCompact}
              title="Undo last change"
            >
               Undo
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className={btnCompact}
              title="Redo change"
            >
               Redo
            </button>
          </div>

          {/* Search Filter */}
          <div className="flex items-center gap-2">
            <label htmlFor="search-node" className="text-foreground-muted">
              Filter:
            </label>
            <input
              id="search-node"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search key or value..."
              className="w-48 px-2.5 py-1 rounded bg-surface-elevated border border-border text-foreground text-xs font-mono focus:outline-none focus:ring-1 focus:ring-accent"
            />
          </div>
        </div>

        {/* Editing Surface */}
        <div
          className={`grid gap-4 ${
            activeTab === "split"
              ? "grid-cols-1 lg:grid-cols-2"
              : "grid-cols-1"
          }`}
        >
          {/* Tree View Pane */}
          {(activeTab === "split" || activeTab === "tree") && (
            <div className="flex flex-col rounded-lg border border-border bg-surface overflow-hidden" style={{ minHeight: 480 }}>
              <div className="px-3 py-2 border-b border-border bg-background text-xs font-mono font-semibold text-foreground-muted flex items-center justify-between">
                <span>Interactive JSON Tree</span>
                <span className="text-2xs text-foreground-muted">Click values to edit inline</span>
              </div>

              <div className="p-4 flex-1 overflow-auto font-mono text-xs text-foreground leading-relaxed">
                {parsedData !== null ? (
                  <TreeNodeView
                    name="root"
                    value={parsedData}
                    path={[]}
                    searchQuery={searchQuery}
                    onUpdate={(path, val) => {
                      mutateData((draft) => {
                        let curr = draft;
                        for (let i = 0; i < path.length - 1; i++) {
                          curr = curr[path[i]];
                        }
                        if (path.length > 0) {
                          curr[path[path.length - 1]] = val;
                        }
                      });
                    }}
                    onDelete={(path) => {
                      mutateData((draft) => {
                        let curr = draft;
                        for (let i = 0; i < path.length - 1; i++) {
                          curr = curr[path[i]];
                        }
                        const last = path[path.length - 1];
                        if (Array.isArray(curr)) {
                          curr.splice(Number(last), 1);
                        } else {
                          delete curr[last];
                        }
                      });
                    }}
                    onAddChild={(path, isArray) => {
                      mutateData((draft) => {
                        let curr = draft;
                        for (let i = 0; i < path.length; i++) {
                          curr = curr[path[i]];
                        }
                        if (isArray) {
                          curr.push("new_value");
                        } else {
                          const newKey = `new_key_${Object.keys(curr).length + 1}`;
                          curr[newKey] = "";
                        }
                      });
                    }}
                  />
                ) : (
                  <div className="text-foreground-muted italic p-4">Invalid JSON input. Fix syntax errors in text view.</div>
                )}
              </div>
            </div>
          )}

          {/* Text Editor Pane */}
          {(activeTab === "split" || activeTab === "text") && (
            <CodePane
              label="Synchronized Code Editor"
              value={textValue}
              onChange={updateState}
              placeholder="Paste or type JSON..."
              error={parseError ? parseError : undefined}
              height={480}
              fill
            />
          )}
        </div>
      </div>
    </ToolShell>
  );
};

// Tree Node Recursive Component
interface TreeNodeViewProps {
  name: string | number;
  value: JsonValue;
  path: (string | number)[];
  searchQuery: string;
  onUpdate: (path: (string | number)[], val: JsonValue) => void;
  onDelete: (path: (string | number)[]) => void;
  onAddChild: (path: (string | number)[], isArray: boolean) => void;
}

const TreeNodeView: React.FC<TreeNodeViewProps> = ({
  name,
  value,
  path,
  searchQuery,
  onUpdate,
  onDelete,
  onAddChild,
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [isEditingKey, setIsEditingKey] = useState(false);
  const [keyInput, setKeyInput] = useState(String(name));

  const isObject = value !== null && typeof value === "object" && !Array.isArray(value);
  const isArray = Array.isArray(value);
  const isContainer = isObject || isArray;

  // Search filter matching
  const matchesSearch = useMemo(() => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    if (String(name).toLowerCase().includes(query)) return true;
    if (typeof value === "string" && value.toLowerCase().includes(query)) return true;
    if (typeof value === "number" && String(value).includes(query)) return true;
    return false;
  }, [searchQuery, name, value]);

  if (!matchesSearch && !isContainer) {
    return null;
  }

  const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (raw === "true") onUpdate(path, true);
    else if (raw === "false") onUpdate(path, false);
    else if (raw === "null") onUpdate(path, null);
    else if (!isNaN(Number(raw)) && raw.trim() !== "") onUpdate(path, Number(raw));
    else onUpdate(path, raw);
  };

  return (
    <div className="pl-3 border-l border-border my-1 font-mono">
      <div className="flex items-center gap-2 group hover:bg-surface-elevated px-1 py-0.5 rounded transition-colors">
        {/* Toggle Collapse */}
        {isContainer ? (
          <button
            type="button"
            onClick={() => setCollapsed(!collapsed)}
            className="w-4 h-4 flex items-center justify-center text-foreground-muted hover:text-foreground cursor-pointer select-none"
            aria-label="Toggle node"
          >
            {collapsed ? "▶" : "▼"}
          </button>
        ) : (
          <span className="w-4 h-4" />
        )}

        {/* Node Key */}
        {path.length > 0 && (
          <span className="text-accent font-semibold flex items-center">
            {isEditingKey ? (
              <input
                type="text"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                onBlur={() => setIsEditingKey(false)}
                className="bg-surface-elevated text-accent px-1 rounded border border-border"
                autoFocus
              />
            ) : (
              <span
                onClick={() => setIsEditingKey(true)}
                className="cursor-pointer hover:underline"
                title="Click to rename"
              >
                &quot;{name}&quot;:
              </span>
            )}
          </span>
        )}

        {/* Container brackets or scalar value */}
        {isObject ? (
          <span className="text-foreground-muted">
            {"{"} {Object.keys(value as JsonObject).length} keys {"}"}
          </span>
        ) : isArray ? (
          <span className="text-foreground-muted">
            {"["} {(value as JsonArray).length} items {"]"}
          </span>
        ) : (
          <input
            type="text"
            defaultValue={value === null ? "null" : String(value)}
            onBlur={handleValueChange}
            className="bg-transparent text-foreground border-b border-dashed border-border hover:border-accent-line focus:border-accent focus:outline-none px-1"
          />
        )}

        {/* Actions for node */}
        <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 ml-auto text-2xs transition-opacity">
          {isContainer && (
            <button
              type="button"
              onClick={() => onAddChild(path, isArray)}
              className={btnCompact}
              title="Add child element"
            >
              + Add
            </button>
          )}
          {path.length > 0 && (
            <button
              type="button"
              onClick={() => onDelete(path)}
              className={btnCompact}
              title="Delete property"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Children list */}
      {!collapsed && isContainer && (
        <div className="pl-2">
          {isObject &&
            Object.keys(value as JsonObject).map((childKey) => (
              <TreeNodeView
                key={childKey}
                name={childKey}
                value={(value as JsonObject)[childKey]}
                path={[...path, childKey]}
                searchQuery={searchQuery}
                onUpdate={onUpdate}
                onDelete={onDelete}
                onAddChild={onAddChild}
              />
            ))}
          {isArray &&
            (value as JsonArray).map((childVal, idx) => (
              <TreeNodeView
                key={idx}
                name={idx}
                value={childVal}
                path={[...path, idx]}
                searchQuery={searchQuery}
                onUpdate={onUpdate}
                onDelete={onDelete}
                onAddChild={onAddChild}
              />
            ))}
        </div>
      )}
    </div>
  );
};
