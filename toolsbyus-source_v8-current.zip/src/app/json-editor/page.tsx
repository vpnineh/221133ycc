import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonEditorClient } from "./JsonEditorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-editor",
  title: "JSON Editor — Edit and Validate in the Browser",
  socialTitle: "JSON Editor",
  description:
    "Interactive synchronized tree and text JSON editor with inline modification, undo/redo, and JSONPath search.",
});

export default function JsonEditorPage() {
  return <JsonEditorClient />;
}
