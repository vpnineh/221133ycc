"use client";

import React, { useState, useTransition, useId } from "react";
import { formatJson, FormatResult } from "@/lib/json/formatter";
import { KeySortOption } from "@/lib/json/serializer";

const SAMPLE_JSON = `{
  // User profile payload
  "user_id": 10492,
  "username": "developer_pro",
  "tags": ["frontend", "security", "fullstack"],
  "beta_tester": true,
  "scores": {
    "module10": 94,
    "module2": 88,
    "module1": 79
  },
  "unicode_sample": "Debugging with ☕ & ❤",
  /* Deprecated flag */
  "legacy_id": null,
}`;

function detectIndentation(input: string): string {
  const lines = input.split("\n");
  for (const line of lines) {
    const match = line.match(/^([ \t]+)[^ \t]/);
    if (match) {
      const whitespace = match[1];
      if (whitespace.startsWith("\t")) {
        return "Tabs";
      }
      return `${whitespace.length} Spaces`;
    }
  }
  return "Compact / None";
}

export default function JsonFormatterClient() {
  const [input, setInput] = useState<string>(SAMPLE_JSON);
  const [indent, setIndent] = useState<number | "tab">(2);
  const [sortKeys, setSortKeys] = useState<KeySortOption>("none");
  const [escapeUnicode, setEscapeUnicode] = useState<boolean>(false);
  const [unescapeUnicode, setUnescapeUnicode] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [, startTransition] = useTransition();

  const inputId = useId();

  const formatResult: FormatResult = formatJson(input, {
    indent,
    sortKeys: sortKeys === "none" ? false : sortKeys,
    escapeUnicode,
    unescapeUnicode,
  });

  const inputBytes = new TextEncoder().encode(input).length;
  const outputBytes = formatResult.success && formatResult.formatted
    ? new TextEncoder().encode(formatResult.formatted).length
    : 0;
  const inputLines = input ? input.split("\n").length : 0;
  const outputLines = formatResult.success && formatResult.formatted
    ? formatResult.formatted.split("\n").length
    : 0;
  const detectedIndent = detectIndentation(input);

  const handleCopy = async () => {
    if (!formatResult.formatted) return;
    try {
      await navigator.clipboard.writeText(formatResult.formatted);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const handleClear = () => {
    setInput("");
  };

  const handleLoadSample = () => {
    startTransition(() => {
      setInput(SAMPLE_JSON);
    });
  };

  return (
    <div className="space-y-6">
      {/* Controls Bar */}
      <div className="rounded-xl bg-surface-elevated p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Indent Selector */}
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-foreground-muted">
                Indent:
              </span>
              <div className="inline-flex rounded-pill bg-surface p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setIndent(2)}
                  className={`rounded-pill px-3 py-1 transition-colors ${
                    indent === 2
                      ? "bg-surface text-foreground shadow-pop font-semibold"
                      : "text-foreground-muted hover:text-foreground"
                  }`}
                >
                  2 Spaces
                </button>
                <button
                  type="button"
                  onClick={() => setIndent(4)}
                  className={`rounded-pill px-3 py-1 transition-colors ${
                    indent === 4
                      ? "bg-surface text-foreground shadow-pop font-semibold"
                      : "text-foreground-muted hover:text-foreground"
                  }`}
                >
                  4 Spaces
                </button>
                <button
                  type="button"
                  onClick={() => setIndent("tab")}
                  className={`rounded-pill px-3 py-1 transition-colors ${
                    indent === "tab"
                      ? "bg-surface text-foreground shadow-pop font-semibold"
                      : "text-foreground-muted hover:text-foreground"
                  }`}
                >
                  Tab
                </button>
              </div>
            </div>

            {/* Key Sort */}
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-foreground-muted">
                Sort Keys:
              </span>
              <select
                value={sortKeys as string}
                onChange={(e) => setSortKeys(e.target.value as KeySortOption)}
                className="rounded-lg bg-surface px-3 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent"
              >
                <option value="none">Original Order</option>
                <option value="alphabetical">Alphabetical (A-Z)</option>
                <option value="natural">Natural Sort (key1, key2, key10)</option>
                <option value="reverse">Reverse (Z-A)</option>
              </select>
            </div>
          </div>

        </div>

        {/* Options Toggles */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-border">
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={escapeUnicode}
                onChange={(e) => {
                  setEscapeUnicode(e.target.checked);
                  if (e.target.checked) setUnescapeUnicode(false);
                }}
                className="rounded border-border text-accent focus:ring-accent"
              />
              <span>Escape Unicode (\uXXXX)</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={unescapeUnicode}
                onChange={(e) => {
                  setUnescapeUnicode(e.target.checked);
                  if (e.target.checked) setEscapeUnicode(false);
                }}
                className="rounded border-border text-accent focus:ring-accent"
              />
              <span>Unescape Unicode (Native chars)</span>
            </label>

            <span className="text-foreground-muted italic">
              * Comments & trailing commas auto-cleaned
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleLoadSample}
              className="rounded-pill bg-surface px-3.5 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-border"
            >
              Load Sample
            </button>
            <button
              type="button"
              onClick={handleClear}
              className="rounded-pill px-3.5 py-1.5 text-xs font-medium text-foreground-muted transition-colors hover:text-foreground"
            >
              Clear
            </button>
            <button
              type="button"
              disabled={!formatResult.success}
              onClick={handleCopy}
              className="rounded-pill bg-accent-solid px-4 py-1.5 text-xs font-semibold text-accent-on transition-colors hover:bg-accent-hover disabled:opacity-50"
            >
              {copied ? "Copied!" : "Copy Formatted"}
            </button>
          </div>
        </div>
      </div>

      {/* Statistics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-lg bg-surface-elevated p-3 text-center">
          <span className="text-xs text-foreground-muted block">Input Size</span>
          <span className="text-sm font-bold text-foreground">{inputBytes} B</span>
        </div>
        <div className="rounded-lg bg-surface-elevated p-3 text-center">
          <span className="text-xs text-foreground-muted block">Formatted Size</span>
          <span className="text-sm font-bold text-foreground">{outputBytes} B</span>
        </div>
        <div className="rounded-lg bg-surface-elevated p-3 text-center">
          <span className="text-xs text-foreground-muted block">Line Delta</span>
          <span className="text-sm font-bold text-foreground">
            {inputLines} &rarr; {outputLines}
          </span>
        </div>
        <div className="rounded-lg bg-surface-elevated p-3 text-center">
          <span className="text-xs text-foreground-muted block">Input Indent</span>
          <span className="text-sm font-bold text-accent">
            {detectedIndent}
          </span>
        </div>
      </div>

      {/* Editor & Output Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Pane */}
        <div className="space-y-2">
          <label
            htmlFor={inputId}
            className="block text-2xs text-foreground-subtle"
          >
            Raw JSON or JSONC Input
          </label>
          <textarea
            id={inputId}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste raw unformatted JSON or JSONC here..."
            rows={16}
            className="w-full resize-y rounded-lg bg-surface-elevated p-3 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent sm:text-sm"
            spellCheck={false}
          />
        </div>

        {/* Formatted Output Pane */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-2xs text-foreground-subtle">
              Formatted & Cleaned JSON
            </span>
            {formatResult.hadComments && (
              <span className="text-xs font-mono text-warn">
                Comments stripped
              </span>
            )}
          </div>

          {!formatResult.success ? (
            <div className="p-4 bg-danger-soft border border-danger rounded-lg space-y-2 font-mono">
              <div className="text-xs font-bold text-danger">
                Syntax Error at Line {formatResult.line}, Column {formatResult.column}:
              </div>
              <div className="text-xs text-danger">
                {formatResult.error}
              </div>
              {formatResult.caretSnippet && (
                <pre className="text-xs bg-surface p-2 rounded border border-danger overflow-x-auto text-danger">
                  {formatResult.caretSnippet}
                </pre>
              )}
            </div>
          ) : (
            <pre className="h-[382px] w-full select-all overflow-auto whitespace-pre rounded-lg bg-surface-elevated p-3 font-mono text-xs leading-relaxed text-foreground sm:text-sm">
              {formatResult.formatted}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}
