import React from "react";
import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import {
  absoluteUrl,
  SITE_NAME,
  CONTENT_FIRST_PUBLISHED,
  CONTENT_LAST_REVIEWED,
} from "../../lib/site";
import FaqSection from "@/components/common/FaqSection";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import { ToolPageFrame } from "@/components/tools/ToolPageFrame";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import JsonFormatterClient from "./JsonFormatterClient";
import Link from "next/link";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-formatter",
  title: "JSON Formatter — Format, Sort and Validate",
  socialTitle: "JSON Formatter",
  description:
    "Online JSON formatter and beautifier. Indent with 2 spaces, 4 spaces or tabs, sort object keys alphabetically, and strip comments — privately, in-browser.",
});

const faqs = [
  {
    question: "What is the difference between alphabetical sort and natural key sort?",
    answer:
      "Standard alphabetical (lexicographical) sorting compares character code points sequentially. Under alphabetical sort, 'key10' precedes 'key2' because the character '1' has a lower ASCII code point than '2'. Natural key sorting recognizes embedded numeric sequences and sorts them numerically, so 'key1', 'key2', and 'key10' appear in expected human order.",
  },
  {
    question: "Why does RFC 8259 prohibit comments in standard JSON?",
    answer:
      "Douglas Crockford deliberately removed comments from standard JSON around 2001 to prevent developers from using comments to hold parsing directives or metadata, which famously caused interoperability failures in early HTML and XML ecosystems. Modern configuration formats like JSONC (JSON with Comments) allow '//' and '/* */', but standard REST APIs and parsers strictly reject them. The ToolsByUs formatter automatically strips comments while preserving strings.",
  },
  {
    question: "When should I escape Unicode characters to \\uXXXX sequences?",
    answer:
      "Escaping non-ASCII characters to \\uXXXX escape sequences is essential when transmitting JSON across legacy transport channels, 7-bit ASCII protocols, or systems that lack reliable UTF-8 locale configurations. In contrast, unescaping \\uXXXX back to native UTF-8 characters reduces payload size and enhances readability for human editors.",
  },
  {
    question: "Should I indent with 2 spaces, 4 spaces, or tabs?",
    answer:
      "Two spaces is the de facto standard in JavaScript, TypeScript, and modern web APIs, balancing readability with horizontal space conservation. Four spaces is common in Python, Java, and C++ ecosystems. Tabs provide true user-side accessibility, allowing each developer to configure their editor's tab width visually without altering file byte counts.",
  },
  {
    question: "Does this formatter store or log my formatted JSON data?",
    answer:
      "Never. All formatting, key sorting, unicode conversions, and comment removals occur exclusively in client-side memory inside your web browser. Zero network calls or API requests are dispatched.",
  },
];

export default function JsonFormatterPage() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "@id": `${absoluteUrl("/json-formatter")}#webpage`,
      url: absoluteUrl("/json-formatter"),
      name: "JSON Formatter",
      inLanguage: "en",
      datePublished: CONTENT_FIRST_PUBLISHED,
      dateModified: CONTENT_LAST_REVIEWED,
      author: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
      publisher: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
    },
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      name: "JSON Formatter",
      url: absoluteUrl("/json-formatter"),
      description:
        "Format, indent, clean, and sort JSON object keys in-browser with zero tracking and full offline support.",
      applicationCategory: "DeveloperApplication",
      operatingSystem: "Any",
      browserRequirements: "Requires a modern browser with JavaScript enabled",
      // These three pages predate ToolShell and build their own graph, so they
      // were the only tools on the site not declaring that they are free — the
      // signal an aggregator or an AI answer reads to say "no sign-up".
      isAccessibleForFree: true,
      offers: {
        "@type": "Offer",
        price: "0",
        priceCurrency: "USD",
        availability: "https://schema.org/InStock",
      },
      featureList: [
        "RFC 8259 parsing with line and column errors",
        "JSONC comment stripping",
        "Alphabetical key sorting at every level",
        "2-space, 4-space and tab indentation",
        "Runs entirely in the browser, no upload",
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "JSON Formatter",
          item: absoluteUrl("/json-formatter"),
        },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: f.answer,
        },
      })),
    },
  ];

  return (
    <>
      <SchemaJsonLd schemas={jsonLdData} />

      <ToolPageFrame
        keyword="JSON Formatter"
        category="json"
        breadcrumbs={[
          { label: "JSON Formatter", href: "/json-formatter" },
        ]}
        directAnswer={
          <>
            JSON Formatter re-indents a JSON document to 2 spaces, 4 spaces or tabs, optionally sorts object keys alphabetically, and strips JSONC comments — without changing a single value. Parsing, formatting and serialization all run in your browser, so the payload never leaves the page.
          </>
        }
        tool={<JsonFormatterClient />}
      >


      {/* Technical Documentation (>= 700 words) */}
      <section className="space-y-5">
        <h2 className="heading-hash">
          How does JSON formatting work?
        </h2>

        <p className="text-sm text-foreground-muted leading-relaxed">
          JavaScript Object Notation (JSON) is specified internationally by <strong>RFC 8259</strong>,
          ECMA-404, and ISO/IEC 21778:2017. As a language-independent text interchange format, JSON has
          supplanted XML, YAML, and custom binary formats across modern web APIs, microservice RPCs, and
          NoSQL document stores. While JSON is syntactically simple, formatting and normalizing arbitrary
          JSON documents requires deep consideration of whitespace semantics, character encodings, object key
          ordering, comment conventions, and syntactical sanitization.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Whitespace Grammar in RFC 8259
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          In RFC 8259 Section 2, the JSON lexical specification defines exactly four allowable whitespace
          characters that may exist before or after any structural token (<code>[</code>, <code>&#123;</code>,
          <code>]</code>, <code>&#125;</code>, <code>:</code>, and <code>,</code>):
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-1 font-mono">
          <li>Space (ASCII 0x20)</li>
          <li>Horizontal Tab (ASCII 0x09)</li>
          <li>Line Feed (ASCII 0x0A)</li>
          <li>Carriage Return (ASCII 0x0D)</li>
        </ul>
        <p className="text-sm text-foreground-muted leading-relaxed">
          No other Unicode whitespace characters—such as Non-Breaking Space (<code>\u00A0</code>), Zero-Width
          Space (<code>\u200B</code>), or Em Space (<code>\u2003</code>)—are permitted outside of quoted
          string literals. When a document contains illegal Unicode whitespace between structural tokens,
          standard parsers immediately throw fatal syntax exceptions. Formatting JSON involves parsing the
          raw token stream, stripping extraneous whitespace, and re-synthesizing indentation according to
          precise nesting depth rules.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Indentation Strategies: 2 Spaces, 4 Spaces, vs. Tabs
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          The choice of indentation profoundly affects file readability and line wrapping in code review
          tools. The three dominant formatting standards serve different development paradigms:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-4 bg-surface rounded-lg border border-border space-y-2">
            <span className="font-bold text-foreground block">2 Spaces Indentation</span>
            <p className="text-foreground-muted">
              The modern standard across JavaScript, TypeScript, Node.js, and React. Conserves horizontal
              real estate in deeply nested JSON structures, preventing excessive line wrapping on laptop
              displays and terminal splits.
            </p>
          </div>
          <div className="p-4 bg-surface rounded-lg border border-border space-y-2">
            <span className="font-bold text-foreground block">4 Spaces Indentation</span>
            <p className="text-foreground-muted">
              Prevalent in Python, Java, C#, and Go backend ecosystems. Provides clear visual hierarchy for
              shallow to moderately nested structures, making structural block boundaries immediately
              obvious.
            </p>
          </div>
          <div className="p-4 bg-surface rounded-lg border border-border space-y-2">
            <span className="font-bold text-foreground block">Tab Indentation (\t)</span>
            <p className="text-foreground-muted">
              The accessibility champion. Storing literal tab characters allows each developer to adjust
              their display width (2, 4, or 8 columns) without modifying the underlying bytes in version control.
            </p>
          </div>
        </div>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Object Key Ordering: Lexicographical vs. Natural Sorting
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          RFC 8259 Section 4 explicitly dictates that JSON objects consist of unordered collections of zero
          or more name/value pairs. Consequently, JSON parsers do not guarantee key order preservation.
          However, in version control diffs (e.g. Git) and human data audits, fluctuating key order causes
          massive false diffs. Sorting object keys restores deterministic canonical serialization:
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-2">
          <li className="text-sm text-foreground-muted">
            <strong>Alphabetical (A-Z) Sort:</strong> Uses standard Unicode code point comparison. Fast and
            deterministic, but causes numbers in keys to sort counterintuitively (e.g., <code>&quot;item1&quot;</code>,
            <code>&quot;item10&quot;</code>, <code>&quot;item2&quot;</code>).
          </li>
          <li className="text-sm text-foreground-muted">
            <strong>Natural Sort:</strong> Evaluates numeric chunks inside key strings as numbers rather than
            ASCII characters. Produces intuitive human ordering (e.g., <code>&quot;step1&quot;</code>,
            <code>&quot;step2&quot;</code>, <code>&quot;step10&quot;</code>).
          </li>
        </ul>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Handling Unicode: Escaping vs. Native Characters
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          All JSON text MUST be encoded using Unicode, with UTF-8 as the mandatory default according to
          RFC 8259 Section 8.1. Within string literals, any character may be represented directly as UTF-8
          or escaped via six-character sequences beginning with <code>\u</code> followed by four hexadecimal
          digits (e.g. <code>\u00A9</code> for &copy;).
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Escaping non-ASCII characters guarantees that payloads can survive transmission through legacy
          systems that corrupt high-order UTF-8 bytes. Conversely, unescaping these sequences into native UTF-8
          characters drastically improves human readability in multilingual payloads and saves up to 50%
          of file size in non-Latin scripts (Arabic, Cyrillic, Chinese, Japanese, Hebrew).
        </p>
      </section>

      {/* Keyboard Shortcuts Reference */}
      <section className="rounded-xl bg-surface p-6 space-y-4">
        <h2 className="heading-hash">
          Which keyboard shortcuts does the JSON formatter support?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Ctrl + Enter / Cmd + Enter</span>
            <span className="text-foreground-muted">Focus formatted output and copy to clipboard</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Tab / Shift+Tab</span>
            <span className="text-foreground-muted">Cycle between indent options, sorting, and editor controls</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Escape</span>
            <span className="text-foreground-muted">Clear input focus and dismiss active modals</span>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FaqSection faqs={faqs} />

      {/* Related Tools */}
      <section className="space-y-4">
        <h2 className="heading-hash">
          Which related tools should I use next?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link
            href="/json-beautifier"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Beautifier &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Beautify JSON with custom color themes and auto-fix capabilities.
            </p>
          </Link>
          <Link
            href="/json-minifier"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Minifier &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Compress formatted JSON and analyze gzip payload reduction.
            </p>
          </Link>
          <Link
            href="/json-diff"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Diff & Patch &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Compare formatted documents semantically with key order invariance.
            </p>
          </Link>
        </div>
      </section>

      <ReviewedStamp href="/json-formatter" />
      </ToolPageFrame>
    </>
  );

}
