import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonMinifierClient } from "./JsonMinifierClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-minifier",
  title: "JSON Minifier — Strip Whitespace, See Gzip",
  socialTitle: "JSON Minifier",
  description:
    "Compress JSON documents by stripping whitespace, estimating gzip wire size, and analyzing key frequency compression opportunities.",
});

export default function JsonMinifierPage() {
  return <JsonMinifierClient />;
}
