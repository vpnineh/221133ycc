"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { field, fieldLabel, panel, panelHeader } from "../../components/common/controls";
import { parseJson } from "../../lib/json/parser";
import { flattenTree, summarise, type JsonNodeType } from "../../lib/json/tree";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `{
  "id": 9007199254740993,
  "price": 0.1,
  "ratio": 1e-7,
  "active": true,
  "deletedAt": null,
  "name": "Ada",
  "tags": ["a", "b"],
  "meta": {}
}`;

type Language = "javascript" | "python" | "go" | "java" | "csharp";

/**
 * How each JSON type lands in a host language.
 *
 * This is the part people actually get wrong, and it is invisible in a
 * validator: the document is fine, and what your language makes of it is not
 * what you assumed.
 */
const TYPE_MAP: Record<Language, Record<JsonNodeType, string>> = {
  javascript: {
    object: "object",
    array: "Array",
    string: "string",
    number: "number (IEEE-754 double)",
    boolean: "boolean",
    null: "null",
  },
  python: {
    object: "dict",
    array: "list",
    string: "str",
    number: "int or float",
    boolean: "bool",
    null: "None",
  },
  go: {
    object: "map[string]any",
    array: "[]any",
    string: "string",
    number: "float64 (unless typed)",
    boolean: "bool",
    null: "nil",
  },
  java: {
    object: "Map<String,Object>",
    array: "List<Object>",
    string: "String",
    number: "Double / BigDecimal",
    boolean: "Boolean",
    null: "null",
  },
  csharp: {
    object: "Dictionary<string,object>",
    array: "List<object>",
    string: "string",
    number: "double / decimal",
    boolean: "bool",
    null: "null",
  },
};

const LANGUAGE_LABEL: Record<Language, string> = {
  javascript: "JavaScript",
  python: "Python",
  go: "Go",
  java: "Java",
  csharp: "C#",
};

/** Numbers that do not survive a round trip through an IEEE-754 double. */
function findLossyNumbers(input: string): string[] {
  const out: string[] = [];
  // Scanned from the source text rather than the parsed value, because by the
  // time it is parsed the precision is already gone.
  for (const match of input.matchAll(/-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g)) {
    const literal = match[0];
    if (!/^-?\d+$/.test(literal)) continue;
    const value = Number(literal);
    if (!Number.isSafeInteger(value) && String(value) !== literal) out.push(literal);
  }
  return [...new Set(out)].slice(0, 8);
}

export const JsonParserClient: React.FC = () => {
  const [raw, setRaw] = useState(SAMPLE);
  const [language, setLanguage] = useState<Language>("javascript");

  const parsed = useMemo(() => parseJson(raw), [raw]);
  const stats = useMemo(
    () => (parsed.success ? summarise(flattenTree(parsed.data)) : null),
    [parsed]
  );
  const lossy = useMemo(() => (parsed.success ? findLossyNumbers(raw) : []), [parsed, raw]);

  const counts: Array<[JsonNodeType, number]> = stats
    ? [
        ["object", stats.objects],
        ["array", stats.arrays],
        ["string", stats.strings],
        ["number", stats.numbers],
        ["boolean", stats.booleans],
        ["null", stats.nulls],
      ]
    : [];

  return (
    <ToolShell
      wide
      slug="json-parser"
      keyword="JSON Parser"
      directAnswer="JSON Parser parses a document to RFC 8259 in your browser and reports what it actually contains: how many values of each type, how deep the structure goes, and what each type becomes in your language. It also flags the integers that silently lose precision when parsed as a double."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON Parser", url: "/json-parser" },
      ]}
      seoDescription="Parse JSON in your browser to RFC 8259 and see what it contains: type counts, structure depth, language type mappings, and integers that lose precision as IEEE-754 doubles."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              &ldquo;Does it parse?&rdquo; is a question the{" "}
              <a href="/json-validator">validator</a> answers. This tool answers the next one, which
              is usually the more interesting one: <em>what did it parse into?</em> A document can
              be perfectly valid and still not be the thing your code is expecting, and the gap is
              rarely visible by reading it.
            </p>
            <p>
              The parser is hand-written rather than a call to <code>JSON.parse</code>, for reasons
              that matter here. It is iterative, with an explicit work stack, so a deeply nested
              document reports an error instead of overflowing the JavaScript call stack. It rejects
              trailing content after the root value, which <code>JSON.parse</code> also does but
              many hand-rolled parsers forget. And every key from the document is assigned as an own
              property through a guard, so a payload containing <code>__proto__</code> becomes a
              real key rather than altering the prototype of the object being built — which is the
              standard prototype-pollution vector for anything that parses untrusted JSON.
            </p>
            <p>
              The analysis then walks the parsed value and counts what is there: how many objects,
              arrays, strings, numbers, booleans and nulls, how deep the nesting goes, and how many
              distinct keys appear. That is often enough on its own to spot the problem — an array
              you expected to hold objects holding only strings, a structure three levels deeper
              than the schema allows, a document that is 90% nulls because an upstream join failed.
            </p>
            <p>
              The type-mapping table addresses the mistake that causes the most real bugs. JSON has
              one number type, and RFC 8259 places no limit on its magnitude, but almost every
              parser represents it as an IEEE-754 double. That gives exact integers only up to
              2<sup>53</sup>−1. An ID of <code>9007199254740993</code> parses without complaint and
              comes back as <code>9007199254740992</code>, and nothing anywhere reports an error.
              Those literals are detected from the source text — by the time the value is parsed the
              precision is already gone — and listed explicitly.
            </p>
            <p>
              The same table shows the rest of the mapping, because the assumptions differ by
              language. Go gives you <code>float64</code> for every number unless you decode into a
              typed struct. Python distinguishes <code>int</code> from <code>float</code> and so
              keeps large integers exactly. Java and C# reach for <code>BigDecimal</code> or{" "}
              <code>decimal</code> when configured to.
            </p>
          </>
        ),
        inputTitle: "Document",
        exampleInput: `{ "id": 9007199254740993, "price": 0.1 }`,
        outputTitle: "What it parses to",
        exampleOutput: `2 values · depth 1 · 2 distinct keys

number   2   →  number (IEEE-754 double)

Precision loss:
  9007199254740993 → 9007199254740992`,
      }}
      referenceTable={{
        title: "Parsing rules and what they catch",
        rows: [
          {
            parameter: "Grammar",
            type: "RFC 8259",
            defaultVal: "strict",
            description:
              "No comments, no trailing commas, no single quotes, no unquoted keys, no NaN or Infinity. A document that parses here is one an API will accept; JSON5 and JSONC are deliberately rejected.",
          },
          {
            parameter: "Trailing content",
            type: "rejected",
            defaultVal: "—",
            description:
              "RFC 8259 §2 defines a document as exactly one value. Two concatenated objects are a common symptom of a log line that was split wrongly, and are reported rather than silently truncated at the first.",
          },
          {
            parameter: "Number precision",
            type: "IEEE-754",
            defaultVal: "flagged",
            description:
              "Integers beyond 2^53-1 are listed with the value they actually become. Detected from the source text, because after parsing the original digits no longer exist anywhere.",
          },
          {
            parameter: "Duplicate keys",
            type: "last wins",
            defaultVal: "—",
            description:
              "RFC 8259 leaves this undefined; nearly every parser keeps the last occurrence, and this one matches that. Worth knowing, because it is a real attack surface when two systems in a chain disagree.",
          },
          {
            parameter: "__proto__",
            type: "own property",
            defaultVal: "—",
            description:
              "Assigned via defineProperty, so it becomes a normal key rather than re-pointing the prototype. Matches JSON.parse, and is the guard most hand-rolled parsers are missing.",
          },
          {
            parameter: "Nesting depth",
            type: "iterative",
            defaultVal: "no limit",
            description:
              "The parser uses an explicit stack, so depth is bounded by memory rather than by the call stack. A 20,000-level document is covered by a test.",
          },
          {
            parameter: "Unicode",
            type: "UTF-8",
            defaultVal: "—",
            description:
              "\\uXXXX escapes are decoded, and surrogate pairs are recombined so astral characters survive. A byte-order mark before the root is reported rather than treated as content.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "Main-thread ceiling. Above it the parse is declined rather than attempted. Nothing is uploaded at any size.",
          },
        ],
      }}
      faqs={[
        {
          question: "How is this different from the JSON Validator?",
          answer:
            "The validator answers whether the document parses and where it breaks if not, with a caret on the offending character and a one-click repair. This one assumes it parses and tells you what came out: type counts, depth, distinct keys, the language mapping, and any integers that lost precision. Use the validator when something is broken and this when something is valid but behaving oddly.",
        },
        {
          question: "My ID changed value after parsing. What happened?",
          answer:
            "It exceeded 2^53-1 and was parsed as an IEEE-754 double, which cannot represent every integer above that. 9007199254740993 becomes 9007199254740992 with no error anywhere. This tool lists those literals explicitly. The fixes are to transmit large IDs as strings, or to use a parser that maps integers to a big-integer type — Python does this natively; Go, Java and C# need configuring.",
        },
        {
          question: "What happens with duplicate keys?",
          answer:
            "The last occurrence wins, which is what nearly every parser does and what RFC 8259 declines to specify. It is worth knowing about rather than ignoring: if two systems in a request chain resolve duplicates differently, a payload can be validated against one interpretation and acted on under another, which is a genuine class of security bug.",
        },
        {
          question: "Why does it reject my JSON with comments?",
          answer:
            "Because RFC 8259 has no comments, and the point of a strict parser is to tell you what an API will accept. If your file is a config — tsconfig.json, .eslintrc.json — it is JSONC, and the JSON Formatter accepts comments and trailing commas and can strip them for you.",
        },
        {
          question: "Is 0.1 exactly 0.1 after parsing?",
          answer:
            "No, and this is not a JSON problem — it is binary floating point. 0.1 has no exact representation as a double in any language, which is why 0.1 + 0.2 is famously not 0.3. For currency, the standard answer is to carry integer minor units (pence, cents) or a decimal string, never a float.",
        },
        {
          question: "Is my document sent anywhere?",
          answer:
            "No. Parsing and analysis run in the tab you already have open. Open the Network panel and paste one — nothing carrying it leaves, and every tool here keeps working with the network disconnected entirely.",
        },
      ]}
      relatedTools={relatedTools("/json-parser").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <label htmlFor="language" className={fieldLabel}>
            Target language
          </label>
          <select
            id="language"
            className={`${field} cursor-pointer`}
            value={language}
            onChange={(e) => setLanguage(e.target.value as Language)}
          >
            {(Object.keys(LANGUAGE_LABEL) as Language[]).map((key) => (
              <option key={key} value={key}>
                {LANGUAGE_LABEL[key]}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label="JSON document"
            value={raw}
            onChange={setRaw}
            placeholder="Paste a JSON document…"
            height={360}
            error={!parsed.success ? parsed.error : undefined}
          />

          <div className="space-y-4">
            {!parsed.success ? (
              <Notice tone="danger" title="Does not parse:">
                Line {parsed.error.line}, column {parsed.error.column} — {parsed.error.message}. The{" "}
                <a href="/json-validator">JSON Validator</a> can repair most of these in one click.
              </Notice>
            ) : (
              <>
                <dl className="grid grid-cols-3 gap-x-4 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
                  {[
                    ["Values", String(stats!.nodes)],
                    ["Max depth", String(stats!.maxDepth)],
                    ["Distinct keys", String(stats!.uniqueKeys)],
                  ].map(([label, value]) => (
                    <div key={label}>
                      <dt className="font-mono text-2xs text-foreground-subtle">
                        {label}
                      </dt>
                      <dd className="mt-0.5 font-mono text-sm font-bold text-foreground">{value}</dd>
                    </div>
                  ))}
                </dl>

                <div className={panel}>
                  <div className={panelHeader}>
                    <span className="text-xs font-semibold text-foreground">
                      Types, and what they become in {LANGUAGE_LABEL[language]}
                    </span>
                  </div>
                  <table className="w-full border-collapse text-left text-xs">
                    <caption className="sr-only">Type counts and language mapping</caption>
                    <thead className="bg-surface-elevated">
                      <tr className="border-b border-border">
                        <th scope="col" className="px-3 py-1.5 font-mono text-2xs text-foreground-subtle">
                          JSON type
                        </th>
                        <th scope="col" className="px-3 py-1.5 font-mono text-2xs text-foreground-subtle">
                          Count
                        </th>
                        <th scope="col" className="px-3 py-1.5 font-mono text-2xs text-foreground-subtle">
                          {LANGUAGE_LABEL[language]}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {counts.map(([type, count]) => (
                        <tr key={type} className={count === 0 ? "opacity-40" : ""}>
                          <th scope="row" className="px-3 py-1.5 text-left font-mono font-medium text-accent">
                            {type}
                          </th>
                          <td className="px-3 py-1.5 font-mono text-foreground">{count}</td>
                          <td className="px-3 py-1.5 font-mono text-foreground-muted">
                            {TYPE_MAP[language][type]}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {lossy.length > 0 && (
                  <Notice tone="warn" title="Integers that lose precision:">
                    <span className="font-mono">
                      {lossy.map((literal) => `${literal} → ${Number(literal)}`).join(", ")}
                    </span>
                    . These exceed 2<sup>53</sup>−1 and cannot be represented exactly as an
                    IEEE-754 double. No parser reports an error; the value simply changes. Transmit
                    identifiers this large as strings.
                  </Notice>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </ToolShell>
  );
};
