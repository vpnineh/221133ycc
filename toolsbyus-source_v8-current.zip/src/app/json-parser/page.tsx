import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonParserClient } from "./JsonParserClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-parser",
  title: "JSON Parser — See What a Document Contains",
  socialTitle: "JSON Parser",
  description:
    "Parse JSON to RFC 8259 in your browser and see what it contains: type counts, structure depth, language type mappings, and integers that lose precision as doubles.",
});

export default function JsonParserPage() {
  return <JsonParserClient />;
}
