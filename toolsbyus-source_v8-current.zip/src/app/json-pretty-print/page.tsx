import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonPrettyPrintClient } from "./JsonPrettyPrintClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-pretty-print",
  title: "JSON Pretty Print — In 11 Languages",
  socialTitle: "JSON Pretty Print",
  description:
    "Pretty-print JSON here, or copy the line that does it in JavaScript, Python, Go, Java, C#, PHP, Ruby, Rust, jq or PowerShell — gotchas included.",
});

export default function JsonPrettyPrintPage() {
  return <JsonPrettyPrintClient />;
}
