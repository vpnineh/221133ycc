"use client";

import React, { useState, useMemo } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { inferSchemaFromSamples, SchemaInferOptions } from "../../lib/schema/infer";
import { validateAgainstSchema, ValidationResult } from "../../lib/schema/validate";
import { parseJson } from "../../lib/json/parser";
import { checkbox } from "../../components/common/controls";

const DEFAULT_SAMPLES = JSON.stringify(
  [
    {
      id: "usr_99182",
      name: "Morgan Lee",
      email: "morgan.lee@enterprise.internal",
      registeredAt: "2026-09-01T12:00:00Z",
      role: "admin",
      status: "active",
      loginCount: 142,
      preferences: {
        theme: "dark",
        notifications: true,
      },
    },
    {
      id: "usr_99183",
      name: "Taylor Chen",
      email: "taylor.chen@enterprise.internal",
      registeredAt: "2026-09-02T15:30:00Z",
      role: "editor",
      status: "active",
      loginCount: 45,
      preferences: {
        theme: "light",
        notifications: false,
      },
    },
  ],
  null,
  2
);

const DEFAULT_TEST_DOC = JSON.stringify(
  {
    id: "usr_99184",
    name: "Alex Rivera",
    email: "invalid-email-address", // Format error
    registeredAt: "2026-09-03T09:15:00Z",
    role: "superadmin", // Enum violation
    status: "active",
    // Missing loginCount (Required property violation)
  },
  null,
  2
);

export const JsonSchemaClient: React.FC = () => {
  const [samplesRaw, setSamplesRaw] = useState(DEFAULT_SAMPLES);
  const [testDocRaw, setTestDocRaw] = useState(DEFAULT_TEST_DOC);

  const [inferRequired, setInferRequired] = useState(true);
  const [typeWidening, setTypeWidening] = useState(true);
  const [detectFormats, setDetectFormats] = useState(true);
  const [enumThreshold, setEnumThreshold] = useState(4);

  // 1. Infer Schema
  const { generatedSchema, schemaError, schemaString } = useMemo(() => {
    const parseRes = parseJson(samplesRaw);
    if (!parseRes.success) {
      return {
        generatedSchema: null,
        schemaError: `Sample JSON syntax error: ${parseRes.error.message}`,
        schemaString: "",
      };
    }

    const samples = Array.isArray(parseRes.data) ? parseRes.data : [parseRes.data];
    const opts: SchemaInferOptions = {
      inferRequired,
      typeWidening,
      detectFormats,
      enumThreshold,
    };

    const schema = inferSchemaFromSamples(samples, opts);
    return {
      generatedSchema: schema,
      schemaError: null,
      schemaString: JSON.stringify(schema, null, 2),
    };
  }, [samplesRaw, inferRequired, typeWidening, detectFormats, enumThreshold]);

  // 2. Validate Test Document against Generated Schema
  const validationResult: ValidationResult | null = useMemo(() => {
    if (!generatedSchema) return null;
    const parseTest = parseJson(testDocRaw);
    if (!parseTest.success) {
      return {
        valid: false,
        errors: [{ path: "/", keyword: "syntax", message: `Test doc syntax error: ${parseTest.error.message}` }],
      };
    }
    return validateAgainstSchema(parseTest.data, generatedSchema);
  }, [testDocRaw, generatedSchema]);

  return (
    <ToolShell
      wide
      slug="json-schema-generator"
      keyword="JSON Schema Generator"
      directAnswer="JSON Schema Generator automatically infers standard JSON Schema (Draft 2020-12) specifications from one or more sample JSON payloads. It features configurable required-field heuristics, type widening across heterogeneous samples, automatic format detection (email, date-time, uuid, uri), enum discovery, and live document validation against the inferred schema on the same page."
      seoDescription="Infer Draft 2020-12 JSON Schema from sample payloads and validate documents against the generated schema in real time."
      breadcrumbs={[{ name: "JSON Schema Generator", url: "/json-schema-generator" }]}
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Manually authoring JSON Schema definitions is repetitive, verbose, and error-prone. The ToolsByUs Schema Inference engine automates this by performing multi-pass structural aggregation across your input samples:
            </p>
            <ul className="list-disc pl-5 space-y-1 my-2">
              <li><strong>Type Inference & Widening:</strong> Recursively examines data values. When differing scalar types are observed across samples for the same key (e.g. integer and string), type widening produces an array of allowed types <code>type: [&quot;integer&quot;, &quot;string&quot;]</code> rather than rejecting valid variations.</li>
              <li><strong>Required Field Heuristics:</strong> Computes frequency ratios. Properties present across 100% of analyzed sample records are cataloged in the <code>required</code> constraint array.</li>
              <li><strong>Format & Semantic Matching:</strong> Matches string fields against RFC standards for <code>date-time</code> (ISO 8601), <code>email</code> (RFC 5322), <code>uuid</code> (RFC 4122/9562), and <code>uri</code> (RFC 3986).</li>
              <li><strong>Enum Extraction:</strong> Detects repetitive low-cardinality values below a configurable threshold (e.g. status fields) and generates strict <code>enum</code> sets.</li>
            </ul>
            <p>
              Most importantly, the generator includes an interactive <strong>Round-Trip Validator</strong>: you can paste any candidate payload and immediately test it against the generated schema to verify conformance.
            </p>
          </>
        ),
        inputTitle: "Sample Payload Input",
        exampleInput: `{"id": "usr_101", "email": "dev@test.org", "active": true}`,
        exampleOutput: `{\n  "$schema": "https://json-schema.org/draft/2020-12/schema",\n  "type": "object",\n  "required": ["id", "email", "active"],\n  "properties": {\n    "id": { "type": "string" },\n    "email": { "type": "string", "format": "email" },\n    "active": { "type": "boolean" }\n  }\n}`,
      }}
      referenceTable={{
        title: "Schema Inference Options & Dial Rules",
        rows: [
          {
            parameter: "inferRequired",
            type: "Boolean",
            defaultVal: "true",
            description: "Automatically tags properties that appear in every provided sample as required.",
          },
          {
            parameter: "typeWidening",
            type: "Boolean",
            defaultVal: "true",
            description: "Allows fields with multiple observed types to support any of those types rather than forcing one.",
          },
          {
            parameter: "detectFormats",
            type: "Boolean",
            defaultVal: "true",
            description: "Inspects string patterns for RFC formats: email, date-time, uuid, and uri.",
          },
          {
            parameter: "enumThreshold",
            type: "Integer",
            defaultVal: "4",
            description: "Maximum unique value count to classify a string/number property as a fixed enum set.",
          },
          {
            parameter: "Schema Draft",
            type: "Standard",
            defaultVal: "Draft 2020-12",
            description: "Emits modern, fully compliant JSON Schema specification draft 2020-12.",
          },
        ],
      }}
      faqs={[
        {
          question: "What version of JSON Schema does this tool generate?",
          answer:
            "This tool outputs JSON Schema Draft 2020-12, the latest stable specification recommended by the JSON Schema organization. It is compatible with modern validation libraries across Python, Node.js, Go, Rust, and Java.",
        },
        {
          question: "Can I supply multiple sample documents?",
          answer:
            "Yes! You can paste either a single JSON object or a JSON array of multiple objects. The generator aggregates property shapes across all samples to produce comprehensive schemas with union types and accurate required field heuristics.",
        },
        {
          question: "How does the live validation work?",
          answer:
            "The lower pane runs a real-time schema validator against whatever schema is currently generated. As you modify sample data or options above, the test document is immediately validated with exact violation paths and keywords displayed.",
        },
        {
          question: "Is my sample schema or data transmitted to a server?",
          answer:
            "No. All schema inference and validation execute 100% locally in your browser with zero network requests, preserving complete privacy for proprietary schemas and production logs.",
        },
      ]}
      relatedTools={[
        {
          href: "/json-validator",
          title: "JSON Validator",
          description: "Validate JSON syntax against RFC 8259 with exact line and column caret tracking.",
        },
        {
          href: "/json-diff",
          title: "JSON Diff",
          description: "Compare JSON documents with AST semantic invariance and array key matching.",
        },
        {
          href: "/json-editor",
          title: "JSON Editor",
          description: "Interactive synchronized tree and text editor with JSONPath query search.",
        },
        {
          href: "/json-formatter",
          title: "JSON Formatter",
          description: "Beautify and indent JSON payloads with comment support and key sorting.",
        },
      ]}
    >
      <div className="space-y-6">
        {/* Controls Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-border bg-surface text-xs font-mono">
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted">
              <input
                type="checkbox"
                checked={inferRequired}
                onChange={(e) => setInferRequired(e.target.checked)}
                className={checkbox}
              />
              <span>Infer Required Fields</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted">
              <input
                type="checkbox"
                checked={typeWidening}
                onChange={(e) => setTypeWidening(e.target.checked)}
                className={checkbox}
              />
              <span>Type Widening</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-foreground-muted">
              <input
                type="checkbox"
                checked={detectFormats}
                onChange={(e) => setDetectFormats(e.target.checked)}
                className={checkbox}
              />
              <span>Detect Formats (date, email, uuid)</span>
            </label>

            <div className="flex items-center gap-1.5">
              <label htmlFor="enum-thresh" className="text-foreground-muted">
                Enum Threshold:
              </label>
              <input
                id="enum-thresh"
                type="number"
                min={1}
                max={20}
                value={enumThreshold}
                onChange={(e) => setEnumThreshold(parseInt(e.target.value, 10) || 4)}
                className="w-14 px-2 py-0.5 rounded bg-surface-elevated border border-border text-foreground text-xs font-mono"
              />
            </div>
          </div>
        </div>

        {/* Inference Grid: Left = Samples, Right = Inferred Schema */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CodePane
            label="Sample Input (Single Object or Array of Samples)"
            value={samplesRaw}
            onChange={setSamplesRaw}
            placeholder="Paste sample JSON..."
          />
          <CodePane
            label="Generated JSON Schema (Draft 2020-12)"
            value={schemaString}
            onChange={() => {}}
            readOnly
            error={schemaError ? { message: schemaError } : undefined}
          />
        </div>

        {/* Round-Trip Verification: Validate Another Document on the same page */}
        <div className="p-4 rounded-lg border border-border bg-surface space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3">
            <div>
              <h2 className="font-mono text-sm font-bold text-foreground flex items-center gap-2">
                <span className="text-accent">✓</span>
                <span>Round-Trip Validation Test</span>
              </h2>
              <p className="text-xs text-foreground-muted mt-0.5">
                Validate candidate JSON documents against the generated schema in real time.
              </p>
            </div>

            {validationResult && (
              <div
                className={`px-3 py-1 rounded-full text-xs font-mono font-semibold flex items-center gap-1.5 ${
                  validationResult.valid
                    ? "bg-accent-soft text-accent border border-accent-line"
                    : "bg-danger-soft text-danger border border-danger"
                }`}
              >
                <span>{validationResult.valid ? "✓ Document Valid" : `✕ ${validationResult.errors.length} Validation Errors`}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <CodePane
              label="Candidate Document to Validate"
              value={testDocRaw}
              onChange={setTestDocRaw}
              placeholder="Paste document to test against generated schema..."
              height={220}
            />

            <div className="flex flex-col rounded-lg border border-border bg-background p-3 text-xs font-mono overflow-auto" style={{ height: 280 }}>
              <span className="font-semibold text-foreground-muted mb-2 border-b border-border pb-1">
                Schema Conformance Report
              </span>
              {validationResult?.valid ? (
                <div className="p-3 rounded bg-accent-soft border border-accent-line text-accent space-y-1">
                  <div className="font-bold">✓ All Constraints Satisfied</div>
                  <div className="text-2xs text-foreground-muted">
                    The document conforms completely to the generated Draft 2020-12 schema rules.
                  </div>
                </div>
              ) : validationResult?.errors ? (
                <div className="space-y-2 overflow-auto">
                  {validationResult.errors.map((err, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded bg-danger-soft border border-danger text-danger text-xs"
                    >
                      <div className="font-bold text-danger">
                        Violation at <span className="text-foreground">{err.path}</span> ({err.keyword})
                      </div>
                      <div className="text-2xs text-danger mt-0.5">{err.message}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-foreground-muted italic">No schema generated to validate against.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </ToolShell>
  );
};
