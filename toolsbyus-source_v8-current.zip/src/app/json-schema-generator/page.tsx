import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonSchemaClient } from "./JsonSchemaClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-schema-generator",
  title: "Schema Generator — JSON Schema 2020-12",
  socialTitle: "Schema Generator",
  description:
    "Infer Draft 2020-12 JSON Schema from sample payloads and validate documents against the generated schema in real time.",
});

export default function JsonSchemaGeneratorPage() {
  return <JsonSchemaClient />;
}
