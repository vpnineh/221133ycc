"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox } from "../../components/common/controls";
import { escapeJsonString, type EscapeOptions } from "../../lib/json/escape";
import { parseJson } from "../../lib/json/parser";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `{
  "service": "checkout",
  "retries": 3,
  "endpoint": "https://api.example.com/v2",
  "note": "Timeout is 3s\\nRetry on 502 only",
  "path": "C:\\\\logs\\\\checkout.log"
}`;

export const JsonStringifyClient: React.FC = () => {
  const [options, setOptions] = useState<EscapeOptions>({
    includeQuotes: true,
    escapeUnicode: false,
    escapeSlashes: false,
  });
  const [requireValid, setRequireValid] = useState(true);

  const transform = useCallback(
    (input: string): TransformOutcome => {
      const warnings: string[] = [];

      if (requireValid) {
        const parsed = parseJson(input);
        if (!parsed.success) {
          return {
            output: "",
            error: `Line ${parsed.error.line}, column ${parsed.error.column}: ${parsed.error.message}. Turn off "Require valid JSON" to escape arbitrary text.`,
          };
        }
      }

      const output = escapeJsonString(input, options);
      if (options.escapeSlashes) {
        warnings.push(
          "Forward slashes are escaped as \\/. That is legal JSON and some log shippers require it, but it is unusual and most parsers do not need it."
        );
      }

      return {
        output,
        warnings,
        stats: [
          { label: "In", value: `${new Blob([input]).size} B` },
          { label: "Out", value: `${new Blob([output]).size} B` },
          {
            label: "Growth",
            value: `${Math.round((new Blob([output]).size / Math.max(1, new Blob([input]).size) - 1) * 100)}%`,
          },
        ],
      };
    },
    [options, requireValid]
  );

  return (
    <ToolShell
      wide
      slug="json-stringify"
      keyword="JSON Stringify"
      directAnswer="JSON Stringify turns a JSON document into a JSON string literal — the escaped, quoted form you need to embed one payload inside another. It escapes quotes, backslashes and control characters in a single pass, so the double-escaping that chained find-and-replace produces cannot happen."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON Stringify", url: "/json-stringify" },
      ]}
      seoDescription="Escape a JSON document into a JSON string literal for embedding in another payload, a config file or a test fixture. Runs in your browser; nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              This is the operation behind a recurring, unglamorous job: putting one payload inside
              another. A request body inside a webhook definition. A fixture inside a test file. A
              configuration document inside a Kubernetes ConfigMap value. A sample response inside
              an OpenAPI <code>example</code> field. In each case the inner document has to become a{" "}
              <em>string</em> in the outer one, which means every quote, backslash and newline
              inside it needs escaping.
            </p>
            <p>
              People do this by hand with find-and-replace, and it goes wrong in a specific,
              predictable way. If you replace the quotes first and the backslashes second, the
              backslash you just introduced in front of each quote gets escaped a second time: you
              wanted <code>\&quot;</code> and you have <code>\\&quot;</code>, which parses as a
              literal backslash followed by the end of the string. The document appears to work
              until something in it contains a quote.
            </p>
            <p>
              Escaping in a single character scan makes that impossible. Each character is examined
              once and mapped once — <code>&quot;</code> to <code>\&quot;</code>,{" "}
              <code>\</code> to <code>\\</code>, newline to <code>\n</code>, tab to{" "}
              <code>\t</code> — with no opportunity for a later pass to re-process an earlier
              pass&rsquo;s output.
            </p>
            <p>
              RFC 8259 requires every control character below U+0020 to be escaped, so anything
              without a shorthand becomes a <code>\u</code> sequence. Non-ASCII characters are left
              alone by default, because modern JSON is UTF-8 and escaping them only makes the
              result larger and less readable. When a target genuinely needs pure ASCII — an older
              log pipeline, a system that mangles high bytes — the option escapes them, and
              correctly emits a surrogate pair for anything outside the Basic Multilingual Plane,
              since a single <code>\u</code> cannot represent an emoji and emitting one truncates it.
            </p>
            <p>
              By default the input is validated as JSON first. Escaping something broken produces a
              string literal that is itself valid but whose contents will fail to parse later,
              somewhere much less convenient. Switch that off to escape arbitrary text, which is
              useful for log lines and shell snippets.
            </p>
          </>
        ),
        inputTitle: "Document",
        exampleInput: `{"name":"Ada","note":"line one\nline two"}`,
        outputTitle: "String literal",
        exampleOutput: `"{\\"name\\":\\"Ada\\",\\"note\\":\\"line one\\nline two\\"}"`,
      }}
      referenceTable={{
        title: "Escaping rules and options",
        rows: [
          {
            parameter: "Wrap in quotes",
            type: "boolean",
            defaultVal: "true",
            description:
              "Emits the surrounding double quotes so the result is a complete JSON string. Turn it off when you are pasting into an existing pair of quotes.",
          },
          {
            parameter: "Escape non-ASCII",
            type: "boolean",
            defaultVal: "false",
            description:
              "Converts every codepoint above U+007E to \\uXXXX. Unnecessary for UTF-8 targets, and it inflates the output. Astral characters correctly emit a surrogate pair rather than a truncated single escape.",
          },
          {
            parameter: "Escape slashes",
            type: "boolean",
            defaultVal: "false",
            description:
              "Writes / as \\/. Legal JSON, required by a few log shippers and by JSON embedded in HTML <script> blocks where </script> would otherwise terminate the element early.",
          },
          {
            parameter: "Require valid JSON",
            type: "boolean",
            defaultVal: "true",
            description:
              "Validates before escaping, so the literal is guaranteed to parse back into the document you started with. Off, it escapes arbitrary text — useful for log lines and shell snippets.",
          },
          {
            parameter: "Control characters",
            type: "always escaped",
            defaultVal: "—",
            description:
              "RFC 8259 forbids raw characters below U+0020 in a string. \\n \\r \\t \\b \\f use their shorthands; everything else becomes \\u00XX.",
          },
          {
            parameter: "Size growth",
            type: "≈ 5–30%",
            defaultVal: "—",
            description:
              "Depends entirely on how many quotes and backslashes the input contains. A JSON document, which is mostly quotes, grows more than prose does.",
          },
        ],
      }}
      faqs={[
        {
          question: "What is the difference between this and JSON.stringify in JavaScript?",
          answer:
            "JSON.stringify takes a JavaScript value and produces JSON text. This takes JSON text and produces a JSON string literal containing it — which is what JSON.stringify(someJsonText) does when you hand it a string. The distinction matters: stringifying an object gives you {\"a\":1}, while stringifying the text {\"a\":1} gives you \"{\\\"a\\\":1}\". This tool does the second.",
        },
        {
          question: "Why did my hand-escaped JSON break?",
          answer:
            "Almost always an ordering mistake. Replacing quotes before backslashes double-escapes the backslash each replacement just introduced, so \\\" becomes \\\\\" and the string terminates early. It works until the document contains a quote — which for JSON is immediately. Scanning each character exactly once, as this does, removes the possibility.",
        },
        {
          question: "How do I reverse it?",
          answer:
            "Use JSON Unescape, which takes the literal and returns the document. It is deliberately tolerant: it copes with a fragment that lost its surrounding quotes, which is the usual state of anything copied out of a log line or a stack trace.",
        },
        {
          question: "Should I escape forward slashes?",
          answer:
            "Usually not. JSON permits \\/ but no parser requires it. The two cases where it matters: JSON embedded directly in an HTML <script> block, where a literal </script> inside a string would end the element early, and a handful of log shippers that expect the escaped form.",
        },
        {
          question: "Is my payload sent anywhere?",
          answer:
            "No. The escaping happens in this browser tab. The documents people embed in other documents are usually fixtures, API bodies and configuration — exactly the material that should not travel through an unknown server to have its quotes changed.",
        },
      ]}
      relatedTools={relatedTools("/json-stringify").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="JSON document"
        outputLabel="Escaped string literal"
        inputPlaceholder="Paste a JSON document…"
        initialInput={SAMPLE}
        transform={transform}
        options={
          <>
            {(
              [
                ["includeQuotes", "Wrap in quotes"],
                ["escapeUnicode", "Escape non-ASCII"],
                ["escapeSlashes", "Escape slashes"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground"
              >
                <input
                  type="checkbox"
                  className={checkbox}
                  checked={options[key]}
                  onChange={(e) => setOptions({ ...options, [key]: e.target.checked })}
                />
                {label}
              </label>
            ))}
            <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
              <input
                type="checkbox"
                className={checkbox}
                checked={requireValid}
                onChange={(e) => setRequireValid(e.target.checked)}
              />
              Require valid JSON
            </label>
          </>
        }
      />
    </ToolShell>
  );
};
