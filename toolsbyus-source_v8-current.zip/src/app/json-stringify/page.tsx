import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonStringifyClient } from "./JsonStringifyClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-stringify",
  title: "JSON Stringify — Escape JSON as a String",
  socialTitle: "JSON Stringify",
  description:
    "Escape a JSON document into a JSON string literal for embedding in another payload, a config file or a test fixture. Runs in your browser.",
});

export default function JsonStringifyPage() {
  return <JsonStringifyClient />;
}
