"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodegenTool } from "../../components/tools/CodegenTool";
import { relatedTools } from "../../lib/tools";

export const JsonToCSharpClient: React.FC = () => (
  <ToolShell
      wide
    slug="json-to-csharp"
    keyword="JSON to C# Classes"
    directAnswer="JSON to C# generates classes or records from a sample document in your browser. Property names are PascalCase and every one carries an explicit attribute with the original JSON key, because System.Text.Json is case-sensitive by default and a PascalCase property will not bind to a snake_case key without being told to."
    breadcrumbs={[
      { name: "JSON Tools", url: "/json-tools" },
      { name: "JSON to C#", url: "/json-to-csharp" },
    ]}
    seoDescription="Convert JSON to C# classes or records in the browser. System.Text.Json or Newtonsoft attributes, nullable reference types, long for wide integers, CS8618 handled. Nothing is uploaded."
    howItWorks={{
      algorithmExplanation: (
        <>
          <p>
            C# is the target where the nullable reference type setting changes what correct output
            looks like, so the generator treats it as a first-class option rather than a formatting
            preference.
          </p>
          <h3>Nullable reference types decide the shape of every member</h3>
          <p>
            Under <code>&lt;Nullable&gt;enable&lt;/Nullable&gt;</code>, which is the default on every
            template since .NET 6, a <code>string</code> property that JSON can leave absent is a
            warning waiting to happen and a <code>NullReferenceException</code> if the warning is
            ignored. Optional and nullable fields therefore get <code>?</code> — which on a value
            type is <code>Nullable&lt;T&gt;</code> and on a reference type is the annotation. Both
            are spelled <code>T?</code>, which is one of the tidier things about the language.
          </p>
          <h3>Non-nullable members need an initialiser or CS8618 fires on every one</h3>
          <p>
            A required <code>string Name &#123; get; set; &#125;</code> warns that it is uninitialised,
            because the compiler cannot see that a deserializer will fill it. The conventional
            generated-code answer is <code>= null!;</code> — an explicit promise to the compiler that
            something else assigns it. Without it the generated file produces one warning per
            property, which people fix by turning nullable off, which throws away the reason to use
            it.
          </p>
          <h3>Attributes are explicit, not conventions</h3>
          <p>
            <code>System.Text.Json</code> matches property names case-sensitively unless configured
            otherwise, so <code>UserId</code> does not bind to <code>user_id</code> and quietly stays
            null. Every property gets a <code>[JsonPropertyName]</code> (or{" "}
            <code>[JsonProperty]</code> for Newtonsoft) carrying the exact original key, so the class
            works regardless of what the serializer options happen to be.
          </p>
          <h3>class or record</h3>
          <p>
            A <code>record</code> is the better default for a deserialized payload — value equality
            and a readable <code>ToString</code> come free, and a DTO should not be mutated after
            it arrives. Plenty of code still expects a mutable class with settable properties, so
            both are available.
          </p>
          <h3>long where int would truncate</h3>
          <p>
            <code>int</code> is 32-bit. Any sample value beyond 2,147,483,647 — a snowflake ID, a
            millisecond timestamp — is emitted as <code>long</code>, because a truncated ID is a bug
            that only appears once real data arrives.
          </p>
        </>
      ),
      inputTitle: "Sample",
      exampleInput: `[
  { "user_id": 900719925474099, "name": "Ada" },
  { "user_id": 12, "name": "Grace", "team": "ops" }
]`,
      outputTitle: "Generated",
      exampleOutput: `public class User
{
    [JsonPropertyName("user_id")]
    public long UserId { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = null!;

    [JsonPropertyName("team")]
    public string? Team { get; set; }
}`,
    }}
    referenceTable={{
      title: "Options and mapping rules",
      rows: [
        {
          parameter: "Shape",
          type: "class / record",
          defaultVal: "class",
          description:
            "record gives value equality and a useful ToString, which suits a DTO. class stays mutable and is what older code expects.",
        },
        {
          parameter: "Namespace",
          type: "identifier",
          defaultVal: "Generated",
          description:
            "Wraps the output in a namespace block. Leave it empty to emit bare types for a file that already has one.",
        },
        {
          parameter: "System.Text.Json",
          type: "boolean",
          defaultVal: "on",
          description:
            "Emits [JsonPropertyName] and the matching using. Turn it off for [JsonProperty] and Newtonsoft.Json, which is still the right choice for anything on .NET Framework.",
        },
        {
          parameter: "nullable",
          type: "boolean",
          defaultVal: "on",
          description:
            "Emits #nullable enable, marks optional members T?, and initialises required reference members with = null! so CS8618 does not fire on every property.",
        },
        {
          parameter: "string",
          type: "C# type",
          defaultVal: "string",
          description:
            "Detected formats are not mapped to DateTime or Guid. System.Text.Json parses ISO 8601 into DateTime if you change the type by hand, but it throws on any record that formats a date differently.",
        },
        {
          parameter: "integer",
          type: "C# type",
          defaultVal: "int / long",
          description:
            "long when any sample exceeds 2,147,483,647. JSON numbers have no declared width, so this is read from the values.",
        },
        {
          parameter: "array",
          type: "C# type",
          defaultVal: "List<T>",
          description:
            "List<T> rather than T[], because both serializers handle it and it is what calling code usually wants. An array of mixed types becomes List<object>.",
        },
        {
          parameter: "Nested object",
          type: "class",
          defaultVal: "own type",
          description:
            "Promoted to its own class, declared before the type that uses it. Identical shapes share one class rather than generating Address, Address2, Address3.",
        },
      ],
    }}
    faqs={[
      {
        question: "Why does every property have an attribute when my keys are already PascalCase?",
        answer:
          "Because the binding is only guaranteed with one. System.Text.Json matches case-sensitively unless PropertyNameCaseInsensitive is set, and even then it will not bridge user_id to UserId — that needs a naming policy the generated class cannot assume is configured. An explicit attribute makes the class correct under any serializer options, which is worth the line.",
      },
      {
        question: "What is = null! and can I delete it?",
        answer:
          "It tells the compiler that a non-nullable reference property will be assigned by something it cannot see — the deserializer — and suppresses CS8618. You can delete it if you make the property required (C# 11) or initialise it in a constructor. What you should not do is turn nullable reference types off to make the warnings go away, which is the usual reaction and throws away the feature that would have caught the real null.",
      },
      {
        question: "Should I use record or class?",
        answer:
          "record for a payload you deserialize and read: value equality makes tests much cleaner and immutability is correct for data that arrived from elsewhere. class if the object is going to be mutated, if you are on a framework older than C# 9, or if an existing codebase expects settable properties everywhere.",
      },
      {
        question: "Why is my date a string?",
        answer:
          "Because generating DateTime from a sample would produce a class that throws on the first record whose date is formatted differently. System.Text.Json only accepts ISO 8601, and real APIs emit Unix timestamps, US-format dates and offsets-without-colons. The detected format is noted so you can change the type deliberately, with a converter if the format needs one.",
      },
      {
        question: "Newtonsoft or System.Text.Json?",
        answer:
          "System.Text.Json for anything on modern .NET — it is in the box, it is significantly faster, and it is where the investment is going. Newtonsoft if you are on .NET Framework, or if you depend on something System.Text.Json still does not do: TypeNameHandling, custom contract resolvers, or the more forgiving parsing of malformed input. The generator emits the right attributes either way.",
      },
      {
        question: "Is my JSON uploaded?",
        answer:
          "No. The document is parsed, the types are inferred and the code is rendered in the tab you already have open. You can confirm it in the Network panel. This matters for the usual reason: the samples people paste into a class generator are real responses, frequently with customer data still in them.",
      },
    ]}
    relatedTools={relatedTools("/json-to-csharp").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <CodegenTool target="csharp" defaultRootName="Root" />
  </ToolShell>
);
