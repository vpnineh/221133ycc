import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToCSharpClient } from "./JsonToCSharpClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-csharp",
  title: "JSON to C# — Generate Classes and Records",
  socialTitle: "JSON to C#",
  description:
    "Generate C# classes or records from a JSON sample in your browser. System.Text.Json or Newtonsoft attributes, nullable reference types handled.",
});

export default function JsonToCSharpPage() {
  return <JsonToCSharpClient />;
}
