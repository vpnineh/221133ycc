"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, field, fieldLabel } from "../../components/common/controls";
import { parseJson } from "../../lib/json/parser";
import { jsonToCsv, type CsvSerializeOptions, type Delimiter } from "../../lib/csv";
import { relatedTools } from "../../lib/tools";

const SAMPLE = JSON.stringify(
  [
    {
      id: "ord_1041",
      customer: { name: "Ada Lovelace", email: "ada@example.com" },
      total: 148.5,
      currency: "GBP",
      tags: ["priority", "gift"],
      shipped: true,
    },
    {
      id: "ord_1042",
      customer: { name: "Grace Hopper", email: "grace@example.com" },
      total: 92,
      currency: "USD",
      tags: ["standard"],
      shipped: false,
      note: "Leave with neighbour",
    },
  ],
  null,
  2
);

export const JsonToCsvClient: React.FC = () => {
  const [options, setOptions] = useState<CsvSerializeOptions>({
    delimiter: ",",
    includeHeader: true,
    arrayMode: "explode",
    arrayJoin: "; ",
    quoteAll: false,
    newline: "\n",
  });

  const transform = useCallback(
    (input: string): TransformOutcome => {
      const parsed = parseJson(input);
      if (!parsed.success) {
        return {
          output: "",
          error: `Line ${parsed.error.line}, column ${parsed.error.column}: ${parsed.error.message}`,
        };
      }

      const result = jsonToCsv(parsed.data, options);
      return {
        output: result.csv,
        warnings: result.warnings,
        stats: [
          { label: "Rows", value: String(result.rowCount) },
          { label: "Columns", value: String(result.columns.length) },
          { label: "Bytes", value: String(new Blob([result.csv]).size) },
          { label: "Delimiter", value: options.delimiter === "\t" ? "tab" : options.delimiter },
        ],
      };
    },
    [options]
  );

  return (
    <ToolShell
      wide
      slug="json-to-csv"
      keyword="JSON to CSV"
      directAnswer="JSON to CSV converts an array of records into a spreadsheet-ready grid in your browser. Nested objects and arrays become explicit, reversible column paths rather than being flattened away or dropped, and the column set is the union of every record so fields that appear only in later rows survive."
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON to CSV", url: "/json-to-csv" },
      ]}
      seoDescription="Convert JSON to CSV in your browser. Handles nested objects and arrays with reversible column paths, unions columns across all records, and quotes correctly. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The hard part of this conversion is not the syntax, it is the shape mismatch. CSV is a
              rectangle: a fixed set of columns, one row per record, one scalar per cell. JSON is a
              tree. Every converter has to decide what happens when a record contains{" "}
              <code>{`{"customer":{"name":"Ada"}}`}</code>, and most of them decide quietly — by
              dropping the nested object, by pasting{" "}
              <code>{`[object Object]`}</code> into the cell, or by serialising the whole subtree
              back to JSON inside a single field.
            </p>
            <p>
              The decision here is an explicit path encoding.{" "}
              <code>customer.name</code> for an object member and <code>tags[0]</code> for an array
              index. The two notations are deliberately different so the mapping is reversible: with
              dots alone, <code>a.0</code> cannot say whether <code>a</code> is an array or an
              object with a key called &ldquo;0&rdquo;, and a round trip through CSV and back would
              guess. Paste the result into{" "}
              <a href="/csv-to-json">CSV to JSON</a> and you get the document you started with.
            </p>
            <p>
              The second decision is the column set. The obvious implementation reads the keys off
              the first record and uses them as the header — and silently loses every field that
              only appears later. Real exports are heterogeneous: an optional{" "}
              <code>note</code> on one order in fifty, a <code>discount</code> that only applies
              sometimes. The column set here is the union across every record, in first-seen order,
              so nothing is dropped and the ordering still reads naturally.
            </p>
            <p>
              Arrays get a choice, because there is no right answer. <strong>Explode</strong> gives
              each element its own column and round-trips exactly. <strong>Join</strong> puts them
              in one cell separated by a delimiter, which is what somebody opening this in a
              spreadsheet usually wants — and is lossy, so it applies only to arrays of scalars; an
              array of objects is always exploded, because joining it would destroy it.
            </p>
            <p>
              Quoting follows RFC 4180: a field is quoted when it contains the delimiter, a double
              quote, a newline, or leading or trailing whitespace that a spreadsheet would otherwise
              strip. Quotes inside a quoted field are doubled. Everything else is emitted bare,
              because a file where every cell is quoted is harder to read and no more correct.
            </p>
          </>
        ),
        inputTitle: "JSON in",
        exampleInput: `[
  { "id": 1, "user": { "name": "Ada" }, "tags": ["a","b"] },
  { "id": 2, "user": { "name": "Grace" }, "tags": ["c"], "vip": true }
]`,
        outputTitle: "CSV out",
        exampleOutput: `id,user.name,tags[0],tags[1],vip
1,Ada,a,b,
2,Grace,c,,true`,
      }}
      referenceTable={{
        title: "Conversion options and edge cases",
        rows: [
          {
            parameter: "Delimiter",
            type: ", ; tab |",
            defaultVal: ",",
            description:
              "Semicolon is the de-facto standard in locales where the comma is the decimal separator, and is what Excel expects there. Tab avoids quoting almost entirely, since tabs are rare inside data.",
          },
          {
            parameter: "Array mode",
            type: "explode | join",
            defaultVal: "explode",
            description:
              "Explode gives tags[0], tags[1] and round-trips exactly. Join collapses scalars into one cell and is lossy. An array of objects is always exploded regardless, because joining it would lose the structure entirely.",
          },
          {
            parameter: "Quote all",
            type: "boolean",
            defaultVal: "false",
            description:
              "By default a field is quoted only when RFC 4180 requires it. Some strict importers prefer everything quoted; the output is valid either way.",
          },
          {
            parameter: "Header row",
            type: "boolean",
            defaultVal: "true",
            description:
              "Emits the flattened column paths as row one. Without it the column meanings are positional only, and a round trip back to JSON cannot reconstruct the nesting.",
          },
          {
            parameter: "Column set",
            type: "union",
            defaultVal: "all records",
            description:
              "Every column that appears in any record, in first-seen order. Reading the header off record one is the commonest way a converter silently drops data.",
          },
          {
            parameter: "null",
            type: "value",
            defaultVal: "empty cell",
            description:
              "Written as an empty field rather than the text \"null\", because a spreadsheet treats the literal word as a string. This means null and absent are indistinguishable in the output — inherent to CSV, not to this tool.",
          },
          {
            parameter: "Top-level shape",
            type: "array | object",
            defaultVal: "array",
            description:
              "An array of records is the expected input. A single object becomes one row. An object with exactly one array member — the {\"data\":[…]} envelope most APIs return — uses that array, and says so.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "Conversion runs on the main thread, so above this ceiling it is declined rather than attempted. Nothing is uploaded at any size.",
          },
        ],
      }}
      faqs={[
        {
          question: "What happens to nested objects?",
          answer:
            "They become dotted column names: {\"customer\":{\"name\":\"Ada\"}} produces a column called customer.name. Arrays use bracket notation — tags[0], tags[1] — so the two are distinguishable and the conversion is reversible. That is the difference from most converters, which either drop the nested object, write [object Object] into the cell, or stuff a JSON blob into one field.",
        },
        {
          question: "My records have different fields. Will some be dropped?",
          answer:
            "No. The column set is the union of every record's fields, in the order they are first seen, so a note that appears on only one order in fifty still gets its own column with empty cells everywhere else. Converters that read the header off the first record alone lose those fields silently, which is the failure most worth avoiding here.",
        },
        {
          question: "Can I convert the CSV back to the original JSON?",
          answer:
            "Yes, with explode mode and the header row on. Paste the result into CSV to JSON and the nesting is rebuilt from the column paths. Two caveats are inherent to CSV rather than to the tool: a cell cannot distinguish the string \"22201\" from the number 22201, and it cannot distinguish an empty string from an absent field.",
        },
        {
          question: "Why is my number column quoted in Excel, or showing as a date?",
          answer:
            "That is Excel's import heuristics, not the file. It aggressively reinterprets anything that resembles a date, and drops leading zeros from anything that resembles a number, which mangles product codes and postcodes. Use Data → From Text/CSV rather than double-clicking the file, and set those columns to Text in the import dialog.",
        },
        {
          question: "Is my JSON uploaded anywhere?",
          answer:
            "No. The conversion runs in your browser. Open DevTools, go to the Network panel and paste a document — no request carries it. That matters here more than it might seem: the JSON people convert to CSV is usually an export of real records, which is precisely the data that should not go through an unknown server on its way to a spreadsheet.",
        },
        {
          question: "Which delimiter should I choose?",
          answer:
            "Comma unless you have a reason. Semicolon if the file is going to somebody in a locale where the comma is the decimal separator, because that is what their Excel expects — a comma-delimited file opens there as a single column. Tab if the data contains a lot of commas and quotes, since tabs almost never appear inside fields and the file stays readable.",
        },
      ]}
      relatedTools={relatedTools("/json-to-csv").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="JSON"
        outputLabel="CSV"
        inputPlaceholder="Paste an array of records…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="export.csv"
        options={
          <>
            <div className="flex items-center gap-2">
              <label htmlFor="delimiter" className={fieldLabel}>
                Delimiter
              </label>
              <select
                id="delimiter"
                className={`${field} cursor-pointer`}
                value={options.delimiter}
                onChange={(e) => setOptions({ ...options, delimiter: e.target.value as Delimiter })}
              >
                <option value=",">Comma</option>
                <option value=";">Semicolon</option>
                <option value="&#9;">Tab</option>
                <option value="|">Pipe</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="array-mode" className={fieldLabel}>
                Arrays
              </label>
              <select
                id="array-mode"
                className={`${field} cursor-pointer`}
                value={options.arrayMode}
                onChange={(e) =>
                  setOptions({ ...options, arrayMode: e.target.value as "explode" | "join" })
                }
              >
                <option value="explode">One column each</option>
                <option value="join">Joined in one cell</option>
              </select>
            </div>

            {options.arrayMode === "join" && (
              <div className="flex items-center gap-2">
                <label htmlFor="array-join" className={fieldLabel}>
                  Join with
                </label>
                <input
                  id="array-join"
                  className={`${field} w-20 font-mono`}
                  value={options.arrayJoin}
                  onChange={(e) => setOptions({ ...options, arrayJoin: e.target.value })}
                />
              </div>
            )}

            <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
              <input
                type="checkbox"
                className={checkbox}
                checked={options.includeHeader}
                onChange={(e) => setOptions({ ...options, includeHeader: e.target.checked })}
              />
              Header row
            </label>

            <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
              <input
                type="checkbox"
                className={checkbox}
                checked={options.quoteAll}
                onChange={(e) => setOptions({ ...options, quoteAll: e.target.checked })}
              />
              Quote every field
            </label>
          </>
        }
      />
    </ToolShell>
  );
};
