import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToCsvClient } from "./JsonToCsvClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-csv",
  title: "JSON to CSV — Convert Records to a Spreadsheet",
  socialTitle: "JSON to CSV",
  description:
    "Convert JSON to CSV in your browser. Nested data becomes reversible column paths, and the columns are the union of every record, so nothing drops.",
});

export default function JsonToCsvPage() {
  return <JsonToCsvClient />;
}
