"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodegenTool } from "../../components/tools/CodegenTool";
import { relatedTools } from "../../lib/tools";

export const JsonToGoClient: React.FC = () => (
  <ToolShell
      wide
    slug="json-to-go"
    keyword="JSON to Go Struct"
    directAnswer="JSON to Go generates structs from a sample document in your browser. Every field is exported and carries an explicit json tag, because encoding/json silently ignores unexported fields — a lowercase field name is the single most common reason a generated struct marshals to an empty object."
    breadcrumbs={[
      { name: "JSON Tools", url: "/json-tools" },
      { name: "JSON to Go", url: "/json-to-go" },
    ]}
    seoDescription="Convert JSON to Go structs in the browser. Exported names with initialisms capitalised, json tags, pointers for optional fields, int64 for wide integers, gofmt-aligned output. Nothing is uploaded."
    howItWorks={{
      algorithmExplanation: (
        <>
          <p>
            Three decisions make a generated Go struct either correct or quietly broken, and all
            three are about what <code>encoding/json</code> does at runtime rather than about how the
            code looks.
          </p>
          <h3>Every field is exported, and tagged</h3>
          <p>
            Go only marshals exported fields. A struct with a field called <code>id</code> produces{" "}
            <code>&#123;&#125;</code> from <code>json.Marshal</code> and leaves <code>id</code> at
            zero after <code>json.Unmarshal</code>, with no error either way. So every name is
            capitalised and given an explicit <code>json:&quot;…&quot;</code> tag carrying the
            original key. Initialisms follow Go&apos;s own style guide:{" "}
            <code>user_id</code> becomes <code>UserID</code>, not <code>UserId</code>, and{" "}
            <code>api_url</code> becomes <code>APIURL</code>.
          </p>
          <h3>Optional fields are pointers</h3>
          <p>
            A plain <code>string</code> cannot hold JSON <code>null</code>, and it cannot tell an
            absent key from an empty one — both arrive as <code>&quot;&quot;</code>. A plain{" "}
            <code>int</code> cannot distinguish a missing count from a count of zero. Optional and
            nullable fields therefore become pointers, which is the only construction in Go that
            keeps the distinction. Slices, maps and <code>interface&#123;&#125;</code> are already
            nilable, so they are left alone rather than given a pointless second indirection.
          </p>
          <h3>Integers that int cannot hold become int64</h3>
          <p>
            <code>int</code> is 32-bit on some platforms. A snowflake ID or a millisecond timestamp
            overflows it, and the resulting bug appears only on the platform where it is narrow.
            Values beyond 2,147,483,647 are emitted as <code>int64</code>.
          </p>
          <h3>Unions are interface&#123;&#125;, because Go has no sum type</h3>
          <p>
            An array holding both strings and numbers has no Go type that describes it. Generators
            that invent one produce code that fails to unmarshal;{" "}
            <code>interface&#123;&#125;</code> is the honest answer, and the place to fix it is the
            API, not the struct.
          </p>
          <h3>The output is already gofmt-aligned</h3>
          <p>
            Names, types, tags and trailing comments are padded to matching columns. Without that,
            the first <code>gofmt</code> in CI produces a diff on a file nobody edited.
          </p>
        </>
      ),
      inputTitle: "Sample",
      exampleInput: `[
  { "user_id": 900719925474099, "api_url": "https://x.dev" },
  { "user_id": 12, "api_url": "https://y.dev", "note": "hi" }
]`,
      outputTitle: "Generated",
      exampleOutput: `type User struct {
	UserID int64   \`json:"user_id"\`
	APIURL string  \`json:"api_url"\`
	Note   *string \`json:"note,omitempty"\` // optional
}`,
    }}
    referenceTable={{
      title: "Options and mapping rules",
      rows: [
        {
          parameter: "Package",
          type: "identifier",
          defaultVal: "main",
          description:
            "The package clause at the top of the file. Set it to whatever the destination file lives in — models, api, internal/store.",
        },
        {
          parameter: "pointers",
          type: "boolean",
          defaultVal: "on",
          description:
            "Optional and nullable fields become *T, so an absent key is distinguishable from the zero value. Turning this off makes the struct simpler and makes missing data invisible.",
        },
        {
          parameter: "omitempty",
          type: "boolean",
          defaultVal: "on",
          description:
            "Adds ,omitempty to optional fields so they disappear when marshalled back. Note that omitempty also drops a genuine empty string or zero, which is exactly why the pointer matters.",
        },
        {
          parameter: "json.Number",
          type: "boolean",
          defaultVal: "off",
          description:
            "Emits json.Number for non-integers instead of float64, preserving the literal digits. Worth it for money or for IDs that arrive as unquoted numbers beyond float64's exact range.",
        },
        {
          parameter: "string",
          type: "Go type",
          defaultVal: "string",
          description:
            "Detected formats (uuid, date-time, email, uri) are noted in a comment rather than mapped to a type, because encoding/json will not parse a timestamp into time.Time without a custom unmarshaller.",
        },
        {
          parameter: "integer",
          type: "Go type",
          defaultVal: "int / int64",
          description:
            "int by default; int64 when any sample exceeds 2,147,483,647. A truncated ID is a bug that only shows up in production.",
        },
        {
          parameter: "number",
          type: "Go type",
          defaultVal: "float64",
          description:
            "Any value with a fractional part. If an integer and a float appear in the same field across records, the field becomes float64.",
        },
        {
          parameter: "nested object",
          type: "Go type",
          defaultVal: "*Named",
          description:
            "Promoted to its own struct and referenced by pointer, which avoids copying on assignment and lets the field be nil. Identical shapes share one struct.",
        },
      ],
    }}
    faqs={[
      {
        question: "Why is every field capitalised when my JSON keys are lowercase?",
        answer:
          "Because encoding/json only sees exported fields, and export in Go means an uppercase first letter. A lowercase field is skipped by both Marshal and Unmarshal with no error, so the struct compiles, runs, and does nothing. The json tag carries the original key, so the wire format is unchanged.",
      },
      {
        question: "Do I need the pointers?",
        answer:
          "You need them wherever absent and zero mean different things. A *int that is nil means the key was missing; an int that is 0 could be either. For a field like retry_count or discount that distinction usually matters. For a field you know is always present it is noise, and turning pointers off is reasonable.",
      },
      {
        question: "Why is my timestamp a string instead of time.Time?",
        answer:
          "Because encoding/json will not parse an arbitrary timestamp into time.Time on its own — it only handles RFC 3339, and only if the field is declared as time.Time, which then fails hard on any other format. Generating time.Time from a sample would produce a struct that panics on the first record that formats a date differently. The detected format is noted in a comment so you can make that choice deliberately.",
      },
      {
        question: "What is interface{} doing in my struct?",
        answer:
          "A field held genuinely different types across your samples — a string in one record, an object in another — and Go has no type that expresses that. The alternatives are a custom UnmarshalJSON, a json.RawMessage you decode later, or fixing the API. A generated union type would simply fail to unmarshal.",
      },
      {
        question: "Will gofmt change the output?",
        answer:
          "It should not. Field names, types, tags and trailing comments are padded to matching columns, which is what gofmt does to a struct. If you find a case where gofmt still produces a diff, that is a bug worth reporting rather than a style preference.",
      },
      {
        question: "Is my JSON uploaded?",
        answer:
          "No. The parse, the type inference and the rendering all run in your browser. Nothing is sent anywhere, which matters because the samples people paste into a struct generator are usually real API responses from a system they are integrating against.",
      },
    ]}
    relatedTools={relatedTools("/json-to-go").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <CodegenTool target="go" defaultRootName="Root" />
  </ToolShell>
);
