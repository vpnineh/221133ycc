import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToGoClient } from "./JsonToGoClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-go",
  title: "JSON to Go — Generate Structs With Tags",
  socialTitle: "JSON to Go",
  description:
    "Generate Go structs from a JSON sample in your browser. Exported fields with json tags, pointers for optional values, gofmt-aligned columns.",
});

export default function JsonToGoPage() {
  return <JsonToGoClient />;
}
