"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodegenTool } from "../../components/tools/CodegenTool";
import { relatedTools } from "../../lib/tools";

export const JsonToJavaClient: React.FC = () => (
  <ToolShell
      wide
    slug="json-to-java"
    keyword="JSON to Java Classes"
    directAnswer="JSON to Java generates records or POJOs from a sample document in your browser. Optional numeric fields are boxed — Integer rather than int — because a primitive cannot hold null, so a missing key deserializes to 0 and becomes indistinguishable from a real zero."
    breadcrumbs={[
      { name: "JSON Tools", url: "/json-tools" },
      { name: "JSON to Java", url: "/json-to-java" },
    ]}
    seoDescription="Convert JSON to Java records or POJOs in the browser. Jackson @JsonProperty annotations, boxed optional primitives, List<T> with boxed elements, long for wide integers. Nothing is uploaded."
    howItWorks={{
      algorithmExplanation: (
        <>
          <p>
            Java&apos;s primitive types make the optional-field question concrete rather than
            stylistic, and getting it wrong produces a bug that is genuinely hard to find.
          </p>
          <h3>A primitive cannot be absent</h3>
          <p>
            <code>int count</code> deserializes a missing <code>count</code> key to <code>0</code>.
            No exception, no warning — and downstream there is no way to tell a record where the
            count was never sent from one where the count really was zero. The same applies to{" "}
            <code>boolean</code>, which becomes <code>false</code>, and <code>double</code>, which
            becomes <code>0.0</code>. Optional and nullable fields are therefore boxed:{" "}
            <code>Integer</code>, <code>Long</code>, <code>Double</code>, <code>Boolean</code>, all of
            which can hold <code>null</code> and let you ask the question.
          </p>
          <h3>Generics cannot hold primitives at all</h3>
          <p>
            <code>List&lt;int&gt;</code> does not compile. Every list element is boxed regardless of
            optionality, which is why an array of integers becomes{" "}
            <code>List&lt;Integer&gt;</code>.
          </p>
          <h3>record or POJO</h3>
          <p>
            A <code>record</code> is the better default on Java 17 and later: immutable, no
            boilerplate, <code>equals</code> and <code>hashCode</code> and <code>toString</code> for
            free, and Jackson has supported them since 2.12. A POJO with private fields and
            getters and setters is what a codebase on Java 8 or a framework that requires a
            no-argument constructor will want, so both are available.
          </p>
          <h3>Jackson annotations carry the original key</h3>
          <p>
            Java convention is <code>camelCase</code>; JSON keys frequently are not. Rather than
            depend on a <code>PropertyNamingStrategy</code> being configured somewhere else, every
            component gets an explicit <code>@JsonProperty</code> with the exact key from the
            document. The class then binds correctly whatever the <code>ObjectMapper</code> is set
            to.
          </p>
          <h3>One public type per file</h3>
          <p>
            Java allows exactly one public top-level type per source file, so a document that
            produces several types does not compile as a single paste. The output says so in a
            header comment: save each type as <code>&lt;TypeName&gt;.java</code>, or nest them inside
            one outer class. Emitting a file that <code>javac</code> rejects without mentioning it is
            the kind of small dishonesty that wastes ten minutes.
          </p>
        </>
      ),
      inputTitle: "Sample",
      exampleInput: `[
  { "user_id": 1, "retries": 0, "tags": ["a"] },
  { "user_id": 2, "tags": [] }
]`,
      outputTitle: "Generated",
      exampleOutput: `public record User(
    @JsonProperty("user_id") int userId,
    @JsonProperty("retries") Integer retries,
    @JsonProperty("tags") List<String> tags
) {}`,
    }}
    referenceTable={{
      title: "Options and mapping rules",
      rows: [
        {
          parameter: "Shape",
          type: "record / POJO",
          defaultVal: "record",
          description:
            "record on Java 17+ for an immutable DTO with no boilerplate. POJO for Java 8, or for anything that needs a no-argument constructor and setters.",
        },
        {
          parameter: "Package",
          type: "identifier",
          defaultVal: "(none)",
          description:
            "Adds a package declaration. Leave it empty for a scratch file; set it to match the directory the file will live in.",
        },
        {
          parameter: "Jackson",
          type: "boolean",
          defaultVal: "on",
          description:
            "Emits @JsonProperty with the exact JSON key, so binding does not depend on an ObjectMapper naming strategy configured elsewhere.",
        },
        {
          parameter: "box optionals",
          type: "boolean",
          defaultVal: "on",
          description:
            "An optional int becomes Integer. Turning this off makes a missing key deserialize to 0, which is indistinguishable from a real zero.",
        },
        {
          parameter: "string",
          type: "Java type",
          defaultVal: "String",
          description:
            "Detected formats are not mapped to Instant, LocalDate or UUID. Jackson needs JavaTimeModule registered for the first two, and it throws on any record whose format differs.",
        },
        {
          parameter: "integer",
          type: "Java type",
          defaultVal: "int / long",
          description:
            "long when any sample exceeds 2,147,483,647. A JSON number carries no declared width, so the width is read from the values.",
        },
        {
          parameter: "array",
          type: "Java type",
          defaultVal: "List<T>",
          description:
            "Elements are always boxed, because generics cannot hold primitives. A mixed array becomes List<Object>.",
        },
        {
          parameter: "Nested object",
          type: "type",
          defaultVal: "own type",
          description:
            "Promoted to its own record or class, declared before the type that uses it. Identical shapes share one type rather than generating numbered duplicates.",
        },
      ],
    }}
    faqs={[
      {
        question: "Why is one field int and another Integer?",
        answer:
          "The Integer appeared in some records and not others. A primitive int cannot hold null, so Jackson deserializes a missing key to 0 — and nothing downstream can tell that apart from a record that genuinely sent zero. Integer can be null, which makes the absence visible. Fields present in every record stay primitive, which is cheaper and simpler.",
      },
      {
        question: "Can I paste the whole output into one file?",
        answer:
          "Not if it generated more than one type. Java allows exactly one public top-level type per source file, so javac will reject it. Save each type as <TypeName>.java, or make the nested ones static nested classes inside one outer class. The output says which case you are in at the top.",
      },
      {
        question: "record or POJO?",
        answer:
          "record if you are on Java 17 or later and the object is data that arrived from somewhere: it is immutable, it gives you equals, hashCode and toString correctly, and Jackson has supported records since 2.12. POJO if you are on Java 8, if a framework requires a no-argument constructor and setters (older JPA, some Spring configurations), or if the object genuinely needs to be mutated after construction.",
      },
      {
        question: "Why is my timestamp a String rather than Instant?",
        answer:
          "Because Jackson cannot parse it into Instant without JavaTimeModule registered, and because it throws on the first record whose format differs from what it expects. Real APIs send Unix seconds, Unix milliseconds, ISO 8601 with and without offsets, and occasionally something regional. The detected format is noted in the reference above so you can change the type deliberately and add a converter if the format needs one.",
      },
      {
        question: "Do I need Lombok?",
        answer:
          "No, and the generator deliberately does not emit @Data or @Builder. On Java 17+ a record covers what Lombok's @Value was for, without an annotation processor in your build. The POJO output is plain Java with real getters and setters, which compiles anywhere. If your project already uses Lombok you can replace the accessors yourself, but nothing here requires it.",
      },
      {
        question: "Is my JSON uploaded?",
        answer:
          "No. Parsing, type inference and rendering all run in your browser — open the Network panel while you paste and you will see nothing leave. The samples people paste into a class generator are usually real responses from a system they are integrating against, which is precisely the material that should not pass through an unknown server.",
      },
    ]}
    relatedTools={relatedTools("/json-to-java").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <CodegenTool target="java" defaultRootName="Root" />
  </ToolShell>
);
