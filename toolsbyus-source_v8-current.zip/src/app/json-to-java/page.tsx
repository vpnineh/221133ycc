import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToJavaClient } from "./JsonToJavaClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-java",
  title: "JSON to Java — Generate POJOs and Records",
  socialTitle: "JSON to Java",
  description:
    "Generate Java records or POJOs from a JSON sample in your browser. Jackson annotations, boxed types for optional fields so absent is not zero, nothing uploaded.",
});

export default function JsonToJavaPage() {
  return <JsonToJavaClient />;
}
