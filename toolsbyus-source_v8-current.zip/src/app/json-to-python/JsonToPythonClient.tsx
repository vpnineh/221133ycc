"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodegenTool } from "../../components/tools/CodegenTool";
import { relatedTools } from "../../lib/tools";

export const JsonToPythonClient: React.FC = () => (
  <ToolShell
      wide
    slug="json-to-python"
    keyword="JSON to Python"
    directAnswer="JSON to Python generates dataclasses, TypedDicts or Pydantic models from a sample document in your browser. The three answer different questions: a dataclass describes the data with no dependencies, a TypedDict describes the dict json.loads already gave you, and a Pydantic model validates it at the boundary."
    breadcrumbs={[
      { name: "JSON Tools", url: "/json-tools" },
      { name: "JSON to Python", url: "/json-to-python" },
    ]}
    seoDescription="Convert JSON to Python dataclasses, TypedDict or Pydantic models in the browser. Correct field ordering, Optional inference, snake_case renaming with aliases. Nothing is uploaded."
    howItWorks={{
      algorithmExplanation: (
        <>
          <p>
            Pick the shape by what you intend to do with the result. The three are not
            interchangeable and choosing the wrong one is the most common problem with generated
            Python.
          </p>
          <h3>dataclass, TypedDict, Pydantic</h3>
          <p>
            A <code>@dataclass</code> gives you a real object with attribute access, equality and a
            useful <code>repr</code>, and no third-party dependency — but it does no validation, so a
            field annotated <code>int</code> will happily hold a string it was constructed with. A{" "}
            <code>TypedDict</code> annotates the plain dictionary <code>json.loads</code> already
            returned, so nothing has to be constructed at all and the type checker still catches a
            misspelled key; it is the right answer when you are passing parsed JSON around as-is. A
            Pydantic <code>BaseModel</code> actually validates and coerces at construction, which is
            what an API client wants at its boundary, at the cost of a dependency and some runtime
            work.
          </p>
          <h3>Field order is a correctness problem, not a style one</h3>
          <p>
            A dataclass field with a default cannot precede one without: Python raises{" "}
            <code>TypeError</code> at import time, not at first use. Because optional fields get{" "}
            <code>= None</code>, the generator emits every required field first. A generator that
            preserves JSON key order here produces a module that fails to import.
          </p>
          <h3>Optional means &quot;can be None&quot;, not &quot;can be omitted&quot;</h3>
          <p>
            This trips people up in Python specifically, because <code>Optional[int]</code> reads
            like it means optional and means nullable. In a dataclass, a field missing from some
            records is emitted as <code>Optional[int] = None</code> — the annotation carries the
            nullability and the default carries the absence. In a <code>TypedDict</code> the two are
            genuinely separate, so an absent key is <code>NotRequired[int]</code> and a null value is{" "}
            <code>Optional[int]</code>.
          </p>
          <h3>Renamed keys keep an alias</h3>
          <p>
            Python convention is <code>snake_case</code>, and JSON from a JavaScript service usually
            is not. Keys are renamed and the original is recorded — as a comment in a dataclass or
            TypedDict, and as a real <code>Field(alias=…)</code> in Pydantic, where it changes
            behaviour rather than just documenting it.
          </p>
          <h3>Forward references are quoted</h3>
          <p>
            Nested classes are emitted before the classes that use them, but the annotation is still
            written as a string, which keeps the module importable if you reorder it by hand.
          </p>
        </>
      ),
      inputTitle: "Sample",
      exampleInput: `[
  { "userId": 1, "team": "ops" },
  { "userId": 2 }
]`,
      outputTitle: "Generated",
      exampleOutput: `from dataclasses import dataclass
from typing import Optional

@dataclass
class User:
    user_id: int  # JSON key: userId
    team: Optional[str] = None`,
    }}
    referenceTable={{
      title: "Options and mapping rules",
      rows: [
        {
          parameter: "Shape",
          type: "dataclass / TypedDict / pydantic",
          defaultVal: "dataclass",
          description:
            "dataclass for a dependency-free object; TypedDict to annotate the dict json.loads returned; pydantic when you want the values validated at the boundary.",
        },
        {
          parameter: "snake_case",
          type: "boolean",
          defaultVal: "on",
          description:
            "Renames keys to Python convention. In pydantic this becomes a real alias, so parsing still matches the wire format; elsewhere it is recorded in a comment and you must map the keys yourself.",
        },
        {
          parameter: "X | None",
          type: "boolean",
          defaultVal: "off",
          description:
            "Python 3.10+ union syntax instead of Optional[X]. Shorter, and it drops the typing import — but it is a syntax error on 3.9 and below.",
        },
        {
          parameter: "string",
          type: "Python type",
          defaultVal: "str",
          description:
            "Detected formats are not mapped to datetime or UUID: json.loads returns strings, and annotating one as datetime would be a lie unless something parses it.",
        },
        {
          parameter: "integer / number",
          type: "Python type",
          defaultVal: "int / float",
          description:
            "Separated by whether any sample had a fractional part. Python integers are arbitrary precision, so there is no int64 distinction to make here.",
        },
        {
          parameter: "Optional field",
          type: "annotation",
          defaultVal: "Optional[T] = None",
          description:
            "In a TypedDict an absent key is NotRequired[T] instead, which is the distinction Python makes and the other two shapes cannot.",
        },
        {
          parameter: "Field order",
          type: "required first",
          defaultVal: "enforced",
          description:
            "A dataclass field without a default cannot follow one with a default. Required fields are emitted first regardless of JSON key order.",
        },
        {
          parameter: "Nested object",
          type: "class",
          defaultVal: "quoted reference",
          description:
            "Promoted to its own class, defined before use, and referenced by a quoted forward reference so the module survives reordering.",
        },
      ],
    }}
    faqs={[
      {
        question: "Which should I pick: dataclass, TypedDict or Pydantic?",
        answer:
          "If the data crosses a trust boundary — an HTTP response, a webhook, a file someone uploaded — use Pydantic, because it is the only one of the three that actually checks anything. If you are annotating dicts you already parsed and passing them around internally, use TypedDict, which costs nothing at runtime. Use a dataclass when you want a real object and no dependency, accepting that the annotations are documentation for your type checker rather than a guarantee.",
      },
      {
        question: "Why are my fields in a different order from my JSON?",
        answer:
          "Because a dataclass field with a default cannot come after one without — Python raises TypeError when the module is imported, before any of your code runs. Optional fields get = None, so they are all moved after the required ones. TypedDict and Pydantic have no such rule and keep the original order.",
      },
      {
        question: "Does Optional[int] mean the key can be missing?",
        answer:
          "No, and this is the most common misreading in Python typing. Optional[int] means the value may be None. Whether the key may be absent is a separate question, expressed by a default in a dataclass or by NotRequired in a TypedDict. The generator distinguishes them: a key missing from some records gets a default, a value that is null in some records gets Optional.",
      },
      {
        question: "Why is my timestamp str instead of datetime?",
        answer:
          "json.loads returns a string, so annotating it datetime would be false unless something parses it. In Pydantic you can change the annotation to datetime and it will parse ISO 8601 for you, which is one of the better reasons to pick Pydantic. In a dataclass or TypedDict, changing the annotation changes nothing at runtime and misleads every reader.",
      },
      {
        question: "Can I use the generated TypedDict on Python 3.9?",
        answer:
          "Yes — the import is from typing_extensions rather than typing, which is why it is written that way. NotRequired only landed in the standard library in 3.11, and typing_extensions backports it to every version that has TypedDict at all. Turning on the X | None option, by contrast, does require 3.10.",
      },
      {
        question: "Is my JSON uploaded?",
        answer:
          "No. Parsing, inference and rendering all happen in your browser, which you can verify in the Network panel. Nothing about generating a class from a sample requires a server, and the samples people paste are usually real payloads from a system they are integrating against.",
      },
    ]}
    relatedTools={relatedTools("/json-to-python").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <CodegenTool target="python" defaultRootName="Root" />
  </ToolShell>
);
