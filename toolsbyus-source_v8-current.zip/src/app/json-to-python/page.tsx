import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToPythonClient } from "./JsonToPythonClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-python",
  title: "JSON to Python — Dataclasses and TypedDicts",
  socialTitle: "JSON to Python",
  description:
    "Generate Python dataclasses, TypedDicts or Pydantic models from a JSON sample in your browser. Optional fields inferred across every record.",
});

export default function JsonToPythonPage() {
  return <JsonToPythonClient />;
}
