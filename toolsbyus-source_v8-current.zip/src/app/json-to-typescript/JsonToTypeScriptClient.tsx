"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodegenTool } from "../../components/tools/CodegenTool";
import { relatedTools } from "../../lib/tools";

export const JsonToTypeScriptClient: React.FC = () => (
  <ToolShell
      wide
    slug="json-to-typescript"
    keyword="JSON to TypeScript"
    directAnswer="JSON to TypeScript generates interfaces from a sample document in your browser. Paste every record you have rather than one: a field that appears in some records and not others is only detectable across samples, and it becomes an optional member rather than a required one that is missing at runtime."
    breadcrumbs={[
      { name: "JSON Tools", url: "/json-tools" },
      { name: "JSON to TypeScript", url: "/json-to-typescript" },
    ]}
    seoDescription="Convert JSON to TypeScript interfaces in the browser. Optional fields inferred across records, identical shapes deduplicated into one named type, nullable values rendered as unions. Nothing is uploaded."
    howItWorks={{
      algorithmExplanation: (
        <>
          <p>
            The generator builds one intermediate type model from your sample and then renders it,
            which sounds like an implementation detail and is the reason the output is correct. The
            genuinely hard decisions — is this field optional, are these two objects the same type,
            what is the element type of a mixed array — are answered once, in one place, rather than
            re-derived every time a value is encountered.
          </p>
          <h3>Optional fields come from disagreement between records</h3>
          <p>
            Given <code>[&#123;&quot;a&quot;:1&#125;, &#123;&quot;a&quot;:1,&quot;b&quot;:2&#125;]</code>,
            the obvious implementation reads the first element and produces{" "}
            <code>&#123; a: number &#125;</code>, silently losing <code>b</code>. The correct answer
            merges the field sets of every element: <code>a</code> is in both so it is required,{" "}
            <code>b</code> is in one so it is <code>b?: number</code>. This is the single largest
            difference between generators, and it is why pasting one record produces a type that
            describes one record rather than your API.
          </p>
          <h3>Identical shapes become one type, not fifty</h3>
          <p>
            Every object is fingerprinted by its structure — key names, optionality, and the
            fingerprint of each value type, order-independent. A document with fifty customers, each
            holding an address of the same shape, produces one <code>Address</code> interface rather
            than <code>Address</code> through <code>Address50</code>. Names come from the key that
            held the object, singularised when it held an array, so{" "}
            <code>&quot;users&quot;: [&#123;…&#125;]</code> generates <code>User</code>.
          </p>
          <h3>null is nullability, not a type</h3>
          <p>
            When a field is a number in one record and <code>null</code> in another, the output is{" "}
            <code>number | null</code> rather than a union type with a generated name. When a field
            is <code>null</code> in <em>every</em> record the honest answer is <code>unknown</code>{" "}
            with a comment saying so — emitting <code>null</code> would be accurate about your sample
            and useless about your data.
          </p>
          <h3>Numbers are numbers, with a note</h3>
          <p>
            TypeScript has one numeric type, so integers and floats both become <code>number</code>.
            An integer too large for a 32-bit type is still flagged in a comment, because the same
            model drives the Go, Java and C# generators where that distinction decides between{" "}
            <code>int</code> and <code>int64</code> — and because a 64-bit ID arriving in JavaScript
            at all is worth knowing about.
          </p>
        </>
      ),
      inputTitle: "Sample",
      exampleInput: `[
  { "id": 1, "name": "Ada", "deleted_at": null },
  { "id": 2, "name": "Grace", "deleted_at": null, "team": "ops" }
]`,
      outputTitle: "Generated",
      exampleOutput: `export interface User {
  id: number;
  name: string;
  deleted_at: unknown; // only null in the sample
  team?: string;
}`,
    }}
    referenceTable={{
      title: "Options and inference rules",
      rows: [
        {
          parameter: "Root type",
          type: "identifier",
          defaultVal: "Root",
          description:
            "Name for the top-level type. An array root is reported as Name[], and object shapes inside it are named after the keys that hold them.",
        },
        {
          parameter: "interface / type",
          type: "declaration",
          defaultVal: "interface",
          description:
            "Interfaces support declaration merging and produce better error messages on object shapes; type aliases are required if you later want unions or mapped types. Either is valid here.",
        },
        {
          parameter: "readonly",
          type: "boolean",
          defaultVal: "off",
          description:
            "Marks every member readonly. Worth turning on for a parsed API response, which nothing in your code should be mutating in place.",
        },
        {
          parameter: "camelCase keys",
          type: "boolean",
          defaultVal: "off",
          description:
            "Renames snake_case keys and records the original in a trailing comment. Only correct if something in your pipeline actually renames them — the generated type otherwise stops matching the JSON.",
        },
        {
          parameter: "Optionality",
          type: "inferred",
          defaultVal: "across records",
          description:
            "A key absent from at least one record of the same shape becomes optional. Paste several records; one record cannot express this.",
        },
        {
          parameter: "Nullable",
          type: "inferred",
          defaultVal: "union with null",
          description:
            "A value that is null in some records and a string in others becomes string | null. Absent and null are different things and are reported differently.",
        },
        {
          parameter: "Mixed arrays",
          type: "union",
          defaultVal: "parenthesised",
          description:
            "An array of mixed scalars becomes (string | number)[]. The parentheses matter: string | number[] means something else entirely.",
        },
        {
          parameter: "Input size",
          type: "bytes",
          defaultVal: "2 MB",
          description:
            "Inference reads every value. A few hundred representative records describe a shape as well as a million, so the ceiling costs nothing in practice.",
        },
      ],
    }}
    faqs={[
      {
        question: "Why is a field optional when my API always sends it?",
        answer:
          "Because at least one record in the sample you pasted did not have it. The generator can only describe the data it was given. If the field is genuinely always present, paste a sample where it always appears — or remove the ? by hand, which is the right call when you know the contract better than the sample does.",
      },
      {
        question: "Should I paste one record or the whole response?",
        answer:
          "The whole response, and ideally several. Optionality, nullability and mixed types are all properties of the set of records, not of any single one. A generator fed one record cannot distinguish a field that is always present from one that happened to be present that time, and it will confidently produce a type that is wrong in the way that is hardest to notice.",
      },
      {
        question: "Why did I get unknown instead of a real type?",
        answer:
          "Every sample at that position was null, so there is nothing to infer from. The alternatives are worse: null as a type is accurate about the sample and useless about the data, and any turns off type checking for everything downstream of it. unknown forces you to narrow before use, which is the correct outcome when the type is genuinely unknown.",
      },
      {
        question: "Can it generate runtime validators, not just types?",
        answer:
          "No. TypeScript types are erased at compile time, so an interface generated from a sample tells you nothing about the response you actually received at runtime. If you need the guarantee rather than the annotation, generate a JSON Schema instead and validate against it, or hand-write a Zod schema. Treating a generated interface as validation is a common and expensive mistake.",
      },
      {
        question: "Does it handle deeply nested or recursive documents?",
        answer:
          "Nesting, yes, to a depth of 100 — past that the generated code would be unusable anyway, so there is a clear ceiling rather than a stack overflow. True recursion (a comment that contains comments) is inferred as far as the sample goes; if the sample has three levels you get three levels, because nothing in the data says the structure repeats forever.",
      },
      {
        question: "Is my JSON uploaded?",
        answer:
          "No. Inference and rendering both run in the tab you already have open — open DevTools and watch the Network panel while you paste. This matters more here than on most tools, because the documents people convert are production API responses, often with real customer records in them.",
      },
    ]}
    relatedTools={relatedTools("/json-to-typescript").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <CodegenTool target="typescript" defaultRootName="Root" />
  </ToolShell>
);
