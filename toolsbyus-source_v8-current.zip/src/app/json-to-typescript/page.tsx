import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToTypeScriptClient } from "./JsonToTypeScriptClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-typescript",
  title: "JSON to TypeScript — Generate Interfaces",
  socialTitle: "JSON to TypeScript",
  description:
    "Generate TypeScript interfaces from a JSON sample in your browser. Fields present in only some records become optional; identical shapes merge.",
});

export default function JsonToTypeScriptPage() {
  return <JsonToTypeScriptClient />;
}
