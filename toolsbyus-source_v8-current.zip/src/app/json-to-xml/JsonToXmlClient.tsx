"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parseJson } from "../../lib/json/parser";
import { jsonToXml, JSON_TO_XML_DEFAULTS, toElementName } from "../../lib/xml/convert";
import { relatedTools } from "../../lib/tools";

const SAMPLE = JSON.stringify(
  {
    "@id": "ord_1041",
    "@currency": "GBP",
    customer: { "@vip": "true", name: "Ada Lovelace", email: "ada@example.com" },
    line: [
      { "@sku": "WID-1", "@qty": "2", "#text": "Widget, small" },
      { "@sku": "WID-9", "@qty": "1", "#text": "Widget & bracket <set>" },
    ],
    shippedAt: null,
    "2024 total": 148.5,
  },
  null,
  2
);

export const JsonToXmlClient: React.FC = () => {
  const [rootName, setRootName] = useState("order");
  const [attributePrefix, setAttributePrefix] = useState("@");
  const [textKey, setTextKey] = useState("#text");
  const [itemName, setItemName] = useState("item");
  const [indent, setIndent] = useState(2);
  const [declaration, setDeclaration] = useState(true);
  const [selfCloseEmpty, setSelfCloseEmpty] = useState(true);

  const transform = (input: string): TransformOutcome => {
    const parsed = parseJson(input);
    if (!parsed.success) {
      return {
        output: "",
        error: `Line ${parsed.error.line}, column ${parsed.error.column}: ${parsed.error.message}`,
      };
    }

    const output = jsonToXml(parsed.data, {
      ...JSON_TO_XML_DEFAULTS,
      rootName: rootName || "root",
      attributePrefix,
      textKey: textKey || "#text",
      itemName: itemName || "item",
      indent,
      declaration,
      selfCloseEmpty,
    });

    // Keys that are not valid XML names are repaired, and the original is kept
    // in a name attribute — but the caller deserves to know it happened.
    const repaired = collectRepairedKeys(parsed.data);

    return {
      output,
      warnings: repaired.length
        ? [
            `${repaired.length} key${repaired.length === 1 ? "" : "s"} could not be used as an XML element name and ${
              repaired.length === 1 ? "was" : "were"
            } rewritten, with the original kept in a name attribute: ${repaired
              .slice(0, 6)
              .join(", ")}${repaired.length > 6 ? "…" : ""}`,
          ]
        : [],
      stats: [
        { label: "Output", value: `${output.length.toLocaleString("en-GB")} bytes` },
        {
          label: "vs JSON",
          value: `${Math.round((output.length / Math.max(input.length, 1) - 1) * 100)}% larger`,
        },
        { label: "Repaired keys", value: String(repaired.length) },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="json-to-xml"
      keyword="JSON to XML"
      directAnswer="JSON to XML converts a document in your browser. Members whose names start with the attribute prefix become XML attributes, an array repeats its member name rather than gaining a wrapper element, and a JSON key that is not a legal XML name is rewritten with the original preserved in a name attribute rather than silently mangled."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "JSON to XML", url: "/json-to-xml" },
      ]}
      seoDescription="Convert JSON to XML in the browser. Attributes from prefixed members, arrays as repeated elements, invalid element names repaired without data loss, correct escaping. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              The hard direction is usually XML to JSON, because XML has more structure. Going the
              other way has fewer decisions but three of them are load-bearing, and getting any of
              them wrong produces output that is not well-formed XML at all.
            </p>
            <h3>JSON keys are not XML names</h3>
            <p>
              A JSON key can be anything: <code>2024 total</code>, <code>user.name</code>,{" "}
              <code>&quot;&quot;</code>, an emoji. An XML element name cannot start with a digit,
              cannot contain a space, and cannot be empty. The usual response is to substitute
              underscores, which silently destroys the key. Here the name is repaired the same way,
              and the original is written to a <code>name</code> attribute — so the document is
              well-formed and nothing is lost. The count of repaired keys is reported rather than
              buried.
            </p>
            <h3>An array root would produce two root elements</h3>
            <p>
              An XML document has exactly one root element; that is not a style rule, it is what
              makes a document a document. Writing the items of a top-level JSON array at the top
              level produces as many roots as there are items, and every XML parser rejects it. So an
              array root is wrapped, and its items take the item name.
            </p>
            <p>
              An array that is a <em>member</em> is different: it repeats the member&apos;s own
              element name, because that is how XML expresses a list. There is no container element
              unless the JSON had one, which is what makes the output round-trip back through the XML
              to JSON converter with the same element in a force-array list.
            </p>
            <h3>Escaping is not optional</h3>
            <p>
              <code>&amp;</code>, <code>&lt;</code> and <code>&gt;</code> in text, plus{" "}
              <code>&quot;</code> and literal newlines in attribute values, all have to be escaped or
              the output is malformed. A newline inside an attribute is the one people miss: XML
              parsers normalise it to a space unless it is written as{" "}
              <code>&amp;#10;</code>, so the value silently changes on the way back.
            </p>
            <h3>XML is bigger, and that is the trade</h3>
            <p>
              Every element name is written twice. The size difference is reported in the stats
              strip so the cost is visible. What it buys is attributes, namespaces, comments,
              processing instructions and schema validation — none of which JSON has, and any of
              which may be the reason you are converting.
            </p>
          </>
        ),
        inputTitle: "JSON",
        exampleInput: `{
  "@id": "1",
  "line": ["a", "b"],
  "note": null
}`,
        outputTitle: "XML",
        exampleOutput: `<?xml version="1.0" encoding="UTF-8"?>
<root id="1">
  <line>a</line>
  <line>b</line>
  <note/>
</root>`,
      }}
      referenceTable={{
        title: "Options and mapping rules",
        rows: [
          {
            parameter: "Root name",
            type: "element name",
            defaultVal: "root",
            description:
              "The single wrapping element. Required, because an XML document has exactly one root and JSON's top level does not supply a name.",
          },
          {
            parameter: "Attribute prefix",
            type: "string",
            defaultVal: "@",
            description:
              "Members starting with this become attributes. Matches the XML to JSON converter's default, so a document survives a round trip through both.",
          },
          {
            parameter: "Text key",
            type: "string",
            defaultVal: "#text",
            description:
              "The member written as element content rather than a child element. This is how an element gets both attributes and text.",
          },
          {
            parameter: "Item name",
            type: "element name",
            defaultVal: "item",
            description:
              "Element name for the items of a top-level array, which has no member name to borrow. Arrays that are members repeat the member's name instead.",
          },
          {
            parameter: "Indent",
            type: "spaces",
            defaultVal: "2",
            description:
              "Zero emits one line, which is what you want on the wire — whitespace between elements is significant to a strict parser and pretty-printing changes the document.",
          },
          {
            parameter: "Declaration",
            type: "boolean",
            defaultVal: "on",
            description:
              "Emits <?xml version=\"1.0\" encoding=\"UTF-8\"?>. Turn it off when the output is a fragment being embedded in a larger document.",
          },
          {
            parameter: "Self-close empty",
            type: "boolean",
            defaultVal: "on",
            description:
              "null and empty objects become <a/> rather than <a></a>. The two are identical to every XML parser; some downstream tools are fussier than the spec.",
          },
          {
            parameter: "Invalid key",
            type: "repaired",
            defaultVal: "original kept",
            description:
              "A key that cannot be an element name is rewritten and the original written to a name attribute. The number repaired is reported above the output.",
          },
          {
            parameter: "Escaping",
            type: "automatic",
            defaultVal: "—",
            description:
              "& < > in text; & < > \" and newlines in attribute values. An unescaped newline in an attribute is normalised to a space by the reader, which changes the value.",
          },
        ],
      }}
      faqs={[
        {
          question: "How do I get attributes instead of child elements?",
          answer:
            'Prefix the member name with @ — {"@id": "1"} becomes id="1" on the element. The prefix is configurable, and it is the same default the XML to JSON converter uses, so a document can go XML → JSON → XML and come back the same shape.',
        },
        {
          question: "Why did my key get renamed?",
          answer:
            "Because it is not a legal XML element name: it started with a digit, contained a space or a character XML does not allow, or was empty. The element name is repaired and the original key is written to a name attribute, so nothing is lost and the document is well-formed. The count is shown above the output so you know it happened.",
        },
        {
          question: "Why is there no wrapper element around my array?",
          answer:
            "Because XML expresses a list by repeating the element, not by wrapping it. {\"line\": [\"a\",\"b\"]} becomes two <line> elements, which is idiomatic XML and what round-trips correctly. If you want <lines><line>…</line></lines>, put that nesting in the JSON: {\"lines\": {\"line\": [\"a\",\"b\"]}}.",
        },
        {
          question: "Should I indent the output?",
          answer:
            "Not for anything going over the wire. Whitespace between elements is significant in XML — a strict parser sees your indentation as text nodes, and for mixed content it genuinely changes the document. Indent for reading, set indent to zero for sending. This is a real difference from JSON, where whitespace never matters.",
        },
        {
          question: "Can it produce a document that validates against my XSD?",
          answer:
            "Only by coincidence. A schema constrains element order, cardinality, datatypes and namespaces, and none of that information exists in JSON — an object's members have no meaningful order, so the converter cannot know what sequence your schema requires. Use this to get the shape, then reorder and add namespaces to match the schema.",
        },
        {
          question: "Is my JSON uploaded?",
          answer:
            "No. The parse and the conversion run in the tab you already have open, which you can confirm in the Network panel. The usual reason to convert JSON to XML is to feed an older enterprise system, and the payloads involved are rarely ones you would want passing through an unknown server.",
        },
      ]}
      relatedTools={relatedTools("/json-to-xml").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="JSON"
        outputLabel="XML"
        inputPlaceholder="Paste JSON here…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="converted.xml"
        height={420}
        options={
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
            {[
              { id: "x2j-root", label: "Root", value: rootName, onChange: setRootName, width: "w-28" },
              {
                id: "x2j-prefix",
                label: "Attr prefix",
                value: attributePrefix,
                onChange: setAttributePrefix,
                width: "w-16",
              },
              { id: "x2j-text", label: "Text key", value: textKey, onChange: setTextKey, width: "w-24" },
              { id: "x2j-item", label: "Item", value: itemName, onChange: setItemName, width: "w-20" },
            ].map((input) => (
              <div key={input.id} className="flex items-center gap-2">
                <label htmlFor={input.id} className={fieldLabel}>
                  {input.label}
                </label>
                <input
                  id={input.id}
                  type="text"
                  value={input.value}
                  onChange={(e) => input.onChange(e.target.value)}
                  spellCheck={false}
                  className={`${field} ${input.width}`}
                />
              </div>
            ))}

            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Indent</span>
              <div className={segmentTrack} role="group" aria-label="Indent">
                {[0, 2, 4].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setIndent(value)}
                    aria-pressed={indent === value}
                    className={segment(indent === value)}
                  >
                    {value === 0 ? "min" : value}
                  </button>
                ))}
              </div>
            </div>

            {[
              {
                id: "x2j-decl",
                label: "Declaration",
                checked: declaration,
                onChange: setDeclaration,
              },
              {
                id: "x2j-selfclose",
                label: "Self-close",
                checked: selfCloseEmpty,
                onChange: setSelfCloseEmpty,
              },
            ].map((toggle) => (
              <label
                key={toggle.id}
                htmlFor={toggle.id}
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id={toggle.id}
                  type="checkbox"
                  checked={toggle.checked}
                  onChange={(e) => toggle.onChange(e.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>{toggle.label}</span>
              </label>
            ))}
          </div>
        }
      />
    </ToolShell>
  );
};

/**
 * Walks the document for keys that cannot be XML element names.
 *
 * Iterative, like everything else that walks a pasted document: the point of a
 * converter is that it survives whatever is pasted into it.
 */
function collectRepairedKeys(value: unknown): string[] {
  const found = new Set<string>();
  const stack: unknown[] = [value];

  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || typeof node !== "object") continue;
    if (Array.isArray(node)) {
      for (const item of node) stack.push(item);
      continue;
    }
    for (const [key, child] of Object.entries(node as Record<string, unknown>)) {
      // Attribute and text members are not element names, so they are exempt.
      if (!key.startsWith("@") && key !== "#text" && toElementName(key).original) {
        found.add(key);
      }
      stack.push(child);
    }
  }

  return [...found];
}
