import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToXmlClient } from "./JsonToXmlClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-xml",
  title: "JSON to XML — Convert With Valid Element Names",
  socialTitle: "JSON to XML",
  description:
    "Convert JSON to XML in your browser. Prefixed members become attributes, arrays repeat their element name, and invalid names are repaired safely.",
});

export default function JsonToXmlPage() {
  return <JsonToXmlClient />;
}
