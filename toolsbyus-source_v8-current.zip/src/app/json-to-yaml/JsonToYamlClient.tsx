"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parseJson } from "../../lib/json/parser";
import { stringifyYaml, parseYaml, YAML_DEFAULTS } from "../../lib/yaml";
import { relatedTools } from "../../lib/tools";

const SAMPLE = JSON.stringify(
  {
    name: "checkout-api",
    version: "1.4.0",
    regions: ["NO", "SE", "DK"],
    build: "007",
    enabled: true,
    replicas: 3,
    startupScript: "#!/bin/sh\nset -eu\nexec node server.js\n",
    resources: { limits: { cpu: "500m", memory: "128Mi" }, requests: null },
    tags: [],
  },
  null,
  2
);

export const JsonToYamlClient: React.FC = () => {
  const [indent, setIndent] = useState(2);
  const [indentSequences, setIndentSequences] = useState(false);
  const [sortKeys, setSortKeys] = useState(false);
  const [documentStart, setDocumentStart] = useState(false);

  const transform = (input: string): TransformOutcome => {
    const parsed = parseJson(input);
    if (!parsed.success) {
      return {
        output: "",
        error: `Line ${parsed.error.line}, column ${parsed.error.column}: ${parsed.error.message}`,
      };
    }

    const options = {
      ...YAML_DEFAULTS,
      indent,
      indentSequences,
      sortKeys,
      documentStart,
    };
    const output = stringifyYaml(parsed.data, options);

    // Prove the claim rather than making it: the emitted YAML is parsed back
    // and compared. A quoting rule that misses one case shows up here.
    const back = parseYaml(output);
    const lossless =
      back.success && JSON.stringify(back.documents[0]) === JSON.stringify(parsed.data);

    return {
      output,
      warnings: lossless
        ? []
        : [
            "The emitted YAML did not parse back to the same JSON. This is a bug in the converter rather than in your document — please report the input.",
          ],
      stats: [
        { label: "Round trip", value: lossless ? "verified" : "FAILED" },
        { label: "Output", value: `${output.length.toLocaleString("en-GB")} bytes` },
        {
          label: "vs JSON",
          value: `${Math.round((1 - output.length / Math.max(input.length, 1)) * 100)}% smaller`,
        },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="json-to-yaml"
      keyword="JSON to YAML"
      directAnswer="JSON to YAML converts a document to YAML in your browser and verifies the result by parsing it back. The rule that makes that work: a string is quoted whenever writing it bare would resolve to something else — so the string &quot;no&quot; keeps its quotes, and so do &quot;007&quot;, &quot;null&quot; and &quot;12:30&quot;."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "JSON to YAML", url: "/json-to-yaml" },
      ]}
      seoDescription="Convert JSON to YAML in the browser. Ambiguous strings are quoted so the round trip is lossless, multi-line strings become block scalars, and every conversion is verified by parsing the output back."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Going from JSON to YAML sounds like the easy direction — YAML is a superset, so every
              JSON document is already valid YAML. That is true and it is not the job. The job is to
              produce YAML a person would want to read, which means block style rather than flow
              style, and that is where the correctness problem appears.
            </p>
            <h3>Quoting is not cosmetic</h3>
            <p>
              YAML resolves unquoted scalars by pattern. Write the string <code>no</code> without
              quotes and a YAML 1.1 reader loads the boolean <code>false</code>. Write{" "}
              <code>007</code> and you get the number 7. Write <code>null</code>, <code>true</code>,{" "}
              <code>12:30</code>, <code>0x1f</code> or <code>.inf</code> and each comes back as
              something that is not a string.
            </p>
            <p>
              So the emitter runs the resolution rules in reverse: a string is quoted whenever
              writing it bare would resolve to anything other than that string. It also quotes the
              tokens that <em>1.1</em> would resolve differently even though 1.2 would not, because
              the output should mean the same thing wherever it is read. This is why the result has
              quotes in places that look unnecessary — every one of them is load-bearing.
            </p>
            <h3>The round trip is checked, not claimed</h3>
            <p>
              Every conversion is parsed back and compared against the original JSON, and the result
              is reported in the stats strip. A quoting rule that misses one case is exactly the kind
              of bug that produces plausible output and a corrupted config, so the check runs on your
              document rather than only in a test suite.
            </p>
            <h3>Multi-line strings become block scalars</h3>
            <p>
              A string containing newlines is written as a <code>|</code> block, which is the reason
              people put certificates, scripts and SQL in YAML instead of JSON: a PEM key in JSON is
              one unreadable line of <code>\n</code> escapes. The chomping indicator follows the
              data — <code>|</code> when the string ends with a newline, <code>|-</code> when it does
              not — so the trailing byte survives.
            </p>
            <h3>Keys are quoted by the same rule as values</h3>
            <p>
              A key is a scalar too. <code>y: 2</code> loads as <code>&#123;True: 2&#125;</code> in a
              1.1 reader, and <code>on:</code> — the second key of every GitHub Actions workflow — is
              the best-known example. Keys get the same treatment as values, which is why{" "}
              <code>&quot;on&quot;</code> comes out quoted.
            </p>
          </>
        ),
        inputTitle: "JSON",
        exampleInput: `{
  "regions": ["NO", "SE"],
  "build": "007",
  "enabled": true
}`,
        outputTitle: "YAML",
        exampleOutput: `regions:
- "NO"
- "SE"
build: "007"
enabled: true`,
      }}
      referenceTable={{
        title: "Options and emission rules",
        rows: [
          {
            parameter: "Indent",
            type: "spaces",
            defaultVal: "2",
            description:
              "Spaces per level. YAML forbids tabs in indentation entirely, so this is a count and not a character.",
          },
          {
            parameter: "Indent sequences",
            type: "boolean",
            defaultVal: "off",
            description:
              "Off puts list dashes at the parent key's column, which is what hand-written Kubernetes manifests look like. On indents them one level, which is what most libraries emit. Both are valid.",
          },
          {
            parameter: "Sort keys",
            type: "boolean",
            defaultVal: "off",
            description:
              "Alphabetical rather than document order. Useful for diffing two configs that were written in different orders.",
          },
          {
            parameter: "Document start",
            type: "boolean",
            defaultVal: "off",
            description:
              "Emits the --- marker. Required when concatenating several documents into one file, as Kubernetes manifests usually are.",
          },
          {
            parameter: "Ambiguous strings",
            type: "quoted",
            defaultVal: "always",
            description:
              'no, yes, on, off, y, n, true, null, ~, 007, 12:30, 0x1f, .inf and the empty string. Each would resolve to a non-string if written bare.',
          },
          {
            parameter: "Multi-line strings",
            type: "block scalar",
            defaultVal: "on",
            description:
              "Written as a | block, with the chomping indicator matched to whether the string ends in a newline, so no byte is added or lost.",
          },
          {
            parameter: "Empty containers",
            type: "[] and {}",
            defaultVal: "explicit",
            description:
              "An empty array or object is written in flow style. Omitting them entirely would make an empty list indistinguishable from a null.",
          },
          {
            parameter: "null",
            type: "null",
            defaultVal: "null",
            description:
              "Written as the word null rather than left empty or written as ~, because it is the spelling that reads the same to a person and to every parser.",
          },
          {
            parameter: "Round trip",
            type: "verified",
            defaultVal: "every conversion",
            description:
              "The output is parsed back and compared to the input. The result is reported in the stats strip rather than assumed.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did it put quotes around my ordinary-looking string?",
          answer:
            'Because writing it bare would resolve to something else. "no" becomes the boolean false in a YAML 1.1 reader, "007" becomes the number 7, "12:30" becomes a sexagesimal number, and "null" becomes null. The quotes are the only thing keeping the value a string, which the round-trip check in the stats strip confirms on your actual document.',
        },
        {
          question: "Is YAML really smaller than JSON?",
          answer:
            "Usually, and the stats strip shows the number for your document. Dropping braces, brackets and the quotes around keys removes a surprising fraction of a config file. What YAML buys over JSON is not size, though — it is comments, which JSON has no way to express at all, and readable multi-line strings.",
        },
        {
          question: "Can I get my comments back?",
          answer:
            "No, and nothing can. JSON has no comments, so by the time a document is JSON the comments are already gone — there is nothing in the input to recover. If you are editing a YAML file, edit the YAML: a JSON round trip strips every comment and reorders nothing back.",
        },
        {
          question: "Which list style should I use?",
          answer:
            "Either; they parse identically. Dashes at the parent key's column is what hand-written Kubernetes manifests and GitHub workflows look like, and it saves two columns of indentation on deeply nested files. Indented dashes is what most libraries emit and what some house styles require. Pick the one that matches the files around it.",
        },
        {
          question: "Why is my multi-line string not escaped like it was in JSON?",
          answer:
            "Because it is written as a | block scalar, which keeps real line breaks instead of \\n escapes. This is the single best reason to use YAML for a config file: a PEM certificate or a shell script is readable in YAML and is one 3,000-character line in JSON. The chomping indicator is chosen to preserve whether your string ended with a newline.",
        },
        {
          question: "Is my JSON uploaded?",
          answer:
            "No. The parse, the conversion and the verification round trip all run in your browser. You can confirm it in the Network panel. It matters here because JSON being converted to YAML is usually about to become a config file, and config files carry connection strings and keys.",
        },
      ]}
      relatedTools={relatedTools("/json-to-yaml").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="JSON"
        outputLabel="YAML"
        inputPlaceholder="Paste JSON here…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="converted.yaml"
        height={420}
        options={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Indent</span>
              <div className={segmentTrack} role="group" aria-label="Indent">
                {[2, 4].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setIndent(value)}
                    aria-pressed={indent === value}
                    className={segment(indent === value)}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>

            {[
              {
                id: "yaml-indent-seq",
                label: "Indent lists",
                checked: indentSequences,
                onChange: setIndentSequences,
              },
              { id: "yaml-sort-keys", label: "Sort keys", checked: sortKeys, onChange: setSortKeys },
              {
                id: "yaml-doc-start",
                label: "--- marker",
                checked: documentStart,
                onChange: setDocumentStart,
              },
            ].map((toggle) => (
              <label
                key={toggle.id}
                htmlFor={toggle.id}
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id={toggle.id}
                  type="checkbox"
                  checked={toggle.checked}
                  onChange={(e) => toggle.onChange(e.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>{toggle.label}</span>
              </label>
            ))}
          </div>
        }
      />
    </ToolShell>
  );
};
