import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonToYamlClient } from "./JsonToYamlClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-to-yaml",
  title: "JSON to YAML — Convert With Safe Quoting",
  socialTitle: "JSON to YAML",
  description:
    "Convert JSON to YAML in your browser. Strings that would resolve to something else are quoted, so the round trip stays lossless. No upload.",
});

export default function JsonToYamlPage() {
  return <JsonToYamlClient />;
}
