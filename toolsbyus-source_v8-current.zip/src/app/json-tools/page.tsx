import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryOf } from "@/lib/tools";

const CATEGORY = categoryOf("json")!;
const LAST_REVIEWED = "2026-09-11";

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "JSON Tools — 19 Browser-Only Utilities",
  socialTitle: "JSON Tools",
  description:
    "Diff, format, minify, validate and explore JSON in your browser. No upload step, no sign-up, and every tool keeps working with the network disconnected.",
});

export default function JsonToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These JSON tools run entirely in your browser. Paste or drop a document and it is parsed, compared, reformatted or validated on your own machine — the payload is never uploaded. Each tool implements RFC 8259 strictly rather than relying on the browser's JSON.parse, so errors carry a line and a column."
      faqs={[
        {
          question: "Which JSON tool should I use to find why my payload is rejected?",
          answer:
            "Start with the JSON Validator. It reports the first syntax error with an exact line and column and a caret pointing at the offending character, and it classifies the common causes separately — a trailing comma, a single-quoted string, an unquoted key, a mismatched bracket, a byte-order mark, or a smart quote pasted from a word processor. If the document is close to valid, the one-click repair will fix it and show you exactly what it changed before you accept.",
        },
        {
          question: "Why does JSON Diff report no changes when the two documents look different?",
          answer:
            "Because object key order carries no meaning in JSON. RFC 8259 defines an object as an unordered collection, so {\"a\":1,\"b\":2} and {\"b\":2,\"a\":1} are the same document and a semantic diff says so. A line-based tool like Unix diff compares the serialised text and reports every reordered key as a change, which is why it is close to useless on formatted API responses.",
        },
        {
          question: "Is there a size limit?",
          answer:
            "Tools that run on the main thread stop at 8 MB, which is the point at which a single parse starts to make the tab feel broken. JSON Diff offloads to a Web Worker and accepts up to 100 MB. Above either ceiling the tool refuses with a clear message rather than freezing — a 50 MB comparison still takes real time, but the interface stays responsive while it runs.",
        },
        {
          question: "Do these tools handle JSONC — JSON with comments?",
          answer:
            "The JSON Formatter does. It accepts // and /* */ comments and trailing commas on input and can strip them on output, which is what you want for tsconfig.json, .eslintrc.json and similar config files. The Validator is deliberately stricter: it holds the document to RFC 8259 exactly, because when you are asking whether an API will accept a payload, a permissive answer is the wrong one.",
        },
        {
          question: "Can I use these offline?",
          answer:
            "Yes. Load any tool page once and it keeps working with the network off — disconnect Wi-Fi and try it. There is nothing on the other end to talk to: the site is a static export with no API routes, and every engine is JavaScript already running in your tab.",
        },
      ]}
      intro={
        <>
          <p>
            Almost every JSON tool on the web is a form that posts your document to a server. For a
            snippet from a tutorial that is fine. For the actual payload you are debugging it is
            rarely fine at all: production JSON tends to carry access tokens, customer records,
            internal hostnames and account identifiers, and pasting it into an unknown endpoint
            hands all of that to somebody else&rsquo;s access log. In a regulated environment it is
            not a judgement call, it is a reportable incident.
          </p>
          <p>
            The tools here take the server out of the question entirely. The page you load is
            static HTML and JavaScript; when you paste a document, it is parsed by code already
            running in your tab. There is no request to inspect and no endpoint to trust, which is
            a much stronger position than a promise not to look.
          </p>
          <p>
            That decision also makes them faster. There is no upload, no queue and no round trip, so
            a 2 MB document formats in the time it takes to repaint rather than the time it takes
            to cross the Atlantic twice. And it means they work on an aeroplane, on a locked-down
            corporate network, and inside a VPN that blocks everything it does not recognise.
          </p>
          <p>
            The engines are written by hand rather than assembled from packages, which matters more
            than it sounds. The parser is iterative rather than recursive, so a deeply nested
            document reports an error instead of blowing the JavaScript call stack — there is a test
            in the suite that feeds it twenty thousand levels of nesting. Every key that comes from
            your document is assigned through an own-property guard, so a payload containing{" "}
            <code>__proto__</code> cannot alter the behaviour of the page that is inspecting it.
            These are not theoretical concerns; they are the two ways JSON tools actually break.
          </p>
          <p>
            Where a standard exists, it is followed exactly: RFC 8259 for the grammar, RFC 6902 for
            patch documents, RFC 7386 for merge patches, and JSON Schema Draft 2020-12 for
            inference and validation. When a tool has to make a choice the standard leaves open —
            how to match array elements when comparing, whether to sort keys on output — it is
            exposed as a setting rather than hard-coded, and the reference table on each page says
            what the setting does at the edges.
          </p>
          <p>
            If you are not sure where to start:{" "}
            <Link href="/json-validator">JSON Validator</Link> for a document that will not parse,{" "}
            <Link href="/json-diff">JSON Diff</Link> for two documents that should match and
            do not, <Link href="/json-formatter">JSON Formatter</Link> for something unreadable, and{" "}
            <Link href="/json-schema-generator">Schema Generator</Link> when you need to describe
            the shape of a response you did not write.
          </p>
        </>
      }
    />
  );
}
