"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox } from "../../components/common/controls";
import { unescapeToDocument } from "../../lib/json/escape";
import { serializeJson } from "../../lib/json/serializer";
import { relatedTools } from "../../lib/tools";

const SAMPLE =
  '"{\\"service\\":\\"checkout\\",\\"retries\\":3,\\"note\\":\\"Timeout is 3s\\\\nRetry on 502 only\\",\\"path\\":\\"C:\\\\\\\\logs\\\\\\\\checkout.log\\"}"';

export const JsonUnescapeClient: React.FC = () => {
  const [prettyPrint, setPrettyPrint] = useState(true);

  const transform = useCallback(
    (input: string): TransformOutcome => {
      const result = unescapeToDocument(input);
      const warnings = [...result.warnings];

      let output = result.text;
      if (prettyPrint && result.parsed.success) {
        output = serializeJson(result.parsed.data, { indent: 2 });
      } else if (prettyPrint && !result.parsed.success) {
        warnings.push(
          `Unescaped, but the result is not valid JSON, so it is shown as plain text: ${result.parsed.error.message} (line ${result.parsed.error.line}, column ${result.parsed.error.column}).`
        );
      }

      return {
        output,
        warnings,
        stats: [
          { label: "In", value: `${new Blob([input]).size} B` },
          { label: "Out", value: `${new Blob([output]).size} B` },
          { label: "Quoted", value: result.hadQuotes ? "yes" : "no" },
          { label: "Valid JSON", value: result.parsed.success ? "yes" : "no" },
        ],
      };
    },
    [prettyPrint]
  );

  return (
    <ToolShell
      wide
      slug="json-unescape"
      keyword="JSON Unescape"
      // A JSX attribute cannot carry these backslashes and quotes literally,
      // so the sentence is an expression rather than an attribute string.
      directAnswer={
        'JSON Unescape reverses string escaping: it turns \\" back into a quote, \\n back into a ' +
        'newline and \\uXXXX back into its character, recovering the document that was embedded ' +
        'inside another one. It is deliberately tolerant of fragments copied out of log lines, ' +
        'which usually arrive missing their outer quotes.'
      }
      breadcrumbs={[
        { name: "JSON Tools", url: "/json-tools" },
        { name: "JSON Unescape", url: "/json-unescape" },
      ]}
      seoDescription="Unescape a JSON string literal back into a readable document. Handles \\n, \\t, \\uXXXX and surrogate pairs, tolerates fragments from log lines, and pretty-prints the result."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              You almost always arrive at this tool from a log file. Something logged a request body
              by putting the whole JSON document into a single string field, and what you are
              looking at is a dense line of <code>\&quot;</code> where the quotes should be, with{" "}
              <code>\n</code> instead of line breaks and <code>\\</code> wherever a Windows path
              appeared. It is technically readable and practically not.
            </p>
            <p>
              Unescaping is the inverse of escaping, and mechanically simple: scan the text, and
              each time a backslash appears, consume the character after it and emit what the pair
              stands for. The judgement is entirely in how to handle the input being imperfect,
              which it nearly always is.
            </p>
            <p>
              A strict JSON parser would reject most of what people paste here. The fragment has
              usually lost its surrounding quotes to a copy-paste that selected the interesting
              part. It may be truncated by a log field&rsquo;s length limit. It may contain a
              backslash that is not a valid JSON escape at all, because the thing that produced it
              was escaping for a different target. A parser that refuses all of these is correct
              and useless.
            </p>
            <p>
              So this is tolerant on purpose. Missing outer quotes are fine and reported rather than
              required. An unknown escape such as <code>\q</code> keeps both characters and raises a
              warning. A trailing backslash is kept. An incomplete <code>\u</code> sequence is left
              as written. In every case the rest of the document is still recovered, because a
              partially recovered payload is far more use than an error message.
            </p>
            <p>
              Unicode gets proper treatment. A <code>\uXXXX</code> escape becomes its character, and
              a high surrogate followed by a low surrogate is recombined into the single character
              they jointly encode — without that step every emoji and every rarer CJK glyph comes
              out as two replacement boxes.
            </p>
            <p>
              Once unescaped, the result is checked: if it is valid JSON it is pretty-printed, which
              is nearly always what you actually wanted. If it is not, it is shown as plain text
              with the parse error, so you can see whether the document was truncated in the log or
              was broken before it got there.
            </p>
          </>
        ),
        inputTitle: "Escaped string",
        exampleInput: `"{\\"name\\":\\"Ada\\",\\"note\\":\\"line one\\nline two\\"}"`,
        outputTitle: "Recovered document",
        exampleOutput: `{
  "name": "Ada",
  "note": "line one\nline two"
}`,
      }}
      referenceTable={{
        title: "Escape sequences and tolerances",
        rows: [
          {
            parameter: '\\" \\\\ \\/',
            type: "escape",
            defaultVal: "—",
            description:
              "Quote, backslash and forward slash. The slash escape is legal but optional in JSON, so it appears in some producers' output and not others.",
          },
          {
            parameter: "\\n \\r \\t \\b \\f",
            type: "escape",
            defaultVal: "—",
            description:
              "The named control characters. \\n is the one that makes the difference between a wall of text and a readable document.",
          },
          {
            parameter: "\\uXXXX",
            type: "escape",
            defaultVal: "—",
            description:
              "A UTF-16 code unit. A high surrogate followed by a low one is recombined into the single character it encodes; without that, every emoji and many CJK characters come back as two broken boxes.",
          },
          {
            parameter: "Surrounding quotes",
            type: "optional",
            defaultVal: "stripped if present",
            description:
              "A fragment pasted out of a log line has usually lost them. Whether they were there is reported rather than required.",
          },
          {
            parameter: "Unknown escape",
            type: "kept + warning",
            defaultVal: "—",
            description:
              "\\q and similar keep both characters. A strict parser rejects the whole document; keeping going recovers the rest, which is what you came for.",
          },
          {
            parameter: "Lone surrogate",
            type: "kept + warning",
            defaultVal: "—",
            description:
              "A high surrogate with no low half cannot form a character. It is preserved and flagged, since it usually means the source was truncated mid-character.",
          },
          {
            parameter: "Pretty-print",
            type: "boolean",
            defaultVal: "true",
            description:
              "Re-indents when the recovered text is valid JSON. When it is not, the raw text is shown with the parse error, which distinguishes a truncated log field from a document that was already broken.",
          },
        ],
      }}
      faqs={[
        {
          question: "My log line is double-escaped. Do I run this twice?",
          answer:
            "Yes. Double-escaping happens when an already-escaped string is escaped again — a payload logged as a string, then that log line logged as a string by an aggregator. You will see \\\\\\\" where \\\" should be. Run the output back through the tool and the second layer comes off. If it looks the same after a pass, you have reached the bottom.",
        },
        {
          question: "Why is the result still not valid JSON?",
          answer:
            "Usually truncation. Log fields have length limits, so the document is often cut mid-string or mid-object, and unescaping it faithfully produces something that cannot parse because it genuinely is incomplete. The parse error names the line and column where it stops, which normally lands exactly at the truncation point.",
        },
        {
          question: "What happened to my emoji?",
          answer:
            "If they survived, the surrogate pair was recombined correctly. If a tool shows two boxes instead, it decoded each \\uXXXX half independently — characters outside the Basic Multilingual Plane are encoded as two code units and must be joined. This tool joins them, and warns when it finds a lone half, which indicates truncation.",
        },
        {
          question: "Can I paste text that is not JSON?",
          answer:
            "Yes. The unescaping is textual, so an escaped SQL statement, an escaped HTML fragment or an escaped shell command unescapes fine. It will simply report that the result is not valid JSON and show it as plain text rather than pretty-printing it.",
        },
        {
          question: "Is the log line I paste sent anywhere?",
          answer:
            "No. Unescaping runs in your browser. This matters more here than for most tools: the log lines people unescape are frequently production request bodies containing tokens, session identifiers and customer records, and pasting one into a server-side tool copies it into a second access log.",
        },
      ]}
      relatedTools={relatedTools("/json-unescape").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="Escaped string"
        outputLabel="Recovered document"
        inputPlaceholder='Paste an escaped fragment, with or without its outer quotes…'
        initialInput={SAMPLE}
        transform={transform}
        options={
          <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
            <input
              type="checkbox"
              className={checkbox}
              checked={prettyPrint}
              onChange={(e) => setPrettyPrint(e.target.checked)}
            />
            Pretty-print when the result is valid JSON
          </label>
        }
      />
    </ToolShell>
  );
};
