import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonUnescapeClient } from "./JsonUnescapeClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-unescape",
  title: "JSON Unescape — Recover JSON From a Log Line",
  socialTitle: "JSON Unescape",
  description:
    "Unescape a JSON string literal back into a readable document. Handles \\n, \\uXXXX and surrogate pairs, and tolerates fragments copied out of log lines.",
});

export default function JsonUnescapePage() {
  return <JsonUnescapeClient />;
}
