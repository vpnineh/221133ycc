import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonValidatorClient } from "./JsonValidatorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-validator",
  title: "JSON Validator — Find and Fix the Broken Line",
  socialTitle: "JSON Validator",
  description:
    "Validate JSON against RFC 8259 with exact line and column caret tracking, plain-English diagnosis, and malformed-input classification.",
});

export default function JsonValidatorPage() {
  return <JsonValidatorClient />;
}
