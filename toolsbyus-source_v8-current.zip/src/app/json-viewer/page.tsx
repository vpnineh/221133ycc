import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JsonViewerClient } from "./JsonViewerClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/json-viewer",
  title: "JSON Viewer — Explore Large Payloads as a Tree",
  socialTitle: "JSON Viewer",
  description:
    "View JSON as a collapsible tree in your browser. Virtualized for large documents, with search across collapsed branches and copyable RFC 6901 pointers.",
});

export default function JsonViewerPage() {
  return <JsonViewerClient />;
}
