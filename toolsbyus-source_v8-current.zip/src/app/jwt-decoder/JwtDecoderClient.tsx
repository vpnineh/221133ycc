"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { Icon } from "../../components/common/Icon";
import { btnCompact, chip, panel, panelHeader } from "../../components/common/controls";
import { decodeJwt, type JwtAdvisory, type JwtClaim } from "../../lib/jwt";
import { relatedTools } from "../../lib/tools";

/**
 * A sample token, built so every advisory the tool can raise has something to
 * point at: it is signed with HS256, has an audience, and expired in the past.
 * A worked example that produces a clean result teaches nothing about what the
 * tool is for.
 */
const SAMPLE_TOKEN = [
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImF1dGgtMjAyNS0wOSJ9",
  "eyJzdWIiOiJ1c3JfOGYyYTFiIiwiaXNzIjoiaHR0cHM6Ly9hdXRoLmV4YW1wbGUuY29tIiwiYXVkIjoiYXBpLmV4YW1wbGUuY29tIiwiaWF0IjoxNzU3NTQyNDAwLCJleHAiOjE3NTc1NDYwMDAsInNjb3BlIjoicmVhZDpvcmRlcnMgd3JpdGU6b3JkZXJzIiwidGVuYW50X2lkIjoiYWNtZS1ldSJ9",
  "3Zc0Kz1qHhVQ9oFmR2sT7xYbN4dJwEuLpAiCgXvKmO8",
].join(".");

const SEVERITY_TONE: Record<JwtAdvisory["severity"], "danger" | "warn" | "info"> = {
  error: "danger",
  warning: "warn",
  info: "info",
};

const ClaimRow: React.FC<{ claim: JwtClaim }> = ({ claim }) => (
  <tr className="border-b border-border last:border-0">
    <th scope="row" className="whitespace-nowrap px-3 py-2 text-left align-top">
      <span className="font-mono text-xs font-medium text-accent">{claim.name}</span>
      {claim.registered && (
        <span className="mt-1 block font-mono text-2xs text-foreground-subtle">registered</span>
      )}
    </th>
    <td className="px-3 py-2 align-top font-mono text-xs text-foreground">
      <span className="break-all">
        {typeof claim.value === "string" ? claim.value : JSON.stringify(claim.value)}
      </span>
      {claim.decoded && (
        <span className="mt-1 block text-2xs text-foreground-muted">{claim.decoded}</span>
      )}
    </td>
    <td className="px-3 py-2 align-top text-xs leading-relaxed text-foreground-muted">
      {claim.description ?? <span className="text-foreground-subtle">Custom claim.</span>}
    </td>
  </tr>
);

export const JwtDecoderClient: React.FC = () => {
  const [raw, setRaw] = useState(SAMPLE_TOKEN);

  // `now` is fixed per render rather than read inside the memo, so the decoded
  // relative times do not shift between the claims table and the advisories.
  const result = useMemo(() => decodeJwt(raw), [raw]);

  const [copied, setCopied] = useState<string | null>(null);
  const copy = async (label: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      // Clipboard denied; the text stays selectable.
    }
  };

  return (
    <ToolShell
      wide
      slug="jwt-decoder"
      keyword="JWT Decoder"
      directAnswer="JWT Decoder reads the header and payload of a JSON Web Token in your browser and explains what it found: the signing algorithm, every claim with its meaning, and expiry decoded into a real date. It never verifies the signature, because that would require sending your token to whoever holds the key."
      breadcrumbs={[
        { name: "Encoding Tools", url: "/encode-tools" },
        { name: "JWT Decoder", url: "/jwt-decoder" },
      ]}
      seoDescription="Decode a JWT in your browser. Reads the header and payload, explains every registered claim, decodes exp and iat into real dates, and flags alg:none and expired tokens. The token is never transmitted."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A JSON Web Token is three base64url-encoded segments joined by dots:{" "}
              <code>header.payload.signature</code>. The first two are JSON objects, and{" "}
              <strong>they are not encrypted</strong> — base64url is an encoding, not a cipher.
              Anyone holding the token can read every claim in it, which is why putting a password,
              a card number or an internal database ID into a JWT payload is a mistake people make
              regularly and discover late.
            </p>
            <p>
              Decoding is therefore straightforward: split on the dots, base64url-decode the first
              two segments, parse each as JSON. The care goes into the details that break naive
              decoders. JWT segments are <em>unpadded</em> base64url (RFC 7515 §2), so a decoder
              that insists on <code>=</code> padding rejects most real tokens. The alphabet uses{" "}
              <code>-</code> and <code>_</code> rather than <code>+</code> and <code>/</code>, so a
              standard Base64 decoder fails on roughly half of all tokens depending on what the
              random bytes happened to encode.
            </p>
            <p>
              What this tool adds beyond decoding is interpretation. Registered claims from RFC 7519
              are annotated with what they mean. <code>exp</code>, <code>nbf</code> and{" "}
              <code>iat</code> are NumericDates — seconds since the Unix epoch — so they are
              rendered as a real timestamp and a relative time, because &ldquo;1757546000&rdquo; is
              not something you can act on and &ldquo;expired 4 hours ago&rdquo; is.
            </p>
            <p>
              Then it looks for the specific problems that cause incidents: an{" "}
              <code>alg</code> of <code>none</code>, an empty signature segment, a token with no{" "}
              <code>exp</code>, a token not yet valid because the issuer&rsquo;s clock is ahead, a
              missing <code>aud</code> that allows the token to be replayed against a different
              service trusting the same issuer.
            </p>
            <p>
              It deliberately stops short of verification. Checking a signature needs the
              issuer&rsquo;s secret or public key, and the only way a web page gets one is by
              sending your token somewhere. Offering that would undo the single property that makes
              it safe to paste a live credential into this page.
            </p>
          </>
        ),
        inputTitle: "Token segment",
        exampleInput: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9
  .eyJzdWIiOiJ1c3JfOGYyYTFiIiwiZXhwIjoxNzU3NTQ2MDAwfQ
  .3Zc0Kz1qHhVQ9oFmR2sT7xYbN4dJwEuLpAiCgXvKmO8`,
        outputTitle: "Decoded",
        exampleOutput: `header  { "alg": "HS256", "typ": "JWT" }
payload { "sub": "usr_8f2a1b", "exp": 1757546000 }

exp  2026-09-10 21:53:20 UTC  (expired)
sub  Subject — who the token is about`,
      }}
      referenceTable={{
        title: "JWT structure and the checks this tool performs",
        rows: [
          {
            parameter: "alg",
            type: "string",
            defaultVal: "required",
            description:
              "Signing algorithm, in the header. HS* is HMAC with a shared secret; RS*/PS* are RSA; ES* is ECDSA; EdDSA is Ed25519. A value of \"none\" is flagged as an error: a library that trusts alg from the token itself lets anyone forge one.",
          },
          {
            parameter: "typ / kid",
            type: "string",
            defaultVal: "optional",
            description:
              "typ is conventionally \"JWT\". kid identifies which key signed the token, and is what lets an issuer rotate keys without invalidating everything at once.",
          },
          {
            parameter: "exp",
            type: "NumericDate",
            defaultVal: "optional",
            description:
              "Seconds since the Unix epoch, not milliseconds and not an ISO string. Decoded here to a UTC timestamp and a relative time. A token with no exp never expires by itself and can only be stopped by revocation.",
          },
          {
            parameter: "nbf",
            type: "NumericDate",
            defaultVal: "optional",
            description:
              "Not-before. A token that is not valid yet is almost always clock skew between the issuing server and the machine reading it, rather than a deliberate delay.",
          },
          {
            parameter: "aud",
            type: "string | string[]",
            defaultVal: "optional",
            description:
              "Intended recipient. A service must reject a token whose audience is not itself; without aud, a token minted for one service can be replayed against another that trusts the same issuer.",
          },
          {
            parameter: "Segment encoding",
            type: "base64url",
            defaultVal: "unpadded",
            description:
              "RFC 7515 §2 uses the URL-safe alphabet (- and _) with padding removed. Standard Base64 decoders fail on tokens whose bytes produce + or /, which is why a token sometimes decodes in one tool and not another.",
          },
          {
            parameter: "Signature",
            type: "base64url",
            defaultVal: "not verified",
            description:
              "Shown but never checked. Verification requires the issuer's key; obtaining one would mean transmitting your token. An empty signature segment is flagged, since it means no integrity protection at all.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "The main-thread ceiling shared across the site. Real tokens are a few kilobytes; the limit exists so pasting the wrong thing cannot lock the tab.",
          },
        ],
      }}
      faqs={[
        {
          question: "Is it safe to paste a real JWT into this page?",
          answer:
            "The decoding happens entirely in your browser and the token is never transmitted — open DevTools, switch to the Network panel, paste a token, and you will see no request carrying it. That makes this page categorically safer than a decoder that posts to a server, where your token lands in an access log. The remaining caveat is not about this site: any credential you paste into any browser on a machine you do not control should be rotated afterwards.",
        },
        {
          question: "Why can't it verify the signature?",
          answer:
            "Because verification needs the key. For HS256 that is the shared secret; for RS256 it is the issuer's public key, usually fetched from a JWKS endpoint. A browser page could only do either by sending your token, or the secret, somewhere — which would destroy the property that makes this page safe to use. Verification belongs in your service, where the key already lives.",
        },
        {
          question: "My token decodes here but my library rejects it. Why?",
          answer:
            "Decoding and accepting are different questions. The commonest causes are: the token has expired (check the exp row — this tool shows it as a real date); the audience does not match what your service expects; the nbf is in the future because the issuing server's clock is ahead; or the signature does not verify against the key your service is configured with, often because the issuer rotated keys and the kid now refers to one your cache has not picked up.",
        },
        {
          question: "What does alg: none mean and why is it flagged as an error?",
          answer:
            "It means the token is unsigned. The danger is not the value itself but what a verifier does with it: some JWT libraries historically read alg from the token and selected the verification method accordingly, so an attacker could take a valid token, change the algorithm to none, strip the signature, and have it accepted. A correct verifier decides the expected algorithm from its own configuration and ignores what the token claims.",
        },
        {
          question: "Is a JWT encrypted?",
          answer:
            "No. A standard JWT (a JWS) is signed, not encrypted — the signature proves the payload has not been altered, and does nothing to hide it. Every claim is readable by anyone holding the token, which is exactly what this page demonstrates. If you need the contents hidden you want a JWE, which has five segments rather than three and cannot be read without the decryption key.",
        },
        {
          question: "Can I decode a token that has already expired?",
          answer:
            "Yes. Expiry is a claim inside the payload, not a property of the encoding, so an expired token decodes exactly like a live one. This tool reads it and tells you when it expired and how long ago, which is usually the fastest way to confirm that an intermittent 401 is a token-lifetime problem rather than a permissions one.",
        },
      ]}
      relatedTools={relatedTools("/jwt-decoder").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <CodePane
          label="JSON Web Token"
          value={raw}
          onChange={setRaw}
          placeholder="Paste a JWT, with or without the Bearer prefix…"
          height={150}
        />

        {!result.ok ? (
          raw.trim() === "" ? (
            <Notice tone="info" title="Nothing to decode.">
              Paste a token above. Nothing is uploaded — the decoding happens in this tab.
            </Notice>
          ) : (
            <Notice tone="danger" title="Not a readable JWT:">
              {result.reason}
            </Notice>
          )
        ) : (
          <>
            <div className={panel}>
              <div className={panelHeader}>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-foreground">Signature</span>
                  <span className={chip}>{result.algorithm || "no alg"}</span>
                  <span className={chip}>{result.algorithmFamily}</span>
                </div>
                <button
                  type="button"
                  className={btnCompact}
                  onClick={() => copy("signature", result.segments.signature)}
                >
                  <Icon name={copied === "signature" ? "check" : "copy"} size="sm" />
                  {copied === "signature" ? "Copied" : "Copy signature"}
                </button>
              </div>
              <p className="px-3 py-2.5 font-mono text-2xs leading-relaxed text-foreground-muted">
                <span className="break-all">{result.segments.signature || "(empty)"}</span>
              </p>
              <p className="border-t border-border px-3 py-2 text-2xs leading-relaxed text-foreground-subtle">
                Shown, never checked. Verifying needs the issuer&rsquo;s key, and fetching one would
                mean sending this token somewhere.
              </p>
            </div>

            {result.advisories.length > 0 && (
              <div className="space-y-2">
                {result.advisories.map((advisory, index) => (
                  <Notice key={index} tone={SEVERITY_TONE[advisory.severity]}>
                    {advisory.message}
                  </Notice>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <CodePane
                label="Header"
                value={JSON.stringify(result.header, null, 2)}
                onChange={() => undefined}
                readOnly
                height={160}
              />
              <CodePane
                label="Payload"
                value={JSON.stringify(result.payload, null, 2)}
                onChange={() => undefined}
                readOnly
                height={160}
              />
            </div>

            <div className={panel}>
              <div className={panelHeader}>
                <span className="text-xs font-semibold text-foreground">
                  Claims ({result.claims.length})
                </span>
                <span className="font-mono text-2xs text-foreground-subtle">
                  RFC 7519 registered claims are annotated
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[34rem] border-collapse text-left">
                  <caption className="sr-only">Decoded JWT claims</caption>
                  <thead className="bg-surface-elevated">
                    <tr className="border-b border-border">
                      <th scope="col" className="px-3 py-2 font-mono text-2xs text-foreground-subtle">
                        Claim
                      </th>
                      <th scope="col" className="px-3 py-2 font-mono text-2xs text-foreground-subtle">
                        Value
                      </th>
                      <th scope="col" className="px-3 py-2 font-mono text-2xs text-foreground-subtle">
                        Meaning
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.claims.map((claim) => (
                      <ClaimRow key={claim.name} claim={claim} />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </ToolShell>
  );
};
