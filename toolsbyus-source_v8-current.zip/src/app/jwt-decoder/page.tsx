import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { JwtDecoderClient } from "./JwtDecoderClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/jwt-decoder",
  title: "JWT Decoder — Inspect Claims Without Sending It",
  socialTitle: "JWT Decoder",
  description:
    "Decode a JSON Web Token in your browser. Reads the header and payload, explains every claim, turns exp into a real date, and flags alg:none. Never transmitted.",
});

export default function JwtDecoderPage() {
  return <JwtDecoderClient />;
}
