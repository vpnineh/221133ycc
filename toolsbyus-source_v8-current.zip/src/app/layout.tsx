import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Header } from "../components/common/Header";
import { Footer } from "../components/common/Footer";
import { CommandPalette } from "../components/common/CommandPalette";
import { ScrollToTop } from "../components/common/ScrollToTop";
import { Analytics } from "../components/common/Analytics";
import { SITE_NAME, SITE_URL, SITE_TAGLINE, absoluteUrl } from "../lib/site";

/*
 * Two faces from one superfamily, both variable.
 *
 * Geist sets everything a person reads; Geist Mono sets everything a machine
 * wrote — payloads, byte counts, key paths, file sizes. They share a skeleton,
 * so a JSON key beside its description does not read as two unrelated designs,
 * and the mono's digits line up with the sans's in the same row.
 *
 * Both are *variable* fonts, which is why using a real sans is now affordable:
 * one woff2 per family covers 400 through 700, where the previous static
 * four-weight cut of JetBrains Mono shipped four separate files for one family
 * and still left prose on whatever the platform happened to have. The earlier
 * note here concluded that a second family cost too much; with variable cuts
 * the arithmetic changed, and the site no longer has to render its prose in
 * San Francisco on one machine and Segoe UI on another.
 *
 * next/font fetches them at build time and emits same-origin
 * /_next/static/media/*.woff2, so the browser makes no request to
 * fonts.googleapis.com or fonts.gstatic.com. That is what keeps
 * `font-src 'self'` in the Content-Security-Policy true, and keeps the privacy
 * page's "no third-party requests" claim literal.
 */
const sans = Geist({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-sans",
  fallback: ["-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "sans-serif"],
});

const mono = Geist_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-mono",
  fallback: ["ui-monospace", "SFMono-Regular", "Menlo", "Consolas", "monospace"],
});

export const metadata: Metadata = {
  title: {
    default: "ToolsByUs — Free Browser Tools for JSON, Files and Text",
    // Tool pages supply their own name; this keeps the brand suffix consistent.
    template: "%s | ToolsByUs",
  },
  description:
    "JSON, text, PDF and image tools that run entirely in your browser. Process files locally with no upload or account required.",
  metadataBase: new URL(SITE_URL),
  applicationName: SITE_NAME,
  alternates: {
    canonical: absoluteUrl("/"),
  },
  keywords: [
    "JSON formatter",
    "JSON viewer",
    "JSON diff",
    "JWT decoder",
    "XML formatter",
    "JSON to CSV",
    "merge PDF",
    "compress image",
    "browser tools",
    "offline tools",
  ],
  authors: [{ name: "ToolsByUs Team", url: SITE_URL }],
  creator: "ToolsByUs",
  publisher: "ToolsByUs",
  category: "technology",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  manifest: "/site.webmanifest",
  // Set NEXT_PUBLIC_GSC_VERIFICATION to the token from Search Console's
  // "HTML tag" method. DNS verification needs no code and is preferable; this
  // is the fallback for operators who do not control the zone.
  ...(process.env.NEXT_PUBLIC_GSC_VERIFICATION
    ? { verification: { google: process.env.NEXT_PUBLIC_GSC_VERIFICATION } }
    : {}),
  icons: {
    icon: [
      { url: "/favicon-32.png?v=8", type: "image/png", sizes: "32x32" },
      { url: "/favicon.svg?v=8", type: "image/svg+xml", sizes: "any" },
      { url: "/icon-192.png", type: "image/png", sizes: "192x192" },
      { url: "/icon-512.png", type: "image/png", sizes: "512x512" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: `ToolsByUs — ${SITE_TAGLINE}`,
    description:
      "JSON, text, PDF and image tools that process your file in the browser tab you already have open.",
    url: SITE_URL,
    siteName: SITE_NAME,
    type: "website",
    locale: "en_US",
    images: [
      {
        url: absoluteUrl("/og-image.png"),
        width: 1200,
        height: 630,
        alt: "ToolsByUs — browser tools that never upload your file",
        type: "image/png",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `ToolsByUs — ${SITE_TAGLINE}`,
    description: "JSON, text, PDF and image tools that run entirely in your browser.",
    images: [absoluteUrl("/og-image.png")],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  // Two entries so the browser chrome follows the page's own light/dark palette
  // instead of always painting the dark ground behind a light page.
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#000000" },
  ],
  colorScheme: "dark light",
};

/**
 * Applies the stored theme before first paint so the page never flashes the
 * wrong palette. Kept as a string constant because its SHA-256 hash is pinned
 * in the Content-Security-Policy — see public/_headers and
 * scripts/generate-csp.mjs, which recompute the hash from this exact text.
 *
 * Three states, not two. Anything that is not the literal string "light" or
 * "dark" — an unset key, the explicit "system", or a value some other tab wrote
 * — means *follow the operating system*, which is the default a visitor gets
 * until they choose otherwise. Writing the test this way round matters: the
 * previous version treated any stored value as a choice, so a stale or
 * corrupted entry pinned the site to one theme with no way back.
 */
export const THEME_INIT_SCRIPT = `try{var t=localStorage.getItem('ycd_theme');if(t!=='light'&&t!=='dark'){t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}if(t==='dark'){document.documentElement.classList.add('dark')}}catch(e){}`;

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${sans.variable} ${mono.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
      </head>
      <body className="min-h-screen flex flex-col bg-background text-foreground antialiased selection:bg-accent-soft selection:text-foreground">
        {/* First tabbable element: lets keyboard and screen-reader users jump
            past the nav on every page (WCAG 2.4.1). */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:rounded focus:border focus:border-accent focus:bg-surface focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-foreground"
        >
          Skip to main content
        </a>
        <Header />
        <main id="main-content" tabIndex={-1} className="flex-1 w-full">
          {children}
        </main>
        <Footer />
        {/* Mounted once at the root so Cmd/Ctrl+K works on every page. */}
        <CommandPalette />
        <ScrollToTop />
        <Analytics />
      </body>
    </html>
  );
}
