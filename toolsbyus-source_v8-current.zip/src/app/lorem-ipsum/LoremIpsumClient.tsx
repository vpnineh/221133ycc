"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { btnCompact, checkbox, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import {
  generateLorem,
  countStats,
  LOREM_DEFAULTS,
  type LoremFlavour,
  type LoremUnit,
} from "../../lib/text/lorem";
import { relatedTools } from "../../lib/tools";

const FLAVOURS: Array<{ id: LoremFlavour; label: string; hint: string }> = [
  { id: "classic", label: "Latin", hint: "The real vocabulary of Cicero's De finibus, 45 BC" },
  { id: "english", label: "English", hint: "Common English words: readable, so reviewers read it" },
  { id: "unicode", label: "Unicode", hint: "Text designed to break a layout that has only met ASCII" },
  { id: "hipster", label: "Hipster", hint: "For when the client keeps reading the placeholder" },
];

const UNITS: Array<{ id: LoremUnit; label: string }> = [
  { id: "paragraphs", label: "Paragraphs" },
  { id: "sentences", label: "Sentences" },
  { id: "words", label: "Words" },
  { id: "list", label: "List items" },
];

export const LoremIpsumClient: React.FC = () => {
  const [flavour, setFlavour] = useState<LoremFlavour>("classic");
  const [unit, setUnit] = useState<LoremUnit>("paragraphs");
  const [count, setCount] = useState(3);
  const [startWithLorem, setStartWithLorem] = useState(true);
  const [html, setHtml] = useState(false);
  const [sentenceLength, setSentenceLength] = useState(12);
  const [seed, setSeed] = useState(1);

  const output = useMemo(
    () =>
      generateLorem(
        { ...LOREM_DEFAULTS, flavour, unit, count, startWithLorem, html, sentenceLength },
        seed
      ),
    [flavour, unit, count, startWithLorem, html, sentenceLength, seed]
  );

  const stats = useMemo(() => countStats(output), [output]);

  return (
    <ToolShell
      wide
      slug="lorem-ipsum"
      keyword="Lorem Ipsum Generator"
      directAnswer="Lorem Ipsum Generator produces placeholder text in your browser. The classical passage is real Latin — a corrupted extract from Cicero written in 45 BC — which gives it the right word-length texture for a layout. It is also pure ASCII, which is why there is a Unicode mode whose entire purpose is to break a design that has never met an accent, an emoji or a right-to-left run."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "Lorem Ipsum", url: "/lorem-ipsum" },
      ]}
      seoDescription="Generate lorem ipsum placeholder text in the browser: paragraphs, sentences, words or list items, in Latin, English, Unicode stress-test or hipster vocabulary, with optional HTML markup."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Placeholder text has one job: look enough like real content that the layout you are
              testing behaves the way it will in production. Two things follow from that, and most
              generators get one of them.
            </p>
            <h3>The classical passage is real Latin</h3>
            <p>
              &ldquo;Lorem ipsum dolor sit amet&rdquo; is a corrupted extract from Cicero&apos;s{" "}
              <em>De finibus bonorum et malorum</em>, written in 45 BC, and it has been the printing
              trade&apos;s dummy text since the 1500s. That history is not decorative: real Latin has
              word lengths and letter frequencies close enough to real prose that a paragraph of it
              occupies about the space a paragraph of English will. Invented syllables do not, and a
              column that looks right filled with nonsense can overflow when filled with content.
            </p>
            <h3>Latin is ASCII, which is the problem</h3>
            <p>
              A design tested only with lorem ipsum has never encountered an accented character that
              makes a line taller, a combining mark that stacks above the cap height, an emoji with a
              skin-tone modifier that must not be split, a German compound noun too long to wrap, a
              right-to-left run that reorders around punctuation, or CJK text that does not break on
              spaces. Every one of those breaks real layouts and none of them appears in Latin. The
              Unicode mode exists to produce exactly that material, so the breakage happens in your
              editor rather than after launch.
            </p>
            <h3>The English mode is for reviews</h3>
            <p>
              The standard argument for Latin is that it stops people reading the placeholder and
              commenting on the copy. The counter-argument is that it also stops them noticing that
              the design cannot accommodate a realistic heading. Plain English words with realistic
              sentence lengths give you a page a reviewer can judge, at the cost of the occasional
              &ldquo;what does this sentence mean?&rdquo;
            </p>
            <h3>Deterministic, so tweaking an option shows what changed</h3>
            <p>
              The generator is seeded rather than using <code>Math.random</code>. With random output,
              changing the paragraph count re-rolls every word and you cannot see what your change
              did. Here the same options and seed always produce the same text, and the reroll button
              is explicit — which also means placeholder text you put in a fixture stays stable
              across runs.
            </p>
            <p>
              Sentence lengths vary around the average rather than matching it, because a paragraph
              of identical-length sentences reads as a block and does not exercise wrapping the way
              real prose does.
            </p>
          </>
        ),
        inputTitle: "Options",
        exampleInput: `3 paragraphs, Latin, starting with the canonical opening`,
        outputTitle: "Output",
        exampleOutput: `Lorem ipsum dolor sit amet, consectetur adipiscing elit
quidem laudantium, natus recusandae provident…`,
      }}
      referenceTable={{
        title: "Options",
        rows: [
          {
            parameter: "Latin",
            type: "flavour",
            defaultVal: "classic",
            description:
              "The genuine vocabulary of the Cicero passage. Right word-length texture, ASCII only, and unreadable enough that nobody reviews the copy.",
          },
          {
            parameter: "English",
            type: "flavour",
            defaultVal: "—",
            description:
              "Common English words. Readable, which is either the point or the problem depending on who is looking at the mockup.",
          },
          {
            parameter: "Unicode",
            type: "flavour",
            defaultVal: "—",
            description:
              "Accents, combining marks, CJK, right-to-left runs, emoji with modifiers, long unbroken words and look-alike characters. Designed to fail, early.",
          },
          {
            parameter: "Hipster",
            type: "flavour",
            defaultVal: "—",
            description:
              "English-shaped nonsense. Useful when a client keeps reading the placeholder and asking about it.",
          },
          {
            parameter: "Unit",
            type: "paragraphs / sentences / words / list",
            defaultVal: "paragraphs",
            description:
              "Words gives exactly the count requested, which matters when you are testing a truncation limit.",
          },
          {
            parameter: "Sentence length",
            type: "words",
            defaultVal: "12",
            description:
              "An average, not a target. Lengths vary around it, because uniform sentences do not exercise line wrapping the way prose does.",
          },
          {
            parameter: "Start with Lorem",
            type: "boolean",
            defaultVal: "on",
            description:
              "Begins with the canonical opening, which is what makes placeholder text recognisable as placeholder text at a glance.",
          },
          {
            parameter: "HTML",
            type: "boolean",
            defaultVal: "off",
            description: "Wraps paragraphs in <p> or list items in <ul><li>, ready to paste into markup.",
          },
          {
            parameter: "Seed",
            type: "integer",
            defaultVal: "1",
            description:
              "Deterministic output: the same options and seed always give the same text, so changing one option shows you what that option did.",
          },
        ],
      }}
      faqs={[
        {
          question: "Is lorem ipsum actually Latin?",
          answer:
            'Yes, corrupted. It comes from Cicero\'s De finibus bonorum et malorum, section 1.10.32, written in 45 BC — the original passage begins "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet". A printer in the 1500s scrambled it into dummy text and it has been in use ever since. The words are real; the text does not mean anything.',
        },
        {
          question: "Why is there a Unicode mode?",
          answer:
            "Because Latin is pure ASCII, so a layout tested only with lorem ipsum has never met a combining mark that makes a line taller, an emoji with a skin-tone modifier that must not be split, a German compound noun too long to wrap, or a right-to-left run that reorders around punctuation. All of those break real designs. The Unicode mode puts them in front of you while the design is still in an editor.",
        },
        {
          question: "Should I use Latin or English placeholder text?",
          answer:
            "Latin when you want people looking at the layout rather than the words — early wireframes, spacing decisions. English when you want a realistic judgement about whether the design can hold actual content, which is when a heading turning out to be four words longer than the mockup assumed becomes visible. Neither is a substitute for putting real copy in before you ship.",
        },
        {
          question: "Why does the same options always give me the same text?",
          answer:
            "Because the generator is seeded rather than random. With random output, changing the paragraph count re-rolls every word and you cannot tell what your change did. Press reroll for different text. It also means placeholder text you paste into a test fixture stays stable, so a snapshot test does not fail every run.",
        },
        {
          question: "Does placeholder text hurt SEO if it ships?",
          answer:
            "Yes, though not in the way people fear. Google does not have a lorem ipsum penalty; what happens is worse and more boring — the page gets indexed with no meaningful content, ranks for nothing, and may be classified as thin. The real risk is that it ships at all: search for \"lorem ipsum\" on your own domain before every release.",
        },
        {
          question: "Is anything uploaded?",
          answer:
            "No. The word lists and the generator are in the page; nothing is requested and nothing is sent. This one genuinely does not matter — placeholder text is not sensitive — but the same rule applies to every tool here, and an exception would be harder to explain than the consistency.",
        },
      ]}
      relatedTools={relatedTools("/lorem-ipsum").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Flavour</span>
            <div className={segmentTrack} role="group" aria-label="Flavour">
              {FLAVOURS.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setFlavour(option.id)}
                  aria-pressed={flavour === option.id}
                  title={option.hint}
                  className={segment(flavour === option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Unit</span>
            <div className={segmentTrack} role="group" aria-label="Unit">
              {UNITS.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setUnit(option.id)}
                  aria-pressed={unit === option.id}
                  className={segment(unit === option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="lorem-count" className={fieldLabel}>
              Count
            </label>
            <input
              id="lorem-count"
              type="number"
              min={1}
              max={500}
              value={count}
              onChange={(e) => setCount(Math.min(500, Math.max(1, Number(e.target.value) || 1)))}
              className={`${field} w-20`}
            />
          </div>

          {(unit === "paragraphs" || unit === "sentences") && (
            <div className="flex items-center gap-2">
              <label htmlFor="lorem-length" className={fieldLabel}>
                Words per sentence
              </label>
              <input
                id="lorem-length"
                type="number"
                min={3}
                max={40}
                value={sentenceLength}
                onChange={(e) =>
                  setSentenceLength(Math.min(40, Math.max(3, Number(e.target.value) || 12)))
                }
                className={`${field} w-20`}
              />
            </div>
          )}

          {flavour === "classic" && unit !== "list" && (
            <label
              htmlFor="lorem-start"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="lorem-start"
                type="checkbox"
                checked={startWithLorem}
                onChange={(e) => setStartWithLorem(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>Start with Lorem</span>
            </label>
          )}

          {(unit === "paragraphs" || unit === "list") && (
            <label
              htmlFor="lorem-html"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="lorem-html"
                type="checkbox"
                checked={html}
                onChange={(e) => setHtml(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>HTML</span>
            </label>
          )}

          <button type="button" onClick={() => setSeed((value) => value + 1)} className={btnCompact}>
            Reroll
          </button>

          <span className="ml-auto font-mono text-2xs text-foreground-subtle">
            {stats.words.toLocaleString("en-GB")} words ·{" "}
            {stats.characters.toLocaleString("en-GB")} characters ·{" "}
            {stats.bytes.toLocaleString("en-GB")} bytes
          </span>
        </div>

        <CodePane
          label="Placeholder text"
          value={output}
          onChange={() => undefined}
          readOnly
          height={380}
        />

        {flavour === "unicode" && (
          <Notice tone="info">
            This mode is meant to break things. It mixes combining marks, right-to-left runs, CJK,
            emoji with modifiers, long unbroken words and look-alike characters — every one of which
            appears in real user input and none of which appears in Latin placeholder text. If your
            layout survives this, it will survive your users.
          </Notice>
        )}
      </div>
    </ToolShell>
  );
};
