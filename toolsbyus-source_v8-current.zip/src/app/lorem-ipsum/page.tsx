import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { LoremIpsumClient } from "./LoremIpsumClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/lorem-ipsum",
  title: "Lorem Ipsum Generator — Seeded and Repeatable",
  socialTitle: "Lorem Ipsum",
  description:
    "Generate placeholder text in your browser — classical Latin, plain English, or a Unicode stress mode whose job is to break a layout that has only ever seen ASCII.",
});

export default function LoremIpsumPage() {
  return <LoremIpsumClient />;
}
