"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { FileResult } from "../../components/tools/FileResult";
import { usePdfWorker } from "../../components/tools/usePdfWorker";
import { Notice } from "../../components/common/Notice";
import { btnPrimary } from "../../components/common/controls";
import { formatBytes, type AcceptedFile } from "../../lib/files";
import { stemOf, withStem } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

export const MergePdfClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [outputName, setOutputName] = useState("");
  const { state, run, reset } = usePdfWorker();

  // Derived from the first file rather than a generic "merged": the result is
  // usually that document with the others appended, and `contract.pdf` +
  // `annex.pdf` is far more useful as `contract-merged.pdf` than as a name that
  // says nothing about which contract it is.
  const defaultStem = files[0] ? `${stemOf(files[0].file.name)}-merged` : "merged";

  const merge = async () => {
    const buffers = await Promise.all(files.map((entry) => entry.file.arrayBuffer()));
    run(
      {
        type: "merge",
        files: buffers,
        names: files.map((entry) => entry.file.name),
        name: withStem(outputName.trim() || defaultStem, "pdf"),
      },
      // Transferred rather than copied: a 40 MB selection copied into the
      // worker costs another 40 MB and a visible pause.
      buffers
    );
  };

  const totalBytes = files.reduce((sum, entry) => sum + entry.file.size, 0);

  return (
    <ToolShell
      slug="merge-pdf"
      keyword="Merge PDF"
      directAnswer="Merge PDF combines several PDF files into one, in your browser. The files are read, merged and written back in this tab — nothing is uploaded, which is the whole point when the documents being merged are a contract, a medical record or a year of bank statements."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Merge PDF", url: "/merge-pdf" },
      ]}
      seoDescription="Combine PDF files into one in your browser. Drag to reorder, no upload, no file size limit beyond your own memory, and no watermark. The merge runs in a Web Worker so the tab stays responsive."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Every other PDF merger asks you to upload your files. That is the part worth thinking
              about before the part about how merging works.
            </p>
            <h3>What uploading a PDF actually means</h3>
            <p>
              A PDF you merge is rarely a leaflet. It is a signed contract, a set of payslips, a
              medical letter, a passport scan for a visa application, a year of bank statements for a
              mortgage. Uploading it means handing a complete copy to a company whose retention
              policy you have not read, whose staff can open it, and whose breach notification you
              will receive some years later if at all. The file also sits on their disk long after
              the &ldquo;files deleted after one hour&rdquo; banner has scrolled away.
            </p>
            <p>
              Here the merge happens in the tab you already have open. You can verify it: open
              DevTools, switch to the Network panel, and merge. Nothing carrying your document
              leaves, because the page&apos;s Content-Security-Policy sets{" "}
              <code>connect-src &apos;self&apos;</code> — the browser would block an upload even if
              the code tried.
            </p>
            <h3>Merging is not concatenation</h3>
            <p>
              A PDF is an object graph with a cross-reference table, not a stream of pages. Every
              page references fonts, images, colour spaces and content streams by object number, and
              two documents both number their objects from one. Appending the bytes of one file to
              another produces something that is not a PDF at all.
            </p>
            <p>
              So each page is copied with its full dependency graph into the destination document,
              with every reference renumbered. That is why merging a 2 MB and a 3 MB file does not
              always give exactly 5 MB: shared resources are written once, and unreferenced objects
              in the originals are not carried over.
            </p>
            <h3>Order is the order you set</h3>
            <p>
              Files merge top to bottom, and the arrows reorder them. This sounds obvious and is the
              single most common complaint about merge tools, because a file picker returns files in
              whatever order the operating system felt like — frequently alphabetical, which puts
              &ldquo;page-10&rdquo; before &ldquo;page-2&rdquo;.
            </p>
            <h3>It runs in a Web Worker</h3>
            <p>
              Parsing and re-serialising a large PDF takes seconds of solid computation. On the main
              thread that freezes the tab completely — the browser cannot even paint a progress bar
              while JavaScript is running. The work happens on a separate thread, so the progress bar
              moves and the page stays responsive.
            </p>
            <h3>What is preserved, and what is not</h3>
            <p>
              Page content, fonts, images, vector graphics and page dimensions all survive exactly.
              Form fields, annotations and bookmarks are carried where the source document makes them
              page-level; document-level structure that cannot belong to two parents at once — the
              outline tree, the AcroForm dictionary — does not merge cleanly and is not faked.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `contract-signed.pdf   (4 pages)
appendix-a.pdf        (2 pages)
appendix-b.pdf        (7 pages)`,
        outputTitle: "Output",
        exampleOutput: `merged.pdf            (13 pages)
— object graphs renumbered
— shared resources written once`,
      }}
      referenceTable={{
        title: "Behaviour and limits",
        rows: [
          {
            parameter: "Upload",
            type: "never",
            defaultVal: "enforced by CSP",
            description:
              "connect-src 'self' means the browser blocks any request to another origin. This is not a promise in a privacy policy; it is a header the browser enforces.",
          },
          {
            parameter: "Order",
            type: "list order",
            defaultVal: "as dropped",
            description:
              "Top to bottom, reorderable with the arrows. A file picker returns files in the operating system's order, which is frequently alphabetical and therefore wrong.",
          },
          {
            parameter: "File size",
            type: "bytes",
            defaultVal: "100 MB each",
            description:
              "A PDF is held in memory several times over during a structural edit. Above the ceiling the tool declines rather than letting the tab be killed mid-merge.",
          },
          {
            parameter: "Total size",
            type: "bytes",
            defaultVal: "250 MB",
            description: "Across the whole selection, for the same reason.",
          },
          {
            parameter: "File count",
            type: "files",
            defaultVal: "100",
            description: "Enough for a year of statements; beyond that the list stops being usable.",
          },
          {
            parameter: "Encrypted PDFs",
            type: "declined",
            defaultVal: "—",
            description:
              "A password-protected document cannot be read without its password. Unlock it first if you have the password; nothing can open it if you do not.",
          },
          {
            parameter: "Page content",
            type: "preserved",
            defaultVal: "exactly",
            description:
              "Fonts, images, vector graphics and page dimensions are copied with their full dependency graph, not re-rendered.",
          },
          {
            parameter: "Bookmarks",
            type: "not merged",
            defaultVal: "—",
            description:
              "A document outline is document-level structure that cannot belong to two parents. Rather than produce a broken tree, it is left out.",
          },
          {
            parameter: "Watermark",
            type: "none",
            defaultVal: "—",
            description:
              "There is no paid tier to upsell, so there is nothing to stamp on your document to encourage one.",
          },
        ],
      }}
      faqs={[
        {
          question: "Are my files really not uploaded?",
          answer:
            "No, and you can check rather than trust. Open DevTools, go to the Network panel, drop your files and merge: no request carrying them appears. Beyond that, the page is served with a Content-Security-Policy of connect-src 'self', which means the browser itself refuses any request to another origin — so even a compromised script could not exfiltrate the document.",
        },
        {
          question: "Is there a file size limit?",
          answer:
            "100 MB per file and 250 MB in total, and the limit is your browser's memory rather than a paywall. A PDF is held in memory several times during a merge — parsed graph, destination graph, serialised output — so a file larger than that would exhaust the tab and lose the work. The tool declines instead, which is the honest failure.",
        },
        {
          question: "Why is the merged file smaller than the sum of the inputs?",
          answer:
            "Because a PDF contains more than its pages. Unreferenced objects, old revisions left behind by incremental saves, and duplicate copies of the same embedded font are not carried over. A file that has been edited and re-saved a dozen times can shrink noticeably from a merge alone.",
        },
        {
          question: "Can I merge a password-protected PDF?",
          answer:
            "Not directly. If it has a user password, the content is genuinely encrypted and cannot be read without it — no tool can, and any site claiming otherwise is either uploading your file to a cracking service or lying. If you have the password, use the PDF unlocker first and merge the result.",
        },
        {
          question: "Will the merged file keep my bookmarks and form fields?",
          answer:
            "Form fields and annotations are preserved where they belong to a page. The bookmark outline is not, because it is document-level structure with a single root: two documents each have their own tree, and stitching them produces destinations that point at the wrong pages. Emitting nothing is better than emitting a broken outline that looks right until you click it.",
        },
        {
          question: "Is there a watermark or a page limit?",
          answer:
            "Neither. There is no paid tier here, so there is nothing to restrict you into buying. The only limits are the memory ones above, and those are the browser's rather than ours.",
        },
      ]}
      relatedTools={relatedTools("/merge-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".pdf", "application/pdf"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          multiple
          reorderable
          label="Drop PDF files here"
          disabled={state.status === "running"}
        />

        {files.length >= 2 && state.status !== "running" && (
          <div className="flex flex-wrap items-center gap-3">
            <button type="button" onClick={() => void merge()} className={btnPrimary}>
              Merge {files.length} files
            </button>
            <span className="font-mono text-2xs text-foreground-subtle">
              {formatBytes(totalBytes)} in, merged in this tab
            </span>
          </div>
        )}

        {files.length === 1 && (
          <Notice tone="info">
            Add at least one more file. A single PDF has nothing to merge with — for reordering or
            removing pages inside one document, use the page tools.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            defaultStem={defaultStem}
            extension="pdf"
            value={outputName}
            onChange={setOutputName}
          />
        )}

        <FileResult state={state} />
      </div>
    </ToolShell>
  );
};
