import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { MergePdfClient } from "./MergePdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/merge-pdf",
  title: "Merge PDF — Combine Files, Nothing Uploaded",
  socialTitle: "Merge PDF",
  description:
    "Combine PDF files in your browser. Nothing is uploaded — which matters when the documents are contracts, payslips or medical records.",
});

export default function MergePdfPage() {
  return <MergePdfClient />;
}
