import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Page Not Found (404)",
  description: "The requested page does not exist on ToolsByUs.",
  // No `robots` override here: Next.js already emits `noindex` for not-found,
  // and adding a second <meta name="robots"> only duplicates the directive.
};

const SUGGESTIONS = [
  { href: "/json-diff", title: "JSON Diff", desc: "Semantic comparison with RFC 6902 patch export" },
  { href: "/json-validator", title: "JSON Validator", desc: "RFC 8259 syntax checking with line and column" },
  { href: "/json-formatter", title: "JSON Formatter", desc: "Indent, sort keys, and normalise output" },
  { href: "/base64-decode", title: "Base64 & JWT", desc: "Decode payloads and inspect token claims" },
];

/**
 * Rendered inside the root layout, which already provides the header and
 * footer — this file used to render its own copies, so every 404 shipped two
 * <header> and two <footer> landmarks.
 */
export default function NotFound() {
  return (
    <div className="shell max-w-2xl py-20 text-center">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-lg bg-surface-elevated border border-border text-accent font-mono text-2xl font-bold mb-6">
        404
      </div>
      <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground font-mono mb-3">
        Page Not Found
      </h1>
      <p className="text-sm text-foreground-muted leading-relaxed max-w-lg mx-auto">
        This URL does not match any tool on ToolsByUs. Every tool below runs entirely in your
        browser, with no payload ever leaving your device.
      </p>

      <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
        {SUGGESTIONS.map((s) => (
          <Link
            key={s.href}
            href={s.href}
            className="p-4 rounded-lg border border-border bg-surface hover:bg-surface-elevated hover:border-accent-line transition-colors group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            <span className="font-semibold text-foreground group-hover:text-accent text-sm font-mono">
              {s.title}
            </span>
            <p className="text-xs text-foreground-muted mt-1">{s.desc}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8">
        <Link
          href="/"
          className="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-accent-solid hover:bg-accent-hover text-accent-on font-semibold text-xs font-mono transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          ← Back to all tools
        </Link>
      </div>
    </div>
  );
}
