"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Notice } from "../../components/common/Notice";
import { checkbox, field, fieldLabel } from "../../components/common/controls";
import {
  parseInBase,
  formatInBase,
  describeInteger,
  COMMON_BASES,
  FORMAT_DEFAULTS,
} from "../../lib/numbers/base";
import { relatedTools } from "../../lib/tools";

export const NumberBaseConverterClient: React.FC = () => {
  const [input, setInput] = useState("255");
  const [fromBase, setFromBase] = useState(10);
  const [customBase, setCustomBase] = useState(36);
  const [grouping, setGrouping] = useState(true);
  const [uppercase, setUppercase] = useState(false);
  const [prefix, setPrefix] = useState(false);

  const parsed = useMemo(() => parseInBase(input, fromBase), [input, fromBase]);
  const options = { ...FORMAT_DEFAULTS, grouping, uppercase, prefix };

  const facts = useMemo(
    () =>
      parsed.ok && parsed.value.fraction.length === 0
        ? describeInteger(parsed.value.negative ? -parsed.value.integer : parsed.value.integer)
        : null,
    [parsed]
  );

  return (
    <ToolShell
      slug="number-base-converter"
      keyword="Number Base Converter"
      directAnswer="Number Base Converter converts between binary, octal, decimal, hexadecimal and any base from 2 to 36, in your browser. Integers run through BigInt end to end rather than through a double, because parseInt silently returns 9007199254740992 for 9007199254740993 — and the values people convert are IDs, bitmasks and hashes, which is exactly the material that exceeds that limit."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "Number Base Converter", url: "/number-base-converter" },
      ]}
      seoDescription="Convert numbers between base 2 and base 36 in the browser. Arbitrary precision integers, fractional conversion, two's complement, bit width analysis and digit grouping."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Base conversion looks like a one-liner and stops being one at two points: large
              integers and fractions.
            </p>
            <h3>parseInt loses digits, silently</h3>
            <p>
              <code>parseInt(&quot;9007199254740993&quot;, 10)</code> returns{" "}
              <code>9007199254740992</code>. Nothing throws, nothing warns, and the last digit is
              simply gone — because a JavaScript number is a double and 2<sup>53</sup> is where
              consecutive integers stop being representable. The things people convert between bases
              are snowflake IDs, permission bitmasks, hashes and memory addresses, every one of which
              routinely exceeds that. So the integer path here is <code>BigInt</code> from parse to
              format and never round-trips through a double.
            </p>
            <h3>Fractions convert by repeated multiplication</h3>
            <p>
              <code>BigInt</code> has no fractional part, so the fraction is handled separately:
              multiply the fractional digits by the target base, take the carry as the next output
              digit, repeat. All the arithmetic stays on integers in the source base, so nothing
              passes through a float — which is why <code>0.1</code> in base 3 comes out as exactly{" "}
              <code>0.1</code> here rather than as <code>0.3333333333333333</code>.
            </p>
            <p>
              Some fractions do not terminate in the target base: <code>0.1</code> decimal is{" "}
              <code>0.0001100110011…</code> in binary, repeating forever, which is the same fact
              behind <code>0.1 + 0.2 !== 0.3</code>. Nothing can fix that, so the expansion is
              bounded at forty digits and stops.
            </p>
            <h3>A leading 0x that disagrees with the base is an error</h3>
            <p>
              Pasting <code>0x1f</code> with base 10 selected almost certainly means you meant base
              16. Treating <code>0</code> and <code>x</code> as digits would either fail confusingly
              or produce a wrong answer, so the mismatch is named. Digit separators — underscores and
              spaces — are accepted, because <code>1010_1010</code> is how people actually write a
              byte.
            </p>
            <h3>Two&apos;s complement is why -1 reads as ffffffff</h3>
            <p>
              A negative integer in memory is stored as its two&apos;s complement: invert the bits and
              add one. So <code>-1</code> in 32 bits is <code>ffffffff</code>, and{" "}
              <code>-2147483648</code> is <code>80000000</code>. When a debugger shows you a huge
              positive hex value where you expected a small negative one, this is what happened. The
              panel shows the encoding at the narrowest width that holds the value.
            </p>
            <h3>Set bits, for a value used as a mask</h3>
            <p>
              A permissions integer is a set of flags, and the useful question is which are on. The
              bit positions are listed, counting from zero at the least significant bit, which is the
              convention every bit-shift operation uses.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `255 (base 10)`,
        outputTitle: "Converted",
        exampleOutput: `binary       1111 1111
octal        377
hexadecimal  ff
set bits     0, 1, 2, 3, 4, 5, 6, 7`,
      }}
      referenceTable={{
        title: "Behaviour and limits",
        rows: [
          {
            parameter: "Base range",
            type: "2 to 36",
            defaultVal: "—",
            description:
              "Digits are 0–9 then a–z, case-insensitive, which gives 36 symbols. Base 36 is the densest encoding that uses only alphanumerics.",
          },
          {
            parameter: "Precision",
            type: "arbitrary",
            defaultVal: "BigInt",
            description:
              "Integers of any length convert exactly. parseInt loses digits past 2^53 with no warning, which is the single most common bug in base converters.",
          },
          {
            parameter: "Fractions",
            type: "repeated multiplication",
            defaultVal: "40 digits max",
            description:
              "Exact where the fraction terminates in the target base. Where it does not — 0.1 decimal in binary — the expansion is bounded rather than infinite.",
          },
          {
            parameter: "Separators",
            type: "_ and space",
            defaultVal: "accepted",
            description:
              "1010_1010 and 1010 1010 both parse. Rejecting them would be pedantry; that is how people write a byte.",
          },
          {
            parameter: "Prefixes",
            type: "0b 0o 0x",
            defaultVal: "checked",
            description:
              "Accepted when they agree with the selected base, and reported as an error when they do not — pasting 0x1f with base 10 selected is a mistake worth naming.",
          },
          {
            parameter: "Grouping",
            type: "boolean",
            defaultVal: "on",
            description:
              "Every 4 digits in binary, 3 in octal and decimal, 2 in hexadecimal — the groupings that match how each base is read.",
          },
          {
            parameter: "Two's complement",
            type: "8/16/32/64-bit",
            defaultVal: "narrowest fit",
            description:
              "How a negative value is actually stored, which is why -1 appears as ffffffff in a debugger.",
          },
          {
            parameter: "Bit width",
            type: "signed and unsigned",
            defaultVal: "reported",
            description:
              "Which of int8 through uint64 can hold the value. A value that fits int32 but not int16 is the kind of thing worth knowing before choosing a column type.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why do other converters give me a different answer for a long number?",
          answer:
            "Because they used parseInt or Number, which go through a double and lose precision past 2^53 — about 9.007 quadrillion. parseInt(\"9007199254740993\") returns 9007199254740992, with no error. This tool uses BigInt throughout, so every digit survives. If you are converting a snowflake ID, a hash or a large bitmask, this is the difference that matters.",
        },
        {
          question: "Why does 0.1 not convert cleanly to binary?",
          answer:
            "Because it cannot. One tenth is 0.0001100110011… in base 2, repeating forever, for the same reason one third is 0.333… in base 10: the denominator has a prime factor the base does not. This is the entire explanation for 0.1 + 0.2 !== 0.3 in every language with binary floating point. The expansion here stops at forty digits because it has to stop somewhere.",
        },
        {
          question: "Why is -1 shown as ffffffff?",
          answer:
            "That is two's complement, which is how essentially every computer stores a negative integer: invert the bits of the magnitude and add one. It has the nice property that addition works identically for signed and unsigned values, which is why it won over the alternatives. When a debugger shows a suspiciously large positive hex value where you expected a small negative number, this is what you are looking at.",
        },
        {
          question: "What is base 36 for?",
          answer:
            "Compact identifiers. Base 36 uses 0-9 and a-z, which is the largest alphabet that survives being case-folded, typed by a human and put in a URL without encoding. A timestamp in base 36 is about half the length it is in decimal. Base 62 is denser but case-sensitive, which makes it fragile anywhere that lowercases.",
        },
        {
          question: "Can I convert a floating-point number's bit pattern?",
          answer:
            "Not directly — this converts the mathematical value, not the IEEE 754 encoding. Those are different questions: 0.5 as a value is 0.1 in binary, while 0.5 as a double is 3FE0000000000000 in hex. If you want the bit pattern, convert the hex of the encoded form as an integer.",
        },
        {
          question: "Is my number uploaded?",
          answer:
            "No. It is arithmetic, running in your browser. Nothing about converting 255 to hexadecimal requires a server, and the numbers people convert are frequently internal identifiers they would rather not put in someone else's log.",
        },
      ]}
      relatedTools={relatedTools("/number-base-converter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className="flex items-center gap-2">
            <label htmlFor="base-input" className={fieldLabel}>
              Value
            </label>
            <input
              id="base-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              spellCheck={false}
              className={`${field} w-64`}
            />
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="base-from" className={fieldLabel}>
              From base
            </label>
            <input
              id="base-from"
              type="number"
              min={2}
              max={36}
              value={fromBase}
              onChange={(e) => setFromBase(Math.min(36, Math.max(2, Number(e.target.value) || 10)))}
              className={`${field} w-20`}
            />
          </div>

          {[
            { id: "base-group", label: "Group digits", checked: grouping, onChange: setGrouping },
            { id: "base-upper", label: "Uppercase", checked: uppercase, onChange: setUppercase },
            { id: "base-prefix", label: "0x prefix", checked: prefix, onChange: setPrefix },
          ].map((toggle) => (
            <label
              key={toggle.id}
              htmlFor={toggle.id}
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id={toggle.id}
                type="checkbox"
                checked={toggle.checked}
                onChange={(e) => toggle.onChange(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>{toggle.label}</span>
            </label>
          ))}
        </div>

        {!parsed.ok ? (
          <Notice tone="danger">{parsed.error}</Notice>
        ) : (
          <>
            <div className="overflow-x-auto rounded-lg border border-border bg-surface">
              <table className="w-full min-w-[30rem] border-collapse text-left font-mono text-xs">
                <caption className="sr-only">The same value in several bases</caption>
                <thead>
                  <tr className="border-b border-border">
                    <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                      Base
                    </th>
                    <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                      Value
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {COMMON_BASES.map((entry) => (
                    <tr key={entry.base} className="border-b border-border last:border-0">
                      <th
                        scope="row"
                        className="whitespace-nowrap px-3 py-2 text-left font-medium text-foreground"
                      >
                        {entry.name}
                        <span className="ml-2 text-2xs font-normal text-foreground-subtle">
                          base {entry.base}
                        </span>
                      </th>
                      <td className="break-all px-3 py-2 text-foreground">
                        {formatInBase(parsed.value, fromBase, entry.base, options)}
                      </td>
                    </tr>
                  ))}
                  <tr>
                    <th scope="row" className="whitespace-nowrap px-3 py-2 text-left">
                      <label htmlFor="base-custom" className="font-medium text-foreground">
                        Custom
                      </label>
                      <input
                        id="base-custom"
                        type="number"
                        min={2}
                        max={36}
                        value={customBase}
                        onChange={(e) =>
                          setCustomBase(Math.min(36, Math.max(2, Number(e.target.value) || 2)))
                        }
                        className={`${field} ml-2 w-16`}
                      />
                    </th>
                    <td className="break-all px-3 py-2 text-foreground">
                      {formatInBase(parsed.value, fromBase, customBase, options)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {facts && (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-lg border border-border bg-surface p-3">
                  <h3 className="mb-2 font-mono text-2xs uppercase tracking-wide text-foreground-subtle">
                    Machine representation
                  </h3>
                  <dl className="space-y-1 font-mono text-xs">
                    <div className="flex gap-3">
                      <dt className="w-28 flex-none text-foreground-subtle">bit length</dt>
                      <dd className="text-foreground">{facts.bitLength}</dd>
                    </div>
                    {facts.twosComplement && (
                      <>
                        <div className="flex gap-3">
                          <dt className="w-28 flex-none text-foreground-subtle">two&apos;s comp.</dt>
                          <dd className="break-all text-foreground">
                            {facts.twosComplement.hex} ({facts.twosComplement.width}-bit)
                          </dd>
                        </div>
                        <div className="flex gap-3">
                          <dt className="w-28 flex-none text-foreground-subtle">binary</dt>
                          <dd className="break-all text-foreground">
                            {facts.twosComplement.binary}
                          </dd>
                        </div>
                      </>
                    )}
                    {facts.setBits.length > 0 && (
                      <div className="flex gap-3">
                        <dt className="w-28 flex-none text-foreground-subtle">set bits</dt>
                        <dd className="break-all text-foreground">{facts.setBits.join(", ")}</dd>
                      </div>
                    )}
                  </dl>
                </div>

                <div className="rounded-lg border border-border bg-surface p-3">
                  <h3 className="mb-2 font-mono text-2xs uppercase tracking-wide text-foreground-subtle">
                    Fits in
                  </h3>
                  <ul className="grid grid-cols-2 gap-x-4 gap-y-0.5 font-mono text-xs">
                    {facts.fits.map((entry) => (
                      <li key={entry.type} className="flex items-center gap-2">
                        <span className={entry.ok ? "text-add" : "text-foreground-subtle"}>
                          {entry.ok ? "yes" : "no "}
                        </span>
                        <span className={entry.ok ? "text-foreground" : "text-foreground-subtle"}>
                          {entry.type}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {parsed.value.fraction.length > 0 && (
              <Notice tone="info">
                A fraction that terminates in one base often does not terminate in another —{" "}
                <code>0.1</code> decimal is <code>0.0001100110011…</code> in binary, repeating
                forever. The expansion stops at 40 digits, which is why a value may look truncated.
              </Notice>
            )}
          </>
        )}
      </div>
    </ToolShell>
  );
};
