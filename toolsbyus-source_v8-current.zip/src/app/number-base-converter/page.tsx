import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { NumberBaseConverterClient } from "./NumberBaseConverterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/number-base-converter",
  title: "Number Base Converter — Binary, Hex, Any Base",
  socialTitle: "Number Base Converter",
  description:
    "Convert between binary, octal, decimal, hex and any base from 2 to 36, with arbitrary precision — so digits past 2^53 survive intact.",
});

export default function NumberBaseConverterPage() {
  return <NumberBaseConverterClient />;
}
