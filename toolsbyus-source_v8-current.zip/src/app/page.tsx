import type { Metadata } from "next";
import Link from "next/link";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import { Icon } from "@/components/common/Icon";
import { HeroSearch } from "@/components/common/HeroSearch";
import { DeskScene } from "@/components/common/DeskScene";
import {
  FeaturedTools,
  type FeaturedGroup,
} from "@/components/common/FeaturedTools";
import { absoluteUrl, SITE_NAME, SITE_URL } from "@/lib/site";
import { ACTIVE_CATEGORIES, TOOLS, toolsInCategory } from "@/lib/tools";

export const metadata: Metadata = {
  // The layout's title template is not applied to `title.default`, so the
  // homepage keeps its full brand-first title without a duplicated suffix.
  title: { absolute: "ToolsByUs — Free Browser Tools for PDF, Images, Color and JSON" },
  description: `${TOOLS.length} tools for PDFs, images, colour and data that run entirely in your browser. Process files locally with no upload or account required.`,
  alternates: {
    // Trailing slash to match the <loc> the sitemap emits for the root.
    canonical: absoluteUrl("/"),
  },
};

function buildGroups(): FeaturedGroup[] {
  const order = ["pdf", "image", "color", "text", "json", "encode", "generate"];
  return [...ACTIVE_CATEGORIES].sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id)).map((category) => ({
    id: category.id,
    label: category.label,
    hub: category.hub,
    hubLabel: `Explore ${category.title.toLowerCase()}`,
    tools: toolsInCategory(category.id).map(({ href, name, description, icon }) => ({ href, name, description, icon })),
  }));
}

/**
 * The three things people actually ask before using a tool like this.
 *
 * Kept on the homepage rather than pushed to a FAQ page because they are
 * objections, not documentation: someone who has just been told their file is
 * not uploaded wants to know why they should believe it, and a link to another
 * page is where that question goes to die.
 */
const QUESTIONS = [
  {
    question: "Are my files really not uploaded?",
    answer:
      "The tools process your files locally. To check, open your browser's Network panel and try a sample file. You may see requests for app code, fonts and workers; your file contents should not appear in request payloads. The site has no file-processing API routes or server-side file storage. See our privacy page for network and optional third-party script details.",
  },
  {
    question: "Do I need an account, and is there a file size limit?",
    answer:
      "No account, and no watermark — there is no paid tier here, so there is nothing to restrict you into buying. The limits that exist are the ones a browser tab has: up to 100 MB per file and 250 MB in a file batch; individual tools may apply lower limits, because a 12-megapixel photo becomes 48 MB of raw pixels the moment it is decoded, and several of those at once is what actually stops a phone.",
  },
  {
    question: "Do these tools work offline?",
    answer:
      "Processing runs locally after the required code has loaded. Some tools load workers or codecs on first use, including the HEIC decoder. Try the operation once before disconnecting. Opening another tool or reloading a page offline is not guaranteed.",
  },
];

export default function HomePage() {
  const groups = buildGroups();

  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      name: SITE_NAME,
      url: absoluteUrl("/"),
      inLanguage: "en",
      description:
        "Browser-based tools for PDFs, images, colour and data. Every file is processed locally; nothing is uploaded.",
      publisher: {
        "@type": "Organization",
        "@id": `${SITE_URL}/#organization`,
        name: SITE_NAME,
        url: absoluteUrl("/"),
        logo: {
          "@type": "ImageObject",
          url: absoluteUrl("/icon-512.png"),
          width: 512,
          height: 512,
        },
      },
    },
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: "Browser Tools",
      numberOfItems: TOOLS.length,
      itemListElement: TOOLS.map((tool, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: tool.title,
        url: absoluteUrl(tool.href),
        description: tool.description,
      })),
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: QUESTIONS.map((item) => ({
        "@type": "Question",
        name: item.question,
        acceptedAnswer: { "@type": "Answer", text: item.answer },
      })),
    },
  ];

  return (
    <>
      <SchemaJsonLd schemas={jsonLdData} />

      {/* ================================================================== */}
      {/* Hero                                                                */}
      {/* ------------------------------------------------------------------ */}
      {/* Two columns that are not a 50/50 split: the words hold the left and  */}
      {/* the drawing takes slightly more of the right, because a scene needs  */}
      {/* room to be read and a headline needs a measure to break on.          */}
      {/* ================================================================== */}
      <section className="shell">
        <div className="grid items-center gap-8 pb-8 pt-2 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-14 lg:pb-12 lg:pt-4">
          {/* `min-w-0` on both children, not decoration: a grid item's default
              `min-width: auto` refuses to shrink below its content, and an SVG
              with a 480-unit viewBox reports that as its minimum — which pushed
              the whole hero 25px past a 320px screen. */}
          <div className="min-w-0 text-center lg:text-left">
            <h1 className="mx-auto max-w-[13ch] text-balance text-[2.5rem] font-bold leading-[1.04] tracking-[-0.042em] text-foreground sm:text-[3.5rem] lg:mx-0 lg:text-[4rem]">
              A few good tools. Everyday files.
              <br />A little less work.
            </h1>

            <p className="mx-auto mt-6 max-w-[38ch] text-balance text-lg leading-relaxed text-foreground-muted sm:text-xl lg:mx-0">
              Merge a PDF. Resize an image. Make sense of JSON.
              Useful tools for the task in front of you, all in your browser.
            </p>

            <div className="mt-9 flex justify-center lg:justify-start">
              <HeroSearch toolCount={TOOLS.length} />
            </div>

            {/* Under the action rather than above the headline. The guarantee
                is the reason to use the site, so it belongs where someone is
                about to act on it — and a chip above an H1 is the eyebrow-label
                shape this design set out to avoid. */}
            <p className="mt-5 text-sm text-foreground-subtle">
              Files are processed in your browser. No upload. No account required.
            </p>
          </div>

          {/* Second in the source, so a screen reader and a phone both reach
              the headline and the search field before the decoration. */}
          <DeskScene className="mx-auto w-full min-w-0 max-w-[42rem] text-foreground" />
        </div>
      </section>

      {/* ================================================================== */}
      {/* What are you working on?                                            */}
      {/* ================================================================== */}
      <section aria-labelledby="tools-heading" className="shell pb-4">
        <FeaturedTools
          groups={groups}
          total={TOOLS.length}
          headingId="tools-heading"
          heading="What are you working on?"
        />
      </section>

      {/* ================================================================== */}
      {/* The claim, stated once, in the middle of the page                   */}
      {/* ================================================================== */}
      <section className="shell">
        {/* A link, not a statement. Someone reading a privacy claim on a page
            that makes its living from that claim should be one click from the
            page that explains how to check it. */}
        <Link
          href="/privacy"
          className="mt-16 block border-y border-border py-8 text-center transition-colors hover:bg-background-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent sm:mt-20"
        >
          <span className="flex flex-wrap items-center justify-center gap-2.5 text-lg font-semibold tracking-[-0.02em] text-foreground">
            <Icon name="shield" size="lg" accent className="text-foreground" />
            Your files stay in your browser
          </span>
          <span className="mx-auto mt-2.5 block max-w-[62ch] text-[0.9375rem] leading-relaxed text-foreground-muted">
            All processing happens on your device. Nothing is uploaded, and no account is required.
          </span>
        </Link>
      </section>

      {/* ================================================================== */}
      {/* The three objections                                                */}
      {/* ================================================================== */}
      <section aria-labelledby="questions-heading" className="shell">
        <div className="mx-auto max-w-[46rem] py-16 sm:py-20">
          <h2
            id="questions-heading"
            className="text-[1.75rem] font-bold tracking-[-0.03em] text-foreground sm:text-[2rem]"
          >
            Why run these tools in the browser?
          </h2>

          <dl className="mt-8">
            {QUESTIONS.map((item) => (
              <div key={item.question} className="border-t border-border py-6">
                <dt className="text-lg font-semibold tracking-[-0.015em] text-foreground">
                  {item.question}
                </dt>
                <dd className="mt-2 max-w-[68ch] leading-relaxed text-foreground-muted">
                  {item.answer}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
    </>
  );
}
