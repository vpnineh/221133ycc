"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { Notice } from "../../components/common/Notice";
import {
  btnPrimary,
  btnSecondary,
  field,
  fieldLabel,
  segment,
  segmentTrack,
} from "../../components/common/controls";
import { downloadBlob, formatBytes, parsePageRange, type AcceptedFile } from "../../lib/files";
import { loadPdfJs, scaleForDpi, canvasToBlob } from "../../lib/pdfjs/load";
import { relatedTools } from "../../lib/tools";

interface PageImage {
  index: number;
  blob: Blob;
  url: string;
  width: number;
  height: number;
}

type Format = "jpeg" | "png" | "webp";

const EXTENSION: Record<Format, string> = { jpeg: "jpg", png: "png", webp: "webp" };

export const PdfToJpgClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [format, setFormat] = useState<Format>("jpeg");
  const [dpi, setDpi] = useState(150);
  const [quality, setQuality] = useState(0.9);
  const [range, setRange] = useState("");
  const [images, setImages] = useState<PageImage[]>([]);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  /** Revokes every preview URL. Without this a long session leaks every render. */
  const clearImages = useCallback((current: PageImage[]) => {
    for (const image of current) URL.revokeObjectURL(image.url);
  }, []);

  const convert = async () => {
    const file = files[0]?.file;
    if (!file) return;

    setError(null);
    clearImages(images);
    setImages([]);

    try {
      const pdfjs = await loadPdfJs();
      const data = new Uint8Array(await file.arrayBuffer());
      const document_ = await pdfjs.getDocument({ data }).promise;

      const selected = range.trim()
        ? parsePageRange(range, document_.numPages)
        : { pages: Array.from({ length: document_.numPages }, (_unused, index) => index) };

      if (selected.error) {
        setError(selected.error);
        return;
      }

      const scale = scaleForDpi(dpi);
      const produced: PageImage[] = [];
      setProgress({ done: 0, total: selected.pages.length });

      for (const [position, pageIndex] of selected.pages.entries()) {
        const page = await document_.getPage(pageIndex + 1);
        const viewport = page.getViewport({ scale });

        const canvas = document.createElement("canvas");
        canvas.width = Math.floor(viewport.width);
        canvas.height = Math.floor(viewport.height);
        const context = canvas.getContext("2d");
        if (!context) throw new Error("This browser did not provide a 2D canvas context.");

        // JPEG has no alpha, so an unpainted canvas renders as black rather
        // than as the white page the reader shows. Painting white first is the
        // whole fix for "my converted pages came out black".
        if (format !== "png") {
          context.fillStyle = "#ffffff";
          context.fillRect(0, 0, canvas.width, canvas.height);
        }

        await page.render({ canvasContext: context, viewport }).promise;

        const blob = await canvasToBlob(canvas, `image/${format}`, quality);
        produced.push({
          index: pageIndex,
          blob,
          url: URL.createObjectURL(blob),
          width: canvas.width,
          height: canvas.height,
        });

        // Release the canvas immediately: at 300 DPI an A4 page is about 34 MB
        // of pixel data, and holding twenty of them exhausts the tab.
        canvas.width = 0;
        canvas.height = 0;
        page.cleanup();

        setProgress({ done: position + 1, total: selected.pages.length });
      }

      await document_.destroy();
      setImages(produced);
    } catch (caught) {
      setError(describe(caught));
    } finally {
      setProgress(null);
    }
  };

  const baseName = files[0]?.file.name.replace(/\.pdf$/i, "") ?? "page";

  return (
    <ToolShell
      slug="pdf-to-jpg"
      keyword="PDF to JPG"
      directAnswer="PDF to JPG renders each page of a document to an image in your browser, at a resolution you choose. The rendering is done by pdf.js — Mozilla's own PDF engine, the same code Firefox uses to display PDFs — so pages look the way a real reader draws them rather than the way a simplified parser guesses."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "PDF to JPG", url: "/pdf-to-jpg" },
      ]}
      seoDescription="Convert PDF pages to JPG, PNG or WebP images in your browser at any DPI. Rendered by Mozilla's pdf.js, with a page range, quality control and nothing uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Converting a PDF page to an image means rendering it: running the page&apos;s content
              stream — its text drawing operators, its vector paths, its embedded images, its
              transparency groups — and painting the result onto a canvas. That is a large piece of
              software, and writing a second-rate one is how pages come out with the wrong fonts.
            </p>
            <h3>The renderer is the one in Firefox</h3>
            <p>
              pdf.js is Mozilla&apos;s PDF implementation, and it is what Firefox uses to display
              every PDF you open in it. Using it means the page you get is the page a real reader
              draws, including the parts that are easy to get wrong: embedded font subsets, Type 3
              fonts, blend modes, clipping paths and CJK text.
            </p>
            <h3>DPI is a real number, not a quality slider</h3>
            <p>
              A PDF page is measured in points — 1/72 inch — so the scale factor for a target
              resolution is exactly DPI/72. At 72 DPI an A4 page is 595 × 842 pixels; at 150 it is
              1240 × 1754, which is readable in print; at 300 it is 2480 × 3508 and four times the
              memory of 150. That last point is the practical ceiling: at 300 DPI a single A4 page
              is about 34 megabytes of pixel data before compression, and a browser canvas has a
              maximum size it will silently refuse to exceed.
            </p>
            <p>
              Each canvas is released as soon as its image is encoded, which is what lets a
              fifty-page document convert at 300 DPI without the tab being killed.
            </p>
            <h3>Why JPEG output needs a white page painted first</h3>
            <p>
              A PDF page has no background; the white you see is the reader drawing one. A fresh
              canvas is transparent, and JPEG has no alpha channel, so an unpainted canvas encodes
              as black. This is the cause of almost every &ldquo;my converted pages came out
              black&rdquo; report, and the fix is one <code>fillRect</code> before rendering — done
              here for JPEG and WebP, and deliberately not for PNG, where transparency is usually the
              reason someone picked PNG.
            </p>
            <h3>Choosing a format</h3>
            <p>
              JPEG for scanned or photographic pages, where its lossy compression is efficient and
              its artefacts are invisible. PNG for pages that are mostly text or diagrams: lossless,
              so text stays crisp, and often <em>smaller</em> than JPEG for large flat areas of
              white. WebP is usually 25–35% smaller than either at the same visual quality and is
              supported everywhere that matters now.
            </p>
            <h3>What is lost, unavoidably</h3>
            <p>
              An image of a page is not a page. Text is no longer selectable, searchable or readable
              by a screen reader; links do not work; and the file is typically several times larger.
              That is inherent to rasterising, not a limitation of this tool — so convert to images
              when you need an image, and keep the PDF when you need a document.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `report.pdf (12 pages)
format: JPEG, 150 DPI, quality 0.9`,
        outputTitle: "Output",
        exampleOutput: `report-1.jpg … report-12.jpg
1240 × 1754 each
white painted before render,
canvas released per page`,
      }}
      referenceTable={{
        title: "Options",
        rows: [
          {
            parameter: "JPEG",
            type: "format",
            defaultVal: "default",
            description:
              "Lossy, efficient on scans and photographs. No alpha, which is why the page is painted white before rendering.",
          },
          {
            parameter: "PNG",
            type: "format",
            defaultVal: "—",
            description:
              "Lossless, so text stays crisp, and often smaller than JPEG on a page that is mostly white. Transparency is preserved.",
          },
          {
            parameter: "WebP",
            type: "format",
            defaultVal: "—",
            description: "Typically 25–35% smaller than JPEG at the same visual quality.",
          },
          {
            parameter: "72 DPI",
            type: "resolution",
            defaultVal: "—",
            description: "Screen size: an A4 page is 595 × 842 pixels. For a thumbnail or a preview.",
          },
          {
            parameter: "150 DPI",
            type: "resolution",
            defaultVal: "default",
            description: "1240 × 1754 for A4. Readable when printed; the sensible default.",
          },
          {
            parameter: "300 DPI",
            type: "resolution",
            defaultVal: "—",
            description:
              "2480 × 3508 for A4, and about 34 MB of pixel data per page before compression. Print quality, and the practical ceiling in a browser.",
          },
          {
            parameter: "Quality",
            type: "0.1 – 1.0",
            defaultVal: "0.9",
            description:
              "JPEG and WebP only. Above 0.95 the file grows fast for no visible gain; below 0.7 artefacts show around text.",
          },
          {
            parameter: "Page range",
            type: "1-3, 7",
            defaultVal: "all pages",
            description: "Print-dialogue syntax. Leave empty to convert the whole document.",
          },
          {
            parameter: "Memory",
            type: "released per page",
            defaultVal: "—",
            description:
              "Each canvas is freed as soon as its image is encoded, which is what lets a long document convert at high DPI.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did my converted pages come out black?",
          answer:
            "That is what happens when a tool renders onto a transparent canvas and encodes it as JPEG, which has no alpha channel — transparent becomes black. A PDF page has no background of its own; the white you see is the reader painting one. This tool fills the canvas white before rendering for JPEG and WebP, and deliberately does not for PNG, where you probably chose PNG because you wanted the transparency.",
        },
        {
          question: "What DPI should I use?",
          answer:
            "150 for almost everything — readable when printed, and a manageable file size. 72 for a thumbnail or web preview. 300 only if the result is going to a printer that will do it justice, and be aware that at 300 DPI a single A4 page is about 34 megabytes of pixel data, so a long document at that setting is genuinely close to what a browser tab can hold.",
        },
        {
          question: "JPG or PNG?",
          answer:
            "JPG for scanned pages and anything photographic: its compression is built for continuous tone and the artefacts hide in the noise. PNG for pages that are mostly text, tables or line drawings — it is lossless so text edges stay sharp, and on a page that is largely white it is frequently smaller than the JPEG as well. WebP beats both on size if the destination accepts it.",
        },
        {
          question: "Can I get the text back out of the images?",
          answer:
            "Not without OCR, and that is not a step you want to need. Rasterising throws away the text layer completely — the result is a picture of words, not words. If you need the text, use the PDF to Text tool on the original document, which reads the text layer directly and is both exact and instant.",
        },
        {
          question: "Why is the image file bigger than the whole PDF?",
          answer:
            "Because a PDF stores instructions and an image stores pixels. A page of text is a few kilobytes of drawing commands referencing a font that is embedded once for the whole document; the same page as an image at 150 DPI is two million pixels that have to be compressed individually. A 200 KB PDF becoming 8 MB of images is entirely normal, and it is a good reason to keep the PDF.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. pdf.js runs in this tab — it is the same engine Firefox uses to display PDFs, running as JavaScript on your machine. Rendering happens on a canvas in your browser and the images are created locally. The page's Content-Security-Policy sets connect-src 'self', so an upload would be blocked by the browser.",
        },
      ]}
      relatedTools={relatedTools("/pdf-to-jpg").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".pdf", "application/pdf"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            clearImages(images);
            setImages([]);
            setError(null);
          }}
          label="Drop a PDF here"
          disabled={progress !== null}
        />

        {files.length === 1 && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Format</span>
              <div className={segmentTrack} role="group" aria-label="Format">
                {(["jpeg", "png", "webp"] as const).map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setFormat(value)}
                    aria-pressed={format === value}
                    className={segment(format === value)}
                  >
                    {value === "jpeg" ? "JPG" : value.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className={fieldLabel}>DPI</span>
              <div className={segmentTrack} role="group" aria-label="Resolution">
                {[72, 150, 300].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setDpi(value)}
                    aria-pressed={dpi === value}
                    className={segment(dpi === value)}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>

            {format !== "png" && (
              <div className="flex items-center gap-2">
                <label htmlFor="jpg-quality" className={fieldLabel}>
                  Quality
                </label>
                <input
                  id="jpg-quality"
                  type="range"
                  min={10}
                  max={100}
                  value={Math.round(quality * 100)}
                  onChange={(event) => setQuality(Number(event.target.value) / 100)}
                  className="w-28 accent-accent-solid"
                />
                <span className="w-8 font-mono text-2xs text-foreground-subtle">
                  {Math.round(quality * 100)}
                </span>
              </div>
            )}

            <div className="flex items-center gap-2">
              <label htmlFor="jpg-range" className={fieldLabel}>
                Pages
              </label>
              <input
                id="jpg-range"
                type="text"
                value={range}
                onChange={(event) => setRange(event.target.value)}
                placeholder="all"
                spellCheck={false}
                className={`${field} w-28`}
              />
            </div>

            {progress === null && (
              <button type="button" onClick={() => void convert()} className={btnPrimary}>
                Convert to images
              </button>
            )}
          </div>
        )}

        {progress && (
          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-2 flex items-baseline justify-between gap-3">
              <span className="text-xs text-foreground">
                Rendering page {progress.done + 1} of {progress.total} at {dpi} DPI
              </span>
              <span className="font-mono text-2xs text-foreground-subtle">
                {Math.round((progress.done / progress.total) * 100)}%
              </span>
            </div>
            <div
              role="progressbar"
              aria-valuenow={Math.round((progress.done / progress.total) * 100)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Rendering progress"
              className="h-1.5 overflow-hidden rounded-full bg-surface-elevated"
            >
              <div
                className="h-full bg-accent-solid"
                style={{ width: `${Math.max((progress.done / progress.total) * 100, 2)}%` }}
              />
            </div>
          </div>
        )}

        {error && <Notice tone="danger">{error}</Notice>}

        {images.length > 0 && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-3 rounded-lg border border-add/40 bg-surface px-3 py-2">
              <span className="font-mono text-2xs uppercase tracking-wide text-add">
                {images.length} image{images.length === 1 ? "" : "s"} ·{" "}
                {formatBytes(images.reduce((sum, image) => sum + image.blob.size, 0))}
              </span>
              <button
                type="button"
                onClick={() => {
                  for (const image of images) {
                    downloadBlob(image.blob, `${baseName}-${image.index + 1}.${EXTENSION[format]}`);
                  }
                }}
                className={btnSecondary}
              >
                Download all
              </button>
            </div>

            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {images.map((image) => (
                <li key={image.index} className="overflow-hidden rounded-lg border border-border bg-surface">
                  {/* A blob URL from a canvas this page rendered; next/image
                      cannot take one, and there is nothing to optimise. */}
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={image.url}
                    alt={`Page ${image.index + 1}`}
                    width={image.width}
                    height={image.height}
                    className="h-40 w-full bg-white object-contain"
                  />
                  <div className="flex items-center justify-between gap-2 border-t border-border px-2 py-1.5">
                    <span className="font-mono text-2xs text-foreground-subtle">
                      p{image.index + 1} · {formatBytes(image.blob.size)}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        downloadBlob(image.blob, `${baseName}-${image.index + 1}.${EXTENSION[format]}`)
                      }
                      className="cursor-pointer rounded px-1.5 font-mono text-2xs text-accent transition-colors hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    >
                      save
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </ToolShell>
  );
};

function describe(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  if (/password/i.test(message)) {
    return "This PDF is password-protected. Unlock it first with the password, if you have it.";
  }
  if (/Invalid PDF|structure/i.test(message)) {
    return "That file is not a readable PDF — it may be truncated, or it may be something else with a .pdf extension.";
  }
  return message;
}
