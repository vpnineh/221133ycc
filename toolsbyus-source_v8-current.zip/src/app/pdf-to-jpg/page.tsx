import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { PdfToJpgClient } from "./PdfToJpgClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/pdf-to-jpg",
  title: "PDF to JPG — Render Pages at Any DPI",
  socialTitle: "PDF to JPG",
  description:
    "Convert PDF pages to JPG or PNG images in your browser, at a DPI you choose. Rendered by Mozilla's own PDF engine, with nothing uploaded.",
});

export default function PdfToJpgPage() {
  return <PdfToJpgClient />;
}
