"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { btnPrimary, checkbox, fieldLabel } from "../../components/common/controls";
import { downloadBlob, withExtension, type AcceptedFile } from "../../lib/files";
import { loadPdfJs } from "../../lib/pdfjs/load";
import { relatedTools } from "../../lib/tools";

/** A text item as pdf.js reports it, with the fields this tool uses. */
interface TextItem {
  str: string;
  transform: number[];
  hasEOL?: boolean;
}

export const PdfToTextClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [text, setText] = useState("");
  const [pageMarkers, setPageMarkers] = useState(true);
  const [preserveLayout, setPreserveLayout] = useState(true);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [emptyPages, setEmptyPages] = useState(0);

  const extract = async () => {
    const file = files[0]?.file;
    if (!file) return;

    setError(null);
    setText("");
    setEmptyPages(0);

    try {
      const pdfjs = await loadPdfJs();
      const data = new Uint8Array(await file.arrayBuffer());
      const document_ = await pdfjs.getDocument({ data }).promise;

      const parts: string[] = [];
      let blank = 0;
      setProgress({ done: 0, total: document_.numPages });

      for (let pageNumber = 1; pageNumber <= document_.numPages; pageNumber++) {
        const page = await document_.getPage(pageNumber);
        const content = await page.getTextContent();
        const items = content.items as unknown as TextItem[];

        const pageText = preserveLayout ? withLineBreaks(items) : items.map((item) => item.str).join(" ");
        if (pageText.trim() === "") blank++;

        if (pageMarkers) parts.push(`--- page ${pageNumber} ---\n${pageText}`);
        else parts.push(pageText);

        page.cleanup();
        setProgress({ done: pageNumber, total: document_.numPages });
      }

      await document_.destroy();
      setEmptyPages(blank);
      setText(parts.join("\n\n"));
    } catch (caught) {
      setError(describe(caught));
    } finally {
      setProgress(null);
    }
  };

  const fileName = files[0]?.file.name ?? "document.pdf";

  return (
    <ToolShell
      wide
      slug="pdf-to-text"
      keyword="PDF to Text"
      directAnswer="PDF to Text extracts a document's text layer in your browser. That is a different operation from OCR: the text is read out of the file exactly as it was put in, character for character, with no recognition and no guessing. The consequence is that a scanned document — which has no text layer, only pictures of words — produces nothing, and the tool says so rather than inventing something."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "PDF to Text", url: "/pdf-to-text" },
      ]}
      seoDescription="Extract text from a PDF in your browser. Reads the real text layer with pdf.js, reconstructs line breaks from glyph positions, and reports honestly when a page is a scan with no text."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A PDF does not contain paragraphs. It contains instructions to place glyphs at
              coordinates — &ldquo;draw this character at x=72, y=708 in this font at this
              size&rdquo; — repeated a few thousand times per page. Extracting text means collecting
              those instructions and reconstructing the words and lines from where things landed.
            </p>
            <h3>This is not OCR, and the difference matters</h3>
            <p>
              OCR looks at a picture of a page and recognises shapes as letters, with an error rate.
              Text extraction reads the characters the document already stores, exactly. When the
              text layer is present the result is perfect — every character, including the ones OCR
              reliably confuses, like <code>rn</code> against <code>m</code> and <code>l</code>{" "}
              against <code>1</code>.
            </p>
            <p>
              When the text layer is absent — a scanned page is a photograph, and photographs have no
              characters — there is nothing to extract. The tool reports how many pages came back
              empty rather than returning silence and letting you conclude your file was broken. For
              those documents OCR is the right tool, and it is a genuinely different piece of
              software.
            </p>
            <h3>Reconstructing line breaks</h3>
            <p>
              The text items pdf.js returns are positioned fragments, not lines. Joining them with
              spaces produces one long paragraph per page, which is unreadable for anything with a
              layout. So the vertical coordinate of each fragment is compared with the last: a
              meaningful drop is a new line, a larger drop is a paragraph break, and a fragment at
              the same height is a continuation.
            </p>
            <p>
              This is an approximation and it is honest about being one. Multi-column layouts are
              where it shows: the extractor reads in the order the glyphs were drawn, which for a
              two-column academic paper is frequently across both columns rather than down one.
              Nothing short of full layout analysis fixes that, and layout analysis guesses.
            </p>
            <h3>Ligatures, hyphens and the missing space</h3>
            <p>
              Three artefacts turn up in extracted text often enough to recognise. A ligature — the
              single glyph for <em>fi</em> or <em>ffl</em> — may extract as one character that looks
              right and does not match a search for &ldquo;fi&rdquo;. A word hyphenated across a line
              break stays hyphenated, because the hyphen is a real character in the document. And
              two words with no space between them usually mean the PDF positioned them separately
              rather than writing a space character, which is common in text set by typesetting
              software.
            </p>
            <h3>Everything stays in the tab</h3>
            <p>
              The extraction runs in your browser. This matters more than for most tools, because the
              documents people extract text from are contracts, reports and statements — and the
              extracted text is the searchable, greppable, paste-into-anything version of exactly
              that.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `invoice.pdf (2 pages, text layer present)`,
        outputTitle: "Output",
        exampleOutput: `--- page 1 ---
INVOICE 2026-0412
Ada Lovelace Ltd
Due: 30 September 2026

--- page 2 ---
Terms and conditions…`,
      }}
      referenceTable={{
        title: "Behaviour",
        rows: [
          {
            parameter: "Text layer",
            type: "read exactly",
            defaultVal: "—",
            description:
              "Characters are taken from the document as stored. No recognition, so no error rate — unlike OCR, which guesses from pixels.",
          },
          {
            parameter: "Scanned pages",
            type: "empty",
            defaultVal: "reported",
            description:
              "A scan is a picture of words and contains no characters. The count of empty pages is shown rather than left for you to infer.",
          },
          {
            parameter: "Line breaks",
            type: "reconstructed",
            defaultVal: "on",
            description:
              "From the vertical position of each text fragment. A meaningful drop is a line, a larger one a paragraph. Turn it off for a single flowing block per page.",
          },
          {
            parameter: "Page markers",
            type: "boolean",
            defaultVal: "on",
            description: "A --- page N --- line between pages, which makes a long extraction navigable.",
          },
          {
            parameter: "Multi-column layouts",
            type: "approximate",
            defaultVal: "—",
            description:
              "Read in drawing order, which for two columns is often across rather than down. Fixing this needs layout analysis, which guesses.",
          },
          {
            parameter: "Ligatures",
            type: "as stored",
            defaultVal: "—",
            description:
              "An fi ligature may come out as a single character that looks correct and does not match a search for the two letters.",
          },
          {
            parameter: "Hyphenation",
            type: "preserved",
            defaultVal: "—",
            description:
              "A word broken across a line keeps its hyphen, because the hyphen is a real character in the document rather than a rendering artefact.",
          },
          {
            parameter: "Encrypted PDFs",
            type: "declined",
            defaultVal: "—",
            description: "Unlock with the password first.",
          },
        ],
      }}
      faqs={[
        {
          question: "I got nothing back. Is my PDF broken?",
          answer:
            "Almost certainly not — it is a scan. A scanned document is a photograph of a page, and a photograph contains no characters, only pixels arranged to look like them. There is no text layer to extract, which is why the tool reports the number of empty pages instead of returning silence. For that document you need OCR, which recognises shapes as letters and has an error rate; this reads characters that are already there and has none.",
        },
        {
          question: "Why is my two-column paper jumbled?",
          answer:
            "Because extraction reads glyphs in the order they were drawn, and for a two-column layout that is frequently left column, right column, left column — across the page rather than down each column. Reconstructing the intended reading order requires analysing the page geometry and deciding where the columns are, which is guesswork that fails on tables, sidebars and figures. This tool does not guess; it tells you what order the characters are in.",
        },
        {
          question: "Why are some words run together?",
          answer:
            "Because the PDF never wrote a space between them. Typesetting software often positions each word independently rather than emitting a space character, so the visual gap is a coordinate difference with no character behind it. An extractor that inserted spaces wherever it saw a gap would also insert them inside kerned words, which is worse. This is the most common artefact in extracted PDF text and it is inherent to the format.",
        },
        {
          question: "Is this OCR?",
          answer:
            "No, and that is the most useful thing to know about it. OCR looks at an image and recognises characters, which works on scans and has an error rate — it confuses rn with m, l with 1, and does badly on poor scans. This reads the characters the document already stores, so where there is a text layer the result is exact. The two tools solve different problems and neither substitutes for the other.",
        },
        {
          question: "Can I extract text from just some pages?",
          answer:
            "The whole document is extracted with page markers, which makes it trivial to find the part you want — search for \"--- page 7 ---\" and take what follows. A per-page range would save you a scroll and cost you the ability to search the whole thing at once, which is usually the reason people extract text in the first place.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. pdf.js runs in this tab — it is Mozilla's engine, the same code Firefox uses to display PDFs — and the text is extracted on your machine. connect-src 'self' in the page's Content-Security-Policy means the browser would block an upload attempt. That matters here because extracted text is the fully searchable, copy-pasteable version of whatever the document contained.",
        },
      ]}
      relatedTools={relatedTools("/pdf-to-text").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={[".pdf", "application/pdf"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            setText("");
            setError(null);
            setEmptyPages(0);
          }}
          label="Drop a PDF here"
          disabled={progress !== null}
        />

        {files.length === 1 && (
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            {[
              {
                id: "text-markers",
                label: "Page markers",
                checked: pageMarkers,
                onChange: setPageMarkers,
              },
              {
                id: "text-layout",
                label: "Reconstruct line breaks",
                checked: preserveLayout,
                onChange: setPreserveLayout,
              },
            ].map((toggle) => (
              <label
                key={toggle.id}
                htmlFor={toggle.id}
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id={toggle.id}
                  type="checkbox"
                  checked={toggle.checked}
                  onChange={(event) => toggle.onChange(event.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>{toggle.label}</span>
              </label>
            ))}

            {progress === null && (
              <button type="button" onClick={() => void extract()} className={btnPrimary}>
                Extract text
              </button>
            )}

            {progress && (
              <span className="font-mono text-2xs text-foreground-subtle">
                page {progress.done} of {progress.total}
              </span>
            )}
          </div>
        )}

        {error && <Notice tone="danger">{error}</Notice>}

        {emptyPages > 0 && (
          <Notice tone="warn">
            {emptyPages} page{emptyPages === 1 ? "" : "s"} produced no text. That almost always means
            those pages are scans — a photograph of a page contains no characters, only pixels. This
            tool reads a document&apos;s text layer exactly; recognising characters in an image is
            OCR, which is a different tool with an error rate.
          </Notice>
        )}

        {text && (
          <>
            <CodePane
              label="Extracted text"
              value={text}
              onChange={() => undefined}
              readOnly
              height={420}
            />
            <button
              type="button"
              onClick={() =>
                downloadBlob(
                  new Blob([text], { type: "text/plain;charset=utf-8" }),
                  withExtension(fileName, "txt")
                )
              }
              className={btnPrimary}
            >
              Download as .txt
            </button>
          </>
        )}
      </div>
    </ToolShell>
  );
};

/**
 * Rebuilds line and paragraph breaks from glyph positions.
 *
 * pdf.js returns positioned fragments, not lines. The vertical translation is
 * element 5 of the text matrix; comparing it with the previous fragment's is the
 * only signal available for where a line ended, because the document does not
 * record lines at all.
 */
function withLineBreaks(items: TextItem[]): string {
  let out = "";
  let lastY: number | null = null;

  for (const item of items) {
    const y = item.transform?.[5];
    if (typeof y === "number" && lastY !== null) {
      const drop = Math.abs(lastY - y);
      // A drop larger than a line is a paragraph; a small one is a new line;
      // none is a continuation of the same line.
      if (drop > 14) out += "\n\n";
      else if (drop > 2) out += "\n";
    }
    out += item.str;
    if (item.hasEOL) out += "\n";
    if (typeof y === "number") lastY = y;
  }

  return out.replace(/\n{3,}/g, "\n\n").trim();
}

function describe(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  if (/password/i.test(message)) {
    return "This PDF is password-protected. Unlock it first with the password, if you have it.";
  }
  if (/Invalid PDF|structure/i.test(message)) {
    return "That file is not a readable PDF — it may be truncated, or something else with a .pdf extension.";
  }
  return message;
}
