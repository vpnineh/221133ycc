import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { PdfToTextClient } from "./PdfToTextClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/pdf-to-text",
  title: "PDF to Text — Extract the Real Text Layer",
  socialTitle: "PDF to Text",
  description:
    "Extract the text from a PDF in your browser. Reads the document's real text layer rather than guessing with OCR, so the result is exact.",
});

export default function PdfToTextPage() {
  return <PdfToTextClient />;
}
