"use client";

import React, { useMemo, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { Notice } from "../../components/common/Notice";
import { btnCompact, btnSecondary, checkbox, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import {
  generateQr,
  qrToSvg,
  wifiString,
  vCardString,
  EC_DESCRIPTIONS,
  QR_DEFAULTS,
  type ErrorCorrection,
} from "../../lib/qr";
import { relatedTools } from "../../lib/tools";

type PayloadKind = "text" | "wifi" | "vcard";

export const QrCodeGeneratorClient: React.FC = () => {
  const [kind, setKind] = useState<PayloadKind>("text");
  const [text, setText] = useState("https://toolsbyus.com");
  const [errorCorrection, setErrorCorrection] = useState<ErrorCorrection>("M");
  const [scale, setScale] = useState(8);
  const [margin, setMargin] = useState(4);

  const [ssid, setSsid] = useState("");
  const [password, setPassword] = useState("");
  const [security, setSecurity] = useState<"WPA" | "WEP" | "nopass">("WPA");
  const [hidden, setHidden] = useState(false);

  const [name, setName] = useState("");
  const [organisation, setOrganisation] = useState("");
  const [title, setTitle] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [url, setUrl] = useState("");

  const containerRef = useRef<HTMLDivElement>(null);

  const payload = useMemo(() => {
    if (kind === "wifi") return ssid ? wifiString({ ssid, password, security, hidden }) : "";
    if (kind === "vcard") {
      return name ? vCardString({ name, organisation, title, phone, email, url }) : "";
    }
    return text;
  }, [kind, text, ssid, password, security, hidden, name, organisation, title, phone, email, url]);

  const options = { ...QR_DEFAULTS, errorCorrection, scale, margin };
  const result = useMemo(
    () => (payload ? generateQr(payload, options) : { error: "Nothing to encode yet." }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [payload, errorCorrection, scale, margin]
  );

  const svg = useMemo(
    () => ("error" in result ? "" : qrToSvg(result, options)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [result, scale, margin]
  );

  const downloadSvg = () => {
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.download = "qr-code.svg";
    link.click();
    URL.revokeObjectURL(href);
  };

  const downloadPng = () => {
    if ("error" in result) return;
    const total = result.size + margin * 2;
    const canvas = document.createElement("canvas");
    canvas.width = total * scale;
    canvas.height = total * scale;
    const context = canvas.getContext("2d");
    if (!context) return;

    // Drawn module by module rather than by rasterising the SVG: loading an SVG
    // into an Image is asynchronous, taints nothing but needs a round trip, and
    // a QR code is a grid of squares that canvas draws exactly.
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#000000";
    for (let r = 0; r < result.size; r++) {
      for (let c = 0; c < result.size; c++) {
        if (result.modules[r][c]) {
          context.fillRect((c + margin) * scale, (r + margin) * scale, scale, scale);
        }
      }
    }

    canvas.toBlob((blob) => {
      if (!blob) return;
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = "qr-code.png";
      link.click();
      URL.revokeObjectURL(href);
    });
  };

  return (
    <ToolShell
      slug="qr-code-generator"
      keyword="QR Code Generator"
      directAnswer="QR Code Generator encodes text, a URL, Wi-Fi credentials or a contact card into a QR code in your browser. The whole encoder — Reed–Solomon error correction included — runs in the page, so the Wi-Fi password you encode is never sent anywhere, and the code has no redirect, no tracking and no expiry."
      breadcrumbs={[
        { name: "Generators", url: "/generate-tools" },
        { name: "QR Code Generator", url: "/qr-code-generator" },
      ]}
      seoDescription="Generate QR codes in the browser: URLs, text, Wi-Fi credentials and vCards. Four error-correction levels, SVG and PNG download, no server, no tracking redirect and no expiry."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Almost every free QR generator online encodes your data on a server, and a good number
              encode a redirect through their own domain rather than your URL. That gives them a
              record of every scan, and it gives them the ability to change where the code points
              after you have printed it — or to let it expire when a subscription lapses. The QR
              codes on a restaurant table that stopped working are usually this.
            </p>
            <p>
              This encoder is ISO/IEC 18004 implemented in the page. Nothing is requested, nothing is
              sent, and the code points exactly where you said.
            </p>
            <h3>Mode selection decides how much fits</h3>
            <p>
              Numeric mode packs three digits into ten bits. Alphanumeric packs two characters into
              eleven, over a 45-character set that includes uppercase letters and a few symbols but
              not lowercase. Byte mode is eight bits per byte. A URL in uppercase therefore fits in a
              smaller symbol than the same URL in mixed case — which is why{" "}
              <code>HTTPS://EXAMPLE.COM</code> on a poster is not shouting, it is engineering.
            </p>
            <h3>Reed–Solomon is why a damaged code still scans</h3>
            <p>
              Error-correction codewords are computed over GF(256) and interleaved with the data, so
              a scratch or a coffee ring destroys a few codewords from each block rather than one
              block entirely. That matters because Reed–Solomon corrects a bounded number of errors{" "}
              <em>per block</em>: interleaving is what turns concentrated damage into distributed
              damage the maths can handle.
            </p>
            <h3>Masking is not cosmetic</h3>
            <p>
              Data that happens to produce a large blank area, or a run that looks like a finder
              pattern, is hard for a scanner to lock onto. The spec defines eight mask patterns, and
              a correct encoder applies all eight, scores each by four penalty rules, and keeps the
              lowest. That is the difference between a code that scans immediately and one that needs
              three attempts under a supermarket light.
            </p>
            <h3>Error-correction level is a trade, not a quality setting</h3>
            <p>
              Higher correction means more redundancy in the same symbol, so either the symbol grows
              or the payload shrinks. Level M is right for a screen or clean print. Level Q or H is
              worth the size for a sticker that will be handled, a label that will be outdoors, or a
              code with a logo placed over the middle — which works precisely because the correction
              treats the logo as damage.
            </p>
            <h3>The quiet zone is part of the code</h3>
            <p>
              The spec requires four modules of blank margin. Scanners genuinely need it to find the
              symbol&apos;s edge, and a QR code placed flush against a coloured background or another
              element is a common reason a printed code fails. The margin is included in the
              downloaded file rather than left to whoever places it.
            </p>
          </>
        ),
        inputTitle: "Payload",
        exampleInput: `https://toolsbyus.com`,
        outputTitle: "Symbol",
        exampleOutput: `version 2 (25x25 modules)
mode    byte
level   M — about 15% recoverable
21 bytes of payload`,
      }}
      referenceTable={{
        title: "Options and encoding",
        rows: [
          {
            parameter: "Level L",
            type: "error correction",
            defaultVal: "~7%",
            description: EC_DESCRIPTIONS.L,
          },
          {
            parameter: "Level M",
            type: "error correction",
            defaultVal: "~15%",
            description: EC_DESCRIPTIONS.M,
          },
          {
            parameter: "Level Q",
            type: "error correction",
            defaultVal: "~25%",
            description: EC_DESCRIPTIONS.Q,
          },
          {
            parameter: "Level H",
            type: "error correction",
            defaultVal: "~30%",
            description: EC_DESCRIPTIONS.H,
          },
          {
            parameter: "Numeric mode",
            type: "10 bits per 3 digits",
            defaultVal: "automatic",
            description: "Digits only. The densest mode by a wide margin — a phone number barely registers.",
          },
          {
            parameter: "Alphanumeric mode",
            type: "11 bits per 2 chars",
            defaultVal: "automatic",
            description:
              "Digits, uppercase A–Z, space and $%*+-./:. An uppercase URL fits in a smaller symbol than a mixed-case one.",
          },
          {
            parameter: "Byte mode",
            type: "8 bits per byte",
            defaultVal: "automatic",
            description:
              "Anything else, encoded as UTF-8 — which is what every modern scanner assumes even though the spec nominally says ISO-8859-1.",
          },
          {
            parameter: "Quiet zone",
            type: "modules",
            defaultVal: "4",
            description:
              "The blank margin the spec requires. Scanners need it to find the symbol's edge; a code placed flush against a background is a common print failure.",
          },
          {
            parameter: "Version",
            type: "1 to 20",
            defaultVal: "smallest that fits",
            description:
              "Size is version × 4 + 17 modules. Version 20 at level L holds 858 bytes, which is already past what a phone camera resolves comfortably.",
          },
          {
            parameter: "Output",
            type: "SVG or PNG",
            defaultVal: "—",
            description:
              "SVG for print — it is resolution-independent and one path element. PNG for anywhere that will not take vector.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will this QR code expire?",
          answer:
            "No, and it cannot. The code encodes your data directly, so there is no redirect, no short link and nothing on any server that could stop working. That is the difference from most free generators, which encode a link through their own domain — giving them scan analytics, the ability to change the destination after printing, and the ability to let it lapse. Restaurant table codes that stopped working are usually that.",
        },
        {
          question: "Which error-correction level should I pick?",
          answer:
            "M for a screen or clean print, which is the default everywhere for good reason. Q or H for a sticker, a label, anything outdoors, or anything that will be handled — the redundancy costs you symbol size and buys tolerance for damage. H specifically if you are placing a logo over the centre, which works because the correction treats the logo as damage and recovers from it.",
        },
        {
          question: "Why does an uppercase URL make a smaller code?",
          answer:
            "Because alphanumeric mode packs two characters into eleven bits and its 45-character set includes uppercase letters but not lowercase. A mixed-case URL falls back to byte mode at eight bits per character. HTTPS://EXAMPLE.COM/PATH in uppercase can be a noticeably smaller symbol than the same URL in lowercase, and hostnames are case-insensitive so it still works.",
        },
        {
          question: "Is the Wi-Fi password safe to encode here?",
          answer:
            "The encoding happens entirely in your browser, so the password is not transmitted anywhere — you can verify that in the Network panel. What the QR code itself does is put the password in a form anyone who photographs the code can read: it is a convenience for a guest network, not a security measure. Print it for guests, not for the network your servers are on.",
        },
        {
          question: "SVG or PNG?",
          answer:
            "SVG for anything printed. A QR code is a grid of squares, so it is exactly the kind of thing vector handles perfectly, and it stays crisp at any size — a rasterised code enlarged for a poster develops soft edges that scanners dislike. PNG for a context that will not accept vector, such as some email clients and social platforms.",
        },
        {
          question: "Why is there a white border I cannot remove?",
          answer:
            "That is the quiet zone, and the spec requires four modules of it. Scanners use it to find where the symbol ends and the rest of the world begins; without it, detection rates drop sharply. It is included in the downloaded file precisely so it does not get lost when someone places the code against a coloured background.",
        },
      ]}
      relatedTools={relatedTools("/qr-code-generator").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className={segmentTrack} role="group" aria-label="Payload type">
            {(
              [
                ["text", "Text or URL"],
                ["wifi", "Wi-Fi"],
                ["vcard", "Contact"],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setKind(value)}
                aria-pressed={kind === value}
                className={segment(kind === value)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className={fieldLabel}>Correction</span>
            <div className={segmentTrack} role="group" aria-label="Error correction level">
              {(["L", "M", "Q", "H"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setErrorCorrection(value)}
                  aria-pressed={errorCorrection === value}
                  title={EC_DESCRIPTIONS[value]}
                  className={segment(errorCorrection === value)}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="qr-scale" className={fieldLabel}>
              Scale
            </label>
            <input
              id="qr-scale"
              type="number"
              min={2}
              max={32}
              value={scale}
              onChange={(e) => setScale(Math.min(32, Math.max(2, Number(e.target.value) || 8)))}
              className={`${field} w-20`}
            />
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="qr-margin" className={fieldLabel}>
              Quiet zone
            </label>
            <input
              id="qr-margin"
              type="number"
              min={0}
              max={16}
              value={margin}
              onChange={(e) => setMargin(Math.min(16, Math.max(0, Number(e.target.value) || 0)))}
              className={`${field} w-20`}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_auto]">
          <div className="space-y-3">
            {kind === "text" && (
              <div>
                <label htmlFor="qr-text" className={`${fieldLabel} mb-1 block`}>
                  Text or URL
                </label>
                <textarea
                  id="qr-text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  rows={6}
                  spellCheck={false}
                  className={`${field} w-full resize-y font-mono`}
                />
              </div>
            )}

            {kind === "wifi" && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {[
                  { id: "wifi-ssid", label: "Network name (SSID)", value: ssid, onChange: setSsid },
                  { id: "wifi-password", label: "Password", value: password, onChange: setPassword },
                ].map((input) => (
                  <div key={input.id}>
                    <label htmlFor={input.id} className={`${fieldLabel} mb-1 block`}>
                      {input.label}
                    </label>
                    <input
                      id={input.id}
                      type="text"
                      value={input.value}
                      onChange={(e) => input.onChange(e.target.value)}
                      spellCheck={false}
                      className={`${field} w-full`}
                    />
                  </div>
                ))}
                <div>
                  <span className={`${fieldLabel} mb-1 block`}>Security</span>
                  <div className={segmentTrack} role="group" aria-label="Security">
                    {(["WPA", "WEP", "nopass"] as const).map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setSecurity(value)}
                        aria-pressed={security === value}
                        className={segment(security === value)}
                      >
                        {value === "nopass" ? "Open" : value}
                      </button>
                    ))}
                  </div>
                </div>
                <label
                  htmlFor="wifi-hidden"
                  className="flex cursor-pointer select-none items-end gap-2 pb-1 pointer-coarse:min-h-[44px]"
                >
                  <input
                    id="wifi-hidden"
                    type="checkbox"
                    checked={hidden}
                    onChange={(e) => setHidden(e.target.checked)}
                    className={checkbox}
                  />
                  <span className={fieldLabel}>Hidden network</span>
                </label>
              </div>
            )}

            {kind === "vcard" && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {[
                  { id: "vc-name", label: "Full name", value: name, onChange: setName },
                  { id: "vc-org", label: "Organisation", value: organisation, onChange: setOrganisation },
                  { id: "vc-title", label: "Job title", value: title, onChange: setTitle },
                  { id: "vc-phone", label: "Phone", value: phone, onChange: setPhone },
                  { id: "vc-email", label: "Email", value: email, onChange: setEmail },
                  { id: "vc-url", label: "Website", value: url, onChange: setUrl },
                ].map((input) => (
                  <div key={input.id}>
                    <label htmlFor={input.id} className={`${fieldLabel} mb-1 block`}>
                      {input.label}
                    </label>
                    <input
                      id={input.id}
                      type="text"
                      value={input.value}
                      onChange={(e) => input.onChange(e.target.value)}
                      spellCheck={false}
                      className={`${field} w-full`}
                    />
                  </div>
                ))}
              </div>
            )}

            {payload && (
              <div>
                <span className={`${fieldLabel} mb-1 block`}>Encoded payload</span>
                <pre className="max-h-32 overflow-auto whitespace-pre-wrap break-all rounded-lg border border-border bg-background px-3 py-2 font-mono text-xs text-foreground">
                  {payload}
                </pre>
              </div>
            )}
          </div>

          <div ref={containerRef} className="flex flex-col items-center gap-3">
            {"error" in result ? (
              <div className="flex h-64 w-64 items-center justify-center rounded-lg border border-border bg-surface p-6 text-center text-xs text-foreground-muted">
                {result.error}
              </div>
            ) : (
              <>
                <div
                  className="rounded-lg border border-border bg-white p-2"
                  // The SVG is generated from the matrix in this file — there is
                  // no user-supplied markup in it, only a path of module rects.
                  dangerouslySetInnerHTML={{ __html: svg }}
                />
                <dl className="w-full space-y-0.5 font-mono text-2xs text-foreground-subtle">
                  <div className="flex justify-between gap-3">
                    <dt>version</dt>
                    <dd className="text-foreground">
                      {result.version} ({result.size}×{result.size})
                    </dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt>mode</dt>
                    <dd className="text-foreground">{result.mode}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt>payload</dt>
                    <dd className="text-foreground">{result.dataBytes} bytes</dd>
                  </div>
                </dl>
                <div className="flex gap-2">
                  <button type="button" onClick={downloadSvg} className={btnSecondary}>
                    SVG
                  </button>
                  <button type="button" onClick={downloadPng} className={btnCompact}>
                    PNG
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {kind === "wifi" && payload && (
          <Notice tone="warn">
            A Wi-Fi QR code puts the password in a form anyone who photographs the code can read.
            That is a convenience for a guest network, not a security measure — the encoding happens
            in your browser and the password is not transmitted, but the printed code is readable by
            anyone who sees it.
          </Notice>
        )}
      </div>
    </ToolShell>
  );
};
