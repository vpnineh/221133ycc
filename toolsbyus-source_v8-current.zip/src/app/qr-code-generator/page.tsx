import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { QrCodeGeneratorClient } from "./QrCodeGeneratorClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/qr-code-generator",
  title: "QR Code Generator — No Tracking Redirect",
  socialTitle: "QR Code Generator",
  description:
    "Generate QR codes in your browser — no server, no tracking redirect, no expiry. Encodes URLs, Wi-Fi credentials and vCards, with SVG and PNG download.",
});

export default function QrCodeGeneratorPage() {
  return <QrCodeGeneratorClient />;
}
