"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { Notice } from "../../components/common/Notice";
import { btnCompact, checkbox, field, fieldLabel } from "../../components/common/controls";
import {
  analyseRisk,
  explainPattern,
  flagsToString,
  applyReplacement,
  FLAG_DEFAULTS,
  REGEX_EXAMPLES,
  type MatchResult,
  type RegexFlags,
} from "../../lib/regex";
import type { RegexWorkerRequest, RegexWorkerResponse } from "../../workers/regex.worker";
import { relatedTools } from "../../lib/tools";

/**
 * How long a pattern gets before the worker is killed.
 *
 * Chosen so a legitimately slow match on a large subject still completes, while
 * an exponential one is stopped long before it would matter. There is no way to
 * distinguish the two in advance — that is the whole problem — so the only
 * signal available is elapsed time.
 */
const TIMEOUT_MS = 2000;

const SAMPLE_SUBJECT = `2026-09-11 08:14:22 INFO  checkout-api  order ord_1041 paid by ada@example.com (GBP 148.50)
2026-09-11 08:14:23 WARN  inventory     sku WID-9 low: 3 remaining
2026-09-11 08:14:25 ERROR payments      gateway timeout after 30000ms, retrying
2026-09-11 08:15:01 INFO  checkout-api  order ord_1042 paid by grace@example.org (GBP 24.00)
2026-09-11 08:15:09 ERROR checkout-api  order ord_1043 declined: insufficient_funds`;

type RunState =
  | { status: "idle" }
  | { status: "running" }
  | { status: "ok"; matches: MatchResult[]; elapsedMs: number; truncated: boolean }
  | { status: "invalid"; error: string }
  | { status: "timeout" };

export const RegexTesterClient: React.FC = () => {
  const [pattern, setPattern] = useState("(\\w+)@(\\w+\\.\\w+)");
  const [subject, setSubject] = useState(SAMPLE_SUBJECT);
  const [flags, setFlags] = useState<RegexFlags>({ ...FLAG_DEFAULTS, multiline: true });
  const [replacement, setReplacement] = useState("");
  const [state, setState] = useState<RunState>({ status: "idle" });

  const workerRef = useRef<Worker | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const runIdRef = useRef(0);

  const terminate = useCallback(() => {
    workerRef.current?.terminate();
    workerRef.current = null;
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const run = useCallback(() => {
    terminate();
    if (typeof window === "undefined") return;

    const runId = ++runIdRef.current;
    setState({ status: "running" });

    let worker: Worker;
    try {
      worker = new Worker(new URL("../../workers/regex.worker.ts", import.meta.url), {
        type: "module",
      });
    } catch {
      // No worker available. Running on the main thread would risk locking the
      // tab on a pattern the worker exists to contain, so the tool declines.
      setState({
        status: "invalid",
        error:
          "Web Workers are unavailable in this browser, and matching on the main thread could lock the tab on a pattern that backtracks. Nothing was run.",
      });
      return;
    }
    workerRef.current = worker;

    worker.onmessage = (event: MessageEvent<RegexWorkerResponse>) => {
      if (runId !== runIdRef.current) return;
      terminate();
      const data = event.data;
      if (data.type === "INVALID") setState({ status: "invalid", error: data.error });
      else
        setState({
          status: "ok",
          matches: data.matches,
          elapsedMs: data.elapsedMs,
          truncated: data.truncated,
        });
    };

    worker.onerror = () => {
      if (runId !== runIdRef.current) return;
      terminate();
      setState({ status: "invalid", error: "The matcher failed to start." });
    };

    // Termination is the mechanism. A regex cannot be interrupted once it is
    // running, so the only way to stop one is to destroy the thread it is on.
    timerRef.current = setTimeout(() => {
      if (runId !== runIdRef.current) return;
      terminate();
      setState({ status: "timeout" });
    }, TIMEOUT_MS);

    worker.postMessage({
      type: "RUN",
      pattern,
      flags: flagsToString(flags),
      subject,
    } satisfies RegexWorkerRequest);
  }, [pattern, flags, subject, terminate]);

  // Debounced so typing a pattern does not spawn a worker per keystroke.
  useEffect(() => {
    const handle = setTimeout(run, 250);
    return () => clearTimeout(handle);
  }, [run]);

  useEffect(() => terminate, [terminate]);

  const risks = useMemo(() => analyseRisk(pattern), [pattern]);
  const parts = useMemo(() => explainPattern(pattern), [pattern]);
  const replaced = useMemo(
    () => (replacement ? applyReplacement(pattern, flags, subject, replacement) : null),
    [pattern, flags, subject, replacement]
  );

  const toggleFlag = (key: keyof RegexFlags) =>
    setFlags((previous) => ({ ...previous, [key]: !previous[key] }));

  return (
    <ToolShell
      wide
      slug="regex-tester"
      keyword="Regex Tester"
      directAnswer="Regex Tester matches a pattern against a subject in your browser, inside a Web Worker with a two-second timeout. That is not caution for its own sake: JavaScript offers no way to interrupt a running regular expression, so a pattern like (a+)+$ against a long input holds its thread indefinitely, and killing the worker is the only defence that actually works."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "Regex Tester", url: "/regex-tester" },
      ]}
      seoDescription="Test regular expressions in the browser with a worker timeout against catastrophic backtracking, a plain-language breakdown of the pattern, named capture groups and replacement preview."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Most regex testers run the pattern on the page&apos;s main thread. That works until
              someone pastes a pattern that backtracks, at which point the tab stops responding and
              the only remedy is to close it.
            </p>
            <h3>Catastrophic backtracking, and why it cannot be caught</h3>
            <p>
              JavaScript&apos;s regex engine backtracks: when a match fails it retries every
              alternative path. For <code>(a+)+b</code> against a run of <code>a</code> characters
              ending in anything else, the paths are every way of dividing the run between the two
              quantifiers — which is exponential. Thirty characters is about a billion attempts.
              There is no timeout option, no abort signal, no yield point and no exception; the
              engine simply does not return.
            </p>
            <p>
              This is the ReDoS vulnerability class, and it takes down real systems. Cloudflare&apos;s
              2019 global outage was one regex in one WAF rule; Stack Overflow&apos;s 2016 outage was
              a pattern matching whitespace on a post with a long run of it. Both were on a server,
              where the consequence is every request blocking rather than one tab.
            </p>
            <h3>A worker can be killed, which is the entire design</h3>
            <p>
              So the match runs in a Web Worker and a timer terminates it after two seconds. That is
              the only mechanism available: nothing can stop a regex mid-execution, but a thread can
              be destroyed. When the timeout fires you get a clear message naming the likely cause
              instead of a frozen tab — which is also a useful signal, because a pattern that times
              out here is a pattern that would hang a server.
            </p>
            <h3>Static analysis names shapes, not verdicts</h3>
            <p>
              The risk panel looks for nested quantifiers, quantified alternations with overlapping
              branches, and adjacent quantifiers over the same characters. Those account for nearly
              every real incident. What it deliberately does not do is declare a pattern safe:
              deciding whether an arbitrary regex has exponential worst-case behaviour is a genuine
              analysis problem, and a tool that promised safety would be making a promise it cannot
              keep.
            </p>
            <h3>Zero-length matches need a nudge</h3>
            <p>
              A global match loop over a pattern that can match nothing — <code>a*</code>,{" "}
              <code>(?:)</code>, <code>\b</code> — never advances <code>lastIndex</code> and loops
              forever. Every correct implementation increments it manually after an empty match, and
              this one does; it is a small thing that breaks a surprising number of tools.
            </p>
            <h3>The breakdown is per token</h3>
            <p>
              The pattern is split into its tokens with a plain-language note for each, because the
              usual problem with a regex someone else wrote is not that it is wrong but that it is
              unreadable. Runs of literal characters are grouped rather than listed one by one.
            </p>
          </>
        ),
        inputTitle: "Pattern",
        exampleInput: `(\\w+)@(\\w+\\.\\w+)`,
        outputTitle: "Matches",
        exampleOutput: `1  ada@example.com     at 58
   $1 ada  $2 example.com
2  grace@example.org   at 271
   $1 grace  $2 example.org`,
      }}
      referenceTable={{
        title: "Flags and behaviour",
        rows: [
          {
            parameter: "g — global",
            type: "flag",
            defaultVal: "on",
            description:
              "Find every match rather than the first. Without it, only one result is returned however many exist.",
          },
          {
            parameter: "i — ignore case",
            type: "flag",
            defaultVal: "off",
            description:
              "Case-insensitive. With the u flag it also applies Unicode case folding, which handles more than ASCII.",
          },
          {
            parameter: "m — multiline",
            type: "flag",
            defaultVal: "on",
            description:
              "^ and $ match at every line break rather than only at the ends of the subject. Almost always what you want for log-shaped input.",
          },
          {
            parameter: "s — dotAll",
            type: "flag",
            defaultVal: "off",
            description:
              "Makes . match a newline too. Without it, .* stops at the end of a line, which is the usual reason a multi-line match fails.",
          },
          {
            parameter: "u — unicode",
            type: "flag",
            defaultVal: "off",
            description:
              "Enables \\u{…} escapes and \\p{…} property classes, and makes the engine work in code points rather than UTF-16 units — which is what makes . match a whole emoji.",
          },
          {
            parameter: "y — sticky",
            type: "flag",
            defaultVal: "off",
            description:
              "Match only at lastIndex, with no scanning forward. Used for tokenisers, where a gap means a syntax error rather than something to skip.",
          },
          {
            parameter: "Timeout",
            type: "milliseconds",
            defaultVal: "2000",
            description:
              "The worker is terminated after this. There is no way to distinguish a slow pattern from an exponential one in advance, so elapsed time is the only signal available.",
          },
          {
            parameter: "Match limit",
            type: "count",
            defaultVal: "5000",
            description:
              "Results are truncated past this, and the truncation is reported. Rendering fifty thousand rows helps nobody.",
          },
          {
            parameter: "Replacement",
            type: "$1, $<name>, $&",
            defaultVal: "—",
            description:
              "Numbered groups, named groups and the whole match. $$ is a literal dollar sign, which is the one everybody forgets.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did my pattern time out?",
          answer:
            "It is almost certainly backtracking catastrophically. Look for a quantifier inside a quantified group — (a+)+, (\\d*)* — or a quantified alternation whose branches can match the same text, like (a|ab)+. The engine tries every way of dividing the input between them, which is exponential in the input length. The risk panel names the shape if it can find one.",
        },
        {
          question: "How do I fix a pattern that backtracks?",
          answer:
            "Remove the ambiguity about which part matches what. Replace (a+)+ with a+. Make alternation branches mutually exclusive so only one can match at each position. Anchor the pattern, so a failure does not retry from every character. Bound open-ended repetitions to what the data actually contains. And prefer a specific character class over a wildcard: [^\"]* backtracks far less than .*.",
        },
        {
          question: "Is ReDoS a real risk or a theoretical one?",
          answer:
            "Real, and expensive. Cloudflare's global outage in July 2019 was a single regular expression in a WAF rule; Stack Overflow went down in 2016 on a pattern matching trailing whitespace when a post contained a long run of it. On a server the failure mode is worse than here — every request queues behind the one stuck in the engine, so one crafted input takes down the service.",
        },
        {
          question: "Why is my .* not crossing lines?",
          answer:
            "Because . does not match a newline unless the s flag is set. This is the single most common regex surprise in JavaScript, and it is easy to mistake for the m flag — but m changes what ^ and $ mean, not what . matches. For a multi-line match you want s; for line-anchored matching you want m; they are independent and often both.",
        },
        {
          question: "Should I validate an email address with a regex?",
          answer:
            "Only loosely. The RFC 5322 grammar for an address runs to several hundred characters as a pattern, accepts things nobody expects — quoted local parts, comments, IP-literal domains — and still cannot tell you whether the mailbox exists. The useful pattern checks for an @ with something either side and a dot in the domain; the actual validation is sending a confirmation email.",
        },
        {
          question: "Is my pattern or subject uploaded?",
          answer:
            "No. The match runs in a Web Worker inside your browser — a separate thread in the same tab, not a server. You can confirm it in the Network panel. It matters because the subject text people test against is usually a production log, and production logs contain email addresses, tokens and customer identifiers.",
        },
      ]}
      relatedTools={relatedTools("/regex-tester").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          {/* `min-w-0` on both the row and the input, because a flex child's
              default `min-width: auto` refuses to shrink below its content and
              a 10rem floor on the input pushed this row 14px past a 320px
              screen — the width of a Galaxy Fold, folded. */}
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <label htmlFor="regex-pattern" className={fieldLabel}>
              Pattern
            </label>
            <span className="font-mono text-sm text-foreground-subtle">/</span>
            <input
              id="regex-pattern"
              type="text"
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              spellCheck={false}
              className={`${field} min-w-0 flex-1`}
            />
            <span className="font-mono text-sm text-foreground-subtle">
              /{flagsToString(flags)}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
            {(
              [
                ["global", "g"],
                ["ignoreCase", "i"],
                ["multiline", "m"],
                ["dotAll", "s"],
                ["unicode", "u"],
                ["sticky", "y"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                htmlFor={`flag-${key}`}
                className="flex cursor-pointer select-none items-center gap-1.5 pointer-coarse:min-h-[44px]"
              >
                <input
                  id={`flag-${key}`}
                  type="checkbox"
                  checked={flags[key]}
                  onChange={() => toggleFlag(key)}
                  className={checkbox}
                />
                <span className="font-mono text-sm text-foreground">{label}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {REGEX_EXAMPLES.map((example) => (
            <button
              key={example.label}
              type="button"
              onClick={() => setPattern(example.pattern)}
              title={example.note}
              className={btnCompact}
            >
              {example.label}
            </button>
          ))}
        </div>

        {risks.length > 0 && (
          <div className="space-y-2">
            {risks.map((risk) => (
              <Notice
                key={risk.title}
                tone={risk.severity === "high" ? "danger" : risk.severity === "medium" ? "warn" : "info"}
              >
                <strong>{risk.title}.</strong> {risk.detail}
              </Notice>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label="Subject"
            value={subject}
            onChange={setSubject}
            placeholder="Paste the text to match against…"
            height={280}
          />

          <div className="flex h-[280px] flex-col overflow-hidden rounded-lg border border-border bg-surface">
            <div className="flex items-center justify-between border-b border-border px-3 py-1.5">
              <span className="font-mono text-2xs uppercase tracking-wide text-foreground-subtle">
                Matches
              </span>
              <span className="font-mono text-2xs text-foreground-subtle">
                {state.status === "ok"
                  ? `${state.matches.length}${state.truncated ? "+" : ""} in ${state.elapsedMs} ms`
                  : state.status === "running"
                    ? "running…"
                    : state.status === "timeout"
                      ? "timed out"
                      : ""}
              </span>
            </div>

            <div className="flex-1 overflow-auto px-3 py-2 font-mono text-xs">
              {state.status === "invalid" && <p className="text-del">{state.error}</p>}
              {state.status === "timeout" && (
                <p className="text-del">
                  Terminated after {TIMEOUT_MS} ms. This pattern almost certainly backtracks
                  catastrophically — the engine is exploring exponentially many paths and would not
                  have finished. On a server, this is a denial of service.
                </p>
              )}
              {state.status === "ok" && state.matches.length === 0 && (
                <p className="text-foreground-muted">No matches.</p>
              )}
              {state.status === "ok" &&
                state.matches.slice(0, 500).map((match, index) => (
                  <div key={`${match.index}-${index}`} className="mb-1.5 border-b border-border pb-1.5 last:border-0">
                    <div className="flex gap-3">
                      <span className="w-8 flex-none text-foreground-subtle">{index + 1}</span>
                      <span className="flex-1 break-all text-add">{match.match || "(empty)"}</span>
                      <span className="flex-none text-foreground-subtle">at {match.index}</span>
                    </div>
                    {match.groups.map((group, groupIndex) => (
                      <div key={groupIndex} className="flex gap-3 pl-8">
                        <span className="w-8 flex-none text-type">${groupIndex + 1}</span>
                        <span className="flex-1 break-all text-foreground">
                          {group === undefined ? "(did not participate)" : group || "(empty)"}
                        </span>
                      </div>
                    ))}
                    {Object.entries(match.named).map(([name, value]) => (
                      <div key={name} className="flex gap-3 pl-8">
                        <span className="flex-none text-type">${`<${name}>`}</span>
                        <span className="flex-1 break-all text-foreground">{value ?? "—"}</span>
                      </div>
                    ))}
                  </div>
                ))}
            </div>
          </div>
        </div>

        {state.status === "ok" && state.truncated && (
          <Notice tone="warn">
            Stopped at 5,000 matches. Rendering more would not tell you anything the first five
            thousand did not.
          </Notice>
        )}

        <div className="space-y-2 rounded-lg border border-border bg-surface p-3">
          <div className="flex items-center gap-2">
            <label htmlFor="regex-replace" className={fieldLabel}>
              Replace with
            </label>
            <input
              id="regex-replace"
              type="text"
              value={replacement}
              onChange={(e) => setReplacement(e.target.value)}
              placeholder="$1 or $<name> — leave empty to skip"
              spellCheck={false}
              className={`${field} flex-1`}
            />
          </div>
          {replaced && (
            <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-all rounded border border-border bg-background px-3 py-2 font-mono text-xs text-foreground">
              {"output" in replaced ? replaced.output : replaced.error}
            </pre>
          )}
        </div>

        {parts.length > 0 && (
          <div className="overflow-x-auto rounded-lg border border-border bg-surface">
            <table className="w-full min-w-[28rem] border-collapse text-left font-mono text-xs">
              <caption className="sr-only">What the pattern means, token by token</caption>
              <thead>
                <tr className="border-b border-border">
                  <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                    Token
                  </th>
                  <th scope="col" className="px-3 py-2 font-medium text-foreground-subtle">
                    Matches
                  </th>
                </tr>
              </thead>
              <tbody>
                {parts.map((part, index) => (
                  <tr key={`${part.token}-${index}`} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap px-3 py-1.5 text-move">{part.token}</td>
                    <td className="px-3 py-1.5 text-foreground-subtle">{part.meaning}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </ToolShell>
  );
};
