import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { RegexTesterClient } from "./RegexTesterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/regex-tester",
  title: "Regex Tester — Matches, Groups and ReDoS Risk",
  socialTitle: "Regex Tester",
  description:
    "Test regular expressions in your browser, in a Web Worker with a timeout — the only real defence against catastrophic backtracking in JavaScript.",
});

export default function RegexTesterPage() {
  return <RegexTesterClient />;
}
