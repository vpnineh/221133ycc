"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SinglePdfTool } from "../../components/tools/SinglePdfTool";
import { Notice } from "../../components/common/Notice";
import { btnCompact, field, fieldLabel } from "../../components/common/controls";
import { parsePageRange, formatPageRange } from "../../lib/files";
import { withStem } from "../../lib/files/naming";
import { relatedTools } from "../../lib/tools";

/**
 * Interleaves two halves of a double-sided scan.
 *
 * A single-sided sheet feeder produces all the fronts and then, after the stack
 * is turned over, all the backs in reverse. The result is pages 1,3,5…6,4,2,
 * which is why so many scanned documents read correctly for half their length
 * and then run backwards.
 */
function interleaveReversed(pageCount: number): number[] {
  const half = Math.ceil(pageCount / 2);
  const fronts = Array.from({ length: half }, (_unused, index) => index);
  const backs = Array.from({ length: pageCount - half }, (_unused, index) => pageCount - 1 - index);
  const order: number[] = [];
  for (let index = 0; index < half; index++) {
    order.push(fronts[index]);
    if (backs[index] !== undefined) order.push(backs[index]);
  }
  return order;
}

export const ReorderPdfPagesClient: React.FC = () => {
  const [order, setOrder] = useState("");

  return (
    <ToolShell
      slug="reorder-pdf-pages"
      keyword="Reorder PDF Pages"
      directAnswer="Reorder PDF Pages rearranges a document in your browser by writing the order you want: 3, 1, 2 produces a file in that order. It also fixes the two orderings a sheet-fed scanner produces — a reversed stack, and the interleaved front-then-back-in-reverse result of scanning a double-sided document in two passes."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Reorder PDF Pages", url: "/reorder-pdf-pages" },
      ]}
      seoDescription="Rearrange PDF pages in your browser. Type the order you want, reverse the document, or interleave the two halves of a double-sided scan. No upload, no watermark."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Most reordering needs come from a scanner rather than from an editorial decision, and
              two scanner behaviours account for nearly all of them.
            </p>
            <h3>The reversed stack</h3>
            <p>
              A feeder that takes the stack face-up and outputs face-down gives you the document
              backwards. The fix is a straight reversal, which is one button rather than typing out
              forty page numbers.
            </p>
            <h3>The double-sided two-pass scan</h3>
            <p>
              A single-sided feeder cannot scan both sides, so the usual procedure is: scan the
              whole stack, turn it over, scan it again. That produces all the odd pages in order
              followed by all the even pages <em>in reverse</em> — pages 1, 3, 5, 7 then 8, 6, 4, 2.
              A document like this reads correctly for its first half and then runs backwards, which
              is a very recognisable kind of broken.
            </p>
            <p>
              Interleaving is the fix and it is fiddly by hand: you need the first page, then the
              last, then the second, then the second-to-last. The button does it, including the
              odd-page-count case where the final sheet has no back.
            </p>
            <h3>Typing an order</h3>
            <p>
              For everything else, write the page numbers in the order you want them:{" "}
              <code>3, 1, 2</code>, or <code>1, 5-8, 2-4</code>. Ranges work. Duplicates are allowed
              — repeating a page is occasionally deliberate, for a cover sheet or a form that needs
              two copies of one page. Omitting a page removes it, which makes this the general case
              of the delete tool.
            </p>
            <h3>Pages are copied, not shuffled in place</h3>
            <p>
              The reordered document is built by copying each page, in the order you gave, into a new
              document with its full dependency graph. That is what keeps the output a clean file
              rather than the original with a rewritten page tree — and it is why omitting a page
              genuinely removes its content rather than leaving it unreferenced in the file.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `scan.pdf (8 pages)
scanned as 1,3,5,7 then 8,6,4,2`,
        outputTitle: "Output",
        exampleOutput: `reordered.pdf
interleave → 1,2,3,4,5,6,7,8
each page copied with its resources`,
      }}
      referenceTable={{
        title: "Options and syntax",
        rows: [
          {
            parameter: "3, 1, 2",
            type: "explicit order",
            defaultVal: "—",
            description: "Pages appear in the order written. One-based, as printed on the page selector.",
          },
          {
            parameter: "1, 5-8, 2-4",
            type: "ranges",
            defaultVal: "—",
            description: "Ranges expand in ascending order. Mix them freely with single pages.",
          },
          {
            parameter: "Reverse",
            type: "preset",
            defaultVal: "—",
            description: "The whole document backwards. For a feeder that outputs face-down.",
          },
          {
            parameter: "Interleave",
            type: "preset",
            defaultVal: "—",
            description:
              "For a double-sided document scanned in two passes: fronts in order, then backs in reverse. Handles an odd page count, where the last sheet has no back.",
          },
          {
            parameter: "Duplicates",
            type: "allowed",
            defaultVal: "—",
            description: "Repeating a page number repeats the page. Occasionally exactly what you want.",
          },
          {
            parameter: "Omissions",
            type: "removed",
            defaultVal: "—",
            description:
              "A page you do not list is not in the output, and its content is not in the file either — the survivors are copied into a new document.",
          },
          {
            parameter: "Content",
            type: "preserved",
            defaultVal: "—",
            description:
              "Each page is copied with its fonts, images and vector content. Nothing is re-rendered, so quality and searchability are unchanged.",
          },
        ],
      }}
      faqs={[
        {
          question: "My scan reads correctly and then runs backwards. What happened?",
          answer:
            "You scanned a double-sided document on a single-sided feeder: all the fronts in one pass, then the stack turned over for all the backs — which come out in reverse. So you have 1, 3, 5, 7 followed by 8, 6, 4, 2. The interleave button fixes exactly this, including the case where the page count is odd and the last sheet has no reverse side.",
        },
        {
          question: "Can I repeat a page?",
          answer:
            "Yes. Writing 1, 1, 2 gives you two copies of page one. This is occasionally deliberate — a cover sheet that needs duplicating, a form where the same page is submitted twice — and there is no reason to forbid it.",
        },
        {
          question: "What happens to a page I do not list?",
          answer:
            "It is not in the output, and its content is not in the file. The reorder is done by copying the pages you listed into a new document, so anything you left out was simply never copied — which makes this a superset of the delete tool rather than a different operation.",
        },
        {
          question: "Does reordering change quality or file size?",
          answer:
            "Quality, no — each page is copied with its content stream and resources intact, not re-rendered. Size can change slightly: the new document is written fresh, so unreferenced objects and old incremental-save revisions from the original are not carried across. A file that has been edited many times can come out noticeably smaller.",
        },
        {
          question: "Will the page numbers printed on the pages update?",
          answer:
            "No. A page number printed on a page is part of that page's content, not metadata, so moving the page moves the number with it. Renumbering is a layout operation that requires knowing where on each page the number sits and what typeface it is in — which is a word processor's job, not a PDF tool's.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. Pages are reordered in this tab and the result is saved locally. connect-src 'self' in the page's Content-Security-Policy means the browser would block an upload attempt regardless.",
        },
      ]}
      relatedTools={relatedTools("/reorder-pdf-pages").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <SinglePdfTool
        runLabel={() => "Reorder pages"}
        controls={(info) => {
          const effective = order.trim() || `1-${info.pageCount}`;
          const parsed = parsePageRange(effective, info.pageCount);

          return (
            <div className="space-y-3">
              <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
                <div className="flex flex-1 items-center gap-2">
                  <label htmlFor="reorder-order" className={fieldLabel}>
                    New order
                  </label>
                  <input
                    id="reorder-order"
                    type="text"
                    value={order}
                    onChange={(event) => setOrder(event.target.value)}
                    placeholder={`1-${info.pageCount}`}
                    spellCheck={false}
                    className={`${field} min-w-[10rem] flex-1`}
                  />
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setOrder(
                      Array.from({ length: info.pageCount }, (_unused, index) => info.pageCount - index).join(", ")
                    )
                  }
                  className={btnCompact}
                >
                  Reverse
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setOrder(interleaveReversed(info.pageCount).map((index) => index + 1).join(", "))
                  }
                  className={btnCompact}
                >
                  Interleave scan
                </button>
                <button type="button" onClick={() => setOrder("")} className={btnCompact}>
                  Reset
                </button>
              </div>

              {parsed.error ? (
                <Notice tone="warn">{parsed.error}</Notice>
              ) : (
                parsed.pages.length !== info.pageCount && (
                  <Notice tone="info">
                    {parsed.pages.length} of {info.pageCount} pages will be in the output. Pages not
                    listed — {formatPageRange(
                      Array.from({ length: info.pageCount }, (_unused, index) => index).filter(
                        (index) => !parsed.pages.includes(index)
                      )
                    )}{" "}
                    — are omitted, and their content will not be in the file.
                  </Notice>
                )
              )}
            </div>
          );
        }}
        naming={{ mode: "single", defaultStem: (stem) => `${stem}-reordered` }}
        operation={async (info, file, stem) => {
          const parsed = parsePageRange(order.trim() || `1-${info.pageCount}`, info.pageCount);
          if (parsed.error) return { blocked: parsed.error };
          return {
            type: "reorder",
            file: await file.arrayBuffer(),
            order: parsed.pages,
            name: withStem(stem, "pdf"),
          };
        }}
      />
    </ToolShell>
  );
};
