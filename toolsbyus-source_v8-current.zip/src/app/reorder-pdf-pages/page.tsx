import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ReorderPdfPagesClient } from "./ReorderPdfPagesClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/reorder-pdf-pages",
  title: "Reorder PDF Pages — Drag or Type an Order",
  socialTitle: "Reorder PDF Pages",
  description:
    "Rearrange the pages of a PDF in your browser by typing the order you want. Handles reversing and interleaving a double-sided scan. Nothing is uploaded.",
});

export default function ReorderPdfPagesPage() {
  return <ReorderPdfPagesClient />;
}
