"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { ImageResults } from "../../components/tools/ImageResults";
import { useImageBatch } from "../../components/tools/useImageBatch";
import { Notice } from "../../components/common/Notice";
import {
  btnPrimary,
  checkbox,
  field,
  fieldLabel,
  segment,
  segmentTrack,
} from "../../components/common/controls";
import { type AcceptedFile } from "../../lib/files";
import {
  fitWithin,
  formatOfFile,
  FORMAT_EXTENSION,
  renderAndEncode,
  SIZE_PRESETS,
  type ImageFormat,
} from "../../lib/images";
import { applyPattern, stemOf } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

type Mode = "fit" | "exact" | "percent";

export const ResizeImageClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [mode, setMode] = useState<Mode>("fit");
  const [width, setWidth] = useState("1600");
  const [height, setHeight] = useState("1600");
  const [percent, setPercent] = useState(50);
  const [allowUpscale, setAllowUpscale] = useState(false);
  const [output, setOutput] = useState<"keep" | ImageFormat>("keep");
  const [quality, setQuality] = useState(0.85);
  const [namePattern, setNamePattern] = useState("");
  const { state, run, reset } = useImageBatch();

  const resize = () => {
    const targetWidth = Number(width) > 0 ? Number(width) : null;
    const targetHeight = Number(height) > 0 ? Number(height) : null;

    void run(files, async (decoded, file, position) => {
      const source = { width: decoded.width, height: decoded.height };
      let size: { width: number; height: number };

      if (mode === "percent") {
        const scale = percent / 100;
        size = {
          width: Math.max(1, Math.round(source.width * scale)),
          height: Math.max(1, Math.round(source.height * scale)),
        };
      } else if (mode === "exact") {
        size = {
          width: targetWidth ?? source.width,
          height: targetHeight ?? source.height,
        };
      } else {
        size = fitWithin(source, {
          width: targetWidth ?? undefined,
          height: targetHeight ?? undefined,
        });
        // fitWithin never enlarges. When the user has explicitly asked for it,
        // compute the scale again without the cap.
        if (allowUpscale && targetWidth && targetHeight) {
          const scale = Math.min(targetWidth / source.width, targetHeight / source.height);
          size = {
            width: Math.max(1, Math.round(source.width * scale)),
            height: Math.max(1, Math.round(source.height * scale)),
          };
        }
      }

      const format: ImageFormat = output === "keep" ? formatOfFile(file) : output;
      const blob = await renderAndEncode(decoded.bitmap, size, {
        format,
        quality,
        background: "#ffffff",
      });

      return {
        blob,
        name: applyPattern(
          namePattern.trim() || "{name}-{width}x{height}",
          { name: stemOf(file.name), n: position, width: size.width, height: size.height },
          FORMAT_EXTENSION[format]
        ),
        width: size.width,
        height: size.height,
      };
    });
  };

  const busy = state.status === "running";

  return (
    <ToolShell
      slug="resize-image"
      keyword="Resize Image"
      directAnswer="Resize Image scales images in your browser to a pixel size, a percentage or a preset. Reductions are done in halving steps rather than in one jump, which is what keeps fine detail — hair, foliage, small text — from turning into aliasing, and the result is encoded locally without the file being uploaded."
      breadcrumbs={[
        { name: "Image Tools", url: "/image-tools" },
        { name: "Resize Image", url: "/resize-image" },
      ]}
      seoDescription="Resize images in the browser by pixels, percentage or preset, with correct stepped downscaling, aspect-ratio locking and batch processing. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Resizing sounds like the simplest operation in imaging and is the one most often done
              badly. Every destination pixel has to be computed from some set of source pixels, and
              the rule for choosing that set is the whole difference between a sharp result and a
              mushy or speckled one.
            </p>

            <h3>Why a single scaling step is the wrong way down</h3>
            <p>
              When a browser draws a 4000-pixel-wide image into a 400-pixel-wide box, it samples a
              small neighbourhood around each destination pixel — typically bilinear, a handful of
              source pixels. But each destination pixel here covers <em>a hundred</em> source
              pixels, and ninety-odd of them are never looked at. The detail in them does not blur
              away; it aliases, turning fine texture into moiré patterns and thin lines into
              flickering dashes.
            </p>
            <p>
              The fix is to step down by halves. Halving samples every source pixel exactly once, so
              nothing is skipped, and repeating it until the image is within a factor of two of the
              target averages all the discarded detail in properly. It is what every serious image
              library does internally and what a naive one-line <code>drawImage</code> does not —
              and it is why a photo resized here looks different from the same photo resized by a
              tool that skipped this step.
            </p>

            <h3>Fit, exact and percentage</h3>
            <p>
              <strong>Fit inside</strong> treats your numbers as a bounding box and scales the image
              until it fits, keeping the aspect ratio. This is what you want almost always: a 4:3
              photo fitted into 1600 × 1600 comes out 1600 × 1200, not squashed into a square.
            </p>
            <p>
              <strong>Exact</strong> forces both dimensions, which distorts anything whose ratio does
              not match. It is the right answer only when the destination genuinely demands specific
              pixels and the content can take it.
            </p>
            <p>
              <strong>Percentage</strong> scales both dimensions by the same factor, which is the
              quickest way to say &ldquo;half the size&rdquo; for a batch of images that are not all
              the same shape.
            </p>

            <h3>Enlarging is off by default, and mostly a mistake</h3>
            <p>
              Scaling a 400-pixel image up to 2000 pixels cannot add detail that was never captured.
              Interpolation invents plausible intermediate pixels, and the result is a larger,
              blurrier file that is worse than the original in every respect except its dimensions.
              This tool will do it if you tick the box — sometimes a destination really does require
              a minimum size — but it does not do it by accident.
            </p>

            <h3>Aspect ratio, and what it is protecting you from</h3>
            <p>
              The ratio lock is not a convenience. A stretched photograph is immediately obvious to a
              viewer even when they cannot say why, because faces are the thing human vision is best
              at and a 10% horizontal stretch makes every face in the frame subtly wrong. Keeping
              the ratio and accepting whatever second dimension follows is nearly always right.
            </p>

            <h3>Resizing beats compressing</h3>
            <p>
              If you are trying to make a file smaller, dimensions are a far stronger lever than
              quality. Pixel count scales with the square of the dimension: halving the width and
              height leaves a quarter of the pixels, which typically takes 70–80% off the file
              before the quality setting is touched at all. An image displayed 800 pixels wide but
              stored at 4000 is paying twenty-five times over for nothing.
            </p>

            <h3>Where this runs</h3>
            <p>
              Entirely in this tab, using the browser&apos;s own image pipeline —
              <code>createImageBitmap</code> to decode, a canvas to scale,
              <code>canvas.toBlob</code> to encode. Nothing is uploaded, and each canvas is released
              as soon as its step is finished, because a 4000 × 3000 intermediate is 48 MB of pixel
              data that a browser is in no hurry to reclaim.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `photo.jpg
4032 x 3024
fit inside 1600 x 1600`,
        outputTitle: "Output",
        exampleOutput: `photo-1600x1200.jpg
1600 x 1200
stepped: 4032 -> 2016 -> 1600`,
      }}
      referenceTable={{
        title: "Settings",
        rows: [
          {
            parameter: "Fit inside",
            type: "mode",
            defaultVal: "default",
            description:
              "Treats the numbers as a bounding box and keeps the aspect ratio. The right choice nearly always.",
          },
          {
            parameter: "Exact",
            type: "mode",
            defaultVal: "—",
            description:
              "Forces both dimensions and distorts anything whose ratio does not match. Use deliberately.",
          },
          {
            parameter: "Percentage",
            type: "mode",
            defaultVal: "—",
            description:
              "Scales both dimensions by the same factor. Useful for a batch of mixed shapes.",
          },
          {
            parameter: "Allow enlarging",
            type: "checkbox",
            defaultVal: "off",
            description:
              "Off by default. Upscaling invents detail and produces a larger, blurrier file.",
          },
          {
            parameter: "Quality",
            type: "0.1 – 1.0",
            defaultVal: "0.85",
            description: "Applies to JPG, WebP and AVIF output. Ignored by PNG, which is lossless.",
          },
          {
            parameter: "Stepped downscale",
            type: "automatic",
            defaultVal: "—",
            description:
              "Repeated halving until within a factor of two of the target, so no source pixel is skipped.",
          },
          {
            parameter: "1920 × 1080",
            type: "preset",
            defaultVal: "—",
            description: "Full HD. A desktop wallpaper or a full-width hero image.",
          },
          {
            parameter: "1200 × 630",
            type: "preset",
            defaultVal: "—",
            description: "The Open Graph link-preview size used by social platforms.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will resizing make my image blurry?",
          answer:
            "Not when it is done properly, which is the point of the stepped downscale here. Scaling straight from 4000 pixels to 400 in one operation makes the browser sample a handful of source pixels per destination pixel and ignore the other ninety-odd, which aliases fine texture into moiré rather than blurring it gracefully. Halving repeatedly until close to the target averages every source pixel in, and the result is as sharp as the source allows. Enlarging is a different matter — that genuinely is blurry, because the detail does not exist.",
        },
        {
          question: "What size should a web image be?",
          answer:
            "Roughly twice the size it will be displayed at, capped by common sense. An image shown 800 pixels wide should be stored at about 1600 so it stays sharp on a retina screen; storing it at 4000 costs twenty-five times the pixels for no visible benefit. 1200 pixels is a good maximum for images inside an article, 1920 for a full-width hero, and 400 for a thumbnail.",
        },
        {
          question: "Can I resize several images at once?",
          answer:
            "Yes — drop as many as you like and they are processed one after another. Sequentially rather than in parallel, deliberately: decoding eight twelve-megapixel photos at the same time means eight 48 MB bitmaps alive at once, which is how a phone browser kills the tab. One at a time keeps peak memory at a single image and is barely slower, because the encoding is the expensive part and it does not parallelise anyway.",
        },
        {
          question: "How do I keep the aspect ratio?",
          answer:
            "Use Fit inside, which is the default. Your width and height become a bounding box, and the image is scaled until it fits inside them with its proportions intact — a 4:3 photo fitted into 1600 × 1600 comes out 1600 × 1200. Exact mode is the one that will stretch an image, and it is separate precisely so it cannot happen by accident.",
        },
        {
          question: "Why will it not make my image bigger?",
          answer:
            "It will, if you tick Allow enlarging — but it is off by default because upscaling almost always makes things worse. Interpolation cannot recover detail that the sensor never recorded; it invents plausible intermediate pixels, and the output is a larger file that looks softer than the original at every scale. If something genuinely needs a minimum size, tick the box; if you are hoping to recover quality from a small image, no tool can do that.",
        },
        {
          question: "Does resizing remove EXIF data?",
          answer:
            "Yes. The image is decoded to raw pixels and re-encoded, so camera model, timestamps and GPS coordinates are not carried into the output. The exception is orientation, which is applied rather than dropped: the rotation recorded in EXIF is baked into the pixels during decoding, so a photo taken with the phone sideways comes out the right way up instead of losing its tag and falling over.",
        },
      ]}
      relatedTools={relatedTools("/resize-image").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <FileDropZone
          accept={["image/*", ".jpg", ".jpeg", ".png", ".webp", ".avif", ".gif", ".bmp"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          multiple
          label="Drop images here"
          disabled={busy}
        />

        {files.length > 0 && (
          <>
            <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
              <div className="flex items-center gap-2">
                <span className={fieldLabel}>Mode</span>
                <div className={segmentTrack} role="group" aria-label="Resize mode">
                  {(
                    [
                      ["fit", "Fit inside"],
                      ["exact", "Exact"],
                      ["percent", "Percent"],
                    ] as const
                  ).map(([value, label]) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setMode(value)}
                      aria-pressed={mode === value}
                      className={segment(mode === value)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {mode === "percent" ? (
                <div className="flex items-center gap-2">
                  <label htmlFor="resize-percent" className={fieldLabel}>
                    Scale
                  </label>
                  <input
                    id="resize-percent"
                    type="range"
                    min={5}
                    max={200}
                    value={percent}
                    onChange={(event) => setPercent(Number(event.target.value))}
                    className="w-32 accent-accent-solid"
                  />
                  <span className="w-10 font-mono text-2xs text-foreground-subtle">{percent}%</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <label htmlFor="resize-width" className={fieldLabel}>
                    Width
                  </label>
                  <input
                    id="resize-width"
                    type="number"
                    min={1}
                    value={width}
                    onChange={(event) => setWidth(event.target.value)}
                    className={`${field} w-24`}
                  />
                  <label htmlFor="resize-height" className={fieldLabel}>
                    Height
                  </label>
                  <input
                    id="resize-height"
                    type="number"
                    min={1}
                    value={height}
                    onChange={(event) => setHeight(event.target.value)}
                    className={`${field} w-24`}
                  />
                </div>
              )}

              <div className="flex items-center gap-2">
                <span className={fieldLabel}>Format</span>
                <div className={segmentTrack} role="group" aria-label="Output format">
                  {(["keep", "jpeg", "png", "webp"] as const).map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setOutput(value)}
                      aria-pressed={output === value}
                      className={segment(output === value)}
                    >
                      {value === "keep" ? "Same" : value === "jpeg" ? "JPG" : value.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {output !== "png" && (
                <div className="flex items-center gap-2">
                  <label htmlFor="resize-quality" className={fieldLabel}>
                    Quality
                  </label>
                  <input
                    id="resize-quality"
                    type="range"
                    min={10}
                    max={100}
                    value={Math.round(quality * 100)}
                    onChange={(event) => setQuality(Number(event.target.value) / 100)}
                    className="w-24 accent-accent-solid"
                  />
                  <span className="w-8 font-mono text-2xs text-foreground-subtle">
                    {Math.round(quality * 100)}
                  </span>
                </div>
              )}

              {mode === "fit" && (
                <label className="flex cursor-pointer items-center gap-2">
                  <input
                    type="checkbox"
                    checked={allowUpscale}
                    onChange={(event) => setAllowUpscale(event.target.checked)}
                    className={checkbox}
                  />
                  <span className={fieldLabel}>Allow enlarging</span>
                </label>
              )}

              <button type="button" onClick={resize} disabled={busy} className={btnPrimary}>
                {busy ? "Resizing…" : `Resize ${files.length} image${files.length === 1 ? "" : "s"}`}
              </button>
            </div>

            {mode !== "percent" && (
              <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2">
                <span className={fieldLabel}>Presets</span>
                {SIZE_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setWidth(String(preset.width));
                      setHeight(String(preset.height));
                    }}
                    title={preset.note}
                    className="cursor-pointer rounded border border-border px-2 py-1 font-mono text-2xs text-foreground-muted transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  >
                    {preset.label} · {preset.width}×{preset.height}
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {mode === "exact" && (
          <Notice tone="warn">
            Exact mode forces both dimensions, so any image whose aspect ratio does not match will
            be stretched. On a photograph that is immediately visible — faces are what human vision
            is best at, and a 10% horizontal stretch makes every face in the frame subtly wrong.
            Fit inside keeps the proportions and is what you probably want.
          </Notice>
        )}

        {mode === "fit" && allowUpscale && (
          <Notice tone="warn">
            Enlarging cannot recover detail that was never captured. Interpolation invents
            intermediate pixels, so the output is a larger file that looks softer than the original.
            Worth doing only when a destination demands a minimum size.
          </Notice>
        )}

        {files.length > 0 && (
          <OutputName
            mode="pattern"
            defaultStem="{name}-{width}x{height}"
            extension={output === "keep" ? "jpg" : FORMAT_EXTENSION[output]}
            sample={{ name: stemOf(files[0].file.name), n: 1, width: 1600, height: 1200 }}
            tokens={["name", "n", "width", "height", "date"]}
            value={namePattern}
            onChange={setNamePattern}
          />
        )}

        <ImageResults state={state} transparent={output === "png" || output === "keep"} />
      </div>
    </ToolShell>
  );
};
