import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { ResizeImageClient } from "./ResizeImageClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/resize-image",
  title: "Resize Image — Sharp Downscaling, No Upload",
  socialTitle: "Resize Image",
  description:
    "Resize images by pixels, percentage or preset, in your browser. Downscales in halving steps, so fine detail is averaged in rather than aliased.",
});

export default function ResizeImagePage() {
  return <ResizeImageClient />;
}
