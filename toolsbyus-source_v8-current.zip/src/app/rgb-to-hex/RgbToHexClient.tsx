"use client";

import React from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { ColorConvertSurface } from "../../components/tools/ColorConvertSurface";
import { relatedTools } from "../../lib/tools";

export const RgbToHexClient: React.FC = () => (
  <ToolShell
    slug="rgb-to-hex"
    keyword="RGB to HEX Converter"
    directAnswer="RGB to HEX turns three decimal channels into a hex colour. Each channel is divided by 16: the quotient is the first hex digit and the remainder is the second, so 136 becomes 88 and 255 becomes ff. An alpha value is appended as a fourth pair, rounded to the nearest of 256 steps — which is the one place the round trip is not exact."
    breadcrumbs={[
      { name: "Color Tools", url: "/color-tools" },
      { name: "RGB to HEX", url: "/rgb-to-hex" },
    ]}
    seoDescription="Convert rgb() or rgba() values to a hex colour, with the base-16 arithmetic shown per channel. Handles alpha, percentages and both CSS syntaxes, entirely in your browser."
    howItWorks={{
      inputTitle: "RGB channels",
      outputTitle: "The hex colour",
      exampleInput: "rgb(255 136 0)",
      exampleOutput: `#ff8800

255 → ff   (15 × 16 + 15)
136 → 88   (8 × 16 + 8)
  0 → 00   (0 × 16 + 0)`,
      algorithmExplanation: (
        <>
          <p>
            Each channel is a whole number from 0 to 255, and two hex digits hold exactly that
            range. Divide by 16: the quotient is the first digit, the remainder is the second. 136
            ÷ 16 is 8 remainder 8, so <code>88</code>. 255 ÷ 16 is 15 remainder 15, and 15 is{" "}
            <code>f</code>, so <code>ff</code>.
          </p>
          <h3>Single-digit channels need the leading zero</h3>
          <p>
            A channel below 16 produces one digit, and dropping the zero shifts every digit after
            it. <code>rgb(255 8 0)</code> is <code>#ff0800</code>, not <code>#ff800</code> — the
            second of which is five digits and not a colour at all. It is the classic bug in a
            hand-rolled converter, and it only shows up on dark colours, which is where nobody
            looks.
          </p>
          <h3>What happens to a non-integer channel</h3>
          <p>
            CSS allows <code>rgb(255.6 136 0)</code>, and hex cannot hold a fraction. The value is
            rounded to the nearest integer, which is what the browser does too. If your channels
            came out of a calculation — a lightened colour, an interpolated step — the hex you get
            back is the rounded version, and converting it forward again will not return the
            fraction you started with.
          </p>
          <h3>Alpha, and the one lossy step</h3>
          <p>
            An alpha of 0.5 becomes <code>80</code>, because 0.5 × 255 is 127.5 and it rounds to
            128. Converting that back gives 0.502. Every colour channel round-trips exactly;
            alpha does not, because it is a fraction being stored in 256 steps. The difference is
            far below anything visible and it will show up the moment you compare two strings in a
            test.
          </p>
          <h3>Percentages</h3>
          <p>
            <code>rgb(100% 53.3% 0%)</code> is the same colour as <code>rgb(255 136 0)</code>:
            percentages in <code>rgb()</code> resolve against 255, not against 100. This catches
            people converting from a design tool that exports 0–100 values, where 53% means 135,
            not 53.
          </p>
        </>
      ),
    }}
    referenceTable={{
      title: "Channel to digits",
      rows: [
        { parameter: "0", type: "channel", defaultVal: "00", description: "The minimum. Both digits zero." },
        { parameter: "8", type: "channel", defaultVal: "08", description: "Below 16, so the leading zero is required. Dropping it corrupts the whole value." },
        { parameter: "128", type: "channel", defaultVal: "80", description: "The midpoint, and 8 × 16 exactly." },
        { parameter: "136", type: "channel", defaultVal: "88", description: "8 × 16 + 8." },
        { parameter: "255", type: "channel", defaultVal: "ff", description: "The maximum. 15 × 16 + 15." },
        { parameter: "0.5 alpha", type: "fraction", defaultVal: "80", description: "127.5 rounds to 128. Converting back gives 0.502 — the only step of this conversion that is not exact." },
        { parameter: "255.6", type: "non-integer", defaultVal: "ff", description: "Rounded, as the browser rounds it. A fractional channel cannot survive hex." },
        { parameter: "100%", type: "percentage", defaultVal: "255", description: "Percentages resolve against 255. 53% is 135, not 53." },
      ],
    }}
    faqs={[
      {
        question: "How do I convert RGB to hex manually?",
        answer:
          "Divide each channel by 16. The quotient is the first digit and the remainder is the second, with 10–15 written as a–f. 136 ÷ 16 = 8 remainder 8, so 88. Write the three pairs in order — red, green, blue — with a # in front. The only trap is a channel below 16: it must still be two digits, so 8 is 08, not 8.",
      },
      {
        question: "Why is my hex colour five digits long?",
        answer:
          "A channel under 16 lost its leading zero. rgb(255 8 0) is #ff0800; written as #ff800 it is five characters, which is not a valid hex colour and browsers will ignore the whole declaration. This is the most common bug in hand-written conversion code and it only appears on dark colours.",
      },
      {
        question: "Does converting RGB to hex lose any colour information?",
        answer:
          "No, for the colour itself — both notations hold the same three bytes, so the round trip is exact. Alpha is the exception: it is a fraction in CSS and hex stores it in 256 steps, so 0.5 becomes 80 and comes back as 0.502. Invisible on screen, visible in a string comparison.",
      },
      {
        question: "What does rgb(100% 50% 0%) convert to?",
        answer:
          "#ff8000. Percentages in rgb() are fractions of 255, not of 100, so 50% is 127.5 which rounds to 128 — hex 80. If a design tool exported those numbers as 0–100 values they mean something different, and that mismatch is worth checking before pasting.",
      },
      {
        question: "Should I write rgba() or use an 8-digit hex?",
        answer:
          "Either; both are supported everywhere current. 8-digit hex is more compact and keeps the whole colour in one token, which suits design tokens and variables. rgba() is easier to read and easier to edit by hand, and it is what most existing stylesheets already contain. The only real argument is consistency with the code around it.",
      },
    ]}
    relatedTools={relatedTools("/rgb-to-hex").map((tool) => ({
      href: tool.href,
      title: tool.title,
      description: tool.description,
    }))}
  >
    <ColorConvertSurface from="rgb" to="hex" initial="rgb(255 136 0)" />
  </ToolShell>
);
