import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { RgbToHexClient } from "./RgbToHexClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/rgb-to-hex",
  title: "RGB to HEX Converter — With the Arithmetic Shown",
  socialTitle: "RGB to HEX",
  description:
    "Convert rgb() or rgba() values to a hex colour, with the base-16 arithmetic shown per channel. Handles alpha, percentages and both CSS syntaxes.",
});

export default function Page() {
  return <RgbToHexClient />;
}
