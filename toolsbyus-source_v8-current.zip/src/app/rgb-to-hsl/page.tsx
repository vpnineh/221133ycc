import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { RgbToHslClient } from "./RgbToHslClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/rgb-to-hsl",
  title: "RGB to HSL Converter — CSS Syntax",
  socialTitle: "RGB to HSL",
  description:
    "Convert rgb() values to hue, saturation and lightness, with the max, min and chroma the formula runs on shown.",
});

export default function Page() {
  return <RgbToHslClient />;
}
