"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SinglePdfTool } from "../../components/tools/SinglePdfTool";
import { field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parsePageRange } from "../../lib/files";
import { withStem } from "../../lib/files/naming";
import { relatedTools } from "../../lib/tools";

export const RotatePdfClient: React.FC = () => {
  const [degrees, setDegrees] = useState(90);
  const [scope, setScope] = useState<"all" | "range">("all");
  const [range, setRange] = useState("1-");

  return (
    <ToolShell
      slug="rotate-pdf"
      keyword="Rotate PDF"
      directAnswer="Rotate PDF turns pages permanently in your browser. That is the distinction that matters: a PDF reader's rotate button changes only your view and resets when the file is reopened elsewhere, while this writes the rotation into the document so it is sideways for nobody."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Rotate PDF", url: "/rotate-pdf" },
      ]}
      seoDescription="Rotate PDF pages permanently in your browser. Turn every page or a selected range by 90, 180 or 270 degrees, saved into the file rather than into your reader's view."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Nearly everyone who needs this has already tried the rotate button in their PDF
              reader, found that it worked, and then discovered that the file was still sideways for
              the person they sent it to.
            </p>
            <h3>View rotation is not document rotation</h3>
            <p>
              A reader&apos;s rotate control changes how that reader draws the page. It is a view
              setting, stored with your application preferences or not stored at all, and it has no
              effect on the file. Send the document to a colleague and they see the original
              orientation.
            </p>
            <p>
              A PDF page carries its own <code>/Rotate</code> entry: a number of degrees, a multiple
              of 90, that every conforming reader applies when drawing that page. Writing it is what
              makes the rotation part of the document rather than part of your session — and it is
              what this tool does.
            </p>
            <h3>Rotation is cumulative, and normalised</h3>
            <p>
              A page already at 270° rotated by another 180° is at 90°, not 450°. The existing value
              is read, the new one added, and the result reduced modulo 360 — because a{" "}
              <code>/Rotate 450</code> is outside what the specification allows and readers disagree
              about what to do with it. Negative values are normalised the same way, so rotating
              anticlockwise from 0 gives 270 rather than −90.
            </p>
            <h3>Nothing is re-rendered</h3>
            <p>
              Only the rotation entry changes. Page content, fonts and images are untouched, so the
              file does not grow, quality does not change, and text stays selectable and searchable.
              A tool that rotated by rasterising each page would produce a visually identical
              document with none of those properties — which is what happens when a rotation turns a
              searchable document into a stack of pictures.
            </p>
            <h3>Rotating some pages and not others</h3>
            <p>
              A scan where the operator turned the stack halfway through needs a range rather than
              the whole document. The range syntax is the print dialogue&apos;s:{" "}
              <code>1-3, 7, 12-</code>, one-based, open-ended at either end.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `scan.pdf — pages 4-9 are sideways
rotate 90° clockwise, pages 4-9`,
        outputTitle: "Output",
        exampleOutput: `rotated.pdf
/Rotate written into pages 4-9
content untouched, text still selectable`,
      }}
      referenceTable={{
        title: "Options and behaviour",
        rows: [
          {
            parameter: "90°",
            type: "clockwise",
            defaultVal: "default",
            description: "A quarter turn right. The usual fix for a page scanned on its side.",
          },
          {
            parameter: "180°",
            type: "half turn",
            defaultVal: "—",
            description: "For a page fed into the scanner upside down.",
          },
          {
            parameter: "270°",
            type: "anticlockwise",
            defaultVal: "—",
            description: "A quarter turn left, equivalent to −90.",
          },
          {
            parameter: "Cumulative",
            type: "added to existing",
            defaultVal: "always",
            description:
              "The page's current rotation is read and the new value added, then reduced modulo 360. A /Rotate outside 0–270 is outside the specification and readers disagree about it.",
          },
          {
            parameter: "Scope",
            type: "all pages or a range",
            defaultVal: "all",
            description:
              "Range syntax is the print dialogue's: 1-3, 7, 12-. One-based, open-ended at either end.",
          },
          {
            parameter: "Content",
            type: "untouched",
            defaultVal: "—",
            description:
              "Only the rotation entry changes. No re-rendering, so file size and quality are unchanged and text stays selectable.",
          },
          {
            parameter: "Reader view rotation",
            type: "unrelated",
            defaultVal: "—",
            description:
              "Your reader's rotate button changes a view setting and not the file. This writes the document, which is why the result is right for everybody.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why did rotating in my PDF reader not stick?",
          answer:
            "Because a reader's rotate button is a view control. It changes how that application draws the page and is stored with your preferences, or not stored at all — the file itself is unchanged, so everyone else still sees the original orientation. Writing the rotation into the document is a different operation, and it is the one you want before sending a file.",
        },
        {
          question: "Does rotating reduce quality or make the file bigger?",
          answer:
            "Neither. Only a single number per page changes; the page content, its fonts and its images are untouched. A tool that rotated by re-rendering each page to an image would produce a visually identical file that was several times larger, no longer searchable, and no longer selectable — which is a real thing that happens, and worth checking after any PDF operation.",
        },
        {
          question: "Can I rotate only some pages?",
          answer:
            "Yes. Switch the scope to a range and use the print-dialogue syntax: 1-3, 7, 12-. This is the common case for a scanned stack where the operator turned the paper partway through, and rotating the whole document would fix half of it and break the other half.",
        },
        {
          question: "What happens if I rotate a page that is already rotated?",
          answer:
            "The rotations add. A page at 270° rotated by 180° ends at 90°, because the sum is reduced modulo 360. This matters because a PDF's rotation entry is only valid at 0, 90, 180 or 270; writing 450 produces a file that some readers normalise and others refuse.",
        },
        {
          question: "Will the text still be selectable afterwards?",
          answer:
            "Yes, and this is the test worth running on any PDF tool. Open the result and try to select a line of text. If you can, the document is still a document; if you cannot, something rasterised your pages into images, and you have lost searchability, accessibility and about ten times the file size.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. The rotation is applied in this tab and the file is saved locally. The page's Content-Security-Policy sets connect-src 'self', so the browser would block an upload attempt regardless of what the code tried to do.",
        },
      ]}
      relatedTools={relatedTools("/rotate-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <SinglePdfTool
        runLabel={() => `Rotate ${degrees}°`}
        controls={(info) => (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Rotate</span>
              <div className={segmentTrack} role="group" aria-label="Rotation">
                {[90, 180, 270].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setDegrees(value)}
                    aria-pressed={degrees === value}
                    className={segment(degrees === value)}
                  >
                    {value}°
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Pages</span>
              <div className={segmentTrack} role="group" aria-label="Scope">
                {(
                  [
                    ["all", `All ${info.pageCount}`],
                    ["range", "Range"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setScope(value)}
                    aria-pressed={scope === value}
                    className={segment(scope === value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {scope === "range" && (
              <div className="flex items-center gap-2">
                <label htmlFor="rotate-range" className={fieldLabel}>
                  Which
                </label>
                <input
                  id="rotate-range"
                  type="text"
                  value={range}
                  onChange={(event) => setRange(event.target.value)}
                  placeholder="1-3, 7"
                  spellCheck={false}
                  className={`${field} w-36`}
                />
              </div>
            )}
          </div>
        )}
        naming={{ mode: "single", defaultStem: (stem) => `${stem}-rotated` }}
        operation={async (info, file, stem) => {
          let pages: number[];
          if (scope === "all") {
            pages = Array.from({ length: info.pageCount }, (_unused, index) => index);
          } else {
            const parsed = parsePageRange(range, info.pageCount);
            if (parsed.error) return { blocked: parsed.error };
            pages = parsed.pages;
          }
          return {
            type: "rotate",
            file: await file.arrayBuffer(),
            pages,
            degrees,
            name: withStem(stem, "pdf"),
          };
        }}
      />
    </ToolShell>
  );
};
