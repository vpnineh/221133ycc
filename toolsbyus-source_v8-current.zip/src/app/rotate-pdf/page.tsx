import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { RotatePdfClient } from "./RotatePdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/rotate-pdf",
  title: "Rotate PDF — Fix a Sideways Scan Permanently",
  socialTitle: "Rotate PDF",
  description:
    "Rotate PDF pages in your browser and save the rotation permanently. Fixes a sideways scan for every reader, not just yours. Nothing is uploaded.",
});

export default function RotatePdfPage() {
  return <RotatePdfClient />;
}
