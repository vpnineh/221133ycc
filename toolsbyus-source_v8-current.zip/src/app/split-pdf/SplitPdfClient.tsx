"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SinglePdfTool } from "../../components/tools/SinglePdfTool";
import { field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parsePageRange, formatPageRange } from "../../lib/files";
import { applyPattern, stemOf } from "../../lib/files/naming";
import { relatedTools } from "../../lib/tools";

type Mode = "ranges" | "every" | "chunks";

export const SplitPdfClient: React.FC = () => {
  const [mode, setMode] = useState<Mode>("ranges");
  const [ranges, setRanges] = useState("1-3, 5");
  const [chunkSize, setChunkSize] = useState(10);
  const [preview, setPreview] = useState<string>("");

  return (
    <ToolShell
      slug="split-pdf"
      keyword="Split PDF"
      directAnswer="Split PDF extracts pages from a document in your browser: a set of ranges, one file per page, or fixed-size chunks. Each output is a real PDF with its own object graph rather than a copy of the original with pages hidden, so the pages you did not select are genuinely absent from the file."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Split PDF", url: "/split-pdf" },
      ]}
      seoDescription="Split a PDF into separate files in your browser. Extract page ranges, produce one file per page, or break a long document into fixed-size chunks. No upload, no watermark."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Splitting sounds like the easy half of merging, and one detail makes it the more
              consequential one: what happens to the pages you did not ask for.
            </p>
            <h3>Extracted, not hidden</h3>
            <p>
              A lazy implementation copies the whole document and marks the unwanted pages
              invisible, or removes them from the page tree while leaving their content streams in
              the file. The result looks right in a reader and still contains every word you thought
              you had removed — recoverable with any text extractor, which is how redaction failures
              make the news.
            </p>
            <p>
              Here each output is a new document into which the selected pages are copied with their
              dependency graph. Nothing from the unselected pages is carried across, because nothing
              references it. That is the difference between extracting page 3 of a contract and
              sending someone a file that merely displays page 3.
            </p>
            <h3>Three ways to split, for three different jobs</h3>
            <p>
              <strong>Ranges</strong> is for pulling out the part you need:{" "}
              <code>1-3, 7, 12-</code> produces one file containing those pages, in that order. An
              open-ended range runs to the last page, which is what a print dialogue does and what
              people expect.
            </p>
            <p>
              <strong>One file per page</strong> is for a scanned batch that should have been
              separate documents in the first place — a stack of receipts, a set of certificates,
              forty invoices scanned in one pass.
            </p>
            <p>
              <strong>Fixed chunks</strong> is for a size limit somewhere else: an email attachment
              ceiling, an upload form that rejects anything over 10 MB, a print shop that takes
              twenty pages at a time.
            </p>
            <h3>Page numbers are the ones printed on the page selector</h3>
            <p>
              Input is one-based, because that is what the page numbers say. Internally every PDF
              API is zero-based, and the conversion happens in exactly one place — a boundary that is
              easy to get wrong and produces a file missing the wrong page, which a user discovers
              much later.
            </p>
            <h3>Everything happens in this tab</h3>
            <p>
              The document is never uploaded. That matters most here, because splitting is what you
              do to send one page of something to someone — which means the whole document is
              material you are being careful about.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `report.pdf (24 pages)
ranges: 1-3, 7, 12-`,
        outputTitle: "Output",
        exampleOutput: `part-1.pdf  — pages 1, 2, 3, 7, 12…24
each a new document, unselected
pages absent rather than hidden`,
      }}
      referenceTable={{
        title: "Modes and syntax",
        rows: [
          {
            parameter: "1-3, 7, 12-",
            type: "range list",
            defaultVal: "—",
            description:
              "Commas separate parts; a hyphen makes a range; an open end runs to the last page. One-based, as printed.",
          },
          {
            parameter: "Ranges",
            type: "mode",
            defaultVal: "default",
            description: "One output file containing the selected pages, in the order given.",
          },
          {
            parameter: "One file per page",
            type: "mode",
            defaultVal: "—",
            description:
              "As many files as the document has pages. For a scanned batch that should have been separate documents.",
          },
          {
            parameter: "Fixed chunks",
            type: "mode",
            defaultVal: "10 pages",
            description:
              "Sequential groups of N pages, with the last one short. For an attachment size limit somewhere else.",
          },
          {
            parameter: "Unselected pages",
            type: "absent",
            defaultVal: "always",
            description:
              "Copied into a new document rather than hidden in a copy of the original, so their content is not recoverable from the output.",
          },
          {
            parameter: "Page order",
            type: "as written",
            defaultVal: "—",
            description:
              "5, 1, 3 produces a document in that order. Duplicates are allowed, which is occasionally exactly what you want.",
          },
          {
            parameter: "Bookmarks",
            type: "not carried",
            defaultVal: "—",
            description:
              "The outline is document-level structure whose destinations point at pages that may not be in the output. A broken outline is worse than none.",
          },
          {
            parameter: "Encrypted PDFs",
            type: "declined",
            defaultVal: "—",
            description: "Unlock it first with the password, if you have it.",
          },
        ],
      }}
      faqs={[
        {
          question: "Are the pages I removed really gone from the file?",
          answer:
            "Yes. Each output is a new document into which only the selected pages are copied, so nothing from the others is present to be recovered. This is worth checking in any tool you use: an implementation that copies the document and hides pages produces a file that looks right and still contains every word, extractable by anyone with a text tool. That is how redaction failures reach the newspapers.",
        },
        {
          question: "What does 12- mean?",
          answer:
            "Page 12 to the end. Open-ended ranges work in both directions: -5 means the first five pages. It is the same syntax a print dialogue uses, because that is the syntax people already know.",
        },
        {
          question: "Can I put the pages in a different order?",
          answer:
            "Yes — the output follows the order you write, so 5, 1, 3 produces a document in that order rather than sorted. Duplicates are allowed too, which is occasionally what you want for a cover sheet. If reordering is the whole job rather than a side effect, the page reorder tool is more direct.",
        },
        {
          question: "Why would I split into fixed chunks?",
          answer:
            "Almost always a size limit somewhere else: an email attachment ceiling, a government upload form that rejects anything over 10 MB, a print shop that takes twenty pages per job. Splitting by page count is a rough proxy for size, so check the results — a document with one photo-heavy section will produce chunks of very different sizes.",
        },
        {
          question: "Will the split files keep their bookmarks?",
          answer:
            "No, and deliberately. A bookmark outline is document-level structure whose destinations point at specific pages; in a file containing a subset of those pages, most destinations point at nothing. Carrying it over would produce an outline that looks intact and misbehaves when clicked, which is worse than its absence.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. It is read, split and written back in this tab, and the page's Content-Security-Policy sets connect-src 'self', so the browser itself would block an upload. Open the Network panel and split something if you want to confirm it — that is a more useful check than any promise on this page.",
        },
      ]}
      relatedTools={relatedTools("/split-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <SinglePdfTool
        runLabel={(info) =>
          mode === "every"
            ? `Split into ${info.pageCount} files`
            : mode === "chunks"
              ? `Split into ${Math.ceil(info.pageCount / Math.max(1, chunkSize))} files`
              : "Extract pages"
        }
        controls={(info) => (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Split by</span>
              <div className={segmentTrack} role="group" aria-label="Split mode">
                {(
                  [
                    ["ranges", "Ranges"],
                    ["every", "Every page"],
                    ["chunks", "Chunks"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setMode(value)}
                    aria-pressed={mode === value}
                    className={segment(mode === value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {mode === "ranges" && (
              <div className="flex items-center gap-2">
                <label htmlFor="split-ranges" className={fieldLabel}>
                  Pages
                </label>
                <input
                  id="split-ranges"
                  type="text"
                  value={ranges}
                  onChange={(event) => {
                    setRanges(event.target.value);
                    const parsed = parsePageRange(event.target.value, info.pageCount);
                    setPreview(parsed.error ?? formatPageRange(parsed.pages));
                  }}
                  placeholder="1-3, 7, 12-"
                  spellCheck={false}
                  className={`${field} w-44`}
                />
                <span className="font-mono text-2xs text-foreground-subtle">
                  {preview || formatPageRange(parsePageRange(ranges, info.pageCount).pages)}
                </span>
              </div>
            )}

            {mode === "chunks" && (
              <div className="flex items-center gap-2">
                <label htmlFor="split-chunk" className={fieldLabel}>
                  Pages per file
                </label>
                <input
                  id="split-chunk"
                  type="number"
                  min={1}
                  max={info.pageCount}
                  value={chunkSize}
                  onChange={(event) =>
                    setChunkSize(Math.max(1, Number(event.target.value) || 1))
                  }
                  className={`${field} w-20`}
                />
              </div>
            )}
          </div>
        )}
        // A pattern rather than a name: this tool can produce one file per page,
        // and a hundred files with one name is a hundred files called "(1)".
        naming={{
          mode: "pattern",
          defaultStem: (stem) => `${stem}-{n}`,
          sample: (stem) => ({ name: stem, n: 1, page: 1 }),
          tokens: ["name", "n", "page", "date"],
        }}
        operation={async (info, file, stem) => {
          const buffer = await file.arrayBuffer();

          // `{page}` means the first page of the part, which is the only reading
          // of it that survives a chunked split.
          const nameGroups = (groups: number[][]) =>
            groups.map((group, index) =>
              applyPattern(stem, { name: stemOf(file.name), n: index + 1, page: group[0] + 1 }, "pdf")
            );

          if (mode === "every") {
            const groups = Array.from({ length: info.pageCount }, (_unused, index) => [index]);
            return { type: "split", file: buffer, groups, names: nameGroups(groups) };
          }

          if (mode === "chunks") {
            const groups: number[][] = [];
            for (let start = 0; start < info.pageCount; start += chunkSize) {
              groups.push(
                Array.from(
                  { length: Math.min(chunkSize, info.pageCount - start) },
                  (_unused, offset) => start + offset
                )
              );
            }
            return { type: "split", file: buffer, groups, names: nameGroups(groups) };
          }

          const parsed = parsePageRange(ranges, info.pageCount);
          if (parsed.error) return { blocked: parsed.error };
          const groups = [parsed.pages];
          return { type: "split", file: buffer, groups, names: nameGroups(groups) };
        }}
      />
    </ToolShell>
  );
};
