import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { SplitPdfClient } from "./SplitPdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/split-pdf",
  title: "Split PDF — Extract Pages, Nothing Uploaded",
  socialTitle: "Split PDF",
  description:
    "Extract pages from a PDF in your browser. Split by range, into fixed-size chunks, or one file per page — with nothing uploaded and no watermark.",
});

export default function SplitPdfPage() {
  return <SplitPdfClient />;
}
