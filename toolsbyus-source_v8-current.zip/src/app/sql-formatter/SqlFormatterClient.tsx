"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatSql, minifySql, tokenizeSql, SQL_DEFAULTS, type SqlDialect } from "../../lib/format/sql";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `-- Revenue by customer, last 30 days
select c.id, c.name, count(o.id) as order_count, sum(o.total) as revenue, 'FROM cache' as source
from customers c left join orders o on o.customer_id = c.id and o.status <> 'cancelled'
where c.created_at >= now() - interval '30 days' and (c.tier = 'pro' or c.tier = 'enterprise')
group by c.id, c.name having sum(o.total) > 1000 order by revenue desc limit 50;`;

const DIALECTS: Array<{ id: SqlDialect; label: string }> = [
  { id: "standard", label: "Standard" },
  { id: "postgres", label: "Postgres" },
  { id: "mysql", label: "MySQL" },
  { id: "tsql", label: "T-SQL" },
];

export const SqlFormatterClient: React.FC = () => {
  const [dialect, setDialect] = useState<SqlDialect>("postgres");
  const [mode, setMode] = useState<"format" | "minify">("format");
  const [indent, setIndent] = useState(2);
  const [uppercaseKeywords, setUppercaseKeywords] = useState(true);
  const [columnPerLine, setColumnPerLine] = useState(true);
  const [leadingCommas, setLeadingCommas] = useState(false);

  const transform = (input: string): TransformOutcome => {
    if (!input.trim()) return { output: "" };

    const output =
      mode === "minify"
        ? minifySql(input, dialect)
        : formatSql(input, {
            ...SQL_DEFAULTS,
            dialect,
            indent,
            uppercaseKeywords,
            columnPerLine,
            leadingCommas,
          });

    const tokens = tokenizeSql(input, dialect).filter((token) => token.kind !== "whitespace");
    const statements = tokens.filter((token) => token.value === ";").length;

    return {
      output,
      stats: [
        { label: "Tokens", value: tokens.length.toLocaleString("en-GB") },
        { label: "Statements", value: String(Math.max(statements, output.trim() ? 1 : 0)) },
        {
          label: mode === "minify" ? "Saved" : "Lines",
          value:
            mode === "minify"
              ? `${Math.round((1 - output.length / Math.max(input.length, 1)) * 100)}%`
              : String(output.split("\n").length),
        },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="sql-formatter"
      keyword="SQL Formatter"
      directAnswer="SQL Formatter re-indents a query in your browser. It tokenises the SQL first rather than matching keywords with a regular expression, which is the difference between a formatter that works and one that breaks on the first string literal containing the word FROM."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "SQL Formatter", url: "/sql-formatter" },
      ]}
      seoDescription="Format and minify SQL in the browser. Postgres, MySQL, T-SQL and standard dialects, keyword casing, one column per line, leading commas. Strings and comments preserved exactly."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A SQL formatter is judged on what it does to the query it was not expecting. Four
              things separate one that is safe to run over a codebase from one that quietly corrupts
              a migration.
            </p>
            <h3>Tokenising, not pattern matching</h3>
            <p>
              The obvious implementation finds keywords with a regular expression and inserts line
              breaks. It works until a query contains{" "}
              <code>&apos;FROM cache&apos;</code> as a string literal, or a comment containing an
              apostrophe, and then it produces something that no longer parses. Here the query is
              tokenised first — strings, identifiers, comments, numbers, operators and keywords are
              separate things — and only keyword tokens affect layout. The sample query above
              contains a string literal with the word <code>FROM</code> in it for exactly this
              reason.
            </p>
            <h3>Quoted identifiers are never rewritten</h3>
            <p>
              <code>&quot;User&quot;</code> and <code>User</code> are different objects on a
              case-sensitive database. A formatter that &ldquo;tidies&rdquo; the quotes away has
              changed which table the query reads. The quoting style also differs by dialect —
              MySQL&apos;s backtick, T-SQL&apos;s square brackets, the standard double quote — so the
              dialect selector is about parsing correctness rather than output style.
            </p>
            <h3>Dialect-specific string rules</h3>
            <p>
              The standard escape for a quote inside a string is doubling it; MySQL also honours a
              backslash. Postgres has dollar-quoted strings whose delimiter is chosen by the author —{" "}
              <code>$func$ … $func$</code> — which exists precisely so a function body can contain
              anything. A tokeniser that does not know these will end a string early and everything
              after it is misclassified.
            </p>
            <h3>Comments keep their position</h3>
            <p>
              A comment on its own line stays on its own line; a trailing comment stays trailing.
              Block comments nest in standard SQL, unlike C, so <code>{"/* a /* b */ c */"}</code> is one
              comment and not a syntax error. Minifying converts a <code>--</code> comment to a block
              comment, because on one line a line comment would comment out the rest of the query —
              a small detail that turns a minified query into a broken one.
            </p>
            <h3>The layout the output uses</h3>
            <p>
              Clauses start lines; joins start lines; columns get one line each; boolean connectives
              in a <code>WHERE</code> start a continuation line, but only at the top level — an{" "}
              <code>AND</code> inside <code>(y = 2 AND z = 3)</code> is part of an expression and
              stays where it is. Leading commas are available because they make a column list easier
              to reorder in a diff, which is a real argument even if it looks strange at first.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `select a,b from t where x=1 and y=2`,
        outputTitle: "Formatted",
        exampleOutput: `SELECT
  a,
  b
FROM t
WHERE x = 1
  AND y = 2`,
      }}
      referenceTable={{
        title: "Options and dialect differences",
        rows: [
          {
            parameter: "Dialect",
            type: "standard / postgres / mysql / tsql",
            defaultVal: "postgres",
            description:
              "Affects parsing, not style: which characters quote an identifier, how a string escapes a quote, and whether dollar-quoting and # comments exist.",
          },
          {
            parameter: "Uppercase keywords",
            type: "boolean",
            defaultVal: "on",
            description:
              "Keywords only. Identifiers, strings and comments keep their original case, because changing an identifier's case changes which object it names on some databases.",
          },
          {
            parameter: "Column per line",
            type: "boolean",
            defaultVal: "on",
            description:
              "One selected column per line. Makes a diff show which column changed rather than that the SELECT line changed.",
          },
          {
            parameter: "Leading commas",
            type: "boolean",
            defaultVal: "off",
            description:
              "Comma before the column rather than after. Divisive, and genuinely easier to reorder: adding a column at the end does not touch the previous line.",
          },
          {
            parameter: "String literals",
            type: "preserved",
            defaultVal: "byte for byte",
            description:
              "Including whitespace inside them. A string is data, and reformatting data is not formatting.",
          },
          {
            parameter: "Quoted identifiers",
            type: "preserved",
            defaultVal: "—",
            description:
              '"User" is not User on a case-sensitive database. The quoting is never added or removed.',
          },
          {
            parameter: "Block comments",
            type: "nested",
            defaultVal: "—",
            description:
              "Standard SQL nests them, unlike C. /* a /* b */ c */ is one comment, and a tokeniser that stops at the first */ misreads the rest of the query.",
          },
          {
            parameter: "Minify",
            type: "one line",
            defaultVal: "—",
            description:
              "Collapses whitespace and converts line comments to block comments, because a -- comment on one line comments out everything after it.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why does the sample query have 'FROM cache' in it?",
          answer:
            "To demonstrate the difference between a tokenising formatter and a regex one. A formatter that finds keywords by pattern sees the FROM inside that string literal, inserts a line break in the middle of it, and produces a query that no longer parses. Tokenising first means a string is a string whatever it contains.",
        },
        {
          question: "Will it change my table or column names?",
          answer:
            "No. Only keyword tokens are recased, and quoted identifiers are passed through byte for byte, including their quotes. This matters more than it sounds: on Postgres, \"User\" and User name different tables, so a formatter that removes quotes changes the meaning of the query rather than its appearance.",
        },
        {
          question: "Which dialect should I pick?",
          answer:
            "The one your database actually is, because the setting is about parsing rather than style. MySQL uses backticks for identifiers and honours backslash escapes in strings; T-SQL uses square brackets; Postgres has dollar-quoted strings. Picking the wrong one means a string or identifier ends in the wrong place and everything after it is misclassified.",
        },
        {
          question: "Leading commas — why would anyone?",
          answer:
            "Because adding or removing the last column in a list touches one line instead of two. With trailing commas, appending a column means editing the previous line to add a comma, so the diff shows two changed lines and a reviewer has to check both. It looks strange for about a day and then stops mattering.",
        },
        {
          question: "Does minifying a query make it faster?",
          answer:
            "No. The database parses the query before planning it, and whitespace is discarded at that stage; a minified query and a formatted one produce identical plans. Minifying is for getting a query onto one line — into a log, a config file, a shell command — not for performance.",
        },
        {
          question: "Is my query uploaded?",
          answer:
            "No. Tokenising and formatting run in the tab you already have open. It matters here because queries carry things people would not paste anywhere: table and column names that describe a business, and often literal values that are real customer data.",
        },
      ]}
      relatedTools={relatedTools("/sql-formatter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="SQL"
        outputLabel={mode === "minify" ? "Minified" : "Formatted"}
        inputPlaceholder="Paste a query…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="query.sql"
        height={400}
        options={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className={segmentTrack} role="group" aria-label="Mode">
              {(["format", "minify"] as const).map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setMode(value)}
                  aria-pressed={mode === value}
                  className={segment(mode === value)}
                >
                  {value === "format" ? "Format" : "Minify"}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Dialect</span>
              <div className={segmentTrack} role="group" aria-label="Dialect">
                {DIALECTS.map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setDialect(option.id)}
                    aria-pressed={dialect === option.id}
                    className={segment(dialect === option.id)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {mode === "format" && (
              <>
                <div className="flex items-center gap-2">
                  <span className={fieldLabel}>Indent</span>
                  <div className={segmentTrack} role="group" aria-label="Indent">
                    {[2, 4].map((value) => (
                      <button
                        key={value}
                        type="button"
                        onClick={() => setIndent(value)}
                        aria-pressed={indent === value}
                        className={segment(indent === value)}
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                </div>

                {[
                  {
                    id: "sql-upper",
                    label: "UPPERCASE keywords",
                    checked: uppercaseKeywords,
                    onChange: setUppercaseKeywords,
                  },
                  {
                    id: "sql-columns",
                    label: "Column per line",
                    checked: columnPerLine,
                    onChange: setColumnPerLine,
                  },
                  {
                    id: "sql-commas",
                    label: "Leading commas",
                    checked: leadingCommas,
                    onChange: setLeadingCommas,
                  },
                ].map((toggle) => (
                  <label
                    key={toggle.id}
                    htmlFor={toggle.id}
                    className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
                  >
                    <input
                      id={toggle.id}
                      type="checkbox"
                      checked={toggle.checked}
                      onChange={(e) => toggle.onChange(e.target.checked)}
                      className={checkbox}
                    />
                    <span className={fieldLabel}>{toggle.label}</span>
                  </label>
                ))}
              </>
            )}
          </div>
        }
      />
    </ToolShell>
  );
};
