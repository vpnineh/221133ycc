import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { SqlFormatterClient } from "./SqlFormatterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/sql-formatter",
  title: "SQL Formatter — Format and Minify Any Dialect",
  socialTitle: "SQL Formatter",
  description:
    "Format and minify SQL in your browser. Tokenised rather than pattern-matched, so a keyword inside a string stays a string and quoted identifiers are never rewritten.",
});

export default function SqlFormatterPage() {
  return <SqlFormatterClient />;
}
