import React from "react";
import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { absoluteUrl } from "../../lib/site";
import Breadcrumb from "@/components/common/Breadcrumb";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import PrivacyBadge from "@/components/common/PrivacyBadge";

export const metadata: Metadata = buildToolMetadata({
  path: "/terms",
  title: "Terms of Service — Client-Side Tool Usage",
  socialTitle: "Terms of Service",
  description:
    "Terms of service for toolsbyus.com. Free developer tools provided as-is with zero data retention.",
});

export default function TermsPage() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: "Terms of Service",
      url: absoluteUrl("/terms"),
      description: "Terms of service and acceptable use policy for ToolsByUs.",
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Terms of Service",
          item: absoluteUrl("/terms"),
        },
      ],
    },
  ];

  return (
    <div className="shell max-w-3xl py-8 space-y-8">
      <SchemaJsonLd schemas={jsonLdData} />

      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Terms of Service", href: "/terms" },
        ]}
      />

      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3">
          <h1 className="text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[2.75rem]">
            Terms of Service
          </h1>
          <PrivacyBadge />
        </div>
        <h2 className="max-w-[68ch] text-sm text-foreground-muted sm:text-base">
          Simple, Honest Terms for a Client-Side Developer Utility
        </h2>
      </div>

      <div className="space-y-6">
        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            1. Acceptance of Terms
          </h3>
          <p>
            By accessing or using toolsbyus.com (&quot;the Service&quot;), you agree to be bound by these
            Terms of Service. If you disagree with any part of these terms, you may cease using the website
            at any time.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            2. Intellectual Property & Payload Ownership
          </h3>
          <p>
            <strong>Your data belongs to you:</strong> Any code, JSON payloads, tokens, schemas, text, or
            configuration files that you process, validate, diff, or format using ToolsByUs remain your
            exclusive intellectual property.
          </p>
          <p>
            Because ToolsByUs executes entirely client-side within your browser, your payloads are never
            transmitted to or stored on our servers. We claim zero ownership, license, or right to view, use,
            or reproduce any data you process through our tools.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            3. Acceptable Use
          </h3>
          <p>You agree to use ToolsByUs only for lawful purposes. You agree not to:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>Engage in automated denial-of-service attacks against our edge CDN hosting infrastructure.</li>
            <li>Attempt to scrape, reverse-engineer, or circumvent our advertising infrastructure.</li>
            <li>Use the service to distribute malicious binaries or attack payloads.</li>
          </ul>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            4. &quot;As-Is&quot; Warranty Disclaimer
          </h3>
          <p>
            ToolsByUs is provided &quot;AS IS&quot; and &quot;AS AVAILABLE&quot;, without warranty of any kind,
            express or implied, including but not limited to the warranties of merchantability, fitness for a
            particular purpose, or non-infringement.
          </p>
          <p>
            While our diff algorithms, parsers, and schema generators conform rigorously to RFC 8259,
            RFC 6902, RFC 7386, RFC 9562, and JSON Schema specifications, we cannot guarantee that the
            service will be completely error-free or that results will meet your specific business requirements.
            You are responsible for reviewing and verifying all outputs before applying them to critical
            production systems.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            5. Limitation of Liability
          </h3>
          <p>
            To the maximum extent permitted by applicable law, in no event shall the authors or operators
            of toolsbyus.com be liable for any direct, indirect, incidental, special, consequential, or
            punitive damages arising out of or related to your use or inability to use the service.
          </p>
        </div>

        <div className="p-4 bg-surface border border-border rounded-lg space-y-2">
          <h3 className="text-sm font-semibold tracking-tight text-foreground">
            6. Modifications & Inquiries
          </h3>
          <p>
            We may update these terms from time to time. Any changes will be posted directly to this URL.
            Questions regarding these terms may be sent to:
          </p>
          <p className="font-bold text-foreground">
            terms@toolsbyus.com
          </p>
        </div>
      </div>

      <ReviewedStamp href="/terms" />
    </div>
  );
}
