import type { Metadata } from "next";
import Link from "next/link";
import { HubShell } from "@/components/tools/HubShell";
import { buildToolMetadata } from "@/lib/metadata";
import { categoryOf } from "@/lib/tools";

const CATEGORY = categoryOf("text")!;
const LAST_REVIEWED = "2026-09-11";

export const metadata: Metadata = buildToolMetadata({
  path: CATEGORY.hub,
  title: "Text Tools — Diff, Format and Convert Text",
  socialTitle: "Text Tools",
  description:
    "Compare two blocks of text line by line, word by word or character by character, and export a unified patch — all in your browser, with nothing uploaded.",
});

export default function TextToolsPage() {
  return (
    <HubShell
      category={CATEGORY}
      lastReviewed={LAST_REVIEWED}
      directAnswer="These text tools compare and reshape plain text in your browser. Paste two versions of a file, a log excerpt or a config block and see exactly what changed, at line, word or character granularity, with a unified patch you can copy into an email or a ticket."
      faqs={[
        {
          question: "What is the difference between line, word and character diff?",
          answer:
            "Line diff is the default and matches what git shows: a line is either present, absent or changed. Word diff subdivides each changed line so you can see that only one identifier moved, rather than a whole 200-character line lighting up red and green. Character diff goes further and is the right choice for a single long string — a URL, a hash, a base64 blob — where the difference is one character in the middle and you need to find it.",
        },
        {
          question: "Can I paste a whole file, or does it have to be an excerpt?",
          answer:
            "Whole files are fine up to the 8 MB main-thread ceiling. The comparison is a Myers diff, which is the same algorithm git uses, so its cost grows with the number of differences rather than the size of the input — two large files that are nearly identical compare almost instantly, while two that share nothing take longer.",
        },
        {
          question: "Is the unified patch the same format as git produces?",
          answer:
            "Yes. The export is a standard unified diff with @@ hunk headers, so it applies with patch(1) and pastes into a code-review comment or a pull-request description without reformatting. The context depth is three lines, the conventional default.",
        },
        {
          question: "Does it handle Windows line endings?",
          answer:
            "It normalises CRLF to LF before comparing, so a file that has been through a Windows editor does not report every single line as changed. If the line endings themselves are what you are investigating, that normalisation is the wrong behaviour — compare the raw bytes with a hex-aware tool instead.",
        },
        {
          question: "Is my text sent anywhere?",
          answer:
            "No. The comparison runs in your browser. There is no upload step and no API route; the page is a static file and the diff algorithm is JavaScript executing in the tab you already have open. Open the Network panel and paste a document — nothing carrying your text appears.",
        },
      ]}
      intro={
        <>
          <p>
            Comparing two blocks of text is a thing people do constantly and almost always at a bad
            moment: a config that works on one host and not another, a response body that changed
            between deploys, a contract clause someone edited without tracking changes, a log line
            that is nearly but not quite the one from yesterday.
          </p>
          <p>
            The temptation is to eyeball it. That works for three lines and fails silently for
            thirty, because human attention is extremely good at seeing what it expects. A diff is
            not a convenience in that situation; it is the difference between finding the change and
            convincing yourself there isn&rsquo;t one.
          </p>
          <p>
            What makes a diff tool good is granularity. Line-level comparison is the right default
            and is what version control shows you, but it is actively misleading on two classes of
            input: minified or single-line files, where the entire document is one line and the diff
            degenerates into &ldquo;this line changed&rdquo;; and long prose lines, where a
            one-word edit paints a whole paragraph as rewritten. Word and character modes exist
            precisely for those cases, and being able to switch between the three without re-pasting
            is most of the value.
          </p>
          <p>
            The other half is that the output has to be portable. A diff you can only look at is
            worth less than one you can hand to somebody else, so the unified-patch export produces
            a standard patch with proper hunk headers — the format <code>patch(1)</code> accepts and
            the format a code-review tool renders correctly when you paste it into a comment.
          </p>
          <p>
            Text is often the most sensitive thing on this site. A JSON payload is usually machine
            data; a text diff is frequently a draft contract, an internal memo, an incident
            timeline or a customer email. That is the reason the comparison happens in your browser
            rather than on a server: not as a feature, but because uploading that material to an
            unknown host to answer a question you could answer locally is a bad trade at any price.
          </p>
          <p>
            If the two things you are comparing are JSON rather than prose, use{" "}
            <Link href="/json-diff">JSON Diff</Link> instead. It compares the parsed structure
            rather than the text, so reformatting and key reordering — which a text diff reports as
            hundreds of changes — correctly show as no change at all.
          </p>
        </>
      }
    />
  );
}
