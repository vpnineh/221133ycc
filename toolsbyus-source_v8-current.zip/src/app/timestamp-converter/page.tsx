import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { TimestampConverterClient } from "./TimestampConverterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/timestamp-converter",
  title: "Timestamp Converter — Unix Epoch to Date",
  socialTitle: "Timestamp Converter",
  description:
    "Convert Unix timestamps, ISO 8601 and human dates in your browser. The unit is detected from magnitude and reported, so a millisecond value is never read as seconds.",
});

export default function TimestampConverterPage() {
  return <TimestampConverterClient />;
}
