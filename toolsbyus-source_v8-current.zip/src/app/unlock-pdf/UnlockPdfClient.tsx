"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { FileDropZone } from "../../components/tools/FileDropZone";
import { FileResult } from "../../components/tools/FileResult";
import { usePdfWorker } from "../../components/tools/usePdfWorker";
import { Notice } from "../../components/common/Notice";
import { btnPrimary, field, fieldLabel } from "../../components/common/controls";
import type { AcceptedFile } from "../../lib/files";
import { stemOf, withStem } from "../../lib/files/naming";
import { OutputName } from "../../components/tools/OutputName";
import { relatedTools } from "../../lib/tools";

export const UnlockPdfClient: React.FC = () => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const [password, setPassword] = useState("");
  const [outputName, setOutputName] = useState("");
  const { state, run, reset } = usePdfWorker();

  const defaultStem = files[0] ? `${stemOf(files[0].file.name)}-unlocked` : "unlocked";

  const unlock = async () => {
    const file = files[0]?.file;
    if (!file) return;
    const buffer = await file.arrayBuffer();
    run(
      {
        type: "unlock",
        file: buffer,
        password,
        name: withStem(outputName.trim() || defaultStem, "pdf"),
      },
      [buffer]
    );
  };

  return (
    <ToolShell
      slug="unlock-pdf"
      keyword="Unlock PDF"
      directAnswer="Unlock PDF removes restrictions from a document you can already open, in your browser. It does not crack passwords and never will: a PDF with a user password is genuinely encrypted, and a site claiming to remove one without it is either uploading your file to a cracking service or simply lying about what it did."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Unlock PDF", url: "/unlock-pdf" },
      ]}
      seoDescription="Remove permission restrictions from a PDF in your browser. Handles owner-password documents and user-password documents where you supply the password. No cracking, no upload."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              PDF has two different passwords, and almost every confusing thing about locked
              documents comes from them being called the same word.
            </p>
            <h3>The owner password restricts; the user password encrypts</h3>
            <p>
              An <strong>owner password</strong> sets permissions: no printing, no copying text, no
              editing. The document itself is not protected by it — the content is readable, and the
              restrictions are flags that conforming readers agree to honour. It is a politeness
              convention with a password attached. Removing it is a matter of writing the document
              back without the permissions dictionary, which is what this tool does.
            </p>
            <p>
              A <strong>user password</strong> is real encryption. The content streams are encrypted
              with a key derived from the password, and without it there is nothing to read — not by
              this tool, not by any tool, not by the person who wrote the specification. If you have
              the password, type it in and the document is decrypted and written back unencrypted.
              If you do not, nothing here helps, and neither does anything else that runs in a
              reasonable amount of time.
            </p>
            <h3>Why there is no cracking feature</h3>
            <p>
              Because the sites offering one are doing something else. Breaking a modern PDF&apos;s
              AES-256 encryption by brute force is not a thing a web page does; what those services
              do is upload your document to a server farm and try a dictionary. So you have handed a
              complete copy of a document you considered worth encrypting to a stranger, in exchange
              for a decent chance that the password was &ldquo;Password1&rdquo;.
            </p>
            <p>
              That is a bad trade for you and an excellent one for them, and it is the reason this
              tool does not have that button. If a document is locked and the password is genuinely
              lost, the answer is the person who created it.
            </p>
            <h3>What &ldquo;unlocked&rdquo; means here</h3>
            <p>
              The output is written without an encryption dictionary and without a permissions entry
              — so it prints, copies and edits like any ordinary PDF. The page content is unchanged:
              nothing is re-rendered, text stays selectable, and the file size is close to the
              original.
            </p>
            <h3>The obvious legal point</h3>
            <p>
              Removing restrictions from a document you own or are licensed to use is ordinary
              file handling. Doing it to someone else&apos;s document to get around a restriction
              they set deliberately is a different matter, in most places a legal one. The tool
              cannot tell the difference; you can.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `statement.pdf
owner password set: no copying, no printing`,
        outputTitle: "Output",
        exampleOutput: `unlocked.pdf
no encryption dictionary,
no permissions entry,
page content byte-identical`,
      }}
      referenceTable={{
        title: "What is and is not possible",
        rows: [
          {
            parameter: "Owner password",
            type: "restrictions",
            defaultVal: "removed",
            description:
              "Permission flags — no print, no copy, no edit — that conforming readers honour by convention. The content was never protected by them.",
          },
          {
            parameter: "User password",
            type: "encryption",
            defaultVal: "needs the password",
            description:
              "Real encryption of the content streams. Type the password and the document is decrypted; without it there is nothing any tool can do.",
          },
          {
            parameter: "Password cracking",
            type: "not implemented",
            defaultVal: "never",
            description:
              "Brute-forcing AES-256 is not something a web page does. Sites offering it upload your document to a server and run a dictionary attack.",
          },
          {
            parameter: "Page content",
            type: "unchanged",
            defaultVal: "—",
            description:
              "Nothing is re-rendered. Text stays selectable, images keep their resolution, and the file size is close to the original.",
          },
          {
            parameter: "Output encryption",
            type: "none",
            defaultVal: "—",
            description:
              "The result is written without an encryption dictionary, so it opens without a password anywhere.",
          },
          {
            parameter: "Digital signatures",
            type: "invalidated",
            defaultVal: "—",
            description:
              "Rewriting the document breaks any signature over it, which is what a signature is for. That is correct behaviour rather than a limitation.",
          },
          {
            parameter: "Upload",
            type: "never",
            defaultVal: "enforced by CSP",
            description:
              "Especially relevant here: a document worth encrypting is a document worth not uploading.",
          },
        ],
      }}
      faqs={[
        {
          question: "Can you remove a password I do not know?",
          answer:
            "No, and neither can anyone else in a browser. A PDF with a user password encrypts its content with a key derived from that password; without it there is nothing to read. Sites that claim to do this upload your file and run a dictionary attack on a server — so you have given a stranger a complete copy of a document you thought worth encrypting, in exchange for a chance that the password was guessable. If the password is genuinely lost, the person who created the document is the answer.",
        },
        {
          question: "Why did my PDF open fine but refuse to let me print it?",
          answer:
            "That is an owner password. It sets permission flags — no printing, no copying, no editing — that PDF readers agree to honour as a convention. The content was never encrypted; your reader is simply declining to do things on the document's behalf. This tool writes the document back without those flags.",
        },
        {
          question: "Is removing restrictions legal?",
          answer:
            "For a document you own or are licensed to use, it is ordinary file handling — the same as removing read-only from a file you created. Removing restrictions from someone else's document to get around a limit they set deliberately is a different question, and in many jurisdictions a legal one. The tool cannot tell which situation you are in; you can.",
        },
        {
          question: "Will unlocking change the document?",
          answer:
            "Only its encryption and permissions. Page content is not re-rendered — text stays selectable, images keep their resolution, and the file size stays close to the original. What does change is any digital signature: rewriting the document invalidates it, which is precisely what a signature exists to detect and is correct behaviour rather than a bug.",
        },
        {
          question: "Why not just print to PDF to remove restrictions?",
          answer:
            "You can, and it works, at a cost. Printing to PDF rasterises or re-renders the page, so you lose selectable text, searchability, any accessibility structure, and often a good deal of quality — and the file usually gets several times larger. This keeps the original page objects intact and simply writes them without the encryption wrapper.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No, and this page is the one where that matters most. A document with a password on it is by definition something someone decided was sensitive. It is decrypted in this tab, and the page's Content-Security-Policy sets connect-src 'self', so the browser itself would block any attempt to send it anywhere.",
        },
      ]}
      relatedTools={relatedTools("/unlock-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <Notice tone="info">
          This removes restrictions from a document you can already open, and decrypts one you have
          the password for. It does not crack passwords — a PDF with a user password is genuinely
          encrypted, and any site claiming to open one without the password is uploading your file
          to try guessing it.
        </Notice>

        <FileDropZone
          accept={[".pdf", "application/pdf"]}
          files={files}
          onChange={(next) => {
            setFiles(next);
            reset();
          }}
          label="Drop a restricted PDF here"
          disabled={state.status === "running"}
        />

        {files.length === 1 && state.status !== "running" && (
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
            <div className="flex flex-1 items-center gap-2">
              <label htmlFor="unlock-password" className={fieldLabel}>
                Password
              </label>
              <input
                id="unlock-password"
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="leave empty for a restrictions-only document"
                // Never remembered: a password typed here exists for the
                // duration of one operation and nowhere else.
                autoComplete="off"
                className={`${field} min-w-[12rem] flex-1`}
              />
            </div>
            <button type="button" onClick={() => void unlock()} className={btnPrimary}>
              Unlock
            </button>
          </div>
        )}

        {files.length > 0 && (
          <OutputName
            defaultStem={defaultStem}
            extension="pdf"
            value={outputName}
            onChange={setOutputName}
          />
        )}

        <FileResult state={state} />
      </div>
    </ToolShell>
  );
};
