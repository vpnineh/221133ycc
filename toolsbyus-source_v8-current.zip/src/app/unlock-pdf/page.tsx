import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { UnlockPdfClient } from "./UnlockPdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/unlock-pdf",
  title: "Unlock PDF — Remove Owner Restrictions",
  socialTitle: "Unlock PDF",
  description:
    "Remove restrictions from a PDF you have the password for, in your browser. No password cracking — any site offering it is uploading your file.",
});

export default function UnlockPdfPage() {
  return <UnlockPdfClient />;
}
