import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { UrlEncodeDecodeClient } from "./UrlEncodeDecodeClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/url-encode-decode",
  title: "URL Encoder and Decoder — Component or Full URL",
  socialTitle: "URL Encoder",
  description:
    "Percent-encode and decode in your browser, with the form-encoding difference explicit: a space is + in a query string and %20 in a path.",
});

export default function UrlEncodeDecodePage() {
  return <UrlEncodeDecodeClient />;
}
