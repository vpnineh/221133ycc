import React from "react";
import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import {
  absoluteUrl,
  SITE_NAME,
  CONTENT_FIRST_PUBLISHED,
  CONTENT_LAST_REVIEWED,
} from "../../lib/site";
import FaqSection from "@/components/common/FaqSection";
import SchemaJsonLd from "@/components/common/SchemaJsonLd";
import { ToolPageFrame } from "@/components/tools/ToolPageFrame";
import ReviewedStamp from "@/components/common/ReviewedStamp";
import UuidClient from "./UuidClient";
import Link from "next/link";

export const metadata: Metadata = buildToolMetadata({
  path: "/uuid-generator",
  title: "UUID Generator — v1, v4 and v7, Bulk Export",
  socialTitle: "UUID Generator",
  description:
    "Generate cryptographically secure UUIDs. Bulk UUID v4, v7 (time-ordered), and v1 generation, plus version and variant inspection of existing UUIDs.",
});

const faqs = [
  {
    question: "Why is UUID v7 recommended over UUID v4 for database primary keys?",
    answer:
      "UUID v4 values are entirely random across all 122 entropy bits. When inserted as primary keys into clustered database indexes (such as PostgreSQL B-Trees or MySQL InnoDB clustered indexes), random keys force frequent page splits, catastrophic cache eviction, and random I/O write amplification. UUID v7 (RFC 9562) solves this by encoding a 48-bit Unix millisecond timestamp at the beginning of the identifier. This guarantees chronological monotonicity, allowing new rows to append sequentially to the rightmost index pages like an auto-incrementing integer, while retaining global uniqueness across distributed nodes without coordination.",
  },
  {
    question: "What is the mathematical collision probability of UUID v4?",
    answer:
      "A standard UUID v4 contains 122 bits of pseudo-random entropy (6 bits are reserved for version and variant). The probability of at least one collision among n generated UUIDs is approximated by the birthday problem formula: p ≈ 1 - exp(-n² / (2 × 2¹²²)). To achieve even a one-in-a-billion (10⁻⁹) probability of a single collision, a system would need to generate over 103 trillion UUIDs. Generating one billion UUIDs per second for 100 years would still yield a negligible collision likelihood.",
  },
  {
    question: "How are UUIDs generated securely without contacting a server?",
    answer:
      "All UUIDs are generated locally in your browser using the Web Cryptography API (crypto.randomUUID and crypto.getRandomValues). These native browser APIs interface directly with your operating system's kernel cryptographic entropy pool (such as /dev/urandom on Linux and macOS, or CryptGenRandom / BCryptGenRandom on Windows). No data is ever transmitted across any network.",
  },
  {
    question: "Why was UUID v1 superseded, and how is its timestamp encoded?",
    answer:
      "UUID v1 encoded a 60-bit count of 100-nanosecond intervals since the start of the Gregorian calendar reform on October 15, 1582. However, its last 48 bits were originally designed to embed the physical MAC address of the network interface card. This posed serious privacy and security risks by leaking hardware identifiers and machine locations into public URLs and databases. UUID v7 obsoleted v1 by replacing the complex Gregorian offset with clean Unix Epoch milliseconds and replacing MAC addresses with secure random bits.",
  },
  {
    question: "Can I generate thousands of UUIDs at once for seed data?",
    answer:
      "Yes. The bulk generator supports generating up to 5,000 UUIDs per batch in a split second. You can customize casing, hyphenation, quotation marks, curly braces, and output delimiter formats including newline, comma-separated lists, and valid JSON arrays.",
  },
];

export default function UuidPage() {
  const jsonLdData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "@id": `${absoluteUrl("/uuid-generator")}#webpage`,
      url: absoluteUrl("/uuid-generator"),
      name: "UUID Generator",
      inLanguage: "en",
      datePublished: CONTENT_FIRST_PUBLISHED,
      dateModified: CONTENT_LAST_REVIEWED,
      author: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
      publisher: { "@type": "Organization", name: SITE_NAME, url: absoluteUrl("/") },
    },
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      name: "UUID Generator",
      url: absoluteUrl("/uuid-generator"),
      description:
        "Generate cryptographically secure UUID v4, time-ordered UUID v7, and UUID v1 bulk identifiers directly in the browser.",
      applicationCategory: "DeveloperApplication",
      operatingSystem: "Any",
      browserRequirements: "Requires a modern browser with JavaScript enabled",
      // These three pages predate ToolShell and build their own graph, so they
      // were the only tools on the site not declaring that they are free — the
      // signal an aggregator or an AI answer reads to say "no sign-up".
      isAccessibleForFree: true,
      offers: {
        "@type": "Offer",
        price: "0",
        priceCurrency: "USD",
        availability: "https://schema.org/InStock",
      },
      featureList: [
        "UUID v4 from a cryptographic RNG",
        "Time-ordered UUID v7 (RFC 9562)",
        "UUID v1 with a random node identifier",
        "Version and variant inspection",
        "Bulk generation and export",
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: absoluteUrl("/"),
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "UUID Generator",
          item: absoluteUrl("/uuid-generator"),
        },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({
        "@type": "Question",
        name: f.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: f.answer,
        },
      })),
    },
  ];

  return (
    <>
      <SchemaJsonLd schemas={jsonLdData} />

      <ToolPageFrame
        keyword="UUID Generator"
        category="generate"
        breadcrumbs={[
          { label: "UUID Generator", href: "/uuid-generator" },
        ]}
        directAnswer={
          <>
            UUID Generator produces cryptographically random v4, time-ordered v7 and Gregorian-timestamp v1 identifiers in bulk, using the browser&apos;s own crypto API. It also inspects an existing UUID to report its version, variant and embedded timestamp. No identifier is ever sent anywhere.
          </>
        }
        tool={<UuidClient />}
      >


      {/* Technical Documentation (>= 700 words) */}
      <section className="space-y-5">
        <h2 className="heading-hash">
          What is a UUID, and how do v1, v4 and v7 differ?
        </h2>

        <p className="text-sm text-foreground-muted leading-relaxed">
          Universally Unique Identifiers (UUIDs), also standardized by the Open Software Foundation (OSF)
          and ISO/IEC 9834-8:2005 as Globally Unique Identifiers (GUIDs), are 128-bit numerical labels
          engineered to enable distributed software architectures to generate primary keys and entity
          references without requiring synchronization through a centralized registry or database authority.
          For nearly two decades, the fundamental standard governing UUID generation was <strong>RFC 4122</strong>,
          published in July 2005. In May 2024, the Internet Engineering Task Force (IETF) published <strong>RFC 9562</strong>,
          a major overhaul that obsoleted RFC 4122 and officially introduced time-ordered UUID versions
          tailored to modern high-throughput databases and distributed streaming pipelines.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          Binary Anatomy and Layout of a 128-Bit UUID
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Regardless of the version, every canonical UUID is represented in textual form as 32 hexadecimal
          digits displayed in five hyphen-separated groups with the format <code>8-4-4-4-12</code>,
          totaling 36 characters (including the 4 hyphens):
        </p>
        <div className="bg-surface p-4 rounded-lg border border-border font-mono text-xs overflow-x-auto space-y-1">
          <p className="text-foreground font-bold">xxxxxxxx-xxxx-Mxxx-Nxxx-xxxxxxxxxxxx</p>
          <p className="text-foreground-muted">├───────┼────┼────┼────┼────────────┤</p>
          <p className="text-foreground-muted">time_low time_mid time_hi clock_seq node</p>
          <p className="text-accent font-bold mt-2">
            M = 4-bit Version Indicator (0x1 = v1, 0x4 = v4, 0x7 = v7)
          </p>
          <p className="text-accent font-bold">
            N = Variant field (Bits 10xx correspond to RFC 4122 / RFC 9562; characters 8, 9, a, or b)
          </p>
        </div>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          UUID Version 4: Pure Cryptographic Entropy
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          UUID v4 is completely pseudo-random. Out of the 128 bits comprising the identifier, 4 bits are
          reserved to encode the version (<code>0b0100</code>) and 2 bits are reserved to encode the variant
          (<code>0b10</code>). This leaves exactly <strong>122 bits</strong> of cryptographically secure
          entropy.
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed">
          The total number of possible UUID v4 identifiers is \(2^{122} \approx 5.3 \times 10^{36}\).
          To comprehend the astronomical magnitude of this space, consider that if every human on Earth
          generated one billion UUIDs every second for the next century, the likelihood of a single duplicate
          occurring remains under one in a billion. However, this total randomness comes at a steep architectural
          cost when utilized as primary keys within persistent storage engines.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          The Database Indexing Crisis and the Rise of UUID v7 (RFC 9562)
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          Relational databases (such as PostgreSQL, MySQL, and SQLite) and document stores organize primary
          keys in <strong>B-Tree (Balanced Tree)</strong> or LSM-Tree index structures. In a B-Tree, keys are
          stored in sorted, sequential order across fixed-size disk pages (typically 8 KB or 16 KB). When
          consecutive inserts have sequential or monotonic keys (such as standard auto-incrementing integers),
          each new insert appends cleanly to the right-hand leaf node. The index pages remain fully saturated,
          cache lines stay hot, and disk write amplification is minimal.
        </p>
        <p className="text-sm text-foreground-muted leading-relaxed">
          When UUID v4 is used as a primary key, each generated value lands at a completely random location
          in the B-tree keyspace. As the index grows beyond RAM capacity:
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-1">
          <li>Every single insert requires reading a random 8 KB index page from disk into the buffer cache.</li>
          <li>Existing index pages become full and undergo costly <strong>page splits</strong>, creating 50% empty space and fragmenting disk storage.</li>
          <li>Database cache hit ratios plummet from &gt;99% to &lt;20%, bottlenecking transactional throughput (IOPS).</li>
        </ul>
        <p className="text-sm text-foreground-muted leading-relaxed">
          <strong>UUID v7</strong> directly resolves this dilemma. It structures the 128 bits into three deliberate tiers:
        </p>
        <ol className="list-decimal list-inside text-sm text-foreground-muted space-y-2">
          <li>
            <strong>48-Bit Unix Epoch Timestamp:</strong> The most significant 48 bits encode the current Unix
            timestamp in milliseconds. This timestamp will not overflow until the year 10889 AD.
          </li>
          <li>
            <strong>12-Bit Sub-millisecond / Sequence Counter:</strong> Provides sub-millisecond precision or
            monotonic sequence incrementation, guaranteeing strict chronological sorting even when thousands
            of records are generated in the same millisecond on the same thread.
          </li>
          <li>
            <strong>62-Bit Cryptographic Entropy:</strong> Provides 62 bits of CSPRNG randomness, guaranteeing
            absolute collision immunity across globally distributed clusters.
          </li>
        </ol>
        <p className="text-sm text-foreground-muted leading-relaxed">
          With UUID v7, database systems achieve the best of both paradigms: sequential B-tree append performance
          matching 64-bit integers, combined with the distributed generation capability and security of UUIDs.
        </p>

        <h3 className="text-lg font-semibold tracking-tight text-foreground">
          UUID Version 1: The Legacy Gregorian Standard
        </h3>
        <p className="text-sm text-foreground-muted leading-relaxed">
          UUID v1 was the original time-based UUID defined in RFC 4122. It encoded a 60-bit timestamp counting
          100-nanosecond intervals since October 15, 1582 (the date the Gregorian calendar was instituted by
          Pope Gregory XIII). However, v1 suffered from two significant design liabilities:
        </p>
        <ul className="list-disc list-inside text-sm text-foreground-muted space-y-1">
          <li>
            <strong>End-endianness and Field Inversion:</strong> The least significant 32 bits of the timestamp
            (<code>time_low</code>) were placed at the very beginning of the UUID string. Consequently, consecutive
            v1 UUIDs did not sort chronologically without byte reordering (which later motivated the experimental
            UUID v6).
          </li>
          <li>
            <strong>Hardware MAC Leakage:</strong> The final 48 bits embedded the physical IEEE 802 MAC address
            of the host machine. This allowed adversaries to reconstruct the identity and physical location
            of the server that authored the UUID, creating severe information disclosure vulnerabilities.
          </li>
        </ul>
        <p className="text-sm text-foreground-muted leading-relaxed">
          RFC 9562 formally recommends that new designs adopt UUID v7 in place of UUID v1.
        </p>
      </section>

      {/* Keyboard Shortcuts Reference */}
      <section className="rounded-xl bg-surface p-6 space-y-4">
        <h2 className="heading-hash">
          Which keyboard shortcuts does the UUID generator support?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Ctrl + Enter / Cmd + Enter</span>
            <span className="text-foreground-muted">Instantly generate a fresh batch of UUIDs</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Tab / Shift+Tab</span>
            <span className="text-foreground-muted">Cycle through version toggles, counts, and copy actions</span>
          </div>
          <div className="p-3 bg-surface-elevated rounded border border-border">
            <span className="font-semibold text-foreground block mb-1">Escape</span>
            <span className="text-foreground-muted">Clear inspector input and reset selection</span>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FaqSection faqs={faqs} />

      {/* Related Tools */}
      <section className="space-y-4">
        <h2 className="heading-hash">
          Which related tools should I use next?
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link
            href="/base64-decode"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              Base64 Decode & Encode &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Encode binary IDs, decode tokens, and inspect JWT headers and claims.
            </p>
          </Link>
          <Link
            href="/json-schema-generator"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Schema Generator &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Automatically detect UUID format strings and infer strict schema constraints.
            </p>
          </Link>
          <Link
            href="/json-editor"
            className="p-4 bg-surface rounded-lg border border-border hover:border-accent transition-colors group"
          >
            <h3 className="text-sm font-semibold tracking-tight text-foreground group-hover:text-accent">
              JSON Editor & Tree Viewer &rarr;
            </h3>
            <p className="text-xs text-foreground-muted mt-1 font-mono">
              Inspect database dumps and JSON payloads containing generated UUID keys.
            </p>
          </Link>
        </div>
      </section>

      <ReviewedStamp href="/uuid-generator" />
      </ToolPageFrame>
    </>
  );

}
