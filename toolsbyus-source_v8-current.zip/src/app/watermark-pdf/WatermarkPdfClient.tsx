"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { SinglePdfTool } from "../../components/tools/SinglePdfTool";
import { Notice } from "../../components/common/Notice";
import { btnCompact, field, fieldLabel } from "../../components/common/controls";
import { withStem } from "../../lib/files/naming";
import { relatedTools } from "../../lib/tools";

const PRESETS = ["CONFIDENTIAL", "DRAFT", "COPY", "SPECIMEN", "DO NOT COPY", "INTERNAL ONLY"];

export const WatermarkPdfClient: React.FC = () => {
  const [text, setText] = useState("CONFIDENTIAL");
  const [opacity, setOpacity] = useState(0.18);
  const [fontSize, setFontSize] = useState(52);
  const [rotation, setRotation] = useState(45);

  return (
    <ToolShell
      slug="watermark-pdf"
      keyword="Watermark PDF"
      directAnswer="Watermark PDF stamps text diagonally across every page in your browser. It is worth being clear about what that achieves: a watermark is a provenance mark and a deterrent, not a security control — the text sits on top of the page and anyone determined can remove it. What it does well is make an unauthorised copy obviously an unauthorised copy."
      breadcrumbs={[
        { name: "PDF Tools", url: "/pdf-tools" },
        { name: "Watermark PDF", url: "/watermark-pdf" },
      ]}
      seoDescription="Add a text watermark to every page of a PDF in your browser. Adjustable opacity, size and angle, drawn as real text rather than an image. Nothing is uploaded."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              A watermark is drawn as an extra text object on top of each page&apos;s existing
              content, using one of the fourteen fonts every PDF reader is required to have. That
              choice has consequences worth knowing.
            </p>
            <h3>Text, not an image</h3>
            <p>
              Stamping an image across every page is the common implementation and it multiplies the
              file size — a semi-transparent PNG large enough to cover an A4 page at print resolution
              is a few hundred kilobytes, and it is embedded once per page unless the tool is
              careful. Drawn as text with a standard font, a watermark costs a few dozen bytes per
              page and stays crisp at any zoom level.
            </p>
            <h3>What a watermark actually protects</h3>
            <p>
              Nothing, in the cryptographic sense. The text is a content object in the page; someone
              with a PDF editor can remove it in about a minute, and someone without one can
              screenshot the page. Any tool that implies otherwise is selling reassurance.
            </p>
            <p>
              What it does achieve is real and worth having. It marks provenance — a leaked document
              stamped &ldquo;CONFIDENTIAL — Legal, 12 September&rdquo; announces where it came from.
              It prevents honest mistakes, which is most of them: a draft that says DRAFT on every
              page does not get signed by accident, and a specimen does not get mistaken for the
              real certificate. And it raises the effort of casual copying enough to stop the casual
              copier, which is who you are mostly dealing with.
            </p>
            <p>
              If you need a document that genuinely cannot be redistributed, watermarking is the
              wrong layer. That is DRM, it requires a server the reader talks to, and it comes with
              all the problems that implies.
            </p>
            <h3>Centring rotated text</h3>
            <p>
              Text is drawn from its baseline start, not its centre, so placing a rotated string in
              the middle of a page means subtracting half its rotated extent from the centre point —
              half the width times the cosine of the angle horizontally, times the sine vertically.
              Skip that and the watermark sits noticeably low and left, which is the giveaway of a
              tool that did not think about it.
            </p>
            <h3>Opacity, and the one that is too dark</h3>
            <p>
              The default is 18%, which reads clearly against white and stays out of the way of the
              text underneath. Above about 30% a watermark starts competing with the content for
              attention and makes the document harder to read, which defeats the purpose of sending
              it. Below about 8% it disappears on a printed copy.
            </p>
          </>
        ),
        inputTitle: "Input",
        exampleInput: `contract.pdf (12 pages)
text: CONFIDENTIAL
45°, 18% opacity, 52 pt`,
        outputTitle: "Output",
        exampleOutput: `watermarked.pdf
one text object per page,
centred on the rotated extent`,
      }}
      referenceTable={{
        title: "Options",
        rows: [
          {
            parameter: "Text",
            type: "string",
            defaultVal: "CONFIDENTIAL",
            description:
              "Drawn in Helvetica Bold, one of the fourteen fonts every PDF reader has, so nothing is embedded and the file barely grows.",
          },
          {
            parameter: "Opacity",
            type: "0.05 – 0.6",
            defaultVal: "0.18",
            description:
              "Above roughly 0.3 the watermark competes with the content. Below 0.08 it disappears when printed.",
          },
          {
            parameter: "Size",
            type: "points",
            defaultVal: "52",
            description:
              "A point is 1/72 inch. At 52 pt a one-word mark spans most of an A4 page diagonally.",
          },
          {
            parameter: "Angle",
            type: "degrees",
            defaultVal: "45",
            description:
              "Anticlockwise from horizontal. 45° is conventional because it crosses the most text; 0° puts it along a line, which reads as part of the document.",
          },
          {
            parameter: "Pages",
            type: "all",
            defaultVal: "—",
            description:
              "Every page, because a watermark on some pages is worse than none: it implies the unmarked pages are not covered.",
          },
          {
            parameter: "Placement",
            type: "centred",
            defaultVal: "—",
            description:
              "Centred on the rotated extent of the text rather than its baseline origin, which is what stops it sitting low and left.",
          },
          {
            parameter: "File size",
            type: "negligible",
            defaultVal: "—",
            description:
              "A few dozen bytes per page. An image watermark would add hundreds of kilobytes and blur when zoomed.",
          },
          {
            parameter: "Security",
            type: "none",
            defaultVal: "—",
            description:
              "The text is a removable content object. This is a provenance mark and a deterrent, not a control.",
          },
        ],
      }}
      faqs={[
        {
          question: "Can someone remove the watermark?",
          answer:
            "Yes, with a PDF editor, in about a minute. It is a content object drawn on top of the page, not an encoding of the page. Any tool that implies its watermark cannot be removed is selling you reassurance rather than a mechanism. What a watermark genuinely does is mark provenance, prevent honest mistakes, and raise the effort enough to stop casual copying — which is most copying.",
        },
        {
          question: "Then what is it actually for?",
          answer:
            "Three things that matter. Provenance: a leaked document stamped with a department and a date announces where it came from, which changes behaviour more than a lock would. Mistake prevention: a draft that says DRAFT on every page does not get signed by accident, and a specimen certificate does not get filed as a real one. And deterrence of the casual: most unauthorised sharing is thoughtless rather than determined, and a visible mark makes it feel deliberate.",
        },
        {
          question: "Will it make my file much bigger?",
          answer:
            "No — a few dozen bytes per page. The text is drawn using Helvetica Bold, one of the fourteen fonts every PDF reader is required to have, so nothing is embedded. Tools that stamp an image instead can add hundreds of kilobytes, and the image blurs when someone zooms in, which a text watermark never does.",
        },
        {
          question: "What opacity should I use?",
          answer:
            "Somewhere around 0.15 to 0.25 for a document meant to be read. Higher and the watermark competes with the content, which makes the document harder to use and encourages the recipient to go looking for an unmarked copy. Lower than about 0.08 and it vanishes when printed, particularly on an office laser printer, which is exactly when you wanted it visible.",
        },
        {
          question: "Can I watermark only some pages?",
          answer:
            "Not here, and that is deliberate. A watermark on some pages is worse than none: it implies the unmarked pages are not covered by whatever the mark asserts. If you genuinely need it on a subset, split the document, watermark the part, and merge it back — which makes the decision explicit rather than accidental.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. The watermark is drawn in this tab and the file is saved locally. This matters particularly here, because a document you are about to stamp CONFIDENTIAL is by definition one you should not be uploading to a stranger's server to have the word added.",
        },
      ]}
      relatedTools={relatedTools("/watermark-pdf").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <SinglePdfTool
        runLabel={(info) => `Stamp ${info.pageCount} page${info.pageCount === 1 ? "" : "s"}`}
        controls={() => (
          <div className="space-y-3">
            <div className="flex flex-wrap items-end gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
              <div className="flex flex-1 items-center gap-2">
                <label htmlFor="wm-text" className={fieldLabel}>
                  Text
                </label>
                <input
                  id="wm-text"
                  type="text"
                  value={text}
                  onChange={(event) => setText(event.target.value)}
                  spellCheck={false}
                  className={`${field} min-w-[10rem] flex-1`}
                />
              </div>

              <div className="flex items-center gap-2">
                <label htmlFor="wm-opacity" className={fieldLabel}>
                  Opacity
                </label>
                <input
                  id="wm-opacity"
                  type="range"
                  min={5}
                  max={60}
                  value={Math.round(opacity * 100)}
                  onChange={(event) => setOpacity(Number(event.target.value) / 100)}
                  className="w-28 accent-accent-solid"
                />
                <span className="w-10 font-mono text-2xs text-foreground-subtle">
                  {Math.round(opacity * 100)}%
                </span>
              </div>

              <div className="flex items-center gap-2">
                <label htmlFor="wm-size" className={fieldLabel}>
                  Size
                </label>
                <input
                  id="wm-size"
                  type="number"
                  min={8}
                  max={200}
                  value={fontSize}
                  onChange={(event) => setFontSize(Math.max(8, Number(event.target.value) || 52))}
                  className={`${field} w-20`}
                />
              </div>

              <div className="flex items-center gap-2">
                <label htmlFor="wm-angle" className={fieldLabel}>
                  Angle
                </label>
                <input
                  id="wm-angle"
                  type="number"
                  min={-90}
                  max={90}
                  value={rotation}
                  onChange={(event) => setRotation(Number(event.target.value) || 0)}
                  className={`${field} w-20`}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setText(preset)}
                  className={btnCompact}
                >
                  {preset}
                </button>
              ))}
            </div>

            {opacity > 0.35 && (
              <Notice tone="info">
                At {Math.round(opacity * 100)}% the watermark competes with the text underneath.
                That makes the document harder to read, which is a reason for the recipient to go
                looking for an unmarked copy.
              </Notice>
            )}
          </div>
        )}
        naming={{ mode: "single", defaultStem: (stem) => `${stem}-watermarked` }}
        operation={async (info, file, stem) => {
          if (!text.trim()) return { blocked: "Enter some watermark text." };
          return {
            type: "watermark",
            file: await file.arrayBuffer(),
            name: withStem(stem, "pdf"),
            text: text.trim(),
            opacity,
            fontSize,
            rotation,
            // A neutral grey rather than red: at low opacity a coloured
            // watermark tints the page and fights with any colour in the
            // content, while grey simply darkens it evenly.
            colour: [0.45, 0.45, 0.45],
          };
        }}
      />
    </ToolShell>
  );
};
