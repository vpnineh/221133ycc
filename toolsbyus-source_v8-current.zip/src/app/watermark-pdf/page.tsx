import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { WatermarkPdfClient } from "./WatermarkPdfClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/watermark-pdf",
  title: "Watermark PDF — Add Text Over Every Page",
  socialTitle: "Watermark PDF",
  description:
    "Stamp text across every page of a PDF in your browser. Honest about what a watermark is: a deterrent and a provenance mark, not a security control.",
});

export default function WatermarkPdfPage() {
  return <WatermarkPdfClient />;
}
