"use client";

import React, { useCallback, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, field, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { formatXml, minifyXml, type XmlFormatOptions } from "../../lib/xml";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<!-- Exported by the billing service --><invoices xmlns:c="urn:acme:customer"><invoice id="INV-2041" status="paid"><c:customer ref="acme-eu"><c:name>Ada Lovelace</c:name><c:email>ada@example.com</c:email></c:customer><lines><line sku="WID-1" qty="2" unit="24.00"/><line sku="WID-9" qty="1" unit="100.50"/></lines><notes><![CDATA[ Deliver after  17:00 <urgent> ]]></notes><total currency="GBP">148.50</total></invoice></invoices>`;

export const XmlFormatterClient: React.FC = () => {
  const [mode, setMode] = useState<"format" | "minify">("format");
  const [options, setOptions] = useState<XmlFormatOptions>({
    indent: 2,
    stripComments: false,
    collapseWhitespace: true,
    attributeWrapThreshold: 0,
  });

  const transform = useCallback(
    (input: string): TransformOutcome => {
      if (mode === "minify") {
        const result = minifyXml(input);
        if (!result.ok) {
          return {
            output: "",
            error: `Line ${result.error.line}, column ${result.error.column}: ${result.error.message}`,
          };
        }
        return {
          output: result.value,
          stats: [
            { label: "In", value: `${new Blob([input]).size} B` },
            { label: "Out", value: `${new Blob([result.value]).size} B` },
            {
              label: "Saved",
              value: `${Math.max(
                0,
                Math.round((1 - new Blob([result.value]).size / Math.max(1, new Blob([input]).size)) * 100)
              )}%`,
            },
          ],
        };
      }

      const result = formatXml(input, options);
      if (!result.ok) {
        return {
          output: "",
          error: result.error.line
            ? `Line ${result.error.line}, column ${result.error.column}: ${result.error.message}`
            : result.error.message,
        };
      }
      return {
        output: result.value.formatted,
        stats: [
          { label: "Elements", value: String(result.value.elementCount) },
          { label: "Max depth", value: String(result.value.maxDepth) },
          { label: "Lines", value: String(result.value.formatted.split("\n").length) },
          { label: "Bytes", value: String(new Blob([result.value.formatted]).size) },
        ],
      };
    },
    [mode, options]
  );

  return (
    <ToolShell
      wide
      slug="xml-formatter"
      keyword="XML Formatter"
      directAnswer="XML Formatter re-indents an XML document in your browser using a single-pass tokenizer, so comments, CDATA sections, DOCTYPE subsets and attribute values containing angle brackets all survive intact. It reports mismatched or unclosed tags with a line and column rather than silently reshaping the tree."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "XML Formatter", url: "/xml-formatter" },
      ]}
      seoDescription="Format and beautify XML in your browser. Single-pass tokenizer keeps CDATA, comments and DOCTYPE subsets intact, reports mismatched tags with a position, and never uploads your document."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Most XML formatters are a series of regular expressions: strip the comments, then
              split on tags, then re-indent. That ordering cannot be made correct, because the
              passes depend on each other in a circle. Deciding whether{" "}
              <code>&lt;!--</code> opens a comment requires knowing whether you are inside a CDATA
              section. Deciding where a CDATA section starts requires knowing you are not inside a
              comment. Deciding whether <code>&gt;</code> ends a tag requires knowing whether you
              are inside an attribute value. Whichever order you choose, one of the three is wrong,
              and the failure is silent corruption rather than an error.
            </p>
            <p>
              So this formatter scans the document exactly once into a token stream — declaration,
              processing instruction, DOCTYPE, comment, CDATA, open tag, close tag, self-closing
              tag, text — and everything after that is a fold over those tokens. The tokenizer is
              lossless by construction: every byte of the input lands in exactly one token, and
              there is a test asserting that concatenating them reproduces the original document
              byte for byte.
            </p>
            <p>
              That design is what makes the awkward cases work rather than being special-cased. A
              DOCTYPE with an internal subset may contain <code>&gt;</code> inside it, so the scan
              tracks bracket depth instead of taking the first closing angle. An attribute value may
              contain <code>&gt;</code>, so tag scanning tracks quotes. A bare{" "}
              <code>&lt;</code> that is not the start of a tag — invalid XML, ubiquitous in
              hand-written files — is carried through as text rather than aborting a format the
              author can see should succeed.
            </p>
            <p>
              Indentation keeps one deliberate exception: an element whose only child is text stays
              on one line, so you get <code>&lt;name&gt;Ada&lt;/name&gt;</code> rather than three
              lines for two words. Exploding every leaf is the main reason machine-formatted XML is
              harder to read than the hand-written kind.
            </p>
            <p>
              When the tree does not close properly, the formatter stops and says where. A
              mismatched <code>&lt;/c&gt;</code> where <code>&lt;/b&gt;</code> was expected is
              reported with its line and column; a document that ends mid-tree names the elements
              still open. The alternative — quietly closing the tags for you — produces a document
              that looks right and is not the one you had, which is the worst outcome available.
            </p>
          </>
        ),
        inputTitle: "Minified in",
        exampleInput: `<r><a id="1"><b>x</b></a><!-- c --><d/></r>`,
        outputTitle: "Formatted out",
        exampleOutput: `<r>
  <a id="1">
    <b>x</b>
  </a>
  <!-- c -->
  <d />
</r>`,
      }}
      referenceTable={{
        title: "Formatting options and edge cases",
        rows: [
          {
            parameter: "Indent",
            type: "2 | 4 | tab",
            defaultVal: "2 spaces",
            description:
              "Applied per nesting level. Tabs are the right choice when the file will be read in editors with different preferences, since each reader controls the visual width.",
          },
          {
            parameter: "Collapse whitespace",
            type: "boolean",
            defaultVal: "true",
            description:
              "Normalises runs of spaces and newlines inside text nodes. Turn it off for documents where text content is whitespace-significant, such as embedded source code outside a CDATA section.",
          },
          {
            parameter: "Strip comments",
            type: "boolean",
            defaultVal: "false",
            description:
              "Removes <!-- … --> entirely. Comments are preserved by default because in configuration files they are frequently the only documentation there is.",
          },
          {
            parameter: "Wrap attributes",
            type: "integer",
            defaultVal: "0 (never)",
            description:
              "Above this count, each attribute goes on its own line. Useful for SVG and XSLT, where a single element can carry a dozen attributes and an unwrapped line runs off the screen.",
          },
          {
            parameter: "CDATA",
            type: "preserved",
            defaultVal: "—",
            description:
              "Reproduced verbatim, including internal whitespace and any characters that look like markup. The whole point of a CDATA section is that its contents are not parsed.",
          },
          {
            parameter: "DOCTYPE",
            type: "preserved",
            defaultVal: "—",
            description:
              "Kept intact, including an internal subset containing > characters. Scanning to the first > truncates the declaration and turns the remainder into text.",
          },
          {
            parameter: "Namespaces",
            type: "preserved",
            defaultVal: "—",
            description:
              "Prefixes and xmlns declarations pass through unchanged. This is a formatter, not a validator: it does not check that a prefix is bound.",
          },
          {
            parameter: "Malformed input",
            type: "error",
            defaultVal: "—",
            description:
              "A mismatched closing tag, an unterminated comment or CDATA, or a document ending mid-tree is reported with a position. Nothing is auto-corrected, because a silently repaired document is not the one you had.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will formatting change what my XML means?",
          answer:
            "It can, in one specific way: whitespace inside text content is data in XML, and collapsing it changes that data. That is why Collapse whitespace is a switch rather than always-on — turn it off for documents where text is whitespace-significant. Everything else is preserved exactly, including CDATA contents, comments, attribute values and the DOCTYPE.",
        },
        {
          question: "Why does it refuse my document instead of fixing it?",
          answer:
            "Because guessing which tag you meant to close is not something a formatter can do safely. Given <a><b></a>, closing <b> for you produces a document that looks correct and has a different tree from the one you wrote. The error names the tag and the position so you can decide, which takes seconds and cannot be wrong.",
        },
        {
          question: "Does it handle SVG, XSLT, RSS, SOAP and Android layouts?",
          answer:
            "Yes — they are all XML, and nothing here is schema-aware. SVG and XSLT in particular benefit from the attribute wrapping option, since a single element with a dozen attributes is common and unwrapped it runs well off the screen.",
        },
        {
          question: "What about HTML?",
          answer:
            "Only XHTML-shaped HTML. Real HTML has void elements that never close (<br>, <img>), optional closing tags (<li>, <td>), and raw-text elements like <script> whose contents are not markup. This tokenizer holds a document to XML rules, so it will report an unclosed <br> as an error. That is correct for XML and wrong for HTML.",
        },
        {
          question: "Is there a size limit?",
          answer:
            "8 MB. Formatting runs on the main thread, so above that ceiling the tool declines rather than locking the tab. Both tokenizing and formatting are iterative rather than recursive, so a deeply nested document — there is a test at five thousand levels — reports a result instead of overflowing the call stack.",
        },
        {
          question: "Is my document uploaded?",
          answer:
            "No. It is tokenized and re-indented by JavaScript in the tab you already have open. Open the Network panel and paste one: nothing carrying it leaves. XML configuration files routinely contain connection strings, internal hostnames and credentials, which is exactly the material that should not pass through an unknown server for reformatting.",
        },
      ]}
      relatedTools={relatedTools("/xml-formatter").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="XML"
        outputLabel={mode === "minify" ? "Minified" : "Formatted"}
        inputPlaceholder="Paste an XML document…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="formatted.xml"
        options={
          <>
            <div className={segmentTrack} role="group" aria-label="Mode">
              <button
                type="button"
                onClick={() => setMode("format")}
                aria-pressed={mode === "format"}
                className={segment(mode === "format")}
              >
                Format
              </button>
              <button
                type="button"
                onClick={() => setMode("minify")}
                aria-pressed={mode === "minify"}
                className={segment(mode === "minify")}
              >
                Minify
              </button>
            </div>

            {mode === "format" && (
              <>
                <div className="flex items-center gap-2">
                  <label htmlFor="indent" className={fieldLabel}>
                    Indent
                  </label>
                  <select
                    id="indent"
                    className={`${field} cursor-pointer`}
                    value={String(options.indent)}
                    onChange={(e) =>
                      setOptions({
                        ...options,
                        indent: e.target.value === "tab" ? "tab" : Number(e.target.value),
                      })
                    }
                  >
                    <option value="2">2 spaces</option>
                    <option value="4">4 spaces</option>
                    <option value="tab">Tab</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <label htmlFor="wrap" className={fieldLabel}>
                    Wrap attributes over
                  </label>
                  <select
                    id="wrap"
                    className={`${field} cursor-pointer`}
                    value={options.attributeWrapThreshold}
                    onChange={(e) =>
                      setOptions({ ...options, attributeWrapThreshold: Number(e.target.value) })
                    }
                  >
                    <option value={0}>Never</option>
                    <option value={3}>3</option>
                    <option value={5}>5</option>
                  </select>
                </div>

                <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
                  <input
                    type="checkbox"
                    className={checkbox}
                    checked={options.collapseWhitespace}
                    onChange={(e) => setOptions({ ...options, collapseWhitespace: e.target.checked })}
                  />
                  Collapse whitespace
                </label>

                <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
                  <input
                    type="checkbox"
                    className={checkbox}
                    checked={options.stripComments}
                    onChange={(e) => setOptions({ ...options, stripComments: e.target.checked })}
                  />
                  Strip comments
                </label>
              </>
            )}
          </>
        }
      />
    </ToolShell>
  );
};
