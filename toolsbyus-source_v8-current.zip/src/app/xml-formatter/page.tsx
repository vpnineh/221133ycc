import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { XmlFormatterClient } from "./XmlFormatterClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/xml-formatter",
  title: "XML Formatter — Indent and Validate XML",
  socialTitle: "XML Formatter",
  description:
    "Format and beautify XML in your browser. A single-pass tokenizer keeps CDATA, comments and DOCTYPE subsets intact and reports mismatched tags with a position.",
});

export default function XmlFormatterPage() {
  return <XmlFormatterClient />;
}
