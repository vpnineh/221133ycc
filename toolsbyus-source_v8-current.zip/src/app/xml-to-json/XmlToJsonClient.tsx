"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, field, fieldLabel } from "../../components/common/controls";
import { xmlToJson, XML_TO_JSON_DEFAULTS } from "../../lib/xml/convert";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<order id="ord_1041" currency="GBP">
  <customer vip="true">
    <name>Ada Lovelace</name>
    <email>ada@example.com</email>
  </customer>
  <!-- one line today, two lines tomorrow: see the force-array note -->
  <lines>
    <line sku="WID-1" qty="2">Widget, small</line>
  </lines>
  <notes><![CDATA[Handle with care & <do not fold>]]></notes>
  <shippedAt/>
</order>
`;

export const XmlToJsonClient: React.FC = () => {
  const [attributePrefix, setAttributePrefix] = useState("@");
  const [textKey, setTextKey] = useState("#text");
  const [forceArray, setForceArray] = useState("line");
  const [parseValues, setParseValues] = useState(false);
  const [stripNamespaces, setStripNamespaces] = useState(false);
  const [keepComments, setKeepComments] = useState(false);

  const transform = (input: string): TransformOutcome => {
    const result = xmlToJson(input, {
      ...XML_TO_JSON_DEFAULTS,
      attributePrefix,
      textKey: textKey || "#text",
      parseValues,
      stripNamespaces,
      keepComments,
      forceArray: forceArray.split(/[\s,]+/).filter(Boolean),
    });

    if (!result.ok) {
      return { output: "", error: `Line ${result.error.line}: ${result.error.message}` };
    }

    const output = JSON.stringify(result.value, null, 2);
    return {
      output,
      warnings: result.warnings,
      stats: [
        { label: "Output", value: `${output.length.toLocaleString("en-GB")} bytes` },
        { label: "Forced arrays", value: forceArray.trim() ? forceArray.trim() : "none" },
        { label: "Values", value: parseValues ? "typed" : "strings" },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="xml-to-json"
      keyword="XML to JSON"
      directAnswer="XML to JSON converts a document in your browser. There is no canonical mapping between the two formats, so every decision is an option rather than a silent default — the important one is the force-array list, because XML cannot distinguish a one-item list from a single value and no converter can infer it."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "XML to JSON", url: "/xml-to-json" },
      ]}
      seoDescription="Convert XML to JSON in the browser. Attributes preserved under a prefix, repeated elements as arrays, a force-array list for single-element collections, CDATA and entities handled correctly."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              XML and JSON do not describe the same shapes, so there is no single correct
              translation between them. A converter that presents one anyway is hiding four
              decisions, each of which can quietly corrupt your data.
            </p>
            <h3>The single-element problem, which cannot be inferred</h3>
            <p>
              XML has no arrays. <code>&lt;line/&gt;&lt;line/&gt;</code> is two elements;{" "}
              <code>&lt;line/&gt;</code> is one. So a converter turns repeated elements into an array
              and leaves a lone element as a scalar — which means the same endpoint produces{" "}
              <code>&#123;&quot;line&quot;: &#123;…&#125;&#125;</code> for an order with one line and{" "}
              <code>&#123;&quot;line&quot;: [&#123;…&#125;, &#123;…&#125;]&#125;</code> for an order
              with two. Code written against the second crashes on the first, in production, on the
              day a customer orders one thing.
            </p>
            <p>
              This is not solvable by inference. The information needed — is this element a
              collection? — lives in the schema, not the instance. The honest fix is the force-array
              list: name the elements that are collections and they are always arrays, however many
              of them the document happens to contain today.
            </p>
            <h3>Attributes need somewhere to go</h3>
            <p>
              <code>&lt;line sku=&quot;X&quot;&gt;&lt;sku&gt;Y&lt;/sku&gt;&lt;/line&gt;</code> has an
              attribute and a child element with the same name. Merging them loses one. The prefix —{" "}
              <code>@</code> by default — keeps both, at the cost of keys that are slightly awkward to
              type in JavaScript. Set it to empty to merge them and accept the collision.
            </p>
            <h3>XML has no types</h3>
            <p>
              <code>&lt;qty&gt;3&lt;/qty&gt;</code> is the string &quot;3&quot;. Coercing it to a
              number is a guess, and it is the guess that turns the part number{" "}
              <code>007</code> into <code>7</code> and the postcode <code>01970</code> into{" "}
              <code>1970</code>. Value parsing is therefore off by default, and when it is on, a
              leading zero still keeps the value a string — the JSON grammar forbids leading zeros
              anyway, so there is nothing to lose.
            </p>
            <h3>Mixed content does not survive</h3>
            <p>
              <code>&lt;p&gt;before&lt;b&gt;bold&lt;/b&gt;after&lt;/p&gt;</code> has text before and
              after a child. JSON objects have no ordering, so the two text runs are joined under one
              key and their position relative to <code>&lt;b&gt;</code> is lost. Nothing can fix
              this; document-shaped XML is not data-shaped, and converting it to JSON is the wrong
              move rather than a lossy one.
            </p>
            <h3>Malformed input is rejected, not guessed at</h3>
            <p>
              Mismatched tags and unclosed elements produce an error naming the tag and the line. A
              converter that accepts <code>&lt;a&gt;&lt;b&gt;&lt;/a&gt;</code> and emits
              plausible-looking JSON is worse than one that fails, because the person pasting
              truncated XML never finds out it was truncated.
            </p>
          </>
        ),
        inputTitle: "XML",
        exampleInput: `<order id="1">
  <line sku="A">Widget</line>
</order>`,
        outputTitle: "JSON",
        exampleOutput: `{
  "order": {
    "@id": "1",
    "line": {
      "@sku": "A",
      "#text": "Widget"
    }
  }
}
// with "line" forced: "line": [ … ]`,
      }}
      referenceTable={{
        title: "Options and mapping rules",
        rows: [
          {
            parameter: "Force array",
            type: "element names",
            defaultVal: "(none)",
            description:
              "Names listed here are always arrays, even with one occurrence. The single most important option: it is the only fix for the one-item-list problem, and it cannot be inferred from the document.",
          },
          {
            parameter: "Attribute prefix",
            type: "string",
            defaultVal: "@",
            description:
              "Keeps attributes distinct from child elements of the same name. Set it to empty to merge them, accepting that one wins on a collision.",
          },
          {
            parameter: "Text key",
            type: "string",
            defaultVal: "#text",
            description:
              "Where an element's text goes when it also has attributes or children. An element with only text collapses to a bare string instead.",
          },
          {
            parameter: "Parse values",
            type: "boolean",
            defaultVal: "off",
            description:
              'Coerces "3" to 3, "true" to true and "null" to null. Off by default because XML has no types and guessing turns part numbers into integers.',
          },
          {
            parameter: "Leading zeros",
            type: "kept as string",
            defaultVal: "always",
            description:
              "007 stays \"007\" even with value parsing on. The JSON grammar forbids a leading zero, so there is no representation to convert to that keeps it.",
          },
          {
            parameter: "Strip namespaces",
            type: "boolean",
            defaultVal: "off",
            description:
              "Drops prefixes, so soap:Envelope becomes Envelope, and removes xmlns declarations. Convenient for SOAP; lossy if two namespaces use the same local name.",
          },
          {
            parameter: "Keep comments",
            type: "boolean",
            defaultVal: "off",
            description:
              "Preserves comments under a #comment member. Their position between elements is not preserved, because JSON objects have no ordering.",
          },
          {
            parameter: "Empty elements",
            type: "null",
            defaultVal: "always",
            description:
              "<a/> and <a></a> are the same thing in XML, and both become null rather than an empty string, which would imply a value.",
          },
          {
            parameter: "CDATA",
            type: "literal text",
            defaultVal: "—",
            description:
              "Content inside CDATA is taken verbatim: an &lt; inside it is an ampersand followed by lt, not a less-than sign. That is what CDATA is for.",
          },
          {
            parameter: "Entities",
            type: "decoded",
            defaultVal: "the five predefined",
            description:
              "&amp; &lt; &gt; &quot; &apos; plus numeric references. An undeclared entity is left verbatim rather than deleted, because deleting content silently is the worse failure.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why is one item an object but two items an array?",
          answer:
            "Because XML has no arrays, and this is the single biggest hazard when converting it. A converter sees one <line> and cannot know whether the schema allows more. Put the element name in the force-array box and it becomes an array every time, which is what your code needs to be written against. This is worth doing before you ship, not after a one-item order breaks production.",
        },
        {
          question: "Why do my keys start with @?",
          answer:
            "Those are attributes. XML has two kinds of member and JSON has one, so attributes need a prefix or they collide with child elements — and an element with both a sku attribute and a sku child is not unusual. You can set the prefix to empty to merge them, or change it to something friendlier like an underscore.",
        },
        {
          question: "Why are my numbers strings?",
          answer:
            "Because in XML they are strings. There is no type information in the document, so converting <qty>3</qty> to the number 3 is a guess that happens to be right for quantities and wrong for part numbers, postcodes and phone numbers. Turn value parsing on if your data has no zero-padded identifiers in it; even then, a leading zero keeps the value a string.",
        },
        {
          question: "What happened to the text around my child elements?",
          answer:
            "It was joined and put under the text key, and its position was lost. This is mixed content, and JSON genuinely cannot represent it: an object has no ordering, so there is nowhere to record that some text came before a child and some after. If your XML is document-shaped — XHTML, DocBook, anything with markup inside prose — converting it to JSON is the wrong operation rather than a lossy one.",
        },
        {
          question: "Can it handle SOAP responses?",
          answer:
            "Yes, and turn on strip namespaces, which is what makes soap:Envelope into Envelope and removes the xmlns declarations that would otherwise appear as attributes on every element. Be aware that stripping is lossy if the document genuinely uses two namespaces with the same local name, which is rare in SOAP and common in mixed-vocabulary XML.",
        },
        {
          question: "Is my XML uploaded?",
          answer:
            "No. The tokenizer and the converter both run in the tab you already have open — check the Network panel. It matters because XML on the wire today is mostly SOAP, SAML assertions and financial messages, which is to say some of the most sensitive material a developer handles.",
        },
      ]}
      relatedTools={relatedTools("/xml-to-json").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="XML"
        outputLabel="JSON"
        inputPlaceholder="Paste XML here…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="converted.json"
        height={420}
        options={
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
            <div className="flex items-center gap-2">
              <label htmlFor="xml-force-array" className={fieldLabel}>
                Force array
              </label>
              <input
                id="xml-force-array"
                type="text"
                value={forceArray}
                onChange={(e) => setForceArray(e.target.value)}
                placeholder="line, item"
                spellCheck={false}
                className={`${field} w-40`}
              />
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="xml-attr-prefix" className={fieldLabel}>
                Attr prefix
              </label>
              <input
                id="xml-attr-prefix"
                type="text"
                value={attributePrefix}
                onChange={(e) => setAttributePrefix(e.target.value)}
                spellCheck={false}
                className={`${field} w-16`}
              />
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="xml-text-key" className={fieldLabel}>
                Text key
              </label>
              <input
                id="xml-text-key"
                type="text"
                value={textKey}
                onChange={(e) => setTextKey(e.target.value)}
                spellCheck={false}
                className={`${field} w-24`}
              />
            </div>

            {[
              {
                id: "xml-parse-values",
                label: "Parse values",
                checked: parseValues,
                onChange: setParseValues,
              },
              {
                id: "xml-strip-ns",
                label: "Strip namespaces",
                checked: stripNamespaces,
                onChange: setStripNamespaces,
              },
              {
                id: "xml-keep-comments",
                label: "Keep comments",
                checked: keepComments,
                onChange: setKeepComments,
              },
            ].map((toggle) => (
              <label
                key={toggle.id}
                htmlFor={toggle.id}
                className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
              >
                <input
                  id={toggle.id}
                  type="checkbox"
                  checked={toggle.checked}
                  onChange={(e) => toggle.onChange(e.target.checked)}
                  className={checkbox}
                />
                <span className={fieldLabel}>{toggle.label}</span>
              </label>
            ))}
          </div>
        }
      />
    </ToolShell>
  );
};
