import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { XmlToJsonClient } from "./XmlToJsonClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/xml-to-json",
  title: "XML to JSON — Keep Attributes and Text Nodes",
  socialTitle: "XML to JSON",
  description:
    "Convert XML to JSON in your browser. Attributes kept and prefixed, repeated elements turned into arrays, plus a force-array list for single items.",
});

export default function XmlToJsonPage() {
  return <XmlToJsonClient />;
}
