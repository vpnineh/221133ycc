"use client";

import React, { useMemo, useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { CodePane } from "../../components/tools/CodePane";
import { JsonTreeView } from "../../components/tools/JsonTreeView";
import { Notice } from "../../components/common/Notice";
import { segment, segmentTrack } from "../../components/common/controls";
import { formatXml, DEFAULT_XML_FORMAT } from "../../lib/xml";
import { xmlToJson, XML_TO_JSON_DEFAULTS } from "../../lib/xml/convert";
import { relatedTools } from "../../lib/tools";
import type { JsonValue } from "../../lib/json/types";

const SAMPLE = `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <auth token="tok_8812" expires="2026-09-12T00:00:00Z"/>
  </soap:Header>
  <soap:Body>
    <GetOrderResponse xmlns="urn:orders">
      <order id="ord_1041" currency="GBP">
        <customer vip="true">
          <name>Ada Lovelace</name>
          <email>ada@example.com</email>
        </customer>
        <lines>
          <line sku="WID-1" qty="2" unit="24.00"/>
          <line sku="WID-9" qty="1" unit="100.50"/>
        </lines>
        <notes><![CDATA[Handle with care & <do not fold>]]></notes>
        <shippedAt/>
      </order>
    </GetOrderResponse>
  </soap:Body>
</soap:Envelope>
`;

export const XmlViewerClient: React.FC = () => {
  const [raw, setRaw] = useState(SAMPLE);
  const [view, setView] = useState<"tree" | "formatted">("tree");

  const converted = useMemo(
    () => xmlToJson(raw, { ...XML_TO_JSON_DEFAULTS, keepComments: true, collapseText: false }),
    [raw]
  );

  const formatted = useMemo(() => formatXml(raw, DEFAULT_XML_FORMAT), [raw]);

  // Keep the last document that parsed, so the tree does not blank on every
  // intermediate broken state while typing.
  const [lastGood, setLastGood] = useState<JsonValue | null>(() =>
    converted.ok ? converted.value : null
  );
  if (converted.ok && converted.value !== lastGood) setLastGood(converted.value);

  const counts = useMemo(() => countNodes(raw), [raw]);

  return (
    <ToolShell
      wide
      slug="xml-viewer"
      keyword="XML Viewer"
      directAnswer="XML Viewer renders a document as a collapsible tree in your browser. The tree is virtualized, so a large SOAP response or sitemap opens at the same speed as a small one, and attributes are shown distinctly from child elements — which is the distinction that makes an unfamiliar XML document readable."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "XML Viewer", url: "/xml-viewer" },
      ]}
      seoDescription="View XML as a collapsible tree in the browser. Virtualized for large documents, attributes shown separately from elements, search across the whole document, plus a formatted text view."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              Nobody opens an XML viewer for a twenty-line document. They open one for a SOAP
              response, a sitemap, an SVG, a Maven POM or a config file that is too large to read as
              text and too nested to follow with a text editor&apos;s folding. So the only question
              that matters is what happens at size.
            </p>
            <h3>The tree is virtualized, so size barely matters</h3>
            <p>
              The obvious implementation renders one component per node, which means a
              fifty-thousand-node document produces fifty thousand DOM elements of which perhaps
              forty are visible. Scrolling stutters and the tab consumes hundreds of megabytes.
              Here the document is flattened into an array of rows first — each carrying its depth,
              its type and where its subtree ends — and only the rows inside the viewport are
              rendered. The DOM holds around fifty elements no matter how big the document is.
            </p>
            <p>
              Recording where each subtree ends is what makes collapsing cheap: hiding a branch is
              one index comparison rather than a walk over everything inside it. Collapsing the root
              of a huge document is instant.
            </p>
            <h3>Attributes are shown separately from elements</h3>
            <p>
              XML has two kinds of member and most viewers flatten them into one, which loses the
              distinction between <code>&lt;line sku=&quot;X&quot;/&gt;</code> and{" "}
              <code>&lt;line&gt;&lt;sku&gt;X&lt;/sku&gt;&lt;/line&gt;</code>. Attributes appear under
              an <code>@</code> prefix so both survive and neither overwrites the other — which
              matters, because an element carrying both an attribute and a child element of the same
              name is common in real vocabularies.
            </p>
            <h3>Search covers the whole document, not the open part</h3>
            <p>
              A match buried in a collapsed subtree is found and shown, with every ancestor on the
              path to it, because a value without its path tells you nothing about where it came
              from.
            </p>
            <h3>Malformed input is named, not guessed at</h3>
            <p>
              Mismatched tags and unclosed elements produce an error identifying the tag and the
              line. Truncated XML is the most common thing anyone pastes into a viewer — it is why
              they are looking at it — so a viewer that renders something plausible from a broken
              document is actively unhelpful.
            </p>
            <p>
              The formatted view is separate and lossless: it re-indents without touching content,
              preserving CDATA, comments, processing instructions and the exact text inside elements.
            </p>
          </>
        ),
        inputTitle: "XML",
        exampleInput: `<order id="1"><line sku="A" qty="2"/></order>`,
        outputTitle: "Tree",
        exampleOutput: `▾ order        { 2 }
    @id        "1"
  ▾ line       { 2 }
      @sku     "A"
      @qty     "2"`,
      }}
      referenceTable={{
        title: "Viewer behaviour and limits",
        rows: [
          {
            parameter: "Virtualization",
            type: "viewport only",
            defaultVal: "—",
            description:
              "Around fifty rows exist in the DOM at any moment regardless of document size. This is the difference between opening a 10 MB SOAP log and hanging the tab.",
          },
          {
            parameter: "Attributes",
            type: "@ prefix",
            defaultVal: "shown",
            description:
              "Kept distinct from child elements, so an element with both a sku attribute and a sku child shows both rather than one silently winning.",
          },
          {
            parameter: "Text nodes",
            type: "#text",
            defaultVal: "shown",
            description:
              "Element text appears under its own row rather than being collapsed into the element, so an element that has text and children shows both.",
          },
          {
            parameter: "Comments",
            type: "#comment",
            defaultVal: "shown",
            description:
              "Kept, because a comment in a config file is frequently the only documentation of why a value is what it is.",
          },
          {
            parameter: "CDATA",
            type: "literal",
            defaultVal: "—",
            description:
              "Shown verbatim. Entities inside a CDATA section are not entities, which is the whole point of the construct.",
          },
          {
            parameter: "Namespaces",
            type: "preserved",
            defaultVal: "prefix kept",
            description:
              "soap:Body stays soap:Body, and xmlns declarations appear as attributes. Stripping them is available in the XML to JSON converter, where it is a conversion choice rather than a display one.",
          },
          {
            parameter: "Search",
            type: "substring",
            defaultVal: "case-insensitive",
            description:
              "Matches names and values across the entire document, including collapsed branches, and keeps every ancestor of a match so the path stays visible.",
          },
          {
            parameter: "Malformed input",
            type: "error",
            defaultVal: "named",
            description:
              "Mismatched or unclosed tags are reported with the tag name and line. The tree keeps showing the last document that parsed rather than blanking as you type.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "Tokenizing runs on the main thread. Above the ceiling the tool declines rather than freezing; the tree itself handles far more nodes than that allows.",
          },
        ],
      }}
      faqs={[
        {
          question: "Will it open a large SOAP response or sitemap?",
          answer:
            "Up to the 8 MB ceiling, and the tree is not the bottleneck — it renders only what is on screen, so node count has almost no effect on it. The limit is the tokenizer, which runs on the main thread and declines above 8 MB rather than attempting it, because attempting it locks the tab for seconds.",
        },
        {
          question: "Why do some rows start with @?",
          answer:
            "Those are attributes. XML has attributes and child elements; JSON-shaped trees have one kind of member, so attributes are prefixed to keep them distinct. Without the prefix, an element carrying both a sku attribute and a sku child element would show only one of them, and you would have no way to tell which.",
        },
        {
          question: "Can I edit the XML here?",
          answer:
            "You can edit the text pane and the tree follows, but the tree itself is read-only. Keeping it read-only is what lets it stay fast on documents an editing tree would struggle with — an editable tree has to reconcile two sources of truth on every keystroke. For re-indenting, use the formatted view or the XML Formatter.",
        },
        {
          question: "My document is invalid. Why does the tree still show something?",
          answer:
            "Because it is showing the last version that parsed, so a single keystroke mid-edit does not blank the whole view. The error banner names the mismatched or unclosed tag and its line. Once the document parses again the tree updates.",
        },
        {
          question: "Does the formatted view change my document?",
          answer:
            "It changes whitespace between elements and nothing else. Text content, CDATA sections, comments, processing instructions and attribute values are preserved byte for byte. Be aware that whitespace between elements is significant to a strict XML parser, so the re-indented document is not always interchangeable with the original for a machine — only for a person.",
        },
        {
          question: "Is my XML uploaded?",
          answer:
            "No. Tokenizing and rendering both happen in the tab you already have open — open DevTools, watch the Network panel and paste. This matters for XML more than most formats: what people actually need to read is SOAP traffic, SAML assertions and financial messages, which is some of the most sensitive material a developer handles.",
        },
      ]}
      relatedTools={relatedTools("/xml-viewer").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          <div className={segmentTrack} role="group" aria-label="View">
            <button
              type="button"
              onClick={() => setView("tree")}
              aria-pressed={view === "tree"}
              className={segment(view === "tree")}
            >
              Tree
            </button>
            <button
              type="button"
              onClick={() => setView("formatted")}
              aria-pressed={view === "formatted"}
              className={segment(view === "formatted")}
            >
              Formatted
            </button>
          </div>
          <span className="font-mono text-2xs text-foreground-subtle">
            {counts.elements.toLocaleString("en-GB")} elements ·{" "}
            {counts.attributes.toLocaleString("en-GB")} attributes · depth {counts.depth}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <CodePane
            label="XML document"
            value={raw}
            onChange={setRaw}
            placeholder="Paste an XML document…"
            height={460}
            error={!converted.ok ? converted.error : undefined}
          />

          <div>
            {view === "tree" ? (
              lastGood !== null ? (
                <JsonTreeView value={lastGood} height={460} initialDepth={4} />
              ) : (
                <div className="flex h-[460px] items-center justify-center rounded-lg border border-border bg-surface p-6 text-center text-xs text-foreground-muted">
                  Paste a well-formed XML document to see its tree.
                </div>
              )
            ) : (
              <CodePane
                label="Formatted"
                value={formatted.ok ? formatted.value.formatted : ""}
                onChange={() => undefined}
                readOnly
                height={460}
              />
            )}
          </div>
        </div>

        {!converted.ok && lastGood !== null && (
          <Notice tone="warn">
            The document does not currently parse, so the tree still shows the last version that did.
            The editor pane above names the tag and the line.
          </Notice>
        )}
      </div>
    </ToolShell>
  );
};

/** Counts elements, attributes and nesting depth for the status line. */
function countNodes(source: string): { elements: number; attributes: number; depth: number } {
  let elements = 0;
  let attributes = 0;
  let depth = 0;
  let maxDepth = 0;

  // A scan rather than a second parse: this runs on every keystroke, and the
  // numbers are a status line, not a contract.
  const tagPattern = /<(\/?)([A-Za-z_:][-A-Za-z0-9_.:]*)([^>]*?)(\/?)>/g;
  let match: RegExpExecArray | null;
  while ((match = tagPattern.exec(source)) !== null) {
    const [, closing, , rest, selfClosing] = match;
    if (closing) {
      depth = Math.max(0, depth - 1);
      continue;
    }
    elements++;
    attributes += (rest.match(/[A-Za-z_:][-A-Za-z0-9_.:]*\s*=\s*["']/g) ?? []).length;
    if (!selfClosing) {
      depth++;
      maxDepth = Math.max(maxDepth, depth);
    }
  }

  return { elements, attributes, depth: maxDepth };
}
