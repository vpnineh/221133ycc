import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { XmlViewerClient } from "./XmlViewerClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/xml-viewer",
  title: "XML Viewer — Explore XML as a Collapsible Tree",
  socialTitle: "XML Viewer",
  description:
    "View XML as a collapsible tree in your browser. Virtualized for large documents, with search, element and attribute counts, and a text view.",
});

export default function XmlViewerPage() {
  return <XmlViewerClient />;
}
