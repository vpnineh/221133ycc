"use client";

import React, { useState } from "react";
import { ToolShell } from "../../components/tools/ToolShell";
import { TransformTool, type TransformOutcome } from "../../components/tools/TransformTool";
import { checkbox, fieldLabel, segment, segmentTrack } from "../../components/common/controls";
import { parseYaml } from "../../lib/yaml";
import { relatedTools } from "../../lib/tools";

const SAMPLE = `# A GitHub Actions workflow, which is the YAML most people paste.
name: CI
on:
  push:
    branches: [main]
  pull_request:
jobs:
  build:
    runs-on: ubuntu-latest
    env: &defaults
      CI: true
      TZ: UTC
    steps:
      - uses: actions/checkout@v4
      - name: Test
        run: |
          npm ci
          npm test
        env: *defaults
  lint:
    runs-on: ubuntu-latest
    # NO is a country code, not a boolean. Under YAML 1.1 it is false.
    regions: [NO, SE, DK]
    version: "007"
`;

export const YamlToJsonClient: React.FC = () => {
  const [indent, setIndent] = useState(2);
  const [allDocuments, setAllDocuments] = useState(true);
  const [sortKeys, setSortKeys] = useState(false);

  const transform = (input: string): TransformOutcome => {
    const result = parseYaml(input);
    if (!result.success) {
      return {
        output: "",
        error: `Line ${result.error.line}: ${result.error.message}`,
      };
    }

    const documents = allDocuments ? result.documents : result.documents.slice(0, 1);
    const payload = documents.length === 1 ? documents[0] : documents;
    const output = JSON.stringify(payload, sortKeys ? sortedReplacer : undefined, indent);

    return {
      output,
      warnings: result.warnings.map((w) => `Line ${w.line}: ${w.message}`),
      stats: [
        { label: "Documents", value: String(result.documents.length) },
        { label: "Output", value: `${output.length.toLocaleString("en-GB")} bytes` },
        { label: "Schema", value: "YAML 1.2 core" },
      ],
    };
  };

  return (
    <ToolShell
      wide
      slug="yaml-to-json"
      keyword="YAML to JSON"
      directAnswer="YAML to JSON converts a YAML document to JSON in your browser using the YAML 1.2 core schema. That matters more than it sounds: under the older 1.2 predecessor still used by PyYAML and Ruby, the unquoted tokens NO, yes, on and off resolve as booleans, so a list of ISO country codes loses Norway. Here they stay strings, and anything that would resolve differently under 1.1 is flagged."
      breadcrumbs={[
        { name: "Text Tools", url: "/text-tools" },
        { name: "YAML to JSON", url: "/yaml-to-json" },
      ]}
      seoDescription="Convert YAML to JSON in the browser under the YAML 1.2 core schema. Anchors and aliases expanded with a bomb guard, block scalars, multi-document files, and warnings wherever YAML 1.1 would disagree."
      howItWorks={{
        algorithmExplanation: (
          <>
            <p>
              YAML looks simple and is not. The specification is longer than
              JSON&apos;s, XML&apos;s and TOML&apos;s combined, and most of the surprises come from one
              design decision: unquoted scalars are resolved by pattern rather than declared by
              syntax. What a token means depends on which resolution table the reader is using.
            </p>
            <h3>The Norway problem is a versioning problem</h3>
            <p>
              YAML 1.1 resolved <code>y</code>, <code>yes</code>, <code>on</code>, <code>n</code>,{" "}
              <code>no</code> and <code>off</code> as booleans. So{" "}
              <code>countries: [NO, SE, DK]</code> loaded as{" "}
              <code>[false, &quot;SE&quot;, &quot;DK&quot;]</code>, and a configuration file that
              said <code>norway: no</code> meant something no one intended. YAML 1.2 removed all of
              them, along with sexagesimal numbers — which is why <code>1.1</code> read{" "}
              <code>12:30</code> as the integer 750.
            </p>
            <p>
              The catch is that the software people actually run is split. PyYAML&apos;s default
              loader and Ruby&apos;s Psych are 1.1; Go&apos;s yaml.v3 and modern JavaScript parsers are
              1.2. This converter applies 1.2 and tells you, by name, every token where a 1.1 reader
              would disagree — because the useful output is not just the JSON but the knowledge that
              the file is ambiguous.
            </p>
            <h3>Anchors are expanded, with a budget</h3>
            <p>
              <code>&amp;name</code> defines an anchor and <code>*name</code> references it. JSON has
              no equivalent, so each reference is expanded into a copy. That expansion is the
              &quot;billion laughs&quot; attack: ten anchors each referencing the previous one twice
              expand to 1,024 nodes, twenty to a million, thirty to more than a billion. A 200-byte
              file can exhaust the heap. Expansion is capped at 100,000 nodes and the cap is
              reported, which is the difference between a clear error and a hung tab.
            </p>
            <h3>Block scalars keep their line breaks</h3>
            <p>
              <code>|</code> keeps newlines, <code>&gt;</code> folds them into spaces, and the
              chomping indicator decides what happens to the trailing one:{" "}
              <code>|</code> keeps exactly one, <code>|-</code> strips them all, <code>|+</code>{" "}
              keeps every one. That last distinction matters for a PEM key or a shell script whose
              final line has to be terminated. A <code>#</code> inside a block scalar is content, not
              a comment — a parser that strips it eats the shebang off every script.
            </p>
            <h3>Duplicate keys are reported, not hidden</h3>
            <p>
              YAML says a duplicate key is an error. Most parsers silently keep the last one. This
              one keeps the last, matching <code>JSON.parse</code>, and says which key and on which
              line — because a duplicate in a config file is almost always a merge gone wrong.
            </p>
          </>
        ),
        inputTitle: "YAML",
        exampleInput: `regions: [NO, SE]
version: "007"
retry: 012`,
        outputTitle: "JSON",
        exampleOutput: `{
  "regions": ["NO", "SE"],
  "version": "007",
  "retry": 12
}
// warning: 012 — leading zero, 1.1 reads it as octal`,
      }}
      referenceTable={{
        title: "Resolution and support",
        rows: [
          {
            parameter: "true / false",
            type: "boolean",
            defaultVal: "resolved",
            description:
              "Only these two spellings, in any case. This is the whole difference from YAML 1.1 and the reason Norway survives.",
          },
          {
            parameter: "yes / no / on / off / y / n",
            type: "string",
            defaultVal: "flagged",
            description:
              "Strings under 1.2, booleans under 1.1. Each one is reported by name so you know the file means different things in different runtimes.",
          },
          {
            parameter: "~ / null / (empty)",
            type: "null",
            defaultVal: "resolved",
            description:
              "All three spell JSON null. An empty value after a key is null, not an empty string.",
          },
          {
            parameter: "012",
            type: "integer",
            defaultVal: "12, flagged",
            description:
              "1.2 reads a leading zero as decimal; 1.1 reads it as octal 10; the author probably meant the string. Quote it to keep the zero.",
          },
          {
            parameter: "0o17 / 0x1f",
            type: "integer",
            defaultVal: "15 / 31",
            description:
              "Explicit octal and hexadecimal. 1.2 requires the 0o prefix for octal, which is why bare 017 is not 15.",
          },
          {
            parameter: ".inf / .nan",
            type: "string",
            defaultVal: "kept as text",
            description:
              "JSON has neither, so emitting one produces a document JSON.parse rejects. The token is kept verbatim and flagged.",
          },
          {
            parameter: "Anchors and aliases",
            type: "expanded",
            defaultVal: "100,000 node cap",
            description:
              "Each *alias becomes a copy, since JSON has no references. The cap stops a billion-laughs expansion from exhausting memory.",
          },
          {
            parameter: "Merge keys (<<)",
            type: "not supported",
            defaultVal: "reported",
            description:
              "Rejected rather than half-implemented. Merge semantics interact with overriding and ordering in ways that are easy to get subtly wrong and hard to notice.",
          },
          {
            parameter: "Multi-document",
            type: "--- separated",
            defaultVal: "array",
            description:
              "Several documents become a JSON array. Turn the option off to convert only the first, which is what a Kubernetes manifest bundle usually wants.",
          },
          {
            parameter: "Input size",
            type: "bytes",
            defaultVal: "8 MB",
            description:
              "Parsing runs on the main thread. Above the ceiling the tool declines rather than freezing the tab.",
          },
        ],
      }}
      faqs={[
        {
          question: "Why is my `no` a string instead of false?",
          answer:
            "Because this parser applies the YAML 1.2 core schema, where only true and false are booleans. YAML 1.1 — still what PyYAML's default loader and Ruby's Psych use — resolves no, yes, on, off, y and n as booleans, which is how a list of ISO country codes silently loses Norway. If you want a boolean, write true or false; if you want the string, you already have it.",
        },
        {
          question: "Which YAML version should I assume my tools use?",
          answer:
            "Check rather than assume, because the split is real and unversioned in practice: PyYAML's safe_load and Ruby's Psych are 1.1, Go's gopkg.in/yaml.v3 and most current JavaScript parsers are 1.2. The reliable answer is to quote anything ambiguous — a quoted scalar is a string in every version of YAML ever published, which makes the question moot.",
        },
        {
          question: "What happened to my anchors?",
          answer:
            "They were expanded. JSON has no way to express a reference, so each *alias becomes a full copy of what the anchor held. This is lossless for the data and lossy for the structure: the fact that two parts of the document were the same object is gone. If you need that preserved, JSON is the wrong target.",
        },
        {
          question: "Why did it refuse to expand my aliases?",
          answer:
            "Nested aliases multiply. If each anchor references the previous one twice, thirty levels expand to more than a billion nodes from a file you can read in one screen — the billion-laughs attack, which has taken down real services. Expansion stops at 100,000 nodes and says so, rather than growing until the tab dies.",
        },
        {
          question: "Why does my number keep its quotes in the output?",
          answer:
            "Because you quoted it in the YAML, and a quoted scalar is a string in every version of YAML. That is the correct behaviour and usually the intent: version: \"007\" and version: 007 are genuinely different values, and only one of them survives a round trip as written.",
        },
        {
          question: "Is my YAML uploaded?",
          answer:
            "No. The parse and the conversion both run in the tab you already have open — watch the Network panel while you paste. This matters specifically for YAML, because the YAML people need converted is usually a Kubernetes manifest, a CI workflow or a docker-compose file, which is to say a file full of infrastructure details and sometimes secrets.",
        },
      ]}
      relatedTools={relatedTools("/yaml-to-json").map((tool) => ({
        href: tool.href,
        title: tool.title,
        description: tool.description,
      }))}
    >
      <TransformTool
        inputLabel="YAML"
        outputLabel="JSON"
        inputPlaceholder="Paste YAML here…"
        initialInput={SAMPLE}
        transform={transform}
        downloadName="converted.json"
        height={420}
        options={
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className="flex items-center gap-2">
              <span className={fieldLabel}>Indent</span>
              <div className={segmentTrack} role="group" aria-label="Indent">
                {[0, 2, 4].map((value) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setIndent(value)}
                    aria-pressed={indent === value}
                    className={segment(indent === value)}
                  >
                    {value === 0 ? "min" : value}
                  </button>
                ))}
              </div>
            </div>

            <label
              htmlFor="yaml-all-docs"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="yaml-all-docs"
                type="checkbox"
                checked={allDocuments}
                onChange={(e) => setAllDocuments(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>All documents</span>
            </label>

            <label
              htmlFor="yaml-sort"
              className="flex cursor-pointer select-none items-center gap-2 pointer-coarse:min-h-[44px]"
            >
              <input
                id="yaml-sort"
                type="checkbox"
                checked={sortKeys}
                onChange={(e) => setSortKeys(e.target.checked)}
                className={checkbox}
              />
              <span className={fieldLabel}>Sort keys</span>
            </label>
          </div>
        }
      />
    </ToolShell>
  );
};

/**
 * Sorts object keys during serialisation.
 *
 * A replacer that returns a new object for every object is the only hook
 * `JSON.stringify` gives for this, and it has to leave arrays alone — sorting
 * an array's indices would reorder the data rather than the presentation.
 */
function sortedReplacer(this: unknown, _key: string, value: unknown): unknown {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return value;
  const source = value as Record<string, unknown>;
  const sorted: Record<string, unknown> = {};
  for (const key of Object.keys(source).sort()) sorted[key] = source[key];
  return sorted;
}
