import type { Metadata } from "next";
import { buildToolMetadata } from "../../lib/metadata";
import { YamlToJsonClient } from "./YamlToJsonClient";

export const metadata: Metadata = buildToolMetadata({
  path: "/yaml-to-json",
  title: "YAML to JSON — YAML 1.2, Norway Problem Safe",
  socialTitle: "YAML to JSON",
  description:
    "Convert YAML to JSON under the YAML 1.2 core schema, so NO stays Norway and not false. Anchors, block scalars and multi-document files included.",
});

export default function YamlToJsonPage() {
  return <YamlToJsonClient />;
}
