"use client";

import React, { useEffect, useRef } from "react";
import { ADS, adUnitFor, type AdPlacement } from "../../lib/ads";

interface AdSlotProps {
  /** DOM id for the wrapper element. Not an AdSense identifier. */
  id: string;
  /**
   * Which configured ad unit to fill.
   *
   * The previous version passed `id` — a page slug like `ad-slot-a-json-diff` —
   * straight into `data-ad-slot`. That attribute takes the *numeric ad-unit ID*
   * issued by the AdSense dashboard, so every slot on the site was requesting a
   * unit that does not exist. AdSense answers that with an empty response and
   * no error, which is why the failure could sit there indefinitely looking
   * like "ads just aren't filling yet".
   */
  placement: AdPlacement;
  className?: string;
}

/**
 * Optional ad placement.
 *
 * Renders nothing unless both a publisher ID and the ad unit for this placement
 * are configured at build time (`NEXT_PUBLIC_ADSENSE_ID`,
 * `NEXT_PUBLIC_AD_UNIT_TOP`, `NEXT_PUBLIC_AD_UNIT_MID`). Enabling ads is a
 * deliberate decision that also changes what /privacy may claim — see
 * `src/lib/ads.data.mjs` and the privacy page, which both read this same
 * configuration so the copy and the network tab cannot disagree.
 */
export const AdSlot: React.FC<AdSlotProps> = ({ id, placement, className = "" }) => {
  const adUnitId = adUnitFor(placement);
  const clientId = ADS.clientId;
  const insRef = useRef<HTMLModElement>(null);
  const pushed = useRef(false);

  useEffect(() => {
    if (!clientId || !adUnitId || typeof window === "undefined") return;

    let cancelled = false;

    const loadScript = () => {
      if (cancelled) return;
      if (!document.querySelector('script[src*="adsbygoogle"]')) {
        const script = document.createElement("script");
        script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
        script.async = true;
        script.crossOrigin = "anonymous";
        document.head.appendChild(script);
      }
      // Without this push the <ins> element is never filled — an earlier
      // version injected the script and then left the slot permanently blank.
      if (!pushed.current && insRef.current) {
        pushed.current = true;
        try {
          const w = window as unknown as { adsbygoogle?: unknown[] };
          w.adsbygoogle = w.adsbygoogle || [];
          w.adsbygoogle.push({});
        } catch {
          // An ad blocker rejecting the push must never break the page.
        }
      }
    };

    // Defer past the LCP: whichever comes first, a real interaction or 3s idle.
    const idleTimer = setTimeout(loadScript, 3000);
    const onInteract = () => {
      clearTimeout(idleTimer);
      loadScript();
    };

    window.addEventListener("pointerdown", onInteract, { once: true, passive: true });
    window.addEventListener("keydown", onInteract, { once: true, passive: true });

    return () => {
      cancelled = true;
      clearTimeout(idleTimer);
      window.removeEventListener("pointerdown", onInteract);
      window.removeEventListener("keydown", onInteract);
    };
  }, [clientId, adUnitId]);

  // With ads off, or this placement unconfigured, there is nothing to label,
  // announce, or reserve space for.
  if (!clientId || !adUnitId) return null;

  return (
    <aside
      id={id}
      aria-label="Advertisement"
      className={`my-8 flex min-h-[100px] w-full select-none flex-col items-center justify-center rounded-lg border border-dashed border-border bg-surface px-4 py-3 text-center ${className}`}
    >
      <span className="mb-1 font-mono text-2xs text-foreground-subtle">
        Advertisement
      </span>
      <ins
        ref={insRef}
        className="adsbygoogle block w-full text-center"
        style={{ display: "block" }}
        data-ad-client={clientId}
        data-ad-slot={adUnitId}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </aside>
  );
};

export default AdSlot;
