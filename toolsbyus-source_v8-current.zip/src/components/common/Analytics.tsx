import React from "react";

/**
 * Optional privacy-preserving analytics.
 *
 * Off unless `NEXT_PUBLIC_ANALYTICS_SRC` is set at build time, and deliberately
 * generic: Plausible, Umami and Cloudflare Web Analytics are each a single
 * `<script src>` plus one data attribute, so one component covers all three
 * rather than pulling in a vendor SDK.
 *
 * Externally sourced, never inline, for two reasons. An inline script would
 * need its SHA-256 pinned into the Content-Security-Policy on every build, and
 * `scripts/generate-csp.mjs` adds the *origin* of this URL to `script-src` —
 * so a misconfigured value fails visibly at build time instead of being
 * silently blocked in the browser.
 *
 * `defer` rather than `async`: nothing on the page waits on the counter, and
 * deferring keeps it off the critical path entirely.
 */
export const Analytics: React.FC = () => {
  const src = process.env.NEXT_PUBLIC_ANALYTICS_SRC;
  if (!src) return null;

  const domain = process.env.NEXT_PUBLIC_ANALYTICS_DOMAIN;
  const websiteId = process.env.NEXT_PUBLIC_ANALYTICS_ID;

  return (
    <script
      defer
      src={src}
      // Plausible reads data-domain; Umami and Cloudflare read data-website-id
      // and data-cf-beacon respectively. Emitting only what is configured keeps
      // the tag minimal for whichever one is in use.
      {...(domain ? { "data-domain": domain } : {})}
      {...(websiteId ? { "data-website-id": websiteId } : {})}
    />
  );
};

export default Analytics;
