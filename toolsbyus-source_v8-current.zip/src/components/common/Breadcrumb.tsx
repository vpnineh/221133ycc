import React from "react";
import Link from "next/link";

export type BreadcrumbItem =
  | { name: string; url: string; label?: never; href?: never }
  | { label: string; href: string; name?: never; url?: never };

interface BreadcrumbProps {
  items: Array<{ name?: string; url?: string; label?: string; href?: string }>;
  /** Layout only — `justify-center` where the page head is centred. */
  className?: string;
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items, className = "" }) => {
  const normalized = items
    .map((it) => ({
      name: it.name || it.label || "",
      url: it.url || it.href || "",
    }))
    // Home is rendered below unconditionally, because it is the one crumb every
    // page shares. Six pages also passed it in `items`, so they rendered
    // "Home / Home / Privacy Policy". Dropping a leading Home here fixes all of
    // them at once and stays correct whichever convention a caller follows.
    .filter((it, index) => !(index === 0 && (it.url === "/" || it.name === "Home")));

  return (
    <nav aria-label="Breadcrumb">
      {/* Under a finger these are the smallest links on the page and the ones
          most often tapped by mistake, so each gets a 40px row of its own on a
          coarse pointer. The separators are not links and stay at text height,
          which is what keeps the trail reading as one line rather than as a
          row of buttons. */}
      <ol
        className={`flex flex-wrap items-center gap-x-1.5 text-sm text-foreground-subtle ${className}`}
      >
        <li>
          <Link
            href="/"
            className="inline-flex items-center transition-colors hover:text-accent pointer-coarse:min-h-[40px]"
          >
            Home
          </Link>
        </li>
        {normalized.map((item, index) => {
          const isLast = index === normalized.length - 1;
          return (
            <li key={item.url || index} className="flex items-center gap-1.5">
              <span aria-hidden="true">/</span>
              {isLast ? (
                <span
                  className="inline-flex items-center text-foreground-muted pointer-coarse:min-h-[40px]"
                  aria-current="page"
                >
                  {item.name}
                </span>
              ) : (
                <Link
                  href={item.url}
                  className="inline-flex items-center transition-colors hover:text-accent pointer-coarse:min-h-[40px]"
                >
                  {item.name}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumb;
