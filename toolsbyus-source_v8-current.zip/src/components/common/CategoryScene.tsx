import React from "react";
import type { ToolCategory } from "../../lib/tools";

/**
 * A small line drawing per category, for the head of every inner page.
 *
 * The homepage earns its illustration by being the front door. An inner page
 * has a different job — someone arrived here from a search for one specific
 * thing and wants the tool — so these are a quarter of the size, sit beside the
 * title rather than opposite it, and never push the tool below the fold. What
 * they buy is continuity: a visitor who came in on "merge pdf" and never sees
 * the homepage still meets the same hand.
 *
 * Same rules as the hero: one stroke weight, `currentColor`, and the orange
 * only ever on the part of the drawing that is the operation — the arrow that
 * turns one thing into another, or, in the one scene with no arrow, the line
 * that changed.
 * Every scene is built from the shapes its own category actually manipulates —
 * pages for PDF, a framed picture for image, mixing circles and a ramp for
 * colour — rather than from a generic motif with a different icon dropped in
 * the middle.
 *
 * Inline SVG for the same reasons the hero is: a few hundred bytes each, one
 * file per theme instead of two, and no request to make on a page whose whole
 * argument is that it does not make requests.
 *
 * Two rules hold every scene together, and both were being broken:
 *
 * - Nothing crosses the shape that contains it. A horizon belongs on the floor
 *   of its frame, a branch ends on the edge of the box it points at, and a
 *   stroke that runs past either is the thing a reader sees before they see the
 *   picture.
 * - Everything shares one centre line, y = 76 to 79, so the arrows across all
 *   seven scenes sit at the same height as each other and as the H1 beside
 *   them.
 */

const ACCENT = "var(--accent-solid)";

/**
 * The arrow that every "in, then out" scene shares.
 *
 * Drawn once because it was previously drawn six times and three of those had
 * drifted: one shaft overshot its own head by two units, one head sat six units
 * off the scene's centre line, and one pair of arrows crossed. The shaft ends
 * exactly where the head's tip is, which is the whole reason to have it in one
 * place — a tip and a shaft that disagree is the defect that reads, at a
 * glance, as a badly drawn picture.
 *
 * Every arrow occupies exactly x to x + 26 on the centre line y, whichever way
 * it points, so a forward and a return arrow can be given the same span and
 * come out as mirror images instead of as two staggered strokes. `plain` drops
 * the accent, for the leg of a round trip that is not the operation.
 */
const Arrow: React.FC<{ x: number; y: number; back?: boolean; plain?: boolean }> = ({
  x,
  y,
  back = false,
  plain = false,
}) => {
  const stroke = plain ? undefined : ACCENT;
  return back ? (
    <>
      <path d={`M${x + 26} ${y}h-26`} stroke={stroke} />
      <path d={`m${x + 10} ${y - 10}-10 10 10 10`} stroke={stroke} />
    </>
  ) : (
    <>
      <path d={`M${x} ${y}h26`} stroke={stroke} />
      <path d={`m${x + 16} ${y - 10} 10 10-10 10`} stroke={stroke} />
    </>
  );
};

const SCENES: Record<ToolCategory, React.ReactNode> = {
  /** PDF — pages, and the order you put them in. */
  pdf: (
    <>
      <rect x="18" y="30" width="86" height="112" rx="8" />
      <rect x="40" y="16" width="86" height="112" rx="8" fill="var(--bg)" />
      <path d="M60 44h46M60 62h46M60 80h28" />
      <Arrow x={152} y={76} />
      <rect x="214" y="16" width="86" height="126" rx="8" fill="var(--bg)" />
      <path d="M236 44h42M236 62h42M236 80h42M236 98h24" />
    </>
  ),

  /**
   * Image — a picture, and the smaller copy of it.
   *
   * Both horizons now land on the floor of the frame that contains them. They
   * used to end nine and three units below it, so the line broke out through
   * the bottom-right corner of each frame and carried on into white space —
   * which is what the eye reads first, and reads as a mistake, because it is.
   */
  image: (
    <>
      <rect x="18" y="20" width="150" height="112" rx="8" />
      <circle cx="50" cy="48" r="9" />
      <path d="M28 126l36-42 26 30 16-18 40 30" />
      <Arrow x={176} y={76} />
      <rect x="210" y="46" width="88" height="60" rx="6" fill="var(--bg)" />
      <circle cx="228" cy="62" r="5" />
      <path d="M218 102l20-24 14 17 10-11 22 18" />
    </>
  ),

  /**
   * Colour — three channels mixing, and the ramp they resolve to.
   *
   * Three circles overlapping on a triangle: the oldest mark there is for
   * colour, and the only one on this page that cannot be read as something
   * else. Two earlier attempts could. The first was a circle inside a circle
   * with four orange dashes at arbitrary angles and four black ticks at four
   * others — eight marks, no two meaning the same thing, which read as a
   * loading spinner. The second was a proper hue wheel, spokes squared off
   * against the band, and it read as a life ring: a wide ring with a small
   * bright thing on it is a life ring no matter what the geometry says.
   *
   * Circles at r = 30 with centres 36 apart, which is the spacing where the
   * three-way overlap in the middle is large enough to be seen as a shape
   * rather than as a crossing of lines.
   */
  color: (
    <>
      <circle cx="72" cy="60" r="30" />
      <circle cx="54" cy="92" r="30" />
      <circle cx="90" cy="92" r="30" />
      <Arrow x={144} y={76} />
      <rect x="182" y="52" width="120" height="48" rx="6" />
      <path d="M212 52v48M242 52v48M272 52v48" />
    </>
  ),

  /**
   * JSON — a payload, and the tree found inside it.
   *
   * The stem drops from the root and every branch meets a child on its own
   * centre line. Before, the stem ran four units past the last branch and then
   * turned into a stub that stopped in the gap short of the box it was pointing
   * at, so the tree read as three loose rectangles beside a bent line.
   */
  json: (
    <>
      <rect x="18" y="18" width="132" height="118" rx="8" />
      <path d="M46 30c-9 0-11 4-11 11s2 12-9 18c11 6 9 12 9 18s2 11 11 11" />
      <path d="M60 58h62M60 78h44M60 98h62" />
      <Arrow x={166} y={76} />
      <rect x="212" y="22" width="64" height="28" rx="6" />
      <rect x="246" y="62" width="64" height="28" rx="6" />
      <rect x="246" y="102" width="64" height="28" rx="6" />
      <path d="M228 50v66M228 76h18M228 116h18" />
    </>
  ),

  /** Text — two versions, and what changed between them. */
  text: (
    <>
      <rect x="18" y="18" width="130" height="118" rx="8" />
      <rect x="168" y="18" width="130" height="118" rx="8" />
      <path d="M40 46h86M40 66h60M40 106h86" />
      <path d="M190 46h86M190 86h60M190 106h86" />
      <path d="M40 86h60" stroke={ACCENT} />
      <path d="M190 66h60" stroke={ACCENT} />
    </>
  ),

  /**
   * Encoding — bytes in one alphabet, out in another, and back.
   *
   * Two arrows on their own lines, one above the other, sharing the scene's
   * centre. They used to be drawn at the same height with overlapping shafts,
   * so the pair crossed in the middle and read as a single arrow with a spur.
   * The return leg is plain: only the forward operation takes the accent.
   */
  encode: (
    <>
      <rect x="18" y="34" width="104" height="90" rx="8" />
      <path d="M40 62h60M40 80h44M40 98h60" />
      <Arrow x={145} y={66} />
      <Arrow x={145} y={90} back plain />
      <rect x="194" y="34" width="104" height="90" rx="8" />
      <path d="M214 62h28M254 62h24M214 80h44M214 98h60" />
    </>
  ),

  /**
   * Generators — a specification, and the artefact it produces.
   *
   * The artefact is a QR code drawn on a real seven-module grid: three finder
   * squares, one alignment square, and data modules that sit on the grid. The
   * previous version had the three finders and then six zero-length dots at
   * unrelated coordinates, which rendered as specks of dirt on the card.
   */
  generate: (
    <>
      <rect x="18" y="30" width="112" height="96" rx="8" />
      <path d="M40 58h58M40 78h40M40 98h58" />
      <Arrow x={148} y={78} />
      <rect x="204" y="32" width="94" height="94" rx="8" fill="var(--bg)" />
      {/* Finders, then the alignment square: the three-cornered asymmetry is
          what makes a QR code read as a QR code and not as a chequerboard. */}
      <rect x="216" y="44" width="20" height="20" rx="4" />
      <rect x="266" y="44" width="20" height="20" rx="4" />
      <rect x="216" y="94" width="20" height="20" rx="4" />
      <rect x="264" y="92" width="14" height="14" rx="3" />
      {/* Data, on the 10-unit grid the finders are aligned to. */}
      <g fill="currentColor" stroke="none">
        <rect x="247" y="45" width="8" height="8" rx="1.5" />
        <rect x="237" y="55" width="8" height="8" rx="1.5" />
        <rect x="257" y="55" width="8" height="8" rx="1.5" />
        <rect x="217" y="65" width="8" height="8" rx="1.5" />
        <rect x="237" y="65" width="8" height="8" rx="1.5" />
        <rect x="257" y="65" width="8" height="8" rx="1.5" />
        <rect x="277" y="65" width="8" height="8" rx="1.5" />
        <rect x="227" y="75" width="8" height="8" rx="1.5" />
        <rect x="247" y="75" width="8" height="8" rx="1.5" />
        <rect x="267" y="75" width="8" height="8" rx="1.5" />
        <rect x="237" y="85" width="8" height="8" rx="1.5" />
        <rect x="257" y="85" width="8" height="8" rx="1.5" />
        <rect x="247" y="95" width="8" height="8" rx="1.5" />
        <rect x="237" y="105" width="8" height="8" rx="1.5" />
        {/* The cell at (4, 6) is deliberately empty: a module there touches the
            corner of the alignment square, and two shapes meeting at a corner
            is the one thing that looks like a rendering fault rather than
            data. */}
      </g>
    </>
  ),
};

export const CategoryScene: React.FC<{ category: ToolCategory; className?: string }> = ({
  category,
  className = "",
}) => (
  <svg
    viewBox="0 0 316 152"
    className={className}
    fill="none"
    aria-hidden="true"
    focusable="false"
    role="presentation"
  >
    <g
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      vectorEffect="non-scaling-stroke"
    >
      {SCENES[category]}
    </g>
  </svg>
);

export default CategoryScene;
