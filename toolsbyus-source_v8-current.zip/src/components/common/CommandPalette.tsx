"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ACTIVE_CATEGORIES, TOOLS, INFO_PAGES, categoryOf } from "../../lib/tools";
import { Icon } from "./Icon";

/** Dispatch this on `window` to open the palette from anywhere. */
export const OPEN_PALETTE_EVENT = "ycd:open-palette";

interface Command {
  id: string;
  label: string;
  hint: string;
  badge?: string;
  group: "Tools" | "Pages" | "Actions";
  /** Lower-cased haystack the query is matched against. */
  search: string;
  run: () => void;
}

/**
 * Subsequence match, the behaviour developers expect from a fuzzy finder:
 * "schm" finds "JSON Schema Generator" because the letters appear in order.
 * Returns a score so better matches sort first, or null for no match.
 *
 * Contiguity is scored quadratically, which is what makes the ranking useful.
 * A linear score plus a word-boundary bonus ranked "JSON Minifier" above
 * "JSON Schema Generator" for "schm", because the letters happened to land on
 * word starts scattered through its keyword list while "sch" sat contiguously
 * in the actual name. Rewarding runs by their square makes a solid run beat any
 * number of coincidental single-letter hits.
 */
function fuzzyScore(haystack: string, needle: string): number | null {
  if (!needle) return 0;

  let score = 0;
  let index = 0;
  let runLength = 0;
  let lastHit = -2;

  for (const char of needle) {
    index = haystack.indexOf(char, index);
    if (index === -1) return null;

    if (index === lastHit + 1) {
      runLength++;
    } else {
      // Bank the finished run, then start a new one.
      score += runLength * runLength;
      runLength = 1;
    }
    // A hit at the start of a word is still worth something, just not enough to
    // outweigh a real run.
    if (index === 0 || haystack[index - 1] === " " || haystack[index - 1] === "-") score += 2;

    lastHit = index;
    index++;
  }
  score += runLength * runLength;

  // Among equally good matches, prefer the shorter target.
  return score - haystack.length * 0.01;
}

/**
 * Rank a command against the query.
 *
 * The name is matched separately from the full keyword text and weighted far
 * more heavily, so typing a tool's actual name always surfaces that tool rather
 * than one whose synonym list happens to contain the same letters.
 */
function scoreCommand(command: Command, needle: string): number | null {
  const label = command.label.toLowerCase();
  const nameScore = fuzzyScore(label, needle);
  const textScore = fuzzyScore(command.search, needle);

  if (nameScore === null && textScore === null) return null;

  // A literal substring hit is a far stronger signal than any scattered
  // subsequence and is ranked above it outright. Without this, "tree" matched
  // "Terms of Service" letter by letter and outranked the JSON Editor, whose
  // keywords contain the whole word.
  let bonus = 0;
  if (label.includes(needle)) bonus += 1000;
  else if (command.search.includes(needle)) bonus += 500;

  return bonus + (nameScore ?? 0) * 2 + (textScore ?? 0);
}

/**
 * Command palette, opened with Cmd/Ctrl+K.
 *
 * Ten tools is more than a nav bar can hold without a dropdown, and a developer
 * who knows where they are going should not have to reach for the mouse. The
 * palette is also where the keyboard shortcuts are documented, so the site
 * teaches its own interface rather than hiding it.
 */
export const CommandPalette: React.FC = () => {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  // Restores focus to wherever the user was when the palette closes.
  const previouslyFocused = useRef<HTMLElement | null>(null);

  // Closing only changes state. Focus restoration happens in the effect below,
  // because `close` is reachable from the command objects built during render,
  // and reading a ref along that path is not render-safe.
  const close = useCallback(() => {
    setOpen(false);
    setQuery("");
    setActiveIndex(0);
  }, []);

  const commands = useMemo<Command[]>(() => {
    const go = (href: string) => () => {
      close();
      router.push(href);
    };

    return [
      ...TOOLS.map((tool) => ({
        id: tool.href,
        label: tool.title,
        hint: tool.description,
        badge: tool.tag,
        group: "Tools" as const,
        // The category name and label are part of the search text, so typing
        // "pdf" or "image" surfaces a whole section rather than only the tools
        // whose names happen to contain the word.
        search: `${tool.title} ${tool.name} ${tool.description} ${tool.category} ${
          categoryOf(tool.category)?.label ?? ""
        } ${tool.group} ${tool.keywords.join(" ")}`.toLowerCase(),
        run: go(tool.href),
      })),
      ...ACTIVE_CATEGORIES.map((category) => ({
        id: category.hub,
        label: category.title,
        hint: category.blurb,
        group: "Pages" as const,
        search: `${category.title} ${category.label} ${category.blurb} all ${category.id} tools`.toLowerCase(),
        run: go(category.hub),
      })),
      ...INFO_PAGES.map((page) => ({
        id: page.href,
        label: page.name,
        hint: page.description,
        group: "Pages" as const,
        search: `${page.name} ${page.description}`.toLowerCase(),
        run: go(page.href),
      })),
      {
        id: "theme",
        label: "Toggle theme",
        hint: "Switch between the light and dark palette",
        group: "Actions" as const,
        search: "toggle theme dark light mode appearance",
        run: () => {
          close();
          const root = document.documentElement;
          const next = root.classList.contains("dark") ? "light" : "dark";
          try {
            localStorage.setItem("ycd_theme", next);
          } catch {
            // Persistence is a convenience; the toggle still works without it.
          }
          root.classList.toggle("dark", next === "dark");
        },
      },
    ];
  }, [router, close]);

  const results = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matched = !needle
      ? commands
      : commands
          .map((command) => ({ command, score: scoreCommand(command, needle) }))
          .filter((entry): entry is { command: Command; score: number } => entry.score !== null)
          .sort((a, b) => b.score - a.score)
          .map((entry) => entry.command);

    // Attach the group heading here rather than tracking a `lastGroup`
    // variable while mapping in JSX. Derived by comparing with the previous
    // entry, so the whole computation stays a pure function of `matched` and
    // is safe to replay under concurrent rendering.
    return matched.map((command, index) => ({
      command,
      index,
      startsGroup: index === 0 || matched[index - 1].group !== command.group,
    }));
  }, [commands, query]);

  // Open with Cmd/Ctrl+K from anywhere; close with Escape.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        previouslyFocused.current = document.activeElement as HTMLElement;
        setOpen((wasOpen) => !wasOpen);
        return;
      }

      // "/" is a familiar search shortcut, but only when not already typing.
      const target = event.target as HTMLElement | null;
      const isTyping =
        target?.tagName === "INPUT" ||
        target?.tagName === "TEXTAREA" ||
        target?.isContentEditable;
      if (event.key === "/" && !isTyping && !open) {
        event.preventDefault();
        previouslyFocused.current = document.activeElement as HTMLElement;
        setOpen(true);
      }
    };

    // The header's search button opens the palette through this event, so the
    // feature is discoverable by sight and not only by knowing the shortcut.
    const onOpenRequest = () => {
      previouslyFocused.current = document.activeElement as HTMLElement;
      setOpen(true);
    };

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener(OPEN_PALETTE_EVENT, onOpenRequest);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener(OPEN_PALETTE_EVENT, onOpenRequest);
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      inputRef.current?.focus();
      return;
    }
    // Returning focus to the trigger is what makes the palette usable with a
    // keyboard: without it, dismissing sends focus back to <body> and the next
    // Tab starts from the top of the page.
    const origin = previouslyFocused.current;
    previouslyFocused.current = null;
    origin?.focus();
  }, [open]);

  // Keep the highlighted row in view when navigating by keyboard.
  useEffect(() => {
    listRef.current
      ?.querySelector('[data-active="true"]')
      ?.scrollIntoView({ block: "nearest" });
  }, [activeIndex, query]);

  if (!open) return null;

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "Escape") {
      event.preventDefault();
      close();
      return;
    }
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((i) => (results.length ? (i + 1) % results.length : 0));
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((i) => (results.length ? (i - 1 + results.length) % results.length : 0));
      return;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      results[activeIndex]?.command.run();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-start justify-center bg-scrim px-4 pt-[12vh]"
      role="presentation"
      onClick={(event) => {
        if (event.target === event.currentTarget) close();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        onKeyDown={onKeyDown}
        className="w-full max-w-xl overflow-hidden rounded-lg border border-border bg-surface shadow-pop"
      >
        <div className="flex items-center gap-3 px-4 border-b border-border">
          <Icon name="search" size="md" className="text-foreground-subtle" />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setActiveIndex(0);
            }}
            placeholder="Search tools and actions…"
            aria-label="Search tools and actions"
            aria-controls="command-palette-results"
            className="flex-1 bg-transparent py-3.5 text-sm text-foreground placeholder-foreground-muted focus:outline-none font-mono"
          />
          <kbd className="hidden sm:block flex-none text-2xs font-mono text-foreground-muted border border-border rounded px-1.5 py-0.5">
            esc
          </kbd>
        </div>

        <ul
          ref={listRef}
          id="command-palette-results"
          role="listbox"
          aria-label="Results"
          className="max-h-[52vh] overflow-y-auto py-2"
        >
          {results.length === 0 && (
            <li className="px-4 py-6 text-center text-xs text-foreground-muted font-mono">
              Nothing matches “{query}”.
            </li>
          )}

          {results.map(({ command, index, startsGroup }) => {
            return (
              <React.Fragment key={command.id}>
                {startsGroup && (
                  <li
                    aria-hidden="true"
                    className="px-4 pt-3 pb-1 text-2xs font-mono text-foreground-muted"
                  >
                    {command.group}
                  </li>
                )}
                <li role="option" aria-selected={index === activeIndex}>
                  <button
                    type="button"
                    data-active={index === activeIndex}
                    onMouseEnter={() => setActiveIndex(index)}
                    onClick={command.run}
                    className={`w-full text-left px-4 py-2.5 pointer-coarse:py-3.5 flex items-center gap-3 transition-colors cursor-pointer ${
                      index === activeIndex ? "bg-surface-elevated" : "hover:bg-surface-elevated"
                    }`}
                  >
                    <span className="min-w-0 flex-1">
                      <span
                        className={`block text-sm font-medium font-mono truncate ${
                          index === activeIndex ? "text-accent" : "text-foreground"
                        }`}
                      >
                        {command.label}
                      </span>
                      <span className="block text-xs text-foreground-muted truncate">
                        {command.hint}
                      </span>
                    </span>
                    {command.badge && (
                      <span className="flex-none text-2xs font-mono px-1.5 py-0.5 rounded bg-surface-elevated text-accent border border-border">
                        {command.badge}
                      </span>
                    )}
                  </button>
                </li>
              </React.Fragment>
            );
          })}
        </ul>

        <div className="flex items-center gap-4 px-4 py-2.5 border-t border-border text-2xs font-mono text-foreground-muted">
          <span>
            <kbd className="border border-border rounded px-1">↑</kbd>{" "}
            <kbd className="border border-border rounded px-1">↓</kbd> navigate
          </span>
          <span>
            <kbd className="border border-border rounded px-1">↵</kbd> open
          </span>
          <span className="ml-auto hidden sm:inline">
            <kbd className="border border-border rounded px-1">⌘</kbd>
            <kbd className="border border-border rounded px-1">K</kbd> anywhere
          </span>
        </div>
      </div>
    </div>
  );
};

export default CommandPalette;
