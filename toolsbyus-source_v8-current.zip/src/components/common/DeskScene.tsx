import React from "react";

/** Code-native line artwork based on the supplied desk reference.
 * Fixed viewBox, no filters, bitmap downloads, animation, or client JS. */
export const DeskScene: React.FC<{ className?: string }> = ({ className = "" }) => (
  <svg viewBox="0 0 920 610" className={className} fill="none" aria-hidden="true" focusable="false">
    <g stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      {/* Four elbow connections terminate at the monitor. */}
      <path d="M226 158h34q16 0 16 16v108q0 16 16 16h29M226 388h34q16 0 16-16v-36q0-16 16-16h29M694 158h-34q-16 0-16 16v108q0 16-16 16h-29M694 388h-34q-16 0-16-16v-36q0-16-16-16h-29" />
      <g stroke="var(--accent-solid)">
        <circle cx="226" cy="158" r="5" fill="var(--bg)" />
        <circle cx="226" cy="388" r="5" fill="var(--bg)" />
        <circle cx="694" cy="158" r="5" fill="var(--bg)" />
        <circle cx="694" cy="388" r="5" fill="var(--bg)" />
        <path d="M307 298h14M307 320h14M599 298h14M599 320h14" />
      </g>
      {/* PDF with a folded corner and a small progress indicator. */}
      <path d="M77 112v115q0 7 7 7h73" stroke="var(--accent-solid)" />
      <path d="M91 104h47l27 27v88q0 7-7 7H91q-7 0-7-7V111q0-7 7-7Z" fill="var(--bg)" />
      <path d="M138 104v21q0 6 6 6h21" fill="var(--accent-soft)" />
      <rect x="58" y="250" width="112" height="13" rx="6.5" />
      <path d="M65 256.5h65" strokeWidth="5" />
      <path d="m180 253 6 6 13-14" stroke="var(--accent-solid)" />
      {/* Image selection: the mountain strokes stay within the frame. */}
      <rect x="725" y="112" width="139" height="114" />
      <circle cx="769" cy="145" r="10" stroke="var(--accent-solid)" />
      <path d="m735 208 30-36 24 25 27-48 38 59" />
      <path d="m803 172 9 7 8-8 9 7" stroke="var(--accent-solid)" />
      <g fill="var(--bg)">
        <rect x="720" y="107" width="10" height="10" />
        <rect x="720" y="221" width="10" height="10" />
        <rect x="859" y="221" width="10" height="10" />
      </g>
      <circle cx="864" cy="112" r="6" fill="var(--accent-solid)" stroke="var(--accent-solid)" />
      {/* Text selection and JSON tree. */}
      <path d="M58 379h132M58 398h91M58 417h43M58 436h132M58 455h100" />
      <rect x="110" y="411" width="86" height="12" rx="6" fill="var(--accent-soft)" stroke="var(--accent-solid)" />
      <path d="M117 417h71" />
      <path d="m175 447 4 23 6-7 9-1Z" fill="var(--accent-solid)" stroke="var(--accent-solid)" />
      <path d="M745 369q-13 0-13 13v13q0 13-12 13 12 0 12 13v13q0 13 13 13M846 369q13 0 13 13v13q0 13 12 13-12 0-12 13v13q0 13-13 13" stroke="var(--accent-solid)" strokeWidth="4" />
      <path d="M766 384h35M782 402h49M782 420h29M766 438h35M756 383v55M756 402h15M756 420h15" />
      <g fill="var(--accent-solid)" stroke="none"><circle cx="815" cy="384" r="3" /><circle cx="842" cy="402" r="3" /><circle cx="825" cy="420" r="3" /></g>
      {/* Monitor behind the figure; desk behind the chair. */}
      <rect x="300" y="213" width="320" height="225" rx="10" fill="var(--bg)" />
      <path d="M313 227h294v180H313Z" />
      <path d="M300 420h320M442 438v31M478 438v31M418 472h84" />
      <circle cx="460" cy="220" r="1.5" fill="currentColor" stroke="none" />
      <path d="M205 475h510l44 65H161ZM161 540v16h598v-16M183 556v40M205 556v40M715 556v40M737 556v40" fill="var(--bg)" />
      {/* Desk objects keep a clear silhouette at compact sizes. */}
      <path d="M229 474v-37M229 457q-27-4-27-31 24 3 27 31ZM229 442q22-3 23-28-21 3-23 28ZM229 470q23-2 31-23-23-1-31 23Z" />
      <path d="M212 473h36l-6 32q-13 7-24 0Z" fill="var(--bg)" />
      <ellipse cx="230" cy="473" rx="18" ry="4" fill="var(--bg)" />
      <path d="M646 479v34q17 9 33 0v-34M679 487h4q15 0 10 15-3 8-14 6" fill="var(--bg)" />
      <ellipse cx="662.5" cy="479" rx="16.5" ry="5" fill="var(--bg)" />
      <path d="m704 471-5-36 5-2 8 38M714 471l6-42 5 1-7 41M699 471h24v27q-12 6-24 0Z" fill="var(--bg)" />
      <path d="M328 493h264l13 30H315Z" fill="var(--bg)" />
      <path d="M334 501h38M329 511h39M548 501h38M550 511h40" />
      {/* Back of a seated person: neck, shoulders, arms, then the chair. */}
      <path d="M442 382v30M478 382v30" />
      <path d="M460 407q-64 0-83 40l-30 65 25 15 13-21 4 52h142l4-52 13 21 25-15-30-65q-19-40-83-40Z" fill="var(--bg)" />
      <path d="M420 339q-8-9-8 5t12 20M500 339q8-9 8 5t-12 20" fill="var(--bg)" />
      <path d="M418 302q-5 12 1 47 6 35 23 42l18-5 18 5q19-12 23-48 2-20-3-30l5 2q-6-35-43-37-15 0-23 11l-5-7-3 11Z" fill="var(--bg)" />
      <path d="m384 595 9-102q2-31 34-31h66q32 0 34 31l9 102" fill="var(--bg)" />
      <path d="M397 490q4-19 30-19h66q26 0 30 19" />
    </g>
    <g fill="currentColor" fontFamily="Arial, Helvetica, sans-serif" fontSize="24" fontWeight="500" letterSpacing="1.5">
      <text x="89" y="80">PDF</text><text x="737" y="80">IMAGE</text>
      <text x="79" y="348">TEXT</text><text x="759" y="343">JSON</text>
      <text x="98" y="181" fontSize="23" letterSpacing="0">PDF</text>
    </g>
  </svg>
);
export default DeskScene;
