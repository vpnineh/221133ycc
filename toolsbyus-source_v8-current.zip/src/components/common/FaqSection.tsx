import React from "react";
import { Icon } from "./Icon";

export interface FaqItem {
  question: string;
  answer: string;
}

interface FaqSectionProps {
  items?: FaqItem[];
  faqs?: FaqItem[];
}

/**
 * Accordion built on native <details>/<summary>.
 *
 * This deliberately is not a React-state accordion. The previous version only
 * mounted the answer for the open item, so a statically exported page shipped
 * exactly one answer in its HTML and hid the rest behind hydration. Search and
 * AI crawlers that read the served markup — most of them do not execute JS —
 * saw a page of unanswered questions. <details> keeps every answer in the DOM,
 * collapses without JavaScript, and is keyboard accessible for free.
 */
export const FaqSection: React.FC<FaqSectionProps> = ({ items, faqs }) => {
  const faqList = faqs || items || [];
  if (faqList.length === 0) return null;

  return (
    <section aria-labelledby="faq-heading">
      <h2
        id="faq-heading"
        className="heading-hash"
      >
        Frequently asked questions
      </h2>

      <div className="mt-4 divide-y divide-border overflow-hidden rounded-lg border border-border bg-surface">
        {faqList.map((item, idx) => (
          <details key={idx} open={idx === 0} className="group">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 text-sm font-medium text-foreground transition-colors hover:bg-surface-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent [&::-webkit-details-marker]:hidden">
              <span>{item.question}</span>
              <Icon
                name="chevronDown"
                size="md"
                className="text-foreground-subtle transition-transform group-open:rotate-180"
              />
            </summary>
            <div className="border-t border-border px-4 py-3">
              <p className="text-sm leading-relaxed text-foreground-muted">{item.answer}</p>
            </div>
          </details>
        ))}
      </div>
    </section>
  );
};

export default FaqSection;
