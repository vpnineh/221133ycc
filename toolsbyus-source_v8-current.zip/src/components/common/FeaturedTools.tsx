"use client";

import React, { useRef, useState } from "react";
import Link from "next/link";
import { Icon, type IconName } from "./Icon";

export interface FeaturedTool {
  href: string;
  name: string;
  description: string;
  icon: IconName;
}

export interface FeaturedGroup {
  id: string;
  label: string;
  /** Where the full category lives, for the link at the end of the panel. */
  hub: string;
  hubLabel: string;
  tools: FeaturedTool[];
}

/**
 * The homepage's answer to "what are you working on?".
 *
 * A tab strip over a two-column list, and the reason it is tabs rather than
 * seven stacked sections is arrival: almost everyone here came from a search
 * for one specific job, and the fastest thing the page can do is show six
 * neighbours of that job without a scroll. Seven sections would be the same
 * information at four times the height.
 *
 * Every panel's markup is in the HTML and the inactive ones are `hidden`, not
 * unmounted. That is not an optimisation — it is what lets a crawler that never
 * runs a script, and a reader with JavaScript disabled, still find every link
 * on this page.
 *
 * The rules between rows are structure rather than ornament: they are what
 * makes six links read as one comparable set instead of six cards competing
 * for attention. There are no boxes here for the same reason.
 *
 * The heading is passed as text rather than as an element. It used to arrive as
 * a ready-made `<h2>` in a prop, which is how the page came to log "each child
 * in a list should have a unique key" against a heading that is not in a list:
 * React validates element-bearing props at the call site, and an element sitting
 * beside a mapped array in the same children position trips it. Strings in,
 * markup here.
 */
export const FeaturedTools: React.FC<{
  groups: FeaturedGroup[];
  total: number;
  heading: string;
  headingId: string;
}> = ({ groups, total, heading, headingId }) => {
  const [active, setActive] = useState(groups[0]?.id ?? "");
  const stripRef = useRef<HTMLDivElement>(null);

  /** Keep the category strip below the sticky header; respect reduced motion. */
  const select = (id: string) => {
    setActive(id);

    const strip = stripRef.current;
    if (!strip) return;

    // 4.5rem of sticky header, plus a little air above the strip.
    const headerOffset = 96;
    const delta = strip.getBoundingClientRect().top - headerOffset;
    if (Math.abs(delta) < 4) return;

    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    window.scrollTo({
      top: window.scrollY + delta,
      behavior: reduced ? "auto" : "smooth",
    });
  };

  /** A tablist is expected to move with the arrow keys, so it does. */
  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    const keys = ["ArrowLeft", "ArrowRight", "Home", "End"];
    if (!keys.includes(event.key)) return;
    event.preventDefault();

    const index = groups.findIndex((group) => group.id === active);
    const next =
      event.key === "Home"
        ? 0
        : event.key === "End"
          ? groups.length - 1
          : (index + (event.key === "ArrowRight" ? 1 : -1) + groups.length) % groups.length;

    select(groups[next].id);
    stripRef.current?.querySelectorAll<HTMLButtonElement>("[role='tab']")[next]?.focus();
  };

  return (
    <>
      <h2
        id={headingId}
        className="mb-5 mt-12 text-center text-[2rem] font-bold tracking-[-0.035em] text-foreground sm:mt-14 sm:text-[2.75rem]"
      >
        {heading}
      </h2>

      {/* Keep the full directory link discoverable before the category panels. */}
      <p className="mb-10 text-center sm:mb-12">
        <Link
          href="/all-tools"
          className="text-lg font-medium text-accent transition-colors hover:text-accent-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
        >
          Explore all {total} tools →
        </Link>
      </p>

      {/* One horizontally scrollable row preserves the tab relationship on mobile. */}
      <div
        ref={stripRef}
        role="tablist"
        aria-label="Tool categories"
        onKeyDown={onKeyDown}
        className="no-scrollbar -mx-4 flex scroll-mt-24 gap-7 overflow-x-auto border-b border-border px-4 sm:mx-0 sm:justify-center sm:px-0"
      >
        {groups.map((group) => {
          const selected = group.id === active;
          return (
            <button
              key={group.id}
              type="button"
              role="tab"
              id={`tab-${group.id}`}
              aria-selected={selected}
              aria-controls={`panel-${group.id}`}
              tabIndex={selected ? 0 : -1}
              onClick={() => select(group.id)}
              className={`-mb-px flex-none cursor-pointer border-b-2 pb-3.5 pt-1 text-[0.9375rem] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent sm:text-base ${
                selected
                  ? "border-accent-solid font-semibold text-foreground"
                  : "border-transparent text-foreground-muted hover:text-foreground"
              }`}
            >
              {group.label}<span className="ml-1.5 text-xs text-foreground-subtle">{group.tools.length}</span>
            </button>
          );
        })}
      </div>

      <div>
        {groups.map((group) => (
          <div
            key={group.id}
            role="tabpanel"
            id={`panel-${group.id}`}
            aria-labelledby={`tab-${group.id}`}
            tabIndex={0}
            hidden={group.id !== active}
          >
            <ul className="grid grid-cols-1 sm:grid-cols-2">
              {group.tools.map((tool, index) => (
                <li
                  key={tool.href}
                  className={`border-border ${index > 0 ? "border-t" : ""} ${
                    // In two columns the first *two* start a row, and every even
                    // item takes the vertical rule that separates the columns.
                    index === 1 ? "sm:border-t-0" : ""
                  } ${index % 2 === 1 ? "sm:border-l sm:pl-6 lg:pl-10" : "sm:pr-6 lg:pr-10"}`}
                >
                  <Link
                    href={tool.href}
                    className="group flex h-full items-start gap-5 py-6 transition-opacity hover:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent sm:gap-6"
                  >
                    <Icon name={tool.icon} size="2xl" accent className="mt-0.5 text-foreground" />
                    <span className="min-w-0">
                      <span className="block text-lg font-semibold tracking-[-0.02em] text-foreground">
                        {tool.name}
                      </span>
                      <span className="mt-1 line-clamp-2 block text-[0.9375rem] leading-relaxed text-foreground-muted">
                        {tool.description}
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>

            {/* The way into the rest of this category, from the category you
                are already looking at — which keeps each hub one click from
                the root. */}
            <p className="mt-9 text-center text-sm">
              <Link
                href={group.hub}
                className="text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                {group.hubLabel}
              </Link>
            </p>
          </div>
        ))}
      </div>
    </>
  );
};

export default FeaturedTools;
