import React from "react";
import Link from "next/link";
import { ACTIVE_CATEGORIES, TOOLS, toolsInCategory } from "../../lib/tools";

/**
 * A footer that carries the hubs and then gets out of the way.
 *
 * The previous one listed all seventy-one tools in seven columns on every page.
 * That was internal linking done by weight rather than by structure, and it
 * added roughly a screen of grey text underneath a set of tools whose whole
 * argument is that they are quick. The header's panel already ships every
 * category and the first seven tools of each in the static HTML of every page,
 * so a crawler loses nothing; what is left here is the seven hubs, which are
 * the pages worth passing weight to, and the four links a person actually looks
 * in a footer for.
 */
const LEGAL = [
  { href: "/all-tools", label: "All tools" },
  { href: "/about", label: "About" },
  { href: "/privacy", label: "Privacy" },
  { href: "/terms", label: "Terms" },
];

export const Footer: React.FC = () => (
  <footer className="mt-8 w-full border-t border-border">
    <div className="shell py-10">
      <nav aria-label="Tool categories" className="flex flex-wrap gap-x-7 gap-y-3">
        {ACTIVE_CATEGORIES.map((category) => (
          <Link
            key={category.id}
            href={category.hub}
            className="flex items-baseline gap-1.5 text-sm text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            {category.title}
            <span className="text-2xs text-foreground-subtle">
              {toolsInCategory(category.id).length}
            </span>
          </Link>
        ))}
      </nav>

      <div className="mt-9 flex flex-col gap-6 border-t border-border pt-7 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Link
            href="/"
            className="text-[1.1875rem] font-bold leading-none tracking-[-0.035em] text-foreground transition-opacity hover:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            ToolsByUs
          </Link>
          <p className="mt-2 text-sm text-foreground-muted">
            {TOOLS.length} simple tools for everyday tasks.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-foreground-muted sm:justify-end">
          <nav aria-label="Site" className="flex flex-wrap items-center gap-x-6 gap-y-3">
            {LEGAL.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <span className="text-foreground-subtle">© 2026 ToolsByUs.</span>
        </div>
      </div>
    </div>
  </footer>
);
