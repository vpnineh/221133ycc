"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "./ThemeToggle";
import { Icon } from "./Icon";
import { Logo } from "./Logo";
import { ACTIVE_CATEGORIES, TOOLS, toolsInCategory } from "../../lib/tools";
import { OPEN_PALETTE_EVENT } from "./CommandPalette";

const panelId = (id: string) => id === "all" ? "tools-menu" : `menu-${id}`;
const triggerId = (id: string) => id === "all" ? "tools-menu-trigger" : `trigger-${id}`;
const REVEAL = ["hidden lg:flex", "hidden lg:flex", "hidden xl:flex", "hidden 2xl:flex"];
const iconButton = "inline-flex h-10 w-10 shrink-0 cursor-pointer items-center justify-center rounded-full border border-border-strong bg-surface text-foreground transition-colors hover:border-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:h-11 pointer-coarse:w-11";
const surface = "rounded-2xl border border-border bg-surface shadow-pop";
const focusRing = "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent";

export const Header: React.FC = () => {
  const pathname = usePathname();
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [menuPathname, setMenuPathname] = useState(pathname);
  const navRef = useRef<HTMLElement>(null);
  const mobileRef = useRef<HTMLButtonElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hoverOpened = useRef(false);
  const pendingFocus = useRef<string | null>(null);
  const cancelTimer = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  }, []);
  const closeMenu = useCallback(() => {
    cancelTimer(); hoverOpened.current = false; pendingFocus.current = null; setOpenMenu(null);
  }, [cancelTimer]);
  const scheduleOpen = (event: React.PointerEvent, id: string) => {
    if (event.pointerType !== "mouse") return;
    cancelTimer();
    timer.current = setTimeout(() => { hoverOpened.current = true; setOpenMenu(id); }, 120);
  };
  const scheduleClose = (event: React.PointerEvent) => {
    if (event.pointerType !== "mouse") return;
    cancelTimer(); timer.current = setTimeout(closeMenu, 180);
  };
  useEffect(() => () => cancelTimer(), [cancelTimer]);
  useEffect(() => {
    cancelTimer(); hoverOpened.current = false; pendingFocus.current = null;
  }, [pathname, cancelTimer]);
  useEffect(() => {
    if (!openMenu) return;
    if (pendingFocus.current === openMenu) {
      navRef.current?.querySelector<HTMLElement>(`#${panelId(openMenu)} a`)?.focus();
      pendingFocus.current = null;
    }
    const outside = (event: PointerEvent | FocusEvent) => {
      if (!navRef.current?.contains(event.target as Node)) closeMenu();
    };
    const escape = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      closeMenu(); document.getElementById(triggerId(openMenu))?.focus();
    };
    document.addEventListener("pointerdown", outside);
    document.addEventListener("focusin", outside);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", outside);
      document.removeEventListener("focusin", outside);
      document.removeEventListener("keydown", escape);
    };
  }, [openMenu, closeMenu]);
  useEffect(() => {
    if (!mobileMenuOpen) return;
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setMobileMenuOpen(false); mobileRef.current?.focus(); }
    };
    document.addEventListener("keydown", escape);
    return () => document.removeEventListener("keydown", escape);
  }, [mobileMenuOpen]);
  if (menuPathname !== pathname) {
    setMenuPathname(pathname); setOpenMenu(null); setMobileMenuOpen(false);
  }
  const categoryActive = (id: string, hub: string) => pathname === hub || TOOLS.some(t => t.category === id && t.href === pathname);
  const linkClass = (active: boolean) => `flex min-h-9 pointer-coarse:min-h-11 items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm leading-5 transition-colors ${focusRing} ${active ? "bg-accent-soft font-medium text-accent" : "text-foreground-muted hover:bg-surface-elevated hover:text-foreground"}`;
  const trigger = (id: string, label: string, active: boolean) => <button
    type="button" id={triggerId(id)} aria-expanded={openMenu === id} aria-controls={panelId(id)} aria-current={active ? "true" : undefined} data-active={active || undefined}
    onFocus={() => { cancelTimer(); if (openMenu && openMenu !== id) closeMenu(); }}
    onClick={() => { cancelTimer(); const fromHover = hoverOpened.current; hoverOpened.current = false; setOpenMenu(current => current === id && !fromHover ? null : id); }}
    onKeyDown={event => {
      if (event.key !== "ArrowDown") return;
      event.preventDefault(); cancelTimer();
      if (openMenu === id) document.querySelector<HTMLElement>(`#${panelId(id)} a`)?.focus();
      else { pendingFocus.current = id; setOpenMenu(id); }
    }}
    className={`flex min-h-11 cursor-pointer items-center gap-1 whitespace-nowrap rounded-md text-sm font-medium ${focusRing} ${active ? "text-accent" : openMenu === id ? "text-foreground" : "text-foreground-muted hover:text-foreground"}`}>
    {label}<Icon name="chevronDown" size="sm" className={`transition-transform ${openMenu === id ? "rotate-180" : ""}`} />
  </button>;
  const toolLinks = (categoryId: string, limit?: number) => toolsInCategory(categoryId as typeof ACTIVE_CATEGORIES[number]["id"]).slice(0, limit).map(tool => <li key={tool.href}>
    <Link href={tool.href} prefetch={false} onClick={() => { closeMenu(); setMobileMenuOpen(false); }} aria-current={pathname === tool.href ? "page" : undefined} className={linkClass(pathname === tool.href)}>
      <Icon name={tool.icon} size="md" className="shrink-0" /><span>{tool.name}</span>
    </Link>
  </li>);
  return <header className="sticky top-0 z-40 w-full border-b border-border bg-background">
    <div className="shell relative flex h-[4.5rem] items-center justify-between gap-4">
      <Link href="/" aria-label="ToolsByUs — home" className={`flex h-11 shrink-0 items-center rounded ${focusRing}`}><Logo /></Link>
      <div className="flex items-center gap-4 lg:gap-6">
        <nav ref={navRef} aria-label="Primary" className="hidden items-center gap-5 md:flex xl:gap-6" onPointerLeave={scheduleClose} onPointerEnter={cancelTimer}>
          <div onPointerEnter={event => scheduleOpen(event, "all")}>
            {trigger("all", "All tools", pathname === "/all-tools")}
            <div id="tools-menu" hidden={openMenu !== "all"} className="absolute inset-x-0 top-full pt-2" onPointerEnter={cancelTimer}>
              <div className={`${surface} grid max-h-[calc(100dvh-6rem)] grid-cols-2 gap-x-6 gap-y-5 overflow-y-auto overscroll-contain p-5 lg:grid-cols-4`}>
                {ACTIVE_CATEGORIES.map(category => <div key={category.id} className="min-w-0">
                  <Link href={category.hub} onClick={closeMenu} className={`mb-2 flex items-baseline gap-2 rounded px-2.5 text-sm font-semibold ${focusRing} ${categoryActive(category.id, category.hub) ? "text-accent" : "text-foreground hover:text-accent"}`}>
                    {category.label}<span className="text-xs font-normal text-foreground-subtle">{toolsInCategory(category.id).length}</span>
                  </Link>
                  <ul>{toolLinks(category.id, 6)}</ul>
                  {toolsInCategory(category.id).length > 6 && <Link href={category.hub} onClick={closeMenu} className={`mt-1 block rounded px-2.5 py-2 text-sm text-accent ${focusRing}`}>All {category.label.toLowerCase()} tools →</Link>}
                </div>)}
                <Link href="/all-tools" onClick={closeMenu} className={`${linkClass(false)} self-start bg-surface-elevated`}>Browse all {TOOLS.length} tools <Icon name="arrowRight" size="sm" /></Link>
              </div>
            </div>
          </div>
          {ACTIVE_CATEGORIES.map((category, index) => <div key={category.id} className={`relative ${REVEAL[index] ?? "hidden 2xl:flex"}`} onPointerEnter={event => scheduleOpen(event, category.id)}>
            {trigger(category.id, category.label, categoryActive(category.id, category.hub))}
            <div id={panelId(category.id)} hidden={openMenu !== category.id} className={`absolute right-0 top-full pt-2 ${toolsInCategory(category.id).length > 9 ? "w-[min(36rem,calc(100vw-3rem))]" : "w-72"}`} onPointerEnter={cancelTimer}>
              <div className={`${surface} max-h-[calc(100dvh-6rem)] overflow-y-auto overscroll-contain p-3`}>
                <Link href={category.hub} onClick={closeMenu} className={`mb-2 flex items-baseline gap-2 rounded px-2.5 py-1 text-sm font-semibold text-foreground hover:text-accent ${focusRing}`}>{category.title}<span className="text-xs font-normal text-foreground-subtle">{toolsInCategory(category.id).length}</span></Link>
                <ul className={toolsInCategory(category.id).length > 9 ? "grid grid-cols-2 gap-x-3" : ""}>{toolLinks(category.id)}</ul>
              </div>
            </div>
          </div>)}
          <Link href="/about" aria-current={pathname === "/about" ? "page" : undefined} onFocus={closeMenu} onPointerEnter={closeMenu} className={`rounded text-sm ${focusRing} ${pathname === "/about" ? "font-medium text-accent" : "text-foreground-muted hover:text-foreground"}`}>About</Link>
        </nav>
        <div className="flex items-center gap-2">
          {pathname !== "/" && <button type="button" onClick={() => window.dispatchEvent(new CustomEvent(OPEN_PALETTE_EVENT))} aria-label="Search tools (Command or Control + K)" className={`${iconButton} max-sm:hidden`}><Icon name="search" size="lg" /></button>}
          <ThemeToggle />
          <button ref={mobileRef} type="button" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className={`${iconButton} md:hidden`} aria-label={mobileMenuOpen ? "Close navigation menu" : "Open navigation menu"} aria-expanded={mobileMenuOpen} aria-controls="mobile-navigation"><Icon name={mobileMenuOpen ? "close" : "menu"} size="lg" /></button>
        </div>
      </div>
    </div>
    {mobileMenuOpen && <nav id="mobile-navigation" aria-label="All tools" className="border-t border-border bg-background md:hidden">
      <div className="shell max-h-[calc(100dvh-4.5rem)] overflow-y-auto overscroll-contain pb-8 pt-4">
        <button type="button" onClick={() => { setMobileMenuOpen(false); window.dispatchEvent(new CustomEvent(OPEN_PALETTE_EVENT)); }} className={`${linkClass(false)} mb-2 w-full bg-surface-elevated`}><Icon name="search" size="md" />Search {TOOLS.length} tools</button>
        <Link href="/all-tools" onClick={() => setMobileMenuOpen(false)} className={`${linkClass(pathname === "/all-tools")} mb-4`}>Browse all {TOOLS.length} tools</Link>
        {ACTIVE_CATEGORIES.map(category => <div key={category.id} className="mb-5">
          <Link href={category.hub} onClick={() => setMobileMenuOpen(false)} className={`mb-1 block rounded px-2.5 py-2 text-sm font-semibold ${focusRing} ${categoryActive(category.id, category.hub) ? "text-accent" : "text-foreground"}`}>{category.title}</Link>
          <ul>{toolLinks(category.id)}</ul>
        </div>)}
        <Link href="/about" onClick={() => setMobileMenuOpen(false)} className={linkClass(pathname === "/about")}>About</Link>
      </div>
    </nav>}
  </header>;
};
