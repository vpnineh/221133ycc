"use client";

import React, { useSyncExternalStore } from "react";
import { Icon } from "./Icon";
import { OPEN_PALETTE_EVENT } from "./CommandPalette";

/**
 * Which modifier key to name in the hint.
 *
 * The platform is external state that never changes, so it is read with
 * useSyncExternalStore and a subscribe that never fires, rather than set from
 * an effect. Reading it during render instead would make the server and the
 * first client render disagree, and correcting it in an effect costs a second
 * render pass on every page load for one word.
 */
const subscribeNever = () => () => {};

const clientShortcut = (): string =>
  /mac|iphone|ipad|ipod/i.test(navigator.platform || navigator.userAgent) ? "⌘K" : "Ctrl K";

// The server cannot know. Render the slot empty rather than guess "Ctrl" and
// then swap it — a hint that changes under the reader is worse than a late one.
const serverShortcut = (): string | null => null;

/**
 * The hero's search field is a button, not an input.
 *
 * Typing here opens the command palette, which is where the filtering, the
 * keyboard handling and the results list already live. Rendering a real
 * `<input>` would mean either duplicating all of that or having focus jump into
 * a dialog the moment someone typed a character — which loses the first
 * keystroke and feels broken. A button that opens the palette and hands it the
 * focus keeps one implementation and one behaviour.
 *
 * It still looks like a field because that is what it does. The prompt names a
 * real tool rather than saying "search": someone arriving from a search engine
 * has a task, not a query, and "try merge PDF" tells them what kind of thing
 * this box takes.
 */
export const HeroSearch: React.FC<{ toolCount: number }> = ({ toolCount }) => {
  const shortcut = useSyncExternalStore(subscribeNever, clientShortcut, serverShortcut);

  const open = () => window.dispatchEvent(new CustomEvent(OPEN_PALETTE_EVENT));

  return (
    <button
      type="button"
      onClick={open}
      aria-label={`Search ${toolCount} tools`}
      className="group flex h-[4.25rem] w-full max-w-[28rem] cursor-pointer items-center gap-3 rounded-pill border border-border-strong bg-surface pl-5 pr-2.5 text-left transition-colors hover:border-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background sm:gap-4 sm:pl-6"
    >
      <Icon name="search" size="lg" className="flex-none text-foreground-subtle" />
      <span className="min-w-0 flex-1 truncate text-base text-foreground-muted sm:text-lg">
        Find a tool — try merge PDF
      </span>

      {/* The shortcut is announced, not printed. Beside a 52px orange circle a
          `Ctrl K` chip is one element too many, and the people who use keyboard
          shortcuts are the people who will try ⌘K without being told. */}
      {shortcut && <span className="sr-only">Keyboard shortcut: {shortcut}</span>}

      {/*
        The one filled orange thing above the fold. It is a span rather than a
        nested button — the whole pill is already the control, and a button
        inside a button is invalid markup that also gives a keyboard user two
        tab stops for one action.

        The arrow takes --on-accent rather than white. White on this orange is
        3.5:1, which clears the 3:1 a non-text graphic needs in light mode and
        drops to 2.6:1 against the lighter orange the dark theme uses. One value
        that is correct in both themes beats a value that is correct in the one
        you happened to design in.
      */}
      <span
        aria-hidden="true"
        className="flex h-12 w-12 flex-none items-center justify-center rounded-pill bg-accent-solid text-accent-on transition-colors group-hover:bg-foreground group-hover:text-background sm:h-[3.25rem] sm:w-[3.25rem]"
      >
        <Icon name="arrowRight" size="lg" />
      </span>
    </button>
  );
};

export default HeroSearch;
