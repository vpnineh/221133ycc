import React from "react";

/**
 * The whole icon set, as one component.
 *
 * Deliberately not an icon package. A dependency like @phosphor-icons/react
 * ships thousands of glyphs to pull in the twenty this site uses, and on a
 * static export that is dead weight on every page. These are hand-drawn on the
 * same 24px grid with the same 1.5 stroke, which is the property that actually
 * makes an icon set look like a set.
 *
 * Sizing lives here too, as three tokens rather than a per-call-site guess —
 * mixing 14px, 15px and 18px icons is the most common reason a dense toolbar
 * reads as unpolished.
 *
 * Every icon renders `aria-hidden`. These are decorative: each one sits beside
 * a visible label, or inside a control that carries its own accessible name.
 */

const PATHS = {
  // ---- Tools -------------------------------------------------------------
  /** JSON Diff — two branches converging, the git-compare idiom. */
  diff: (
    <>
      <circle cx="6" cy="6" r="2.25" />
      <circle cx="6" cy="18" r="2.25" />
      <circle cx="18" cy="18" r="2.25" />
      <path d="M6 8.25v7.5M8.25 6H14a2 2 0 0 1 2 2v7.75" />
    </>
  ),
  /** Diff Checker — two text columns side by side. */
  columns: (
    <>
      <rect x="3" y="4" width="7.5" height="16" rx="1.5" />
      <rect x="13.5" y="4" width="7.5" height="16" rx="1.5" />
    </>
  ),
  /** Formatter — indented lines. */
  indent: (
    <>
      <path d="M4 6h16M9 10.5h11M9 15h11M4 19.5h16" />
      <path d="M4 10.5 6.25 12.75 4 15" />
    </>
  ),
  /** Beautifier — collapsed into expanded. */
  expand: (
    <>
      <path d="M4 4h16M4 20h16" />
      <path d="M12 8v8M9 11l3-3 3 3M9 13l3 3 3-3" />
    </>
  ),
  /** Minifier — expanded into collapsed. */
  compress: (
    <>
      <path d="M4 4h16M4 20h16" />
      <path d="M12 7v4M12 17v-4M9 8l3 3 3-3M9 16l3-3 3 3" />
    </>
  ),
  /** Image tools — the universal picture frame with a sun and a horizon. */
  image: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <circle cx="8.5" cy="9" r="1.5" />
      <path d="m4 18 4-4a2 2 0 0 1 2.8 0L16 19M13 16l3-4 5 6" />
    </>
  ),
  /** Crop — the two overlapping rules of a crop mark. */
  crop: (
    <>
      <path d="M6 2v14a2 2 0 0 0 2 2h14" />
      <path d="M2 6h14a2 2 0 0 1 2 2v14" />
    </>
  ),
  /** Resize — a frame with a corner handle being dragged. */
  resize: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2.5" />
      <path d="m8 8 8 8" />
      <path d="M8 12.5V8h4.5M16 11.5V16h-4.5" />
    </>
  ),
  /** Validator — a checked document. */
  checkDoc: (
    <>
      <path d="M13 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-9" />
      <path d="M13 3v5a2 2 0 0 0 2 2h4" />
      <path d="m9 14 2 2 4-4" />
    </>
  ),
  /** Schema Generator — a nested outline. */
  tree: (
    <>
      <rect x="3" y="3.5" width="6" height="5" rx="1" />
      <rect x="14" y="9.5" width="7" height="4.5" rx="1" />
      <rect x="14" y="16.5" width="7" height="4.5" rx="1" />
      <path d="M6 8.5v9.25h8M14 11.75H6" />
    </>
  ),
  /** JSON Editor — braces. */
  braces: (
    <>
      <path d="M9 4c-2 0-2.5 1-2.5 2.5S7 9.5 5 12c2 2.5 1.5 3 1.5 5.5S7 20 9 20" />
      <path d="M15 4c2 0 2.5 1 2.5 2.5S17 9.5 19 12c-2 2.5-1.5 3-1.5 5.5S17 20 15 20" />
    </>
  ),
  /** Base64 & JWT — binary payload. */
  binary: (
    <>
      <rect x="3.5" y="3.5" width="6" height="7" rx="1.5" />
      <rect x="14.5" y="13.5" width="6" height="7" rx="1.5" />
      <path d="M14.5 3.5h3.5v7M17 10.5h3.5M3.5 13.5H7v7M5.5 20.5H9" />
    </>
  ),
  /** UUID Generator — a fingerprint-like identifier. */
  fingerprint: (
    <>
      <path d="M12 4.5a7.5 7.5 0 0 0-7.5 7.5v1.5" />
      <path d="M19.5 13.5V12A7.5 7.5 0 0 0 12 4.5" />
      <path d="M8.25 12a3.75 3.75 0 0 1 7.5 0v3.75" />
      <path d="M12 12v6M15.75 18.75v.75M8.25 12v6.75" />
    </>
  ),

  // ---- Interface ---------------------------------------------------------
  search: (
    <>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m20 20-4.5-4.5" />
    </>
  ),
  chevronDown: <path d="m6 9.5 6 6 6-6" />,
  chevronRight: <path d="m9.5 6 6 6-6 6" />,
  arrowRight: <path d="M4.5 12h15m-6-6 6 6-6 6" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4l-1.4 1.4" />
    </>
  ),
  moon: <path d="M20 14.2A8.2 8.2 0 0 1 9.8 4 8.5 8.5 0 1 0 20 14.2Z" />,
  /** "System" in the theme menu — follow whatever the machine is set to. */
  monitor: (
    <>
      <rect x="2.5" y="4" width="19" height="13" rx="2" />
      <path d="M9 20.5h6M12 17v3.5" />
    </>
  ),
  copy: (
    <>
      <rect x="9" y="9" width="11" height="11" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" transform="translate(2 2)" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  plus: <path d="M12 5v14M5 12h14" />,
  upload: (
    <>
      <path d="M21 15v3.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V15" />
      <path d="M12 15.5V3.5M7.5 8 12 3.5 16.5 8" />
    </>
  ),
  download: (
    <>
      <path d="M21 15v3.5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V15" />
      <path d="M12 3.5v12M7.5 11l4.5 4.5L16.5 11" />
    </>
  ),
  trash: (
    <>
      <path d="M4 6.5h16M9.5 6.5V4.75A1.25 1.25 0 0 1 10.75 3.5h2.5a1.25 1.25 0 0 1 1.25 1.25V6.5" />
      <path d="M6.5 6.5 7.4 19a2 2 0 0 0 2 1.9h5.2a2 2 0 0 0 2-1.9l.9-12.5" />
    </>
  ),
  wrap: (
    <>
      <path d="M4 6.5h16M4 17.5h6" />
      <path d="M4 12h13a3 3 0 1 1 0 6h-2.5" />
      <path d="m13 15.5-2.5 2.5 2.5 2.5" />
    </>
  ),
  wand: (
    <>
      <path d="m4 20 10.5-10.5" />
      <path d="M17 3.5 18 6l2.5 1-2.5 1-1 2.5-1-2.5L13.5 7 16 6l1-2.5Z" />
      <path d="m14.5 9.5 1.5 1.5" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3 5 6v5.5c0 4.3 2.9 8.3 7 9.5 4.1-1.2 7-5.2 7-9.5V6l-7-3Z" />
      <path d="m9.25 12 2 2 3.5-3.75" />
    </>
  ),
  bolt: <path d="M13 3 5.5 13.5H11l-1 7.5 8-11H12.5L13 3Z" />,
  offline: (
    <>
      <path d="M3 8.5a15 15 0 0 1 18 0" />
      <path d="M6.5 12.2a10 10 0 0 1 11 0" />
      <path d="M10 15.8a5 5 0 0 1 4 0" />
      <circle cx="12" cy="19.5" r="0.75" fill="currentColor" stroke="none" />
    </>
  ),
  keyboard: (
    <>
      <rect x="2.5" y="6" width="19" height="12" rx="2" />
      <path d="M6.5 10h.01M10 10h.01M13.5 10h.01M17 10h.01M8 14h8" />
    </>
  ),
  warning: (
    <>
      <path d="M12 4.5 2.8 20h18.4L12 4.5Z" />
      <path d="M12 10v4M12 17h.01" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5.5M12 7.75h.01" />
    </>
  ),

  // ---- Page and file operations ------------------------------------------
  /*
   * These exist because the catalogue outgrew the icon set.
   *
   * The set was drawn for a JSON toolkit and then reused when PDF and image
   * tools arrived, so Split PDF was showing the two-branches diff glyph, Rotate
   * PDF was showing the beautifier's expand arrows, and the QR generator was
   * showing a fingerprint. Every one of those was legible and every one was
   * about a different operation than the page it sat on — which is worse than
   * no icon, because it is a confident wrong answer.
   */
  /** Merge — several streams becoming one. */
  merge: (
    <>
      <path d="M3 6h4a5 5 0 0 1 5 5v1" />
      <path d="M3 18h4a5 5 0 0 0 5-5v-1" />
      <path d="M12 12h7.5" />
      <path d="m16.5 9 3 3-3 3" />
    </>
  ),
  /** Split — one becoming several. The mirror of `merge`, deliberately. */
  split: (
    <>
      <path d="M3 12h4" />
      <path d="M7 12V9a3 3 0 0 1 3-3h4" />
      <path d="M7 12v3a3 3 0 0 0 3 3h4" />
      <path d="m11.5 3.5 2.5 2.5-2.5 2.5M11.5 15.5l2.5 2.5-2.5 2.5" />
    </>
  ),
  /** Rotate — a quarter turn, with the arrowhead that says which way. */
  rotate: (
    <>
      <path d="M20.5 12a8.5 8.5 0 1 1-2.49-6.01" />
      <path d="M20.5 4v5.5H15" />
    </>
  ),
  /** Reorder — rows, and the handle you drag them by. */
  reorder: (
    <>
      <path d="M11 6h10M11 12h10M11 18h10" />
      <path d="M5 4.5v15" />
      <path d="m2.5 7 2.5-2.5L7.5 7M2.5 17l2.5 2.5L7.5 17" />
    </>
  ),
  /** Unlock — the shackle is open, which is the whole point of the tool. */
  unlock: (
    <>
      <rect x="4" y="10.5" width="16" height="10" rx="2.5" />
      <path d="M8 10.5V7.5a4 4 0 0 1 7.7-1.5" />
    </>
  ),
  /** Watermark — a page with a mark laid across it. */
  watermark: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="m8 13.5 4.5-4.5M11 16.5 16 11.5" />
    </>
  ),
  /** Timestamp. */
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5.3l3.4 2" />
    </>
  ),
  /** Cron — a calendar, because a cron expression is a schedule. */
  schedule: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M3 10h18M8 3v4M16 3v4" />
      <path d="M7.5 14h.01M12 14h.01M16.5 14h.01M7.5 17.5h.01M12 17.5h.01" />
    </>
  ),
  /** QR — the three finder patterns, which is what makes a QR code legible. */
  qr: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <path d="M14 14h3.5v3.5H14zM21 14v.01M21 17.5v.01M21 21v.01M17.5 21v.01M14 21v.01" />
    </>
  ),
  /** Regex — the asterisk and the dot, as every editor draws it. */
  regex: (
    <>
      <path d="M15.5 4.5v8M12 6.5l7 4M19 6.5l-7 4" />
      <circle cx="6.5" cy="17.5" r="1.6" />
    </>
  ),
  /** Case converter — a capital and a lowercase, at their real sizes. */
  letterCase: (
    <>
      <path d="M2 18.5 6.6 5.5l4.6 13M3.6 14.6h6" />
      <path d="M13.8 18.5 17 9.5l3.2 9M14.9 15.9h4.2" />
    </>
  ),
  /** Lorem Ipsum — lines of text, the last one short. */
  textLines: <path d="M4 5.5h16M4 10h16M4 14.5h16M4 19h9" />,
  /** CSV — a table, which is exactly what the output is. */
  table: (
    <>
      <rect x="3" y="4.5" width="18" height="15" rx="2" />
      <path d="M3 9.5h18M9.5 9.5v10M15.5 9.5v10" />
    </>
  ),
  /** Convert — the same thing, in the other format. */
  swap: (
    <>
      <path d="M4 8.5h13m0 0-3.5-3.5M17 8.5 13.5 12" />
      <path d="M20 15.5H7m0 0 3.5-3.5M7 15.5 10.5 19" />
    </>
  ),
  /** PDF to Text — a page, and the lines pulled out of it. */
  pageText: (
    <>
      <path d="M13.5 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5z" />
      <path d="M13.5 3v5.5H19" />
      <path d="M8.5 13h7M8.5 16.5h4.5" />
    </>
  ),
  /** A plain document — the thing you end up with. */
  fileDoc: (
    <>
      <path d="M13.5 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5z" />
      <path d="M13.5 3v5.5H19" />
    </>
  ),
  /** XML and HTML — the markup, not the data. */
  angleBrackets: <path d="m8.5 7.5-5 4.5 5 4.5M15.5 7.5l5 4.5-5 4.5" />,
  /** Codegen — source, in whichever language you picked. */
  code: (
    <>
      <path d="m8 8-4 4 4 4M16 8l4 4-4 4" />
      <path d="m13.5 5-3 14" />
    </>
  ),
  /** SQL. */
  database: (
    <>
      <ellipse cx="12" cy="6" rx="7.5" ry="3" />
      <path d="M4.5 6v12c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3V6" />
      <path d="M19.5 12c0 1.66-3.36 3-7.5 3s-7.5-1.34-7.5-3" />
    </>
  ),
  /** URL encoding — the thing being encoded is a link. */
  link: (
    <>
      <path d="M10 13.5a3.5 3.5 0 0 0 5 0l3-3a3.54 3.54 0 0 0-5-5l-1.4 1.4" />
      <path d="M14 10.5a3.5 3.5 0 0 0-5 0l-3 3a3.54 3.54 0 0 0 5 5l1.4-1.4" />
    </>
  ),
  // ---- Colour and codes ---------------------------------------------------
  /** Colour picker — the eyedropper, which is what the control is called. */
  eyedropper: (
    <>
      <path d="m15 6 3.4-3.4a2.1 2.1 0 1 1 3 3L18 9l.4.4a2.1 2.1 0 1 1-3 3l-3.8-3.8a2.1 2.1 0 1 1 3-3l.4.4Z" />
      <path d="M3 21v-3l9-9" />
      <path d="m2 22 1-1h3l9-9" />
    </>
  ),
  /** Palette — a set of colours chosen together. */
  palette: (
    <>
      <path d="M12 3a9 9 0 0 0 0 18 2 2 0 0 0 1.6-3.2 2 2 0 0 1 1.6-3.2h1.9A3.9 3.9 0 0 0 21 10.7C21 6.4 16.97 3 12 3Z" />
      <path d="M7.5 11h.01M10.5 7.5h.01M15 7.5h.01" />
    </>
  ),
  /** Colour wheel — hue around a circle. */
  colorWheel: (
    <>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 3v5.8M12 15.2V21M3 12h5.8M15.2 12H21" />
    </>
  ),
  /** Gradient — one colour becoming another. */
  gradient: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2.5" />
      <path d="M3 16.5h18M3 12.5h18M3 8.5h18" opacity="0.45" />
    </>
  ),
  /** Contrast — the half-filled circle, as every contrast control draws it. */
  contrast: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none" />
    </>
  ),
  /** Colour vision — an eye. */
  eye: (
    <>
      <path d="M2.5 12s3.6-6.5 9.5-6.5S21.5 12 21.5 12 17.9 18.5 12 18.5 2.5 12 2.5 12Z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  /** Barcode — bars of differing width, which is the whole idea. */
  barcode: (
    <>
      <path d="M3 6v12M6 6v12M9.5 6v12M13 6v12M16.5 6v12M21 6v12" />
    </>
  ),

  /** UUID — an identifier, on a tag. */
  identifier: (
    <>
      <path d="M3 8.5a2 2 0 0 1 2-2h9.6a2 2 0 0 1 1.5.7l4 4.5a1 1 0 0 1 0 1.3l-4 4.3a2 2 0 0 1-1.5.7H5a2 2 0 0 1-2-2z" />
      <path d="M7 12h.01M10.5 12h.01" />
    </>
  ),
} as const;

export type IconName = keyof typeof PATHS;

/**
 * The operation inside an icon, drawn again in the accent.
 *
 * At the size the homepage draws these — 40px, one to a row — a flat monochrome
 * mark says "a document" and stops. What a visitor is choosing between is not
 * documents but *verbs*: merge, split, compress, rotate. So the object stays in
 * ink and the part of the drawing that is the verb is repeated here in orange,
 * on top of itself. Exact duplicates, so nothing smears or thickens; the orange
 * simply lands on the ink and takes over those strokes.
 *
 * Only the icons that have a separable verb appear here. A picture frame, a
 * palette or an eye is a noun all the way through, and colouring an arbitrary
 * third of it would be decoration — those render monochrome, which is also what
 * keeps the orange meaning something when it does appear.
 */
const ACCENT_PATHS: Partial<Record<IconName, React.ReactNode>> = {
  merge: <path d="M12 12h7.5m-3 -3 3 3-3 3" />,
  split: <path d="m11.5 3.5 2.5 2.5-2.5 2.5M11.5 15.5l2.5 2.5-2.5 2.5" />,
  compress: <path d="M12 7v4M12 17v-4M9 8l3 3 3-3M9 16l3-3 3 3" />,
  expand: <path d="M12 8v8M9 11l3-3 3 3M9 13l3 3 3-3" />,
  resize: <path d="m8 8 8 8M8 12.5V8h4.5M16 11.5V16h-4.5" />,
  rotate: <path d="M20.5 4v5.5H15" />,
  reorder: <path d="M5 4.5v15m-2.5-12.5 2.5-2.5L7.5 7M2.5 17l2.5 2.5L7.5 17" />,
  checkDoc: <path d="m9 14 2 2 4-4" />,
  shield: <path d="m9.25 12 2 2 3.5-3.75" />,
  indent: <path d="M4 10.5 6.25 12.75 4 15" />,
  swap: <path d="M20 15.5H7m0 0 3.5-3.5M7 15.5 10.5 19" />,
  search: <path d="m20 20-4.5-4.5" />,
  watermark: <path d="m8 13.5 4.5-4.5M11 16.5 16 11.5" />,
  pageText: <path d="M8.5 13h7M8.5 16.5h4.5" />,
  diff: <path d="M6 8.25v7.5M8.25 6H14a2 2 0 0 1 2 2v7.75" />,
  wand: <path d="M17 3.5 18 6l2.5 1-2.5 1-1 2.5-1-2.5L13.5 7 16 6l1-2.5Z" />,
  unlock: <path d="M8 10.5V7.5a4 4 0 0 1 7.7-1.5" />,
  regex: <circle cx="6.5" cy="17.5" r="1.6" />,
  clock: <path d="M12 7v5.3l3.4 2" />,
  table: <path d="M3 9.5h18M9.5 9.5v10M15.5 9.5v10" />,
  colorWheel: <path d="M12 3v5.8M12 15.2V21M3 12h5.8M15.2 12H21" />,
  crop: <path d="M2 6h14a2 2 0 0 1 2 2v14" />,
  eyedropper: <path d="m2 22 1-1h3l9-9" />,
};

/**
 * The icon sizes in the UI.
 *
 * `xl` is for a category tile. `2xl` is the homepage's featured rows and
 * nothing else — at 40px an icon stops being a label on a link and becomes the
 * thing you aim at, which is why it is the one place the accent overlay is
 * used.
 */
const SIZES = {
  sm: "w-3.5 h-3.5",
  md: "w-4 h-4",
  lg: "w-5 h-5",
  xl: "w-6 h-6",
  "2xl": "w-10 h-10",
} as const;

export interface IconProps {
  name: IconName;
  size?: keyof typeof SIZES;
  className?: string;
  /**
   * Draw the operation in the accent. Ignored for icons with no separable
   * operation, which is deliberate rather than a gap: see `ACCENT_PATHS`.
   */
  accent?: boolean;
}

export const Icon: React.FC<IconProps> = ({
  name,
  size = "md",
  className = "",
  accent = false,
}) => (
  <svg
    className={`${SIZES[size]} flex-none ${className}`}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth={1.5}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    focusable="false"
  >
    {PATHS[name]}
    {accent && ACCENT_PATHS[name] && (
      <g stroke="var(--accent-solid)">{ACCENT_PATHS[name]}</g>
    )}
  </svg>
);

export default Icon;
