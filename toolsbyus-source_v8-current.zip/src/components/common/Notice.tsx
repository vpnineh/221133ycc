import React from "react";
import { Icon, type IconName } from "./Icon";

export type NoticeTone = "info" | "success" | "warn" | "danger";

interface NoticeProps {
  tone?: NoticeTone;
  title?: string;
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}

/**
 * The one inline-message component.
 *
 * Replaces both the hand-rolled coloured boxes each tool page carried — each
 * with its own inline SVG and its own padding — and, more importantly, the two
 * `alert()` calls on the diff page. A native alert blocks the tab, cannot be
 * styled or dismissed with the keyboard, and throws away the context the reader
 * needs; for a tool aimed at developers it is the worst possible way to say
 * "this document does not parse".
 *
 * `role="status"` announces the message when it appears without stealing focus;
 * a failure uses `role="alert"`, which interrupts, because a failed action is
 * worth interrupting for.
 */
const TONES: Record<NoticeTone, { icon: IconName; border: string; bg: string; fg: string }> = {
  info: { icon: "info", border: "border-border", bg: "bg-surface-elevated", fg: "text-foreground-muted" },
  success: { icon: "check", border: "border-accent-line", bg: "bg-accent-soft", fg: "text-accent" },
  warn: { icon: "warning", border: "border-warn", bg: "bg-warn-soft", fg: "text-warn" },
  danger: { icon: "warning", border: "border-danger", bg: "bg-danger-soft", fg: "text-danger" },
};

export const Notice: React.FC<NoticeProps> = ({
  tone = "info",
  title,
  children,
  action,
  className = "",
}) => {
  const t = TONES[tone];

  return (
    <div
      role={tone === "danger" ? "alert" : "status"}
      className={`flex flex-wrap items-start gap-x-2.5 gap-y-2 rounded-lg border px-3 py-2.5 text-xs leading-relaxed ${t.border} ${t.bg} ${className}`}
    >
      <Icon name={t.icon} size="md" className={`mt-px ${t.fg}`} />
      <div className="min-w-0 flex-1">
        {title && <span className={`font-semibold ${t.fg}`}>{title} </span>}
        <span className="text-foreground-muted">{children}</span>
      </div>
      {action}
    </div>
  );
};

export default Notice;
