import React from "react";
import Link from "next/link";
import { Icon } from "./Icon";

interface PrivacyBadgeProps {
  /**
   * `chip` is the compact form: two words, fixed width, never wraps.
   * `full` states the guarantee outright, for the one place per view that has
   * room for it.
   *
   * There used to be a third copy of this in the site header, and every page
   * that carried its own badge hid it with `lg:hidden` so the two would not
   * appear at once. When the header lost its chip in the redesign, those guards
   * silently took the guarantee off every desktop view — the claim the whole
   * product rests on, invisible above 1024px, with nothing failing. It is now
   * rendered once per page at every width, and an end-to-end test counts it.
   */
  variant?: "chip" | "full";
  className?: string;
}

export const PrivacyBadge: React.FC<PrivacyBadgeProps> = ({
  variant = "chip",
  className = "",
}) => {
  const isChip = variant === "chip";

  return (
    <Link
      href="/privacy"
      title="Every tool runs in this browser tab. The file or text you put in is never uploaded, logged or transmitted."
      className={`group inline-flex items-center gap-1.5 rounded-full border border-border text-foreground-muted transition-colors hover:border-border-strong hover:text-foreground ${
        isChip
          ? // Two words. It never wraps, and wrapping it would look broken.
            "whitespace-nowrap px-3 py-1 text-2xs font-medium pointer-coarse:min-h-[44px] pointer-coarse:px-3.5"
          : // A whole sentence, which at 320px in a row beside something else
            // has to be allowed to take a second line rather than push the
            // document sideways.
            "px-3.5 py-1.5 text-xs font-medium"
      } ${className}`}
    >
      {/* The shield is the only orange in the badge. The words are the claim
          and the mark is the reassurance, and putting the accent on the whole
          chip would make a guarantee look like a promotion. */}
      <Icon name="shield" size="sm" accent />
      {isChip ? (
        <span className="tracking-tight">Local-only</span>
      ) : (
        <span>Your file never leaves your browser</span>
      )}
      <Icon
        name="chevronRight"
        size="sm"
        className="text-foreground-subtle transition-opacity group-hover:opacity-100"
      />
    </Link>
  );
};

export default PrivacyBadge;
