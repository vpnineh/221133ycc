import React from "react";
import Link from "next/link";
import { toolByHref, INFO_PAGES } from "../../lib/tools";
import { CONTENT_LAST_REVIEWED } from "../../lib/site";

/**
 * The visible "last updated" line, in one place.
 *
 * `ToolShell` has rendered one from the beginning, but three pages predate it
 * and are composed by hand — `/base64-decode`, `/json-formatter` and
 * `/uuid-generator`. They emitted a correct `dateModified` in their JSON-LD and
 * showed a reader nothing at all, so the site's claim that every tool page
 * carries a visible review date was true of fifty-five pages out of fifty-eight.
 *
 * The date comes from the catalogue rather than a prop, for the same reason it
 * does in `ToolShell`: a page cannot then disagree with the sitemap about its
 * own freshness.
 */
export const ReviewedStamp: React.FC<{ href: string }> = ({ href }) => {
  const reviewed =
    toolByHref(href)?.lastReviewed ??
    INFO_PAGES.find((page) => page.href === href)?.lastReviewed ??
    CONTENT_LAST_REVIEWED;

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-5 text-2xs text-foreground-subtle">
      <Link href="/about#editorial-process" className="underline underline-offset-4 hover:text-accent">ToolsByUs team · How we check our tools</Link>
      <span>
        Last updated{" "}
        <time dateTime={reviewed} className="font-mono text-foreground-muted">
          {reviewed}
        </time>
      </span>
    </div>
  );
};

export default ReviewedStamp;
