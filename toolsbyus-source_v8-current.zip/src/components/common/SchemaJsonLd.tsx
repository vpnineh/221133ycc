import React from "react";
import { toolByHref } from "../../lib/tools";
import { BreadcrumbItem } from "./Breadcrumb";
import { FaqItem } from "./FaqSection";
import {
  SITE_NAME,
  SITE_URL,
  absoluteUrl,
  CONTENT_LAST_REVIEWED,
  CONTENT_FIRST_PUBLISHED,
} from "../../lib/site";

interface SchemaJsonLdProps {
  url?: string;
  title?: string;
  description?: string;
  dateModified?: string;
  breadcrumbs?: BreadcrumbItem[];
  faqs?: FaqItem[];
  applicationName?: string;
  /** Extra feature bullets surfaced on the WebApplication node. */
  featureList?: string[];
  schemas?: Record<string, unknown>[];
}

/**
 * Serialize a JSON-LD payload for embedding in a <script> element.
 *
 * `JSON.stringify` alone is not safe inside an HTML script context: a `</script>`
 * sequence anywhere in the data closes the element early and lets the remainder
 * be parsed as markup. Escaping `<`, `>` and `&` as unicode sequences keeps the
 * JSON semantically identical while making early termination impossible.
 */
function serializeJsonLd(data: unknown): string {
  return JSON.stringify(data)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026");
}

export const SchemaJsonLd: React.FC<SchemaJsonLdProps> = ({
  url = "/",
  title = SITE_NAME,
  description = "Free browser tools for PDFs, images, color, text, JSON, encoding and generators",
  dateModified = CONTENT_LAST_REVIEWED,
  breadcrumbs = [],
  faqs = [],
  applicationName,
  featureList,
  schemas,
}) => {
  if (schemas && schemas.length > 0) {
    return (
      <>
        {schemas.map((s, idx) => (
          <script
            key={idx}
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: serializeJsonLd(s) }}
          />
        ))}
      </>
    );
  }

  const fullUrl = absoluteUrl(url);

  // 1. Organization
  const orgSchema = {
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: SITE_NAME,
    url: `${SITE_URL}/`,
    logo: {
      "@type": "ImageObject",
      url: absoluteUrl("/icon-512.png"),
      width: 512,
      height: 512,
    },
    description:
      "Publisher of free browser tools for documents, images, color, text and structured data.",
  };

  // 2. WebSite
  const webSiteSchema = {
    "@type": "WebSite",
    "@id": `${SITE_URL}/#website`,
    url: `${SITE_URL}/`,
    name: SITE_NAME,
    description: "Free browser tools for PDFs, images, color, text, JSON, encoding and generators",
    inLanguage: "en",
    publisher: { "@id": `${SITE_URL}/#organization` },
  };

  // 3. WebPage
  const webPageSchema: Record<string, unknown> = {
    "@type": "WebPage",
    "@id": `${fullUrl}#webpage`,
    url: fullUrl,
    name: title,
    description,
    // Both dates: freshness is a documented AI-citation signal, and a page with
    // only a modified date reads as undated to anything comparing the two.
    datePublished: CONTENT_FIRST_PUBLISHED,
    dateModified,
    inLanguage: "en",
    author: { "@id": `${SITE_URL}/#organization` },
    publisher: { "@id": `${SITE_URL}/#organization` },
    isPartOf: { "@id": `${SITE_URL}/#website` },
    about: { "@id": `${SITE_URL}/#organization` },
    primaryImageOfPage: {
      "@type": "ImageObject",
      url: absoluteUrl("/og-image.png"),
      width: 1200,
      height: 630,
    },
  };

  if (applicationName) {
    webPageSchema.mainEntity = { "@id": `${fullUrl}#webapp` };
    webPageSchema.about = { "@id": `${fullUrl}#webapp` };
  }
  if (breadcrumbs.length) webPageSchema.breadcrumb = { "@id": `${fullUrl}#breadcrumb` };
  const category = toolByHref(url)?.category;

  // 4. WebApplication (for tools)
  const webAppSchema = applicationName
    ? {
        "@type": "WebApplication",
        "@id": `${fullUrl}#webapp`,
        name: applicationName,
        url: fullUrl,
        description,
        applicationCategory: category === "pdf" ? "BusinessApplication" : category === "image" || category === "color" ? "DesignApplication" : "DeveloperApplication",
        operatingSystem: "Any",
        browserRequirements: "Requires a modern browser with JavaScript enabled",
        isAccessibleForFree: true,
        ...(featureList && featureList.length > 0 ? { featureList } : {}),
        offers: {
          "@type": "Offer",
          price: "0",
          priceCurrency: "USD",
          availability: "https://schema.org/InStock",
        },
        publisher: { "@id": `${SITE_URL}/#organization` },
      }
    : null;

  // 5. BreadcrumbList
  const breadcrumbListSchema =
    breadcrumbs.length > 0
      ? {
          "@type": "BreadcrumbList",
          "@id": `${fullUrl}#breadcrumb`,
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Home",
              item: `${SITE_URL}/`,
            },
            ...breadcrumbs.map((b: BreadcrumbItem & { name?: string; url?: string }, i) => ({
              "@type": "ListItem",
              position: i + 2,
              name: b.name || b.label,
              item: absoluteUrl(b.url || b.href || url),
            })),
          ],
        }
      : null;

  // 6. FAQPage
  const faqPageSchema =
    faqs.length > 0
      ? {
          "@type": "FAQPage",
          "@id": `${fullUrl}#faq`,
          mainEntity: faqs.map((f) => ({
            "@type": "Question",
            name: f.question,
            acceptedAnswer: {
              "@type": "Answer",
              text: f.answer,
            },
          })),
        }
      : null;

  const graph = [
    orgSchema,
    webSiteSchema,
    webPageSchema,
    ...(webAppSchema ? [webAppSchema] : []),
    ...(breadcrumbListSchema ? [breadcrumbListSchema] : []),
    ...(faqPageSchema ? [faqPageSchema] : []),
  ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": graph,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }}
    />
  );
};

export default SchemaJsonLd;
