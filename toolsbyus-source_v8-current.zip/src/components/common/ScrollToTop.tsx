"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";

/**
 * Back-to-top control with a scroll-progress ring.
 *
 * Two jobs in one 44px target. The ring answers "how much of this is left?",
 * which on a 1,800-word tool page is a question people actually have — the
 * browser scrollbar is a two-pixel sliver on a trackpad Mac and absent on a
 * phone. The button answers "take me back", which on a page with the tool at
 * the top and the reference material below is the single most common thing
 * somebody wants after reading.
 *
 * Implementation constraints, all deliberate:
 *
 * - **No keyframes and no `backdrop-filter`.** The whole design system bans
 *   them, and a control pinned above the page is the worst place to break that:
 *   it repaints on every scroll frame either way.
 * - **rAF-coalesced.** A scroll listener that writes to the DOM directly runs
 *   at the event rate, which on a precision trackpad is faster than the display
 *   refresh. Reading `scrollY` in the handler and writing in the frame keeps it
 *   to one layout read and one paint per frame.
 * - **Passive listener.** Anything else lets the browser think this might call
 *   `preventDefault`, which costs scroll smoothness on touch.
 * - **Removed from the tab order while hidden.** A focusable control nobody can
 *   see is a keyboard trap in miniature: you tab, focus vanishes, and the page
 *   jumps to something invisible.
 * - **`scroll-behavior` decided per click, not in CSS.** A global smooth scroll
 *   also animates in-page anchor jumps and the skip link, where it is slow and
 *   disorienting. Reduced-motion gets an instant jump.
 */

/** Past this, the page is long enough that returning to the top is a chore. */
const SHOW_AFTER_PX = 600;

const SIZE = 44;
const STROKE = 2.5;
const RADIUS = (SIZE - STROKE) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export const ScrollToTop: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  const frameRef = useRef<number | null>(null);

  useEffect(() => {
    const measure = () => {
      frameRef.current = null;
      const scrolled = window.scrollY;
      const total = document.documentElement.scrollHeight - window.innerHeight;

      setVisible(scrolled > SHOW_AFTER_PX);
      // A page shorter than the viewport has no progress to report, and
      // dividing by zero would render the ring full at the top of the page.
      setProgress(total > 0 ? Math.min(1, Math.max(0, scrolled / total)) : 0);
    };

    const onScroll = () => {
      if (frameRef.current === null) frameRef.current = requestAnimationFrame(measure);
    };

    measure();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
  }, []);

  const toTop = useCallback(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
    // Focus the skip link's target so the keyboard lands where the eye does.
    document.getElementById("main-content")?.focus({ preventScroll: true });
  }, []);

  const percent = Math.round(progress * 100);

  return (
    <button
      type="button"
      onClick={toTop}
      tabIndex={visible ? 0 : -1}
      aria-hidden={!visible}
      aria-label={`Back to top — ${percent}% read`}
      title="Back to top"
      className={`fixed bottom-[max(1rem,env(safe-area-inset-bottom))] right-[max(1rem,env(safe-area-inset-right))] z-40 grid h-11 w-11 place-items-center rounded-full border border-border bg-surface text-foreground-muted shadow-pop transition-[opacity,color,border-color] hover:border-border-strong hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
        visible ? "cursor-pointer opacity-100" : "pointer-events-none opacity-0"
      }`}
    >
      {/* The ring sits behind the glyph rather than around it, so the control
          stays exactly one 44px target instead of a 44px ring with a smaller
          hit area inside it. */}
      <svg
        width={SIZE}
        height={SIZE}
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        aria-hidden="true"
        className="absolute inset-0 -rotate-90"
      >
        <circle
          cx={SIZE / 2}
          cy={SIZE / 2}
          r={RADIUS}
          fill="none"
          stroke="var(--border)"
          strokeWidth={STROKE}
        />
        <circle
          cx={SIZE / 2}
          cy={SIZE / 2}
          r={RADIUS}
          fill="none"
          stroke="var(--accent-solid)"
          strokeWidth={STROKE}
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={CIRCUMFERENCE * (1 - progress)}
        />
      </svg>

      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        className="relative"
      >
        <path d="M12 19V5M5 12l7-7 7 7" />
      </svg>
    </button>
  );
};

export default ScrollToTop;
