"use client";

import React, { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Icon, type IconName } from "./Icon";

/**
 * Three states, not two: System, Light, Dark — with System the default.
 *
 * A two-way toggle has to guess what the visitor wants the first time they
 * arrive, and whichever way it guesses it is wrong for half of them. Worse, it
 * has no way back: once you have pressed it, the site is pinned to your choice
 * and stops following the machine when the machine changes at sunset. So the
 * stored value is a *preference* — "follow the system", "always light",
 * "always dark" — and the applied class is derived from it.
 *
 * What is stored is the preference; what is on <html> is the result. Keeping
 * those two apart is the whole design: it is why the button can show a monitor
 * while the page is dark, and why changing the OS theme at 6pm moves a visitor
 * on System without touching a visitor who chose Light.
 */
type Preference = "system" | "light" | "dark";

const STORAGE_KEY = "ycd_theme";

/** Same-tab notification. `storage` only fires in the *other* tabs. */
const PREFERENCE_EVENT = "toolsbyus:theme-preference";

const OPTIONS: Array<{ value: Preference; label: string; icon: IconName }> = [
  { value: "system", label: "System", icon: "monitor" },
  { value: "light", label: "Light", icon: "sun" },
  { value: "dark", label: "Dark", icon: "moon" },
];

function readPreference(): Preference {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored === "light" || stored === "dark" ? stored : "system";
  } catch {
    // Private mode, or storage blocked by policy. Following the OS is the
    // right answer when we cannot remember anything.
    return "system";
  }
}

function prefersDark(): boolean {
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

/** Derives the class on <html> from a preference. Mirrors THEME_INIT_SCRIPT. */
function applyPreference(preference: Preference): void {
  const dark = preference === "dark" || (preference === "system" && prefersDark());
  document.documentElement.classList.toggle("dark", dark);
}

/**
 * The preference is external state — it lives in localStorage and can change in
 * another tab — so it is read with useSyncExternalStore rather than mirrored
 * into useState inside an effect. The latter renders once with a guessed value
 * and again after the effect, and reports the wrong mode in between.
 */
const preferenceStore = {
  subscribe(onChange: () => void) {
    // Another tab changed the preference: adopt it here too, then re-render.
    const onStorage = (event: StorageEvent) => {
      if (event.key !== null && event.key !== STORAGE_KEY) return;
      applyPreference(readPreference());
      onChange();
    };

    // The OS theme changed. Only visitors on System should move.
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onMedia = () => {
      if (readPreference() !== "system") return;
      applyPreference("system");
      onChange();
    };

    window.addEventListener(PREFERENCE_EVENT, onChange);
    window.addEventListener("storage", onStorage);
    media.addEventListener("change", onMedia);
    return () => {
      window.removeEventListener(PREFERENCE_EVENT, onChange);
      window.removeEventListener("storage", onStorage);
      media.removeEventListener("change", onMedia);
    };
  },
  getSnapshot: readPreference,
  // The server cannot know. "system" is both the default and the honest answer;
  // the inline script in the root layout has already corrected the class by the
  // time the browser paints, so there is nothing to flash.
  getServerSnapshot: (): Preference => "system",
};

export const ThemeToggle: React.FC = () => {
  const preference = useSyncExternalStore(
    preferenceStore.subscribe,
    preferenceStore.getSnapshot,
    preferenceStore.getServerSnapshot
  );

  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const choose = useCallback((next: Preference) => {
    try {
      // "system" is written rather than removed so a later visit can tell a
      // deliberate choice from a first arrival, should that ever matter.
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // A rejected write costs persistence, not the change itself.
    }
    applyPreference(next);
    window.dispatchEvent(new Event(PREFERENCE_EVENT));
    setOpen(false);
    triggerRef.current?.focus();
  }, []);

  // Close on outside pointer, Escape, or focus leaving the menu. Escape returns
  // focus to the trigger so a keyboard user is not dropped at the top of the
  // document.
  useEffect(() => {
    if (!open) return;

    const onPointerDown = (event: PointerEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
      }
    };
    const onFocusIn = (event: FocusEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };

    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("focusin", onFocusIn);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("focusin", onFocusIn);
    };
  }, [open]);

  /** Up and Down move between the three options, as a menu is expected to. */
  const onMenuKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    event.preventDefault();
    const items = Array.from(
      rootRef.current?.querySelectorAll<HTMLButtonElement>("[role='menuitemradio']") ?? []
    );
    const index = items.indexOf(document.activeElement as HTMLButtonElement);
    const step = event.key === "ArrowDown" ? 1 : -1;
    items[(index + step + items.length) % items.length]?.focus();
  };

  const active = OPTIONS.find((option) => option.value === preference) ?? OPTIONS[0];

  return (
    <div className="relative" ref={rootRef}>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen((wasOpen) => !wasOpen)}
        onKeyDown={(event) => {
          if (event.key === "ArrowDown" && !open) {
            event.preventDefault();
            setOpen(true);
          }
        }}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Theme: ${active.label}`}
        suppressHydrationWarning
        className="inline-flex h-10 w-10 cursor-pointer items-center justify-center rounded-pill border border-border-strong bg-surface text-foreground transition-colors hover:border-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:h-11 pointer-coarse:w-11"
      >
        {/*
          No chevron beside the icon. The trigger is a 40px circle carrying one
          glyph, and a second glyph inside it at that size is a smudge rather
          than an affordance — `aria-haspopup` and `aria-expanded` are what
          actually announce that this opens a menu, and they are on the button.
        */}
        <Icon name={active.icon} size="lg" />
      </button>

      {open && (
        <div
          role="menu"
          aria-label="Colour theme"
          onKeyDown={onMenuKeyDown}
          className="absolute right-0 top-full z-50 mt-2 w-44 overflow-hidden rounded-lg border border-border bg-surface p-1 shadow-pop"
        >
          {OPTIONS.map((option) => {
            const selected = option.value === preference;
            return (
              <button
                key={option.value}
                type="button"
                role="menuitemradio"
                aria-checked={selected}
                onClick={() => choose(option.value)}
                className={`flex w-full cursor-pointer items-center gap-3 rounded px-3 py-2.5 text-left text-sm transition-colors hover:bg-surface-elevated focus-visible:outline-none focus-visible:bg-surface-elevated focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:py-3 ${
                  selected ? "text-foreground" : "text-foreground-muted"
                }`}
              >
                <Icon name={option.icon} size="md" className="text-foreground-subtle" />
                <span className="flex-1 font-medium">{option.label}</span>
                {/* The check is the only accent in the menu, and it marks state
                    rather than decorating the row. */}
                {selected && <Icon name="check" size="md" className="text-accent" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ThemeToggle;
