import React from "react";
import { TOOL_SCENES, type SceneKind } from "../../lib/tool-scenes";
import type { ToolCategory } from "../../lib/tools";
import { CategoryScene } from "./CategoryScene";

const A = "var(--accent-solid)";
const lines = <path d="M25 43h64M25 60h46M25 77h64M25 94h35" />;
function Drawing({ kind, label }: { kind: SceneKind; label: string }) {
  switch (kind) {
    case "compare": return <><rect x="2" y="26" width="48" height="98" rx="4" /><rect x="65" y="26" width="48" height="98" rx="4" /><path d="M12 47h28M12 65h20M12 83h28M12 101h17M75 47h28M75 65h20M75 83h28M75 101h17" /><path d="M12 65h20M75 83h28" stroke={A} /></>;
    case "code": {
      const token = label.includes("TYPESCRIPT") ? "TS" : label.includes("GO ") ? "Go" : label.includes("PYTHON") ? "Py" : label.includes("C#") ? "C#" : label.includes("JAVA") ? "Java" : label.includes("JSON") || label.includes("SCHEMA") ? "{ }" : label.includes("XML") || label.includes("HTML") ? "</>" : label.includes("YAML") ? "YML" : label.includes("SQL") ? "SQL" : label.includes("CSS") ? "CSS" : label.includes("UUID") ? "UUID" : label.includes("BIN") ? "01" : label.includes("RGB") || label.includes("COLOR") ? "RGB" : label === "HEX" || label === "HSL" ? label : "Aa";
      return <><rect x="6" y="18" width="105" height="113" rx="5" /><path d="M6 51h105M22 70h66M34 86h42M34 102h57M22 118h40" /><text x="58" y="42" textAnchor="middle" fontFamily="Arial, Helvetica, sans-serif" fontSize="17" fontWeight="500" fill={A} stroke="none">{token}</text></>;
    }
    case "image-compressed":
    case "image": case "crop": return <><rect x="5" y="28" width="105" height="86" rx="4" /><circle cx="32" cy="52" r="8" stroke={A} /><path d="m14 102 26-28 18 20 17-32 26 40" />{kind === "image-compressed" && <path d="M24 130h20m-7-6 7 6-7 6M92 130H72m7-6-7 6 7 6" stroke={A} />}{kind === "crop" && <path d="M30 18v70h89M20 40h69v85" stroke={A} strokeWidth="3" />}</>;
    case "stack": return <><rect x="12" y="33" width="76" height="102" rx="5" /><rect x="22" y="22" width="76" height="102" rx="5" fill="var(--bg)" /><rect x="32" y="11" width="76" height="102" rx="5" fill="var(--bg)" /><path d="M45 40h45M45 58h45M45 76h29" /></>;
    case "rotate": return <><rect x="9" y="42" width="101" height="72" rx="5" /><path d="M27 60h66M27 77h44M27 94h66M28 29a37 37 0 0 1 61-9M89 7v17H72" stroke={A} /></>;
    case "tree": return <><rect x="5" y="14" width="63" height="28" rx="4" /><rect x="43" y="63" width="66" height="26" rx="4" /><rect x="43" y="106" width="66" height="26" rx="4" /><path d="M20 42v77h23M20 76h23" stroke={A} /><path d="M55 76h40M55 119h28" /></>;
    case "table": return <><rect x="6" y="22" width="106" height="106" rx="4" /><path d="M6 48h106M6 74h106M6 100h106M42 22v106M78 22v106" /><path d="M6 48h106" stroke={A} /></>;
    case "compact": return <><rect x="4" y="47" width="110" height="49" rx="5" /><path d="M16 64h29M53 64h22M83 64h19M16 79h17M41 79h38M88 79h14" stroke={A} /></>;
    case "swatches": return <><circle cx="46" cy="52" r="30" /><circle cx="68" cy="86" r="30" /><circle cx="28" cy="86" r="30" stroke={A} /><path d="M12 134h92" /></>;
    case "wheel": return <><circle cx="58" cy="74" r="49" /><circle cx="58" cy="74" r="30" />{Array.from({ length: 12 }, (_, i) => <path key={i} transform={`rotate(${i*30} 58 74)`} d="M58 25v19" />)}<path d="m58 74 38-25M58 74l-37 27" stroke={A} /><circle cx="58" cy="74" r="5" fill="var(--bg)" /></>;
    case "contrast": return <><rect x="7" y="26" width="104" height="91" rx="5" /><path d="M59 26v91" /><text x="18" y="83" fill="currentColor" stroke="none" fontFamily="Arial, Helvetica, sans-serif" fontSize="30">A</text><text x="68" y="83" fill="var(--accent)" stroke="none" fontFamily="Arial, Helvetica, sans-serif" fontSize="30">a</text><path d="M25 132h64" stroke={A} /></>;
    case "gradient": return <><rect x="7" y="40" width="104" height="65" rx="4" />{[0,1,2,3,4,5,6,7].map(i=><rect key={i} x={10+i*12.6} y="43" width="13" height="59" stroke="none" fill={A} opacity={(i+1)/8} />)}<path d="M10 126h101M10 121v10M111 121v10" /></>;
    case "eye": return <><path d="M4 74q54-73 110 0-56 73-110 0Z" /><circle cx="59" cy="74" r="24" /><circle cx="59" cy="74" r="8" stroke={A} /></>;
    case "clock": case "calendar": return kind === "clock" ? <><circle cx="58" cy="74" r="49" /><path d="M58 40v34l25 15" stroke={A} /><path d="M58 25v8M9 74h8M99 74h8M58 115v8" /></> : <><rect x="9" y="29" width="99" height="95" rx="5" /><path d="M9 53h99M33 19v20M84 19v20M28 72h10M54 72h10M80 72h10M28 95h10M54 95h10" /><path d="m79 95 6 6 12-14" stroke={A} /></>;
    case "key": case "unlock": return <><rect x="25" y="63" width="71" height="63" rx="7" /><path d={kind === "unlock" ? "M42 63V44q0-23 19-23 14 0 18 14" : "M42 63V44q0-23 19-23t19 23v19"} stroke={A} /><circle cx="61" cy="88" r="7" /><path d="M61 95v12" /></>;
    case "qr": return <><rect x="5" y="20" width="108" height="108" rx="5" />{[[17,32],[71,32],[17,86]].map(([x,y])=><g key={`${x}-${y}`}><rect x={x} y={y} width="28" height="28" /><rect x={x+8} y={y+8} width="12" height="12" fill="currentColor" stroke="none" /></g>)}<path d="M58 32v16M17 73h27M57 65h28v16h16M58 97h13v16h28M99 91v9" stroke={A} strokeWidth="5" /></>;
    case "barcode": return <><path d="M7 42V27h18M92 27h18v15M7 104v17h18M92 121h18v-17" />{[17,25,32,45,51,63,76,82,96].map((x,i)=><path key={x} d={`M${x} 42v61`} strokeWidth={i%3===0?4:2} stroke={i===4?A:undefined} />)}</>;
    default: return <><path d="M14 13h66l22 23v91q0 6-6 6H20q-6 0-6-6Z" /><path d="M80 13v23h22" />{lines}{kind === "compressed" && <path d="M25 115h18m-7-6 7 6-7 6M90 115H72m7-6-7 6 7 6" stroke={A} />}{kind === "check" && <path d="m42 104 12 12 28-31" stroke={A} strokeWidth="3" />}{kind === "diff" && <path d="M25 60h46M25 94h35" stroke={A} strokeWidth="5" />}{kind === "edit" && <path d="m62 111 27-27 7 7-27 27-10 3Z" fill="var(--bg)" stroke={A} />}{kind === "delete" && <path d="m37 52 46 46M83 52 37 98" stroke={A} strokeWidth="3" />}{kind === "order" && <path d="M106 48h13v48M114 88l5 8 5-8" stroke={A} />}{kind === "watermark" && <g transform="rotate(-28 57 74)"><rect x="10" y="63" width="96" height="24" fill="var(--bg)" stroke={A} /><path d="M22 75h72" stroke={A} /></g>}</>;
  }
}

export function ToolScene({ slug, category, className = "" }: { slug: string; category: ToolCategory; className?: string }) {
  const recipe = TOOL_SCENES[slug as keyof typeof TOOL_SCENES];
  if (!recipe) return <CategoryScene category={category} className={className} />;
  const [input, output, inputLabel, outputLabel] = recipe;
  const smaller = slug === "resize-image";
  return <svg viewBox="0 0 400 220" className={className} fill="none" aria-hidden="true" focusable="false" data-tool-scene={slug}>
    <g stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <g transform="translate(20 20)"><Drawing kind={input} label={inputLabel} /></g>
      <path d="M170 92h52m-9-9 9 9-9 9" stroke={A} strokeWidth="2.3" />
      <g transform={smaller ? "translate(271 40) scale(.76)" : "translate(258 20)"}><Drawing kind={output} label={outputLabel} /></g>
    </g>
    <g fill="currentColor" fontFamily="Arial, Helvetica, sans-serif" fontSize="10" fontWeight="500" letterSpacing=".8" textAnchor="middle">
      <text x="80" y="191">{inputLabel}</text><text x="317" y="191">{outputLabel}</text>
    </g>
  </svg>;
}
