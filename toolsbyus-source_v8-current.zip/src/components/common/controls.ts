/**
 * Shared control classes.
 *
 * Ten tool pages previously each spelled out their own buttons, selects and
 * panels, so the same control was 26px tall on one page and 34px on another,
 * with three different radii and two different focus rings. These strings are
 * the single definition; a page that needs a variation composes onto one of
 * them rather than starting from scratch.
 *
 * Every interactive class carries a 44px minimum under `pointer-coarse`, which
 * targets the input device rather than the viewport — a 28px control is fine
 * under a mouse on any screen size and awkward under a thumb on any screen
 * size (WCAG 2.5.5).
 */

const focusRing =
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-1 focus-visible:ring-offset-background";

/*
 * Depth from tone, not from lines.
 *
 * These used to be bordered boxes in ten-pixel radii, which is a different
 * language from the one the rest of the site now speaks: the chrome, the
 * homepage and the colour tools all say "a control is a filled pill on a
 * quieter ground", and a visitor moving from the front page into a tool was
 * crossing between two design systems. Because every tool page composes onto
 * these strings, changing them here changes all of them at once — which is
 * exactly what this file was written for.
 *
 * Sizes are deliberately close to what they replaced. The register changed; the
 * density did not, because a toolbar over a code pane is not a landing page and
 * making every button 44px tall would push the JSON tools past a 320px screen.
 */
const btnBase =
  "inline-flex items-center justify-center gap-1.5 rounded-pill text-xs font-medium " +
  "transition-colors cursor-pointer whitespace-nowrap " +
  "disabled:cursor-not-allowed disabled:opacity-50 " +
  "px-3.5 py-1.5 pointer-coarse:min-h-[44px] pointer-coarse:px-4 " +
  focusRing;

/** The one action a page wants you to take. At most one per view. */
export const btnPrimary = `${btnBase} bg-accent-solid text-accent-on hover:bg-accent-hover font-semibold`;

/** Everything else that is a real action. */
export const btnSecondary = `${btnBase} bg-surface-elevated text-foreground hover:bg-border`;

/** Low-emphasis actions inside a dense strip. */
export const btnGhost =
  `${btnBase} bg-transparent text-foreground-muted hover:bg-surface-elevated hover:text-foreground`;

/** Destructive, and visibly so before it is pressed. */
export const btnDanger =
  `${btnBase} bg-surface-elevated text-danger hover:bg-danger-soft`;

/** Compact variant for toolbars sitting on top of a pane. */
export const btnCompact =
  "inline-flex items-center justify-center gap-1.5 rounded-pill bg-surface-elevated " +
  "px-2.5 py-1 text-2xs text-foreground-muted transition-colors cursor-pointer whitespace-nowrap " +
  "hover:bg-border hover:text-foreground " +
  "disabled:cursor-not-allowed disabled:opacity-50 " +
  "pointer-coarse:min-h-[44px] pointer-coarse:px-3 " +
  focusRing;

export const field =
  "rounded-lg bg-surface-elevated px-3 py-1.5 text-xs text-foreground " +
  "transition-shadow " +
  "focus:outline-none focus:ring-2 focus:ring-inset focus:ring-accent " +
  "pointer-coarse:min-h-[44px] disabled:opacity-50";

/**
 * Mono was doing two jobs and only one of them was real. A value the machine
 * produced is monospace because it is literally code; the word "Indent" above a
 * select is not, and setting it in mono at 10px made a form read as a terminal.
 */
export const fieldLabel = "text-2xs text-foreground-subtle";

export const checkbox =
  "h-4 w-4 cursor-pointer rounded-sm border-border accent-[var(--accent-solid)] " +
  "pointer-coarse:h-5 pointer-coarse:w-5 " +
  focusRing;

/** A panel. The border survives here because it is what makes a work surface
    read as a container rather than as a lighter patch of page. */
export const panel = "rounded-xl border border-border bg-surface";

export const panelHeader =
  "flex flex-wrap items-center justify-between gap-x-3 gap-y-2 border-b border-border " +
  "bg-surface-elevated px-3.5 py-2";

/** Small non-interactive label, e.g. a version or format tag. */
/** Small non-interactive label for a value the machine produced — a version, a
    byte count, a format. Still monospace: that is what mono means here. */
export const chip =
  "inline-flex items-center gap-1 rounded-pill bg-surface-elevated px-2 py-0.5 " +
  "font-mono text-2xs text-foreground-subtle whitespace-nowrap";

/** One option inside a segmented control; `active` picks the selected look. */
export function segment(active: boolean): string {
  return (
    "cursor-pointer rounded-pill px-3 py-1 text-2xs font-medium transition-colors " +
    "pointer-coarse:min-h-[44px] pointer-coarse:px-3.5 " +
    focusRing +
    (active
      ? " bg-surface text-foreground shadow-pop"
      : " text-foreground-muted hover:text-foreground")
  );
}

/**
 * The track a segmented control sits in.
 *
 * `max-w-full` and `overflow-x-auto` are load-bearing, not defensive. A track
 * holds as many options as its tool has, and one of them holds eleven language
 * names: on a 360px phone that is 599px of buttons, and without these the whole
 * document scrolled sideways rather than the strip. Scrolling the strip is the
 * correct failure — the options stay reachable and the page stays still.
 */
export const segmentTrack =
  "inline-flex max-w-full items-center gap-0.5 overflow-x-auto rounded-pill " +
  "bg-surface-elevated p-1";
