import React from "react";
import { DiffSummary } from "../../lib/diff/types";
import { btnCompact } from "../common/controls";

interface DiffSummaryBarProps {
  summary: DiffSummary;
  durationMs?: number;
  onNextChange?: () => void;
  onPrevChange?: () => void;
}

/**
 * Counts read as a single dense strip rather than five chunky pills. Each entry
 * pairs its glyph with a word, so the classes stay distinguishable without
 * relying on colour (WCAG 1.4.1) — including for the roughly one in twelve men
 * who cannot separate the added-green from the removed-red.
 */
const TONES = {
  add: "text-add",
  del: "text-del",
  mod: "text-mod",
  type: "text-type",
  move: "text-move",
} as const;

const Count: React.FC<{
  tone: keyof typeof TONES;
  glyph: string;
  value: number;
  label: string;
}> = ({ tone, glyph, value, label }) => (
  <span className="inline-flex items-baseline gap-1.5 whitespace-nowrap">
    <span className={`font-mono font-bold ${TONES[tone]}`} aria-hidden="true">
      {glyph}
    </span>
    <span className="font-mono text-xs">
      <span className="font-bold text-foreground">{value}</span>{" "}
      <span className="text-foreground-muted">{label}</span>
    </span>
  </span>
);

export const DiffSummaryBar: React.FC<DiffSummaryBarProps> = ({
  summary,
  durationMs,
  onNextChange,
  onPrevChange,
}) => {
  return (
    <div className="flex flex-wrap items-center justify-between gap-x-5 gap-y-2 rounded-lg border border-border bg-surface px-3 py-2">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
        <Count tone="add" glyph="+" value={summary.added} label="added" />
        <Count tone="del" glyph="−" value={summary.removed} label="removed" />
        <Count tone="mod" glyph="≠" value={summary.changed} label="changed" />
        {summary.typeChanged > 0 && (
          <Count tone="type" glyph="~" value={summary.typeChanged} label="type shifted" />
        )}
        {summary.moved > 0 && (
          <Count tone="move" glyph="⇄" value={summary.moved} label="moved" />
        )}

        {durationMs !== undefined && (
          <span className="font-mono text-2xs text-foreground-subtle">
            computed in {durationMs}ms
          </span>
        )}
      </div>

      {summary.total > 0 && (
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onPrevChange}
            className={btnCompact}
            title="Previous change (Alt + Up)"
          >
            <span aria-hidden="true">↑</span>
            <span>Prev</span>
          </button>
          <button
            type="button"
            onClick={onNextChange}
            className={btnCompact}
            title="Next change (Alt + Down)"
          >
            <span aria-hidden="true">↓</span>
            <span>Next</span>
          </button>
        </div>
      )}
    </div>
  );
};
