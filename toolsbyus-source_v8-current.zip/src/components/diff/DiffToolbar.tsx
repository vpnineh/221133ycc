"use client";

import React from "react";
import { ArrayMatchMode, DiffOptions } from "../../lib/diff/types";
import { Icon } from "../common/Icon";
import {
  btnCompact,
  btnSecondary,
  checkbox,
  field,
  fieldLabel,
  segment,
  segmentTrack,
} from "../common/controls";

interface DiffToolbarProps {
  options: DiffOptions;
  onOptionsChange: (opts: DiffOptions) => void;
  viewMode: "split" | "unified";
  onViewModeChange: (mode: "split" | "unified") => void;
  onExportPatch: () => void;
  onExportMergePatch: () => void;
  onOpenApplyPatch: () => void;
  onSwapDocuments?: () => void;
}

export const DiffToolbar: React.FC<DiffToolbarProps> = ({
  options,
  onOptionsChange,
  viewMode,
  onViewModeChange,
  onExportPatch,
  onExportMergePatch,
  onOpenApplyPatch,
  onSwapDocuments,
}) => {
  const matchMode = options.arrayMatchMode || "index";

  return (
    <div className="flex flex-wrap items-center justify-between gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <div className="flex items-center gap-2">
          <label htmlFor="array-mode-select" className={fieldLabel}>
            Array identity
          </label>
          <select
            id="array-mode-select"
            value={matchMode}
            onChange={(e) =>
              onOptionsChange({ ...options, arrayMatchMode: e.target.value as ArrayMatchMode })
            }
            className={`${field} cursor-pointer`}
          >
            <option value="index">By index</option>
            <option value="key">By key</option>
            <option value="similarity">By structural similarity</option>
          </select>
        </div>

        {matchMode === "key" && (
          <div className="flex items-center gap-2">
            <label htmlFor="array-key-input" className={fieldLabel}>
              Key
            </label>
            <input
              id="array-key-input"
              type="text"
              value={options.arrayKey || "id"}
              onChange={(e) => onOptionsChange({ ...options, arrayKey: e.target.value })}
              placeholder="id"
              className={`${field} w-24 font-mono`}
            />
          </div>
        )}

        <label className="flex cursor-pointer select-none items-center gap-2 text-xs text-foreground-muted transition-colors hover:text-foreground">
          <input
            type="checkbox"
            checked={!!options.collapseUnchanged}
            onChange={(e) => onOptionsChange({ ...options, collapseUnchanged: e.target.checked })}
            className={checkbox}
          />
          Collapse unchanged
        </label>

        <div className={segmentTrack} role="group" aria-label="Diff layout">
          <button
            type="button"
            onClick={() => onViewModeChange("split")}
            aria-pressed={viewMode === "split"}
            className={segment(viewMode === "split")}
          >
            Side by side
          </button>
          <button
            type="button"
            onClick={() => onViewModeChange("unified")}
            aria-pressed={viewMode === "unified"}
            className={segment(viewMode === "unified")}
          >
            Unified
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        {onSwapDocuments && (
          <button
            type="button"
            onClick={onSwapDocuments}
            className={btnCompact}
            title="Swap the left and right documents"
          >
            <span aria-hidden="true">⇄</span>
            Swap
          </button>
        )}
        <button
          type="button"
          onClick={onExportPatch}
          aria-label="Export Patch (RFC 6902)"
          className={btnSecondary}
          title="Export an RFC 6902 JSON Patch describing left → right"
        >
          <Icon name="download" size="sm" />
          Export Patch (RFC 6902)
        </button>
        <button
          type="button"
          onClick={onExportMergePatch}
          className={btnCompact}
          title="Export an RFC 7386 JSON Merge Patch"
        >
          Merge Patch (RFC 7386)
        </button>
        <button
          type="button"
          onClick={onOpenApplyPatch}
          className={btnCompact}
          title="Apply a JSON Patch to one of the documents"
        >
          Apply Patch
        </button>
      </div>
    </div>
  );
};
