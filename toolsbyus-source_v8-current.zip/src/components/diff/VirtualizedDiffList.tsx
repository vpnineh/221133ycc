"use client";

import React, { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { FlatDiffRow, ChangeType } from "../../lib/diff/types";
import { Icon } from "../common/Icon";

interface VirtualizedDiffListProps {
  rows: FlatDiffRow[];
  rowHeight?: number;
  height?: number;
  viewMode?: "split" | "unified";
  activeIndex?: number;
  onRowClick?: (row: FlatDiffRow, index: number) => void;
}

export const VirtualizedDiffList: React.FC<VirtualizedDiffListProps> = ({
  rows,
  rowHeight = 30,
  height = 560,
  viewMode = "split",
  activeIndex,
  onRowClick,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);

  const totalRows = rows.length;
  const totalHeight = totalRows * rowHeight;

  const onScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  }, []);

  const buffer = 15;
  const visibleCount = Math.ceil(height / rowHeight);
  const startIndex = Math.max(0, Math.floor(scrollTop / rowHeight) - buffer);
  const endIndex = Math.min(totalRows, Math.floor(scrollTop / rowHeight) + visibleCount + buffer);

  const visibleRows = useMemo(() => {
    return rows.slice(startIndex, endIndex).map((row, idx) => ({
      row,
      index: startIndex + idx,
      top: (startIndex + idx) * rowHeight,
    }));
  }, [rows, startIndex, endIndex, rowHeight]);

  // Scroll active index into view
  useEffect(() => {
    if (activeIndex !== undefined && activeIndex >= 0 && containerRef.current) {
      const targetTop = activeIndex * rowHeight;
      const currentScroll = containerRef.current.scrollTop;
      if (targetTop < currentScroll || targetTop > currentScroll + height - rowHeight) {
        containerRef.current.scrollTop = targetTop - height / 2;
      }
    }
  }, [activeIndex, rowHeight, height]);

  /**
   * Arrow-key navigation for the list as a whole.
   *
   * The rows are click targets, and a click target with no keyboard equivalent
   * is unreachable without a mouse (WCAG 2.1.1). Making each row focusable
   * would instead bury the rest of the page behind thousands of tab stops, so
   * the list is one composite widget: Tab lands on it, arrows move within it.
   */
  const handleKeyDown = useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>) => {
      if (!onRowClick || totalRows === 0) return;
      const current = activeIndex ?? -1;
      let next: number | null = null;

      if (event.key === "ArrowDown") next = Math.min(totalRows - 1, current + 1);
      else if (event.key === "ArrowUp") next = Math.max(0, current <= 0 ? 0 : current - 1);
      else if (event.key === "Home") next = 0;
      else if (event.key === "End") next = totalRows - 1;
      else return;

      event.preventDefault();
      onRowClick(rows[next], next);
    },
    [onRowClick, rows, totalRows, activeIndex]
  );

  function getBadgeStyle(type: ChangeType) {
    switch (type) {
      case "ADD":
        return { glyph: "+", tone: "text-add", badge: "border-add bg-add-soft", rowBg: "bg-add-soft" };
      case "REMOVE":
        return { glyph: "-", tone: "text-del", badge: "border-del bg-del-soft", rowBg: "bg-del-soft" };
      case "TYPE_CHANGE":
        return { glyph: "~", tone: "text-type", badge: "border-type bg-type-soft", rowBg: "bg-type-soft" };
      case "MOVE":
        return { glyph: "\u21c4", tone: "text-move", badge: "border-move bg-move-soft", rowBg: "bg-move-soft" };
      case "REPLACE":
        return { glyph: "\u2260", tone: "text-mod", badge: "border-mod bg-mod-soft", rowBg: "bg-mod-soft" };
      default:
        return {
          glyph: "\u00a0",
          tone: "text-foreground-subtle",
          badge: "border-border",
          rowBg: "hover:bg-surface-elevated",
        };
    }
  }

  if (totalRows === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center rounded-lg border border-border bg-surface p-10 text-center"
        style={{ height }}
      >
        <span className="flex h-10 w-10 items-center justify-center rounded border border-border bg-surface-elevated text-foreground-subtle">
          <Icon name="diff" size="lg" />
        </span>
        <p className="mt-3 text-sm font-medium text-foreground">No differences to show</p>
        <p className="mt-1 max-w-sm text-xs leading-relaxed text-foreground-muted">
          Paste two JSON documents above. Comparison runs in a Web Worker, so the page stays
          responsive even on a multi-megabyte payload.
        </p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      onScroll={onScroll}
      onKeyDown={handleKeyDown}
      className="relative overflow-auto rounded-lg border border-border bg-background font-mono text-xs select-text focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent"
      style={{ height }}
      tabIndex={0}
      role="region"
      aria-label="Virtualized semantic diff viewer"
      aria-describedby="diff-keyboard-hint"
    >
      {/* One tab stop for the whole list, with the arrow keys moving inside it.
          Giving every row its own tabindex would put thousands of stops between
          the diff and the next control on the page. */}
      <p id="diff-keyboard-hint" className="sr-only">
        Use the up and down arrow keys to move between rows, Home and End to jump to the first or
        last row.
      </p>

      <div style={{ height: totalHeight, position: "relative", width: "100%", minWidth: "44rem" }}>
        {visibleRows.map(({ row, index, top }) => {
          const style = getBadgeStyle(row.type);
          const isSelected = activeIndex === index;
          const indentPx = row.depth * 16 + 8;

          return (
            <div
              key={row.id}
              onClick={() => onRowClick?.(row, index)}
              aria-current={isSelected ? "true" : undefined}
              style={{ position: "absolute", top, height: rowHeight, left: 0, right: 0 }}
              className={`flex cursor-pointer items-center border-b border-border transition-colors ${
                isSelected ? "bg-accent-soft ring-1 ring-inset ring-accent" : style.rowBg
              }`}
            >
              {/* Gutter: the two source line numbers and the change glyph. */}
              <div className="flex-none select-none border-r border-border bg-surface px-2 text-foreground-subtle">
                <span className="inline-block w-7 text-right tabular-nums">
                  {row.leftLineNum ?? ""}
                </span>
                <span className="inline-block w-7 text-right tabular-nums">
                  {row.rightLineNum ?? ""}
                </span>
                <span
                  className={`ml-2 inline-flex h-4 w-4 items-center justify-center rounded-sm border text-2xs font-bold ${style.badge} ${style.tone}`}
                  title={row.type}
                >
                  {style.glyph}
                </span>
              </div>

              <div
                className="flex flex-1 items-center gap-2 overflow-hidden whitespace-nowrap pr-2"
                style={{ paddingLeft: `${indentPx}px` }}
              >
                <span className="flex-none font-medium text-foreground">
                  {String(row.keyOrIndex)}
                  <span className="text-foreground-subtle">:</span>
                </span>

                {viewMode === "split" ? (
                  <div className="grid flex-1 grid-cols-2 gap-4 overflow-hidden">
                    <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                      {row.leftDisplay ? (
                        <span
                          className={
                            row.type === "REMOVE"
                              ? "text-del line-through"
                              : "text-foreground-muted"
                          }
                        >
                          {row.leftDisplay}
                        </span>
                      ) : (
                        <span className="italic text-foreground-subtle">absent</span>
                      )}
                    </div>
                    <div className="overflow-hidden text-ellipsis whitespace-nowrap">
                      {row.rightDisplay ? (
                        <span className={row.type === "ADD" ? "text-add" : "text-foreground-muted"}>
                          {row.rightDisplay}
                        </span>
                      ) : (
                        <span className="italic text-foreground-subtle">absent</span>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
                    {row.leftDisplay && (
                      <span
                        className={
                          row.type === "REMOVE" || row.type === "REPLACE"
                            ? "text-del"
                            : "text-foreground-muted"
                        }
                      >
                        {row.leftDisplay}
                      </span>
                    )}
                    {(row.type === "REPLACE" || row.type === "TYPE_CHANGE") && (
                      <span className="font-bold text-foreground-subtle" aria-hidden="true">
                        &rarr;
                      </span>
                    )}
                    {row.rightDisplay && (
                      <span
                        className={
                          row.type === "ADD" || row.type === "REPLACE"
                            ? "text-add"
                            : "text-foreground-muted"
                        }
                      >
                        {row.rightDisplay}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
