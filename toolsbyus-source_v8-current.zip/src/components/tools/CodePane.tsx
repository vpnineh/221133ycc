"use client";

import React, { useCallback, useMemo, useRef, useState } from "react";
import { usePageFileDrop } from "./usePageFileDrop";
import { useFileReader } from "./useFileReader";
import { fastByteLength } from "../../lib/limits";
import { Icon, type IconName } from "../common/Icon";

interface CodePaneProps {
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  readOnly?: boolean;
  error?: { message: string; line?: number; column?: number; caretSnippet?: string };
  actions?: React.ReactNode;
  /** Editor height in pixels. With `fill`, this becomes the minimum. */
  height?: number;
  /**
   * Grow to the height of the grid cell instead of staying fixed. Used where a
   * pane sits beside a taller sibling — the editor page's tree view — which
   * otherwise left several hundred pixels of dead space under the code.
   */
  fill?: boolean;
}

/**
 * Metrics shared by the textarea and the line-number gutter.
 *
 * Set as inline styles on both rather than as Tailwind classes: the gutter is
 * aligned to the textarea by arithmetic, so a future class change on one of
 * them silently shearing the numbers off the lines is exactly the failure to
 * design out.
 */
const LINE_HEIGHT = 20;
const FONT_SIZE = 12;
const PAD_Y = 10;
const PAD_X = 12;

/**
 * Above this size, line/column of the caret stops being reported.
 *
 * Deriving it means scanning the document from the start on every keystroke.
 * At a few hundred kilobytes that is invisible; at the 8MB main-thread ceiling
 * it is tens of milliseconds per character typed, which is precisely the kind
 * of quiet quadratic that makes an editor feel broken on exactly the payloads
 * people bring to a debugging tool.
 */
const CARET_READOUT_MAX_BYTES = 512 * 1024;

const INDENT = "  ";

function formatBytes(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}

/** Toolbar control. Compact under a mouse, 36px under a finger (WCAG 2.5.5). */
const ToolButton: React.FC<{
  icon: IconName;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  active?: boolean;
  title: string;
}> = ({ icon, label, onClick, disabled, active, title }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={disabled}
    title={title}
    aria-pressed={active}
    className={`inline-flex items-center gap-1.5 rounded border px-1.5 py-1 text-2xs transition-colors pointer-coarse:min-h-[44px] pointer-coarse:px-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${
      disabled
        ? "cursor-not-allowed border-border text-foreground-subtle opacity-50"
        : active
        ? "cursor-pointer border-accent-line bg-accent-soft text-accent"
        : "cursor-pointer border-border bg-surface text-foreground-muted hover:border-border-strong hover:text-foreground"
    }`}
  >
    <Icon name={icon} size="sm" />
    {/*
      Below `sm` the toolbar has room for glyphs only, but the label stays in
      the DOM rather than being removed by `hidden`. `hidden` would leave five
      buttons on a phone with no accessible name at all — an icon is not a name,
      and `title` is not dependable as the only one (WCAG 4.1.2).
    */}
    <span className="sr-only sm:not-sr-only">{label}</span>
  </button>
);

export const CodePane: React.FC<CodePaneProps> = ({
  label,
  value,
  onChange: onValueChange,
  placeholder = "Paste payload here…",
  readOnly = false,
  error,
  actions,
  height = 360,
  fill = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const editorAreaRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const { readFile, cancelRead, fileError } = useFileReader(onValueChange);
  const onChange = useCallback((next: string) => {
    cancelRead();
    onValueChange(next);
  }, [cancelRead, onValueChange]);
  React.useEffect(() => { cancelRead(); }, [value, readOnly, cancelRead]);
  // Off by default, as in every code editor a developer already uses — and it
  // is what puts the line-number gutter on screen without hunting for a toggle.
  // A pasted single-line blob is one press of Format away from being readable.
  const [wordWrap, setWordWrap] = useState(false);
  const [scrollTop, setScrollTop] = useState(0);
  const [caret, setCaret] = useState({ line: 1, column: 1 });
  // Set by Escape so the *next* Tab leaves the field instead of indenting.
  // Without this, Tab-to-indent turns the editor into a keyboard trap
  // (WCAG 2.1.2) — the one thing that must never be traded for convenience.
  const [tabEscapes, setTabEscapes] = useState(false);

  // These used to run on every render, uncached: `TextEncoder.encode`
  // allocated a full byte copy of the document and `split("\n")` allocated one
  // string per line. With two panes on a page and a multi-megabyte payload that
  // is hundreds of megabytes of garbage per keystroke — the single biggest
  // cause of the editor locking up on large input. Both are now allocation-free
  // and memoized on the value.
  const byteCount = useMemo(() => fastByteLength(value), [value]);
  // `value.trim()` allocates a whole second copy of the document just to test
  // for emptiness, which is the same trap at a smaller scale.
  const isBlank = useMemo(() => value.trim().length === 0, [value]);
  const lineCount = useMemo(() => {
    if (value.length === 0) return 1;
    let lines = 1;
    for (let i = value.indexOf("\n"); i !== -1; i = value.indexOf("\n", i + 1)) lines++;
    return lines;
  }, [value]);

  const caretReadoutEnabled = value.length <= CARET_READOUT_MAX_BYTES;

  const updateCaret = useCallback(() => {
    const el = textareaRef.current;
    if (!el || !caretReadoutEnabled) return;
    const upTo = el.selectionStart;
    let line = 1;
    let lineStart = 0;
    for (let i = el.value.indexOf("\n"); i !== -1 && i < upTo; i = el.value.indexOf("\n", i + 1)) {
      line++;
      lineStart = i + 1;
    }
    setCaret({ line, column: upTo - lineStart + 1 });
  }, [caretReadoutEnabled]);

  /**
   * Writes through execCommand when available so the browser's own undo stack
   * survives. Assigning to `.value` wipes it, and losing Ctrl+Z after an
   * accidental Tab is worse than not having Tab at all.
   */
  const replaceSelection = useCallback(
    (el: HTMLTextAreaElement, text: string, selectStart: number, selectEnd: number) => {
      el.setSelectionRange(selectStart, selectEnd);
      let inserted = false;
      try {
        inserted = document.execCommand("insertText", false, text);
      } catch {
        inserted = false;
      }
      if (!inserted) {
        const next = el.value.slice(0, selectStart) + text + el.value.slice(selectEnd);
        el.value = next;
        el.setSelectionRange(selectStart + text.length, selectStart + text.length);
      }
      onChange(el.value);
    },
    [onChange]
  );

  const handleKeyDown = useCallback(
    (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (event.key === "Escape") {
        setTabEscapes(true);
        return;
      }
      if (event.key !== "Tab" || readOnly) {
        if (tabEscapes) setTabEscapes(false);
        return;
      }
      if (tabEscapes) {
        // Let the browser move focus, and re-arm indenting for next time.
        setTabEscapes(false);
        return;
      }

      const el = event.currentTarget;
      const { selectionStart, selectionEnd } = el;
      event.preventDefault();

      const spansLines = el.value.slice(selectionStart, selectionEnd).includes("\n");

      if (!spansLines && !event.shiftKey) {
        replaceSelection(el, INDENT, selectionStart, selectionEnd);
        return;
      }

      // Block indent / outdent: rewrite whole lines so the selection keeps its
      // meaning rather than being replaced by a tab character.
      const blockStart = el.value.lastIndexOf("\n", selectionStart - 1) + 1;
      const lineEnd = el.value.indexOf("\n", selectionEnd);
      const blockEnd = lineEnd === -1 ? el.value.length : lineEnd;
      const block = el.value.slice(blockStart, blockEnd);

      const shifted = event.shiftKey
        ? block
            .split("\n")
            .map((line) => (line.startsWith(INDENT) ? line.slice(INDENT.length) : line.replace(/^\s/, "")))
            .join("\n")
        : block
            .split("\n")
            .map((line) => INDENT + line)
            .join("\n");

      replaceSelection(el, shifted, blockStart, blockEnd);
      el.setSelectionRange(blockStart, blockStart + shifted.length);
    },
    [readOnly, tabEscapes, replaceSelection]
  );

  const handleCopy = async () => {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard permission denied; the text stays selectable by hand.
    }
  };

  const handlePrettify = () => {
    if (isBlank) return;
    try {
      onChange(JSON.stringify(JSON.parse(value), null, 2));
    } catch {
      // Not valid JSON; leave the buffer untouched rather than mangling it.
    }
  };

  /** Puts the caret on a reported error line and selects it. */
  const jumpToLine = (target: number) => {
    const el = textareaRef.current;
    if (!el) return;
    let start = 0;
    for (let i = 1; i < target; i++) {
      const next = el.value.indexOf("\n", start);
      if (next === -1) break;
      start = next + 1;
    }
    const end = el.value.indexOf("\n", start);
    el.focus();
    el.setSelectionRange(start, end === -1 ? el.value.length : end);
    el.scrollTop = Math.max(0, (target - 3) * LINE_HEIGHT);
    setScrollTop(el.scrollTop);
    updateCaret();
  };

  // The gutter is exact only when one logical line is one visual line, so it
  // is shown with wrapping off and hidden with it on, rather than drifting
  // further out of alignment the longer the document gets.
  // The gutter renders only the line numbers in view, so it needs the real
  // pixel height of the editor area. That is `height` when the pane is fixed,
  // and whatever the grid gave it when the pane fills.
  const [measuredHeight, setMeasuredHeight] = useState(height);
  React.useEffect(() => {
    if (!fill) return;
    const el = editorAreaRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(([entry]) => {
      setMeasuredHeight(entry.contentRect.height);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, [fill]);

  const paneHeight = fill ? measuredHeight : height;
  const showGutter = !wordWrap;
  const gutterDigits = Math.max(2, String(lineCount).length);
  const firstVisible = Math.max(0, Math.floor((scrollTop - PAD_Y) / LINE_HEIGHT));
  const visibleLineNumbers = useMemo(() => {
    if (!showGutter) return [];
    const count = Math.ceil(paneHeight / LINE_HEIGHT) + 2;
    const out: number[] = [];
    for (let i = firstVisible; i < Math.min(firstVisible + count, lineCount); i++) out.push(i + 1);
    return out;
  }, [showGutter, firstVisible, paneHeight, lineCount]);

  const { ref: dropRef, dragging: isDragOver } = usePageFileDrop((files) => {
    if (files[0]) readFile(files[0]);
  }, { enabled: !readOnly });

  const editorFont: React.CSSProperties = {
    fontFamily: "var(--font-mono), ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",
    fontSize: FONT_SIZE,
    lineHeight: `${LINE_HEIGHT}px`,
  };

  return (
    <div
      ref={dropRef}
      className={`relative flex flex-col overflow-hidden rounded-lg border bg-surface transition-colors ${
        fill ? "h-full" : ""
      } ${isDragOver ? "border-accent" : "border-border focus-within:border-border-strong"}`}
    >
      {isDragOver && <div role="status" className="pointer-events-none fixed inset-3 z-[100] flex items-center justify-center rounded-xl border-2 border-accent bg-background/95 p-6 text-xl font-semibold">Drop a file to open in {label}</div>}
      {fileError && <p role="alert" className="px-3 py-2 text-sm text-danger">{fileError}</p>}
      {/* Toolbar. Wraps rather than overflowing: on a 390px screen a single
          non-wrapping row pushed "Copy" entirely off the pane and clipped
          "Clear", leaving both unreachable on a phone. */}
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 border-b border-border bg-surface-elevated px-3 py-2">
        <div className="flex min-w-0 items-baseline gap-2">
          <span className="truncate text-xs font-semibold text-foreground">{label}</span>
          {readOnly && (
            <span className="rounded border border-border px-1.5 py-0.5 font-mono text-2xs text-foreground-subtle">
              read-only
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-1">
          {actions}

          <ToolButton
            icon="wrap"
            label="Wrap"
            title={
              wordWrap
                ? "Turn off soft wrap (shows the line-number gutter)"
                : "Turn on soft wrap (hides the line-number gutter)"
            }
            active={wordWrap}
            onClick={() => setWordWrap((w) => !w)}
          />

          {!readOnly && (
            <>
              <ToolButton
                icon="wand"
                label="Format"
                title="Re-indent this pane with 2 spaces"
                disabled={isBlank}
                onClick={handlePrettify}
              />
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".json,.txt,.jsonc,.diff,.patch,.csv,.xml,.yaml,.yml,.html,.css,.sql,.md"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) readFile(file);
                  e.target.value = "";
                }}
              />
              <ToolButton
                icon="upload"
                label="Open"
                title="Open a file, or drop anywhere on this page (uses the focused input pane)"
                onClick={() => fileInputRef.current?.click()}
              />
              <ToolButton
                icon="trash"
                label="Clear"
                title="Empty this pane"
                disabled={!value}
                onClick={() => onChange("")}
              />
            </>
          )}

          <ToolButton
            icon={copied ? "check" : "copy"}
            label={copied ? "Copied" : "Copy"}
            title="Copy this pane to the clipboard"
            disabled={!value}
            active={copied}
            onClick={handleCopy}
          />
        </div>
      </div>

      {/* Editor */}
      <div
        ref={editorAreaRef}
        className={`relative flex ${fill ? "min-h-0 flex-1" : ""}`}
        style={fill ? { minHeight: height } : { height }}
      >
        {showGutter && (
          <div
            aria-hidden="true"
            className="relative flex-none select-none overflow-hidden border-r border-border bg-surface-elevated text-right text-foreground-subtle"
            style={{
              ...editorFont,
              width: `calc(${gutterDigits}ch + ${PAD_X * 2}px)`,
              paddingLeft: PAD_X,
              paddingRight: PAD_X,
            }}
          >
            {visibleLineNumbers.map((n) => (
              <div
                key={n}
                className="absolute"
                style={{
                  // Absolute children resolve against the padding box, which
                  // ignores the parent's padding, so the inset is explicit.
                  right: PAD_X,
                  top: PAD_Y + (n - 1) * LINE_HEIGHT - scrollTop,
                  height: LINE_HEIGHT,
                }}
              >
                {n}
              </div>
            ))}
          </div>
        )}

        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
          onKeyDown={handleKeyDown}
          onKeyUp={updateCaret}
          onClick={updateCaret}
          onSelect={updateCaret}
          onBlur={() => setTabEscapes(false)}
          readOnly={readOnly}
          placeholder={placeholder}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          className={`h-full min-w-0 flex-1 resize-none bg-transparent text-foreground placeholder-foreground-subtle focus:outline-none ${
            wordWrap ? "whitespace-pre-wrap break-words" : "overflow-x-auto whitespace-pre"
          }`}
          style={{ ...editorFont, padding: `${PAD_Y}px ${PAD_X}px` }}
        />

        {isDragOver && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-accent bg-surface">
            <Icon name="download" size="lg" className="text-accent" />
            <span className="font-mono text-xs font-medium text-accent">Drop file to load</span>
          </div>
        )}
      </div>

      {/* Status bar */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-border bg-surface-elevated px-3 py-1.5 font-mono text-2xs text-foreground-subtle">
        <span>{formatBytes(byteCount)}</span>
        <span aria-hidden="true">·</span>
        <span>
          {lineCount} {lineCount === 1 ? "line" : "lines"}
        </span>
        {!readOnly && (
          <>
            <span aria-hidden="true">·</span>
            <span>
              {caretReadoutEnabled ? (
                <>
                  Ln {caret.line}, Col {caret.column}
                </>
              ) : (
                "Ln —"
              )}
            </span>
          </>
        )}
        {!readOnly && (
          <span className="ml-auto hidden sm:inline">
            {tabEscapes ? (
              <span className="text-accent">Tab now moves focus</span>
            ) : (
              <>Tab indents · Esc then Tab exits</>
            )}
          </span>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="border-t border-border bg-danger-soft px-3 py-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <Icon name="warning" size="sm" className="text-danger" />
            <span className="text-xs font-semibold text-danger">
              Syntax error
              {error.line !== undefined && (
                <> at line {error.line}, column {error.column}</>
              )}
            </span>
            {error.line !== undefined && !readOnly && (
              <button
                type="button"
                onClick={() => jumpToLine(error.line as number)}
                className="ml-auto cursor-pointer rounded border border-border bg-surface px-1.5 py-0.5 font-mono text-2xs text-foreground-muted transition-colors hover:border-border-strong hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] pointer-coarse:px-2.5"
              >
                Jump to line
              </button>
            )}
          </div>
          <p className="mt-1.5 text-2xs leading-relaxed text-foreground-muted">{error.message}</p>
          {error.caretSnippet && (
            <pre
              className="mt-2 select-text overflow-x-auto rounded border border-border bg-surface p-2 text-2xs text-foreground-muted"
              style={{ fontFamily: "var(--font-mono), ui-monospace, monospace" }}
            >
              {error.caretSnippet}
            </pre>
          )}
        </div>
      )}
    </div>
  );
};
