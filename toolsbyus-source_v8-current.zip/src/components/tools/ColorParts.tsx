"use client";

import React, { useCallback, useEffect, useId, useRef, useState } from "react";
import { Icon } from "../common/Icon";
import { contrastRatio, parseColor, toHex, type Rgb } from "../../lib/color";

/**
 * The pieces every colour tool on this site needs.
 *
 * Kept together rather than in one file each because they are small, they are
 * only ever used by the twelve colour pages, and they share one decision: a
 * swatch is a control, not a picture. You can click it, copy it, and read what
 * it is — so each of them carries its own value and its own copy affordance
 * instead of leaving that to whichever page happens to render it.
 */

const WHITE: Rgb = { r: 255, g: 255, b: 255, a: 1 };
const BLACK: Rgb = { r: 0, g: 0, b: 0, a: 1 };

/** Black or white, whichever is legible on the given colour. */
export function readableOn(color: Rgb): string {
  return contrastRatio(WHITE, color) >= contrastRatio(BLACK, color) ? "#ffffff" : "#000000";
}

/**
 * Copy, with the confirmation that makes it obvious it worked.
 *
 * Every colour tool here ends in "and now put that value somewhere else", so
 * the copy affordance is the most-pressed control on the page. Two seconds of
 * "Copied" is long enough to read and short enough not to hide the value.
 */
export function useCopy(): { copied: string | null; copy: (value: string) => void } {
  const [copied, setCopied] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (timer.current !== null) clearTimeout(timer.current);
    },
    []
  );

  const copy = useCallback((value: string) => {
    navigator.clipboard
      .writeText(value)
      .then(() => {
        setCopied(value);
        if (timer.current !== null) clearTimeout(timer.current);
        timer.current = setTimeout(() => setCopied(null), 2000);
      })
      // A rejected clipboard write (no permission, insecure context) must not
      // throw into a render. The value is still on screen to select by hand.
      .catch(() => {});
  }, []);

  return { copied, copy };
}

/* ------------------------------------------------------------------------- */

interface ColorInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  /** The parsed colour, or null when the text is not a colour. */
  parsed: Rgb | null;
  placeholder?: string;
  id?: string;
}

/**
 * A text field and a native colour well, bound together.
 *
 * The native `<input type="color">` is here because it is the only way to reach
 * the operating system's own picker — including the eyedropper that samples any
 * pixel on screen, which no amount of canvas work in a page can replicate. It
 * cannot express alpha, so it is a companion to the text field rather than a
 * replacement for it: type `#ff000080` and the well shows the opaque red while
 * the field keeps the alpha.
 */
export const ColorInput: React.FC<ColorInputProps> = ({
  label,
  value,
  onChange,
  parsed,
  placeholder = "#00696f",
  id,
}) => {
  const generated = useId();
  const fieldId = id ?? generated;
  const invalid = value.trim() !== "" && parsed === null;

  return (
    <div>
      <label htmlFor={fieldId} className="mb-2 block text-sm text-foreground-muted">
        {label}
      </label>
      <div
        className={`flex items-center gap-3 rounded-lg bg-surface-elevated p-2 transition-colors ${
          invalid ? "ring-2 ring-inset ring-danger" : ""
        }`}
      >
        <input
          type="color"
          aria-label={`${label} — pick from the system colour picker`}
          value={parsed ? toHex(parsed, { alpha: "never" }) : "#000000"}
          onChange={(event) => onChange(event.target.value)}
          className="h-11 w-12 flex-none cursor-pointer rounded border-0 bg-transparent p-0 [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded [&::-webkit-color-swatch]:border-0"
        />
        <input
          id={fieldId}
          type="text"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          spellCheck={false}
          autoComplete="off"
          autoCapitalize="off"
          aria-invalid={invalid}
          aria-describedby={invalid ? `${fieldId}-error` : undefined}
          className="w-full min-w-0 border-0 bg-transparent font-mono text-base text-foreground outline-none"
        />
      </div>
      {invalid && (
        <p id={`${fieldId}-error`} role="status" className="mt-2 text-sm text-danger">
          Not a colour this understands. Try a hex value, <code>rgb(…)</code>,{" "}
          <code>hsl(…)</code>, <code>oklch(…)</code>, or a CSS colour name.
        </p>
      )}
    </div>
  );
};

/* ------------------------------------------------------------------------- */

interface SwatchProps {
  color: Rgb;
  /** The string copied when the swatch is pressed. */
  value: string;
  /** Small print inside the swatch, above the value. */
  caption?: string;
  copied: string | null;
  onCopy: (value: string) => void;
  className?: string;
}

/**
 * A colour, its value, and one press to take it away.
 *
 * The label is drawn in whichever of black or white is legible on the swatch —
 * measured, not guessed from a lightness threshold, because a threshold picks
 * wrong on saturated yellows and cyans every time.
 */
export const Swatch: React.FC<SwatchProps> = ({
  color,
  value,
  caption,
  copied,
  onCopy,
  className = "",
}) => {
  const ink = readableOn(color);
  const isCopied = copied === value;

  return (
    <button
      type="button"
      onClick={() => onCopy(value)}
      title={`Copy ${value}`}
      className={`group flex w-full cursor-pointer flex-col justify-end rounded-lg p-3 text-left transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-surface ${className}`}
      style={{ backgroundColor: toHex(color), color: ink }}
    >
      {caption && <span className="text-xs opacity-70">{caption}</span>}
      <span className="flex items-center gap-1.5 font-mono text-sm">
        {isCopied ? (
          <>
            <Icon name="check" size="sm" />
            Copied
          </>
        ) : (
          value
        )}
      </span>
    </button>
  );
};

/* ------------------------------------------------------------------------- */

interface ValueRowProps {
  label: string;
  value: string;
  copied: string | null;
  onCopy: (value: string) => void;
  /** Extra context to the right of the value — a warning, a note. */
  note?: React.ReactNode;
}

/** One format, its value, and a copy button. The converter pages are a stack of these. */
export const ValueRow: React.FC<ValueRowProps> = ({ label, value, copied, onCopy, note }) => {
  const isCopied = copied === value;
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-border py-3">
      <span className="w-16 flex-none text-sm font-medium text-foreground">{label}</span>
      <code className="min-w-0 flex-1 break-all font-mono text-[0.9375rem] text-foreground-muted">
        {value}
      </code>
      {note}
      <button
        type="button"
        onClick={() => onCopy(value)}
        aria-label={`Copy the ${label} value`}
        className="inline-flex flex-none cursor-pointer items-center gap-1.5 rounded-pill bg-surface-elevated px-3 py-1.5 text-xs font-medium text-foreground-muted transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] pointer-coarse:px-4"
      >
        <Icon name={isCopied ? "check" : "copy"} size="sm" />
        {isCopied ? "Copied" : "Copy"}
      </button>
    </div>
  );
};

/* ------------------------------------------------------------------------- */

/**
 * Keeps a text field and a parsed colour in step.
 *
 * The text is the source of truth, not the colour: a half-typed `#ff00` has to
 * stay on screen as the person types the rest of it, so the parsed value simply
 * goes null for a moment rather than the field snapping back to the last good
 * colour.
 */
export function useColorField(initial: string): {
  text: string;
  setText: (value: string) => void;
  color: Rgb | null;
} {
  const [text, setText] = useState(initial);
  return { text, setText, color: parseColor(text) };
}
