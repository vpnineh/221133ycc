"use client";

import React, { useCallback, useRef } from "react";

/**
 * A drag-to-crop overlay on top of a preview image.
 *
 * The rectangle is held in *source pixel* coordinates, not in the pixels of the
 * element on screen. That is the whole design decision here, and it is what
 * makes the tool correct: the preview is whatever size the layout gives it, it
 * changes when the window is resized, and on a phone it is a fraction of the
 * photo's real dimensions. Storing screen coordinates and converting at the end
 * means the crop moves when the layout does, and rounds differently depending
 * on how wide the browser happened to be.
 *
 * Pointer events rather than mouse events, so a finger and a stylus work
 * without a second code path, with `setPointerCapture` so a drag that leaves
 * the element still tracks — releasing outside the image otherwise leaves the
 * rectangle stuck to the cursor.
 */

export interface CropRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface CropCanvasProps {
  /** Object URL of the image being cropped. */
  src: string;
  /** Natural dimensions, which the rectangle is expressed in. */
  naturalWidth: number;
  naturalHeight: number;
  rect: CropRect;
  onChange: (rect: CropRect) => void;
  /** width / height, or null for a free crop. */
  aspect: number | null;
}

type Handle = "move" | "nw" | "ne" | "sw" | "se";

interface DragState {
  handle: Handle;
  startX: number;
  startY: number;
  origin: CropRect;
  scale: number;
}

const MIN_SIZE = 16;

export const CropCanvas: React.FC<CropCanvasProps> = ({
  src,
  naturalWidth,
  naturalHeight,
  rect,
  onChange,
  aspect,
}) => {
  const frameRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<DragState | null>(null);

  /**
   * One handler for all five grab points, keyed off a data attribute.
   *
   * A `begin(handle)` factory would be tidier to read, but it is called during
   * render to produce each handler, and anything called during render must not
   * touch a ref. Reading the handle from the element at pointer-down keeps
   * every ref access inside the event itself, which is both the rule and the
   * honest description of when these values are needed.
   */
  const begin = useCallback(
    (event: React.PointerEvent<HTMLElement>) => {
      event.preventDefault();
      event.stopPropagation();
      (event.target as Element).setPointerCapture(event.pointerId);

      const frame = frameRef.current;
      // Displayed pixels per source pixel, sampled now: the preview's width is
      // whatever the layout gives it, and it changes when the window does.
      const scale = frame && naturalWidth > 0 ? frame.clientWidth / naturalWidth : 1;

      dragRef.current = {
        handle: (event.currentTarget.dataset.handle as Handle) ?? "move",
        startX: event.clientX,
        startY: event.clientY,
        origin: { ...rect },
        scale,
      };
    },
    [naturalWidth, rect]
  );

  const move = useCallback(
    (event: React.PointerEvent) => {
      const drag = dragRef.current;
      if (!drag || drag.scale === 0) return;

      const dx = (event.clientX - drag.startX) / drag.scale;
      const dy = (event.clientY - drag.startY) / drag.scale;
      onChange(applyDrag(drag, dx, dy, naturalWidth, naturalHeight, aspect));
    },
    [aspect, naturalHeight, naturalWidth, onChange]
  );

  const end = useCallback((event: React.PointerEvent) => {
    if (dragRef.current) {
      (event.target as Element).releasePointerCapture?.(event.pointerId);
      dragRef.current = null;
    }
  }, []);

  const box = {
    left: `${(rect.x / naturalWidth) * 100}%`,
    top: `${(rect.y / naturalHeight) * 100}%`,
    width: `${(rect.width / naturalWidth) * 100}%`,
    height: `${(rect.height / naturalHeight) * 100}%`,
  };

  return (
    <div
      ref={frameRef}
      onPointerMove={move}
      onPointerUp={end}
      onPointerCancel={end}
      className="relative mx-auto w-full max-w-2xl touch-none select-none overflow-hidden rounded-lg border border-border bg-checkerboard"
      style={{ aspectRatio: `${naturalWidth} / ${naturalHeight}` }}
    >
      {/* A blob URL for a local file; next/image cannot take one. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt="Crop preview"
        width={naturalWidth}
        height={naturalHeight}
        draggable={false}
        className="pointer-events-none absolute inset-0 h-full w-full object-contain"
      />

      {/* The area outside the crop, dimmed. Four divs rather than one box with a
          giant box-shadow: the shadow version repaints the whole element on
          every pointer move, which is visible as lag on a large photo. */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 bg-scrim" style={{ height: box.top }} />
        <div
          className="absolute inset-x-0 bottom-0 bg-scrim"
          style={{ top: `calc(${box.top} + ${box.height})` }}
        />
        <div
          className="absolute left-0 bg-scrim"
          style={{ top: box.top, height: box.height, width: box.left }}
        />
        <div
          className="absolute right-0 bg-scrim"
          style={{ top: box.top, height: box.height, left: `calc(${box.left} + ${box.width})` }}
        />
      </div>

      <div
        data-handle="move"
        onPointerDown={begin}
        role="application"
        aria-label={`Crop region, ${Math.round(rect.width)} by ${Math.round(rect.height)} pixels`}
        className="absolute cursor-move border-2 border-accent-solid"
        style={box}
      >
        {/* Rule-of-thirds guides: the reason a crop looks composed rather than
            merely centred, and free to draw. */}
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <div className="absolute inset-y-0 left-1/3 w-px bg-white" />
          <div className="absolute inset-y-0 left-2/3 w-px bg-white" />
          <div className="absolute inset-x-0 top-1/3 h-px bg-white" />
          <div className="absolute inset-x-0 top-2/3 h-px bg-white" />
        </div>

        {(
          [
            ["nw", "-left-1.5 -top-1.5 cursor-nwse-resize"],
            ["ne", "-right-1.5 -top-1.5 cursor-nesw-resize"],
            ["sw", "-bottom-1.5 -left-1.5 cursor-nesw-resize"],
            ["se", "-bottom-1.5 -right-1.5 cursor-nwse-resize"],
          ] as const
        ).map(([handle, position]) => (
          <span
            key={handle}
            data-handle={handle}
            onPointerDown={begin}
            className={`absolute h-3 w-3 rounded-sm border border-white bg-accent-solid ${position}`}
          />
        ))}
      </div>

      <span className="pointer-events-none absolute bottom-1 right-1 rounded bg-scrim px-1.5 py-0.5 font-mono text-2xs text-white">
        {Math.round(rect.width)} × {Math.round(rect.height)}
      </span>
    </div>
  );
};

/**
 * Applies a drag to the rectangle, clamped to the image and to the aspect ratio.
 *
 * Order matters: the aspect ratio is enforced before the clamp to the image
 * bounds, because doing it the other way round lets a corner dragged past the
 * edge produce a rectangle that satisfies neither — clamped in one axis and
 * still ratio-locked in the other, which reads on screen as the box refusing to
 * move.
 */
export function applyDrag(
  drag: { handle: Handle; origin: CropRect },
  dx: number,
  dy: number,
  imageWidth: number,
  imageHeight: number,
  aspect: number | null
): CropRect {
  const origin = drag.origin;

  if (drag.handle === "move") {
    return {
      ...origin,
      x: clamp(origin.x + dx, 0, imageWidth - origin.width),
      y: clamp(origin.y + dy, 0, imageHeight - origin.height),
    };
  }

  const west = drag.handle === "nw" || drag.handle === "sw";
  const north = drag.handle === "nw" || drag.handle === "ne";

  let width = Math.max(MIN_SIZE, west ? origin.width - dx : origin.width + dx);
  let height = Math.max(MIN_SIZE, north ? origin.height - dy : origin.height + dy);

  if (aspect) {
    // Follow whichever axis the pointer moved further in, so a diagonal drag
    // does not snap to one edge and feel stuck.
    if (Math.abs(dx) > Math.abs(dy)) height = width / aspect;
    else width = height * aspect;
  }

  // The anchor is the corner opposite the handle, which stays put.
  const anchorX = west ? origin.x + origin.width : origin.x;
  const anchorY = north ? origin.y + origin.height : origin.y;

  width = Math.min(width, west ? anchorX : imageWidth - anchorX);
  height = Math.min(height, north ? anchorY : imageHeight - anchorY);
  if (aspect) {
    // Re-apply after clamping so the ratio survives hitting an edge.
    if (width / aspect > height) width = height * aspect;
    else height = width / aspect;
  }

  return {
    x: west ? anchorX - width : anchorX,
    y: north ? anchorY - height : anchorY,
    width: Math.max(MIN_SIZE, width),
    height: Math.max(MIN_SIZE, height),
  };
}

function clamp(value: number, low: number, high: number): number {
  return Math.min(Math.max(value, low), Math.max(low, high));
}

/** The largest rectangle of a given ratio that fits, centred. */
export function centredRect(
  imageWidth: number,
  imageHeight: number,
  aspect: number | null
): CropRect {
  if (!aspect) {
    const width = imageWidth * 0.8;
    const height = imageHeight * 0.8;
    return { x: (imageWidth - width) / 2, y: (imageHeight - height) / 2, width, height };
  }

  let width = imageWidth;
  let height = width / aspect;
  if (height > imageHeight) {
    height = imageHeight;
    width = height * aspect;
  }
  return { x: (imageWidth - width) / 2, y: (imageHeight - height) / 2, width, height };
}
