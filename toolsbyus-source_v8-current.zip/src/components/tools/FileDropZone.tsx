"use client";

import React, { useCallback, useEffect, useId, useRef, useState } from "react";
import { usePageFileDrop } from "./usePageFileDrop";
import { Icon } from "../common/Icon";
import { Notice } from "../common/Notice";
import { btnCompact } from "../common/controls";
import {
  acceptFiles,
  acceptAttribute,
  formatBytes,
  MAX_FILE_BYTES,
  type AcceptedFile,
} from "../../lib/files";

/**
 * The file input every Phase B tool starts with.
 *
 * Three ways in, because people genuinely use all three: drag and drop, the
 * file picker, and paste. Paste is the one usually missing and the one that
 * matters most for a screenshot — Print Screen puts an image on the clipboard
 * and nowhere else, so a tool without paste support forces a detour through
 * saving a file.
 *
 * Drag-and-drop needs a counter rather than a boolean for its highlight state:
 * `dragenter` and `dragleave` both fire when the pointer crosses a child
 * element, so a boolean flickers off the moment the cursor moves over the text
 * inside the drop zone.
 */

interface FileDropZoneProps {
  /** Extensions and MIME patterns: [".pdf"], ["image/*"]. */
  accept: string[];
  files: AcceptedFile[];
  onChange: (files: AcceptedFile[]) => void;
  multiple?: boolean;
  /** What the zone says before anything is dropped. */
  label?: string;
  /** Allow reordering the list, which merge and page-order tools need. */
  reorderable?: boolean;
  disabled?: boolean;
}

export const FileDropZone: React.FC<FileDropZoneProps> = ({
  accept,
  files,
  onChange,
  multiple = false,
  label,
  reorderable = false,
  disabled = false,
}) => {
  const inputId = useId();
  const inputRef = useRef<HTMLInputElement>(null);
  const [rejected, setRejected] = useState<string[]>([]);
  // A counter, not a boolean: dragenter/dragleave fire per child element.

  const add = useCallback(
    (incoming: FileList | File[]) => {
      const result = acceptFiles(incoming, { accept, existing: multiple ? files : [], multiple });
      setRejected(result.rejected);
      if (result.accepted.length === 0) return;
      onChange(multiple ? [...files, ...result.accepted] : result.accepted);
    },
    [accept, files, multiple, onChange]
  );

  const { ref: dropRef, dragging } = usePageFileDrop(add, { disabled });

  // Paste anywhere on the page while this tool is mounted. Scoped to the
  // document rather than the zone because the zone is rarely focused, and a
  // paste target nobody can find is not a feature.
  useEffect(() => {
    if (disabled) return;
    const onPaste = (event: ClipboardEvent) => {
      const items = event.clipboardData?.files;
      if (!items || items.length === 0) return;
      // Only intercept when the paste is actually a file; pasting text into an
      // input on the same page must still work.
      event.preventDefault();
      add(items);
    };
    document.addEventListener("paste", onPaste);
    return () => document.removeEventListener("paste", onPaste);
  }, [add, disabled]);

  const remove = (id: string) => {
    if (disabled) return;
    onChange(files.filter((entry) => entry.id !== id));
    setRejected([]);
  };

  const move = (index: number, delta: number) => {
    if (disabled) return;
    const target = index + delta;
    if (target < 0 || target >= files.length) return;
    const next = [...files];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  };

  const totalBytes = files.reduce((sum, entry) => sum + entry.file.size, 0);

  return (
    <div ref={dropRef} className="space-y-3">
      {dragging && (
        <div className="pointer-events-none fixed inset-3 z-[100] flex items-center justify-center rounded-xl border-2 border-accent bg-background/95 p-6" role="status" aria-live="polite">
          <div className="text-center">
            <Icon name="upload" size="2xl" className="mx-auto mb-4 text-accent" />
            <p className="text-2xl font-semibold tracking-tight">{disabled ? "Please wait for the current task" : "Drop your file anywhere"}</p>
            <p className="mt-2 text-sm text-foreground-muted">{disabled ? "You can add files when processing finishes." : `Accepted: ${accept.join(", ")} · Up to ${formatBytes(MAX_FILE_BYTES)} per file`}</p>
          </div>
        </div>
      )}
      <div
        className={`rounded-lg px-6 py-12 text-center transition-colors ${
          dragging && !disabled
            ? "bg-accent-soft ring-2 ring-inset ring-accent"
            : "bg-surface-elevated hover:bg-border"
        } ${disabled ? "opacity-50" : ""}`}
      >
        <input
          ref={inputRef}
          id={inputId}
          type="file"
          accept={acceptAttribute(accept)}
          multiple={multiple}
          disabled={disabled}
          onChange={(event) => {
            if (event.target.files) add(event.target.files);
            // Reset so selecting the same file twice fires a change event.
            event.target.value = "";
          }}
          aria-label="Choose files"
          className="sr-only"
        />

        <p className="text-xl font-semibold tracking-[-0.022em] text-foreground">
          {label ?? `Drop ${multiple ? "PDFs" : "a file"} here`}
        </p>
        <p className="mt-1.5 text-sm text-foreground-muted">
          Drop anywhere on this page, choose {multiple ? "files" : "a file"}, or paste — up to{" "}
          {formatBytes(MAX_FILE_BYTES)} each
        </p>

        <button
          type="button"
          disabled={disabled}
          onClick={() => inputRef.current?.click()}
          className="mt-6 inline-flex cursor-pointer items-center gap-2 rounded-pill bg-surface px-6 py-3 text-[0.9375rem] font-medium text-foreground transition-colors hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent disabled:cursor-not-allowed"
        >
          <Icon name="upload" size="md" className="text-foreground-subtle" />
          Choose {multiple ? "files" : "a file"}
        </button>
      </div>

      {rejected.map((reason) => (
        <Notice key={reason} tone="warn">
          {reason}
        </Notice>
      ))}

      {files.length > 0 && (
        /* No box. The caption row names what the list is and the hairlines
           between rows are the only rules, which is what a table wants and
           what a card does not. */
        <div className="pt-4">
          <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 px-1 pb-3">
            <span className="text-[0.9375rem] font-semibold tracking-tight text-foreground">
              {reorderable ? "Merge order" : files.length === 1 ? "Your file" : "Your files"}
            </span>
            {reorderable && files.length > 1 && (
              <span className="text-sm text-foreground-subtle">
                use the arrows to move a row
              </span>
            )}
            <span className="ml-auto font-mono text-xs text-foreground-subtle">
              {files.length} file{files.length === 1 ? "" : "s"} · {formatBytes(totalBytes)}
            </span>
            <button
              type="button"
              disabled={disabled}
              onClick={() => {
                onChange([]);
                setRejected([]);
              }}
              className="cursor-pointer rounded text-xs text-foreground-subtle transition-colors hover:text-danger focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              Clear
            </button>
          </div>

          <ul>
            {files.map((entry, index) => (
              <li
                key={entry.id}
                className="flex items-center gap-3 border-t border-border px-1 py-3"
              >
                {reorderable && (
                  <span className="w-5 flex-none font-mono text-xs text-foreground-subtle">
                    {index + 1}
                  </span>
                )}
                <span
                  className="min-w-0 flex-1 truncate text-[0.9375rem] text-foreground"
                  title={entry.file.name}
                >
                  {entry.file.name}
                </span>
                <span className="flex-none font-mono text-xs text-foreground-subtle">
                  {formatBytes(entry.file.size)}
                </span>

                {reorderable && files.length > 1 && (
                  <span className="flex flex-none gap-1">
                    <button
                      type="button"
                      onClick={() => move(index, -1)}
                      disabled={disabled || index === 0}
                      aria-label={`Move ${entry.file.name} up`}
                      className={`${btnCompact} disabled:cursor-not-allowed disabled:opacity-30`}
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      onClick={() => move(index, 1)}
                      disabled={disabled || index === files.length - 1}
                      aria-label={`Move ${entry.file.name} down`}
                      className={`${btnCompact} disabled:cursor-not-allowed disabled:opacity-30`}
                    >
                      ↓
                    </button>
                  </span>
                )}

                <button
                  type="button"
                  onClick={() => remove(entry.id)}
                  disabled={disabled}
                  aria-label={`Remove ${entry.file.name}`}
                  className="flex-none cursor-pointer rounded px-1.5 text-foreground-subtle transition-colors hover:text-danger focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:min-h-[44px] pointer-coarse:min-w-[44px]"
                >
                  <Icon name="close" size="sm" />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
