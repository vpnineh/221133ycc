"use client";

import React from "react";
import { Notice } from "../common/Notice";
import { btnPrimary, btnSecondary } from "../common/controls";
import { downloadBlob, formatBytes } from "../../lib/files";
import type { PdfRunState } from "./usePdfWorker";

/**
 * The progress-and-result strip every file tool shares.
 *
 * Determinate progress rather than a spinner, because these operations take
 * seconds and a spinner tells you only that something has not crashed. The bar
 * reports which file is being processed, which is the difference between
 * "waiting" and "waiting, on file 7 of 12".
 */

interface FileResultProps {
  state: PdfRunState;
  /** Rendered when nothing has run yet. */
  idle?: React.ReactNode;
  /** Filename used when several results are downloaded together. */
  onDownloadAll?: () => void;
}

export const FileResult: React.FC<FileResultProps> = ({ state, idle, onDownloadAll }) => {
  if (state.status === "idle") return <>{idle ?? null}</>;

  if (state.status === "running") {
    const percent = state.total > 0 ? Math.round((state.done / state.total) * 100) : 0;
    return (
      <div className="rounded-lg border border-border bg-surface p-4">
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <span className="text-xs text-foreground">
            Processing {state.label}
            {state.total > 1 ? ` — ${state.done + 1} of ${state.total}` : ""}
          </span>
          <span className="font-mono text-2xs text-foreground-subtle">{percent}%</span>
        </div>
        <div
          role="progressbar"
          aria-valuenow={percent}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Processing progress"
          className="h-1.5 overflow-hidden rounded-full bg-surface-elevated"
        >
          {/* Width only: no transition, because the design system ships no
              keyframes and a bar that animates its own width is a keyframe in
              all but name. */}
          <div className="h-full bg-accent-solid" style={{ width: `${Math.max(percent, 2)}%` }} />
        </div>
      </div>
    );
  }

  if (state.status === "error") {
    return <Notice tone="danger">{state.message}</Notice>;
  }

  const totalBytes = state.files.reduce((sum, file) => sum + file.bytes, 0);

  return (
    <div className="overflow-hidden rounded-lg border border-add/40 bg-surface">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-3 py-2">
        <span className="font-mono text-2xs uppercase tracking-wide text-add">
          Done in {(state.elapsedMs / 1000).toFixed(1)}s · {state.files.length} file
          {state.files.length === 1 ? "" : "s"} · {formatBytes(totalBytes)}
        </span>
        {state.files.length > 1 && onDownloadAll && (
          <button type="button" onClick={onDownloadAll} className={btnSecondary}>
            Download all
          </button>
        )}
      </div>

      <ul>
        {state.files.map((file) => (
          <li
            key={file.name}
            className="flex flex-wrap items-center gap-3 border-b border-border px-3 py-2 last:border-0"
          >
            <span className="min-w-0 flex-1 truncate text-xs text-foreground">{file.name}</span>
            <span className="flex-none font-mono text-2xs text-foreground-subtle">
              {formatBytes(file.bytes)}
            </span>
            <button
              type="button"
              onClick={() => downloadBlob(file.blob, file.name)}
              className={btnPrimary}
            >
              Download
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};
