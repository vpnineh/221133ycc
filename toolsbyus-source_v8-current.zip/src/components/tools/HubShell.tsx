import React from "react";
import Link from "next/link";
import { Breadcrumb } from "../common/Breadcrumb";
import { SchemaJsonLd } from "../common/SchemaJsonLd";
import { FaqSection, FaqItem } from "../common/FaqSection";
import { Icon } from "../common/Icon";
import { PrivacyBadge } from "../common/PrivacyBadge";
import { CategoryScene } from "../common/CategoryScene";
import { AdSlot } from "../common/AdSlot";
import {
  ACTIVE_CATEGORIES,
  groupedToolsInCategory,
  toolsInCategory,
  type Category,
} from "../../lib/tools";
import { absoluteUrl, SITE_NAME } from "../../lib/site";

interface HubShellProps {
  category: Category;
  /** 40–60 words. The direct answer an AI engine can lift whole. */
  directAnswer: string;
  /** 300–500 words of copy unique to this category. */
  intro: React.ReactNode;
  faqs: FaqItem[];
  lastReviewed: string;
}

/**
 * The frame for a category hub.
 *
 * Hubs are not filler. On a site of this shape they are the pages with the best
 * chance of ranking for the head term ("json tools", "pdf tools"), and they are
 * the internal-linking spine: every tool links up to its hub, every hub links
 * down to its tools and sideways to its siblings. That structure is what lets a
 * new domain get a large catalogue crawled at all.
 *
 * Which is also why the intro copy is passed in rather than templated. Six hubs
 * generated from one paragraph with the category name swapped is precisely the
 * pattern that produces "Crawled — currently not indexed".
 */
export const HubShell: React.FC<HubShellProps> = ({
  category,
  directAnswer,
  intro,
  faqs,
  lastReviewed,
}) => {
  const tools = toolsInCategory(category.id);
  const grouped = groupedToolsInCategory(category.id);
  const siblings = ACTIVE_CATEGORIES.filter((c) => c.id !== category.id);

  const jsonLd = [
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: category.title,
      url: absoluteUrl(category.hub),
      description: directAnswer,
      inLanguage: "en",
      isPartOf: { "@type": "WebSite", name: SITE_NAME, url: absoluteUrl("/") },
      dateModified: lastReviewed,
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: absoluteUrl("/") },
        { "@type": "ListItem", position: 2, name: category.title, item: absoluteUrl(category.hub) },
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: category.title,
      numberOfItems: tools.length,
      itemListElement: tools.map((tool, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: tool.title,
        url: absoluteUrl(tool.href),
        description: tool.description,
      })),
    },
    ...(faqs.length
      ? [
          {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqs.map((faq) => ({
              "@type": "Question",
              name: faq.question,
              acceptedAnswer: { "@type": "Answer", text: faq.answer },
            })),
          },
        ]
      : []),
  ];

  return (
    <div className="shell py-6">
      <SchemaJsonLd schemas={jsonLd} />

      <Breadcrumb items={[{ label: category.title, href: category.hub }]} />

      {/* The same hero shape as a tool page and as the homepage, so the three
          levels of the site read as one place. A hub used to open with a
          monospace H1 and a bordered count chip, which was the last of the old
          vocabulary still visible above the fold. */}
      <header className="mt-4">
        <div className="grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.7fr)] lg:gap-12">
          <div className="min-w-0 text-center lg:text-left">
            <h1 className="text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[3rem]">
              {category.title}
            </h1>

            <p className="mx-auto mt-6 max-w-[68ch] border-l-2 border-accent-line pl-5 text-left text-base leading-relaxed text-foreground-muted sm:text-lg lg:mx-0">
              {directAnswer}
            </p>

            <div className="mt-7 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
              <span className="rounded-pill bg-surface-elevated px-3 py-1 text-2xs text-foreground-subtle">
                {tools.length} {tools.length === 1 ? "tool" : "tools"}
              </span>
              <PrivacyBadge />
            </div>
          </div>

          <CategoryScene
            category={category.id}
            className="hidden w-full min-w-0 max-w-[26rem] justify-self-end text-foreground lg:block"
          />
        </div>
      </header>

      {/* The list is the point of the page, so it comes first. */}
      <section aria-label={`${category.title} list`} className="mt-8 space-y-8">
        {grouped.map(({ group, tools: groupTools }) => (
          <div key={group}>
            {grouped.length > 1 && (
              <h2 className="mb-3 text-2xs text-foreground-subtle">
                {group}
              </h2>
            )}
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {groupTools.map((tool) => (
                <li key={tool.href}>
                  <Link
                    href={tool.href}
                    className="group flex h-full flex-col rounded-lg border border-border bg-surface p-4 transition-colors hover:border-accent-line hover:bg-surface-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="flex h-8 w-8 flex-none items-center justify-center rounded border border-border bg-surface-elevated text-foreground-muted transition-colors group-hover:border-accent-line group-hover:text-accent">
                        <Icon name={tool.icon} size="md" />
                      </span>
                      <h3 className="min-w-0 flex-1 truncate text-[0.9375rem] font-semibold tracking-tight text-foreground">
                        {tool.name}
                      </h3>
                      {/* `min-w-0 truncate` rather than a fixed intrinsic width:
                          a long tag beside a long name pushed the card past a
                          320px viewport, which moved the whole page. */}
                      <span className="min-w-0 max-w-[45%] truncate rounded-pill bg-surface-elevated px-2 py-0.5 text-2xs text-foreground-subtle">
                        {tool.tag}
                      </span>
                    </div>
                    <p className="mt-3 flex-1 text-xs leading-relaxed text-foreground-muted">
                      {tool.description}
                    </p>
                    <span className="mt-4 flex items-center justify-between border-t border-border pt-2.5 text-2xs text-foreground-subtle transition-colors group-hover:text-accent">
                      {tool.action}
                      <Icon name="arrowRight" size="sm" />
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>

      <AdSlot id={`ad-slot-hub-${category.id}`} placement="top" />

      <div className="mt-12 max-w-3xl space-y-12">
        <section aria-labelledby="hub-intro-heading">
          <h2
            id="hub-intro-heading"
            className="heading-hash"
          >
            When should you use a browser-based {category.label.toLowerCase()} tool?
          </h2>
          <div className="prose-tool mt-4">{intro}</div>
        </section>

        <FaqSection items={faqs} />

        <section aria-labelledby="hub-siblings-heading">
          <h2
            id="hub-siblings-heading"
            className="heading-hash"
          >
            What else is on ToolsByUs?
          </h2>
          <ul className="mt-4 grid gap-2 sm:grid-cols-2">
            {siblings.map((sibling) => (
              <li key={sibling.id}>
                <Link
                  href={sibling.hub}
                  className="group flex h-full items-start gap-2.5 rounded-lg border border-border bg-surface p-3 transition-colors hover:border-accent-line hover:bg-surface-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <Icon
                    name="arrowRight"
                    size="md"
                    className="mt-0.5 text-foreground-subtle transition-colors group-hover:text-accent"
                  />
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold tracking-tight text-foreground">
                      {sibling.title}
                    </span>
                    <span className="mt-1 block text-2xs leading-relaxed text-foreground-muted">
                      {sibling.blurb}
                    </span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-5 text-2xs text-foreground-subtle">
          <span>ToolsByUs — {category.title}</span>
          <span>
            Last updated{" "}
            <time dateTime={lastReviewed} className="font-mono text-foreground-muted">
              {lastReviewed}
            </time>
          </span>
        </div>
      </div>
    </div>
  );
};
