"use client";

import React from "react";
import { Notice } from "../common/Notice";
import { btnSecondary } from "../common/controls";
import { downloadBlob, formatBytes } from "../../lib/files";
import type { ImageBatchState } from "./useImageBatch";

/**
 * Progress, then previews, for every image tool.
 *
 * The preview grid is not decoration. An image tool whose output you cannot see
 * before downloading makes you download to check, and at quality 0.6 that is
 * the difference between noticing the artefacts now and noticing them in the
 * document you already sent. Each thumbnail is the real encoded result — the
 * blob the download button hands you, not the source re-rendered at a smaller
 * size — so what you are looking at is what you will get.
 *
 * The size line is a before-and-after with a percentage, because "412 KB" alone
 * answers nothing. The percentage is the whole reason someone opened a
 * compressor, and when it goes the wrong way — a PNG screenshot re-encoded as
 * PNG frequently gets larger — saying so is more useful than hiding it.
 */

interface ImageResultsProps {
  state: ImageBatchState;
  /** A checkerboard behind the thumbnail, for formats that keep transparency. */
  transparent?: boolean;
}

export const ImageResults: React.FC<ImageResultsProps> = ({ state, transparent = false }) => {
  if (state.status === "idle") return null;

  if (state.status === "running") {
    const percent = state.total > 0 ? Math.round((state.done / state.total) * 100) : 0;
    return (
      <div className="rounded-lg border border-border bg-surface p-4">
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <span className="min-w-0 truncate text-xs text-foreground">
            Processing {state.label}
            {state.total > 1 ? ` — ${state.done + 1} of ${state.total}` : ""}
          </span>
          <span className="flex-none font-mono text-2xs text-foreground-subtle">{percent}%</span>
        </div>
        <div
          role="progressbar"
          aria-valuenow={percent}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label="Processing progress"
          className="h-1.5 overflow-hidden rounded-full bg-surface-elevated"
        >
          <div className="h-full bg-accent-solid" style={{ width: `${Math.max(percent, 2)}%` }} />
        </div>
      </div>
    );
  }

  if (state.status === "error") return <Notice tone="danger">{state.message}</Notice>;

  const before = state.results.reduce((sum, result) => sum + result.originalBytes, 0);
  const after = state.results.reduce((sum, result) => sum + result.blob.size, 0);
  const change = before > 0 ? Math.round(((before - after) / before) * 100) : 0;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-add/40 bg-surface px-3 py-2">
        <span className="font-mono text-2xs uppercase tracking-wide text-add">
          {state.results.length} image{state.results.length === 1 ? "" : "s"} in{" "}
          {(state.elapsedMs / 1000).toFixed(1)}s
        </span>
        <span className="font-mono text-2xs text-foreground-subtle">
          {formatBytes(before)} → {formatBytes(after)}{" "}
          <span className={change > 0 ? "text-add" : change < 0 ? "text-danger" : ""}>
            ({change > 0 ? "−" : change < 0 ? "+" : ""}
            {Math.abs(change)}%)
          </span>
        </span>
        {state.results.length > 1 && (
          <button
            type="button"
            onClick={() => {
              for (const result of state.results) downloadBlob(result.blob, result.name);
            }}
            className={`${btnSecondary} ml-auto`}
          >
            Download all
          </button>
        )}
      </div>

      {state.failures.map((failure) => (
        <Notice key={failure} tone="warn">
          {failure}
        </Notice>
      ))}

      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {state.results.map((result) => {
          const delta =
            result.originalBytes > 0
              ? Math.round(((result.originalBytes - result.blob.size) / result.originalBytes) * 100)
              : 0;
          return (
            <li
              key={result.id}
              className="overflow-hidden rounded-lg border border-border bg-surface"
            >
              {/* A blob URL for a file this page just encoded: next/image cannot
                  take one, and there is nothing left to optimise. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={result.url}
                alt={result.name}
                width={result.width}
                height={result.height}
                className={`h-36 w-full object-contain ${
                  transparent ? "bg-checkerboard" : "bg-surface-elevated"
                }`}
              />
              <div className="space-y-1 border-t border-border px-2 py-1.5">
                <p className="truncate font-mono text-2xs text-foreground" title={result.name}>
                  {result.name}
                </p>
                <p className="font-mono text-2xs text-foreground-subtle">
                  {result.width} × {result.height} · {formatBytes(result.blob.size)}{" "}
                  <span className={delta > 0 ? "text-add" : delta < 0 ? "text-danger" : ""}>
                    ({delta > 0 ? "−" : delta < 0 ? "+" : ""}
                    {Math.abs(delta)}%)
                  </span>
                </p>
                <button
                  type="button"
                  onClick={() => downloadBlob(result.blob, result.name)}
                  className="cursor-pointer rounded font-mono text-2xs text-accent transition-colors hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  save
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};
