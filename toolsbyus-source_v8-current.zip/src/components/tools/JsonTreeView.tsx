"use client";

import React, { useCallback, useMemo, useRef, useState } from "react";
import { Icon } from "../common/Icon";
import { btnCompact, field, fieldLabel } from "../common/controls";
import {
  containerIds,
  flattenTree,
  searchRows,
  summarise,
  visibleRows,
  type TreeRow,
} from "../../lib/json/tree";
import type { JsonValue } from "../../lib/json/types";

/**
 * A read-only JSON tree that stays usable on documents nobody else will open.
 *
 * Virtualized over a flattened row list rather than rendered as nested
 * components: only the rows in the viewport exist in the DOM, so a 50,000-node
 * response scrolls at the same speed as a 50-node one. Collapsing is a skip
 * over a row range, not an unmount of a subtree, which is why collapsing the
 * root of a large document is instant.
 */

const ROW_HEIGHT = 22;
const OVERSCAN = 12;

const TYPE_COLOR: Record<TreeRow["type"], string> = {
  object: "text-foreground-muted",
  array: "text-foreground-muted",
  string: "text-add",
  number: "text-move",
  boolean: "text-type",
  null: "text-foreground-subtle",
};

interface JsonTreeViewProps {
  value: JsonValue;
  height?: number;
  /** Containers deeper than this start collapsed. */
  initialDepth?: number;
}

export const JsonTreeView: React.FC<JsonTreeViewProps> = ({
  value,
  height = 460,
  initialDepth = 2,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [query, setQuery] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  // Index into the visible rows. A tree is a composite widget: one tab stop,
  // arrow keys inside it. Declaring role="tree" without this would announce a
  // tree to a screen reader and then do nothing when its user pressed a key.
  const [activeIndex, setActiveIndex] = useState(0);

  const rows = useMemo(() => flattenTree(value), [value]);
  const stats = useMemo(() => summarise(rows), [rows]);

  // Everything below the initial depth starts collapsed, so a large document
  // opens as an overview rather than forty thousand lines.
  const [collapsed, setCollapsed] = useState<Set<string>>(() => {
    const all = new Set(containerIds(rows));
    for (const id of containerIds(rows, initialDepth)) all.delete(id);
    return all;
  });

  const matches = useMemo(() => searchRows(rows, query), [rows, query]);

  const shown = useMemo(() => {
    const base = visibleRows(rows, collapsed);
    if (!query.trim()) return base;
    // While searching, show only the matched rows and their ancestors; the
    // collapsed set is ignored so a hit deep in a closed subtree is reachable.
    return rows.filter((row) => matches.has(row.id));
  }, [rows, collapsed, query, matches]);

  const toggle = useCallback((id: string) => {
    setCollapsed((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const expandAll = () => setCollapsed(new Set());
  const collapseAll = () => setCollapsed(new Set(containerIds(rows)));

  const copyPointer = async (id: string) => {
    try {
      await navigator.clipboard.writeText(id);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1200);
    } catch {
      // Clipboard denied; the pointer is still visible in the title attribute.
    }
  };

  const onKeyDown = useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>) => {
      const row = shown[activeIndex];
      let next: number | null = null;

      switch (event.key) {
        case "ArrowDown":
          next = Math.min(shown.length - 1, activeIndex + 1);
          break;
        case "ArrowUp":
          next = Math.max(0, activeIndex - 1);
          break;
        case "Home":
          next = 0;
          break;
        case "End":
          next = shown.length - 1;
          break;
        case "ArrowRight":
          // Expand, or step into the first child if already open — the
          // behaviour the ARIA authoring practices specify for a tree.
          if (row?.isContainer && collapsed.has(row.id)) toggle(row.id);
          else next = Math.min(shown.length - 1, activeIndex + 1);
          break;
        case "ArrowLeft":
          if (row?.isContainer && !collapsed.has(row.id)) toggle(row.id);
          else {
            // Move to the parent: the nearest row above with a smaller depth.
            for (let i = activeIndex - 1; i >= 0; i--) {
              if (shown[i].depth < row.depth) {
                next = i;
                break;
              }
            }
          }
          break;
        case "Enter":
        case " ":
          if (row?.isContainer) toggle(row.id);
          else return;
          break;
        default:
          return;
      }

      event.preventDefault();
      if (next !== null) {
        setActiveIndex(next);
        // Keep the focused row in view without fighting the virtualization.
        const el = containerRef.current;
        if (el) {
          const top = next * ROW_HEIGHT;
          if (top < el.scrollTop) el.scrollTop = top;
          else if (top + ROW_HEIGHT > el.scrollTop + el.clientHeight) {
            el.scrollTop = top + ROW_HEIGHT - el.clientHeight;
          }
        }
      }
    },
    [shown, activeIndex, collapsed, toggle]
  );

  const total = shown.length;
  const first = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN);
  const last = Math.min(total, Math.ceil((scrollTop + height) / ROW_HEIGHT) + OVERSCAN);
  const window = shown.slice(first, last);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border bg-surface px-3 py-2.5">
        <div className="flex items-center gap-2">
          <label htmlFor="tree-search" className={fieldLabel}>
            Find
          </label>
          <input
            id="tree-search"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="key or value"
            className={`${field} w-44`}
          />
        </div>

        <button type="button" onClick={expandAll} className={btnCompact}>
          Expand all
        </button>
        <button type="button" onClick={collapseAll} className={btnCompact}>
          Collapse all
        </button>

        <span className="ml-auto font-mono text-2xs text-foreground-subtle">
          {query.trim()
            ? `${total} matching row${total === 1 ? "" : "s"}`
            : `${stats.nodes} nodes · depth ${stats.maxDepth} · ${stats.uniqueKeys} distinct keys`}
        </span>
      </div>

      <div
        ref={containerRef}
        onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
        onKeyDown={onKeyDown}
        className="overflow-auto rounded-lg border border-border bg-background font-mono text-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent"
        style={{ height }}
        tabIndex={0}
        role="tree"
        aria-label="JSON document tree. Use the arrow keys to move, left and right to collapse and expand."
        aria-activedescendant={shown[activeIndex] ? `tree-row-${shown[activeIndex].id}` : undefined}
      >
        {total === 0 ? (
          <p className="p-6 text-center text-xs text-foreground-muted">
            Nothing matches &ldquo;{query}&rdquo;.
          </p>
        ) : (
          <div style={{ height: total * ROW_HEIGHT, position: "relative" }}>
            {window.map((row, index) => {
              const top = (first + index) * ROW_HEIGHT;
              const isCollapsed = collapsed.has(row.id);

              return (
                <div
                  key={row.id}
                  id={`tree-row-${row.id}`}
                  role="treeitem"
                  aria-level={row.depth + 1}
                  aria-selected={first + index === activeIndex}
                  aria-setsize={total}
                  aria-posinset={first + index + 1}
                  aria-expanded={row.isContainer ? !isCollapsed : undefined}
                  onClick={() => setActiveIndex(first + index)}
                  className={`group absolute left-0 right-0 flex items-center gap-1.5 whitespace-nowrap pr-2 ${
                    first + index === activeIndex
                      ? "bg-accent-soft ring-1 ring-inset ring-accent"
                      : "hover:bg-surface-elevated"
                  }`}
                  style={{ top, height: ROW_HEIGHT, paddingLeft: row.depth * 14 + 8 }}
                >
                  {row.isContainer ? (
                    <button
                      type="button"
                      onClick={() => toggle(row.id)}
                      aria-label={`${isCollapsed ? "Expand" : "Collapse"} ${row.key}`}
                      className="flex h-4 w-4 flex-none cursor-pointer items-center justify-center rounded text-foreground-subtle transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    >
                      <Icon
                        name="chevronRight"
                        size="sm"
                        className={`transition-transform ${isCollapsed ? "" : "rotate-90"}`}
                      />
                    </button>
                  ) : (
                    <span className="h-4 w-4 flex-none" aria-hidden="true" />
                  )}

                  <span className="flex-none font-medium text-foreground">{row.key}</span>
                  <span className="flex-none text-foreground-subtle">:</span>

                  {row.isContainer ? (
                    <span className="flex-none text-foreground-subtle">
                      {row.type === "array" ? `[ ${row.size} ]` : `{ ${row.size} }`}
                      {isCollapsed && row.size! > 0 && <span className="ml-1.5 opacity-60">…</span>}
                    </span>
                  ) : (
                    <span className={`truncate ${TYPE_COLOR[row.type]}`}>{row.display}</span>
                  )}

                  <button
                    type="button"
                    onClick={() => copyPointer(row.id)}
                    title={`Copy JSON Pointer ${row.id}`}
                    className="ml-auto flex-none cursor-pointer rounded px-1.5 text-2xs text-foreground-subtle opacity-0 transition-opacity hover:text-accent focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent group-hover:opacity-100"
                  >
                    {copiedId === row.id ? "copied" : row.id}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
