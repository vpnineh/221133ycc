"use client";

import React, { useId, useState } from "react";
import { fieldLabel } from "../common/controls";
import {
  applyPattern,
  collidesInBatch,
  sanitiseFilename,
  TOKEN_HELP,
  withStem,
  type NameTokens,
} from "../../lib/files/naming";

/**
 * Lets the user name the output, on tools that produce a file.
 *
 * Two shapes, because a tool producing one file and a tool producing forty
 * need different controls. One file takes a name. Forty take a *rule* — a
 * single name would collide forty times, and typing forty names is not a
 * feature anyone wants.
 *
 * The preview under the field is the point. It shows the name after
 * sanitising, so a colon becoming a dash or a `{widht}` typo surviving as
 * literal text is visible before the download rather than afterwards in the
 * downloads folder. It also means the sanitising never has to be explained:
 * you can see what it did.
 *
 * Collapsed by default. Most people want the default name, and a filename
 * field sitting open above every tool is clutter charged to everyone to serve
 * the few who need it.
 */

interface SingleProps {
  mode?: "single";
  /** Stem the tool would use on its own, without the extension. */
  defaultStem: string;
  extension: string;
  value: string;
  onChange: (value: string) => void;
}

interface PatternProps {
  mode: "pattern";
  /** Pattern the tool would use on its own, e.g. `{name}-compressed`. */
  defaultStem: string;
  extension: string;
  value: string;
  onChange: (value: string) => void;
  /** Sample values, so the preview shows a real filename rather than tokens. */
  sample: NameTokens;
  /** Which tokens this tool actually provides. */
  tokens?: Array<keyof NameTokens>;
}

type OutputNameProps = SingleProps | PatternProps;

export const OutputName: React.FC<OutputNameProps> = (props) => {
  const { defaultStem, extension, value, onChange } = props;
  const isPattern = props.mode === "pattern";
  const inputId = useId();
  const [open, setOpen] = useState(false);

  const effective = value.trim() === "" ? defaultStem : value;
  const preview = isPattern
    ? applyPattern(effective, props.sample, extension)
    : withStem(effective, extension);

  const available = isPattern
    ? TOKEN_HELP.filter((entry) =>
        (props.tokens ?? ["name", "n", "date"]).some((token) => entry.token === `{${token}}`)
      )
    : [];

  const willCollide = isPattern && collidesInBatch(effective);
  // The sanitiser changed something the user typed, which is worth pointing at
  // rather than leaving them to spot in a preview they may not read.
  const changed = value.trim() !== "" && sanitiseFilename(effective) !== effective.trim();

  return (
    <div className="rounded-lg border border-border bg-surface">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        aria-expanded={open}
        aria-controls={`${inputId}-panel`}
        className="flex w-full cursor-pointer items-center justify-between gap-3 px-3 py-2 text-left transition-colors hover:bg-surface-elevated focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-accent"
      >
        <span className={fieldLabel}>{isPattern ? "Output names" : "Output name"}</span>
        <span className="flex min-w-0 items-center gap-2">
          <span className="min-w-0 truncate font-mono text-2xs text-foreground-muted">
            {preview}
          </span>
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
            className={`flex-none text-foreground-subtle transition-transform ${
              open ? "rotate-180" : ""
            }`}
          >
            <path d="m6 9 6 6 6-6" />
          </svg>
        </span>
      </button>

      <div id={`${inputId}-panel`} hidden={!open} className="space-y-2 border-t border-border p-3">
        <div className="flex items-center gap-1.5">
          <input
            id={inputId}
            type="text"
            value={value}
            onChange={(event) => onChange(event.target.value)}
            placeholder={defaultStem}
            spellCheck={false}
            autoComplete="off"
            aria-label={isPattern ? "Output filename pattern" : "Output filename"}
            className="min-w-0 flex-1 rounded border border-border bg-surface-elevated px-2.5 py-1.5 font-mono text-xs text-foreground transition-colors focus:border-accent focus:outline-none"
          />
          <span className="flex-none font-mono text-2xs text-foreground-subtle">.{extension}</span>
          {value.trim() !== "" && (
            <button
              type="button"
              onClick={() => onChange("")}
              className="flex-none cursor-pointer rounded px-1.5 py-1 font-mono text-2xs text-foreground-subtle transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              reset
            </button>
          )}
        </div>

        {isPattern && available.length > 0 && (
          <p className="font-mono text-2xs leading-relaxed text-foreground-subtle">
            {available.map((entry, index) => (
              <React.Fragment key={entry.token}>
                {index > 0 && " · "}
                <button
                  type="button"
                  onClick={() => onChange(`${effective}${entry.token}`)}
                  title={entry.meaning}
                  className="cursor-pointer rounded text-accent transition-colors hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  {entry.token}
                </button>
              </React.Fragment>
            ))}
          </p>
        )}

        {willCollide && (
          <p className="text-2xs leading-relaxed text-warn">
            Every file would get the same name, and your browser will append
            &ldquo;(1)&rdquo;, &ldquo;(2)&rdquo; and so on in whatever order the downloads finish —
            which is not the order they are listed in. Add <code>{"{name}"}</code> or{" "}
            <code>{"{n}"}</code> to keep them distinguishable.
          </p>
        )}

        {changed && (
          <p className="text-2xs leading-relaxed text-foreground-muted">
            Saved as <span className="font-mono text-foreground">{preview}</span> — path separators,
            control characters and the names Windows reserves are removed, because a download that
            silently fails is worse than one that is renamed.
          </p>
        )}
      </div>
    </div>
  );
};
