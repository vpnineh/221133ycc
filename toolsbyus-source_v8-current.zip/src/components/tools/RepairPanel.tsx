"use client";

import React, { useMemo, useState } from "react";
import { repairJson } from "../../lib/json/repair";

interface RepairPanelProps {
  /** The document currently in the editor. */
  value: string;
  /** Called when the user accepts the repair. */
  onApply: (repaired: string) => void;
}

/**
 * Offers a one-click repair for a malformed document, and shows exactly what
 * would change before anything is applied.
 *
 * The validator already identifies the precise fault; this closes the loop. It
 * is deliberately a two-step flow — preview, then apply — because silently
 * rewriting someone's payload is the kind of "help" that destroys trust in a
 * debugging tool. Nothing is changed until the button is pressed, and the exact
 * change list is on screen when it is.
 */
export const RepairPanel: React.FC<RepairPanelProps> = ({ value, onApply }) => {
  const [showPreview, setShowPreview] = useState(false);

  // Cheap enough to run eagerly: the editor is already parsing on every change,
  // and repair is a single tokenizer pass over the same text.
  const repair = useMemo(() => repairJson(value), [value]);

  // Nothing to offer for an empty pane or a document that is already valid.
  if (!value.trim() || repair.changes.length === 0) return null;

  const totalFixes = repair.changes.reduce((sum, c) => sum + c.count, 0);

  return (
    <div
      className={`rounded-lg border font-mono text-xs overflow-hidden ${
        repair.success
          ? "border-accent-line bg-accent-soft"
          : "border-warn bg-warn-soft"
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
        <div className="flex items-start gap-2.5 min-w-0">
          <svg
            className={`w-4 h-4 mt-0.5 flex-none ${
              repair.success ? "text-accent" : "text-warn"
            }`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth="2"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 1 1-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 0 0 4.486-6.336l-3.276 3.277a3.004 3.004 0 0 1-2.25-2.25l3.276-3.276a4.5 4.5 0 0 0-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085m-1.745 1.437L5.909 7.5H4.5L2.25 3.75l1.5-1.5L7.5 4.5v1.409l4.26 4.26m-1.745 1.437 1.745-1.437m6.615 8.206L15.75 15.75M4.867 19.125h.008v.008h-.008v-.008Z"
            />
          </svg>
          <div className="min-w-0">
            <p
              className={`font-bold ${
                repair.success ? "text-accent" : "text-warn"
              }`}
            >
              {repair.success
                ? `${totalFixes} issue${totalFixes === 1 ? "" : "s"} can be fixed automatically`
                : "Partial repair only"}
            </p>
            <p className="text-foreground-muted mt-0.5 leading-relaxed">
              {repair.success
                ? "The repaired document was re-parsed and is valid RFC 8259 JSON."
                : `Some faults were corrected, but the document still does not parse: ${repair.remainingError}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowPreview((open) => !open)}
            aria-expanded={showPreview}
            className="px-3 py-2 pointer-coarse:min-h-[44px] rounded-lg border border-border bg-surface-elevated text-foreground-muted hover:text-foreground transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          >
            {showPreview ? "Hide changes" : "Preview changes"}
          </button>
          {repair.success && (
            <button
              type="button"
              onClick={() => onApply(repair.repaired)}
              className="px-3 py-2 pointer-coarse:min-h-[44px] rounded-lg bg-accent-solid hover:bg-accent-hover text-accent-on font-bold transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              Fix it
            </button>
          )}
        </div>
      </div>

      {showPreview && (
        <div className="border-t border-border px-4 py-3 space-y-3">
          <ul className="space-y-1.5">
            {repair.changes.map((change) => (
              <li key={change.action} className="flex items-start gap-2 text-foreground-muted">
                <span className="text-accent flex-none" aria-hidden="true">
                  +
                </span>
                <span>
                  <span className="text-foreground font-semibold">
                    {change.count}&times;
                  </span>{" "}
                  {change.description}
                </span>
              </li>
            ))}
          </ul>

          <div>
            <p className="text-foreground-muted mb-1.5 uppercase tracking-wider text-2xs">
              Result preview
            </p>
            <pre className="max-h-56 overflow-auto rounded-lg border border-border bg-background p-3 text-2xs leading-relaxed whitespace-pre">
              {repair.repaired.length > 4000
                ? repair.repaired.slice(0, 4000) + "\n… truncated for preview"
                : repair.repaired}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default RepairPanel;
