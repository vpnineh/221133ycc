"use client";

import React, { useCallback, useEffect, useState } from "react";
import { FileDropZone } from "./FileDropZone";
import { FileResult } from "./FileResult";
import { usePdfWorker } from "./usePdfWorker";
import { Notice } from "../common/Notice";
import { btnPrimary } from "../common/controls";
import { OutputName } from "./OutputName";
import { formatBytes, downloadBlob, type AcceptedFile } from "../../lib/files";
import { stemOf, type NameTokens } from "../../lib/files/naming";
import type { PdfInfo, PdfOperation } from "../../workers/pdf.worker";

/**
 * The shape shared by every tool that edits one PDF in place.
 *
 * Drop a file, the document is inspected so the controls know how many pages
 * there are, choose what to do, run it. Rotate, delete, reorder, split and
 * watermark differ only in the controls between those steps, and four copies of
 * this scaffolding would mean four places to fix the next bug in file handling.
 *
 * Inspection is its own worker round trip rather than part of the operation,
 * because the controls cannot be rendered until the page count is known and the
 * user should not have to guess at it.
 */

interface SinglePdfToolProps {
  /** Rendered once a document is loaded; receives its page count. */
  controls: (info: PdfInfo) => React.ReactNode;
  /**
   * Builds the operation to run, or returns a reason it cannot run yet.
   *
   * `stem` is the filename the user chose, already sanitised and without an
   * extension. Tools that emit one file use it directly; a tool that emits
   * several treats it as a pattern.
   */
  operation: (
    info: PdfInfo,
    file: File,
    stem: string
  ) => Promise<PdfOperation | { blocked: string }>;
  /** Label for the run button. */
  runLabel: (info: PdfInfo) => string;
  /** Extra guidance above the drop zone. */
  hint?: React.ReactNode;
  /**
   * How the output is named. Omit and the tool keeps its own naming.
   *
   * `defaultStem` receives the input's stem so a tool can suggest something
   * derived from it — `invoice` becoming `invoice-rotated` — which is what the
   * field is pre-filled with and what is used if the user leaves it alone.
   */
  naming?: {
    mode: "single" | "pattern";
    defaultStem: (inputStem: string, info: PdfInfo) => string;
    sample?: (inputStem: string, info: PdfInfo) => NameTokens;
    tokens?: Array<keyof NameTokens>;
  };
}

export const SinglePdfTool: React.FC<SinglePdfToolProps> = ({
  controls,
  operation,
  runLabel,
  hint,
  naming,
}) => {
  const [files, setFiles] = useState<AcceptedFile[]>([]);
  const { state, info, run, reset } = usePdfWorker();
  const [blocked, setBlocked] = useState<string | null>(null);
  const [chosenName, setChosenName] = useState("");

  const file = files[0]?.file;
  const inputStem = file ? stemOf(file.name) : "document";
  const defaultStem = naming && info ? naming.defaultStem(inputStem, info) : inputStem;

  // Inspect as soon as a file arrives: the controls need the page count, and a
  // document that cannot be opened should say so now rather than after the user
  // has configured an operation.
  useEffect(() => {
    if (!file) return;
    let cancelled = false;
    void file.arrayBuffer().then((buffer) => {
      if (!cancelled) run({ type: "inspect", file: buffer }, [buffer]);
    });
    return () => {
      cancelled = true;
    };
    // `run` is stable; re-running on every render would loop.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [file]);

  const execute = useCallback(async () => {
    if (!info || !file) return;
    setBlocked(null);
    const built = await operation(info, file, chosenName.trim() || defaultStem);
    if ("blocked" in built) {
      setBlocked(built.blocked);
      return;
    }
    // The document buffer is the only transferable in every operation shape.
    const transfer: Transferable[] = [];
    for (const value of Object.values(built)) {
      if (value instanceof ArrayBuffer) transfer.push(value);
    }
    run(built, transfer);
  }, [info, file, operation, run, chosenName, defaultStem]);

  const downloadAll = () => {
    if (state.status !== "done") return;
    for (const result of state.files) downloadBlob(result.blob, result.name);
  };

  return (
    <div className="space-y-4">
      {hint}

      <FileDropZone
        accept={[".pdf", "application/pdf"]}
        files={files}
        onChange={(next) => {
          setFiles(next);
          setBlocked(null);
          setChosenName("");
          reset();
        }}
        label="Drop a PDF here"
        disabled={state.status === "running"}
      />

      {info && file && (
        <>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border border-border bg-surface px-3 py-2 font-mono text-2xs text-foreground-subtle">
            <span>
              {info.pageCount} page{info.pageCount === 1 ? "" : "s"}
            </span>
            <span>{formatBytes(file.size)}</span>
            {info.pages[0] && (
              <span>
                {info.pages[0].width} × {info.pages[0].height} pt
              </span>
            )}
            {info.title && <span className="truncate">title: {info.title}</span>}
          </div>

          {controls(info)}

          {naming &&
            (naming.mode === "pattern" ? (
              <OutputName
                mode="pattern"
                sample={naming.sample?.(inputStem, info) ?? { name: inputStem, n: 1 }}
                tokens={naming.tokens}
                defaultStem={defaultStem}
                extension="pdf"
                value={chosenName}
                onChange={setChosenName}
              />
            ) : (
              <OutputName
                defaultStem={defaultStem}
                extension="pdf"
                value={chosenName}
                onChange={setChosenName}
              />
            ))}

          {blocked && <Notice tone="warn">{blocked}</Notice>}

          {state.status !== "running" && (
            <button type="button" onClick={() => void execute()} className={btnPrimary}>
              {runLabel(info)}
            </button>
          )}
        </>
      )}

      <FileResult state={state} onDownloadAll={downloadAll} />
    </div>
  );
};
