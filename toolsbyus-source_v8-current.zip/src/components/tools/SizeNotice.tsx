import React from "react";
import type { SizeCheck } from "../../lib/limits";

/**
 * Surfaces the outcome of a main-thread size check.
 *
 * Renders nothing for ordinary inputs, a caution for large ones, and an error
 * when processing was refused — so an oversized paste produces an explanation
 * instead of a frozen tab.
 */
export const SizeNotice: React.FC<{ check: SizeCheck }> = ({ check }) => {
  if (!check.message) return null;

  const isError = check.exceeded;

  return (
    <div
      role={isError ? "alert" : "status"}
      className={`flex items-start gap-2.5 rounded-lg border px-3.5 py-2.5 text-xs leading-relaxed ${
        isError
          ? "border-danger bg-danger-soft text-danger"
          : "border-warn bg-warn-soft text-warn"
      }`}
    >
      <svg
        className="mt-0.5 h-4 w-4 flex-shrink-0"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth="2"
        aria-hidden="true"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"
        />
      </svg>
      <span>{check.message}</span>
    </div>
  );
};

export default SizeNotice;
