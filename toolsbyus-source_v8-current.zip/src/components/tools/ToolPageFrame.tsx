import React from "react";
import { Breadcrumb, BreadcrumbItem } from "../common/Breadcrumb";
import { PrivacyBadge } from "../common/PrivacyBadge";
import { ToolScene } from "../common/ToolScene";
import type { ToolCategory } from "../../lib/tools";

interface ToolPageFrameProps {
  /** The exact term the page targets. It is the H1. */
  keyword: string;
  breadcrumbs: BreadcrumbItem[];
  /** 40–60 words an answer engine can quote whole. */
  directAnswer: React.ReactNode;
  /** Picks the drawing in the head. */
  category: ToolCategory;
  /** The working surface, lifted onto the band. */
  tool: React.ReactNode;
  /** Everything below it: prose, tables, FAQs, related links. */
  children: React.ReactNode;
  /** For a surface that genuinely needs more than 1024px. */
  wide?: boolean;
}

/**
 * The page frame for the three tools that predate `ToolShell`.
 *
 * JSON Formatter, Base64 Decode and UUID Generator were built before the shell
 * existed and each assembles its own structured data from hand-written content
 * that does not fit the shell's props — a reference table of RFC 8259
 * whitespace rules is not four columns of parameter/type/default. Rewriting
 * them into the shell would mean rewriting that content, and the content is
 * good; these are three of the highest-intent keywords on the site.
 *
 * What was not defensible was the *frame*. They kept a monospace H1, a
 * monospace subtitle and a left-aligned stack while every other tool on the
 * site moved to a centred head over a lifted panel, so arriving at "json
 * formatter" from a search and then clicking through to "json diff" felt like
 * crossing between two websites.
 *
 * So this is the shell's frame without the shell's content model: same head,
 * same band, same panel, same measure below. The prose those pages already
 * carry goes in as children and keeps its own headings.
 */
export const ToolPageFrame: React.FC<ToolPageFrameProps> = ({
  keyword,
  category,
  breadcrumbs,
  directAnswer,
  tool,
  children,
  wide = false,
}) => (
  <>
    <header className="bg-background">
      <div className="shell pb-8 pt-6 sm:pb-10">
        <div className="grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.6fr)] lg:gap-12">
          <div className="min-w-0 text-center lg:text-left">
            <Breadcrumb items={breadcrumbs} className="justify-center lg:justify-start" />

            <h1 className="mx-auto mt-5 max-w-[16ch] text-balance text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[3.25rem] lg:mx-0">
              {keyword}
            </h1>

            {/* `verify-seo` counts the left rule when it audits the built HTML,
                so it stays. */}
            <p className="mx-auto mt-6 max-w-[58ch] border-l-2 border-accent-line pl-5 text-left text-base leading-relaxed text-foreground-muted sm:text-lg lg:mx-0">
              {directAnswer}
            </p>

            <div className="mt-7 flex justify-center lg:justify-start">
              <PrivacyBadge />
            </div>
          </div>

          <ToolScene
            category={category}
            slug={breadcrumbs.at(-1)?.href?.replace(/^\//, "") ?? ""}
            className="hidden w-full min-w-0 max-w-[26rem] justify-self-end text-foreground lg:block"
          />
        </div>
      </div>
    </header>

    <div className="bg-background-subtle pb-20 pt-6 sm:pt-8">
      <section aria-label={`${keyword} tool`} className="shell">
        <div
          className={`mx-auto rounded-xl bg-surface p-4 sm:p-6 lg:p-8 ${
            wide ? "" : "max-w-[64rem]"
          }`}
        >
          {tool}
        </div>
      </section>

      <div className="shell mt-16 max-w-[52rem] space-y-14">{children}</div>
    </div>
  </>
);

export default ToolPageFrame;
