import React from "react";
import Link from "next/link";
import { Breadcrumb, BreadcrumbItem } from "../common/Breadcrumb";
import { FaqSection, FaqItem } from "../common/FaqSection";
import { SchemaJsonLd } from "../common/SchemaJsonLd";
import { AdSlot } from "../common/AdSlot";
import { PrivacyBadge } from "../common/PrivacyBadge";
import { ToolScene } from "../common/ToolScene";
import { Icon } from "../common/Icon";
import { TOOLS } from "../../lib/tools";
import { CONTENT_LAST_REVIEWED } from "../../lib/site";

export interface RelatedToolLink {
  href: string;
  title: string;
  description: string;
}

export interface ReferenceRow {
  parameter: string;
  type: string;
  defaultVal: string;
  description: string;
}

interface ToolShellProps {
  slug: string;
  keyword: string;
  directAnswer: string;
  breadcrumbs: BreadcrumbItem[];
  children: React.ReactNode; // The tool itself (above the fold)
  howItWorks: {
    algorithmExplanation: string | React.ReactNode;
    exampleInput: string;
    exampleOutput: string;
    inputTitle?: string;
    outputTitle?: string;
  };
  referenceTable: {
    title?: string;
    rows: ReferenceRow[];
  };
  faqs: FaqItem[];
  relatedTools: RelatedToolLink[];
  lastUpdatedDate?: string;
  seoDescription: string;
  /**
   * Let the tool surface run the full width of the shell.
   *
   * For the handful of tools whose interface is two documents side by side —
   * the diffs, the code generators — 1024px means two 480px columns of
   * monospace, which is about 55 characters each and not enough to read a
   * payload in. Everything else is better contained.
   */
  wide?: boolean;
}

/**
 * The page frame every tool shares.
 *
 * Three rules do the work.
 *
 * *Tone, not lines.* The page has two grounds: the head sits on the page
 * colour, everything from the tool down sits on the band. The tool itself is a
 * panel lifted onto that boundary, which is what makes it read as the subject
 * of the page rather than as the first of several sections. No borders are
 * involved; the separation is entirely a step in lightness.
 *
 * *Mono means a machine wrote it.* Keys, values, byte counts and payloads are
 * monospace because they are literally code. Headings and prose are not — the
 * previous build set explanatory paragraphs in monospace too, which is slower
 * to read at body size and flattened the distinction between what the page says
 * and what the payload says.
 *
 * *Measure.* Long-form text sits in a 68-character column even though the tool
 * above it spans the full shell, because a paragraph that runs the width of a
 * desktop monitor is unreadable regardless of font.
 */
export const ToolShell: React.FC<ToolShellProps> = ({
  slug,
  keyword,
  directAnswer,
  breadcrumbs,
  children,
  howItWorks,
  referenceTable,
  faqs,
  relatedTools,
  lastUpdatedDate,
  seoDescription,
  wide = false,
}) => {
  const tool = TOOLS.find((t) => t.href === `/${slug}`);

  /*
   * The review date comes from the catalogue unless a page overrides it.
   *
   * It used to default to a hard-coded constant, and ten pages never passed the
   * prop — so the flagship JSON Diff page told a reader "last updated
   * 2026-09-11" in its own catalogue entry and told a machine `dateModified:
   * 2026-09-09` in its JSON-LD. A freshness claim that contradicts itself in
   * structured data is worse than no claim at all, and it is precisely what an
   * AI engine compares when deciding whether a source is maintained.
   *
   * `reviewedDate` in `tests/unit/tool-catalogue.test.ts` now asserts that every
   * published tool has a `lastReviewed` to fall back to.
   */
  const reviewedDate = lastUpdatedDate ?? tool?.lastReviewed ?? CONTENT_LAST_REVIEWED;

  /*
   * `featureList` for the WebApplication node, derived from the reference table.
   *
   * The prop existed on SchemaJsonLd and no page ever passed it, which is the
   * usual fate of a field that has to be written twice. Deriving it from the
   * options table means it is accurate by construction and cannot go stale: the
   * table already names every capability the tool has, in the author's own
   * words, and it is the part of the page a reader scans to decide whether the
   * tool does what they need. Those are exactly the strings worth handing to a
   * machine asking the same question.
   *
   * Capped at eight. A list of thirty parameters is not a feature list; it is
   * the table again, and nothing consuming this reads that far.
   */
  const featureList = referenceTable.rows
    .slice(0, 8)
    .map((row) => (row.type && row.type !== "—" ? `${row.parameter} (${row.type})` : row.parameter));

  return (
    <article>
      {/* 0. SEO JSON-LD Schemas */}
      <SchemaJsonLd
        url={`/${slug}`}
        title={`${keyword} — ToolsByUs`}
        description={seoDescription}
        breadcrumbs={breadcrumbs}
        faqs={faqs}
        applicationName={keyword}
        featureList={featureList}
        dateModified={reviewedDate}
      />

      {/* 1–3. The head, centred on the page ground: breadcrumb, the H1 on the
             exact target keyword, then the 40–60 word answer an engine can
             quote. Centred because the tool below it is centred, and a
             left-aligned title over a centred panel reads as two pages stapled
             together. Bottom padding is deliberately large — the panel is
             pulled up into it, and this is the space it lands in. */}
      <header className="bg-background">
        <div className="shell pb-8 pt-6 sm:pb-10">
          {/*
            The same two-column hero the homepage uses, at a quarter of the
            scale. A tool page used to open with a centred title over empty
            space, which looked like the homepage's hero with the picture
            removed — and a visitor who arrives here from a search never sees
            the homepage, so this was the whole site as far as they knew.

            It stacks and centres below `lg`, where a drawing beside a headline
            would leave neither enough room.
          */}
          <div className="grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.6fr)] lg:gap-12">
            <div className="min-w-0 text-center lg:text-left">
              <Breadcrumb items={breadcrumbs} className="justify-center lg:justify-start" />

              <h1 className="mx-auto mt-5 max-w-[16ch] text-balance text-[2rem] font-semibold leading-[1.08] tracking-[-0.038em] text-foreground sm:text-[3.25rem] lg:mx-0">
                {keyword}
              </h1>

              {/* The quotable answer. `verify-seo` counts the left rule when it
                  audits the built HTML, so it stays. */}
              <p className="mx-auto mt-6 max-w-[58ch] border-l-2 border-accent-line pl-5 text-left text-base leading-relaxed text-foreground-muted sm:text-lg lg:mx-0">
                {directAnswer}
              </p>

              {/* The one guarantee the site is built on, stated on every tool
                  page rather than only in the site header, where it was easy to
                  miss and disappeared entirely above 1024px. */}
              <div className="mt-7 flex justify-center lg:justify-start">
                <PrivacyBadge />
              </div>
            </div>

            {/* Second in the source, so a screen reader and a phone both reach
                the title and the answer before the decoration. */}
            {tool && (
              <ToolScene
                category={tool.category}
                slug={slug}
                className="hidden w-full min-w-0 max-w-[26rem] justify-self-end text-foreground lg:block"
              />
            )}
          </div>
        </div>
      </header>

      {/* Everything from here down sits on the band, so the tool panel reads as
          lifted off the page rather than stacked on it. */}
      <div className="bg-background-subtle pb-20 pt-6 sm:pt-8">
        {/*
          4. The tool, above the fold and pulled up onto the boundary.

          Contained rather than full-bleed. The shell runs to 1440px, which a
          side-by-side diff genuinely uses, but a tool whose whole interface is
          a drop zone looked abandoned in the middle of it. `--tool-max` lets a
          page that needs the extra width ask for it without every page paying.
        */}
        <section aria-label={`${keyword} tool`} className="shell">
          <div
            className={`mx-auto rounded-xl bg-surface p-4 sm:p-6 lg:p-8 ${
              wide ? "" : "max-w-[64rem]"
            }`}
          >
            {children}
          </div>
        </section>

        {/* 5. Ad, below the tool. Never above the fold: if the tool is not the
               first thing visible, bounce rate takes both rankings and RPM. */}
        <div className="shell mx-auto max-w-[64rem]">
          <AdSlot id={`ad-slot-a-${slug}`} placement="top" />
        </div>

        {/* 6. Reference material, in a readable measure. */}
        <div className="shell mt-16 max-w-[52rem] space-y-14">
        <section aria-labelledby="how-it-works-heading">
          {/* Question-form headings: AI answer engines match headings against
              the query, and a user's query is nearly always phrased as one. */}
          <h2
            id="how-it-works-heading"
            className="heading-hash"
          >
            How does {keyword} work?
          </h2>

          <div className="prose-tool mt-4">
            {typeof howItWorks.algorithmExplanation === "string" ? (
              <p>{howItWorks.algorithmExplanation}</p>
            ) : (
              howItWorks.algorithmExplanation
            )}
          </div>

          <div className="mt-7 grid gap-4 md:grid-cols-2">
            {[
              { title: howItWorks.inputTitle || "Example input", body: howItWorks.exampleInput },
              { title: howItWorks.outputTitle || "Example output", body: howItWorks.exampleOutput },
            ].map((block) => (
              <div key={block.title} className="overflow-hidden rounded-lg bg-surface">
                <h3 className="px-4 pb-1 pt-3.5 text-sm font-semibold tracking-tight text-foreground">
                  {block.title}
                </h3>
                <pre className="overflow-x-auto px-4 pb-4 font-mono text-xs leading-relaxed text-foreground-muted">
                  {block.body}
                </pre>
              </div>
            ))}
          </div>
        </section>

        {/* 7. Reference table */}
        <section aria-labelledby="reference-heading">
          <h2
            id="reference-heading"
            className="heading-hash"
          >
            What options and edge cases does {keyword} support?
          </h2>

          {/* A table is the one place a rule is information rather than
              decoration: it is what tells you which cells belong to the same
              row. The border stays; the box around the whole thing goes. */}
          <div className="mt-5 overflow-x-auto rounded-lg bg-surface">
            <table className="w-full min-w-[40rem] border-collapse text-left text-sm">
              <caption className="sr-only">
                {referenceTable.title || "Technical reference and options"}
              </caption>
              <thead>
                <tr className="border-b border-border">
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Parameter
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Type
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Default
                  </th>
                  <th scope="col" className="px-4 py-3 text-xs font-semibold text-foreground-muted">
                    Behaviour &amp; edge cases
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {referenceTable.rows.map((row, idx) => (
                  <tr key={idx} className="transition-colors hover:bg-surface-elevated">
                    <th
                      scope="row"
                      className="whitespace-nowrap px-4 py-3 text-left align-top font-mono text-xs font-medium text-accent"
                    >
                      {row.parameter}
                    </th>
                    <td className="whitespace-nowrap px-4 py-3 align-top font-mono text-xs text-foreground-subtle">
                      {row.type}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 align-top font-mono text-xs text-foreground-subtle">
                      {row.defaultVal}
                    </td>
                    <td className="px-4 py-3 align-top text-[0.9375rem] leading-relaxed text-foreground-muted">
                      {row.description}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* 8. AdSlot B */}
        <AdSlot id={`ad-slot-b-${slug}`} placement="mid" />

        {/* 9. FAQ */}
        <FaqSection items={faqs} />

        {/* 10. Related tools */}
        <section aria-labelledby="related-tools-heading">
          <h2
            id="related-tools-heading"
            className="heading-hash"
          >
            Which related tools should I use next?
          </h2>

          <ul className="mt-5 grid gap-3 sm:grid-cols-2">
            {relatedTools.map((t) => {
              const related = TOOLS.find((entry) => entry.href === t.href);
              return (
                <li key={t.href}>
                  <Link
                    href={t.href}
                    className="group flex h-full items-start gap-3.5 rounded-lg bg-surface p-4 transition-colors hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent pointer-coarse:p-5"
                  >
                    <span className="mt-0.5 flex h-9 w-9 flex-none items-center justify-center rounded bg-surface-elevated text-foreground-muted transition-colors group-hover:bg-accent-soft group-hover:text-accent">
                      <Icon name={related?.icon ?? "chevronRight"} size="md" />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[0.9375rem] font-semibold tracking-tight text-foreground">
                        {t.title}
                      </span>
                      <span className="mt-1 block text-sm leading-relaxed text-foreground-muted">
                        {t.description}
                      </span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>

          {/* 11. Visible last-updated, machine readable via <time> */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-6 text-xs text-foreground-subtle">
            <Link href="/about#editorial-process" className="hover:text-accent underline underline-offset-4">ToolsByUs team · How we check our tools</Link>
            <span>
              Last updated{" "}
              <time dateTime={reviewedDate} className="font-mono text-foreground-muted">
                {reviewedDate}
              </time>
            </span>
          </div>
        </div>
      </div>
    </article>
  );
};
