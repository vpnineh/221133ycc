"use client";

import React, { useMemo, useState } from "react";
import { CodePane } from "./CodePane";
import { Notice } from "../common/Notice";
import { Icon } from "../common/Icon";
import { btnCompact } from "../common/controls";

/**
 * The shape almost every converter on this site takes: text in one pane, a
 * derived result in the other, a strip of options between them.
 *
 * Extracted because the alternative is fifteen near-identical copies of the
 * same two-pane layout, and a fix to the size guard or the error surface would
 * then have to be made fifteen times — which in practice means it gets made
 * three times and the other twelve quietly drift.
 *
 * Deliberately generic over the option state rather than prescribing one: each
 * tool owns its own options object and passes a `transform` closure. This
 * component owns only the input, the pane chrome, the size ceiling and the
 * presentation of success, warning and failure.
 */

export interface TransformOutcome {
  /** Rendered in the output pane. Empty string is a valid result. */
  output: string;
  /** Fatal problem. Shown instead of the output. */
  error?: string;
  /** Non-fatal notes: a lossy conversion, an assumption made, a dropped field. */
  warnings?: string[];
  /** Short facts rendered as a strip under the panes: counts, sizes, ratios. */
  stats?: Array<{ label: string; value: string }>;
}

interface TransformToolProps {
  inputLabel: string;
  outputLabel: string;
  inputPlaceholder?: string;
  initialInput: string;
  /** Pure function from input text to result. Called on every keystroke. */
  transform: (input: string) => TransformOutcome;
  /** Options strip rendered above the panes. */
  options?: React.ReactNode;
  /** Extra controls in the output pane's toolbar, e.g. a download button. */
  outputActions?: React.ReactNode;
  /** Suggested filename when the result is downloaded. */
  downloadName?: string;
  /** Pane height in pixels. */
  height?: number;
  /** Stack the panes vertically; for conversions where the output is wide. */
  stacked?: boolean;
  /** Input byte ceiling. Above it the transform is skipped entirely. */
  maxBytes?: number;
}

/** Shared main-thread ceiling: the point at which a tab starts to feel broken. */
const DEFAULT_MAX_BYTES = 8 * 1024 * 1024;

export const TransformTool: React.FC<TransformToolProps> = ({
  inputLabel,
  outputLabel,
  inputPlaceholder,
  initialInput,
  transform,
  options,
  outputActions,
  downloadName,
  height = 340,
  stacked = false,
  maxBytes = DEFAULT_MAX_BYTES,
}) => {
  const [input, setInput] = useState(initialInput);

  const tooLarge = useMemo(() => {
    // Measured without allocating a byte copy of the document, which is the
    // trap the editor's own size readout fell into.
    let bytes = 0;
    for (let i = 0; i < input.length; i++) {
      const code = input.charCodeAt(i);
      bytes += code < 0x80 ? 1 : code < 0x800 ? 2 : code < 0xd800 || code >= 0xe000 ? 3 : (i++, 4);
      if (bytes > maxBytes) return true;
    }
    return false;
  }, [input, maxBytes]);

  const result = useMemo<TransformOutcome>(() => {
    if (tooLarge) {
      return {
        output: "",
        error: `Input is larger than ${(maxBytes / (1024 * 1024)).toFixed(0)} MB. Converting it on the main thread would lock the tab, so the conversion is skipped rather than attempted.`,
      };
    }
    if (input.trim() === "") return { output: "" };
    try {
      return transform(input);
    } catch (err) {
      // A thrown error from an engine is a bug, not user error — say so rather
      // than blaming the input.
      return {
        output: "",
        error: `The conversion failed unexpectedly: ${(err as Error).message}. This is a defect in the tool rather than in your input.`,
      };
    }
  }, [input, transform, tooLarge, maxBytes]);

  const download = () => {
    if (!result.output || !downloadName) return;
    const blob = new Blob([result.output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = downloadName;
    anchor.click();
    // Without this the blob is retained for the life of the document, and a
    // long session converting large files leaks the lot.
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {options && (
        <div className="flex flex-wrap items-center gap-x-5 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5">
          {options}
        </div>
      )}

      <div className={stacked ? "space-y-4" : "grid gap-4 lg:grid-cols-2"}>
        <CodePane
          label={inputLabel}
          value={input}
          onChange={setInput}
          placeholder={inputPlaceholder}
          height={height}
        />
        <CodePane
          label={outputLabel}
          value={result.error ? "" : result.output}
          onChange={() => undefined}
          readOnly
          height={height}
          actions={
            <>
              {outputActions}
              {downloadName && result.output && (
                <button type="button" onClick={download} className={btnCompact} title={`Download ${downloadName}`}>
                  <Icon name="download" size="sm" />
                  <span className="sr-only sm:not-sr-only">Download</span>
                </button>
              )}
            </>
          }
        />
      </div>

      {result.error && (
        <Notice tone="danger" title="Cannot convert:">
          {result.error}
        </Notice>
      )}

      {result.warnings?.map((warning, index) => (
        <Notice key={index} tone="warn">
          {warning}
        </Notice>
      ))}

      {!result.error && result.stats && result.stats.length > 0 && (
        <dl className="grid grid-cols-2 gap-x-6 gap-y-3 rounded-lg border border-border bg-surface px-3 py-2.5 sm:grid-cols-4">
          {result.stats.map((stat) => (
            <div key={stat.label}>
              <dt className="font-mono text-2xs text-foreground-subtle">
                {stat.label}
              </dt>
              <dd className="mt-0.5 font-mono text-sm font-bold text-foreground">{stat.value}</dd>
            </div>
          ))}
        </dl>
      )}
    </div>
  );
};
