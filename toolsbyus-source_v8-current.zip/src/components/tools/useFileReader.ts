"use client";

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { MAX_FILE_BYTES } from "../../lib/files";

/** One pending read per input. A replacement or unmount invalidates older callbacks. */
export function useFileReader(onRead: (value: string) => void, mode: "text" | "dataURL" = "text") {
  const current = useRef<FileReader | null>(null);
  const [fileError, setFileError] = useState("");
  const receive = useRef(onRead);
  useLayoutEffect(() => { receive.current = onRead; }, [onRead]);
  const cancelRead = useCallback(() => {
    const previous = current.current;
    current.current = null;
    if (previous?.readyState === 1) previous.abort();
  }, []);
  useEffect(() => cancelRead, [cancelRead]);

  const readFile = (file: File | undefined) => {
    if (!file) return;
    cancelRead();
    if (file.size > MAX_FILE_BYTES) {
      setFileError("This file exceeds the 100 MB limit.");
      return;
    }
    setFileError("");
    const reader = new FileReader();
    current.current = reader;
    reader.onload = () => {
      if (current.current !== reader) return;
      current.current = null;
      if (typeof reader.result === "string") receive.current(reader.result);
    };
    const fail = () => {
      if (current.current !== reader) return;
      current.current = null;
      setFileError("This file could not be read. Please try another file.");
    };
    reader.onerror = fail;
    try {
      if (mode === "dataURL") reader.readAsDataURL(file);
      else reader.readAsText(file);
    } catch { fail(); }
  };
  return { readFile, cancelRead, fileError };
}
