"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { decodeImage, type DecodedImage } from "../../lib/images";
import type { AcceptedFile } from "../../lib/files";

/**
 * Runs one image operation across a selection of files.
 *
 * Every image tool on the site is the same loop — decode, transform, encode,
 * preview — differing only in the transform, so the loop lives here and the
 * pages supply a function. What the loop owns is the parts that are easy to get
 * wrong and invisible when they are:
 *
 * **One file at a time, not `Promise.all`.** Decoding eight 12-megapixel photos
 * concurrently means eight 48 MB bitmaps alive at once, which is how a phone
 * browser kills the tab. Sequential is barely slower — the encode is the
 * expensive part and it is not parallel anyway — and it keeps peak memory at
 * one image.
 *
 * **A yield between files.** `await` on an already-resolved promise does not
 * release the main thread for a paint, so a batch would run to completion with
 * the progress bar frozen at zero. A `setTimeout(0)` between files lets the
 * browser actually draw it.
 *
 * **Every bitmap closed and every URL revoked.** An `ImageBitmap` holds memory
 * outside the JavaScript heap that the garbage collector will not hurry to
 * reclaim, and an object URL is never collected at all while the document
 * lives. A session spent trying settings on forty photos is exactly where both
 * leaks become fatal.
 *
 * **One file's failure does not end the batch.** A corrupt image in a folder of
 * thirty should cost you that one image and a line saying which, not the run.
 */

export interface ImageJobOutput {
  blob: Blob;
  name: string;
  width: number;
  height: number;
}

export type ImageJob = (
  decoded: DecodedImage,
  file: File,
  /** 1-based position in the batch, so a naming pattern can use {n}. */
  position: number
) => Promise<ImageJobOutput>;

export interface ImageResult extends ImageJobOutput {
  id: string;
  url: string;
  originalName: string;
  originalBytes: number;
  /** True when the browser could not decode the source and libheif did. */
  viaHeic: boolean;
}

export type ImageBatchState =
  | { status: "idle" }
  | { status: "running"; done: number; total: number; label: string }
  | { status: "done"; results: ImageResult[]; failures: string[]; elapsedMs: number }
  | { status: "error"; message: string };

export function useImageBatch() {
  const [state, setState] = useState<ImageBatchState>({ status: "idle" });
  const runIdRef = useRef(0);
  const urlsRef = useRef<string[]>([]);

  const revokeAll = useCallback(() => {
    for (const url of urlsRef.current) URL.revokeObjectURL(url);
    urlsRef.current = [];
  }, []);

  useEffect(() => revokeAll, [revokeAll]);

  const reset = useCallback(() => {
    runIdRef.current++;
    revokeAll();
    setState({ status: "idle" });
  }, [revokeAll]);

  const run = useCallback(
    async (files: AcceptedFile[], job: ImageJob) => {
      if (files.length === 0) return;

      const runId = ++runIdRef.current;
      revokeAll();
      const started = Date.now();
      setState({ status: "running", done: 0, total: files.length, label: files[0].file.name });

      const results: ImageResult[] = [];
      const failures: string[] = [];

      for (const [index, entry] of files.entries()) {
        if (runId !== runIdRef.current) return;

        setState({
          status: "running",
          done: index,
          total: files.length,
          label: entry.file.name,
        });

        // Let the browser paint the bar before the next file locks the thread.
        await new Promise((resolve) => setTimeout(resolve, 0));
        if (runId !== runIdRef.current) return;

        let decoded: DecodedImage | null = null;
        try {
          decoded = await decodeImage(entry.file);
          const output = await job(decoded, entry.file, index + 1);
          if (runId !== runIdRef.current) {
            decoded.bitmap.close();
            return;
          }

          const url = URL.createObjectURL(output.blob);
          urlsRef.current.push(url);
          results.push({
            ...output,
            id: entry.id,
            url,
            originalName: entry.file.name,
            originalBytes: entry.file.size,
            viaHeic: decoded.viaHeic,
          });
        } catch (caught) {
          failures.push(caught instanceof Error ? caught.message : String(caught));
        } finally {
          decoded?.bitmap.close();
        }
      }

      if (runId !== runIdRef.current) return;

      if (results.length === 0) {
        setState({
          status: "error",
          message:
            failures[0] ??
            "Nothing could be processed, and nothing said why — which should not happen; please report it.",
        });
        return;
      }

      setState({ status: "done", results, failures, elapsedMs: Date.now() - started });
    },
    [revokeAll]
  );

  return { state, run, reset };
}
