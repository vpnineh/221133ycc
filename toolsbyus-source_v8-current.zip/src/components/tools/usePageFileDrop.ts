"use client";

import { useEffect, useEffectEvent, useRef, useState } from "react";

type Target = {
  element: () => HTMLElement | null;
  receive: (files: FileList) => void;
  disabled: () => boolean;
  highlight: (active: boolean) => void;
};
const targets = new Set<Target>();
let stop: (() => void) | undefined;

/** A page has exactly one receiver, including editors with two input panes.
 * Drop over a pane targets it; elsewhere uses the last-focused input or first
 * writable input in DOM order. Output panes never register. */
function listen() {
  let depth = 0;
  let focused: Target | undefined;
  const isFile = (event: DragEvent) => Array.from(event.dataTransfer?.types ?? []).includes("Files");
  const choose = (node: EventTarget | null) => {
    const ordered = [...targets].filter(t => t.element()?.getClientRects().length).sort((a, b) =>
      a.element()!.compareDocumentPosition(b.element()!) & Node.DOCUMENT_POSITION_PRECEDING ? 1 : -1);
    return ordered.find(t => node instanceof Node && t.element()?.contains(node))
      ?? (focused && ordered.includes(focused) ? focused : ordered[0]);
  };
  const show = (target?: Target) => targets.forEach(t => t.highlight(t === target));
  const reset = () => { depth = 0; show(); };
  const focus = (event: FocusEvent) => {
    const target = [...targets].find(t => event.target instanceof Node && t.element()?.contains(event.target));
    if (target) focused = target;
  };
  const enter = (event: DragEvent) => {
    if (!isFile(event)) return;
    event.preventDefault(); depth++; show(choose(event.target));
  };
  const over = (event: DragEvent) => {
    if (!isFile(event)) return;
    event.preventDefault();
    const target = choose(event.target);
    show(target);
    if (event.dataTransfer) event.dataTransfer.dropEffect = target && !target.disabled() ? "copy" : "none";
  };
  const leave = (event: DragEvent) => {
    if (!isFile(event)) return;
    depth = Math.max(0, depth - 1);
    if (!depth) reset();
  };
  const drop = (event: DragEvent) => {
    if (!isFile(event)) return;
    event.preventDefault();
    const target = choose(event.target);
    reset();
    if (target && !target.disabled() && event.dataTransfer?.files.length) target.receive(event.dataTransfer.files);
  };
  const key = (event: KeyboardEvent) => { if (event.key === "Escape") reset(); };
  document.addEventListener("focusin", focus);
  document.addEventListener("dragenter", enter);
  document.addEventListener("dragover", over);
  document.addEventListener("dragleave", leave);
  document.addEventListener("drop", drop);
  document.addEventListener("dragend", reset);
  document.addEventListener("keydown", key);
  window.addEventListener("blur", reset);
  return () => {
    document.removeEventListener("focusin", focus);
    document.removeEventListener("dragenter", enter);
    document.removeEventListener("dragover", over);
    document.removeEventListener("dragleave", leave);
    document.removeEventListener("drop", drop);
    document.removeEventListener("dragend", reset);
    document.removeEventListener("keydown", key);
    window.removeEventListener("blur", reset);
  };
}

export function usePageFileDrop(onFiles: (files: FileList) => void, { disabled = false, enabled = true } = {}) {
  const ref = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const receive = useEffectEvent(onFiles);
  const isDisabled = useEffectEvent(() => disabled);
  useEffect(() => {
    if (!enabled) return;
    const target: Target = { element: () => ref.current, receive, disabled: isDisabled, highlight: setDragging };
    targets.add(target);
    stop ??= listen();
    return () => {
      targets.delete(target);
      if (!targets.size) { stop?.(); stop = undefined; }
    };
  }, [enabled]);
  return { ref, dragging };
}
