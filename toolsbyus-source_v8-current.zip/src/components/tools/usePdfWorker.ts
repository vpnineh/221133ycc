"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { PdfInfo, PdfOperation, PdfWorkerResponse } from "../../workers/pdf.worker";

/**
 * Drives the PDF worker and owns its lifecycle.
 *
 * One worker per hook instance, terminated on unmount and on each new run. A
 * long-running operation that the user abandoned by starting another one is not
 * merely useless — it is still holding a copy of a 40 MB document, so leaving it
 * alive doubles the memory cost of every retry.
 *
 * A run counter guards against a late reply from a superseded operation
 * overwriting a newer result. Without it, a slow merge that the user cancelled
 * can land after a fast one and hand back the wrong file.
 */

export interface PdfResultFile {
  blob: Blob;
  name: string;
  bytes: number;
}

export type PdfRunState =
  | { status: "idle" }
  | { status: "running"; done: number; total: number; label: string }
  | { status: "done"; files: PdfResultFile[]; elapsedMs: number }
  | { status: "error"; message: string };

export function usePdfWorker() {
  const workerRef = useRef<Worker | null>(null);
  const runIdRef = useRef(0);
  const startedRef = useRef(0);
  const [state, setState] = useState<PdfRunState>({ status: "idle" });
  const [info, setInfo] = useState<PdfInfo | null>(null);

  const terminate = useCallback(() => {
    workerRef.current?.terminate();
    workerRef.current = null;
  }, []);

  useEffect(() => terminate, [terminate]);

  const run = useCallback(
    (operation: PdfOperation, transfer: Transferable[] = []) => {
      terminate();
      const runId = ++runIdRef.current;
      startedRef.current = Date.now();
      setState({ status: "running", done: 0, total: 1, label: "reading" });

      let worker: Worker;
      try {
        worker = new Worker(new URL("../../workers/pdf.worker.ts", import.meta.url), {
          type: "module",
        });
      } catch {
        setState({
          status: "error",
          message:
            "Web Workers are unavailable in this browser, and processing a PDF on the main thread would freeze the tab. Nothing was run.",
        });
        return;
      }
      workerRef.current = worker;

      worker.onmessage = (event: MessageEvent<PdfWorkerResponse>) => {
        if (runId !== runIdRef.current) return;
        const data = event.data;

        switch (data.type) {
          case "PROGRESS":
            setState({
              status: "running",
              done: data.done,
              total: data.total,
              label: data.label,
            });
            break;

          case "INFO":
            setInfo(data.info);
            setState({ status: "idle" });
            terminate();
            break;

          case "RESULT":
            setState({
              status: "done",
              elapsedMs: Date.now() - startedRef.current,
              files: data.files.map((file) => ({
                blob: new Blob([file.bytes], { type: "application/pdf" }),
                name: file.name,
                bytes: file.bytes.byteLength,
              })),
            });
            terminate();
            break;

          case "ERROR":
            setState({ status: "error", message: data.message });
            terminate();
            break;
        }
      };

      worker.onerror = (event) => {
        if (runId !== runIdRef.current) return;
        setState({
          status: "error",
          message: event.message || "The PDF worker failed to start.",
        });
        terminate();
      };

      worker.postMessage(operation, transfer);
    },
    [terminate]
  );

  const reset = useCallback(() => {
    terminate();
    runIdRef.current++;
    setState({ status: "idle" });
    setInfo(null);
  }, [terminate]);

  return { state, info, run, reset, cancel: terminate };
}

/** Reads a File into a transferable ArrayBuffer. */
export async function readFile(file: File): Promise<ArrayBuffer> {
  return file.arrayBuffer();
}
