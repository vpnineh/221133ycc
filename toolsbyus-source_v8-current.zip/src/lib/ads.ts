import { buildAdsConfig } from "./ads.data.mjs";

/**
 * Typed view of the shared ad configuration.
 *
 * `process.env.NEXT_PUBLIC_*` is inlined by Next at build time, so the members
 * have to be read as literal property accesses for the substitution to happen —
 * `env[name]` would leave the lookup in the bundle and resolve to undefined in
 * the browser.
 */
export interface AdsConfig {
  enabled: boolean;
  publisherId: string | null;
  clientId: string | null;
  units: { top: string | null; mid: string | null };
  misconfigured: boolean;
}

export const ADS: AdsConfig = buildAdsConfig({
  NEXT_PUBLIC_ADSENSE_ID: process.env.NEXT_PUBLIC_ADSENSE_ID,
  NEXT_PUBLIC_AD_UNIT_TOP: process.env.NEXT_PUBLIC_AD_UNIT_TOP,
  NEXT_PUBLIC_AD_UNIT_MID: process.env.NEXT_PUBLIC_AD_UNIT_MID,
}) as AdsConfig;

/** Which ad-unit slot a placement maps to. */
export type AdPlacement = "top" | "mid";

export function adUnitFor(placement: AdPlacement): string | null {
  return ADS.units[placement];
}
