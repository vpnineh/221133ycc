/**
 * Linear (1D) barcode encoding, from the symbology specifications.
 *
 * A barcode is not a picture of a number — it is a specific sequence of bar and
 * space widths, with a check digit the scanner recomputes and a quiet zone it
 * needs in order to find the symbol at all. Get the check digit wrong and the
 * scanner beeps and reports nothing; get the quiet zone wrong and it never
 * beeps. Both are silent failures that only show up against real hardware,
 * which is why they are the two things this module is most careful about.
 *
 * Everything here produces a *module pattern*: an array of 1s and 0s, one entry
 * per narrow module, where 1 is a bar. Rendering that into SVG or canvas is the
 * caller's problem, and keeping it separate is what lets the same encoder be
 * unit-tested without a DOM.
 *
 * No dependency. The tables are in ISO/IEC 15417 (Code 128), ISO/IEC 15420
 * (EAN/UPC), ISO/IEC 16388 (Code 39) and ISO/IEC 16390 (ITF-14), and they do
 * not change.
 */

export type Symbology = "code128" | "ean13" | "ean8" | "upca" | "upce" | "code39" | "itf14";

export interface SymbologyInfo {
  id: Symbology;
  label: string;
  /** What the input has to look like, in a sentence a person can act on. */
  accepts: string;
  /** Where it is actually used, which is how people decide which one they need. */
  usedFor: string;
  /** Quiet zone each side, in modules, from the standard. */
  quietZone: number;
  /** Whether the human-readable line sits under the bars by convention. */
  showsText: boolean;
}

export const SYMBOLOGIES: SymbologyInfo[] = [
  {
    id: "code128",
    label: "Code 128",
    accepts: "Any ASCII text, any length",
    usedFor: "Shipping labels, asset tags, GS1-128 logistics — the general-purpose choice",
    quietZone: 10,
    showsText: true,
  },
  {
    id: "ean13",
    label: "EAN-13",
    accepts: "12 digits (the 13th is calculated)",
    usedFor: "Retail products outside North America",
    quietZone: 11,
    showsText: true,
  },
  {
    id: "ean8",
    label: "EAN-8",
    accepts: "7 digits (the 8th is calculated)",
    usedFor: "Small retail packages with no room for a full EAN-13",
    quietZone: 7,
    showsText: true,
  },
  {
    id: "upca",
    label: "UPC-A",
    accepts: "11 digits (the 12th is calculated)",
    usedFor: "Retail products in the United States and Canada",
    quietZone: 9,
    showsText: true,
  },
  {
    id: "code39",
    label: "Code 39",
    accepts: "A–Z, 0–9, space and - . $ / + %",
    usedFor: "Defence, automotive and health logistics; older scanners read nothing else",
    quietZone: 10,
    showsText: true,
  },
  {
    id: "itf14",
    label: "ITF-14",
    accepts: "13 digits (the 14th is calculated)",
    usedFor: "Outer cases and pallets — printed on corrugated board, where fine bars fail",
    quietZone: 10,
    showsText: true,
  },
];

export interface EncodedBarcode {
  /** One entry per module. 1 is a bar, 0 is a space. Quiet zones not included. */
  modules: number[];
  /** The full value including any check digit the encoder added. */
  text: string;
  /** The human-readable line, grouped the way the standard prints it. */
  display: string;
  symbology: Symbology;
  quietZone: number;
  /**
   * Module indices where a guard bar runs taller than the rest, as EAN and UPC
   * require. Empty for the symbologies that have no guard pattern.
   */
  guards: number[];
}

export class BarcodeError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "BarcodeError";
  }
}

/* ------------------------------------------------------------------------- */
/* Code 128                                                                   */
/* ------------------------------------------------------------------------- */

/**
 * The 107 Code 128 patterns, as bar/space run lengths.
 *
 * Each string is six digits: bar, space, bar, space, bar, space, summing to 11
 * modules. Index is the code value; 103–105 are the start codes for sets A, B
 * and C, and 106 is the stop pattern (which is 13 modules — the only exception).
 */
const CODE128_PATTERNS = [
  "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312",
  "132212", "221213", "221312", "231212", "112232", "122132", "122231", "113222",
  "123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131",
  "311222", "321122", "321221", "312212", "322112", "322211", "212123", "212321",
  "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
  "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121",
  "313121", "211331", "231131", "213113", "213311", "213131", "311123", "311321",
  "331121", "312113", "312311", "332111", "314111", "221411", "431111", "111224",
  "111422", "121124", "121421", "141122", "141221", "112214", "112412", "122114",
  "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
  "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112",
  "421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113",
  "114311", "411113", "411311", "113141", "114131", "311141", "411131", "211412",
  "211214", "211232", "2331112",
];

/**
 * 107 patterns, 0 through 106, and the count is asserted rather than assumed.
 *
 * An off-by-one here is the worst kind of bug this file can have: every symbol
 * still renders, most of them still scan, and the ones that do scan report the
 * wrong characters. It cost a round of failing tests to find six duplicated
 * rows pasted into the middle of the table, where the only visible symptom was
 * a stop pattern two modules short.
 */
if (CODE128_PATTERNS.length !== 107) {
  throw new Error(
    `Code 128 needs exactly 107 patterns; the table has ${CODE128_PATTERNS.length}.`
  );
}

const CODE128_START_B = 104;
const CODE128_START_C = 105;
const CODE128_STOP = 106;

/** Expands "212222" into [1,1,0,0,1,1,1,1,0,0,0,0] — bars first, alternating. */
function expandRuns(runs: string): number[] {
  const modules: number[] = [];
  for (let index = 0; index < runs.length; index++) {
    const width = Number(runs[index]);
    const value = index % 2 === 0 ? 1 : 0;
    for (let n = 0; n < width; n++) modules.push(value);
  }
  return modules;
}

/**
 * Encodes into Code 128, switching to set C for runs of digits.
 *
 * Set C packs two digits into one symbol, so a 12-digit value is 6 symbols
 * instead of 12 — a barcode roughly half the width, which on a 100mm label is
 * the difference between fitting and not. The switch is only worth it for runs
 * of four or more (six at the start), because the switch itself costs a symbol.
 *
 * Set A, which holds the control characters, is deliberately not used: the
 * printable range is covered by set B, and a tool that silently emitted a
 * control character because the input contained a tab would produce a symbol
 * that scans as something nobody typed.
 */
export function encodeCode128(input: string): EncodedBarcode {
  if (input.length === 0) throw new BarcodeError("Nothing to encode.");

  for (const character of input) {
    const code = character.charCodeAt(0);
    if (code < 32 || code > 126) {
      throw new BarcodeError(
        `Code 128 here covers printable ASCII, and ${JSON.stringify(character)} is outside it. ` +
          "Remove it, or use a QR code, which is built for arbitrary text."
      );
    }
  }

  /** How many digits start at `from`. */
  const digitRunAt = (from: number) => {
    let run = 0;
    while (from + run < input.length && input[from + run] >= "0" && input[from + run] <= "9") run++;
    return run;
  };

  const values: number[] = [];
  let position = 0;
  // Six digits at the very start is the threshold where starting in C wins;
  // four anywhere else, because a mid-string switch costs one symbol and saves
  // two per pair.
  let inSetC = digitRunAt(0) >= 6 || digitRunAt(0) === input.length;
  values.push(inSetC && digitRunAt(0) >= 2 ? CODE128_START_C : CODE128_START_B);
  if (values[0] === CODE128_START_B) inSetC = false;

  while (position < input.length) {
    const run = digitRunAt(position);

    if (inSetC) {
      if (run >= 2) {
        // Set C consumes pairs. An odd digit left at the end of a run has to be
        // emitted in B, so switch back before it rather than after.
        const pairs = Math.floor(run / 2);
        for (let pair = 0; pair < pairs; pair++) {
          values.push(Number(input.slice(position, position + 2)));
          position += 2;
        }
        continue;
      }
      values.push(CODE128_START_B - 4); // 100: switch to set B
      inSetC = false;
      continue;
    }

    if (run >= 4 && run % 2 === 0) {
      values.push(CODE128_START_C - 6); // 99: switch to set C
      inSetC = true;
      continue;
    }

    values.push(input.charCodeAt(position) - 32);
    position += 1;
  }

  // Modulo 103 over the start code plus each value weighted by its position.
  let checksum = values[0];
  for (let index = 1; index < values.length; index++) checksum += values[index] * index;
  values.push(checksum % 103);
  values.push(CODE128_STOP);

  const modules = values.flatMap((value) => expandRuns(CODE128_PATTERNS[value]));
  return {
    modules,
    text: input,
    display: input,
    symbology: "code128",
    quietZone: 10,
    guards: [],
  };
}

/* ------------------------------------------------------------------------- */
/* EAN / UPC                                                                  */
/* ------------------------------------------------------------------------- */

/** L, G and R digit patterns, seven modules each. */
const EAN_L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"];
const EAN_G = ["0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111"];
const EAN_R = ["1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100"];

/**
 * Which of L and G the six left-hand digits use, chosen by the first digit.
 *
 * This is the part of EAN-13 that surprises people: the thirteenth digit has no
 * bars of its own. It is encoded entirely in *which pattern set* each of the
 * next six digits uses, which is how a 13-digit number fits in a 12-digit
 * symbol — and why an EAN-13 cannot simply be re-rendered as a UPC-A.
 */
const EAN13_PARITY = [
  "LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG",
  "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL",
];

/** EAN-8's left half is always L, so its parity table is a constant. */
const EAN8_PARITY = "LLLL";

const digitsOnly = (value: string) => value.replace(/[\s-]/g, "");

/**
 * The modulo-10 check digit shared by EAN-8, EAN-13, UPC-A and ITF-14.
 *
 * Weights alternate 3 and 1 from the right. Every one of these standards uses
 * the same rule, which is why there is one function rather than four.
 */
export function checkDigit(digits: string): number {
  let sum = 0;
  // From the right, so the weighting is anchored to the check position and not
  // to the length — which is what makes it correct for 7, 11, 12 and 13 digits
  // alike without a table of special cases.
  for (let index = digits.length - 1, weight = 3; index >= 0; index--, weight = weight === 3 ? 1 : 3) {
    sum += Number(digits[index]) * weight;
  }
  return (10 - (sum % 10)) % 10;
}

function requireDigits(value: string, expected: number[], label: string): string {
  const digits = digitsOnly(value);
  if (!/^\d*$/.test(digits)) {
    throw new BarcodeError(`${label} holds digits only. Remove anything that is not 0–9.`);
  }
  if (!expected.includes(digits.length)) {
    const wanted = expected.map((n) => String(n)).join(" or ");
    throw new BarcodeError(
      `${label} needs ${wanted} digits; this has ${digits.length}.`
    );
  }
  return digits;
}

function encodeEanFamily(
  value: string,
  kind: "ean13" | "ean8" | "upca"
): EncodedBarcode {
  const spec = {
    ean13: { body: 12, lengths: [12, 13], label: "EAN-13" },
    ean8: { body: 7, lengths: [7, 8], label: "EAN-8" },
    upca: { body: 11, lengths: [11, 12], label: "UPC-A" },
  }[kind];

  const digits = requireDigits(value, spec.lengths, spec.label);
  // A full-length input carries its own check digit. Verify it rather than
  // trusting it: a mistyped one produces a symbol that scans as a different
  // product, which is worse than a symbol that does not scan at all.
  const body = digits.slice(0, spec.body);
  const computed = checkDigit(body);
  if (digits.length === spec.body + 1 && Number(digits[spec.body]) !== computed) {
    throw new BarcodeError(
      `The check digit does not match: this number ends in ${digits[spec.body]}, and ` +
        `${body} checks to ${computed}. Either the number is mistyped, or drop the last ` +
        "digit and let it be calculated."
    );
  }
  const full = body + computed;

  // UPC-A is an EAN-13 whose leading digit is 0. Encoding it that way rather
  // than with a second table is not a shortcut — it is what the standard says,
  // and it is why a UPC scans in Europe.
  const asEan13 = kind === "upca" ? `0${full}` : full;

  const modules: number[] = [];
  const guards: number[] = [];
  const pushGuard = (pattern: string) => {
    for (const bit of pattern) {
      guards.push(modules.length);
      modules.push(Number(bit));
    }
  };
  const push = (pattern: string) => {
    for (const bit of pattern) modules.push(Number(bit));
  };

  if (kind === "ean8") {
    pushGuard("101");
    for (let index = 0; index < 4; index++) {
      push(EAN8_PARITY[index] === "L" ? EAN_L[Number(full[index])] : EAN_G[Number(full[index])]);
    }
    pushGuard("01010");
    for (let index = 4; index < 8; index++) push(EAN_R[Number(full[index])]);
    pushGuard("101");
  } else {
    const parity = EAN13_PARITY[Number(asEan13[0])];
    pushGuard("101");
    for (let index = 1; index <= 6; index++) {
      const digit = Number(asEan13[index]);
      push(parity[index - 1] === "L" ? EAN_L[digit] : EAN_G[digit]);
    }
    pushGuard("01010");
    for (let index = 7; index <= 12; index++) push(EAN_R[Number(asEan13[index])]);
    pushGuard("101");
  }

  // The human-readable line is grouped the way the standard prints it, because
  // that grouping is how a person reads the number back off a package.
  const display =
    kind === "ean13"
      ? `${full[0]} ${full.slice(1, 7)} ${full.slice(7)}`
      : kind === "upca"
        ? `${full[0]} ${full.slice(1, 6)} ${full.slice(6, 11)} ${full[11]}`
        : `${full.slice(0, 4)} ${full.slice(4)}`;

  return {
    modules,
    text: full,
    display,
    symbology: kind,
    quietZone: kind === "ean13" ? 11 : kind === "upca" ? 9 : 7,
    guards,
  };
}

/* ------------------------------------------------------------------------- */
/* Code 39                                                                    */
/* ------------------------------------------------------------------------- */

/**
 * Code 39, as nine-element patterns: five bars and four spaces, three of which
 * are wide. The name is the mnemonic — 3 of 9 elements are wide.
 */
const CODE39: Record<string, string> = {
  "0": "101001101101", "1": "110100101011", "2": "101100101011", "3": "110110010101",
  "4": "101001101011", "5": "110100110101", "6": "101100110101", "7": "101001011011",
  "8": "110100101101", "9": "101100101101", A: "110101001011", B: "101101001011",
  C: "110110100101", D: "101011001011", E: "110101100101", F: "101101100101",
  G: "101010011011", H: "110101001101", I: "101101001101", J: "101011001101",
  K: "110101010011", L: "101101010011", M: "110110101001", N: "101011010011",
  O: "110101101001", P: "101101101001", Q: "101010110011", R: "110101011001",
  S: "101101011001", T: "101011011001", U: "110010101011", V: "100110101011",
  W: "110011010101", X: "100101101011", Y: "110010110101", Z: "100110110101",
  "-": "100101011011", ".": "110010101101", " ": "100110101101", $: "100100100101",
  "/": "100100101001", "+": "100101001001", "%": "101001001001", "*": "100101101101",
};

/**
 * Code 39 has no check digit in its base form and no lower case.
 *
 * The input is upper-cased rather than rejected, because "abc" and "ABC" encode
 * to the same symbol and refusing the first would be pedantry. Anything outside
 * the 43-character set is refused, because there is no pattern for it and
 * substituting a space would silently change the data.
 */
export function encodeCode39(input: string): EncodedBarcode {
  const value = input.toUpperCase();
  if (value.length === 0) throw new BarcodeError("Nothing to encode.");

  for (const character of value) {
    if (character === "*") {
      throw new BarcodeError(
        "* is the start and stop character in Code 39 and cannot appear in the data."
      );
    }
    if (!(character in CODE39)) {
      throw new BarcodeError(
        `Code 39 covers A–Z, 0–9, space and - . $ / + % — and ${JSON.stringify(character)} ` +
          "is not one of them. Code 128 takes any printable ASCII."
      );
    }
  }

  // Start and stop are both *, and every character is followed by a one-module
  // space. Omitting that inter-character gap is the classic Code 39 bug: the
  // symbol looks right and no scanner will read it.
  const parts = ["*", ...value.split(""), "*"];
  const modules: number[] = [];
  parts.forEach((character, index) => {
    for (const bit of CODE39[character]) modules.push(Number(bit));
    if (index < parts.length - 1) modules.push(0);
  });

  return {
    modules,
    text: value,
    display: `*${value}*`,
    symbology: "code39",
    quietZone: 10,
    guards: [],
  };
}

/* ------------------------------------------------------------------------- */
/* ITF-14                                                                     */
/* ------------------------------------------------------------------------- */

/**
 * Interleaved 2 of 5: five elements per digit, two of them wide.
 *
 * "Interleaved" is literal — digits are encoded in pairs, the first digit in the
 * bars and the second in the spaces between them. That is what halves the width
 * against a non-interleaved code, and why the data length must be even.
 */
const ITF_PATTERNS = [
  "NNWWN", "WNNNW", "NWNNW", "WWNNN", "NNWNW",
  "WNWNN", "NWWNN", "NNNWW", "WNNWN", "NWNWN",
];

const ITF_WIDE = 3; // Wide:narrow ratio, within the 2:1–3:1 the standard allows.

export function encodeItf14(value: string): EncodedBarcode {
  const digits = requireDigits(value, [13, 14], "ITF-14");
  const body = digits.slice(0, 13);
  const computed = checkDigit(body);
  if (digits.length === 14 && Number(digits[13]) !== computed) {
    throw new BarcodeError(
      `The check digit does not match: this number ends in ${digits[13]}, and ${body} ` +
        `checks to ${computed}.`
    );
  }
  const full = body + computed;

  const modules: number[] = [];
  // Start: narrow bar, narrow space, narrow bar, narrow space.
  modules.push(1, 0, 1, 0);

  for (let pair = 0; pair < full.length; pair += 2) {
    const bars = ITF_PATTERNS[Number(full[pair])];
    const spaces = ITF_PATTERNS[Number(full[pair + 1])];
    for (let element = 0; element < 5; element++) {
      const barWidth = bars[element] === "W" ? ITF_WIDE : 1;
      const spaceWidth = spaces[element] === "W" ? ITF_WIDE : 1;
      for (let n = 0; n < barWidth; n++) modules.push(1);
      for (let n = 0; n < spaceWidth; n++) modules.push(0);
    }
  }

  // Stop: wide bar, narrow space, narrow bar.
  for (let n = 0; n < ITF_WIDE; n++) modules.push(1);
  modules.push(0, 1);

  return {
    modules,
    text: full,
    display: `${full.slice(0, 1)} ${full.slice(1, 3)} ${full.slice(3, 8)} ${full.slice(8, 13)} ${full[13]}`,
    symbology: "itf14",
    quietZone: 10,
    guards: [],
  };
}

/* ------------------------------------------------------------------------- */
/* Entry point                                                                */
/* ------------------------------------------------------------------------- */

export function encodeBarcode(value: string, symbology: Symbology): EncodedBarcode {
  switch (symbology) {
    case "code128":
      return encodeCode128(value);
    case "ean13":
      return encodeEanFamily(value, "ean13");
    case "ean8":
      return encodeEanFamily(value, "ean8");
    case "upca":
      return encodeEanFamily(value, "upca");
    case "code39":
      return encodeCode39(value);
    case "itf14":
      return encodeItf14(value);
    case "upce":
      throw new BarcodeError("UPC-E is not supported yet.");
  }
}

/* ------------------------------------------------------------------------- */
/* Rendering                                                                  */
/* ------------------------------------------------------------------------- */

export interface RenderOptions {
  /** Width of one narrow module, in px. The standards call this X. */
  moduleWidth?: number;
  /** Height of the bars, in px, before the text line. */
  barHeight?: number;
  foreground?: string;
  background?: string;
  /** Print the value under the bars. */
  showText?: boolean;
  fontSize?: number;
}

/**
 * Renders to SVG.
 *
 * SVG rather than canvas because a barcode is printed far more often than it is
 * displayed, and a raster one at the wrong DPI is the single most common reason
 * a label fails to scan — the bars land on non-integer device pixels and the
 * printer smears the edges. Vector output has no resolution to get wrong.
 *
 * Adjacent bars are merged into one rectangle. A 100-module symbol drawn as 100
 * separate rects has hairline seams between them at some zoom levels, and those
 * seams are exactly what a scanner's edge detector looks for.
 */
export function renderSvg(encoded: EncodedBarcode, options: RenderOptions = {}): string {
  const {
    moduleWidth = 2,
    barHeight = 80,
    foreground = "#000000",
    background = "#ffffff",
    showText = true,
    fontSize = 14,
  } = options;

  const quiet = encoded.quietZone;
  const totalModules = encoded.modules.length + quiet * 2;
  const width = totalModules * moduleWidth;
  // Guard bars on EAN and UPC run 5 modules below the others, which is what
  // gives the symbol its recognisable "tails" — and what the human-readable
  // digits sit between.
  const guardExtra = encoded.guards.length > 0 ? moduleWidth * 5 : 0;
  const textGap = showText ? fontSize + 6 : 0;
  const height = barHeight + guardExtra + textGap + 4;

  const guardSet = new Set(encoded.guards);
  const rects: string[] = [];

  let index = 0;
  while (index < encoded.modules.length) {
    if (encoded.modules[index] === 0) {
      index += 1;
      continue;
    }
    // A run may not span the guard/normal boundary, or one of them gets the
    // wrong height.
    const isGuard = guardSet.has(index);
    let run = 1;
    while (
      index + run < encoded.modules.length &&
      encoded.modules[index + run] === 1 &&
      guardSet.has(index + run) === isGuard
    ) {
      run += 1;
    }
    const x = (quiet + index) * moduleWidth;
    const barLength = barHeight + (isGuard ? guardExtra : 0);
    rects.push(
      `<rect x="${round2(x)}" y="0" width="${round2(run * moduleWidth)}" height="${round2(barLength)}" />`
    );
    index += run;
  }

  const text = showText
    ? `<text x="${round2(width / 2)}" y="${round2(height - 4)}" text-anchor="middle" ` +
      `font-family="ui-monospace, SFMono-Regular, Menlo, monospace" font-size="${fontSize}" ` +
      `letter-spacing="1" fill="${foreground}">${escapeXml(encoded.display)}</text>`
    : "";

  return (
    `<svg xmlns="http://www.w3.org/2000/svg" width="${round2(width)}" height="${round2(height)}" ` +
    `viewBox="0 0 ${round2(width)} ${round2(height)}" role="img" ` +
    `aria-label="${escapeXml(encoded.symbology)} barcode for ${escapeXml(encoded.text)}">` +
    `<rect width="100%" height="100%" fill="${background}" />` +
    `<g fill="${foreground}">${rects.join("")}</g>${text}</svg>`
  );
}

const round2 = (value: number) => Math.round(value * 100) / 100;

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * The printed width at a given module width, in millimetres.
 *
 * Worth surfacing because it is the number that decides whether a symbol fits
 * on the label, and because the standards set a minimum X — 0.264mm for retail
 * EAN/UPC, 0.495mm for ITF-14 on corrugated board. Below that, print gain
 * closes the spaces and the symbol stops scanning.
 */
export function printedWidthMm(encoded: EncodedBarcode, moduleWidthMm: number): number {
  return (encoded.modules.length + encoded.quietZone * 2) * moduleWidthMm;
}
