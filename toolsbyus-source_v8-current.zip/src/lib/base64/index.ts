export type Base64Alphabet = "standard" | "url-safe";
export type TextEncoding = "utf-8" | "ascii" | "utf-16le";

export interface JwtInspection {
  isJwt: boolean;
  header?: any;
  payload?: any;
  signature?: string;
  headerRaw?: string;
  payloadRaw?: string;
  /**
   * Advisory notes about the token. The signature is never verified here — this
   * is a decoder, and verification needs the issuer's key, which would mean
   * sending the token somewhere.
   */
  warnings?: string[];
  expiresAt?: string;
  isExpired?: boolean;
}

/**
 * Standard to URL-safe and vice versa helpers
 */
export function toUrlSafe(base64: string): string {
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function fromUrlSafe(urlSafe: string): string {
  // MIME (RFC 2045), PEM and most copied-from-a-terminal Base64 is line-wrapped.
  // Strip all whitespace first — atob() throws on embedded newlines.
  let base64 = urlSafe.replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
  const remainder = base64.length % 4;
  if (remainder === 1) {
    // 4n+1 can never be valid Base64; padding it would only defer the failure.
    return base64;
  }
  if (remainder !== 0) {
    base64 += "=".repeat(4 - remainder);
  }
  return base64;
}

/**
 * Build a binary string from bytes in chunks.
 *
 * `String.fromCharCode(...bytes)` spreads every byte as an argument and throws
 * RangeError past roughly 100k elements, which is well inside the payload sizes
 * this tool advertises.
 */
const CHUNK = 0x8000;

function bytesToBinaryString(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    out += String.fromCharCode.apply(
      null,
      bytes.subarray(i, i + CHUNK) as unknown as number[]
    );
  }
  return out;
}

function codeUnitsToString(units: Uint16Array): string {
  let out = "";
  for (let i = 0; i < units.length; i += CHUNK) {
    out += String.fromCharCode.apply(
      null,
      units.subarray(i, i + CHUNK) as unknown as number[]
    );
  }
  return out;
}

/**
 * Encode string to Base64 with specified encoding and alphabet.
 */
export function encodeBase64(
  input: string,
  alphabet: Base64Alphabet = "standard",
  encoding: TextEncoding = "utf-8"
): string {
  let bytes: Uint8Array;

  if (encoding === "ascii") {
    bytes = new Uint8Array(input.length);
    for (let i = 0; i < input.length; i++) {
      bytes[i] = input.charCodeAt(i) & 0x7f;
    }
  } else if (encoding === "utf-16le") {
    bytes = new Uint8Array(input.length * 2);
    for (let i = 0; i < input.length; i++) {
      const code = input.charCodeAt(i);
      bytes[i * 2] = code & 0xff;
      bytes[i * 2 + 1] = (code >> 8) & 0xff;
    }
  } else {
    // UTF-8
    bytes = new TextEncoder().encode(input);
  }

  const stdB64 = btoa(bytesToBinaryString(bytes));

  return alphabet === "url-safe" ? toUrlSafe(stdB64) : stdB64;
}

/**
 * Decode Base64 to string or raw binary.
 */
export function decodeBase64(
  input: string,
  encoding: TextEncoding = "utf-8"
): { text: string; bytes: Uint8Array; error?: string } {
  try {
    const stdB64 = fromUrlSafe(input);

    if (stdB64.length === 0) {
      return { text: "", bytes: new Uint8Array(0) };
    }
    if (stdB64.length % 4 !== 0) {
      return {
        text: "",
        bytes: new Uint8Array(0),
        error: "Base64 decode failed: input length is not a multiple of 4 after padding.",
      };
    }
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(stdB64)) {
      return {
        text: "",
        bytes: new Uint8Array(0),
        error:
          "Base64 decode failed: input contains characters outside the Base64 alphabet (A–Z, a–z, 0–9, +, /, =).",
      };
    }

    const binary = atob(stdB64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    let text = "";
    if (encoding === "ascii") {
      const masked = new Uint8Array(bytes.length);
      for (let i = 0; i < bytes.length; i++) masked[i] = bytes[i] & 0x7f;
      text = bytesToBinaryString(masked);
    } else if (encoding === "utf-16le") {
      const pairCount = Math.floor(bytes.length / 2);
      const u16 = new Uint16Array(pairCount);
      // Assemble manually: a Uint16Array view over bytes.buffer would inherit
      // the platform's endianness and needs a 2-byte-aligned offset.
      for (let i = 0; i < pairCount; i++) {
        u16[i] = bytes[i * 2] | (bytes[i * 2 + 1] << 8);
      }
      text = codeUnitsToString(u16);
    } else {
      // UTF-8
      text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    }

    return { text, bytes };
  } catch (err) {
    return {
      text: "",
      bytes: new Uint8Array(0),
      error: `Base64 decode failed: ${(err as Error).message}`,
    };
  }
}

/**
 * Inspect a string to determine if it is a JSON Web Token (JWT).
 */
export function inspectJwt(input: string): JwtInspection {
  const trimmed = input.trim();
  const parts = trimmed.split(".");
  if (parts.length !== 3) {
    return { isJwt: false };
  }

  try {
    const headerDecoded = decodeBase64(parts[0], "utf-8");
    const payloadDecoded = decodeBase64(parts[1], "utf-8");

    if (headerDecoded.error || payloadDecoded.error) {
      return { isJwt: false };
    }

    const header = JSON.parse(headerDecoded.text);
    const payload = JSON.parse(payloadDecoded.text);

    // Basic JWT sanity check: header should have 'alg' or 'typ'
    if (header && (header.alg !== undefined || header.typ !== undefined)) {
      const warnings: string[] = [];

      if (typeof header.alg === "string" && header.alg.toLowerCase() === "none") {
        warnings.push(
          'Header declares alg "none" — this token is unsigned. Any party can forge it; never accept it as proof of identity.'
        );
      }
      if (parts[2] === "") {
        warnings.push("The signature segment is empty, so this token carries no integrity protection.");
      }

      let expiresAt: string | undefined;
      let isExpired: boolean | undefined;
      if (typeof payload?.exp === "number") {
        const expMs = payload.exp * 1000;
        expiresAt = new Date(expMs).toISOString();
        isExpired = expMs < Date.now();
        if (isExpired) warnings.push(`Token expired at ${expiresAt}.`);
      }
      if (typeof payload?.nbf === "number" && payload.nbf * 1000 > Date.now()) {
        warnings.push(`Token is not valid before ${new Date(payload.nbf * 1000).toISOString()}.`);
      }

      return {
        isJwt: true,
        header,
        payload,
        signature: parts[2],
        headerRaw: headerDecoded.text,
        payloadRaw: payloadDecoded.text,
        warnings,
        expiresAt,
        isExpired,
      };
    }
  } catch {
    // Not valid JSON
  }

  return { isJwt: false };
}
