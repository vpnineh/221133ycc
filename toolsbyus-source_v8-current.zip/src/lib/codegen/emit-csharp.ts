import {
  CSHARP_KEYWORDS,
  pascalCase,
  safeName,
  type Field,
  type NamedType,
  type TypeNode,
} from "./model";

/**
 * C# emitter.
 *
 * The nullable reference type decision drives everything. Under
 * `<Nullable>enable</Nullable>`, a `string` property that JSON can leave absent
 * is a compile-time warning waiting to happen, and a runtime
 * `NullReferenceException` if it is ignored. So optional and nullable fields get
 * `?` — on value types that is `Nullable<T>`, on reference types it is the
 * annotation. Both are correct and neither is optional if the generated code is
 * going into a modern project.
 */

export type CSharpStyle = "class" | "record";

export interface CSharpOptions {
  style: CSharpStyle;
  /** Namespace declaration; empty for none. */
  namespaceName: string;
  /** `[JsonPropertyName]` from System.Text.Json, rather than Newtonsoft. */
  systemTextJson: boolean;
  /** Emit `?` on optional and nullable members. */
  nullableEnabled: boolean;
}

export const CSHARP_DEFAULTS: CSharpOptions = {
  style: "class",
  namespaceName: "Generated",
  systemTextJson: true,
  nullableEnabled: true,
};

const VALUE_TYPES = new Set(["int", "long", "double", "bool"]);

function render(type: TypeNode): string {
  switch (type.kind) {
    case "object":
      return type.name ?? "Dictionary<string, object>";
    case "array":
      return `List<${render(type.items ?? { kind: "any" })}>`;
    case "union":
      // No discriminated union in C# without a hand-written converter, so the
      // honest output is object rather than a type that fails to deserialize.
      return "object";
    case "integer":
      return type.wide ? "long" : "int";
    case "number":
      return "double";
    case "boolean":
      return "bool";
    case "string":
      return "string";
    default:
      return "object";
  }
}

function memberType(field: Field, options: CSharpOptions): string {
  const base = render(field.type);
  if (!options.nullableEnabled) return base;
  // A field whose every sample was null is unknown *and* nullable.
  const wantsNullable = field.optional || field.type.nullable || field.type.kind === "null";
  if (!wantsNullable) return base;
  // A value type takes Nullable<T>; a reference type takes the annotation.
  // Both are written `T?`, which is one of the tidier things about the language.
  return base.endsWith("?") ? base : `${base}?`;
}

export function emitCSharp(types: NamedType[], options: CSharpOptions): string {
  if (types.length === 0) return "// Nothing to generate: the sample has no object shapes.\n";

  const attribute = options.systemTextJson ? "JsonPropertyName" : "JsonProperty";
  const usings = [
    "using System.Collections.Generic;",
    options.systemTextJson
      ? "using System.Text.Json.Serialization;"
      : "using Newtonsoft.Json;",
  ];

  const indent = options.namespaceName ? "    " : "";
  const blocks = types.map((named) => {
    const lines: string[] = [];
    lines.push(
      `${indent}public ${options.style === "record" ? "record" : "class"} ${named.name}`,
      `${indent}{`
    );

    for (const field of named.type.fields ?? []) {
      // Properties are PascalCase and every C# keyword is lowercase, so this is
      // a guard rather than a routine rename — `ref` becomes `Ref`, not `Ref_`.
      const name = safeName(pascalCase(field.key), CSHARP_KEYWORDS);
      const type = memberType(field, options);
      if (field.type.kind === "null") {
        lines.push(`${indent}    // Only null in the sample; the real type is unknown.`);
      }
      lines.push(`${indent}    [${attribute}("${field.key}")]`);

      // A non-nullable reference member needs an initialiser or the compiler
      // warns CS8618 on every single one. `= null!;` is the conventional
      // generated-code answer: it tells the compiler the deserializer fills it.
      const needsBang =
        options.nullableEnabled && !type.endsWith("?") && !VALUE_TYPES.has(type);
      lines.push(
        `${indent}    public ${type} ${name} { get; set; }${needsBang ? " = null!;" : ""}`
      );
      lines.push("");
    }

    if (lines[lines.length - 1] === "") lines.pop();
    lines.push(`${indent}}`);
    return lines.join("\n");
  });

  const body = blocks.join("\n\n");
  const nullableDirective = options.nullableEnabled ? "#nullable enable\n\n" : "";

  if (!options.namespaceName) {
    return `${usings.join("\n")}\n\n${nullableDirective}${body}\n`;
  }
  return `${usings.join("\n")}\n\n${nullableDirective}namespace ${options.namespaceName}\n{\n${body}\n}\n`;
}

/** The C# type expression for the document root. */
export function cSharpRootExpression(root: TypeNode): string {
  return render(root);
}
