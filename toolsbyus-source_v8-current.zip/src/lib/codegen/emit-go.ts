import { GO_KEYWORDS, pascalCase, safeName, type Field, type NamedType, type TypeNode } from "./model";

/**
 * Go emitter.
 *
 * Two decisions carry most of the value here, and both are about what
 * `encoding/json` does at runtime rather than about syntax.
 *
 * First, exported field names. Go only marshals exported fields, so a field
 * named `id` is silently dropped from the output of `json.Marshal`. Every field
 * is therefore capitalised and given an explicit struct tag carrying the
 * original key.
 *
 * Second, pointers. A non-pointer `string` cannot hold JSON null and cannot
 * tell an absent key from an empty one — both arrive as `""`. Optional and
 * nullable fields become pointers, which is the only way to keep that
 * distinction in Go.
 */

export interface GoOptions {
  /** Package clause at the top of the file. */
  packageName: string;
  /** Use a pointer for optional and nullable fields, so absent != zero value. */
  pointerForOptional: boolean;
  /** Add `,omitempty` to optional fields, so they vanish when marshalled back. */
  omitEmpty: boolean;
  /** Emit `json.Number` instead of `float64` for non-integers. */
  useJSONNumber: boolean;
}

export const GO_DEFAULTS: GoOptions = {
  packageName: "main",
  pointerForOptional: true,
  omitEmpty: true,
  useJSONNumber: false,
};

/** Initialisms Go's own style guide wants fully capitalised. */
const INITIALISMS = new Set([
  "ACL", "API", "ASCII", "CPU", "CSS", "DNS", "EOF", "GUID", "HTML", "HTTP", "HTTPS", "ID",
  "IP", "JSON", "LHS", "QPS", "RAM", "RHS", "RPC", "SLA", "SMTP", "SQL", "SSH", "TCP", "TLS",
  "TTL", "UDP", "UI", "UID", "UUID", "URI", "URL", "UTF8", "VM", "XML", "XMPP", "XSRF", "XSS",
]);

export function goName(input: string): string {
  const pascal = pascalCase(input);
  // Re-capitalise initialisms: UserId -> UserID, ApiUrl -> APIURL.
  return pascal.replace(/[A-Z][a-z0-9]*/g, (word) => {
    const upper = word.toUpperCase();
    return INITIALISMS.has(upper) ? upper : word;
  });
}

function render(type: TypeNode, options: GoOptions): string {
  switch (type.kind) {
    case "object":
      return type.name ? `*${type.name}` : "map[string]interface{}";
    case "array":
      return `[]${render(type.items ?? { kind: "any" }, options).replace(/^\*/, "")}`;
    case "union":
      // Go has no sum type. `interface{}` is the honest answer; a generated
      // union type would be a lie that fails to unmarshal.
      return "interface{}";
    case "integer":
      return type.wide ? "int64" : "int";
    case "number":
      return options.useJSONNumber ? "json.Number" : "float64";
    case "boolean":
      return "bool";
    case "string":
      return "string";
    default:
      return "interface{}";
  }
}

function fieldType(field: Field, options: GoOptions): string {
  const base = render(field.type, options);
  // Slices, maps and interfaces are already nilable; pointing at them adds
  // nothing but an extra dereference.
  const alreadyNilable =
    base.startsWith("[]") || base.startsWith("map[") || base.startsWith("*") || base === "interface{}";
  const wantsPointer = options.pointerForOptional && (field.optional || field.type.nullable);
  return wantsPointer && !alreadyNilable ? `*${base}` : base;
}

export function emitGo(types: NamedType[], options: GoOptions): string {
  if (types.length === 0) return `package ${options.packageName}\n\n// No object shapes in the sample.\n`;

  const needsJSONImport =
    options.useJSONNumber &&
    types.some((named) =>
      (named.type.fields ?? []).some((f) => render(f.type, options).includes("json.Number"))
    );

  const blocks = types.map((named) => {
    const rows = (named.type.fields ?? []).map((field) => {
      // Exported names are PascalCase and every Go keyword is lowercase, so
      // this only ever fires on a name that arrived already lowercase.
      const name = safeName(goName(field.key), GO_KEYWORDS);
      const tagParts = [field.key];
      if (options.omitEmpty && (field.optional || field.type.nullable)) tagParts.push("omitempty");
      const note: string[] = [];
      if (field.type.kind === "null") note.push("only null in the sample");
      if (field.type.format) note.push(field.type.format);
      if (field.optional) note.push("optional");
      return {
        name,
        type: fieldType(field, options),
        tag: `\`json:"${tagParts.join(",")}"\``,
        note: note.length ? `// ${note.join(", ")}` : "",
      };
    });

    // gofmt aligns struct field columns — names, types, tags and trailing
    // comments — so the generated code has to be aligned already or the first
    // `gofmt` in CI produces a diff on a file nobody edited.
    const nameWidth = Math.max(0, ...rows.map((r) => r.name.length));
    const typeWidth = Math.max(0, ...rows.map((r) => r.type.length));
    const tagWidth = rows.some((r) => r.note) ? Math.max(0, ...rows.map((r) => r.tag.length)) : 0;

    const lines = [`type ${named.name} struct {`];
    for (const row of rows) {
      const tag = row.note ? `${row.tag.padEnd(tagWidth)} ${row.note}` : row.tag;
      lines.push(`\t${row.name.padEnd(nameWidth)} ${row.type.padEnd(typeWidth)} ${tag}`);
    }
    lines.push("}");
    return lines.join("\n");
  });

  const header = needsJSONImport
    ? `package ${options.packageName}\n\nimport "encoding/json"\n`
    : `package ${options.packageName}\n`;

  return `${header}\n${blocks.join("\n\n")}\n`;
}

/** The Go type expression for the document root. */
export function goRootExpression(root: TypeNode, options: GoOptions): string {
  return render(root, options).replace(/^\*/, "");
}
