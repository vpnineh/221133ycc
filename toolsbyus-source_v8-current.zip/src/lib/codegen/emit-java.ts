import {
  JAVA_KEYWORDS,
  camelCase,
  pascalCase,
  safeName,
  type Field,
  type NamedType,
  type TypeNode,
} from "./model";

/**
 * Java emitter.
 *
 * Java's boxing rules make the optional-field question concrete rather than
 * stylistic: `int` cannot be null, so a field that JSON sometimes omits and is
 * typed `int` silently deserializes to 0. A missing count and a count of zero
 * then look identical, which is a real class of bug. Optional and nullable
 * numeric fields are therefore boxed (`Integer`, `Long`, `Double`, `Boolean`).
 *
 * `record` is the better default on Java 17+ — immutable, no boilerplate, and
 * Jackson has supported it since 2.12 — but plenty of code still targets 8, so
 * the POJO with getters and setters stays available.
 */

export type JavaStyle = "record" | "pojo";

export interface JavaOptions {
  style: JavaStyle;
  /** Package declaration; empty for none. */
  packageName: string;
  /** Add Jackson `@JsonProperty` annotations. */
  jackson: boolean;
  /** Use `Optional<T>` for optional reference members in POJO getters. */
  boxPrimitives: boolean;
}

export const JAVA_DEFAULTS: JavaOptions = {
  style: "record",
  packageName: "",
  jackson: true,
  boxPrimitives: true,
};

const BOXED: Record<string, string> = {
  int: "Integer",
  long: "Long",
  double: "Double",
  boolean: "Boolean",
};

function render(type: TypeNode): string {
  switch (type.kind) {
    case "object":
      return type.name ?? "Map<String, Object>";
    case "array":
      // Generics cannot hold primitives, so a list element is always boxed.
      return `List<${box(render(type.items ?? { kind: "any" }))}>`;
    case "union":
      return "Object";
    case "integer":
      return type.wide ? "long" : "int";
    case "number":
      return "double";
    case "boolean":
      return "boolean";
    case "string":
      return "String";
    default:
      return "Object";
  }
}

function box(type: string): string {
  return BOXED[type] ?? type;
}

function memberType(field: Field, options: JavaOptions): string {
  const base = render(field.type);
  const wantsNull = field.optional || field.type.nullable || field.type.kind === "null";
  // A record component is always a field, so this applies to both styles: a
  // primitive that can be absent must be boxed or absence becomes zero.
  return wantsNull && options.boxPrimitives ? box(base) : base;
}

function needsList(types: NamedType[]): boolean {
  return types.some((named) =>
    (named.type.fields ?? []).some((field) => render(field.type).startsWith("List<"))
  );
}

function needsMap(types: NamedType[]): boolean {
  return types.some((named) =>
    (named.type.fields ?? []).some((field) => render(field.type).includes("Map<"))
  );
}

export function emitJava(types: NamedType[], options: JavaOptions): string {
  if (types.length === 0) return "// Nothing to generate: the sample has no object shapes.\n";

  const imports: string[] = [];
  if (needsList(types)) imports.push("import java.util.List;");
  if (needsMap(types)) imports.push("import java.util.Map;");
  if (options.jackson) imports.push("import com.fasterxml.jackson.annotation.JsonProperty;");

  const blocks = types.map((named) =>
    options.style === "record" ? emitRecord(named, options) : emitPojo(named, options)
  );

  // Java allows exactly one public top-level type per source file, so a
  // multi-type document does not compile as a single paste. Saying so is more
  // useful than silently emitting a file that javac rejects.
  const note =
    types.length > 1
      ? `// ${types.length} types. Java allows one public type per file, so save each\n// as <TypeName>.java, or nest them inside one outer class.\n`
      : "";

  const head = [
    options.packageName ? `package ${options.packageName};\n` : "",
    imports.length ? `${imports.join("\n")}\n` : "",
  ]
    .filter(Boolean)
    .join("\n");

  return `${note}${note && head ? "\n" : ""}${head}${head ? "\n" : ""}${blocks.join("\n\n")}\n`;
}

function emitRecord(named: NamedType, options: JavaOptions): string {
  const fields = named.type.fields ?? [];
  if (fields.length === 0) return `public record ${named.name}() {}`;

  const components = fields.map((field) => {
    const name = safeName(camelCase(field.key), JAVA_KEYWORDS);
    const annotation = options.jackson ? `@JsonProperty("${field.key}") ` : "";
    return `    ${annotation}${memberType(field, options)} ${name}`;
  });

  // One component per line: a record with fifteen components on one line is
  // technically valid and unreadable.
  return `public record ${named.name}(\n${components.join(",\n")}\n) {}`;
}

function emitPojo(named: NamedType, options: JavaOptions): string {
  const fields = named.type.fields ?? [];
  const lines = [`public class ${named.name} {`];

  for (const field of fields) {
    const name = safeName(camelCase(field.key), JAVA_KEYWORDS);
    if (options.jackson) lines.push(`    @JsonProperty("${field.key}")`);
    lines.push(`    private ${memberType(field, options)} ${name};`);
  }

  for (const field of fields) {
    const name = safeName(camelCase(field.key), JAVA_KEYWORDS);
    const type = memberType(field, options);
    const accessor = pascalCase(field.key);
    lines.push(
      "",
      `    public ${type} get${accessor}() {`,
      `        return ${name};`,
      "    }",
      "",
      `    public void set${accessor}(${type} ${name}) {`,
      `        this.${name} = ${name};`,
      "    }"
    );
  }

  lines.push("}");
  return lines.join("\n");
}

/** The Java type expression for the document root. */
export function javaRootExpression(root: TypeNode): string {
  return render(root);
}
