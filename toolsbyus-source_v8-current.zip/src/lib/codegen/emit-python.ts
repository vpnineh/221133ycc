import { PYTHON_KEYWORDS, safeName, snakeCase, type NamedType, type TypeNode } from "./model";

/**
 * Python emitter, with three shapes that answer different questions.
 *
 * `dataclass` describes the data with no dependencies and no validation.
 * `TypedDict` describes the dict you already have from `json.loads`, so nothing
 * has to be constructed at all. `pydantic` validates at the boundary, which is
 * what an API client actually wants.
 *
 * The ordering rule they share: a class must be defined before it is used, and
 * the model emits children first, so the declaration order is already correct.
 */

export type PythonStyle = "dataclass" | "typeddict" | "pydantic";

export interface PythonOptions {
  style: PythonStyle;
  /** Rename keys to snake_case, keeping the original as a field alias. */
  snakeCaseKeys: boolean;
  /** `str | None` (3.10+) rather than `Optional[str]`. */
  modernOptional: boolean;
}

export const PYTHON_DEFAULTS: PythonOptions = {
  style: "dataclass",
  snakeCaseKeys: true,
  modernOptional: false,
};

const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;

interface RenderContext {
  options: PythonOptions;
  imports: Set<string>;
}

function render(type: TypeNode, context: RenderContext): string {
  const base = ((): string => {
    switch (type.kind) {
      case "object":
        // Quoted, because the class may be referenced before Python has
        // finished defining it in a self-referential document.
        return type.name ? `"${type.name}"` : dict(context);
      case "array":
        context.imports.add("List");
        return `List[${render(type.items ?? { kind: "any" }, context)}]`;
      case "union": {
        const members = (type.members ?? []).map((m) => render(m, context));
        if (members.length === 0) return any(context);
        if (context.options.modernOptional) return members.join(" | ");
        context.imports.add("Union");
        return `Union[${members.join(", ")}]`;
      }
      case "integer":
        return "int";
      case "number":
        return "float";
      case "boolean":
        return "bool";
      case "string":
        return "str";
      case "null":
        // Only nulls were seen, so the type is unknown and nullable.
        return context.options.modernOptional ? `${any(context)} | None` : optional(any(context), context);
      default:
        return any(context);
    }
  })();

  if (!type.nullable || type.kind === "null") return base;
  return optional(base, context);
}

function optional(base: string, context: RenderContext): string {
  if (context.options.modernOptional) return `${base} | None`;
  context.imports.add("Optional");
  return `Optional[${base}]`;
}

function any(context: RenderContext): string {
  context.imports.add("Any");
  return "Any";
}

function dict(context: RenderContext): string {
  context.imports.add("Dict");
  context.imports.add("Any");
  return "Dict[str, Any]";
}

export function emitPython(types: NamedType[], options: PythonOptions): string {
  if (types.length === 0) return "# Nothing to generate: the sample has no object shapes.\n";

  const context: RenderContext = { options, imports: new Set() };
  const blocks: string[] = [];

  for (const named of types) {
    const fields = named.type.fields ?? [];
    const lines: string[] = [];

    if (options.style === "dataclass") lines.push("@dataclass");
    const base =
      options.style === "typeddict" ? "(TypedDict)" : options.style === "pydantic" ? "(BaseModel)" : "";
    lines.push(`class ${named.name}${base}:`);

    if (fields.length === 0) {
      lines.push("    pass");
      blocks.push(lines.join("\n"));
      continue;
    }

    // A dataclass field with a default cannot precede one without, so every
    // required field is emitted first. Getting this wrong produces a class that
    // raises TypeError at import time.
    const ordered =
      options.style === "dataclass"
        ? [...fields].sort((a, b) => Number(a.optional) - Number(b.optional))
        : fields;

    for (const field of ordered) {
      const renamed = options.snakeCaseKeys ? snakeCase(field.key) : field.key;
      const identifier = IDENTIFIER.test(renamed) ? renamed : snakeCase(field.key);
      const name = safeName(identifier, PYTHON_KEYWORDS);
      const annotation = render(field.type, context);
      const aliasNeeded = name !== field.key;

      if (options.style === "pydantic" && (aliasNeeded || field.optional)) {
        context.imports.add("Field");
        const args: string[] = [field.optional ? "None" : "..."];
        if (aliasNeeded) args.push(`alias="${field.key}"`);
        const optionalAnnotation = field.optional && !annotation.includes("None")
          ? wrapOptional(annotation, context)
          : annotation;
        lines.push(`    ${name}: ${optionalAnnotation} = Field(${args.join(", ")})`);
      } else if (options.style === "typeddict" && field.optional) {
        context.imports.add("NotRequired");
        lines.push(`    ${name}: NotRequired[${annotation}]${comment(field.key, name)}`);
      } else if (options.style === "dataclass" && field.optional) {
        lines.push(
          `    ${name}: ${wrapOptional(annotation, context)} = None${comment(field.key, name)}`
        );
      } else {
        lines.push(`    ${name}: ${annotation}${comment(field.key, name)}`);
      }
    }

    blocks.push(lines.join("\n"));
  }

  return `${header(context)}\n\n${blocks.join("\n\n\n")}\n`;
}

function wrapOptional(annotation: string, context: RenderContext): string {
  if (context.options.modernOptional) return `${annotation} | None`;
  context.imports.add("Optional");
  return `Optional[${annotation}]`;
}

function comment(original: string, renamed: string): string {
  return original === renamed ? "" : `  # JSON key: ${original}`;
}

function header(context: RenderContext): string {
  const lines: string[] = [];
  const typing = ["Any", "Dict", "List", "Optional", "Union"].filter((name) =>
    context.imports.has(name)
  );

  if (context.options.style === "dataclass") lines.push("from dataclasses import dataclass");
  if (context.options.style === "typeddict") {
    const extras = context.imports.has("NotRequired")
      ? "NotRequired, TypedDict"
      : "TypedDict";
    // NotRequired landed in typing in 3.11; typing_extensions is the portable
    // import and works on every version that has TypedDict at all.
    lines.push(`from typing_extensions import ${extras}`);
  }
  if (context.options.style === "pydantic") {
    const extras = context.imports.has("Field") ? "BaseModel, Field" : "BaseModel";
    lines.push(`from pydantic import ${extras}`);
  }
  if (typing.length > 0) lines.push(`from typing import ${typing.join(", ")}`);

  return lines.join("\n");
}

/** The Python annotation for the document root. */
export function pythonRootExpression(root: TypeNode, options: PythonOptions): string {
  return render(root, { options, imports: new Set() }).replace(/"/g, "");
}
