import { camelCase, type NamedType, type TypeNode } from "./model";

/**
 * TypeScript emitter.
 *
 * TypeScript is the one target where the generated code can describe the JSON
 * exactly, because its type system has unions, optional members and structural
 * typing. That makes it the reference output: if a document produces something
 * awkward here, the model is wrong, not the emitter.
 */

export interface TypeScriptOptions {
  /** `interface X {}` rather than `type X = {}`. */
  useInterfaces: boolean;
  /** Mark every member `readonly`. */
  readonly: boolean;
  /** `export` each declaration. */
  exported: boolean;
  /** Rename snake_case keys to camelCase, keeping the original in a comment. */
  camelCaseKeys: boolean;
}

export const TYPESCRIPT_DEFAULTS: TypeScriptOptions = {
  useInterfaces: true,
  readonly: false,
  exported: true,
  camelCaseKeys: false,
};

/** A key that is not a valid identifier has to be quoted. */
const IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

function render(type: TypeNode): string {
  const base = ((): string => {
    switch (type.kind) {
      case "object":
        // A named object is referenced by name; an anonymous one is inlined,
        // which only happens for an empty object.
        return type.name ?? "Record<string, unknown>";
      case "array":
        return `${wrap(type.items ?? { kind: "any" })}[]`;
      case "union":
        return (type.members ?? []).map(render).join(" | ") || "unknown";
      case "integer":
      case "number":
        return "number";
      case "boolean":
        return "boolean";
      case "string":
        return "string";
      case "null":
        // Every sample at this position was null, so the real type is unknown
        // and nullable. `null` alone would be accurate about the sample and
        // useless about the data.
        return "unknown";
      default:
        return "unknown";
    }
  })();
  return type.nullable && type.kind !== "null" ? `${base} | null` : base;
}

/** Parenthesise a union before `[]`, or `A | B[]` means something else. */
function wrap(type: TypeNode): string {
  const rendered = render(type);
  return rendered.includes(" | ") ? `(${rendered})` : rendered;
}

export function emitTypeScript(types: NamedType[], options: TypeScriptOptions): string {
  if (types.length === 0) return "// Nothing to generate: the sample has no object shapes.\n";

  const keyword = options.useInterfaces ? "interface" : "type";
  const blocks = types.map((named) => {
    const lines: string[] = [];
    const head = `${options.exported ? "export " : ""}${keyword} ${named.name}${
      options.useInterfaces ? " {" : " = {"
    }`;
    lines.push(head);

    for (const field of named.type.fields ?? []) {
      const original = field.key;
      // TypeScript allows any identifier as a member name, keywords included,
      // so nothing here needs escaping beyond quoting the invalid ones.
      const renamed = options.camelCaseKeys ? camelCase(original) : original;
      const key = IDENTIFIER.test(renamed) ? renamed : JSON.stringify(renamed);
      const note: string[] = [];
      if (renamed !== original) note.push(`JSON key: ${original}`);
      if (field.type.kind === "null") note.push("only null in the sample");
      if (field.type.format) note.push(field.type.format);
      if (field.type.kind === "integer" && field.type.wide) note.push("64-bit integer");

      lines.push(
        `  ${options.readonly ? "readonly " : ""}${key}${field.optional ? "?" : ""}: ${render(
          field.type
        )};${note.length ? ` // ${note.join(", ")}` : ""}`
      );
    }

    lines.push(options.useInterfaces ? "}" : "};");
    return lines.join("\n");
  });

  return `${blocks.join("\n\n")}\n`;
}

/** The type expression for the document root, which may be an array of a named type. */
export function typeScriptRootExpression(root: TypeNode): string {
  return render(root);
}
