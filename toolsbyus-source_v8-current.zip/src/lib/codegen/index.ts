import type { JsonValue } from "../json/types";
import { extractNamedTypes, inferType, type NamedType, type TypeNode } from "./model";
import { emitTypeScript, typeScriptRootExpression, type TypeScriptOptions } from "./emit-typescript";
import { emitGo, goRootExpression, type GoOptions } from "./emit-go";
import { emitPython, pythonRootExpression, type PythonOptions } from "./emit-python";
import { emitCSharp, cSharpRootExpression, type CSharpOptions } from "./emit-csharp";
import { emitJava, javaRootExpression, type JavaOptions } from "./emit-java";

export * from "./model";
export * from "./emit-typescript";
export * from "./emit-go";
export * from "./emit-python";
export * from "./emit-csharp";
export * from "./emit-java";

export type Target = "typescript" | "go" | "python" | "csharp" | "java";

export interface GenerateResult {
  code: string;
  /** Every named type in declaration order, for a summary line. */
  names: string[];
  /** The type expression for the document root, which may be `User[]`. */
  rootExpression: string;
  /** The inferred model, exposed so a page can show what was detected. */
  root: TypeNode;
  types: NamedType[];
}

export type TargetOptions =
  | { target: "typescript"; options: TypeScriptOptions }
  | { target: "go"; options: GoOptions }
  | { target: "python"; options: PythonOptions }
  | { target: "csharp"; options: CSharpOptions }
  | { target: "java"; options: JavaOptions };

/**
 * Infers a type model from a sample document and renders it for one target.
 *
 * The model is built once and shared, which is what makes the five generators
 * agree: if `b` is optional in the TypeScript output it is a pointer in Go, a
 * `NotRequired` in a TypedDict and a boxed `Integer` in Java, because all five
 * are reading the same answer rather than each re-deriving it.
 */
export function generate(value: JsonValue, rootName: string, spec: TargetOptions): GenerateResult {
  const root = inferType(value);
  // The named types come from the object shapes. An array root is named in the
  // singular, so `[{...}]` under the root name `User` generates `User`, not
  // `Users` holding one user.
  const types = extractNamedTypes(root, rootName);

  const code = ((): string => {
    switch (spec.target) {
      case "typescript":
        return emitTypeScript(types, spec.options);
      case "go":
        return emitGo(types, spec.options);
      case "python":
        return emitPython(types, spec.options);
      case "csharp":
        return emitCSharp(types, spec.options);
      case "java":
        return emitJava(types, spec.options);
    }
  })();

  const rootExpression = ((): string => {
    switch (spec.target) {
      case "typescript":
        return typeScriptRootExpression(root);
      case "go":
        return goRootExpression(root, spec.options);
      case "python":
        return pythonRootExpression(root, spec.options);
      case "csharp":
        return cSharpRootExpression(root);
      case "java":
        return javaRootExpression(root);
    }
  })();

  return { code, names: types.map((t) => t.name), rootExpression, root, types };
}
