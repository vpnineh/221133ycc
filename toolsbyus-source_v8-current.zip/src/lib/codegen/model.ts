import type { JsonValue } from "../json/types";
import { isForbiddenKey } from "../safe-object";

/**
 * An intermediate type model, built once from a JSON sample and rendered by one
 * emitter per target language.
 *
 * The alternative — a separate walker per language — means five copies of the
 * genuinely hard parts: deciding when two object shapes are the same type,
 * working out which fields are optional, and merging the element types of a
 * heterogeneous array. Those decisions are language-independent, so they are
 * made here once and the emitters only choose syntax.
 */

export type TypeKind =
  | "string"
  | "number"
  | "integer"
  | "boolean"
  | "null"
  | "any"
  | "array"
  | "object"
  | "union";

export interface TypeNode {
  kind: TypeKind;
  /** Element type, for arrays. */
  items?: TypeNode;
  /** Fields, for objects, in first-seen order. */
  fields?: Field[];
  /** Members, for unions. */
  members?: TypeNode[];
  /** Assigned when an object shape is promoted to a named type. */
  name?: string;
  /**
   * True when an integer was seen that a 32-bit type cannot hold, so an emitter
   * can pick int64 rather than int. Silently narrowing an ID is the kind of bug
   * that only appears in production.
   */
  wide?: boolean;
  /** A detected string format — uuid, date-time, email — for a comment. */
  format?: string;
  /**
   * An explicit null was seen at this position alongside a real value. Every
   * target spells this differently — `| null`, `*string`, `Optional[str]`,
   * `string?` — so it is recorded here and rendered by the emitter.
   */
  nullable?: boolean;
}

export interface Field {
  /** The key exactly as it appears in the JSON. */
  key: string;
  type: TypeNode;
  /** Absent from at least one sample of the same shape. */
  optional: boolean;
}

const INT32_MAX = 2_147_483_647;

/* -------------------------------------------------------------------------- */
/* Inference                                                                  */
/* -------------------------------------------------------------------------- */

function scalarOf(value: JsonValue): TypeNode {
  if (value === null) return { kind: "null" };
  switch (typeof value) {
    case "boolean":
      return { kind: "boolean" };
    case "number":
      return Number.isInteger(value)
        ? { kind: "integer", wide: Math.abs(value) > INT32_MAX }
        : { kind: "number" };
    default:
      return { kind: "string", format: detectFormat(value as string) };
  }
}

const FORMATS: Array<[string, RegExp]> = [
  ["uuid", /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/],
  ["date-time", /^\d{4}-\d{2}-\d{2}[Tt ]\d{2}:\d{2}:\d{2}(\.\d+)?([Zz]|[+-]\d{2}:\d{2})$/],
  ["date", /^\d{4}-\d{2}-\d{2}$/],
  ["email", /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/],
  ["uri", /^https?:\/\/[^\s]+$/],
];

export function detectFormat(value: string): string | undefined {
  for (const [name, pattern] of FORMATS) {
    if (pattern.test(value)) return name;
  }
  return undefined;
}

/**
 * Merges two inferred types into one that describes both samples.
 *
 * This is where a converter is judged. Given `[{"a":1},{"a":1,"b":2}]`, the
 * naive answer is to type the array from its first element and lose `b`
 * entirely. The correct answer is one type with `b` optional, and getting there
 * means merging field sets rather than picking one.
 */
export function merge(a: TypeNode, b: TypeNode): TypeNode {
  if (a.kind === "any") return b;
  if (b.kind === "any") return a;

  // null merges into everything as nullability rather than as a union member,
  // which is what every target language expects: `string | null`, not a union
  // type named StringOrNull.
  if (a.kind === "null") return b.kind === "null" ? a : { ...b, nullable: true };
  if (b.kind === "null") return { ...a, nullable: true };

  const nulls = a.nullable || b.nullable ? { nullable: true } : {};

  if (a.kind === "integer" && b.kind === "number") return { kind: "number", ...nulls };
  if (a.kind === "number" && b.kind === "integer") return { kind: "number", ...nulls };

  if (a.kind === "integer" && b.kind === "integer") {
    return { kind: "integer", wide: Boolean(a.wide || b.wide), ...nulls };
  }

  if (a.kind === "string" && b.kind === "string") {
    return {
      kind: "string",
      format: a.format === b.format ? a.format : undefined,
      ...nulls,
    };
  }

  if (a.kind === "array" && b.kind === "array") {
    return {
      kind: "array",
      items: a.items && b.items ? merge(a.items, b.items) : a.items ?? b.items,
      ...nulls,
    };
  }

  if (a.kind === "object" && b.kind === "object") {
    const fields: Field[] = [];
    const bByKey = new Map((b.fields ?? []).map((f) => [f.key, f]));

    for (const field of a.fields ?? []) {
      const other = bByKey.get(field.key);
      if (other) {
        fields.push({
          key: field.key,
          type: merge(field.type, other.type),
          optional: field.optional || other.optional,
        });
        bByKey.delete(field.key);
      } else {
        // Present in one sample and not the other, so optional.
        fields.push({ ...field, optional: true });
      }
    }
    for (const field of bByKey.values()) fields.push({ ...field, optional: true });

    return { kind: "object", fields, ...nulls };
  }

  if (a.kind === b.kind) return { ...a, ...nulls };

  // Genuinely different shapes. Flatten nested unions so a three-way mix does
  // not become a union of a union.
  const members = [...flatten(a), ...flatten(b)];
  const unique: TypeNode[] = [];
  for (const member of members) {
    if (!unique.some((existing) => signature(existing) === signature(member))) unique.push(member);
  }
  return unique.length === 1
    ? { ...unique[0], ...nulls }
    : { kind: "union", members: unique, ...nulls };
}

function flatten(type: TypeNode): TypeNode[] {
  return type.kind === "union" ? (type.members ?? []) : [type];
}

/** A structural fingerprint, used for deduplicating identical object shapes. */
export function signature(type: TypeNode): string {
  // Nullability is part of the shape: `{ name: string }` and
  // `{ name: string | null }` are different types in every target, so merging
  // them under one name would generate code that does not describe the data.
  const suffix = type.nullable ? "?" : "";
  switch (type.kind) {
    case "array":
      return `[${type.items ? signature(type.items) : "any"}]${suffix}`;
    case "object":
      return `{${(type.fields ?? [])
        .map((f) => `${f.key}${f.optional ? "?" : ""}:${signature(f.type)}`)
        .sort()
        .join(",")}}${suffix}`;
    case "union":
      return `(${(type.members ?? []).map(signature).sort().join("|")})${suffix}`;
    case "integer":
      return `${type.wide ? "int64" : "int"}${suffix}`;
    default:
      return `${type.kind}${suffix}`;
  }
}

/**
 * Builds the type model from a sample document.
 *
 * Recursive, unlike the parser and the tree flattener, and deliberately capped:
 * generated code for a 20,000-level document would be unusable anyway, so the
 * useful behaviour is a clear ceiling rather than a stack overflow.
 */
export function inferType(value: JsonValue, depth = 0): TypeNode {
  if (depth > 100) return { kind: "any" };

  if (Array.isArray(value)) {
    if (value.length === 0) return { kind: "array", items: { kind: "any" } };
    let items = inferType(value[0], depth + 1);
    for (let i = 1; i < value.length; i++) items = merge(items, inferType(value[i], depth + 1));
    return { kind: "array", items };
  }

  if (value !== null && typeof value === "object") {
    const fields: Field[] = [];
    for (const [key, child] of Object.entries(value)) {
      // A key named __proto__ or constructor would generate a member that
      // breaks the target language or, worse, silently works differently.
      if (isForbiddenKey(key)) continue;
      fields.push({ key, type: inferType(child, depth + 1), optional: false });
    }
    return { kind: "object", fields };
  }

  return scalarOf(value);
}

/* -------------------------------------------------------------------------- */
/* Naming                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Keyword sets, one per target rather than one union of all five.
 *
 * A union set looks tidier and is wrong in practice. `ref` is a C# keyword, so a
 * union set renames the extremely common JSON key `ref` in Go, Python and Java
 * as well, where it is perfectly legal. The same goes for `type`, `object`,
 * `map`, `range`, `from`, `in`, `is` and `not`. Mangling a name to protect a
 * language that is not the target is a worse failure than the one it prevents.
 *
 * Matching is exact, not case-insensitive: every keyword in all five languages
 * is lowercase, so a PascalCase Go or C# member can never collide with one.
 */
export const GO_KEYWORDS = new Set([
  "break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough", "for",
  "func", "go", "goto", "if", "import", "interface", "map", "package", "range", "return",
  "select", "struct", "switch", "type", "var",
]);

export const PYTHON_KEYWORDS = new Set([
  "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue",
  "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import",
  "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while",
  "with", "yield",
]);

export const CSHARP_KEYWORDS = new Set([
  "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class",
  "const", "continue", "decimal", "default", "delegate", "do", "double", "else", "enum", "event",
  "explicit", "extern", "false", "finally", "fixed", "float", "for", "foreach", "goto", "if",
  "implicit", "in", "int", "interface", "internal", "is", "lock", "long", "namespace", "new",
  "null", "object", "operator", "out", "override", "params", "private", "protected", "public",
  "readonly", "ref", "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static",
  "string", "struct", "switch", "this", "throw", "true", "try", "typeof", "uint", "ulong",
  "unchecked", "unsafe", "ushort", "using", "virtual", "void", "volatile", "while",
]);

export const JAVA_KEYWORDS = new Set([
  "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
  "continue", "default", "do", "double", "else", "enum", "extends", "false", "final", "finally",
  "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long",
  "native", "new", "null", "package", "private", "protected", "public", "return", "short",
  "static", "strictfp", "super", "switch", "synchronized", "this", "throw", "throws",
  "transient", "true", "try", "void", "volatile", "while",
]);

/**
 * TypeScript allows any identifier as an interface member, keywords included,
 * so only type names need protecting — and only from the built-in type names,
 * which are what an `interface String {}` would shadow.
 */
export const TYPESCRIPT_TYPE_NAMES = new Set([
  "any", "bigint", "boolean", "never", "null", "number", "object", "string", "symbol",
  "undefined", "unknown", "void",
]);

/**
 * Names a generated *type* must not take, in any target.
 *
 * These are PascalCase, so the lowercase keyword sets never catch them, and they
 * are the ones that do damage: `interface String {}` in TypeScript merges with
 * the global `String` rather than shadowing it, which breaks every string in the
 * file. A key called `string` or `object` is common enough to be worth guarding.
 */
const UNSAFE_TYPE_NAMES = new Set([
  "String", "Number", "Boolean", "Object", "Array", "Date", "Error", "Function", "Map", "Set",
  "Symbol", "Promise", "List", "Dict", "Type", "Integer", "Double", "Long", "Record",
]);

/** Appends `Type` to a generated type name that would shadow a built-in. */
export function safeTypeName(name: string): string {
  return UNSAFE_TYPE_NAMES.has(name) ? `${name}Type` : name;
}

/** Splits an identifier of any convention into its words. */
export function words(input: string): string[] {
  return input
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    // An all-caps run followed by a word starts a new word: HTTPServer -> HTTP Server.
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/[^a-zA-Z0-9]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

export function pascalCase(input: string): string {
  const parts = words(input).map((w) => w[0].toUpperCase() + w.slice(1).toLowerCase());
  const name = parts.join("") || "Value";
  return /^\d/.test(name) ? `N${name}` : name;
}

export function camelCase(input: string): string {
  const name = pascalCase(input);
  return name[0].toLowerCase() + name.slice(1);
}

export function snakeCase(input: string): string {
  const name = words(input).map((w) => w.toLowerCase()).join("_") || "value";
  return /^\d/.test(name) ? `n_${name}` : name;
}

/**
 * Appends an underscore to a name that collides with a keyword of the target.
 *
 * The set is a parameter because it has to be: see the note on the keyword sets
 * above. Matching is exact — `Ref` is not `ref`, and no language here has an
 * uppercase keyword.
 */
export function safeName(name: string, reserved: ReadonlySet<string>): string {
  return reserved.has(name) ? `${name}_` : name;
}

/** English-ish singular, so `users: [...]` generates a `User` type. */
export function singular(input: string): string {
  if (/(ss|us|is)$/i.test(input)) return input;
  if (/ies$/i.test(input)) return `${input.slice(0, -3)}y`;
  if (/(ch|sh|x|z|s)es$/i.test(input)) return input.slice(0, -2);
  if (/s$/i.test(input)) return input.slice(0, -1);
  return input;
}

/* -------------------------------------------------------------------------- */
/* Named type extraction                                                      */
/* -------------------------------------------------------------------------- */

export interface NamedType {
  name: string;
  type: TypeNode;
}

/**
 * Promotes every object shape to a named type, deduplicating by structure.
 *
 * Deduplication is what stops a document with fifty addresses generating fifty
 * identical `Address` types with numeric suffixes. Names come from the key that
 * held the object, singularised when it held an array, which produces the name
 * a person would have chosen.
 */
export function extractNamedTypes(root: TypeNode, rootName: string): NamedType[] {
  const bySignature = new Map<string, NamedType>();
  const used = new Set<string>();

  const claim = (preferred: string): string => {
    const base = safeTypeName(pascalCase(preferred));
    if (!used.has(base)) {
      used.add(base);
      return base;
    }
    let n = 2;
    while (used.has(`${base}${n}`)) n++;
    used.add(`${base}${n}`);
    return `${base}${n}`;
  };

  const walk = (type: TypeNode, preferred: string): void => {
    if (type.kind === "array") {
      if (type.items) walk(type.items, singular(preferred));
      return;
    }
    if (type.kind === "union") {
      for (const member of type.members ?? []) walk(member, preferred);
      return;
    }
    if (type.kind !== "object") return;

    // Children first, so a nested type is defined before the one that uses it.
    for (const fieldEntry of type.fields ?? []) walk(fieldEntry.type, fieldEntry.key);

    const key = signature(type);
    const existing = bySignature.get(key);
    if (existing) {
      type.name = existing.name;
      return;
    }
    const name = claim(preferred);
    type.name = name;
    bySignature.set(key, { name, type });
  };

  walk(root, rootName);

  // Root last in the map's insertion order becomes first in the output, which
  // is how a reader expects to encounter it.
  const all = [...bySignature.values()];
  const rootEntry = all.find((entry) => entry.type === root);
  if (!rootEntry) return all;
  return [rootEntry, ...all.filter((entry) => entry !== rootEntry)];
}
