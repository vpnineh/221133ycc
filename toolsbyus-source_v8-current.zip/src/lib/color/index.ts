/**
 * Colour, in the spaces that actually answer the questions people ask.
 *
 * sRGB and HSL are what CSS accepts, so everything has to round-trip through
 * them. But neither is perceptually uniform: in HSL, `hsl(60 100% 50%)` (yellow)
 * and `hsl(240 100% 50%)` (blue) claim the same 50% lightness while one is
 * blinding and the other is nearly black. Any tool that builds a tint ramp, mixes
 * two colours, or asks "is this readable" on top of HSL gets a wrong answer that
 * looks plausible.
 *
 * So the model here is: parse into sRGB, work in OKLab/OKLCh, print back to
 * whatever the caller asked for. OKLab (Björn Ottosson, 2020) is cheap, has no
 * hue-shift artefacts through blues, and is what CSS Color 4's own `oklch()`
 * uses — so a ramp built here is the same ramp a browser would build.
 *
 * Everything is pure and synchronous. No canvas, no DOM, no colour library:
 * the matrices are in the specs and the specs are stable.
 */

/* ------------------------------------------------------------------------- */
/* Types                                                                      */
/* ------------------------------------------------------------------------- */

/** sRGB, 0–255 per channel, plus straight (non-premultiplied) alpha 0–1. */
export interface Rgb {
  r: number;
  g: number;
  b: number;
  a: number;
}

/** CSS HSL. h 0–360, s and l 0–100. */
export interface Hsl {
  h: number;
  s: number;
  l: number;
  a: number;
}

/** HSV / HSB, as colour pickers use. h 0–360, s and v 0–100. */
export interface Hsv {
  h: number;
  s: number;
  v: number;
  a: number;
}

/** OKLCh. l 0–1, c 0–~0.4, h 0–360. */
export interface Oklch {
  l: number;
  c: number;
  h: number;
  a: number;
}

/** Naive CMYK, 0–100. See `toCmyk` for why "naive" is the honest word. */
export interface Cmyk {
  c: number;
  m: number;
  y: number;
  k: number;
}

export type ColorFormat = "hex" | "rgb" | "hsl" | "oklch" | "cmyk";

/* ------------------------------------------------------------------------- */
/* Small helpers                                                              */
/* ------------------------------------------------------------------------- */

const clamp = (value: number, min: number, max: number) =>
  value < min ? min : value > max ? max : value;

const round = (value: number, places = 0) => {
  const factor = 10 ** places;
  // `Math.round` on a value already at .5 in binary floating point rounds in a
  // direction that depends on the bits, so nudge deterministically first.
  return Math.round((value + Number.EPSILON) * factor) / factor;
};

/** Hue is modular: -30 and 330 are the same angle and both must print as 330. */
const normaliseHue = (hue: number) => ((hue % 360) + 360) % 360;

const hex2 = (value: number) =>
  clamp(Math.round(value), 0, 255).toString(16).padStart(2, "0");

/* ------------------------------------------------------------------------- */
/* Named colours                                                              */
/* ------------------------------------------------------------------------- */

/**
 * The CSS named colours, because people paste them.
 *
 * Stored as packed 24-bit integers rather than "#rrggbb" strings: the table is
 * 148 entries and this is roughly a third of the bytes, which matters because
 * it ships in the route chunk of every colour tool.
 */
const NAMED: Record<string, number> = {
  aliceblue: 0xf0f8ff, antiquewhite: 0xfaebd7, aqua: 0x00ffff, aquamarine: 0x7fffd4,
  azure: 0xf0ffff, beige: 0xf5f5dc, bisque: 0xffe4c4, black: 0x000000,
  blanchedalmond: 0xffebcd, blue: 0x0000ff, blueviolet: 0x8a2be2, brown: 0xa52a2a,
  burlywood: 0xdeb887, cadetblue: 0x5f9ea0, chartreuse: 0x7fff00, chocolate: 0xd2691e,
  coral: 0xff7f50, cornflowerblue: 0x6495ed, cornsilk: 0xfff8dc, crimson: 0xdc143c,
  cyan: 0x00ffff, darkblue: 0x00008b, darkcyan: 0x008b8b, darkgoldenrod: 0xb8860b,
  darkgray: 0xa9a9a9, darkgreen: 0x006400, darkgrey: 0xa9a9a9, darkkhaki: 0xbdb76b,
  darkmagenta: 0x8b008b, darkolivegreen: 0x556b2f, darkorange: 0xff8c00,
  darkorchid: 0x9932cc, darkred: 0x8b0000, darksalmon: 0xe9967a, darkseagreen: 0x8fbc8f,
  darkslateblue: 0x483d8b, darkslategray: 0x2f4f4f, darkslategrey: 0x2f4f4f,
  darkturquoise: 0x00ced1, darkviolet: 0x9400d3, deeppink: 0xff1493,
  deepskyblue: 0x00bfff, dimgray: 0x696969, dimgrey: 0x696969, dodgerblue: 0x1e90ff,
  firebrick: 0xb22222, floralwhite: 0xfffaf0, forestgreen: 0x228b22, fuchsia: 0xff00ff,
  gainsboro: 0xdcdcdc, ghostwhite: 0xf8f8ff, gold: 0xffd700, goldenrod: 0xdaa520,
  gray: 0x808080, green: 0x008000, greenyellow: 0xadff2f, grey: 0x808080,
  honeydew: 0xf0fff0, hotpink: 0xff69b4, indianred: 0xcd5c5c, indigo: 0x4b0082,
  ivory: 0xfffff0, khaki: 0xf0e68c, lavender: 0xe6e6fa, lavenderblush: 0xfff0f5,
  lawngreen: 0x7cfc00, lemonchiffon: 0xfffacd, lightblue: 0xadd8e6, lightcoral: 0xf08080,
  lightcyan: 0xe0ffff, lightgoldenrodyellow: 0xfafad2, lightgray: 0xd3d3d3,
  lightgreen: 0x90ee90, lightgrey: 0xd3d3d3, lightpink: 0xffb6c1, lightsalmon: 0xffa07a,
  lightseagreen: 0x20b2aa, lightskyblue: 0x87cefa, lightslategray: 0x778899,
  lightslategrey: 0x778899, lightsteelblue: 0xb0c4de, lightyellow: 0xffffe0,
  lime: 0x00ff00, limegreen: 0x32cd32, linen: 0xfaf0e6, magenta: 0xff00ff,
  maroon: 0x800000, mediumaquamarine: 0x66cdaa, mediumblue: 0x0000cd,
  mediumorchid: 0xba55d3, mediumpurple: 0x9370db, mediumseagreen: 0x3cb371,
  mediumslateblue: 0x7b68ee, mediumspringgreen: 0x00fa9a, mediumturquoise: 0x48d1cc,
  mediumvioletred: 0xc71585, midnightblue: 0x191970, mintcream: 0xf5fffa,
  mistyrose: 0xffe4e1, moccasin: 0xffe4b5, navajowhite: 0xffdead, navy: 0x000080,
  oldlace: 0xfdf5e6, olive: 0x808000, olivedrab: 0x6b8e23, orange: 0xffa500,
  orangered: 0xff4500, orchid: 0xda70d6, palegoldenrod: 0xeee8aa, palegreen: 0x98fb98,
  paleturquoise: 0xafeeee, palevioletred: 0xdb7093, papayawhip: 0xffefd5,
  peachpuff: 0xffdab9, peru: 0xcd853f, pink: 0xffc0cb, plum: 0xdda0dd,
  powderblue: 0xb0e0e6, purple: 0x800080, rebeccapurple: 0x663399, red: 0xff0000,
  rosybrown: 0xbc8f8f, royalblue: 0x4169e1, saddlebrown: 0x8b4513, salmon: 0xfa8072,
  sandybrown: 0xf4a460, seagreen: 0x2e8b57, seashell: 0xfff5ee, sienna: 0xa0522d,
  silver: 0xc0c0c0, skyblue: 0x87ceeb, slateblue: 0x6a5acd, slategray: 0x708090,
  slategrey: 0x708090, snow: 0xfffafa, springgreen: 0x00ff7f, steelblue: 0x4682b4,
  tan: 0xd2b48c, teal: 0x008080, thistle: 0xd8bfd8, tomato: 0xff6347,
  turquoise: 0x40e0d0, violet: 0xee82ee, wheat: 0xf5deb3, white: 0xffffff,
  whitesmoke: 0xf5f5f5, yellow: 0xffff00, yellowgreen: 0x9acd32,
};

export const NAMED_COLOR_COUNT = Object.keys(NAMED).length;

/**
 * The hue families people actually search by.
 *
 * Nobody looks up "navy" under "blue-ish colours with a hue of 240 degrees";
 * they look up "navy blue hex code". So the families are named the way a person
 * would say them, and assignment is by OKLCh hue with a neutral test in front —
 * chroma has to be checked first, because `gainsboro` has a hue angle and is
 * plainly a grey.
 */
export type ColorFamily =
  | "red" | "orange" | "yellow" | "green" | "cyan" | "blue" | "purple" | "pink"
  | "brown" | "grey" | "white" | "black";

export interface NamedColor {
  name: string;
  color: Rgb;
  family: ColorFamily;
}

/**
 * The boundaries are OKLCh hue angles, and they are not the ones you would
 * guess from HSL.
 *
 * Pure red sits at 29°, not 0°; yellow at 110°, not 60°; blue at 264°, not 240°.
 * An implementation carrying HSL's boundaries over to OKLCh files `red` under
 * orange and `gold` under yellow-green, which is exactly what the first draft of
 * this function did. Every number below was measured from the CSS keyword it is
 * named after rather than assumed.
 *
 * Families are a browsing aid, not a taxonomy. A handful of colours sit on a
 * boundary and could defensibly go either way — `maroon` as a dark red or a
 * brown, `teal` as cyan or green — and the filter exists so somebody can find
 * `navy` without scrolling, not to settle those arguments.
 */
function familyOf(color: Rgb): ColorFamily {
  const { l, c, h } = rgbToOklch(color);

  // Neutrals first: chroma has to be tested before hue, because a near-grey
  // still has a hue angle and `gainsboro` is plainly not a blue.
  if (l >= 0.95 && c < 0.1) return "white";
  if (l <= 0.2) return "black";
  if (c < 0.04) return "grey";

  // Brown is not a hue. It is a dark, muted orange-red, and without this test
  // `saddlebrown` comes back as orange.
  if (h >= 15 && h < 95 && l < 0.62 && c < 0.17) return "brown";

  if (h >= 340 || h < 15) return "pink";
  if (h < 40) return "red";
  if (h < 85) return "orange";
  if (h < 120) return "yellow";
  if (h < 175) return "green";
  if (h < 215) return "cyan";
  if (h < 285) return "blue";
  return "purple";
}

/** Display order for the families, roughly around the wheel then the neutrals. */
export const COLOR_FAMILIES: ColorFamily[] = [
  "red", "orange", "yellow", "green", "cyan", "blue",
  "purple", "pink", "brown", "grey", "white", "black",
];

/** Every CSS colour name, with its value and family. Sorted alphabetically. */
export const NAMED_COLORS: NamedColor[] = Object.entries(NAMED)
  .map(([name, packed]) => {
    const color: Rgb = {
      r: (packed >> 16) & 255,
      g: (packed >> 8) & 255,
      b: packed & 255,
      a: 1,
    };
    return { name, color, family: familyOf(color) };
  })
  .sort((a, b) => a.name.localeCompare(b.name));

/* ------------------------------------------------------------------------- */
/* Parsing                                                                    */
/* ------------------------------------------------------------------------- */

/** `50%` → 0.5, `0.5` → 0.5, `128` → 128. Returns null on nonsense. */
function number(token: string, percentOf: number): number | null {
  const text = token.trim();
  if (text === "") return null;
  if (text.endsWith("%")) {
    const value = Number(text.slice(0, -1));
    return Number.isFinite(value) ? (value / 100) * percentOf : null;
  }
  const value = Number(text);
  return Number.isFinite(value) ? value : null;
}

/**
 * Splits the inside of a functional notation into its arguments.
 *
 * Both the legacy comma form `rgb(1, 2, 3)` and the modern space form
 * `rgb(1 2 3 / 50%)` are in use, often in the same stylesheet, so both are
 * accepted. The slash separates alpha in the modern syntax.
 */
function args(body: string): { parts: string[]; alpha: string | null } {
  const [main, alpha = null] = body.split("/");
  const parts = main
    .trim()
    .split(/[\s,]+/)
    .filter(Boolean);
  return { parts, alpha: alpha === null ? null : alpha.trim() };
}

/**
 * Parses anything a person is likely to paste: hex in 3, 4, 6 or 8 digits,
 * `rgb()`, `hsl()`, `hsb()`/`hsv()`, `oklch()`, a CSS colour name, or a bare
 * hex with no `#`.
 *
 * Returns null rather than throwing or guessing. A colour tool that silently
 * turns a typo into black is worse than one that says it cannot read the input.
 */
export function parseColor(input: string): Rgb | null {
  const text = input.trim().toLowerCase();
  if (text === "") return null;

  if (text === "transparent") return { r: 0, g: 0, b: 0, a: 0 };

  const named = NAMED[text];
  if (named !== undefined) {
    return { r: (named >> 16) & 255, g: (named >> 8) & 255, b: named & 255, a: 1 };
  }

  // Hex, with or without the #. Bare hex is how values arrive from a
  // spreadsheet, a design token file, or somebody's clipboard.
  const hex = text.startsWith("#") ? text.slice(1) : text;
  if (/^[0-9a-f]+$/.test(hex)) {
    if (hex.length === 3 || hex.length === 4) {
      const [r, g, b, a = "f"] = hex.split("");
      return {
        r: parseInt(r + r, 16),
        g: parseInt(g + g, 16),
        b: parseInt(b + b, 16),
        a: parseInt(a + a, 16) / 255,
      };
    }
    if (hex.length === 6 || hex.length === 8) {
      return {
        r: parseInt(hex.slice(0, 2), 16),
        g: parseInt(hex.slice(2, 4), 16),
        b: parseInt(hex.slice(4, 6), 16),
        a: hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1,
      };
    }
    // 1, 2, 5 or 7 hex digits is a typo, not a colour.
    return null;
  }

  const call = /^([a-z]+)\((.*)\)$/.exec(text);
  if (!call) return null;
  const [, fn, body] = call;
  const { parts, alpha } = args(body);

  const readAlpha = (token: string | null | undefined): number => {
    if (token === null || token === undefined) return 1;
    const value = number(token, 1);
    return value === null ? 1 : clamp(value, 0, 1);
  };

  if (fn === "rgb" || fn === "rgba") {
    if (parts.length < 3) return null;
    const r = number(parts[0], 255);
    const g = number(parts[1], 255);
    const b = number(parts[2], 255);
    if (r === null || g === null || b === null) return null;
    return {
      r: clamp(r, 0, 255),
      g: clamp(g, 0, 255),
      b: clamp(b, 0, 255),
      a: readAlpha(alpha ?? parts[3]),
    };
  }

  if (fn === "hsl" || fn === "hsla") {
    if (parts.length < 3) return null;
    const h = number(parts[0].replace(/deg$/, ""), 360);
    const s = number(parts[1], 100);
    const l = number(parts[2], 100);
    if (h === null || s === null || l === null) return null;
    return hslToRgb({
      h: normaliseHue(h),
      s: clamp(s, 0, 100),
      l: clamp(l, 0, 100),
      a: readAlpha(alpha ?? parts[3]),
    });
  }

  if (fn === "hsv" || fn === "hsb") {
    if (parts.length < 3) return null;
    const h = number(parts[0].replace(/deg$/, ""), 360);
    const s = number(parts[1], 100);
    const v = number(parts[2], 100);
    if (h === null || s === null || v === null) return null;
    return hsvToRgb({
      h: normaliseHue(h),
      s: clamp(s, 0, 100),
      v: clamp(v, 0, 100),
      a: readAlpha(alpha ?? parts[3]),
    });
  }

  if (fn === "oklch") {
    if (parts.length < 3) return null;
    const l = number(parts[0], 1);
    const c = number(parts[1], 0.4);
    const h = number(parts[2].replace(/deg$/, ""), 360);
    if (l === null || c === null || h === null) return null;
    return oklchToRgb({
      l: clamp(l, 0, 1),
      c: Math.max(0, c),
      h: normaliseHue(h),
      a: readAlpha(alpha ?? parts[3]),
    });
  }

  return null;
}

/* ------------------------------------------------------------------------- */
/* sRGB ↔ HSL ↔ HSV                                                           */
/* ------------------------------------------------------------------------- */

export function rgbToHsl({ r, g, b, a }: Rgb): Hsl {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const delta = max - min;
  const l = (max + min) / 2;

  let h = 0;
  let s = 0;
  if (delta !== 0) {
    s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
    if (max === rn) h = ((gn - bn) / delta) % 6;
    else if (max === gn) h = (bn - rn) / delta + 2;
    else h = (rn - gn) / delta + 4;
    h *= 60;
  }
  return { h: normaliseHue(h), s: s * 100, l: l * 100, a };
}

export function hslToRgb({ h, s, l, a }: Hsl): Rgb {
  const hn = normaliseHue(h) / 360;
  const sn = s / 100;
  const ln = l / 100;

  if (sn === 0) {
    const value = ln * 255;
    return { r: value, g: value, b: value, a };
  }

  const q = ln < 0.5 ? ln * (1 + sn) : ln + sn - ln * sn;
  const p = 2 * ln - q;
  const channel = (t: number) => {
    let tn = t;
    if (tn < 0) tn += 1;
    if (tn > 1) tn -= 1;
    if (tn < 1 / 6) return p + (q - p) * 6 * tn;
    if (tn < 1 / 2) return q;
    if (tn < 2 / 3) return p + (q - p) * (2 / 3 - tn) * 6;
    return p;
  };

  return {
    r: channel(hn + 1 / 3) * 255,
    g: channel(hn) * 255,
    b: channel(hn - 1 / 3) * 255,
    a,
  };
}

export function rgbToHsv({ r, g, b, a }: Rgb): Hsv {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const delta = max - min;

  let h = 0;
  if (delta !== 0) {
    if (max === rn) h = ((gn - bn) / delta) % 6;
    else if (max === gn) h = (bn - rn) / delta + 2;
    else h = (rn - gn) / delta + 4;
    h *= 60;
  }
  return {
    h: normaliseHue(h),
    s: max === 0 ? 0 : (delta / max) * 100,
    v: max * 100,
    a,
  };
}

export function hsvToRgb({ h, s, v, a }: Hsv): Rgb {
  const hn = normaliseHue(h) / 60;
  const sn = s / 100;
  const vn = v / 100;
  const i = Math.floor(hn) % 6;
  const f = hn - Math.floor(hn);
  const p = vn * (1 - sn);
  const q = vn * (1 - f * sn);
  const t = vn * (1 - (1 - f) * sn);

  const table: Array<[number, number, number]> = [
    [vn, t, p],
    [q, vn, p],
    [p, vn, t],
    [p, q, vn],
    [t, p, vn],
    [vn, p, q],
  ];
  const [r, g, b] = table[i];
  return { r: r * 255, g: g * 255, b: b * 255, a };
}

/* ------------------------------------------------------------------------- */
/* sRGB ↔ linear ↔ OKLab ↔ OKLCh                                              */
/* ------------------------------------------------------------------------- */

/** The sRGB transfer function. Not gamma 2.2 — the piecewise one, per IEC 61966-2-1. */
export function srgbToLinear(channel: number): number {
  const c = channel / 255;
  return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}

export function linearToSrgb(channel: number): number {
  const c = channel <= 0.0031308 ? channel * 12.92 : 1.055 * channel ** (1 / 2.4) - 0.055;
  return clamp(c * 255, 0, 255);
}

/** OKLab, from Björn Ottosson's published matrices. */
export function rgbToOklch({ r, g, b, a }: Rgb): Oklch {
  const lr = srgbToLinear(r);
  const lg = srgbToLinear(g);
  const lb = srgbToLinear(b);

  const l = 0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb;
  const m = 0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb;
  const s = 0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb;

  const l_ = Math.cbrt(l);
  const m_ = Math.cbrt(m);
  const s_ = Math.cbrt(s);

  const L = 0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_;
  const A = 1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_;
  const B = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_;

  const chroma = Math.hypot(A, B);
  // A neutral has no hue. Atan2 of two near-zero numbers is noise, and letting
  // that noise through makes a grey ramp wander across the hue wheel.
  const hue = chroma < 1e-7 ? 0 : normaliseHue((Math.atan2(B, A) * 180) / Math.PI);
  return { l: L, c: chroma, h: hue, a };
}

export function oklchToRgb({ l, c, h, a }: Oklch): Rgb {
  const hr = (normaliseHue(h) * Math.PI) / 180;
  const A = c * Math.cos(hr);
  const B = c * Math.sin(hr);

  const l_ = l + 0.3963377774 * A + 0.2158037573 * B;
  const m_ = l - 0.1055613458 * A - 0.0638541728 * B;
  const s_ = l - 0.0894841775 * A - 1.291485548 * B;

  const lc = l_ ** 3;
  const mc = m_ ** 3;
  const sc = s_ ** 3;

  return {
    r: linearToSrgb(4.0767416621 * lc - 3.3077115913 * mc + 0.2309699292 * sc),
    g: linearToSrgb(-1.2684380046 * lc + 2.6097574011 * mc - 0.3413193965 * sc),
    b: linearToSrgb(-0.0041960863 * lc - 0.7034186147 * mc + 1.707614701 * sc),
    a,
  };
}

/**
 * Whether an OKLCh value has a real sRGB colour, or only a clipped one.
 *
 * OKLCh describes far more colours than a monitor can show. `oklch(0.7 0.3 140)`
 * is a perfectly valid coordinate and there is no sRGB pixel for it, so the
 * conversion clips and two different inputs come back as the same swatch. A ramp
 * generator that does not check this quietly flattens its own most saturated
 * steps, which is exactly where a designer is looking.
 */
export function isInSrgbGamut({ l, c, h }: Oklch): boolean {
  const hr = (normaliseHue(h) * Math.PI) / 180;
  const A = c * Math.cos(hr);
  const B = c * Math.sin(hr);
  const l_ = (l + 0.3963377774 * A + 0.2158037573 * B) ** 3;
  const m_ = (l - 0.1055613458 * A - 0.0638541728 * B) ** 3;
  const s_ = (l - 0.0894841775 * A - 1.291485548 * B) ** 3;

  const channels = [
    4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_,
    -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_,
    -0.0041960863 * l_ - 0.7034186147 * m_ + 1.707614701 * s_,
  ];
  // A hair of slack: the round trip is floating point, and a channel landing at
  // 1.0000000002 is in gamut by any sane reading.
  return channels.every((channel) => channel >= -1e-4 && channel <= 1 + 1e-4);
}

/**
 * The most chromatic version of a hue and lightness that sRGB can actually show.
 *
 * Binary search rather than the analytic gamut boundary: the exact solution
 * needs the cusp of the OKLab gamut hull per hue, and twenty iterations lands
 * within a thousandth of a chroma unit, which is far below a visible step.
 */
export function clampToSrgbGamut(color: Oklch): Oklch {
  if (isInSrgbGamut(color)) return color;
  let low = 0;
  let high = color.c;
  for (let i = 0; i < 20; i++) {
    const mid = (low + high) / 2;
    if (isInSrgbGamut({ ...color, c: mid })) low = mid;
    else high = mid;
  }
  return { ...color, c: low };
}

/* ------------------------------------------------------------------------- */
/* CMYK                                                                       */
/* ------------------------------------------------------------------------- */

/**
 * The naive RGB→CMYK conversion, and it is named naive because it is.
 *
 * A real conversion needs an ICC profile for the press, the paper and the ink
 * set; the same sRGB value becomes different CMYK numbers on coated stock than
 * on newsprint. This is the device-independent approximation every online
 * converter uses, and it is fine for picking a swatch and wrong for sending to
 * a printer. The tool says so on the page rather than pretending otherwise.
 */
export function toCmyk({ r, g, b }: Rgb): Cmyk {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const k = 1 - Math.max(rn, gn, bn);
  if (k === 1) return { c: 0, m: 0, y: 0, k: 100 };
  return {
    c: ((1 - rn - k) / (1 - k)) * 100,
    m: ((1 - gn - k) / (1 - k)) * 100,
    y: ((1 - bn - k) / (1 - k)) * 100,
    k: k * 100,
  };
}

export function fromCmyk({ c, m, y, k }: Cmyk, a = 1): Rgb {
  const cn = c / 100;
  const mn = m / 100;
  const yn = y / 100;
  const kn = k / 100;
  return {
    r: 255 * (1 - cn) * (1 - kn),
    g: 255 * (1 - mn) * (1 - kn),
    b: 255 * (1 - yn) * (1 - kn),
    a,
  };
}

/* ------------------------------------------------------------------------- */
/* Formatting                                                                 */
/* ------------------------------------------------------------------------- */

export function toHex(color: Rgb, { alpha = "auto" }: { alpha?: "auto" | "never" | "always" } = {}) {
  const base = `#${hex2(color.r)}${hex2(color.g)}${hex2(color.b)}`;
  const wantsAlpha = alpha === "always" || (alpha === "auto" && color.a < 1);
  return wantsAlpha ? `${base}${hex2(color.a * 255)}` : base;
}

export function toRgbString(color: Rgb): string {
  const r = Math.round(color.r);
  const g = Math.round(color.g);
  const b = Math.round(color.b);
  return color.a < 1
    ? `rgb(${r} ${g} ${b} / ${round(color.a, 3)})`
    : `rgb(${r} ${g} ${b})`;
}

export function toHslString(color: Rgb): string {
  const { h, s, l, a } = rgbToHsl(color);
  const body = `${round(h)} ${round(s, 1)}% ${round(l, 1)}%`;
  return a < 1 ? `hsl(${body} / ${round(a, 3)})` : `hsl(${body})`;
}

export function toOklchString(color: Rgb): string {
  const { l, c, h, a } = rgbToOklch(color);
  const body = `${round(l, 4)} ${round(c, 4)} ${round(h, 2)}`;
  return a < 1 ? `oklch(${body} / ${round(a, 3)})` : `oklch(${body})`;
}

export function toCmykString(color: Rgb): string {
  const { c, m, y, k } = toCmyk(color);
  return `cmyk(${round(c)}% ${round(m)}% ${round(y)}% ${round(k)}%)`;
}

export function format(color: Rgb, as: ColorFormat): string {
  switch (as) {
    case "hex":
      return toHex(color);
    case "rgb":
      return toRgbString(color);
    case "hsl":
      return toHslString(color);
    case "oklch":
      return toOklchString(color);
    case "cmyk":
      return toCmykString(color);
  }
}

/** The closest CSS keyword, when there is one within a hair of the value. */
export function namedFor(color: Rgb): string | null {
  const packed = (Math.round(color.r) << 16) | (Math.round(color.g) << 8) | Math.round(color.b);
  for (const [name, value] of Object.entries(NAMED)) {
    if (value === packed) return name;
  }
  return null;
}

/* ------------------------------------------------------------------------- */
/* Contrast                                                                   */
/* ------------------------------------------------------------------------- */

/** Relative luminance, WCAG 2.x definition. */
export function relativeLuminance({ r, g, b }: Rgb): number {
  return (
    0.2126 * srgbToLinear(r) + 0.7152 * srgbToLinear(g) + 0.0722 * srgbToLinear(b)
  );
}

/**
 * WCAG 2.x contrast ratio, 1 to 21.
 *
 * Alpha is composited against the background first, because a semi-transparent
 * foreground does not have a contrast ratio on its own — a rule every
 * "why does my check disagree with the browser" bug report comes down to.
 */
export function contrastRatio(foreground: Rgb, background: Rgb): number {
  const fg = foreground.a < 1 ? composite(foreground, background) : foreground;
  const l1 = relativeLuminance(fg);
  const l2 = relativeLuminance(background);
  const [light, dark] = l1 > l2 ? [l1, l2] : [l2, l1];
  return (light + 0.05) / (dark + 0.05);
}

/** Source-over compositing, which is what the browser does before it paints. */
export function composite(foreground: Rgb, background: Rgb): Rgb {
  const alpha = clamp(foreground.a, 0, 1);
  return {
    r: foreground.r * alpha + background.r * (1 - alpha),
    g: foreground.g * alpha + background.g * (1 - alpha),
    b: foreground.b * alpha + background.b * (1 - alpha),
    a: 1,
  };
}

/**
 * APCA lightness contrast (Lc), from the SAPC/APCA 0.1.9 constants.
 *
 * WCAG 2.x's ratio is known to be wrong at both ends: it passes some light-grey
 * on white pairs that nobody can read, and fails some dark pairs that are
 * perfectly legible. APCA is the model behind the WCAG 3 draft, is polarity
 * aware (dark-on-light and light-on-dark are different problems) and returns a
 * signed number rather than a ratio.
 *
 * It is reported here *alongside* the 2.x ratio, never instead of it: 2.x is
 * what conformance is still measured against, and a tool that quietly swapped
 * the metric would tell people they had passed an audit they had not.
 */
export function apcaLc(text: Rgb, background: Rgb): number {
  const Y = (color: Rgb) => {
    const y =
      0.2126729 * (color.r / 255) ** 2.4 +
      0.7151522 * (color.g / 255) ** 2.4 +
      0.072175 * (color.b / 255) ** 2.4;
    // Soft clamp near black: below this level the display's own black point
    // dominates and the raw number overstates the difference.
    return y < 0.022 ? y + (0.022 - y) ** 1.414 : y;
  };

  const yText = Y(text.a < 1 ? composite(text, background) : text);
  const yBg = Y(background);

  if (Math.abs(yBg - yText) < 0.0005) return 0;

  let output: number;
  if (yBg > yText) {
    // Dark text on a light background.
    const sapc = (yBg ** 0.56 - yText ** 0.57) * 1.14;
    output = sapc < 0.1 ? 0 : sapc - 0.027;
  } else {
    // Light text on a dark background — a different curve, not a sign flip.
    const sapc = (yBg ** 0.65 - yText ** 0.62) * 1.14;
    output = sapc > -0.1 ? 0 : sapc + 0.027;
  }
  return output * 100;
}

export interface WcagVerdict {
  ratio: number;
  /** 4.5:1 — body text below 18.66px, or below 14px bold. */
  normalAA: boolean;
  /** 7:1 — the enhanced level for the same sizes. */
  normalAAA: boolean;
  /** 3:1 — text at 18.66px+, or 14px+ bold. */
  largeAA: boolean;
  largeAAA: boolean;
  /** 3:1 — icons, focus rings, input borders (WCAG 1.4.11). */
  uiAA: boolean;
}

export function wcagVerdict(foreground: Rgb, background: Rgb): WcagVerdict {
  const ratio = contrastRatio(foreground, background);
  return {
    ratio,
    normalAA: ratio >= 4.5,
    normalAAA: ratio >= 7,
    largeAA: ratio >= 3,
    largeAAA: ratio >= 4.5,
    uiAA: ratio >= 3,
  };
}

/**
 * The nearest colour to `foreground` that reaches `target` against `background`.
 *
 * Walks OKLCh lightness rather than sRGB channels, so the result keeps the hue
 * and as much of the chroma as the lightness allows — the usual sRGB approach
 * drifts the hue as it darkens and hands back a colour that no longer belongs
 * to the palette it came from. Searches away from the background first, and
 * only tries the other direction if that fails, which is what keeps a dark
 * brand colour dark instead of flipping it to near-white.
 */
export function nudgeToContrast(
  foreground: Rgb,
  background: Rgb,
  target = 4.5
): { color: Rgb; ratio: number; reached: boolean } {
  const start = rgbToOklch(foreground);
  const backgroundIsLight = relativeLuminance(background) > 0.18;
  const directions = backgroundIsLight ? [-1, 1] : [1, -1];

  let best = { color: foreground, ratio: contrastRatio(foreground, background) };
  if (best.ratio >= target) return { ...best, reached: true };

  for (const direction of directions) {
    // 0.002 steps: 500 of them span the whole lightness range, which is finer
    // than the 8-bit output can represent, so nothing is missed.
    for (let step = 1; step <= 500; step++) {
      const l = clamp(start.l + direction * step * 0.002, 0, 1);
      const candidate = oklchToRgb(clampToSrgbGamut({ ...start, l }));
      const ratio = contrastRatio(candidate, background);
      if (ratio > best.ratio) best = { color: candidate, ratio };
      if (ratio >= target) return { color: candidate, ratio, reached: true };
      if (l === 0 || l === 1) break;
    }
  }
  return { ...best, reached: false };
}

/* ------------------------------------------------------------------------- */
/* Harmony and scales                                                         */
/* ------------------------------------------------------------------------- */

export type Harmony =
  | "complementary"
  | "analogous"
  | "triadic"
  | "tetradic"
  | "split-complementary"
  | "monochromatic";

export const HARMONIES: Array<{ id: Harmony; label: string; blurb: string }> = [
  {
    id: "complementary",
    label: "Complementary",
    blurb: "The opposite hue. Maximum separation, and the reason it is hard to use for more than an accent.",
  },
  {
    id: "analogous",
    label: "Analogous",
    blurb: "Neighbours 30° either side. Quiet, and the safest choice for a whole interface.",
  },
  {
    id: "triadic",
    label: "Triadic",
    blurb: "Three hues 120° apart. Balanced, and strong enough that two of them usually want muting.",
  },
  {
    id: "tetradic",
    label: "Tetradic",
    blurb: "Two complementary pairs. Four hues is more than most layouts can carry at full strength.",
  },
  {
    id: "split-complementary",
    label: "Split complementary",
    blurb: "The opposite hue, split 30° either side. Most of the contrast, less of the vibration.",
  },
  {
    id: "monochromatic",
    label: "Monochromatic",
    blurb: "One hue, varied by lightness and chroma. What a design system actually ships.",
  },
];

const HARMONY_OFFSETS: Record<Exclude<Harmony, "monochromatic">, number[]> = {
  complementary: [0, 180],
  analogous: [-30, 0, 30],
  triadic: [0, 120, 240],
  tetradic: [0, 90, 180, 270],
  "split-complementary": [0, 150, 210],
};

/**
 * Rotates the hue in OKLCh, so every result keeps the *perceived* lightness of
 * the colour it came from. Rotating in HSL instead is what produces a "triad"
 * where the yellow blinds you and the blue disappears.
 */
export function harmonyOf(base: Rgb, harmony: Harmony): Rgb[] {
  const oklch = rgbToOklch(base);

  if (harmony === "monochromatic") {
    return [-0.18, -0.09, 0, 0.09, 0.18].map((delta) =>
      oklchToRgb(clampToSrgbGamut({ ...oklch, l: clamp(oklch.l + delta, 0.05, 0.98) }))
    );
  }

  return HARMONY_OFFSETS[harmony].map((offset) =>
    oklchToRgb(clampToSrgbGamut({ ...oklch, h: normaliseHue(oklch.h + offset) }))
  );
}

export interface ScaleStop {
  /** The Tailwind-style step number: 50, 100, … 950. */
  step: number;
  color: Rgb;
  /** True for the stop nearest the colour the scale was built from. */
  isBase: boolean;
  /** Contrast against white and black, so a caller can pick a text colour. */
  onWhite: number;
  onBlack: number;
}

const SCALE_STEPS = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950];

/**
 * An eleven-step tint and shade ramp, in the shape design systems expect.
 *
 * Built by walking OKLCh lightness on a fixed curve and holding the hue, with
 * chroma tapering towards both ends — a ramp that keeps full chroma at step 50
 * produces a "light" tint that is actually a fluorescent pastel, and one that
 * keeps it at 950 produces a near-black that still glows.
 *
 * Every stop is gamut-clamped, so what you copy is what the browser will paint.
 */
export function buildScale(base: Rgb): ScaleStop[] {
  const oklch = rgbToOklch(base);
  const white: Rgb = { r: 255, g: 255, b: 255, a: 1 };
  const black: Rgb = { r: 0, g: 0, b: 0, a: 1 };

  // Target lightness per step. Not linear: the eye needs more room at the light
  // end, which is why 50→200 move less than 700→950.
  const lightness = [0.97, 0.94, 0.88, 0.8, 0.71, 0.62, 0.53, 0.44, 0.36, 0.28, 0.2];

  // Which step the input colour is closest to, so the ramp is anchored to it.
  let baseIndex = 0;
  let bestDistance = Infinity;
  lightness.forEach((l, index) => {
    const distance = Math.abs(l - oklch.l);
    if (distance < bestDistance) {
      bestDistance = distance;
      baseIndex = index;
    }
  });

  return SCALE_STEPS.map((step, index) => {
    // Chroma tapers towards both ends, fastest at the light end where the
    // display runs out of gamut first.
    const distance = Math.abs(index - baseIndex) / Math.max(baseIndex, SCALE_STEPS.length - 1 - baseIndex, 1);
    const taper = index < baseIndex ? 1 - distance * 0.55 : 1 - distance * 0.25;
    const color = oklchToRgb(
      clampToSrgbGamut({
        l: lightness[index],
        c: Math.max(0, oklch.c * taper),
        h: oklch.h,
        a: 1,
      })
    );
    return {
      step,
      color,
      isBase: index === baseIndex,
      onWhite: contrastRatio(color, white),
      onBlack: contrastRatio(color, black),
    };
  });
}

/**
 * Mixes two colours in OKLab, which is what `color-mix(in oklab, …)` does.
 *
 * The sRGB midpoint of blue and yellow is a muddy grey; the OKLab midpoint is
 * the green a person expects. Hue is interpolated through Lab's a/b rather than
 * as an angle, so there is no decision to make about which way round the wheel
 * to travel and no grey dip in the middle.
 */
export function mix(from: Rgb, to: Rgb, amount: number): Rgb {
  const t = clamp(amount, 0, 1);
  const lerp = (a: number, b: number) => a + (b - a) * t;

  const fl = { r: srgbToLinear(from.r), g: srgbToLinear(from.g), b: srgbToLinear(from.b) };
  const tl = { r: srgbToLinear(to.r), g: srgbToLinear(to.g), b: srgbToLinear(to.b) };

  const toLab = (c: { r: number; g: number; b: number }) => {
    const l = Math.cbrt(0.4122214708 * c.r + 0.5363325363 * c.g + 0.0514459929 * c.b);
    const m = Math.cbrt(0.2119034982 * c.r + 0.6806995451 * c.g + 0.1073969566 * c.b);
    const s = Math.cbrt(0.0883024619 * c.r + 0.2817188376 * c.g + 0.6299787005 * c.b);
    return { l, m, s };
  };

  const a = toLab(fl);
  const b = toLab(tl);
  const l_ = lerp(a.l, b.l) ** 3;
  const m_ = lerp(a.m, b.m) ** 3;
  const s_ = lerp(a.s, b.s) ** 3;

  return {
    r: linearToSrgb(4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_),
    g: linearToSrgb(-1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_),
    b: linearToSrgb(-0.0041960863 * l_ - 0.7034186147 * m_ + 1.707614701 * s_),
    a: lerp(from.a, to.a),
  };
}

/* ------------------------------------------------------------------------- */
/* Colour vision deficiency                                                   */
/* ------------------------------------------------------------------------- */

export type Cvd = "protanopia" | "deuteranopia" | "tritanopia" | "achromatopsia";

export const CVD_TYPES: Array<{ id: Cvd; label: string; blurb: string; prevalence: string }> = [
  {
    id: "deuteranopia",
    label: "Deuteranopia",
    blurb: "No green cone. Red and green collapse towards a shared yellow-brown.",
    prevalence: "≈1.1% of men",
  },
  {
    id: "protanopia",
    label: "Protanopia",
    blurb: "No red cone. Red darkens sharply as well as shifting, so red-on-black nearly vanishes.",
    prevalence: "≈1.0% of men",
  },
  {
    id: "tritanopia",
    label: "Tritanopia",
    blurb: "No blue cone. Blue and green converge, and yellow reads as pink.",
    prevalence: "≈0.01%, and not sex-linked",
  },
  {
    id: "achromatopsia",
    label: "Achromatopsia",
    blurb: "No colour at all. The honest test of whether a design works on lightness alone.",
    prevalence: "≈0.003%",
  },
];

/**
 * Machado, Oliveira & Fernandes (2009), severity 1.0.
 *
 * The alternative is the older Viénot/Brettel projection, which is exact for
 * protan and deutan and visibly wrong for tritan. These matrices are derived
 * from a shift in the cone response curves rather than a projection, cover all
 * three types with one mechanism, and are the ones browsers and accessibility
 * tooling converged on. They operate on *linear* RGB, which is the step most
 * implementations skip — applying them to gamma-encoded values gives a
 * plausible-looking image that is wrong everywhere.
 */
const CVD_MATRIX: Record<Exclude<Cvd, "achromatopsia">, number[]> = {
  protanopia: [0.152286, 1.052583, -0.204868, 0.114503, 0.786281, 0.099216, -0.003882, -0.048116, 1.051998],
  deuteranopia: [0.367322, 0.860646, -0.227968, 0.280085, 0.672501, 0.047413, -0.01182, 0.04294, 0.968881],
  tritanopia: [1.255528, -0.076749, -0.178779, -0.078411, 0.930809, 0.147602, 0.004733, 0.691367, 0.3039],
};

export function simulateCvd(color: Rgb, type: Cvd): Rgb {
  if (type === "achromatopsia") {
    const value = linearToSrgb(relativeLuminance(color));
    return { r: value, g: value, b: value, a: color.a };
  }

  const m = CVD_MATRIX[type];
  const r = srgbToLinear(color.r);
  const g = srgbToLinear(color.g);
  const b = srgbToLinear(color.b);

  return {
    r: linearToSrgb(m[0] * r + m[1] * g + m[2] * b),
    g: linearToSrgb(m[3] * r + m[4] * g + m[5] * b),
    b: linearToSrgb(m[6] * r + m[7] * g + m[8] * b),
    a: color.a,
  };
}

/**
 * Applies a simulation to raw RGBA pixels, in place.
 *
 * A lookup table rather than a per-pixel matrix multiply: a 12-megapixel photo
 * is 48 million channel reads, and the transfer function alone is two `Math.pow`
 * calls per channel. Caching `srgbToLinear` for all 256 inputs turns the inner
 * loop into three multiply-adds and three table reads, which is the difference
 * between a visible freeze and an instant one.
 */
export function simulateCvdPixels(pixels: Uint8ClampedArray, type: Cvd): void {
  const toLinear = new Float32Array(256);
  for (let i = 0; i < 256; i++) toLinear[i] = srgbToLinear(i);

  if (type === "achromatopsia") {
    for (let i = 0; i < pixels.length; i += 4) {
      const y =
        0.2126 * toLinear[pixels[i]] +
        0.7152 * toLinear[pixels[i + 1]] +
        0.0722 * toLinear[pixels[i + 2]];
      const value = linearToSrgb(y);
      pixels[i] = value;
      pixels[i + 1] = value;
      pixels[i + 2] = value;
    }
    return;
  }

  const m = CVD_MATRIX[type];
  for (let i = 0; i < pixels.length; i += 4) {
    const r = toLinear[pixels[i]];
    const g = toLinear[pixels[i + 1]];
    const b = toLinear[pixels[i + 2]];
    pixels[i] = linearToSrgb(m[0] * r + m[1] * g + m[2] * b);
    pixels[i + 1] = linearToSrgb(m[3] * r + m[4] * g + m[5] * b);
    pixels[i + 2] = linearToSrgb(m[6] * r + m[7] * g + m[8] * b);
  }
}

/* ------------------------------------------------------------------------- */
/* Palette extraction                                                         */
/* ------------------------------------------------------------------------- */

export interface Swatch {
  color: Rgb;
  /** Share of sampled pixels, 0–1. */
  share: number;
}

/**
 * The dominant colours in an image, by k-means in OKLab.
 *
 * Two decisions worth stating. First, the clustering runs in OKLab rather than
 * sRGB, because "nearest colour" in sRGB is not the nearest colour to a person —
 * an sRGB k-means on a photograph reliably returns several indistinguishable
 * browns and misses a small but vivid accent entirely.
 *
 * Second, it seeds with k-means++ rather than at random. Random seeding on a
 * photo that is 80% sky converges to five shades of blue about a third of the
 * time, and the user has no way to know they got the bad run.
 *
 * Fully transparent pixels are skipped: they have no colour, and averaging them
 * in drags every cluster towards black.
 */
export function extractPalette(
  pixels: Uint8ClampedArray,
  count = 6,
  { maxSamples = 20000, iterations = 12 }: { maxSamples?: number; iterations?: number } = {}
): Swatch[] {
  const total = pixels.length / 4;
  if (total === 0 || count < 1) return [];

  // Sample on a stride rather than taking the first N pixels, which on most
  // photographs means "the top edge".
  const stride = Math.max(1, Math.floor(total / maxSamples));
  const points: Array<[number, number, number]> = [];
  const sources: Rgb[] = [];

  for (let index = 0; index < total; index += stride) {
    const offset = index * 4;
    const alpha = pixels[offset + 3];
    if (alpha < 8) continue;
    const rgb: Rgb = {
      r: pixels[offset],
      g: pixels[offset + 1],
      b: pixels[offset + 2],
      a: 1,
    };
    const { l, c, h } = rgbToOklch(rgb);
    const hr = (h * Math.PI) / 180;
    points.push([l, c * Math.cos(hr), c * Math.sin(hr)]);
    sources.push(rgb);
  }

  if (points.length === 0) return [];
  const k = Math.min(count, points.length);

  // ---- k-means++ seeding -------------------------------------------------
  const centroids: Array<[number, number, number]> = [points[0]];
  const distanceTo = (point: number[], centre: number[]) =>
    (point[0] - centre[0]) ** 2 + (point[1] - centre[1]) ** 2 + (point[2] - centre[2]) ** 2;

  while (centroids.length < k) {
    let farthest = points[0];
    let farthestDistance = -1;
    for (const point of points) {
      let nearest = Infinity;
      for (const centre of centroids) nearest = Math.min(nearest, distanceTo(point, centre));
      if (nearest > farthestDistance) {
        farthestDistance = nearest;
        farthest = point;
      }
    }
    // Deterministic "furthest point" rather than the probabilistic form: the
    // same image must produce the same palette every time it is opened, or the
    // tool is not something you can cite in a handover document.
    centroids.push(farthest);
  }

  // ---- Lloyd iterations ---------------------------------------------------
  const assignment = new Int32Array(points.length);
  for (let pass = 0; pass < iterations; pass++) {
    let moved = false;
    for (let index = 0; index < points.length; index++) {
      let best = 0;
      let bestDistance = Infinity;
      for (let centre = 0; centre < centroids.length; centre++) {
        const distance = distanceTo(points[index], centroids[centre]);
        if (distance < bestDistance) {
          bestDistance = distance;
          best = centre;
        }
      }
      if (assignment[index] !== best) {
        assignment[index] = best;
        moved = true;
      }
    }
    if (!moved && pass > 0) break;

    const sums = centroids.map(() => [0, 0, 0, 0]);
    for (let index = 0; index < points.length; index++) {
      const bucket = sums[assignment[index]];
      bucket[0] += points[index][0];
      bucket[1] += points[index][1];
      bucket[2] += points[index][2];
      bucket[3] += 1;
    }
    for (let centre = 0; centre < centroids.length; centre++) {
      const [l, a, b, n] = sums[centre];
      if (n > 0) centroids[centre] = [l / n, a / n, b / n];
    }
  }

  // ---- Report the *nearest real pixel*, not the centroid -------------------
  // A centroid is an average and averages of colour are often colours that do
  // not appear in the picture. Handing back the closest pixel that does appear
  // is what makes the swatch match the thing the person pointed at.
  const counts = new Array(centroids.length).fill(0);
  const nearestPixel = new Array<number>(centroids.length).fill(-1);
  const nearestDistance = new Array(centroids.length).fill(Infinity);

  for (let index = 0; index < points.length; index++) {
    const centre = assignment[index];
    counts[centre] += 1;
    const distance = distanceTo(points[index], centroids[centre]);
    if (distance < nearestDistance[centre]) {
      nearestDistance[centre] = distance;
      nearestPixel[centre] = index;
    }
  }

  return centroids
    .map((_, centre) => ({
      color: nearestPixel[centre] >= 0 ? sources[nearestPixel[centre]] : { r: 0, g: 0, b: 0, a: 1 },
      share: counts[centre] / points.length,
    }))
    .filter((swatch) => swatch.share > 0)
    .sort((a, b) => b.share - a.share);
}
