/**
 * Pseudo-isochromatic plates, generated rather than reproduced.
 *
 * The Ishihara plates are a specific set of copyrighted images from 1917, and
 * scans of them are all over the web at whatever colour accuracy the scanner
 * and the reader's screen happen to produce — which is most of the reason
 * online colour-blindness tests are unreliable. This module builds plates from
 * the same principle instead: a figure and a ground made of dots that differ
 * *only* along a confusion axis, so someone with normal colour vision reads the
 * figure and someone with that deficiency does not.
 *
 * The colour pairs are not hand-picked. They are searched for using the same
 * simulation the site's simulator uses: a pair qualifies when the two colours
 * are far apart in OKLab before simulation and close together after it. That
 * makes the plate correct by construction rather than by somebody's eye, and it
 * is why the pair for tritan looks nothing like the pair for deutan.
 *
 * This is a screening indication and nothing more. A real diagnosis is an
 * anomaloscope in a clinic, under controlled lighting, on a calibrated display.
 */
import { oklchToRgb, rgbToOklch, simulateCvd, type Cvd, type Rgb } from "./index";

export type PlateType = Extract<Cvd, "protanopia" | "deuteranopia" | "tritanopia">;

/** Squared distance in OKLab. Squared because only the ordering matters. */
function labDistance(a: Rgb, b: Rgb): number {
  const oa = rgbToOklch(a);
  const ob = rgbToOklch(b);
  const ha = (oa.h * Math.PI) / 180;
  const hb = (ob.h * Math.PI) / 180;
  return (
    (oa.l - ob.l) ** 2 +
    (oa.c * Math.cos(ha) - ob.c * Math.cos(hb)) ** 2 +
    (oa.c * Math.sin(ha) - ob.c * Math.sin(hb)) ** 2
  );
}

export interface ConfusionPair {
  figure: Rgb;
  ground: Rgb;
  /** How far apart they look to normal colour vision. Higher is a clearer plate. */
  separation: number;
  /** How far apart they remain under the simulation. Lower is a better plate. */
  residual: number;
}

/**
 * Finds two colours that a given deficiency cannot tell apart.
 *
 * The criterion is the simulation, not a table of hues: a pair qualifies when
 * the two colours land on top of each other after `simulateCvd`, and among
 * those the one that is furthest apart before it wins. So the pair for protan
 * is genuinely different from the pair for deutan — which matters, because the
 * classic pink/green deutan pair stays clearly separable under protanopia, and
 * a test that used one pair for "red-green" would miss protans entirely.
 *
 * Lightness is allowed to vary by a little, and that is deliberate rather than
 * sloppy. Protanopia's signature is that long wavelengths *darken* as well as
 * shifting, so forcing both colours to the same lightness suppresses the very
 * effect the plate needs to exercise — the search returns a nearly invisible
 * figure. The offset is capped tightly so the figure still cannot be found by
 * brightness alone, and `jitterLightness` scatters both populations over a
 * wider range than the offset itself, which closes the greyscale-screenshot
 * shortcut.
 *
 * A plain scan rather than an optimiser: the space is small, and the same plate
 * has to appear for everyone who opens the page.
 */
export function findConfusionPair(type: PlateType, lightness = 0.68, chroma = 0.15): ConfusionPair {
  let best: ConfusionPair | null = null;

  for (let h1 = 0; h1 < 360; h1 += 3) {
    for (const offset of [-0.05, -0.025, 0, 0.025, 0.05]) {
      const figure = oklchToRgb({ l: lightness + offset, c: chroma, h: h1, a: 1 });
      const figureSeen = simulateCvd(figure, type);

      for (let h2 = h1 + 18; h2 < h1 + 342; h2 += 3) {
        const ground = oklchToRgb({ l: lightness, c: chroma, h: h2 % 360, a: 1 });
        const residual = labDistance(figureSeen, simulateCvd(ground, type));
        // The pair has to actually collapse under the simulation. 0.0004 in
        // squared OKLab is roughly a 2% difference — below what anyone
        // separates in a field of scattered dots.
        if (residual > 0.0004) continue;

        const separation = labDistance(figure, ground);
        if (!best || separation > best.separation) {
          best = { figure, ground, separation, residual };
        }
      }
    }
  }

  // Every deficiency has confusion lines by definition, so this cannot fail for
  // a real type; the fallback exists so a caller never has to handle null.
  return (
    best ?? {
      figure: oklchToRgb({ l: lightness, c: chroma, h: 30, a: 1 }),
      ground: oklchToRgb({ l: lightness, c: chroma, h: 130, a: 1 }),
      separation: 0,
      residual: 0,
    }
  );
}

export interface Dot {
  x: number;
  y: number;
  r: number;
  /** True when this dot is part of the figure rather than the ground. */
  inFigure: boolean;
  /** Per-dot lightness jitter, −1 to 1, applied to whichever colour it takes. */
  jitter: number;
}

/**
 * A deterministic pseudo-random generator.
 *
 * The plates must be identical for everyone who opens the page — a test whose
 * difficulty varies per visitor cannot be compared with anything, and a person
 * retaking it should see the same plate. `Math.random` gives neither.
 */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Fills a circle with non-overlapping dots, marking which fall inside the figure.
 *
 * Dart-throwing with a bounded number of attempts rather than a packing
 * algorithm: the dots need to look scattered, not tessellated, and an even
 * packing gives the figure a visible edge that defeats the whole design. Sizes
 * vary and no dot touches another, so the figure cannot be traced by following
 * a seam.
 *
 * `isInFigure` receives coordinates normalised to 0–1 over the plate.
 */
export function layoutPlate(
  size: number,
  isInFigure: (x: number, y: number) => boolean,
  seed: number,
  { attempts = 9000, minRadius = 3, maxRadius = 11 }: { attempts?: number; minRadius?: number; maxRadius?: number } = {}
): Dot[] {
  const random = mulberry32(seed);
  const centre = size / 2;
  const dots: Dot[] = [];

  for (let attempt = 0; attempt < attempts; attempt++) {
    const r = minRadius + random() * (maxRadius - minRadius);
    const x = random() * size;
    const y = random() * size;

    // Inside the plate's circular boundary, with room for the dot itself.
    if (Math.hypot(x - centre, y - centre) > centre - r - 1) continue;

    let overlaps = false;
    for (const dot of dots) {
      if (Math.hypot(x - dot.x, y - dot.y) < r + dot.r + 1.2) {
        overlaps = true;
        break;
      }
    }
    if (overlaps) continue;

    dots.push({
      x,
      y,
      r,
      inFigure: isInFigure(x / size, y / size),
      jitter: random() * 2 - 1,
    });
  }

  return dots;
}

/**
 * Nudges a dot's lightness so the field is not flat.
 *
 * Real plates vary the tone of every dot, and it matters for more than looks: a
 * field of two exact colours can be separated by any image-processing trick,
 * including the reader's own screenshot and a levels adjustment. Jittering
 * lightness across both figure and ground by the same amount removes that
 * shortcut without giving the figure away, because the jitter is uncorrelated
 * with which colour a dot has.
 */
export function jitterLightness(color: Rgb, amount: number, spread = 0.05): Rgb {
  const oklch = rgbToOklch(color);
  return oklchToRgb({
    ...oklch,
    l: Math.max(0.05, Math.min(0.95, oklch.l + amount * spread)),
  });
}

export interface Plate {
  /** The digit the figure spells, or null for a control plate everyone reads. */
  answer: string;
  type: PlateType | null;
  seed: number;
}

/**
 * The test, in order.
 *
 * It opens and closes with a control plate that everyone can read, which is
 * doing real work: if someone misses those, the problem is the screen, the
 * lighting or the instructions rather than their colour vision, and the result
 * should be discarded instead of reported.
 */
export const PLATES: Plate[] = [
  { answer: "12", type: null, seed: 1 },
  { answer: "8", type: "deuteranopia", seed: 2 },
  { answer: "6", type: "protanopia", seed: 3 },
  { answer: "29", type: "deuteranopia", seed: 4 },
  { answer: "5", type: "tritanopia", seed: 5 },
  { answer: "74", type: "protanopia", seed: 6 },
  { answer: "3", type: "tritanopia", seed: 7 },
  { answer: "45", type: null, seed: 8 },
];
