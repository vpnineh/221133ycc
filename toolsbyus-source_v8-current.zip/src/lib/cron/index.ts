/**
 * Cron expression parsing, description and next-run calculation.
 *
 * Three things make cron harder than it looks.
 *
 * The day fields are ORed, not ANDed. When both day-of-month and day-of-week are
 * restricted — `0 0 13 * 5` — the job runs on the 13th *or* on every Friday, not
 * on Friday the 13th. This is in POSIX and in Vixie cron's manual and it still
 * surprises people, because every other pair of fields intersects.
 *
 * Next-run calculation is a search, not a formula. `0 0 31 2 *` — midnight on
 * 31 February — never runs, and a naive loop looking for it never terminates.
 * The search is bounded by years, and a schedule that never fires is reported as
 * such rather than hanging.
 *
 * Daylight saving is a real hazard and is out of this tool's scope by design:
 * everything here is computed in UTC, because a local-time schedule genuinely
 * runs twice on one night a year and not at all on another, and pretending
 * otherwise would produce confidently wrong times.
 */

export type CronFlavour = "standard" | "quartz";

export interface CronField {
  name: string;
  min: number;
  max: number;
  /** Values this field matches, sorted. */
  values: number[];
  /** True when the field was `*`, which day-of-week and day-of-month treat specially. */
  wildcard: boolean;
  raw: string;
}

export interface ParsedCron {
  fields: CronField[];
  /** Present for a six- or seven-field expression. */
  hasSeconds: boolean;
  hasYear: boolean;
  description: string;
}

export type CronResult = { ok: true; value: ParsedCron } | { ok: false; error: string };

const MONTH_NAMES = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
const DAY_NAMES = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

const MONTH_LABELS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const DAY_LABELS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

/** Named shorthands every cron implementation accepts. */
export const ALIASES: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};

interface FieldSpec {
  name: string;
  min: number;
  max: number;
  names?: string[];
}

const MINUTE: FieldSpec = { name: "minute", min: 0, max: 59 };
const HOUR: FieldSpec = { name: "hour", min: 0, max: 23 };
const DOM: FieldSpec = { name: "day of month", min: 1, max: 31 };
const MONTH: FieldSpec = { name: "month", min: 1, max: 12, names: MONTH_NAMES };
const DOW: FieldSpec = { name: "day of week", min: 0, max: 6, names: DAY_NAMES };
const SECOND: FieldSpec = { name: "second", min: 0, max: 59 };
const YEAR: FieldSpec = { name: "year", min: 1970, max: 2099 };

export function parseCron(input: string): CronResult {
  const trimmed = input.trim().toUpperCase();
  if (trimmed === "") return { ok: false, error: "Nothing to parse." };

  const expression = ALIASES[trimmed.toLowerCase()] ?? ALIASES[trimmed] ?? trimmed;
  if (expression.startsWith("@")) {
    if (expression.toLowerCase() === "@reboot") {
      return {
        ok: false,
        error:
          "@reboot runs once when the daemon starts. It has no schedule, so there is no next run to compute.",
      };
    }
    return { ok: false, error: `Unknown shorthand ${expression}. Try @daily, @hourly or @weekly.` };
  }

  const parts = expression.split(/\s+/);
  let specs: FieldSpec[];
  let hasSeconds = false;
  let hasYear = false;

  switch (parts.length) {
    case 5:
      specs = [MINUTE, HOUR, DOM, MONTH, DOW];
      break;
    case 6:
      // Six fields is ambiguous: Quartz puts seconds first, some schedulers put
      // year last. Seconds-first is far more common, so it wins, and the
      // description says which reading was used.
      specs = [SECOND, MINUTE, HOUR, DOM, MONTH, DOW];
      hasSeconds = true;
      break;
    case 7:
      specs = [SECOND, MINUTE, HOUR, DOM, MONTH, DOW, YEAR];
      hasSeconds = true;
      hasYear = true;
      break;
    default:
      return {
        ok: false,
        error: `Expected 5, 6 or 7 fields; found ${parts.length}. Standard cron is "minute hour day month weekday".`,
      };
  }

  const fields: CronField[] = [];
  for (const [index, spec] of specs.entries()) {
    const parsed = parseField(parts[index], spec);
    if ("error" in parsed) return { ok: false, error: parsed.error };
    fields.push(parsed.field);
  }

  return { ok: true, value: { fields, hasSeconds, hasYear, description: describe(fields) } };
}

function parseField(
  raw: string,
  spec: FieldSpec
): { field: CronField } | { error: string } {
  const values = new Set<number>();
  const wildcard = raw === "*" || raw === "?";

  for (const chunk of raw.split(",")) {
    const [rangePart, stepPart] = chunk.split("/");
    const step = stepPart === undefined ? 1 : Number(stepPart);
    if (stepPart !== undefined && (!Number.isInteger(step) || step < 1)) {
      return { error: `"${stepPart}" is not a valid step in the ${spec.name} field.` };
    }

    let from: number;
    let to: number;

    if (rangePart === "*" || rangePart === "?" || rangePart === "") {
      from = spec.min;
      to = spec.max;
    } else if (rangePart.includes("-")) {
      const [a, b] = rangePart.split("-");
      const start = namedValue(a, spec);
      const end = namedValue(b, spec);
      if (start === null || end === null) {
        return { error: `"${rangePart}" is not a valid range in the ${spec.name} field.` };
      }
      from = start;
      to = end;
    } else {
      const single = namedValue(rangePart, spec);
      if (single === null) {
        return {
          error: `"${rangePart}" is not valid in the ${spec.name} field (${spec.min}–${spec.max}${
            spec.names ? ` or ${spec.names.slice(0, 3).join(", ")}…` : ""
          }).`,
        };
      }
      from = single;
      to = stepPart === undefined ? single : spec.max;
    }

    if (from < spec.min || to > spec.max) {
      return {
        error: `${spec.name} must be between ${spec.min} and ${spec.max}; found ${
          from < spec.min ? from : to
        }.`,
      };
    }

    if (from <= to) {
      for (let value = from; value <= to; value += step) values.add(value);
    } else {
      // A wrapping range: FRI-MON, or 22-2 for late-night hours. Rejecting it
      // would be simpler and would reject expressions real crontabs contain.
      for (let value = from; value <= spec.max; value += step) values.add(value);
      for (let value = spec.min; value <= to; value += step) values.add(value);
    }
  }

  if (values.size === 0) return { error: `The ${spec.name} field matches nothing.` };

  // Both 0 and 7 mean Sunday, which every implementation accepts and no
  // documentation mentions in the same place.
  if (spec.name === "day of week" && values.has(7)) {
    values.delete(7);
    values.add(0);
  }

  return {
    field: {
      name: spec.name,
      min: spec.min,
      max: spec.max,
      values: [...values].sort((a, b) => a - b),
      wildcard,
      raw,
    },
  };
}

function namedValue(token: string, spec: FieldSpec): number | null {
  const trimmed = token.trim();
  if (spec.names) {
    const index = spec.names.indexOf(trimmed);
    if (index !== -1) return index + (spec.name === "month" ? 1 : 0);
  }
  if (spec.name === "day of week" && trimmed === "7") return 0;
  const numeric = Number(trimmed);
  if (!Number.isInteger(numeric)) return null;
  if (numeric < spec.min || numeric > spec.max) return null;
  return numeric;
}

/* -------------------------------------------------------------------------- */
/* Description                                                                */
/* -------------------------------------------------------------------------- */

function describe(fields: CronField[]): string {
  const byName = new Map(fields.map((field) => [field.name, field]));
  const second = byName.get("second");
  const minute = byName.get("minute")!;
  const hour = byName.get("hour")!;
  const dom = byName.get("day of month")!;
  const month = byName.get("month")!;
  const dow = byName.get("day of week")!;
  const year = byName.get("year");

  const parts: string[] = [];

  // Time of day.
  if (second && !second.wildcard && second.values.length === 1 && minute.values.length === 1 && hour.values.length === 1) {
    parts.push(`At ${pad(hour.values[0])}:${pad(minute.values[0])}:${pad(second.values[0])}`);
  } else if (minute.wildcard && hour.wildcard) {
    parts.push(second && !second.wildcard ? `Every minute at second ${list(second.values)}` : "Every minute");
  } else if (minute.values.length === 1 && hour.wildcard) {
    parts.push(`At ${pad(minute.values[0])} minutes past every hour`);
  } else if (minute.wildcard && !hour.wildcard) {
    parts.push(`Every minute of hour ${list(hour.values)}`);
  } else if (isStep(minute) && hour.wildcard) {
    parts.push(`Every ${stepOf(minute)} minutes`);
  } else if (minute.values.length === 1 && hour.values.length === 1) {
    parts.push(`At ${pad(hour.values[0])}:${pad(minute.values[0])}`);
  } else {
    parts.push(`At minute ${list(minute.values)} of hour ${list(hour.values)}`);
  }

  // Day, with the OR that catches people out stated explicitly.
  if (!dom.wildcard && !dow.wildcard) {
    parts.push(
      `on day ${list(dom.values)} of the month OR on ${listNames(dow.values, DAY_LABELS)} — cron ORs these two fields rather than intersecting them, so this is not "${listNames(dow.values, DAY_LABELS)} the ${list(dom.values)}"`
    );
  } else if (!dom.wildcard) {
    parts.push(`on day ${list(dom.values)} of the month`);
  } else if (!dow.wildcard) {
    parts.push(`on ${listNames(dow.values, DAY_LABELS)}`);
  } else {
    parts.push("every day");
  }

  if (!month.wildcard) parts.push(`in ${listNames(month.values.map((m) => m - 1), MONTH_LABELS)}`);
  if (year && !year.wildcard) parts.push(`during ${list(year.values)}`);

  return `${parts.join(", ")}, UTC.`;
}

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

function isStep(field: CronField): boolean {
  if (field.values.length < 2) return false;
  const gap = field.values[1] - field.values[0];
  return field.values.every((value, index) => value === field.values[0] + index * gap);
}

function stepOf(field: CronField): number {
  return field.values[1] - field.values[0];
}

function list(values: number[]): string {
  if (values.length === 1) return String(values[0]);
  if (values.length > 8) return `${values.length} values`;
  return `${values.slice(0, -1).join(", ")} and ${values[values.length - 1]}`;
}

function listNames(values: number[], names: string[]): string {
  const labels = values.map((value) => names[value] ?? String(value));
  if (labels.length === 1) return labels[0];
  if (labels.length > 8) return `${labels.length} values`;
  return `${labels.slice(0, -1).join(", ")} and ${labels[labels.length - 1]}`;
}

/* -------------------------------------------------------------------------- */
/* Next runs                                                                  */
/* -------------------------------------------------------------------------- */

/** Years searched before declaring a schedule unreachable. */
const SEARCH_YEARS = 5;

/**
 * Computes the next N fire times, in UTC.
 *
 * A minute-by-minute scan would be simple and would take 2.6 million iterations
 * to discover that `0 0 31 2 *` never runs. This advances by the largest unit
 * that can be ruled out — a wrong month skips to the next month rather than
 * stepping through its days — so an impossible schedule is proven impossible in
 * a few hundred steps rather than a few million.
 */
export function nextRuns(parsed: ParsedCron, from: Date, count: number): Date[] {
  const byName = new Map(parsed.fields.map((field) => [field.name, field]));
  const second = byName.get("second");
  const minute = byName.get("minute")!;
  const hour = byName.get("hour")!;
  const dom = byName.get("day of month")!;
  const month = byName.get("month")!;
  const dow = byName.get("day of week")!;
  const year = byName.get("year");

  const results: Date[] = [];
  const limit = new Date(from.getTime());
  limit.setUTCFullYear(limit.getUTCFullYear() + SEARCH_YEARS);

  const cursor = new Date(from.getTime());
  // Start at the next whole second or minute, so "now" is never returned.
  if (second) cursor.setUTCMilliseconds(0);
  else cursor.setUTCSeconds(0, 0);
  cursor.setTime(cursor.getTime() + (second ? 1000 : 60_000));

  while (results.length < count && cursor <= limit) {
    if (year && !year.values.includes(cursor.getUTCFullYear())) {
      cursor.setUTCFullYear(cursor.getUTCFullYear() + 1, 0, 1);
      cursor.setUTCHours(0, 0, 0, 0);
      continue;
    }
    if (!month.values.includes(cursor.getUTCMonth() + 1)) {
      cursor.setUTCMonth(cursor.getUTCMonth() + 1, 1);
      cursor.setUTCHours(0, 0, 0, 0);
      continue;
    }
    if (!dayMatches(cursor, dom, dow)) {
      cursor.setUTCDate(cursor.getUTCDate() + 1);
      cursor.setUTCHours(0, 0, 0, 0);
      continue;
    }
    if (!hour.values.includes(cursor.getUTCHours())) {
      cursor.setUTCHours(cursor.getUTCHours() + 1, 0, 0, 0);
      continue;
    }
    if (!minute.values.includes(cursor.getUTCMinutes())) {
      cursor.setUTCMinutes(cursor.getUTCMinutes() + 1, 0, 0);
      continue;
    }
    if (second && !second.values.includes(cursor.getUTCSeconds())) {
      cursor.setUTCSeconds(cursor.getUTCSeconds() + 1, 0);
      continue;
    }

    results.push(new Date(cursor.getTime()));
    cursor.setTime(cursor.getTime() + (second ? 1000 : 60_000));
  }

  return results;
}

/**
 * The OR rule, which is the single most misunderstood thing about cron.
 *
 * When both day fields are restricted the job runs if *either* matches. When one
 * is `*` the other decides alone. This is POSIX behaviour and matches Vixie
 * cron, which is what almost everything in production runs.
 */
function dayMatches(date: Date, dom: CronField, dow: CronField): boolean {
  const domMatch = dom.values.includes(date.getUTCDate());
  const dowMatch = dow.values.includes(date.getUTCDay());

  if (dom.wildcard && dow.wildcard) return true;
  if (dom.wildcard) return dowMatch;
  if (dow.wildcard) return domMatch;
  return domMatch || dowMatch;
}

/** Average gap between runs, for a "how often does this fire" line. */
export function frequencySummary(runs: Date[]): string {
  if (runs.length < 2) return "Fewer than two runs in the next five years.";
  const gaps = runs.slice(1).map((run, index) => run.getTime() - runs[index].getTime());
  const average = gaps.reduce((sum, gap) => sum + gap, 0) / gaps.length;

  const units: Array<[string, number]> = [
    ["day", 86_400_000],
    ["hour", 3_600_000],
    ["minute", 60_000],
    ["second", 1000],
  ];
  for (const [label, size] of units) {
    if (average >= size) {
      const amount = Math.round((average / size) * 10) / 10;
      return `About every ${amount} ${label}${amount === 1 ? "" : "s"}`;
    }
  }
  return "Sub-second";
}

/** Common expressions, offered as one-click examples. */
export const CRON_EXAMPLES = [
  { expression: "*/5 * * * *", label: "Every 5 minutes" },
  { expression: "0 * * * *", label: "Hourly, on the hour" },
  { expression: "0 3 * * *", label: "Daily at 03:00" },
  { expression: "0 9 * * 1-5", label: "Weekdays at 09:00" },
  { expression: "0 0 1 * *", label: "First of the month" },
  { expression: "0 0 13 * 5", label: "The 13th OR any Friday" },
  { expression: "30 2 * * 0", label: "Sundays at 02:30" },
  { expression: "0 0 29 2 *", label: "29 February only" },
  { expression: "@daily", label: "Shorthand for 0 0 * * *" },
];
