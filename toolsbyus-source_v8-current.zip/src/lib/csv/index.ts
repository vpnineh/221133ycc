import type { JsonArray, JsonObject, JsonValue } from "../json/types";
import { isForbiddenKey, safeGet, safeSet } from "../safe-object";

/**
 * CSV ⇄ JSON, to RFC 4180 with the deviations real files actually contain.
 *
 * The interesting part is not the parser — that is a small state machine — but
 * the mapping between a flat grid and a nested document, which is where every
 * competing tool gets vague. A CSV row has no way to express `{"a":{"b":1}}`,
 * so something has to be decided, and the honest options are: flatten the path
 * into the column name, or refuse. Flattening is chosen here, with the encoding
 * made explicit and reversible so a round trip through CSV and back returns the
 * document you started with.
 */

export type Delimiter = "," | ";" | "\t" | "|";

export interface CsvParseOptions {
  /** Column separator. `auto` sniffs the header line. */
  delimiter: Delimiter | "auto";
  /** Treat the first row as column names. */
  hasHeader: boolean;
  /** Convert "1", "true" and "null" into their JSON types. */
  inferTypes: boolean;
  /** Rebuild nested structure from dotted / bracketed column names. */
  expandPaths: boolean;
  /** Drop rows that are entirely empty, as trailing newlines produce. */
  skipEmptyRows: boolean;
  /**
   * Treat an empty cell as an absent field rather than an empty string.
   *
   * CSV cannot tell the two apart, and the column set is the union across every
   * record, so a record that simply lacks `tags[1]` is written as an empty cell
   * exactly like one whose `tags[1]` is "". Omitting wins because the sparse
   * case is overwhelmingly the common one: without it, a round trip turns
   * `["c"]` into `["c", ""]` for every record shorter than the longest.
   */
  omitEmpty: boolean;
}

export interface CsvSerializeOptions {
  delimiter: Delimiter;
  /** Emit the header row. */
  includeHeader: boolean;
  /**
   * What to do with a nested array.
   *
   * `explode` gives each element its own column (`tags[0]`, `tags[1]`), which
   * round-trips exactly but produces a ragged column set across a
   * heterogeneous document. `join` puts them in one cell separated by
   * `arrayJoin`, which is what a spreadsheet user usually wants and is lossy
   * for anything but scalars.
   */
  arrayMode: "explode" | "join";
  arrayJoin: string;
  /** Always quote every field rather than only where required. */
  quoteAll: boolean;
  /** CRLF is what RFC 4180 specifies; LF is what everything else uses. */
  newline: "\n" | "\r\n";
}

export const DEFAULT_PARSE_OPTIONS: CsvParseOptions = {
  delimiter: "auto",
  hasHeader: true,
  inferTypes: true,
  expandPaths: true,
  skipEmptyRows: true,
  omitEmpty: true,
};

export const DEFAULT_SERIALIZE_OPTIONS: CsvSerializeOptions = {
  delimiter: ",",
  includeHeader: true,
  arrayMode: "explode",
  arrayJoin: "; ",
  quoteAll: false,
  newline: "\n",
};

export interface CsvParseError {
  message: string;
  line: number;
  column: number;
}

export type CsvResult<T> = { success: true; data: T; warnings: string[] } | { success: false; error: CsvParseError };

/* -------------------------------------------------------------------------- */
/* Grid parsing                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Guesses the delimiter from the first line.
 *
 * Counts candidates outside quoted regions and takes the most frequent. A file
 * whose header is `name,description` with semicolons inside the descriptions
 * would otherwise be split on the wrong character — counting only outside
 * quotes is what makes the guess reliable rather than merely usual.
 */
export function sniffDelimiter(input: string): Delimiter {
  const candidates: Delimiter[] = [",", ";", "\t", "|"];
  const firstLine = readFirstLogicalLine(input);
  let best: Delimiter = ",";
  let bestCount = 0;

  for (const candidate of candidates) {
    let count = 0;
    let inQuotes = false;
    for (let i = 0; i < firstLine.length; i++) {
      const ch = firstLine[i];
      if (ch === '"') {
        if (inQuotes && firstLine[i + 1] === '"') i++;
        else inQuotes = !inQuotes;
      } else if (!inQuotes && ch === candidate) {
        count++;
      }
    }
    if (count > bestCount) {
      bestCount = count;
      best = candidate;
    }
  }
  return best;
}

/** The first row, respecting newlines that live inside a quoted field. */
function readFirstLogicalLine(input: string): string {
  let inQuotes = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (ch === '"') {
      if (inQuotes && input[i + 1] === '"') i++;
      else inQuotes = !inQuotes;
    } else if (!inQuotes && (ch === "\n" || ch === "\r")) {
      return input.slice(0, i);
    }
  }
  return input;
}

/**
 * Parses CSV text into a grid of strings.
 *
 * Written as an explicit state machine over the character stream rather than
 * split-on-comma, because a quoted field may contain the delimiter, a newline,
 * and escaped quotes — all three appear constantly in exported data and all
 * three break the naive version.
 */
export function parseCsvGrid(
  input: string,
  delimiter: Delimiter,
  skipEmptyRows: boolean
): CsvResult<string[][]> {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  let fieldWasQuoted = false;
  let line = 1;
  let column = 1;

  // A BOM at the start would otherwise become part of the first column name,
  // producing a header nobody can match against.
  let text = input;
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);

  const endField = () => {
    row.push(field);
    field = "";
    fieldWasQuoted = false;
  };

  const endRow = () => {
    endField();
    const isEmpty = row.length === 1 && row[0] === "";
    if (!(skipEmptyRows && isEmpty)) rows.push(row);
    row = [];
  };

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    column++;

    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
          column++;
        } else {
          inQuotes = false;
        }
      } else {
        if (ch === "\n") {
          line++;
          column = 1;
        }
        field += ch;
      }
      continue;
    }

    if (ch === '"') {
      if (field.length > 0) {
        // A quote in the middle of a bare field is malformed under RFC 4180.
        // Excel writes it anyway, so it is taken literally rather than
        // rejected — refusing here would decline files the user can see are
        // fine, which is not a service.
        field += ch;
        continue;
      }
      inQuotes = true;
      fieldWasQuoted = true;
      continue;
    }

    if (ch === delimiter) {
      endField();
      continue;
    }

    if (ch === "\r") {
      if (text[i + 1] === "\n") i++;
      endRow();
      line++;
      column = 1;
      continue;
    }

    if (ch === "\n") {
      endRow();
      line++;
      column = 1;
      continue;
    }

    field += ch;
  }

  if (inQuotes) {
    return {
      success: false,
      error: {
        message:
          "Unterminated quoted field: a double quote was opened and never closed. " +
          "A quote inside a quoted field must be doubled (\"\").",
        line,
        column,
      },
    };
  }

  // Flush the final row unless the file ended on a newline.
  if (field.length > 0 || fieldWasQuoted || row.length > 0) endRow();

  return { success: true, data: rows, warnings: [] };
}

/* -------------------------------------------------------------------------- */
/* Path encoding                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Column names encode a path into the document: `address.city` for an object
 * member and `tags[0]` for an array index. The two forms are distinguishable,
 * which is what makes the mapping reversible — `a.0` alone cannot say whether
 * `a` is an object with a key "0" or an array.
 */
export interface PathSegment {
  key: string;
  isIndex: boolean;
}

export function encodePath(segments: PathSegment[]): string {
  let out = "";
  for (const segment of segments) {
    if (segment.isIndex) out += `[${segment.key}]`;
    else out += out ? `.${segment.key}` : segment.key;
  }
  return out;
}

export function decodePath(path: string): PathSegment[] {
  const segments: PathSegment[] = [];
  let buffer = "";
  let i = 0;

  const flush = () => {
    if (buffer !== "") {
      segments.push({ key: buffer, isIndex: false });
      buffer = "";
    }
  };

  while (i < path.length) {
    const ch = path[i];
    if (ch === ".") {
      flush();
      i++;
    } else if (ch === "[") {
      flush();
      const close = path.indexOf("]", i);
      if (close === -1) {
        buffer += ch;
        i++;
        continue;
      }
      segments.push({ key: path.slice(i + 1, close), isIndex: true });
      i = close + 1;
    } else {
      buffer += ch;
      i++;
    }
  }
  flush();
  return segments;
}

/* -------------------------------------------------------------------------- */
/* JSON -> CSV                                                                */
/* -------------------------------------------------------------------------- */

/**
 * Flattens one record to leaf paths.
 *
 * Iterative with an explicit stack rather than recursive: a deeply nested
 * document would otherwise overflow the call stack, and a tool whose failure
 * mode on pathological input is a blank page is not much of a tool. The same
 * discipline is used by the JSON parser and the diff engine.
 */
export function flattenRecord(
  value: JsonValue,
  options: Pick<CsvSerializeOptions, "arrayMode" | "arrayJoin">
): Map<string, string> {
  const out = new Map<string, string>();
  const stack: Array<{ value: JsonValue; path: PathSegment[] }> = [{ value, path: [] }];

  while (stack.length > 0) {
    const { value: current, path } = stack.pop()!;

    if (current === null) {
      out.set(encodePath(path) || "value", "");
      continue;
    }

    if (Array.isArray(current)) {
      if (current.length === 0) {
        out.set(encodePath(path) || "value", "");
        continue;
      }
      const scalarOnly = current.every(
        (item) => item === null || typeof item !== "object"
      );
      if (options.arrayMode === "join" && scalarOnly) {
        out.set(
          encodePath(path) || "value",
          current.map((item) => (item === null ? "" : String(item))).join(options.arrayJoin)
        );
        continue;
      }
      // Push in reverse so the stack yields them in order, which keeps the
      // column order stable and human-readable.
      for (let i = current.length - 1; i >= 0; i--) {
        stack.push({ value: current[i], path: [...path, { key: String(i), isIndex: true }] });
      }
      continue;
    }

    if (typeof current === "object") {
      const keys = Object.keys(current);
      if (keys.length === 0) {
        out.set(encodePath(path) || "value", "");
        continue;
      }
      for (let i = keys.length - 1; i >= 0; i--) {
        stack.push({
          value: (current as JsonObject)[keys[i]],
          path: [...path, { key: keys[i], isIndex: false }],
        });
      }
      continue;
    }

    out.set(encodePath(path) || "value", String(current));
  }

  return out;
}

/** Escapes one field for output, quoting only where the grammar requires it. */
export function escapeCsvField(
  value: string,
  delimiter: Delimiter,
  quoteAll: boolean
): string {
  const mustQuote =
    quoteAll ||
    value.includes(delimiter) ||
    value.includes('"') ||
    value.includes("\n") ||
    value.includes("\r") ||
    // Leading or trailing whitespace is preserved only inside quotes, and
    // spreadsheets strip it otherwise.
    value !== value.trim();

  if (!mustQuote) return value;
  return `"${value.replace(/"/g, '""')}"`;
}

export interface JsonToCsvResult {
  csv: string;
  columns: string[];
  rowCount: number;
  warnings: string[];
}

/**
 * Converts a JSON document to CSV.
 *
 * Accepts an array of records, a single record, or an object whose only array
 * member is the record set — the last is what most APIs return
 * (`{"data":[...]}`), and refusing it would fail on the commonest real input.
 */
export function jsonToCsv(
  value: JsonValue,
  options: CsvSerializeOptions = DEFAULT_SERIALIZE_OPTIONS
): JsonToCsvResult {
  const warnings: string[] = [];
  let records: JsonArray;

  if (Array.isArray(value)) {
    records = value;
  } else if (value !== null && typeof value === "object") {
    const arrayMembers = Object.entries(value).filter(([, v]) => Array.isArray(v));
    if (arrayMembers.length === 1) {
      records = arrayMembers[0][1] as JsonArray;
      warnings.push(
        `Used the "${arrayMembers[0][0]}" array as the record set; the other top-level keys were ignored.`
      );
    } else {
      records = [value];
    }
  } else {
    records = [value];
  }

  // Union of every record's columns, in first-seen order. Using the first
  // record alone silently drops fields that only later records carry, which is
  // the most common way a converter loses data.
  const columns: string[] = [];
  const seen = new Set<string>();
  const flattened = records.map((record) => {
    const map = flattenRecord(record, options);
    for (const key of map.keys()) {
      if (!seen.has(key)) {
        seen.add(key);
        columns.push(key);
      }
    }
    return map;
  });

  const lines: string[] = [];
  if (options.includeHeader) {
    lines.push(
      columns.map((c) => escapeCsvField(c, options.delimiter, options.quoteAll)).join(options.delimiter)
    );
  }
  for (const map of flattened) {
    lines.push(
      columns
        .map((column) => escapeCsvField(map.get(column) ?? "", options.delimiter, options.quoteAll))
        .join(options.delimiter)
    );
  }

  return {
    csv: lines.join(options.newline),
    columns,
    rowCount: flattened.length,
    warnings,
  };
}

/* -------------------------------------------------------------------------- */
/* CSV -> JSON                                                                */
/* -------------------------------------------------------------------------- */

/** Recognises the scalar literals a CSV cell can stand for. */
export function inferCellType(raw: string): JsonValue {
  if (raw === "") return "";
  const trimmed = raw.trim();
  if (trimmed === "true") return true;
  if (trimmed === "false") return false;
  if (trimmed === "null") return null;
  // Only the JSON number grammar, so "007", "1,5", "1e", "+1" and "0x10" stay
  // strings — the grammar's own no-leading-zero rule is what protects a zip
  // code or a part number from being silently renumbered.
  if (/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(trimmed)) {
    const num = Number(trimmed);
    // Beyond 2^53 the conversion loses digits outright, which is real data
    // loss rather than a change of representation, so those stay strings.
    if (Number.isFinite(num) && (Number.isSafeInteger(num) || !Number.isInteger(num))) {
      return num;
    }
  }
  return raw;
}

/**
 * Rebuilds a nested record from flattened column names.
 *
 * Every segment comes from a column header, which is user-controlled text, so
 * each one is checked against the forbidden-key set before it is used to index
 * an object. A header of `a.__proto__.polluted` in an uploaded CSV is exactly
 * the shape of a prototype-pollution payload.
 */
export function expandRow(pairs: Array<[string, JsonValue]>, omitEmpty = true): JsonObject {
  const root: JsonObject = {};

  for (const [path, value] of pairs) {
    if (omitEmpty && value === "") continue;
    const segments = decodePath(path);
    if (segments.length === 0) continue;
    if (segments.some((segment) => isForbiddenKey(segment.key))) continue;

    let cursor: JsonObject | JsonArray = root;

    for (let i = 0; i < segments.length - 1; i++) {
      const segment = segments[i];
      const nextIsIndex = segments[i + 1].isIndex;

      if (Array.isArray(cursor)) {
        const index = Number(segment.key);
        if (!Number.isInteger(index) || index < 0) break;
        if (cursor[index] === undefined || typeof cursor[index] !== "object" || cursor[index] === null) {
          cursor[index] = nextIsIndex ? [] : {};
        }
        cursor = cursor[index] as JsonObject | JsonArray;
      } else {
        const existing = safeGet(cursor, segment.key);
        if (existing === undefined || typeof existing !== "object" || existing === null) {
          safeSet(cursor as Record<string, unknown>, segment.key, nextIsIndex ? [] : {});
        }
        cursor = safeGet(cursor, segment.key) as JsonObject | JsonArray;
      }
    }

    const last = segments[segments.length - 1];
    if (Array.isArray(cursor)) {
      const index = Number(last.key);
      if (Number.isInteger(index) && index >= 0) cursor[index] = value;
    } else {
      safeSet(cursor as Record<string, unknown>, last.key, value);
    }
  }

  return root;
}

export interface CsvToJsonResult {
  records: JsonArray;
  columns: string[];
  warnings: string[];
}

export function csvToJson(
  input: string,
  options: CsvParseOptions = DEFAULT_PARSE_OPTIONS
): CsvResult<CsvToJsonResult> {
  const delimiter = options.delimiter === "auto" ? sniffDelimiter(input) : options.delimiter;
  const grid = parseCsvGrid(input, delimiter, options.skipEmptyRows);
  if (!grid.success) return grid;

  const rows = grid.data;
  const warnings: string[] = [];
  if (rows.length === 0) {
    return { success: true, data: { records: [], columns: [], warnings }, warnings };
  }

  let columns: string[];
  let dataRows: string[][];

  if (options.hasHeader) {
    columns = rows[0].map((name, index) => (name.trim() === "" ? `column${index + 1}` : name.trim()));
    dataRows = rows.slice(1);

    const duplicates = columns.filter((name, index) => columns.indexOf(name) !== index);
    if (duplicates.length > 0) {
      // Later columns win, matching how a spreadsheet import behaves; saying so
      // is better than silently dropping a column the user can see in the file.
      warnings.push(
        `Duplicate column name(s): ${[...new Set(duplicates)].join(", ")}. The rightmost occurrence wins.`
      );
    }
  } else {
    const width = Math.max(...rows.map((r) => r.length));
    columns = Array.from({ length: width }, (_, i) => `column${i + 1}`);
    dataRows = rows;
  }

  const records: JsonArray = [];
  let raggedRows = 0;

  for (const row of dataRows) {
    if (row.length !== columns.length) raggedRows++;

    const pairs: Array<[string, JsonValue]> = [];
    for (let i = 0; i < columns.length; i++) {
      const raw = row[i] ?? "";
      const value = options.inferTypes ? inferCellType(raw) : raw;
      pairs.push([columns[i], value]);
    }

    if (options.expandPaths) {
      records.push(expandRow(pairs, options.omitEmpty));
    } else {
      const flat: JsonObject = {};
      for (const [key, value] of pairs) {
        if (!isForbiddenKey(key)) safeSet(flat as Record<string, unknown>, key, value);
      }
      records.push(flat);
    }
  }

  if (raggedRows > 0) {
    warnings.push(
      `${raggedRows} row(s) did not have ${columns.length} fields. Missing fields are empty strings; extra fields were dropped.`
    );
  }

  return { success: true, data: { records, columns, warnings }, warnings };
}
