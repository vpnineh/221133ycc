import { JsonValue, JsonObject } from "../json/types";
import { areValuesEqual, getJsonType } from "./semantic-diff";

export function createJsonMergePatch(source: JsonValue, target: JsonValue): JsonValue {
  if (areValuesEqual(source, target)) {
    return {};
  }

  const typeS = getJsonType(source);
  const typeT = getJsonType(target);

  if (typeS !== "object" || typeT !== "object") {
    return target;
  }

  const objS = source as JsonObject;
  const objT = target as JsonObject;
  const patch: JsonObject = {};

  const keysS = Object.keys(objS);
  const keysT = Object.keys(objT);
  const allKeys = Array.from(new Set([...keysS, ...keysT]));

  for (const k of allKeys) {
    const valS = objS[k];
    const valT = objT[k];

    if (valT === undefined) {
      patch[k] = null;
    } else if (valS === undefined) {
      patch[k] = valT;
    } else if (!areValuesEqual(valS, valT)) {
      if (getJsonType(valS) === "object" && getJsonType(valT) === "object") {
        patch[k] = createJsonMergePatch(valS, valT);
      } else {
        patch[k] = valT;
      }
    }
  }

  return patch;
}

export function applyJsonMergePatch(target: JsonValue, patch: JsonValue): JsonValue {
  if (patch === null || typeof patch !== "object" || Array.isArray(patch)) {
    return patch;
  }

  let result: JsonObject = {};
  if (target !== null && typeof target === "object" && !Array.isArray(target)) {
    result = { ...(target as JsonObject) };
  }

  const patchObj = patch as JsonObject;
  for (const k of Object.keys(patchObj)) {
    const patchVal = patchObj[k];
    if (patchVal === null) {
      delete result[k];
    } else if (typeof patchVal === "object" && !Array.isArray(patchVal)) {
      result[k] = applyJsonMergePatch(result[k] ?? {}, patchVal);
    } else {
      result[k] = patchVal;
    }
  }

  return result;
}
