import { JsonValue } from "../json/types";
import { Rfc6902Op, JsonPatch, DiffNode } from "./types";
import { computeSemanticDiff, areValuesEqual } from "./semantic-diff";
import { isForbiddenKey, safeSet, hasOwn } from "../safe-object";

export function parseJsonPointer(pointer: string): string[] {
  if (!pointer || pointer === "") return [];
  if (!pointer.startsWith("/")) {
    throw new Error(`Invalid JSON Pointer: must start with '/': '${pointer}'`);
  }
  const segments = pointer
    .slice(1)
    .split("/")
    // Order matters: ~1 before ~0, so an encoded "~01" decodes to "~1" not "/".
    .map((seg) => seg.replace(/~1/g, "/").replace(/~0/g, "~"));

  // A patch is untrusted input. Refuse pointers that would walk into the
  // prototype chain rather than silently polluting Object.prototype.
  for (const seg of segments) {
    if (isForbiddenKey(seg)) {
      throw new Error(
        `Unsafe JSON Pointer segment '${seg}' in '${pointer}': ` +
          `'__proto__', 'constructor' and 'prototype' are rejected to prevent prototype pollution.`
      );
    }
  }
  return segments;
}

function cloneDeep<T>(val: T): T {
  if (val === null || typeof val !== "object") return val;
  if (Array.isArray(val)) {
    return val.map(cloneDeep) as unknown as T;
  }
  const res: Record<string, unknown> = {};
  for (const k of Object.keys(val)) {
    // safeSet, not res[k]=…, so a literal "__proto__" key survives the clone as
    // an own property instead of re-pointing the prototype.
    safeSet(res, k, cloneDeep((val as Record<string, unknown>)[k]));
  }
  return res as unknown as T;
}

/** RFC 6902 array indices are unsigned integers with no leading zeros or sign. */
function parseArrayIndex(segment: string): number {
  if (!/^(0|[1-9][0-9]*)$/.test(segment)) return NaN;
  return Number(segment);
}

/**
 * Generate RFC 6902 JSON Patch operations from a semantic diff.
 */
export function createJsonPatch(source: JsonValue, target: JsonValue): JsonPatch {
  const diffResult = computeSemanticDiff(source, target);
  const patch: JsonPatch = [];

  // If root replaced or type changed
  if (diffResult.root.type === "REPLACE" || diffResult.root.type === "TYPE_CHANGE") {
    patch.push({
      op: "replace",
      path: "",
      value: cloneDeep(target),
    });
    return patch;
  }

  function collectOps(node: DiffNode): Rfc6902Op[] {
    const ops: Rfc6902Op[] = [];

    if (node.isMove && node.type === "MOVE") {
      if (node.moveFrom) {
        ops.push({
          op: "move",
          from: node.moveFrom,
          path: node.jsonPointer,
        });
      }
      return ops;
    }

    if (node.type === "REMOVE") {
      ops.push({
        op: "remove",
        path: node.jsonPointer,
      });
      return ops;
    }

    if (node.type === "ADD") {
      ops.push({
        op: "add",
        path: node.jsonPointer,
        value: cloneDeep(node.rightValue!),
      });
      return ops;
    }

    if (node.type === "REPLACE" || node.type === "TYPE_CHANGE") {
      ops.push({
        op: "replace",
        path: node.jsonPointer,
        value: cloneDeep(node.rightValue!),
      });
      return ops;
    }

    if (node.children && node.children.length > 0) {
      // Group children:
      // For array children, removals MUST happen in descending index order
      // to avoid shifting target indices out of bounds!
      const removals: DiffNode[] = [];
      const others: DiffNode[] = [];

      for (const child of node.children) {
        if (child.type === "REMOVE") {
          removals.push(child);
        } else {
          others.push(child);
        }
      }

      removals.sort((a, b) => {
        const segA = a.key;
        const segB = b.key;
        if (typeof segA === "number" && typeof segB === "number") {
          return segB - segA; // Descending index
        }
        return 0;
      });

      for (const rem of removals) {
        ops.push(...collectOps(rem));
      }
      for (const other of others) {
        ops.push(...collectOps(other));
      }
    }

    return ops;
  }

  if (diffResult.root.children) {
    const removals: DiffNode[] = [];
    const others: DiffNode[] = [];

    for (const child of diffResult.root.children) {
      if (child.type === "REMOVE") {
        removals.push(child);
      } else {
        others.push(child);
      }
    }

    removals.sort((a, b) => {
      const segA = a.key;
      const segB = b.key;
      if (typeof segA === "number" && typeof segB === "number") {
        return segB - segA;
      }
      return 0;
    });

    for (const rem of removals) {
      patch.push(...collectOps(rem));
    }
    for (const other of others) {
      patch.push(...collectOps(other));
    }
  }

  return patch;
}

/**
 * Apply an RFC 6902 JSON Patch to a document.
 */
export function applyJsonPatch(document: JsonValue, patch: JsonPatch): JsonValue {
  let doc = cloneDeep(document);

  for (const op of patch) {
    const pathSegments = parseJsonPointer(op.path);

    // Root level operations — the whole document is the target, so there is no
    // parent container to index into.
    if (pathSegments.length === 0) {
      if (op.op === "replace" || op.op === "add") {
        doc = cloneDeep(op.value);
        continue;
      }
      if (op.op === "test") {
        if (!areValuesEqual(doc, op.value)) {
          throw new Error(`JSON Patch test failed at root: expected ${JSON.stringify(op.value)}`);
        }
        continue;
      }
      if (op.op === "copy") {
        doc = cloneDeep(getValueAtPath(doc, parseJsonPointer(op.from)));
        continue;
      }
      // "remove" and "move" cannot target the whole document.
      throw new Error(`Operation '${op.op}' is not valid on the document root ("")`);
    }

    switch (op.op) {
      case "add": {
        const parent = navigateToParent(doc, pathSegments);
        const lastKey = pathSegments[pathSegments.length - 1];

        if (Array.isArray(parent)) {
          if (lastKey === "-") {
            parent.push(cloneDeep(op.value));
          } else {
            const idx = parseArrayIndex(lastKey);
            if (isNaN(idx) || idx > parent.length) {
              throw new Error(`Invalid array index in add operation: '${lastKey}'`);
            }
            parent.splice(idx, 0, cloneDeep(op.value));
          }
        } else if (parent && typeof parent === "object") {
          safeSet(parent, lastKey, cloneDeep(op.value));
        } else {
          throw new Error(`Cannot add to non-container at path '${op.path}'`);
        }
        break;
      }

      case "remove": {
        const parent = navigateToParent(doc, pathSegments);
        const lastKey = pathSegments[pathSegments.length - 1];

        if (Array.isArray(parent)) {
          const idx = parseArrayIndex(lastKey);
          if (isNaN(idx) || idx >= parent.length) {
            throw new Error(`Invalid array index in remove operation: '${lastKey}'`);
          }
          parent.splice(idx, 1);
        } else if (parent && typeof parent === "object") {
          if (!hasOwn(parent, lastKey)) {
            throw new Error(`Cannot remove non-existent key '${lastKey}' at '${op.path}'`);
          }
          delete parent[lastKey];
        } else {
          throw new Error(`Cannot remove from non-container at path '${op.path}'`);
        }
        break;
      }

      case "replace": {
        const parent = navigateToParent(doc, pathSegments);
        const lastKey = pathSegments[pathSegments.length - 1];

        if (Array.isArray(parent)) {
          const idx = parseArrayIndex(lastKey);
          if (isNaN(idx) || idx >= parent.length) {
            throw new Error(`Invalid array index in replace operation: '${lastKey}'`);
          }
          parent[idx] = cloneDeep(op.value);
        } else if (parent && typeof parent === "object") {
          // RFC 6902 §4.3: replace requires the target location to exist.
          if (!hasOwn(parent, lastKey)) {
            throw new Error(`Cannot replace non-existent key '${lastKey}' at '${op.path}'`);
          }
          safeSet(parent, lastKey, cloneDeep(op.value));
        } else {
          throw new Error(`Cannot replace in non-container at path '${op.path}'`);
        }
        break;
      }

      case "move": {
        const fromSegments = parseJsonPointer(op.from);

        // RFC 6902 §4.4: "from" must not be a proper prefix of "path" — you
        // cannot move a container into its own subtree.
        if (isProperPrefix(fromSegments, pathSegments)) {
          throw new Error(
            `Invalid move: source '${op.from}' is a parent of destination '${op.path}'`
          );
        }

        const fromParent = navigateToParent(doc, fromSegments);
        const fromKey = fromSegments[fromSegments.length - 1];

        let valueToMove: any;
        if (Array.isArray(fromParent)) {
          const idx = parseArrayIndex(fromKey);
          if (isNaN(idx) || idx >= fromParent.length) {
            throw new Error(`Invalid array index in move source: '${fromKey}'`);
          }
          valueToMove = fromParent.splice(idx, 1)[0];
        } else if (fromParent && typeof fromParent === "object") {
          if (!hasOwn(fromParent, fromKey)) {
            throw new Error(`Cannot move from non-existent path '${op.from}'`);
          }
          valueToMove = fromParent[fromKey];
          delete fromParent[fromKey];
        } else {
          throw new Error(`Invalid source path for move: '${op.from}'`);
        }

        const toParent = navigateToParent(doc, pathSegments);
        const toKey = pathSegments[pathSegments.length - 1];

        if (Array.isArray(toParent)) {
          if (toKey === "-") {
            toParent.push(valueToMove);
          } else {
            const idx = parseArrayIndex(toKey);
            if (isNaN(idx) || idx > toParent.length) {
              throw new Error(`Invalid array index in move destination: '${toKey}'`);
            }
            toParent.splice(idx, 0, valueToMove);
          }
        } else if (toParent && typeof toParent === "object") {
          safeSet(toParent, toKey, valueToMove);
        } else {
          throw new Error(`Cannot move into non-container at path '${op.path}'`);
        }
        break;
      }

      case "copy": {
        const fromSegments = parseJsonPointer(op.from);
        // RFC 6902 §4.5: the source location MUST exist.
        if (!pathExists(doc, fromSegments)) {
          throw new Error(`Cannot copy from non-existent path '${op.from}'`);
        }
        const valueToCopy = getValueAtPath(doc, fromSegments);

        const toParent = navigateToParent(doc, pathSegments);
        const toKey = pathSegments[pathSegments.length - 1];

        if (Array.isArray(toParent)) {
          if (toKey === "-") {
            toParent.push(cloneDeep(valueToCopy));
          } else {
            const idx = parseArrayIndex(toKey);
            if (isNaN(idx) || idx > toParent.length) {
              throw new Error(`Invalid array index in copy destination: '${toKey}'`);
            }
            toParent.splice(idx, 0, cloneDeep(valueToCopy));
          }
        } else if (toParent && typeof toParent === "object") {
          safeSet(toParent, toKey, cloneDeep(valueToCopy));
        } else {
          throw new Error(`Cannot copy into non-container at path '${op.path}'`);
        }
        break;
      }

      case "test": {
        const currentVal = getValueAtPath(doc, pathSegments);
        if (!areValuesEqual(currentVal, op.value)) {
          throw new Error(
            `JSON Patch test failed at path '${op.path}': expected ${JSON.stringify(op.value)}, got ${JSON.stringify(currentVal)}`
          );
        }
        break;
      }
    }
  }

  return doc;
}

function navigateToParent(root: any, segments: string[]): any {
  let curr = root;
  for (let i = 0; i < segments.length - 1; i++) {
    const seg = segments[i];
    if (curr === null || curr === undefined) {
      throw new Error(`Cannot traverse through null/undefined at segment '${seg}'`);
    }
    if (Array.isArray(curr)) {
      curr = curr[parseArrayIndex(seg)];
    } else if (typeof curr === "object") {
      // Own properties only — never step onto the prototype chain.
      curr = hasOwn(curr, seg) ? curr[seg] : undefined;
    } else {
      throw new Error(`Cannot traverse into primitive value at segment '${seg}'`);
    }
  }
  if (curr === null || curr === undefined) {
    throw new Error(`Target container is null or undefined for segment '${segments[segments.length - 1]}'`);
  }
  return curr;
}

function getValueAtPath(root: any, segments: string[]): any {
  let curr = root;
  for (const seg of segments) {
    if (curr === null || curr === undefined) return undefined;
    if (Array.isArray(curr)) {
      curr = curr[parseArrayIndex(seg)];
    } else if (typeof curr === "object") {
      curr = hasOwn(curr, seg) ? curr[seg] : undefined;
    } else {
      return undefined;
    }
  }
  return curr;
}

/** Whether a JSON Pointer location resolves to an existing member. */
function pathExists(root: any, segments: string[]): boolean {
  let curr = root;
  for (const seg of segments) {
    if (curr === null || typeof curr !== "object") return false;
    if (Array.isArray(curr)) {
      const idx = parseArrayIndex(seg);
      if (isNaN(idx) || idx >= curr.length) return false;
      curr = curr[idx];
    } else {
      if (!hasOwn(curr, seg)) return false;
      curr = curr[seg];
    }
  }
  return true;
}

/** True when `prefix` names an ancestor location of `full`. */
function isProperPrefix(prefix: string[], full: string[]): boolean {
  if (prefix.length >= full.length) return false;
  return prefix.every((seg, i) => seg === full[i]);
}
