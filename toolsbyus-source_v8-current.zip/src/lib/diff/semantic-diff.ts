import { JsonValue, JsonObject, JsonArray } from "../json/types";
import {
  DiffNode,
  DiffOptions,
  DiffSummary,
  FlatDiffRow,
  SemanticDiffResult,
} from "./types";

export function getJsonType(val: any): string {
  if (val === undefined) return "undefined";
  if (val === null) return "null";
  if (Array.isArray(val)) return "array";
  return typeof val;
}

export function toJsonPointer(path: (string | number)[]): string {
  if (path.length === 0) return "";
  return "/" + path.map((segment) => String(segment).replace(/~/g, "~0").replace(/\//g, "~1")).join("/");
}

/**
 * Deep equality for JSON values without recursion.
 */
export function areValuesEqual(a: JsonValue, b: JsonValue): boolean {
  if (a === b) return true;
  const typeA = getJsonType(a);
  const typeB = getJsonType(b);
  if (typeA !== typeB) return false;
  if (typeA !== "object" && typeA !== "array") return false;

  const stack: [JsonValue, JsonValue][] = [[a, b]];

  while (stack.length > 0) {
    const [currA, currB] = stack.pop()!;
    if (currA === currB) continue;
    const tA = getJsonType(currA);
    const tB = getJsonType(currB);
    if (tA !== tB) return false;

    if (tA === "array") {
      const arrA = currA as JsonArray;
      const arrB = currB as JsonArray;
      if (arrA.length !== arrB.length) return false;
      for (let i = arrA.length - 1; i >= 0; i--) {
        stack.push([arrA[i], arrB[i]]);
      }
    } else if (tA === "object") {
      const objA = currA as JsonObject;
      const objB = currB as JsonObject;
      const keysA = Object.keys(objA);
      const keysB = Object.keys(objB);
      if (keysA.length !== keysB.length) return false;

      for (let i = 0; i < keysA.length; i++) {
        const k = keysA[i];
        if (!Object.prototype.hasOwnProperty.call(objB, k)) return false;
        stack.push([objA[k], objB[k]]);
      }
    } else {
      if (currA !== currB) return false;
    }
  }

  return true;
}

/**
 * Compute structural similarity score between two objects (0.0 to 1.0).
 */
export function calculateObjectSimilarity(a: JsonValue, b: JsonValue): number {
  if (areValuesEqual(a, b)) return 1.0;
  const tA = getJsonType(a);
  const tB = getJsonType(b);
  if (tA !== tB) return 0.0;
  if (tA !== "object" && tA !== "array") return 0.0;

  if (tA === "object") {
    const objA = a as JsonObject;
    const objB = b as JsonObject;
    const keysA = new Set(Object.keys(objA));
    const keysB = new Set(Object.keys(objB));

    let commonKeys = 0;
    let exactMatches = 0;

    for (const k of keysA) {
      if (keysB.has(k)) {
        commonKeys++;
        if (areValuesEqual(objA[k], objB[k])) {
          exactMatches++;
        }
      }
    }

    const totalKeys = new Set([...keysA, ...keysB]).size;
    if (totalKeys === 0) return 1.0;
    return (commonKeys * 0.5 + exactMatches * 0.5) / totalKeys;
  }

  // Arrays: score on positional agreement, so nested arrays can be matched too
  // rather than always scoring 0 and falling through to add+remove.
  const arrA = a as JsonArray;
  const arrB = b as JsonArray;
  const longer = Math.max(arrA.length, arrB.length);
  if (longer === 0) return 1.0;

  const overlap = Math.min(arrA.length, arrB.length);
  let equalElements = 0;
  for (let i = 0; i < overlap; i++) {
    if (areValuesEqual(arrA[i], arrB[i])) equalElements++;
  }
  return equalElements / longer;
}

/**
 * Key-order-independent serialization, used to bucket candidate move pairs.
 *
 * Object keys are sorted so `{a:1,b:2}` and `{b:2,a:1}` share a key — the same
 * key-order invariance the diff itself promises. Collisions are harmless: every
 * bucket hit is confirmed with a real deep comparison.
 */
function canonicalKey(value: JsonValue): string {
  const seen = new WeakSet<object>();

  const walk = (val: any): string => {
    if (val === null) return "null";
    const t = typeof val;
    if (t === "string") return JSON.stringify(val);
    if (t === "number" || t === "boolean") return String(val);
    if (t !== "object") return "undefined";

    if (seen.has(val)) return '"[circular]"';
    seen.add(val);

    let out: string;
    if (Array.isArray(val)) {
      out = `[${val.map(walk).join(",")}]`;
    } else {
      const keys = Object.keys(val).sort();
      out = `{${keys.map((k) => `${JSON.stringify(k)}:${walk(val[k])}`).join(",")}}`;
    }
    seen.delete(val);
    return out;
  };

  return walk(value);
}

/**
 * Similarity matching compares every left element against every right element.
 * Past this many elements the quadratic pass costs more than it is worth, so
 * the array falls back to index matching.
 */
const SIMILARITY_MAX_ELEMENTS = 400;

interface DiffTask {
  left: any;
  right: any;
  /** This node's fully-built JSON Pointer; "" at the document root. */
  pointer: string;
  /** Final path segment, or null at the root. */
  key: string | number | null;
  depth: number;
  parentNode?: DiffNode;
}

/** Append one segment to a JSON Pointer in O(1) (RFC 6901 escaping). */
function childPointer(parentPointer: string, segment: string | number): string {
  const escaped = String(segment).replace(/~/g, "~0").replace(/\//g, "~1");
  return `${parentPointer}/${escaped}`;
}

export function computeSemanticDiff(
  leftData: JsonValue,
  rightData: JsonValue,
  options: DiffOptions = {}
): SemanticDiffResult {
  const arrayMatchMode = options.arrayMatchMode || "index";
  const arrayKey = options.arrayKey;

  const summary: DiffSummary = {
    added: 0,
    removed: 0,
    changed: 0,
    moved: 0,
    typeChanged: 0,
    total: 0,
  };

  const rootPointer = "";
  const rootNode: DiffNode = {
    id: "root",
    key: null,
    depth: 0,
    jsonPointer: rootPointer,
    type: "UNCHANGED",
    leftValue: leftData,
    rightValue: rightData,
    leftType: getJsonType(leftData),
    rightType: getJsonType(rightData),
    children: [],
  };

  // Iterative worklist
  const queue: DiffTask[] = [
    { left: leftData, right: rightData, pointer: "", key: null, depth: 0, parentNode: rootNode },
  ];
  let queueHead = 0;

  const removedSubtrees: { pointer: string; value: JsonValue; node: DiffNode }[] = [];
  const addedSubtrees: { pointer: string; value: JsonValue; node: DiffNode }[] = [];

  while (queueHead < queue.length) {
    const task = queue[queueHead++];
    const { left, right, pointer, key, depth, parentNode } = task;

    const typeLeft = getJsonType(left);
    const typeRight = getJsonType(right);

    // 1. Key absent on left, present on right -> ADD
    if (left === undefined && right !== undefined) {
      const node: DiffNode = {
        id: pointer || "root",
        key,
        depth,
        jsonPointer: pointer,
        type: "ADD",
        rightValue: right,
        rightType: typeRight,
      };
      if (parentNode && parentNode.children) {
        parentNode.children.push(node);
      } else if (task.parentNode === rootNode && depth === 0) {
        rootNode.type = "ADD";
      }
      summary.added++;
      summary.total++;
      if (typeRight === "object" || typeRight === "array") {
        addedSubtrees.push({ pointer, value: right, node });
      }
      continue;
    }

    // 2. Key present on left, absent on right -> REMOVE
    if (left !== undefined && right === undefined) {
      const node: DiffNode = {
        id: pointer || "root",
        key,
        depth,
        jsonPointer: pointer,
        type: "REMOVE",
        leftValue: left,
        leftType: typeLeft,
      };
      if (parentNode && parentNode.children) {
        parentNode.children.push(node);
      } else if (task.parentNode === rootNode && depth === 0) {
        rootNode.type = "REMOVE";
      }
      summary.removed++;
      summary.total++;
      if (typeLeft === "object" || typeLeft === "array") {
        removedSubtrees.push({ pointer, value: left, node });
      }
      continue;
    }

    // 3. Distinct type changes (e.g. "1" -> 1 or true -> "true")
    if (typeLeft !== typeRight) {
      const node: DiffNode = {
        id: pointer || "root",
        key,
        depth,
        jsonPointer: pointer,
        type: "TYPE_CHANGE",
        leftValue: left,
        rightValue: right,
        leftType: typeLeft,
        rightType: typeRight,
      };
      if (parentNode && parentNode.children) {
        parentNode.children.push(node);
      } else if (depth === 0) {
        rootNode.type = "TYPE_CHANGE";
      }
      summary.typeChanged++;
      summary.total++;
      continue;
    }

    // 4. Equal values
    if (left === right || (typeLeft !== "object" && typeLeft !== "array" && areValuesEqual(left, right))) {
      const node: DiffNode = {
        id: pointer || "root",
        key,
        depth,
        jsonPointer: pointer,
        type: "UNCHANGED",
        leftValue: left,
        rightValue: right,
        leftType: typeLeft,
        rightType: typeRight,
      };
      if (parentNode && parentNode.children && depth > 0) {
        parentNode.children.push(node);
      }
      continue;
    }

    // 5. Primitive value difference -> REPLACE
    if (typeLeft !== "object" && typeLeft !== "array") {
      const node: DiffNode = {
        id: pointer || "root",
        key,
        depth,
        jsonPointer: pointer,
        type: "REPLACE",
        leftValue: left,
        rightValue: right,
        leftType: typeLeft,
        rightType: typeRight,
      };
      if (parentNode && parentNode.children) {
        parentNode.children.push(node);
      } else if (depth === 0) {
        rootNode.type = "REPLACE";
      }
      summary.changed++;
      summary.total++;
      continue;
    }

    // 6. Object vs Object
    if (typeLeft === "object") {
      const objL = left as JsonObject;
      const objR = right as JsonObject;
      const keysL = Object.keys(objL);
      const keysR = Object.keys(objR);

      // Union of keys (sorted for deterministic order)
      const allKeys = Array.from(new Set([...keysL, ...keysR])).sort();

      const containerNode: DiffNode = depth === 0 ? rootNode : {
        id: pointer,
        key,
        depth,
        jsonPointer: pointer,
        type: "UNCHANGED",
        leftType: "object",
        rightType: "object",
        children: [],
      };

      if (depth > 0 && parentNode && parentNode.children) {
        parentNode.children.push(containerNode);
      }

      for (let i = 0; i < allKeys.length; i++) {
        const k = allKeys[i];
        queue.push({
          left: objL[k],
          right: objR[k],
          pointer: childPointer(pointer, k),
                key: k,
                depth: depth + 1,
          parentNode: containerNode,
        });
      }
      continue;
    }

    // 7. Array vs Array
    if (typeLeft === "array") {
      const arrL = left as JsonArray;
      const arrR = right as JsonArray;

      const containerNode: DiffNode = depth === 0 ? rootNode : {
        id: pointer,
        key,
        depth,
        jsonPointer: pointer,
        type: "UNCHANGED",
        leftType: "array",
        rightType: "array",
        children: [],
      };

      if (depth > 0 && parentNode && parentNode.children) {
        parentNode.children.push(containerNode);
      }

      if (arrayMatchMode === "key" && arrayKey) {
        // Match objects by user-selected key
        const mapL = new Map<any, { item: any; index: number }>();
        const unkeyedL: { item: any; index: number }[] = [];

        arrL.forEach((it, idx) => {
          if (it && typeof it === "object" && !Array.isArray(it) && it[arrayKey] !== undefined) {
            mapL.set(it[arrayKey], { item: it, index: idx });
          } else {
            unkeyedL.push({ item: it, index: idx });
          }
        });

        const matchedKeys = new Set<any>();

        arrR.forEach((itR, idxR) => {
          if (itR && typeof itR === "object" && !Array.isArray(itR) && itR[arrayKey] !== undefined) {
            const kVal = itR[arrayKey];
            if (mapL.has(kVal)) {
              matchedKeys.add(kVal);
              const { item: itL } = mapL.get(kVal)!;
              queue.push({
                left: itL,
                right: itR,
                pointer: childPointer(pointer, idxR),
                key: idxR,
                depth: depth + 1,
                parentNode: containerNode,
              });
            } else {
              // Added
              queue.push({
                left: undefined,
                right: itR,
                pointer: childPointer(pointer, idxR),
                key: idxR,
                depth: depth + 1,
                parentNode: containerNode,
              });
            }
          } else {
            // Unkeyed in right: match sequentially with unkeyed in left or mark added
            if (unkeyedL.length > 0) {
              const pairL = unkeyedL.shift()!;
              queue.push({
                left: pairL.item,
                right: itR,
                pointer: childPointer(pointer, idxR),
                key: idxR,
                depth: depth + 1,
                parentNode: containerNode,
              });
            } else {
              queue.push({
                left: undefined,
                right: itR,
                pointer: childPointer(pointer, idxR),
                key: idxR,
                depth: depth + 1,
                parentNode: containerNode,
              });
            }
          }
        });

        // Any leftover in left are REMOVED
        mapL.forEach(({ item: itL, index: idxL }, kVal) => {
          if (!matchedKeys.has(kVal)) {
            queue.push({
              left: itL,
              right: undefined,
              pointer: childPointer(pointer, idxL),
                key: idxL,
                depth: depth + 1,
              parentNode: containerNode,
            });
          }
        });

        unkeyedL.forEach(({ item: itL, index: idxL }) => {
          queue.push({
            left: itL,
            right: undefined,
            pointer: childPointer(pointer, idxL),
                key: idxL,
                depth: depth + 1,
            parentNode: containerNode,
          });
        });
      } else if (
        arrayMatchMode === "similarity" &&
        arrL.length * arrR.length <= SIMILARITY_MAX_ELEMENTS * SIMILARITY_MAX_ELEMENTS
      ) {
        // Best-effort structural similarity matching
        const matchedR = new Set<number>();
        const pairs: { lIdx: number; rIdx: number; score: number }[] = [];

        for (let l = 0; l < arrL.length; l++) {
          for (let r = 0; r < arrR.length; r++) {
            const score = calculateObjectSimilarity(arrL[l], arrR[r]);
            if (score > 0.4) {
              pairs.push({ lIdx: l, rIdx: r, score });
            }
          }
        }

        pairs.sort((a, b) => b.score - a.score);
        const assignedL = new Set<number>();
        const matchedPairs: { l: number; r: number }[] = [];

        for (const p of pairs) {
          if (!assignedL.has(p.lIdx) && !matchedR.has(p.rIdx)) {
            assignedL.add(p.lIdx);
            matchedR.add(p.rIdx);
            matchedPairs.push({ l: p.lIdx, r: p.rIdx });
          }
        }

        matchedPairs.forEach(({ l, r }) => {
          queue.push({
            left: arrL[l],
            right: arrR[r],
            pointer: childPointer(pointer, r),
                key: r,
                depth: depth + 1,
            parentNode: containerNode,
          });
        });

        // Unmatched left -> removed
        for (let l = 0; l < arrL.length; l++) {
          if (!assignedL.has(l)) {
            queue.push({
              left: arrL[l],
              right: undefined,
              pointer: childPointer(pointer, l),
                key: l,
                depth: depth + 1,
              parentNode: containerNode,
            });
          }
        }

        // Unmatched right -> added
        for (let r = 0; r < arrR.length; r++) {
          if (!matchedR.has(r)) {
            queue.push({
              left: undefined,
              right: arrR[r],
              pointer: childPointer(pointer, r),
                key: r,
                depth: depth + 1,
              parentNode: containerNode,
            });
          }
        }
      } else {
        // Default: match by index
        const maxLen = Math.max(arrL.length, arrR.length);
        for (let i = 0; i < maxLen; i++) {
          queue.push({
            left: arrL[i],
            right: arrR[i],
            pointer: childPointer(pointer, i),
                key: i,
                depth: depth + 1,
            parentNode: containerNode,
          });
        }
      }
    }
  }

  // 8. Move detection across removed and added subtrees.
  //
  // Pairing these by scanning every (removed x added) combination and deep-
  // comparing each pair is quadratic in the number of subtrees *and* linear in
  // their size — a diff with a few thousand adds and removes stalls the tab.
  // Bucket by a canonical serialization instead: identical subtrees hash to the
  // same key, so pairing is linear and the deep compare only runs to confirm a
  // hash-bucket hit.
  if (removedSubtrees.length > 0 && addedSubtrees.length > 0) {
    const addedByKey = new Map<string, typeof addedSubtrees>();
    for (const add of addedSubtrees) {
      const key = canonicalKey(add.value);
      const bucket = addedByKey.get(key);
      if (bucket) bucket.push(add);
      else addedByKey.set(key, [add]);
    }

    for (const rem of removedSubtrees) {
      if (rem.node.type !== "REMOVE") continue;
      const bucket = addedByKey.get(canonicalKey(rem.value));
      if (!bucket) continue;

      const matchIdx = bucket.findIndex(
        (add) => add.node.type === "ADD" && areValuesEqual(rem.value, add.value)
      );
      if (matchIdx === -1) continue;

      const add = bucket[matchIdx];
      bucket.splice(matchIdx, 1);

      rem.node.type = "MOVE";
      rem.node.isMove = true;
      rem.node.moveTo = add.pointer;

      add.node.type = "MOVE";
      add.node.isMove = true;
      add.node.moveFrom = rem.pointer;

      summary.added--;
      summary.removed--;
      summary.moved++;
    }
  }

  // Generate flat rows for virtualized rendering
  const flatRows = flattenDiffTree(rootNode, options);

  return {
    root: rootNode,
    flatRows,
    summary,
  };
}

export function flattenDiffTree(root: DiffNode, options: DiffOptions = {}): FlatDiffRow[] {
  const rows: FlatDiffRow[] = [];
  const collapseUnchanged = !!options.collapseUnchanged;
  const contextDepth = options.contextDepth ?? 2;

  let leftLine = 1;
  let rightLine = 1;

  // Iterative DFS stack
  const stack: { node: DiffNode; depth: number }[] = [{ node: root, depth: 0 }];

  while (stack.length > 0) {
    const { node, depth } = stack.pop()!;
    const isUnchanged = node.type === "UNCHANGED";
    if (collapseUnchanged && isUnchanged && depth > contextDepth) {
      continue;
    }

    const keyOrIndex = node.key ?? "root";
    const hasChildren = !!(node.children && node.children.length > 0);

    let leftDisplay = "";
    let rightDisplay = "";

    if (node.type === "ADD") {
      rightDisplay = formatDisplayValue(node.rightValue);
    } else if (node.type === "REMOVE") {
      leftDisplay = formatDisplayValue(node.leftValue);
    } else if (node.type === "TYPE_CHANGE" || node.type === "REPLACE") {
      leftDisplay = formatDisplayValue(node.leftValue);
      rightDisplay = formatDisplayValue(node.rightValue);
    } else {
      leftDisplay = formatDisplayValue(node.leftValue);
      rightDisplay = formatDisplayValue(node.rightValue);
    }

    rows.push({
      id: `${node.jsonPointer || "root"}_${depth}_${rows.length}`,
      depth,
      keyOrIndex,
      jsonPointer: node.jsonPointer,
      type: node.type,
      leftType: node.leftType,
      rightType: node.rightType,
      leftDisplay,
      rightDisplay,
      hasChildren,
      leftLineNum: node.leftValue !== undefined ? leftLine++ : undefined,
      rightLineNum: node.rightValue !== undefined ? rightLine++ : undefined,
    });

    if (node.children && node.children.length > 0) {
      for (let i = node.children.length - 1; i >= 0; i--) {
        stack.push({ node: node.children[i], depth: depth + 1 });
      }
    }
  }

  return rows;
}

function formatDisplayValue(val: any): string {
  if (val === undefined) return "";
  if (val === null) return "null";
  if (typeof val === "string") return `"${val}"`;
  if (typeof val === "number" || typeof val === "boolean") return String(val);
  if (Array.isArray(val)) return `Array(${val.length})`;
  if (typeof val === "object") return `{ ${Object.keys(val).length} keys }`;
  return String(val);
}
