import { TextDiffGranularity, TextDiffLine } from "./types";

export interface TextDiffOptions {
  granularity?: TextDiffGranularity;
  ignoreWhitespace?: boolean;
  ignoreCase?: boolean;
}

/**
 * Standard Myers Difference Algorithm on tokens.
 */
export function myersDiff<T>(
  a: T[],
  b: T[],
  equals: (x: T, y: T) => boolean = (x, y) => x === y
): { type: "added" | "removed" | "unchanged"; value: T }[] {
  const n = a.length;
  const m = b.length;
  const max = n + m;

  if (max === 0) return [];

  // V array stores furthest reaching D-paths
  const v: Record<number, number> = { 1: 0 };
  const trace: Record<number, number>[] = [];

  let d = 0;
  outer: for (d = 0; d <= max; d++) {
    trace.push({ ...v });
    for (let k = -d; k <= d; k += 2) {
      let x: number;
      if (k === -d || (k !== d && (v[k - 1] ?? 0) < (v[k + 1] ?? 0))) {
        x = v[k + 1] ?? 0;
      } else {
        x = (v[k - 1] ?? 0) + 1;
      }
      let y = x - k;

      while (x < n && y < m && equals(a[x], b[y])) {
        x++;
        y++;
      }

      v[k] = x;

      if (x >= n && y >= m) {
        break outer;
      }
    }
  }

  // Backtrack to find edit script
  const script: { type: "added" | "removed" | "unchanged"; value: T }[] = [];
  let x = n;
  let y = m;

  for (let step = d; step > 0; step--) {
    const prevV = trace[step];
    const k = x - y;

    let prevK: number;
    if (k === -step || (k !== step && (prevV[k - 1] ?? 0) < (prevV[k + 1] ?? 0))) {
      prevK = k + 1;
    } else {
      prevK = k - 1;
    }

    const prevX = prevV[prevK] ?? 0;
    const prevY = prevX - prevK;

    while (x > prevX && y > prevY) {
      script.unshift({ type: "unchanged", value: a[x - 1] });
      x--;
      y--;
    }

    if (x === prevX) {
      script.unshift({ type: "added", value: b[y - 1] });
      y--;
    } else {
      script.unshift({ type: "removed", value: a[x - 1] });
      x--;
    }
  }

  while (x > 0 && y > 0) {
    script.unshift({ type: "unchanged", value: a[x - 1] });
    x--;
    y--;
  }

  return script;
}

export function tokenize(text: string, granularity: TextDiffGranularity): string[] {
  if (granularity === "char") {
    return Array.from(text);
  }
  if (granularity === "word") {
    return text.split(/(\s+|[^\w\s])/).filter(Boolean);
  }
  // Default: line
  const lines = text.split(/\r?\n/);
  return lines;
}

export function computeTextDiff(
  oldText: string,
  newText: string,
  options: TextDiffOptions = {}
): {
  lines: TextDiffLine[];
  unifiedPatch: string;
  summary: { addedLines: number; removedLines: number; unchangedLines: number };
} {
  const ignoreWhitespace = !!options.ignoreWhitespace;
  const ignoreCase = !!options.ignoreCase;

  function normalize(s: string): string {
    let res = s;
    if (ignoreWhitespace) res = res.replace(/\s+/g, " ").trim();
    if (ignoreCase) res = res.toLowerCase();
    return res;
  }

  const oldLines = oldText.split(/\r?\n/);
  const newLines = newText.split(/\r?\n/);

  const diffItems = myersDiff(oldLines, newLines, (a, b) => normalize(a) === normalize(b));

  const lines: TextDiffLine[] = [];
  let leftNum = 1;
  let rightNum = 1;
  let addedLines = 0;
  let removedLines = 0;
  let unchangedLines = 0;

  for (let i = 0; i < diffItems.length; i++) {
    const item = diffItems[i];
    const next = diffItems[i + 1];

    // Check if paired remove + add = modified line
    if (item.type === "removed" && next && next.type === "added") {
      const wordsOld = item.value.split(/(\s+|[^\w\s])/).filter(Boolean);
      const wordsNew = next.value.split(/(\s+|[^\w\s])/).filter(Boolean);
      const wordDiff = myersDiff(wordsOld, wordsNew, (w1, w2) => normalize(w1) === normalize(w2));

      lines.push({
        id: `line_${lines.length}`,
        type: "modified",
        leftLineNum: leftNum++,
        rightLineNum: rightNum++,
        leftText: item.value,
        rightText: next.value,
        words: wordDiff,
      });
      removedLines++;
      addedLines++;
      i++; // skip next since processed
      continue;
    }

    if (item.type === "added") {
      lines.push({
        id: `line_${lines.length}`,
        type: "added",
        rightLineNum: rightNum++,
        rightText: item.value,
      });
      addedLines++;
    } else if (item.type === "removed") {
      lines.push({
        id: `line_${lines.length}`,
        type: "removed",
        leftLineNum: leftNum++,
        leftText: item.value,
      });
      removedLines++;
    } else {
      lines.push({
        id: `line_${lines.length}`,
        type: "unchanged",
        leftLineNum: leftNum++,
        rightLineNum: rightNum++,
        leftText: item.value,
        rightText: item.value,
      });
      unchangedLines++;
    }
  }

  // Generate unified diff patch
  const patchHeader = [
    "--- a/original",
    "+++ b/modified",
    `@@ -1,${oldLines.length} +1,${newLines.length} @@`,
  ];

  const patchLines: string[] = [];
  for (const l of lines) {
    if (l.type === "added") {
      patchLines.push(`+${l.rightText ?? ""}`);
    } else if (l.type === "removed") {
      patchLines.push(`-${l.leftText ?? ""}`);
    } else if (l.type === "modified") {
      patchLines.push(`-${l.leftText ?? ""}`);
      patchLines.push(`+${l.rightText ?? ""}`);
    } else {
      patchLines.push(` ${l.leftText ?? ""}`);
    }
  }

  const unifiedPatch = patchHeader.concat(patchLines).join("\n");

  return {
    lines,
    unifiedPatch,
    summary: {
      addedLines,
      removedLines,
      unchangedLines,
    },
  };
}
