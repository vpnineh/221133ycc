import { JsonValue, JsonObject } from "../json/types";
import { ThreeWayConflict, ThreeWayDiffResult } from "./types";
import { areValuesEqual, getJsonType, toJsonPointer } from "./semantic-diff";

export function computeThreeWayDiff(
  base: JsonValue,
  left: JsonValue,
  right: JsonValue
): ThreeWayDiffResult {
  const conflicts: ThreeWayConflict[] = [];
  let cleanMerges = 0;

  function mergeValues(b: any, l: any, r: any, path: (string | number)[]): any {
    const pointer = toJsonPointer(path);

    // 1. Both branches agree
    if (areValuesEqual(l, r)) {
      if (!areValuesEqual(b, l)) cleanMerges++;
      return l;
    }

    // 2. Only left changed
    if (areValuesEqual(b, r)) {
      cleanMerges++;
      return l;
    }

    // 3. Only right changed
    if (areValuesEqual(b, l)) {
      cleanMerges++;
      return r;
    }

    // 4. Both changed, check if both are objects (can merge recursively)
    const typeB = getJsonType(b);
    const typeL = getJsonType(l);
    const typeR = getJsonType(r);

    if (typeL === "object" && typeR === "object") {
      const objB = (typeB === "object" ? b : {}) as JsonObject;
      const objL = l as JsonObject;
      const objR = r as JsonObject;

      const allKeys = Array.from(
        new Set([...Object.keys(objB), ...Object.keys(objL), ...Object.keys(objR)])
      ).sort();

      const mergedObj: JsonObject = {};

      for (const k of allKeys) {
        const childMerged = mergeValues(objB[k], objL[k], objR[k], [...path, k]);
        if (childMerged !== undefined) {
          mergedObj[k] = childMerged;
        }
      }

      return mergedObj;
    }

    // 5. Conflict!
    conflicts.push({
      path: pointer || "/",
      base: b ?? null,
      left: l ?? null,
      right: r ?? null,
    });

    return {
      _conflict: true,
      path: pointer || "/",
      left: l,
      base: b,
      right: r,
    };
  }

  const merged = mergeValues(base, left, right, []);

  return {
    merged,
    hasConflicts: conflicts.length > 0,
    conflicts,
    summary: {
      cleanMerges,
      conflictsCount: conflicts.length,
    },
  };
}
