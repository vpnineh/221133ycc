import { JsonValue } from "../json/types";

export type ChangeType =
  | "UNCHANGED"
  | "ADD"
  | "REMOVE"
  | "REPLACE"
  | "TYPE_CHANGE"
  | "MOVE";

export type ArrayMatchMode = "index" | "key" | "similarity";

export interface DiffOptions {
  arrayMatchMode?: ArrayMatchMode;
  arrayKey?: string;
  collapseUnchanged?: boolean;
  contextDepth?: number;
}

export interface DiffNode {
  id: string;
  /**
   * This node's own key within its parent — an object property name, an array
   * index, or null at the document root.
   *
   * This replaced a full `path: (string | number)[]` array. Materializing the
   * whole path at every node made traversal quadratic in nesting depth (each of
   * D levels copied an array of length D), and nothing ever read more than the
   * final segment. The full location is available as `jsonPointer`.
   */
  key: string | number | null;
  /** Distance from the document root; 0 for the root node itself. */
  depth: number;
  jsonPointer: string;
  type: ChangeType;
  leftValue?: JsonValue;
  rightValue?: JsonValue;
  leftType?: string;
  rightType?: string;
  children?: DiffNode[];
  isMove?: boolean;
  moveFrom?: string;
  moveTo?: string;
}

export interface DiffSummary {
  added: number;
  removed: number;
  changed: number;
  moved: number;
  typeChanged: number;
  total: number;
}

export interface SemanticDiffResult {
  root: DiffNode;
  flatRows: FlatDiffRow[];
  summary: DiffSummary;
}

export interface FlatDiffRow {
  id: string;
  depth: number;
  keyOrIndex: string | number;
  jsonPointer: string;
  type: ChangeType;
  leftType?: string;
  rightType?: string;
  leftDisplay?: string;
  rightDisplay?: string;
  hasChildren: boolean;
  isCollapsed?: boolean;
  leftLineNum?: number;
  rightLineNum?: number;
}

export type Rfc6902Op =
  | { op: "add"; path: string; value: JsonValue }
  | { op: "remove"; path: string }
  | { op: "replace"; path: string; value: JsonValue }
  | { op: "move"; from: string; path: string }
  | { op: "copy"; from: string; path: string }
  | { op: "test"; path: string; value: JsonValue };

export type JsonPatch = Rfc6902Op[];

export interface ThreeWayConflict {
  path: string;
  base: JsonValue;
  left: JsonValue;
  right: JsonValue;
}

export interface ThreeWayDiffResult {
  merged: JsonValue;
  hasConflicts: boolean;
  conflicts: ThreeWayConflict[];
  summary: {
    cleanMerges: number;
    conflictsCount: number;
  };
}

export type TextDiffGranularity = "line" | "word" | "char";

export interface TextDiffItem {
  type: "added" | "removed" | "unchanged";
  value: string;
}

export interface TextDiffLine {
  id: string;
  type: "added" | "removed" | "unchanged" | "modified";
  leftLineNum?: number;
  rightLineNum?: number;
  leftText?: string;
  rightText?: string;
  words?: TextDiffItem[];
}
