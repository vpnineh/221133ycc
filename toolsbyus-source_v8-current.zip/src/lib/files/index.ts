/**
 * Shared plumbing for the file tools.
 *
 * The developer tools take a paste; these take a file, and everything about
 * that is different. A file has a size the user did not choose, a type that may
 * be a lie, and — unlike a pasted payload — it is usually the only copy. Three
 * rules follow:
 *
 * 1. Refuse politely above a ceiling rather than letting the tab run out of
 *    memory, which loses the work with no message at all.
 * 2. Revoke every object URL. A session that converts thirty images and never
 *    revokes holds every one of them until the tab closes.
 * 3. Never write a user's file to storage of any kind. Same rule as the
 *    payload tools, and here it is the whole product.
 */

/**
 * Per-file ceiling.
 *
 * Chosen from what a browser tab can actually hold rather than from what sounds
 * generous. A PDF is decoded into memory several times over during a structural
 * edit — parsed object graph, modified graph, serialised output — so a 100 MB
 * file is several hundred megabytes of heap, and a mobile tab is killed well
 * before that.
 */
export const MAX_FILE_BYTES = 100 * 1024 * 1024;

/** Ceiling for all selected files together. */
export const MAX_TOTAL_BYTES = 250 * 1024 * 1024;

/** Above this the UI warns that the operation will take a noticeable moment. */
export const SLOW_FILE_BYTES = 10 * 1024 * 1024;

/** Files accepted in one selection, to keep the list rendering sane. */
export const MAX_FILE_COUNT = 100;

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit++;
  }
  // One decimal below 10, none above: 9.4 MB and 143 MB both read cleanly.
  return `${value < 10 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`;
}

export interface AcceptedFile {
  file: File;
  /** Stable across re-renders so React keys and reordering behave. */
  id: string;
}

export interface SelectionResult {
  accepted: AcceptedFile[];
  /** Human-readable reasons for anything rejected, shown rather than swallowed. */
  rejected: string[];
}

let sequence = 0;

/**
 * Filters a selection against the ceilings and the accepted types.
 *
 * Rejections are returned rather than thrown, because a user who drops twelve
 * files of which one is too large wants the other eleven processed and wants to
 * know which one was dropped.
 */
export function acceptFiles(
  incoming: FileList | File[],
  options: { accept: string[]; existing?: AcceptedFile[]; multiple?: boolean }
): SelectionResult {
  const accepted: AcceptedFile[] = [];
  const rejected: string[] = [];
  const existing = options.existing ?? [];
  let total = existing.reduce((sum, entry) => sum + entry.file.size, 0);

  for (const file of Array.from(incoming)) {
    if (!options.multiple && accepted.length > 0) {
      rejected.push(`${file.name}: this tool takes one file at a time.`);
      continue;
    }
    if (existing.length + accepted.length >= MAX_FILE_COUNT) {
      rejected.push(`${file.name}: more than ${MAX_FILE_COUNT} files selected.`);
      continue;
    }
    if (!matchesAccept(file, options.accept)) {
      rejected.push(
        `${file.name}: not a ${describeAccept(options.accept)} file. The extension and the reported type both have to match.`
      );
      continue;
    }
    if (file.size === 0) {
      rejected.push(`${file.name}: the file is empty.`);
      continue;
    }
    if (file.size > MAX_FILE_BYTES) {
      rejected.push(
        `${file.name} is ${formatBytes(file.size)}, above the ${formatBytes(MAX_FILE_BYTES)} ceiling. Everything happens in this tab's memory, and a file that size would exhaust it rather than finish.`
      );
      continue;
    }
    if (total + file.size > MAX_TOTAL_BYTES) {
      rejected.push(
        `${file.name}: the selection would exceed the ${formatBytes(MAX_TOTAL_BYTES)} total ceiling.`
      );
      continue;
    }

    total += file.size;
    accepted.push({ file, id: `f${++sequence}-${file.name}` });
  }

  return { accepted, rejected };
}

/**
 * Type checking that trusts neither the extension nor the reported MIME type
 * alone.
 *
 * A browser reports an empty `type` for a file dragged from some archive tools,
 * and Windows reports `application/octet-stream` for plenty of things it does
 * not recognise. Accepting on either signal is the pragmatic answer; the real
 * validation is the parser rejecting the bytes a moment later.
 */
function matchesAccept(file: File, accept: string[]): boolean {
  const name = file.name.toLowerCase();
  const type = file.type.toLowerCase();

  return accept.some((pattern) => {
    if (pattern.startsWith(".")) return name.endsWith(pattern);
    if (pattern.endsWith("/*")) return type.startsWith(pattern.slice(0, -1));
    return type === pattern;
  });
}

function describeAccept(accept: string[]): string {
  const extensions = accept.filter((entry) => entry.startsWith("."));
  if (extensions.length > 0) return extensions.join(", ");
  return accept.join(", ");
}

/** The `accept` attribute value for a file input. */
export function acceptAttribute(accept: string[]): string {
  return accept.join(",");
}

/* -------------------------------------------------------------------------- */
/* Downloads                                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Hands a blob to the browser as a download and revokes the URL afterwards.
 *
 * The revoke is the part that gets forgotten. Without it every result stays
 * alive for the lifetime of the document, so a session spent converting images
 * accumulates hundreds of megabytes that no amount of navigation frees.
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const href = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = href;
  link.download = filename;
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  // A microtask is too early — Safari cancels the download if the URL is gone
  // before the navigation starts.
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}

/** Replaces a filename's extension, keeping any dots inside the stem. */
export function withExtension(filename: string, extension: string): string {
  const dot = filename.lastIndexOf(".");
  const stem = dot > 0 ? filename.slice(0, dot) : filename;
  return `${stem}.${extension.replace(/^\./, "")}`;
}

/** A filename that will not collide with the input. */
export function suffixed(filename: string, suffix: string, extension?: string): string {
  const dot = filename.lastIndexOf(".");
  const stem = dot > 0 ? filename.slice(0, dot) : filename;
  const ext = extension ?? (dot > 0 ? filename.slice(dot + 1) : "");
  return ext ? `${stem}-${suffix}.${ext}` : `${stem}-${suffix}`;
}

/* -------------------------------------------------------------------------- */
/* Page ranges                                                                */
/* -------------------------------------------------------------------------- */

export interface RangeResult {
  /** Zero-based page indices, in the order given, duplicates preserved. */
  pages: number[];
  error?: string;
}

/**
 * Parses "1-3, 7, 12-" the way every print dialogue does.
 *
 * One-based on the way in because that is what the page numbers say, zero-based
 * on the way out because that is what every API takes. Getting that boundary
 * wrong deletes the wrong page, which is the kind of mistake a user discovers
 * much later.
 */
export function parsePageRange(input: string, pageCount: number): RangeResult {
  const trimmed = input.trim();
  if (trimmed === "") return { pages: [], error: "No pages selected." };
  if (/^all$/i.test(trimmed)) {
    return { pages: Array.from({ length: pageCount }, (_unused, index) => index) };
  }

  const pages: number[] = [];
  for (const part of trimmed.split(",")) {
    const chunk = part.trim();
    if (chunk === "") continue;

    const range = /^(\d*)\s*-\s*(\d*)$/.exec(chunk);
    if (range) {
      const from = range[1] === "" ? 1 : Number(range[1]);
      const to = range[2] === "" ? pageCount : Number(range[2]);
      if (from < 1 || to > pageCount || from > to) {
        return {
          pages: [],
          error: `"${chunk}" is not a valid range for a ${pageCount}-page document.`,
        };
      }
      for (let page = from; page <= to; page++) pages.push(page - 1);
      continue;
    }

    const single = Number(chunk);
    if (!Number.isInteger(single) || single < 1 || single > pageCount) {
      return {
        pages: [],
        error: `"${chunk}" is not a page number in a ${pageCount}-page document.`,
      };
    }
    pages.push(single - 1);
  }

  if (pages.length === 0) return { pages: [], error: "No pages selected." };
  return { pages };
}

/** Renders zero-based indices back as a human page range. */
export function formatPageRange(pages: number[]): string {
  if (pages.length === 0) return "none";
  const sorted = [...new Set(pages)].sort((a, b) => a - b);
  const parts: string[] = [];
  let start = sorted[0];
  let previous = sorted[0];

  for (let i = 1; i <= sorted.length; i++) {
    const current = sorted[i];
    if (current === previous + 1) {
      previous = current;
      continue;
    }
    parts.push(start === previous ? `${start + 1}` : `${start + 1}-${previous + 1}`);
    start = current;
    previous = current;
  }

  return parts.join(", ");
}
