/**
 * CSS formatting and minification.
 *
 * Deliberately a tokeniser rather than a parser. A parser has to model the
 * grammar of every at-rule, every value syntax and every new feature, and
 * rejects anything it does not recognise — which means it breaks on CSS that
 * browsers accept. A tokeniser only needs to know where strings, comments and
 * blocks begin and end, which is stable, and it passes unknown syntax through
 * unchanged rather than throwing it away.
 *
 * That is the right trade for a formatter: preserving something it does not
 * understand is always better than deleting it.
 */

export interface CssFormatOptions {
  indent: number;
  /** Each selector in a comma-separated list on its own line. */
  selectorPerLine: boolean;
  /** A blank line between top-level rules. */
  blankLineBetweenRules: boolean;
  /** Keep comments. Off strips them, which is what a build step does. */
  keepComments: boolean;
}

export const CSS_DEFAULTS: CssFormatOptions = {
  indent: 2,
  selectorPerLine: true,
  blankLineBetweenRules: true,
  keepComments: true,
};

type CssTokenKind = "comment" | "string" | "block-open" | "block-close" | "semicolon" | "text";

interface CssToken {
  kind: CssTokenKind;
  value: string;
}

/**
 * Scans CSS into structural tokens.
 *
 * The three things that must not be scanned naively: a comment can contain a
 * brace, a string can contain a brace or a semicolon, and a `url()` can contain
 * an unquoted string with almost anything in it. Each gets its own state.
 */
export function tokenizeCss(input: string): CssToken[] {
  const tokens: CssToken[] = [];
  let buffer = "";
  let i = 0;

  const flush = () => {
    if (buffer) {
      tokens.push({ kind: "text", value: buffer });
      buffer = "";
    }
  };

  while (i < input.length) {
    const char = input[i];

    if (char === "/" && input[i + 1] === "*") {
      flush();
      const end = input.indexOf("*/", i + 2);
      const stop = end === -1 ? input.length : end + 2;
      tokens.push({ kind: "comment", value: input.slice(i, stop) });
      i = stop;
      continue;
    }

    if (char === '"' || char === "'") {
      let end = i + 1;
      while (end < input.length) {
        if (input[end] === "\\") end += 2;
        else if (input[end] === char) {
          end++;
          break;
        } else end++;
      }
      buffer += input.slice(i, end);
      i = end;
      continue;
    }

    // An unquoted url() can contain characters that would otherwise be
    // structural, so it is consumed whole.
    if (/^url\(/i.test(input.slice(i))) {
      const close = input.indexOf(")", i);
      const end = close === -1 ? input.length : close + 1;
      buffer += input.slice(i, end);
      i = end;
      continue;
    }

    if (char === "{") {
      flush();
      tokens.push({ kind: "block-open", value: "{" });
      i++;
      continue;
    }
    if (char === "}") {
      flush();
      tokens.push({ kind: "block-close", value: "}" });
      i++;
      continue;
    }
    if (char === ";") {
      flush();
      tokens.push({ kind: "semicolon", value: ";" });
      i++;
      continue;
    }

    buffer += char;
    i++;
  }

  flush();
  return tokens;
}

export function formatCss(input: string, options: CssFormatOptions): string {
  const tokens = tokenizeCss(input);
  const lines: string[] = [];
  let depth = 0;

  const pad = () => " ".repeat(depth * options.indent);

  for (const [index, token] of tokens.entries()) {
    switch (token.kind) {
      case "comment": {
        if (!options.keepComments) break;
        const text = token.value.trim();
        // A multi-line comment keeps its shape; its first line is re-indented
        // and the rest are left as written, because ASCII-art banners are
        // common and re-flowing them destroys them.
        lines.push(pad() + text.split("\n").join(`\n${pad()}`));
        break;
      }

      case "block-open": {
        const selector = normaliseSelector(previousText(tokens, index), options, pad());
        lines.push(`${selector} {`);
        depth++;
        break;
      }

      case "block-close": {
        const trailing = previousText(tokens, index).trim();
        // The last declaration in a block may have no trailing semicolon, and
        // it still needs the same property/value normalisation as the others.
        if (trailing) lines.push(`${pad()}${formatDeclaration(trailing)};`);
        depth = Math.max(0, depth - 1);
        lines.push(`${pad()}}`);
        if (depth === 0 && options.blankLineBetweenRules) lines.push("");
        break;
      }

      case "semicolon": {
        const declaration = previousText(tokens, index).trim();
        if (declaration) lines.push(`${pad()}${formatDeclaration(declaration)};`);
        break;
      }

      default:
        break;
    }
  }

  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

/** The text token immediately before position `index`, or empty. */
function previousText(tokens: CssToken[], index: number): string {
  const previous = tokens[index - 1];
  return previous && previous.kind === "text" ? previous.value : "";
}

function collapse(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

function normaliseSelector(raw: string, options: CssFormatOptions, pad: string): string {
  const selector = collapse(raw);
  if (!options.selectorPerLine || !selector.includes(",")) return pad + selector;
  // Splitting on a bare comma would break :is(a, b) and nth-child(2n, 3).
  return splitTopLevel(selector, ",")
    .map((part) => pad + part.trim())
    .join(",\n");
}

function formatDeclaration(raw: string): string {
  const declaration = collapse(raw);
  const colon = findTopLevelColon(declaration);
  if (colon === -1) return declaration;
  const property = declaration.slice(0, colon).trim();
  const value = declaration.slice(colon + 1).trim();
  return `${property}: ${value}`;
}

/**
 * Finds the colon that separates property from value.
 *
 * Not the first colon: `background: url(https://x)` has one inside the value,
 * and a custom property's value may contain anything at all.
 */
function findTopLevelColon(text: string): number {
  let depth = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === "(") depth++;
    else if (char === ")") depth--;
    else if (char === ":" && depth === 0) return i;
  }
  return -1;
}

function splitTopLevel(text: string, separator: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let current = "";
  for (const char of text) {
    if (char === "(" || char === "[") depth++;
    else if (char === ")" || char === "]") depth--;
    if (char === separator && depth === 0) {
      parts.push(current);
      current = "";
      continue;
    }
    current += char;
  }
  if (current.trim()) parts.push(current);
  return parts;
}

export interface CssMinifyResult {
  output: string;
  originalBytes: number;
  minifiedBytes: number;
  savedPercent: number;
}

export function minifyCss(input: string, keepImportantComments = true): CssMinifyResult {
  const tokens = tokenizeCss(input);
  let out = "";

  for (const token of tokens) {
    switch (token.kind) {
      case "comment":
        // `/*! … */` marks a licence header, which minifiers keep by convention
        // and which stripping may actually breach.
        if (keepImportantComments && token.value.startsWith("/*!")) out += token.value;
        break;
      case "text":
        out += collapse(token.value)
          // No space around the structural characters of a declaration.
          .replace(/\s*([:,>~+])\s*/g, "$1")
          // ...except in a selector, where > ~ + are combinators and a space
          // after a comma in a media query is harmless. Restore the one case
          // where removing the space changes meaning: `a +b` in a value.
          .replace(/\)([a-zA-Z])/g, ") $1");
        break;
      case "block-open":
        out = `${out.trimEnd()}{`;
        break;
      case "block-close":
        // The last declaration's semicolon is redundant before a closing brace.
        out = `${out.replace(/;$/, "")}}`;
        break;
      case "semicolon":
        out += ";";
        break;
    }
  }

  const output = out.replace(/;\}/g, "}").replace(/\s+/g, " ").replace(/ ?([{}:;,]) ?/g, "$1").trim();
  const originalBytes = new TextEncoder().encode(input).length;
  const minifiedBytes = new TextEncoder().encode(output).length;

  return {
    output,
    originalBytes,
    minifiedBytes,
    savedPercent: originalBytes === 0 ? 0 : Math.round((1 - minifiedBytes / originalBytes) * 100),
  };
}

export interface CssStats {
  rules: number;
  declarations: number;
  selectors: number;
  atRules: number;
  customProperties: number;
  /** The deepest selector, which is a useful specificity smell. */
  maxNesting: number;
}

export function analyseCss(input: string): CssStats {
  const tokens = tokenizeCss(input);
  const stats: CssStats = {
    rules: 0,
    declarations: 0,
    selectors: 0,
    atRules: 0,
    customProperties: 0,
    maxNesting: 0,
  };
  let depth = 0;

  for (const [index, token] of tokens.entries()) {
    if (token.kind === "block-open") {
      const selector = collapse(previousText(tokens, index));
      if (selector.startsWith("@")) stats.atRules++;
      else {
        stats.rules++;
        stats.selectors += splitTopLevel(selector, ",").length;
      }
      depth++;
      stats.maxNesting = Math.max(stats.maxNesting, depth);
    } else if (token.kind === "block-close") {
      // The last declaration in a block often has no semicolon, and counting
      // only semicolons undercounts every hand-written stylesheet by one per
      // rule.
      countDeclaration(collapse(previousText(tokens, index)), stats);
      depth = Math.max(0, depth - 1);
    } else if (token.kind === "semicolon") {
      countDeclaration(collapse(previousText(tokens, index)), stats);
    }
  }

  return stats;
}

function countDeclaration(declaration: string, stats: CssStats): void {
  if (!declaration || !declaration.includes(":")) return;
  stats.declarations++;
  if (declaration.startsWith("--")) stats.customProperties++;
}
