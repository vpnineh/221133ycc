/**
 * HTML formatting.
 *
 * HTML is not XML and formatting it as XML corrupts documents. Four differences
 * matter, and every one of them has produced a real bug in a formatter that
 * treated the two alike:
 *
 * 1. Void elements — `<br>`, `<img>`, `<input>` — have no closing tag. Indenting
 *    as if they opened a scope pushes the rest of the document one level right
 *    and never recovers.
 * 2. Raw text elements — `<script>`, `<style>`, `<textarea>`, `<pre>` — contain
 *    text that is not markup. A `<` inside a script is a less-than sign, and
 *    re-indenting the contents of a `<pre>` changes what the page renders.
 * 3. Whitespace between inline elements is significant. `<b>a</b> <i>b</i>` and
 *    `<b>a</b><i>b</i>` render differently, so a formatter may not insert or
 *    remove breaks freely inside a text flow.
 * 4. Closing tags are optional for several elements — `</li>`, `</p>`, `</td>` —
 *    so a parser that requires them rejects valid HTML.
 */

export interface HtmlFormatOptions {
  indent: number;
  /** Wrap attributes onto their own lines past this many. */
  attributeWrapCount: number;
  /** Preserve the contents of pre, textarea, script and style exactly. */
  preserveRawText: boolean;
  /** Keep comments. */
  keepComments: boolean;
}

export const HTML_DEFAULTS: HtmlFormatOptions = {
  indent: 2,
  attributeWrapCount: 4,
  preserveRawText: true,
  keepComments: true,
};

/** Elements with no closing tag, per the HTML spec's void element list. */
export const VOID_ELEMENTS = new Set([
  "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source",
  "track", "wbr",
]);

/** Elements whose content is text, not markup. */
export const RAW_TEXT_ELEMENTS = new Set(["script", "style", "textarea", "title", "pre"]);

/** Elements that participate in a text flow, where whitespace is significant. */
export const INLINE_ELEMENTS = new Set([
  "a", "abbr", "b", "bdi", "bdo", "br", "cite", "code", "data", "dfn", "em", "i", "kbd", "mark",
  "q", "rp", "rt", "ruby", "s", "samp", "small", "span", "strong", "sub", "sup", "time", "u",
  "var", "wbr", "img", "button", "input", "label", "select", "textarea",
]);

/** Elements whose closing tag may be omitted, so a stack must tolerate it. */
const OPTIONAL_CLOSE = new Set([
  "li", "dt", "dd", "p", "rt", "rp", "optgroup", "option", "colgroup", "caption", "thead",
  "tbody", "tfoot", "tr", "td", "th",
]);

type HtmlTokenKind = "doctype" | "comment" | "open" | "close" | "selfClosing" | "text" | "raw" | "cdata";

export interface HtmlToken {
  kind: HtmlTokenKind;
  raw: string;
  name?: string;
  /** For raw text elements, the untouched content. */
  content?: string;
}

export function tokenizeHtml(input: string): HtmlToken[] {
  const tokens: HtmlToken[] = [];
  let i = 0;

  while (i < input.length) {
    if (input[i] !== "<") {
      const next = input.indexOf("<", i);
      const end = next === -1 ? input.length : next;
      tokens.push({ kind: "text", raw: input.slice(i, end) });
      i = end;
      continue;
    }

    if (input.startsWith("<!--", i)) {
      const end = input.indexOf("-->", i);
      const stop = end === -1 ? input.length : end + 3;
      tokens.push({ kind: "comment", raw: input.slice(i, stop) });
      i = stop;
      continue;
    }

    if (/^<!doctype/i.test(input.slice(i))) {
      const end = input.indexOf(">", i);
      const stop = end === -1 ? input.length : end + 1;
      tokens.push({ kind: "doctype", raw: input.slice(i, stop) });
      i = stop;
      continue;
    }

    if (input.startsWith("<![CDATA[", i)) {
      const end = input.indexOf("]]>", i);
      const stop = end === -1 ? input.length : end + 3;
      tokens.push({ kind: "cdata", raw: input.slice(i, stop) });
      i = stop;
      continue;
    }

    const closing = /^<\/\s*([A-Za-z][-A-Za-z0-9_:.]*)\s*>/.exec(input.slice(i));
    if (closing) {
      tokens.push({ kind: "close", raw: closing[0], name: closing[1].toLowerCase() });
      i += closing[0].length;
      continue;
    }

    const opening = /^<([A-Za-z][-A-Za-z0-9_:.]*)/.exec(input.slice(i));
    if (opening) {
      // Scan to the tag's end, honouring quotes so an attribute value
      // containing > does not end the tag early.
      let end = i + opening[0].length;
      let quote: '"' | "'" | null = null;
      while (end < input.length) {
        const char = input[end];
        if (quote) {
          if (char === quote) quote = null;
        } else if (char === '"' || char === "'") {
          quote = char;
        } else if (char === ">") {
          end++;
          break;
        }
        end++;
      }

      const raw = input.slice(i, end);
      const name = opening[1].toLowerCase();
      const selfClosed = /\/\s*>$/.test(raw) || VOID_ELEMENTS.has(name);
      tokens.push({ kind: selfClosed ? "selfClosing" : "open", raw, name });
      i = end;

      // A raw text element's content runs to its matching close tag and is not
      // markup: a `<` inside a script is a less-than sign.
      if (!selfClosed && RAW_TEXT_ELEMENTS.has(name)) {
        const closeTag = new RegExp(`</\\s*${name}\\s*>`, "i");
        const rest = input.slice(i);
        const match = closeTag.exec(rest);
        const contentEnd = match ? i + match.index : input.length;
        if (contentEnd > i) {
          tokens.push({ kind: "raw", raw: input.slice(i, contentEnd), name, content: input.slice(i, contentEnd) });
        }
        i = contentEnd;
      }
      continue;
    }

    // A bare `<` that starts nothing: text, not markup.
    tokens.push({ kind: "text", raw: "<" });
    i++;
  }

  return tokens;
}

export function parseHtmlAttributes(raw: string): Array<{ name: string; value?: string; quote: string }> {
  const attributes: Array<{ name: string; value?: string; quote: string }> = [];
  const body = raw.replace(/^<[A-Za-z][-A-Za-z0-9_:.]*/, "").replace(/\/?\s*>$/, "");
  const pattern = /([^\s=/>]+)(?:\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;

  let match: RegExpExecArray | null;
  while ((match = pattern.exec(body)) !== null) {
    const [, name, , doubleQuoted, singleQuoted, unquoted] = match;
    if (!name.trim()) continue;
    if (doubleQuoted !== undefined) attributes.push({ name, value: doubleQuoted, quote: '"' });
    else if (singleQuoted !== undefined) attributes.push({ name, value: singleQuoted, quote: "'" });
    else if (unquoted !== undefined) attributes.push({ name, value: unquoted, quote: "" });
    else attributes.push({ name, quote: "" });
  }

  return attributes;
}

export function formatHtml(input: string, options: HtmlFormatOptions): string {
  const tokens = tokenizeHtml(input);
  const lines: string[] = [];
  const stack: string[] = [];
  let depth = 0;
  /** Buffered inline run, where whitespace is significant. */
  let inline = "";

  const pad = (level = depth) => " ".repeat(Math.max(0, level) * options.indent);

  const flushInline = () => {
    if (inline.trim()) lines.push(pad() + inline.trim().replace(/\s+/g, " "));
    inline = "";
  };

  for (const token of tokens) {
    switch (token.kind) {
      case "doctype":
        flushInline();
        lines.push(token.raw);
        break;

      case "comment":
        if (!options.keepComments) break;
        flushInline();
        lines.push(pad() + token.raw.trim());
        break;

      case "cdata":
        flushInline();
        lines.push(pad() + token.raw);
        break;

      case "text": {
        if (token.raw.trim() === "") {
          // Whitespace-only text between block elements is layout, not content;
          // between inline ones it is a real space.
          if (inline) inline += " ";
          break;
        }
        inline += token.raw;
        break;
      }

      case "raw": {
        // Preserved exactly. Re-indenting the contents of a <pre> changes the
        // rendered page, and re-indenting a script changes nothing visible but
        // breaks template literals and line-sensitive directives.
        flushInline();
        const content = options.preserveRawText
          ? token.raw.replace(/^\n/, "").replace(/\s+$/, "")
          : token.raw.trim();
        if (content) {
          const reindent = shouldReindent(stack[stack.length - 1], options);
          lines.push(
            reindent
              ? dedent(content)
                  .split("\n")
                  .map((line) => (line.trim() ? pad() + line : ""))
                  .join("\n")
              : content
          );
        }
        break;
      }

      case "selfClosing": {
        const rendered = renderTag(token, options, depth);
        // A tag wrapped across lines cannot go through the inline buffer, which
        // collapses whitespace and would put the attributes back on one line.
        if (INLINE_ELEMENTS.has(token.name ?? "") && !rendered.includes("\n")) {
          // Without trimming the indent, `a<br>b` becomes `a <br>b` — an
          // inserted space that the browser actually renders.
          inline += rendered.trimStart();
        } else {
          flushInline();
          lines.push(rendered);
        }
        break;
      }

      case "open": {
        const name = token.name!;
        const renderedOpen = renderTag(token, options, depth);
        if (INLINE_ELEMENTS.has(name) && !RAW_TEXT_ELEMENTS.has(name) && !renderedOpen.includes("\n")) {
          inline += renderedOpen.trimStart();
          stack.push(name);
          break;
        }
        flushInline();
        lines.push(renderedOpen);
        stack.push(name);
        depth++;
        break;
      }

      case "close": {
        const name = token.name!;
        if (INLINE_ELEMENTS.has(name) && !RAW_TEXT_ELEMENTS.has(name)) {
          inline += token.raw;
          if (stack[stack.length - 1] === name) stack.pop();
          break;
        }

        // Unwind through elements whose closing tag was omitted, which is legal
        // for li, p, td and several others.
        while (stack.length > 0 && stack[stack.length - 1] !== name) {
          const top = stack[stack.length - 1];
          if (!OPTIONAL_CLOSE.has(top) && !INLINE_ELEMENTS.has(top)) break;
          stack.pop();
          if (!INLINE_ELEMENTS.has(top)) depth = Math.max(0, depth - 1);
        }

        flushInline();
        if (stack[stack.length - 1] === name) {
          stack.pop();
          depth = Math.max(0, depth - 1);
        }
        lines.push(pad() + token.raw);
        break;
      }
    }
  }

  flushInline();
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function shouldReindent(parent: string | undefined, options: HtmlFormatOptions): boolean {
  // <pre> and <textarea> render their whitespace, so it must not be touched.
  // A <script> or <style> body can be re-indented safely.
  if (!options.preserveRawText) return true;
  return parent === "script" || parent === "style";
}

function dedent(text: string): string {
  const lines = text.split("\n");
  const indents = lines
    .filter((line) => line.trim())
    .map((line) => line.length - line.trimStart().length);
  const min = indents.length ? Math.min(...indents) : 0;
  return lines.map((line) => line.slice(min)).join("\n");
}

function renderTag(token: HtmlToken, options: HtmlFormatOptions, depth: number): string {
  const pad = " ".repeat(Math.max(0, depth) * options.indent);
  const name = token.name!;
  const attributes = parseHtmlAttributes(token.raw);
  const selfClosingMark = token.kind === "selfClosing" && /\/\s*>$/.test(token.raw) ? " /" : "";

  if (attributes.length === 0) return `${pad}<${name}${selfClosingMark}>`;

  const rendered = attributes.map((attribute) => {
    if (attribute.value === undefined) return attribute.name;
    // Quotes are normalised to double, except where the value contains one.
    const quote = attribute.value.includes('"') ? "'" : '"';
    return `${attribute.name}=${quote}${attribute.value}${quote}`;
  });

  const single = `${pad}<${name} ${rendered.join(" ")}${selfClosingMark}>`;
  if (attributes.length < options.attributeWrapCount && single.length <= 100) return single;

  const attributePad = pad + " ".repeat(options.indent);
  return `${pad}<${name}\n${rendered.map((line) => attributePad + line).join("\n")}\n${pad}${selfClosingMark.trim()}>`;
}

export interface HtmlStats {
  elements: number;
  /** Elements whose closing tag is missing, which is legal for some and not others. */
  unclosed: string[];
  /** Images with no alt attribute, which is an accessibility failure. */
  missingAlt: number;
  inlineStyles: number;
  inlineScripts: number;
}

export function analyseHtml(input: string): HtmlStats {
  const tokens = tokenizeHtml(input);
  const stats: HtmlStats = {
    elements: 0,
    unclosed: [],
    missingAlt: 0,
    inlineStyles: 0,
    inlineScripts: 0,
  };
  const stack: string[] = [];

  for (const token of tokens) {
    if (token.kind === "selfClosing" || token.kind === "open") {
      stats.elements++;
      const attributes = parseHtmlAttributes(token.raw);
      if (token.name === "img" && !attributes.some((a) => a.name.toLowerCase() === "alt")) {
        stats.missingAlt++;
      }
      if (attributes.some((a) => a.name.toLowerCase() === "style")) stats.inlineStyles++;
      if (token.name === "script" && !attributes.some((a) => a.name.toLowerCase() === "src")) {
        stats.inlineScripts++;
      }
      if (token.kind === "open") stack.push(token.name!);
    } else if (token.kind === "close") {
      const index = stack.lastIndexOf(token.name!);
      if (index !== -1) {
        for (const name of stack.slice(index + 1)) {
          if (!OPTIONAL_CLOSE.has(name)) stats.unclosed.push(name);
        }
        stack.length = index;
      }
    }
  }

  for (const name of stack) {
    if (!OPTIONAL_CLOSE.has(name)) stats.unclosed.push(name);
  }

  return stats;
}

export function minifyHtml(input: string, keepComments = false): string {
  const tokens = tokenizeHtml(input);
  let out = "";

  for (const [index, token] of tokens.entries()) {
    switch (token.kind) {
      case "comment":
        // A conditional comment is markup to old IE and must survive.
        if (keepComments || /^<!--\[if/i.test(token.raw)) out += token.raw;
        break;
      case "raw":
        out += token.raw;
        break;
      case "text": {
        if (token.raw.trim() === "") {
          // Whitespace between inline elements is a rendered space; between
          // block elements it is not.
          const previous = tokens[index - 1];
          const next = tokens[index + 1];
          const inlineNeighbour =
            (previous && isInline(previous)) || (next && isInline(next));
          if (inlineNeighbour) out += " ";
          break;
        }
        out += token.raw.replace(/\s+/g, " ");
        break;
      }
      default:
        out += token.raw.replace(/\s+/g, " ").replace(/\s+>/, ">");
        break;
    }
  }

  return out.trim();
}

function isInline(token: HtmlToken): boolean {
  if (token.kind === "text") return token.raw.trim() !== "";
  return token.name !== undefined && INLINE_ELEMENTS.has(token.name);
}
