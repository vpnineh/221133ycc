/**
 * SQL formatting.
 *
 * A formatter that works by regular expression breaks on the first string
 * literal containing the word `FROM`, and on the first comment containing an
 * unbalanced quote. So this tokenises first: strings, identifiers, comments,
 * numbers, operators and keywords are separate things, and only keyword tokens
 * influence layout.
 *
 * The other decision is that formatting is lossless for content. Comments keep
 * their position and their text, string literals keep every byte including
 * whitespace, and identifier quoting is never changed — a formatter that
 * "tidies" `"user"` into `user` has changed which object the query refers to on
 * a case-sensitive database.
 */

export type SqlDialect = "standard" | "postgres" | "mysql" | "tsql";

export interface SqlFormatOptions {
  dialect: SqlDialect;
  indent: number;
  /** Uppercase keywords, which is the convention almost every style guide uses. */
  uppercaseKeywords: boolean;
  /** Put each selected column on its own line. */
  columnPerLine: boolean;
  /** Put the comma before the column rather than after it. */
  leadingCommas: boolean;
}

export const SQL_DEFAULTS: SqlFormatOptions = {
  dialect: "standard",
  indent: 2,
  uppercaseKeywords: true,
  columnPerLine: true,
  leadingCommas: false,
};

export type SqlTokenKind =
  | "keyword"
  | "identifier"
  | "quotedIdentifier"
  | "string"
  | "number"
  | "operator"
  | "punctuation"
  | "comment"
  | "whitespace"
  | "parameter";

export interface SqlToken {
  kind: SqlTokenKind;
  value: string;
  /** Uppercased, for keyword comparisons. */
  upper: string;
}

/** Keywords that start a new top-level clause, so each begins a line. */
const CLAUSE_KEYWORDS = new Set([
  "SELECT", "FROM", "WHERE", "GROUP", "HAVING", "ORDER", "LIMIT", "OFFSET", "UNION", "INTERSECT",
  "EXCEPT", "INSERT", "UPDATE", "DELETE", "VALUES", "SET", "RETURNING", "WITH", "WINDOW", "FETCH",
]);

/** Join keywords, which begin a line but read better indented under FROM. */
const JOIN_KEYWORDS = new Set(["JOIN", "INNER", "LEFT", "RIGHT", "FULL", "CROSS", "NATURAL", "LATERAL"]);

/** Boolean connectives, which begin a continuation line inside a clause. */
const CONNECTIVES = new Set(["AND", "OR"]);

const KEYWORDS = new Set([
  ...CLAUSE_KEYWORDS, ...JOIN_KEYWORDS, ...CONNECTIVES,
  "ALL", "ALTER", "ANALYZE", "ANY", "AS", "ASC", "BEGIN", "BETWEEN", "BY", "CASCADE", "CASE",
  "CAST", "CHECK", "COLUMN", "COMMIT", "CONFLICT", "CONSTRAINT", "CREATE", "CURRENT", "DATABASE",
  "DEFAULT", "DESC", "DISTINCT", "DO", "DROP", "ELSE", "END", "ESCAPE", "EXISTS", "EXPLAIN",
  "FIRST", "FOLLOWING", "FOR", "FOREIGN", "GRANT", "IF", "ILIKE", "IN", "INDEX", "INTO", "IS",
  "KEY", "LAST", "LIKE", "MATERIALIZED", "NOT", "NOTHING", "NULL", "NULLS", "ON", "ONLY", "OVER",
  "PARTITION", "PRECEDING", "PRIMARY", "RANGE", "RECURSIVE", "REFERENCES", "RENAME", "REPLACE",
  "ROLLBACK", "ROW", "ROWS", "SIMILAR", "TABLE", "TEMPORARY", "THEN", "TO", "TRANSACTION",
  "TRUNCATE", "UNBOUNDED", "UNIQUE", "USING", "VACUUM", "VIEW", "WHEN", "WHILE",
]);

/**
 * Tokenises SQL in one pass.
 *
 * The quoting rules differ by dialect and getting them wrong changes meaning:
 * MySQL's backtick is an identifier quote, T-SQL uses square brackets, and
 * Postgres has dollar-quoted strings whose delimiter is user-defined. A single
 * pass that knows all of them is simpler than three passes that each know one.
 */
export function tokenizeSql(input: string, dialect: SqlDialect): SqlToken[] {
  const tokens: SqlToken[] = [];
  let i = 0;

  const push = (kind: SqlTokenKind, value: string) => {
    tokens.push({ kind, value, upper: value.toUpperCase() });
  };

  while (i < input.length) {
    const char = input[i];

    if (/\s/.test(char)) {
      let end = i;
      while (end < input.length && /\s/.test(input[end])) end++;
      push("whitespace", input.slice(i, end));
      i = end;
      continue;
    }

    // Line comment. The rest of the line is content, whatever it contains.
    if (char === "-" && input[i + 1] === "-") {
      const end = input.indexOf("\n", i);
      push("comment", input.slice(i, end === -1 ? input.length : end));
      i = end === -1 ? input.length : end;
      continue;
    }
    if (char === "#" && dialect === "mysql") {
      const end = input.indexOf("\n", i);
      push("comment", input.slice(i, end === -1 ? input.length : end));
      i = end === -1 ? input.length : end;
      continue;
    }

    // Block comment. Standard SQL nests them, unlike C.
    if (char === "/" && input[i + 1] === "*") {
      let depth = 1;
      let end = i + 2;
      while (end < input.length && depth > 0) {
        if (input[end] === "/" && input[end + 1] === "*") {
          depth++;
          end += 2;
        } else if (input[end] === "*" && input[end + 1] === "/") {
          depth--;
          end += 2;
        } else {
          end++;
        }
      }
      push("comment", input.slice(i, end));
      i = end;
      continue;
    }

    // Dollar-quoted string, whose delimiter is whatever is between the dollars.
    if (char === "$" && dialect === "postgres") {
      const tagMatch = /^\$([A-Za-z_][A-Za-z0-9_]*)?\$/.exec(input.slice(i));
      if (tagMatch) {
        const closing = input.indexOf(tagMatch[0], i + tagMatch[0].length);
        const end = closing === -1 ? input.length : closing + tagMatch[0].length;
        push("string", input.slice(i, end));
        i = end;
        continue;
      }
    }

    // Single-quoted string. The escape is a doubled quote in standard SQL; MySQL
    // also honours a backslash.
    if (char === "'") {
      let end = i + 1;
      while (end < input.length) {
        if (input[end] === "\\" && dialect === "mysql") end += 2;
        else if (input[end] === "'" && input[end + 1] === "'") end += 2;
        else if (input[end] === "'") {
          end++;
          break;
        } else end++;
      }
      push("string", input.slice(i, end));
      i = end;
      continue;
    }

    // Quoted identifiers. Never unquoted by the formatter: "user" and user are
    // different objects on a case-sensitive database.
    const identifierQuote =
      char === '"' ? '"' : char === "`" && dialect === "mysql" ? "`" : char === "[" && dialect === "tsql" ? "]" : null;
    if (identifierQuote) {
      const closing = char === "[" ? "]" : identifierQuote;
      let end = i + 1;
      while (end < input.length) {
        if (input[end] === closing && input[end + 1] === closing) end += 2;
        else if (input[end] === closing) {
          end++;
          break;
        } else end++;
      }
      push("quotedIdentifier", input.slice(i, end));
      i = end;
      continue;
    }

    // Bind parameters, in every spelling anyone uses.
    const parameter = /^(\$\d+|\?|:[A-Za-z_][A-Za-z0-9_]*|@[A-Za-z_][A-Za-z0-9_]*)/.exec(
      input.slice(i)
    );
    if (parameter) {
      push("parameter", parameter[0]);
      i += parameter[0].length;
      continue;
    }

    const number = /^\d+(\.\d+)?([eE][-+]?\d+)?/.exec(input.slice(i));
    if (number) {
      push("number", number[0]);
      i += number[0].length;
      continue;
    }

    const word = /^[A-Za-z_][A-Za-z0-9_$]*/.exec(input.slice(i));
    if (word) {
      const upper = word[0].toUpperCase();
      push(KEYWORDS.has(upper) ? "keyword" : "identifier", word[0]);
      i += word[0].length;
      continue;
    }

    // Multi-character operators first, so <= is one token rather than two.
    const operator = /^(<=>|!=|<>|<=|>=|\|\||::|->>|->|#>>|#>|:=)/.exec(input.slice(i));
    if (operator) {
      push("operator", operator[0]);
      i += operator[0].length;
      continue;
    }

    if ("()[],;".includes(char)) {
      push("punctuation", char);
      i++;
      continue;
    }

    push("operator", char);
    i++;
  }

  return tokens;
}

export function formatSql(input: string, options: SqlFormatOptions): string {
  const tokens = tokenizeSql(input, options.dialect).filter((token) => token.kind !== "whitespace");
  if (tokens.length === 0) return "";

  const pad = (level: number) => " ".repeat(Math.max(0, level) * options.indent);
  const lines: string[] = [];
  let current = "";
  let depth = 0;
  /**
   * Parenthesis nesting, tracked separately from indentation.
   *
   * These are not the same thing and conflating them is what makes a formatter
   * treat `AND` inside `(y = 2 AND z = 3)` as a new clause: that AND is part of
   * an expression and belongs on the line it is on.
   */
  let parenDepth = 0;
  let inSelectList = false;

  const flush = () => {
    if (current.trim()) lines.push(current.replace(/\s+$/, ""));
    current = "";
  };

  const startLine = (level: number) => {
    flush();
    current = pad(level);
  };

  const append = (text: string, spaceBefore = true) => {
    if (current.trim() === "") current += text;
    else current += (spaceBefore ? " " : "") + text;
  };

  for (let index = 0; index < tokens.length; index++) {
    const token = tokens[index];
    const next = tokens[index + 1];
    const rendered =
      token.kind === "keyword" && options.uppercaseKeywords ? token.upper : token.value;

    if (token.kind === "comment") {
      // A comment that was on its own line stays on its own line.
      if (token.value.startsWith("--") || token.value.startsWith("#")) {
        if (current.trim()) append(rendered);
        else {
          startLine(depth);
          append(rendered, false);
          flush();
        }
      } else {
        append(rendered);
      }
      continue;
    }

    if (token.kind === "punctuation") {
      if (token.value === "(") {
        append("(", shouldSpaceBeforeParen(tokens[index - 1]));
        parenDepth++;
        continue;
      }
      if (token.value === ")") {
        parenDepth = Math.max(0, parenDepth - 1);
        append(")", false);
        continue;
      }
      if (token.value === ",") {
        if (inSelectList && options.columnPerLine && parenDepth === 0) {
          if (options.leadingCommas) {
            flush();
            current = `${pad(depth + 1)},`;
          } else {
            append(",", false);
            startLine(depth + 1);
          }
        } else {
          append(",", false);
        }
        continue;
      }
      if (token.value === ";") {
        append(";", false);
        flush();
        lines.push("");
        depth = 0;
        parenDepth = 0;
        inSelectList = false;
        continue;
      }
      append(token.value, false);
      continue;
    }

    if (token.kind === "keyword") {
      // ORDER BY and GROUP BY are two tokens and one clause.
      if ((token.upper === "BY" || token.upper === "ALL") && lines.length + current.length > 0) {
        append(rendered);
        continue;
      }

      if (CLAUSE_KEYWORDS.has(token.upper)) {
        startLine(depth);
        append(rendered, false);
        inSelectList = token.upper === "SELECT";
        if (token.upper === "SELECT" && options.columnPerLine) {
          const following = next?.upper;
          if (following !== "DISTINCT" && following !== "*") startLine(depth + 1);
        }
        continue;
      }

      if (JOIN_KEYWORDS.has(token.upper)) {
        // LEFT OUTER JOIN is one clause spelled with three keywords, so only
        // the first of a run starts a line.
        const previous = tokens[index - 1];
        if (!previous || !JOIN_KEYWORDS.has(previous.upper)) {
          startLine(depth);
          append(rendered, false);
        } else {
          append(rendered);
        }
        inSelectList = false;
        continue;
      }

      if (CONNECTIVES.has(token.upper)) {
        // A connective inside parentheses is part of an expression, not a new
        // line in the clause.
        if (parenDepth === 0) {
          startLine(depth + 1);
          append(rendered, false);
        } else {
          append(rendered);
        }
        continue;
      }

      if (token.upper === "ON" || token.upper === "USING") {
        append(rendered);
        continue;
      }

      append(rendered);
      continue;
    }

    append(token.value, shouldSpaceBefore(tokens[index - 1], token));
  }

  flush();
  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

function shouldSpaceBeforeParen(previous: SqlToken | undefined): boolean {
  if (!previous) return false;
  // A function call has no space before its parenthesis; a keyword does.
  if (previous.kind === "identifier") return false;
  if (previous.kind === "punctuation" && previous.value === "(") return false;
  return true;
}

function shouldSpaceBefore(previous: SqlToken | undefined, token: SqlToken): boolean {
  if (!previous) return false;
  if (previous.kind === "punctuation" && previous.value === "(") return false;
  if (token.kind === "punctuation" && [")", ",", ";"].includes(token.value)) return false;
  if (previous.kind === "operator" && previous.value === ".") return false;
  if (token.kind === "operator" && token.value === ".") return false;
  return true;
}

/** Compresses a query to one line, preserving strings and comments exactly. */
export function minifySql(input: string, dialect: SqlDialect): string {
  const tokens = tokenizeSql(input, dialect);
  let out = "";

  for (const [index, token] of tokens.entries()) {
    if (token.kind === "whitespace") {
      // Collapse to one space, but only where removing it would join two words.
      const previous = tokens[index - 1];
      const next = tokens[index + 1];
      const needed =
        previous &&
        next &&
        /[A-Za-z0-9_$]$/.test(previous.value) &&
        /^[A-Za-z0-9_$]/.test(next.value);
      if (needed) out += " ";
      continue;
    }
    if (token.kind === "comment" && (token.value.startsWith("--") || token.value.startsWith("#"))) {
      // A line comment swallows everything to the newline, so on one line it
      // would comment out the rest of the query. It has to become a block.
      out += `/*${token.value.replace(/^(--|#)\s?/, "")}*/`;
      continue;
    }
    out += token.value;
  }

  return out.trim();
}
