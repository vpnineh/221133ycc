/**
 * Hashing in the browser, using SubtleCrypto where it exists and hand-written
 * code where it does not.
 *
 * SubtleCrypto deliberately omits MD5, because MD5 is broken: collisions can be
 * produced in seconds on a laptop, and MD5 certificate collisions were used in
 * the wild by Flame in 2012. It is still everywhere in checksums, ETags and
 * legacy protocols, so it is implemented here rather than left out — with the
 * status attached to the output rather than buried in a footnote.
 *
 * The distinction that matters more than the algorithm: a hash is not a
 * password hash. SHA-256 is designed to be fast, and fast is exactly wrong for
 * a password, where the defence is being slow. Anything on this page is the
 * wrong tool for storing a password; that job wants bcrypt, scrypt or Argon2.
 */

export type HashAlgorithm = "MD5" | "SHA-1" | "SHA-256" | "SHA-384" | "SHA-512" | "CRC32";

export interface AlgorithmInfo {
  id: HashAlgorithm;
  label: string;
  bits: number;
  /** Honest security status, shown next to every result. */
  status: "broken" | "legacy" | "secure" | "not-a-hash";
  note: string;
}

export const ALGORITHMS: AlgorithmInfo[] = [
  {
    id: "MD5",
    label: "MD5",
    bits: 128,
    status: "broken",
    note: "Collisions are practical on a laptop and have been used in real attacks. Fine as a non-security checksum; never for signatures, integrity against an adversary, or deduplication of untrusted input.",
  },
  {
    id: "SHA-1",
    label: "SHA-1",
    bits: 160,
    status: "broken",
    note: "SHAttered produced a real collision in 2017 and the cost has fallen since. Browsers and certificate authorities have dropped it. Git still uses it for object names, which is a compatibility decision rather than a security one.",
  },
  {
    id: "SHA-256",
    label: "SHA-256",
    bits: 256,
    status: "secure",
    note: "The current default for integrity and signatures. No practical attack. Fast by design, which is why it is the wrong choice for hashing a password.",
  },
  {
    id: "SHA-384",
    label: "SHA-384",
    bits: 384,
    status: "secure",
    note: "SHA-512 truncated, which makes it immune to the length-extension attack that affects SHA-256. Chosen where that property matters.",
  },
  {
    id: "SHA-512",
    label: "SHA-512",
    bits: 512,
    status: "secure",
    note: "Faster than SHA-256 on 64-bit hardware, despite the larger output. Worth preferring where the extra length is not a cost.",
  },
  {
    id: "CRC32",
    label: "CRC32",
    bits: 32,
    status: "not-a-hash",
    note: "An error-detecting checksum, not a hash. Trivial to forge deliberately and collides by accident after about 65,000 inputs. Correct for catching a corrupted transfer and wrong for everything else.",
  },
];

export function algorithmInfo(id: HashAlgorithm): AlgorithmInfo {
  return ALGORITHMS.find((entry) => entry.id === id)!;
}

export function toHex(bytes: Uint8Array): string {
  let out = "";
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0");
  return out;
}

export function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

export async function hashBytes(data: Uint8Array, algorithm: HashAlgorithm): Promise<Uint8Array> {
  if (algorithm === "MD5") return md5(data);
  if (algorithm === "CRC32") {
    const value = crc32(data);
    return new Uint8Array([
      (value >>> 24) & 0xff,
      (value >>> 16) & 0xff,
      (value >>> 8) & 0xff,
      value & 0xff,
    ]);
  }
  const buffer = await crypto.subtle.digest(algorithm, data as BufferSource);
  return new Uint8Array(buffer);
}

export async function hashText(text: string, algorithm: HashAlgorithm): Promise<Uint8Array> {
  // UTF-8, always. A hash of "café" differs between UTF-8 and Latin-1, and the
  // mismatch is a recurring cause of signatures that verify locally and fail in
  // production.
  return hashBytes(new TextEncoder().encode(text), algorithm);
}

/**
 * HMAC, which is not "hash the key and the message together".
 *
 * Naive constructions like `H(key || message)` are vulnerable to length
 * extension on Merkle–Damgård hashes: an attacker who knows `H(key || m)` and
 * the length of the key can compute `H(key || m || padding || m2)` without ever
 * seeing the key. HMAC's nested inner and outer construction is what prevents
 * that, which is why it exists as a separate primitive.
 */
export async function hmac(
  key: string,
  message: string,
  algorithm: Exclude<HashAlgorithm, "MD5" | "CRC32">
): Promise<Uint8Array> {
  const imported = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(key) as BufferSource,
    { name: "HMAC", hash: algorithm },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    imported,
    new TextEncoder().encode(message) as BufferSource
  );
  return new Uint8Array(signature);
}

/* -------------------------------------------------------------------------- */
/* CRC32                                                                      */
/* -------------------------------------------------------------------------- */

let crcTable: Uint32Array | null = null;

function buildCrcTable(): Uint32Array {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let value = i;
    for (let bit = 0; bit < 8; bit++) {
      // 0xEDB88320 is the reversed form of the IEEE 802.3 polynomial, which is
      // the one zip, gzip and PNG all use.
      value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    }
    table[i] = value >>> 0;
  }
  return table;
}

export function crc32(data: Uint8Array): number {
  crcTable ??= buildCrcTable();
  let crc = 0xffffffff;
  for (const byte of data) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

/* -------------------------------------------------------------------------- */
/* MD5 (RFC 1321)                                                             */
/* -------------------------------------------------------------------------- */

const MD5_S = [
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
];

// K[i] = floor(2^32 x |sin(i + 1)|), per the RFC. Precomputed rather than
// derived at load: Math.sin is not required to be bit-identical across engines.
const MD5_K = new Uint32Array(64);
for (let i = 0; i < 64; i++) MD5_K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;

function rotateLeft(value: number, shift: number): number {
  return ((value << shift) | (value >>> (32 - shift))) >>> 0;
}

/** MD5 per RFC 1321. Present because SubtleCrypto refuses to implement it. */
export function md5(input: Uint8Array): Uint8Array {
  const bitLength = input.length * 8;
  // Pad to 56 mod 64, then eight bytes of little-endian length.
  const paddedLength = ((input.length + 8) >> 6 << 6) + 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(input);
  padded[input.length] = 0x80;

  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, bitLength >>> 0, true);
  view.setUint32(paddedLength - 4, Math.floor(bitLength / 0x100000000), true);

  let a0 = 0x67452301;
  let b0 = 0xefcdab89;
  let c0 = 0x98badcfe;
  let d0 = 0x10325476;

  for (let offset = 0; offset < paddedLength; offset += 64) {
    const words = new Uint32Array(16);
    for (let i = 0; i < 16; i++) words[i] = view.getUint32(offset + i * 4, true);

    let [a, b, c, d] = [a0, b0, c0, d0];

    for (let i = 0; i < 64; i++) {
      let f: number;
      let g: number;
      if (i < 16) {
        f = (b & c) | (~b & d);
        g = i;
      } else if (i < 32) {
        f = (d & b) | (~d & c);
        g = (5 * i + 1) % 16;
      } else if (i < 48) {
        f = b ^ c ^ d;
        g = (3 * i + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        g = (7 * i) % 16;
      }

      const temp = d;
      d = c;
      c = b;
      const sum = (a + f + MD5_K[i] + words[g]) >>> 0;
      b = (b + rotateLeft(sum, MD5_S[i])) >>> 0;
      a = temp;
    }

    a0 = (a0 + a) >>> 0;
    b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0;
    d0 = (d0 + d) >>> 0;
  }

  const out = new Uint8Array(16);
  const outView = new DataView(out.buffer);
  outView.setUint32(0, a0, true);
  outView.setUint32(4, b0, true);
  outView.setUint32(8, c0, true);
  outView.setUint32(12, d0, true);
  return out;
}
