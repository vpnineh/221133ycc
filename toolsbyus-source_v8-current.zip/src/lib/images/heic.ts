/**
 * HEIC decoding — the one place on this site where a WebAssembly codec earns
 * its download.
 *
 * Everywhere else the argument in `./index.ts` holds: the browser already has
 * JPEG, PNG and WebP decoders written in C, and shipping our own would be
 * megabytes spent to do worse. HEIC is the exception, and it is not a close
 * call. Apple made HEIC the iPhone's default photo format in 2017, and outside
 * Safari no browser will decode one: HEIC wraps HEVC, HEVC is patent-encumbered,
 * and Chrome and Firefox have declined to ship a decoder for it. So the choice
 * for a "HEIC to JPG" tool is a real decoder or a page that fails for most of
 * the people who open it.
 *
 * The cost is contained rather than avoided:
 *
 * - The decoder is `import()`ed, and only after a native decode has already
 *   failed. A visitor using any other tool never downloads a byte of it, and
 *   nor does a Safari user, whose browser decodes HEIC natively.
 * - The build used is `libheif-bundle.mjs`, which carries its WebAssembly
 *   inline as base64. That means no second network request and no `.wasm` asset
 *   to place correctly in a static export — it compiles from memory, which the
 *   site's `script-src 'wasm-unsafe-eval'` permits and its `connect-src 'self'`
 *   would otherwise make fragile.
 * - The module instance is cached, so converting forty photos compiles it once.
 *
 * libheif is LGPL-3.0. It is used unmodified, loaded as a separate chunk, and
 * its licence and upstream source are recorded in ASSUMPTIONS.md.
 */

/** Fourcc at an offset, or "" if the buffer is too short. */
function fourcc(bytes: Uint8Array, offset: number): string {
  if (bytes.length < offset + 4) return "";
  return String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
}

/**
 * Brands that mean "HEIF image, HEVC inside".
 *
 * `mif1` and `msf1` are the generic HEIF brands; the `he**` family is the
 * HEVC-specific set. AVIF (`avif`, `avis`) is deliberately absent: it is the
 * same container, but browsers decode it natively, and claiming a failed AVIF
 * is a HEIC would produce a wrong and confusing message.
 */
const HEIF_BRANDS = new Set([
  "heic",
  "heix",
  "heim",
  "heis",
  "hevc",
  "hevx",
  "hevm",
  "hevs",
  "mif1",
  "msf1",
]);

const NOT_HEIF_BRANDS = new Set(["avif", "avis"]);

/**
 * Detects HEIC from the bytes rather than from the filename.
 *
 * A file's extension is a claim, not evidence: a `.heic` that is really a JPEG
 * is common enough (some tools rename rather than convert), and a HEIC saved as
 * `.jpg` happens on every share sheet that does the reverse. The container is
 * ISOBMFF, so the answer is in the `ftyp` box at the start of the file: a major
 * brand, then a list of compatible brands. Both are checked, because an iPhone
 * HEIC's major brand is `heic` while a Google Photos export's is `mif1` with
 * `heic` only in the compatible list.
 */
export function looksLikeHeic(head: Uint8Array): boolean {
  if (head.length < 12) return false;
  if (fourcc(head, 4) !== "ftyp") return false;

  const major = fourcc(head, 8);
  if (NOT_HEIF_BRANDS.has(major)) return false;
  if (HEIF_BRANDS.has(major)) return true;

  // Compatible brands: 4 bytes each, from offset 16 to the end of the ftyp box.
  const boxSize = new DataView(head.buffer, head.byteOffset, head.byteLength).getUint32(0);
  const end = Math.min(boxSize, head.length);
  for (let offset = 16; offset + 4 <= end; offset += 4) {
    const brand = fourcc(head, offset);
    if (NOT_HEIF_BRANDS.has(brand)) return false;
    if (HEIF_BRANDS.has(brand)) return true;
  }
  return false;
}

/**
 * Pixel ceiling for a HEIC decode.
 *
 * Decoding produces RGBA at four bytes a pixel, so a 48-megapixel photo — which
 * a recent iPhone in ProRAW mode really does produce — is 192 MB of one
 * contiguous buffer, before the canvas that receives it. Refusing with a
 * sentence beats a tab the browser kills without one.
 */
export const MAX_HEIC_PIXELS = 50_000_000;

/* -------------------------------------------------------------------------- */
/* The decoder                                                                */
/* -------------------------------------------------------------------------- */

/** The slice of libheif's surface this file uses. */
interface HeifImage {
  get_width(): number;
  get_height(): number;
  display(target: ImageData, done: (result: ImageData | null) => void): void;
  free(): void;
}

interface HeifDecoder {
  decode(bytes: Uint8Array): HeifImage[];
}

export interface HeifModule {
  HeifDecoder: new () => HeifDecoder;
}

let cached: Promise<HeifModule> | null = null;

/**
 * Loads and caches the decoder.
 *
 * The failure path matters as much as the success one: on a slow connection
 * this is a two-megabyte download, and if it fails the user needs to be told
 * that rather than watching a spinner. The cache is cleared on failure so a
 * retry is a real retry rather than a replay of the same rejected promise.
 */
export async function loadHeif(): Promise<HeifModule> {
  if (!cached) {
    cached = import("libheif-js/libheif-wasm/libheif-bundle.mjs")
      .then((module) => {
        const factory = (module as { default: () => HeifModule | Promise<HeifModule> }).default;
        return factory();
      })
      .catch((caught: unknown) => {
        cached = null;
        throw new Error(
          `The HEIC decoder could not be loaded (${
            caught instanceof Error ? caught.message : String(caught)
          }). It is about two megabytes and is fetched only when a HEIC file is dropped, so this usually means the download was interrupted — try again.`
        );
      });
  }
  return cached;
}

/**
 * Decodes a HEIC file to a bitmap.
 *
 * libheif's JavaScript wrapper reports failure by returning an empty array and
 * writing to the console, which is no use to anyone looking at the page, so
 * every branch here turns into a thrown message. `display` is callback-based
 * and defers through a `setTimeout`, so it is wrapped rather than awaited.
 *
 * Every handle is freed in a `finally`. They are pointers into the WebAssembly
 * heap, and that heap does not shrink: leak them across a batch of forty photos
 * and the module's memory grows until an allocation fails.
 */
export async function decodeHeic(bytes: Uint8Array, override?: HeifModule): Promise<ImageBitmap> {
  const library = override ?? (await loadHeif());
  const decoder = new library.HeifDecoder();

  const images = decoder.decode(bytes);
  if (images.length === 0) {
    throw new Error(
      "This file starts like a HEIC but no image could be read from it. A HEIC that has been truncated by an incomplete transfer, or re-saved by a tool that did not finish, ends up like this."
    );
  }

  // A "live photo" or a burst is several images in one container. The first
  // top-level image is the one the camera roll shows, which is the one the user
  // means by "the photo".
  const image = images[0];
  try {
    const width = image.get_width();
    const height = image.get_height();
    if (!(width > 0 && height > 0)) {
      throw new Error("The HEIC file reports a zero-sized image, so there is nothing to convert.");
    }
    if (width * height > MAX_HEIC_PIXELS) {
      throw new Error(
        `That photo is ${width} × ${height}, which is ${Math.round(
          (width * height) / 1e6
        )} megapixels. Decoding it needs ${Math.round(
          (width * height * 4) / (1024 * 1024)
        )} MB in one block and would exhaust the tab, so it is declined rather than attempted.`
      );
    }

    const target = new ImageData(width, height);
    await new Promise<void>((resolve, reject) => {
      image.display(target, (result) => {
        if (result) resolve();
        else
          reject(
            new Error(
              "The HEIC decoded as a container but its image data could not be read. This is what an unsupported HEVC profile looks like — some cameras write 10-bit or monochrome variants that libheif does not decode."
            )
          );
      });
    });

    return createImageBitmap(target);
  } finally {
    for (const entry of images) entry.free();
  }
}
