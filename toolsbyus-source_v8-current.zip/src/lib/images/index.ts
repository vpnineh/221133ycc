/**
 * Image decoding, resizing and encoding, using what the browser already has.
 *
 * The obvious alternative is a set of WebAssembly codecs. They are excellent
 * and they are megabytes: a build that ships libjpeg, libpng, libwebp and
 * libavif costs every visitor several seconds of download to do something the
 * browser can already do natively, in C, with hardware acceleration.
 *
 * `createImageBitmap` decodes any format the browser can display, and
 * `canvas.toBlob` encodes JPEG, PNG and WebP everywhere, plus AVIF in Chromium.
 * That covers every operation here at full quality with no dependency at all.
 * Where a browser genuinely cannot do something — decoding HEIC outside Safari —
 * the tool says so rather than pretending.
 */

import { decodeHeic, looksLikeHeic } from "./heic";

export type ImageFormat = "jpeg" | "png" | "webp" | "avif";

export const FORMAT_EXTENSION: Record<ImageFormat, string> = {
  jpeg: "jpg",
  png: "png",
  webp: "webp",
  avif: "avif",
};

export const FORMAT_MIME: Record<ImageFormat, string> = {
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  avif: "image/avif",
};

/** Formats with no alpha channel, which need a background painted first. */
const OPAQUE_FORMATS = new Set<ImageFormat>(["jpeg"]);

export interface DecodedImage {
  bitmap: ImageBitmap;
  width: number;
  height: number;
  /** True when the browser refused the file and libheif decoded it instead. */
  viaHeic: boolean;
}

/**
 * Decodes a file to a bitmap.
 *
 * Three things are happening here that a one-line `createImageBitmap` would get
 * wrong.
 *
 * `imageOrientation: "from-image"` applies the EXIF orientation tag. A photo
 * taken on a phone held sideways is stored the way the sensor read it, with a
 * tag saying which way up it goes; a viewer honours the tag, and
 * `createImageBitmap` does not unless it is asked to. Leave it out and every
 * portrait photo comes out on its side — the single most common complaint about
 * browser-based image tools.
 *
 * The HEIC fallback runs only after the browser has already refused the file,
 * so Safari — which decodes HEIC natively — never downloads the decoder, and
 * neither does anyone converting a JPEG.
 *
 * And the failure message is written for a person. `createImageBitmap` rejects
 * with a DOMException whose text is "The source image could not be decoded",
 * which tells the user nothing they did not already know.
 */
export async function decodeImage(file: File): Promise<DecodedImage> {
  try {
    const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    return { bitmap, width: bitmap.width, height: bitmap.height, viaHeic: false };
  } catch (nativeFailure) {
    const head = new Uint8Array(await file.slice(0, 64).arrayBuffer());

    if (looksLikeHeic(head)) {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const bitmap = await decodeHeic(bytes);
      return { bitmap, width: bitmap.width, height: bitmap.height, viaHeic: true };
    }

    // A name that claims HEIC over bytes that are not HEIC is worth saying out
    // loud: it is nearly always a renamed file, and the user is about to
    // conclude the tool is broken.
    if (/heic|heif/i.test(file.type) || /\.hei[cf]$/i.test(file.name)) {
      throw new Error(
        `${file.name} is named like a HEIC file but does not contain one — the bytes are not a HEIF container. It was probably renamed rather than converted.`
      );
    }

    throw new Error(
      `${file.name} could not be decoded. The browser does not recognise it as an image it can display${
        nativeFailure instanceof Error && nativeFailure.name === "SecurityError"
          ? " and refused it for security reasons"
          : ""
      } — check that it opens in an image viewer.`
    );
  }
}

/** True when the browser can actually encode this format. */
export async function canEncode(format: ImageFormat): Promise<boolean> {
  // Feature-detected rather than sniffed from the user agent: AVIF encoding
  // arrived at different times in different browsers and a version check would
  // be wrong within a year.
  const canvas = document.createElement("canvas");
  canvas.width = 1;
  canvas.height = 1;
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, FORMAT_MIME[format], 0.5)
  );
  return blob?.type === FORMAT_MIME[format];
}

export interface EncodeOptions {
  format: ImageFormat;
  /** 0–1. Ignored by PNG, which is lossless. */
  quality: number;
  /** Painted behind the image for formats with no alpha. */
  background: string;
}

export interface ResizeOptions {
  width: number;
  height: number;
}

/**
 * Draws a bitmap to a canvas at a target size and encodes it.
 *
 * Two details do most of the quality work.
 *
 * Downscaling in one step aliases badly: the browser samples a handful of
 * source pixels per destination pixel, so a 4000px photo scaled straight to
 * 400px loses detail into moiré. Halving repeatedly until within a factor of
 * two averages the discarded pixels in, which is what every image library does
 * and what a naive one-step `drawImage` does not.
 *
 * And a format with no alpha needs a background painted first, or transparency
 * encodes as black — the single most common bug in browser image conversion.
 */
export async function renderAndEncode(
  bitmap: ImageBitmap,
  size: ResizeOptions,
  options: EncodeOptions
): Promise<Blob> {
  const target = { width: Math.max(1, Math.round(size.width)), height: Math.max(1, Math.round(size.height)) };

  let source: ImageBitmap | HTMLCanvasElement = bitmap;
  let currentWidth = bitmap.width;
  let currentHeight = bitmap.height;
  const scratch: HTMLCanvasElement[] = [];

  // Step down by halves while the target is less than half the current size.
  while (currentWidth / 2 > target.width && currentHeight / 2 > target.height) {
    const half = document.createElement("canvas");
    half.width = Math.max(1, Math.floor(currentWidth / 2));
    half.height = Math.max(1, Math.floor(currentHeight / 2));
    const halfContext = half.getContext("2d");
    if (!halfContext) throw new Error("This browser did not provide a 2D canvas context.");
    halfContext.imageSmoothingEnabled = true;
    halfContext.imageSmoothingQuality = "high";
    halfContext.drawImage(source, 0, 0, half.width, half.height);

    source = half;
    currentWidth = half.width;
    currentHeight = half.height;
    scratch.push(half);
  }

  const canvas = document.createElement("canvas");
  canvas.width = target.width;
  canvas.height = target.height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser did not provide a 2D canvas context.");

  if (OPAQUE_FORMATS.has(options.format)) {
    context.fillStyle = options.background;
    context.fillRect(0, 0, canvas.width, canvas.height);
  }

  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = "high";
  context.drawImage(source, 0, 0, target.width, target.height);

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, FORMAT_MIME[options.format], options.quality)
  );

  // Release every canvas: at 4000 x 3000 each one is 48 MB of pixel data, and
  // a browser frees them lazily.
  canvas.width = 0;
  canvas.height = 0;
  for (const used of scratch) {
    used.width = 0;
    used.height = 0;
  }

  if (!blob) {
    throw new Error(
      `The browser could not encode ${options.format.toUpperCase()}. AVIF encoding in particular is not available everywhere — try WebP, which is.`
    );
  }
  return blob;
}

/**
 * Encodes repeatedly, searching for the highest quality that fits a byte budget.
 *
 * There is no way to ask an encoder for "about 200 KB": quality is a knob on the
 * quantisation tables, and the resulting size depends entirely on the picture.
 * A flat screenshot at quality 0.9 can be 40 KB where a detailed photograph at
 * the same setting is 900 KB, so the only honest way to hit a target is to
 * encode, measure, and adjust.
 *
 * A binary search does it in seven encodes rather than the twenty a linear walk
 * would take, and it is biased towards *under* the target — when the search
 * ends, the result returned is the best one that fit, never the nearest one
 * that did not. A tool asked for "under 200 KB" that returns 214 KB has failed
 * at the only thing it was asked to do.
 *
 * Above the ceiling the loop stops early: if quality 0.92 already fits, there
 * is nothing above it worth spending encodes on.
 */
export const TARGET_SEARCH_STEPS = 7;

export interface TargetResult {
  blob: Blob;
  quality: number;
  attempts: number;
  /** False when even the lowest quality could not reach the target. */
  reached: boolean;
}

export async function encodeToTargetBytes(
  bitmap: ImageBitmap,
  size: ResizeOptions,
  options: Omit<EncodeOptions, "quality">,
  targetBytes: number
): Promise<TargetResult> {
  let low = 0.05;
  let high = 0.95;
  let best: Blob | null = null;
  let bestQuality = low;
  let attempts = 0;

  for (let step = 0; step < TARGET_SEARCH_STEPS; step++) {
    const quality = (low + high) / 2;
    const blob = await renderAndEncode(bitmap, size, { ...options, quality });
    attempts++;

    if (blob.size <= targetBytes) {
      best = blob;
      bestQuality = quality;
      low = quality;
      // Within 3% of the budget is as close as the next halving would get.
      if (blob.size >= targetBytes * 0.97) break;
    } else {
      high = quality;
    }
  }

  if (best) return { blob: best, quality: bestQuality, attempts, reached: true };

  // Nothing fit. Return the smallest thing the encoder can produce and say so,
  // rather than silently handing back something over the budget as though it
  // were the answer.
  const floor = await renderAndEncode(bitmap, size, { ...options, quality: 0.05 });
  return { blob: floor, quality: 0.05, attempts: attempts + 1, reached: false };
}

/** Crops a region, then encodes it. Coordinates are in source pixels. */
export async function cropAndEncode(
  bitmap: ImageBitmap,
  region: { x: number; y: number; width: number; height: number },
  options: EncodeOptions
): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(region.width));
  canvas.height = Math.max(1, Math.round(region.height));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("This browser did not provide a 2D canvas context.");

  if (OPAQUE_FORMATS.has(options.format)) {
    context.fillStyle = options.background;
    context.fillRect(0, 0, canvas.width, canvas.height);
  }

  context.drawImage(
    bitmap,
    region.x,
    region.y,
    region.width,
    region.height,
    0,
    0,
    canvas.width,
    canvas.height
  );

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, FORMAT_MIME[options.format], options.quality)
  );
  canvas.width = 0;
  canvas.height = 0;

  if (!blob) throw new Error("The browser could not encode the cropped image.");
  return blob;
}

/**
 * Fits a size inside a box, preserving the aspect ratio.
 *
 * Never enlarges: upscaling a 400px image to 2000px invents detail that is not
 * there and produces a larger, blurrier file. A tool that silently did it would
 * be giving the user something worse than what they started with.
 */
export function fitWithin(
  source: { width: number; height: number },
  box: { width?: number; height?: number }
): ResizeOptions {
  const targetWidth = box.width ?? Infinity;
  const targetHeight = box.height ?? Infinity;
  const scale = Math.min(targetWidth / source.width, targetHeight / source.height, 1);
  return {
    width: Math.max(1, Math.round(source.width * scale)),
    height: Math.max(1, Math.round(source.height * scale)),
  };
}

/**
 * The output format a file already is, for the "keep the format" option.
 *
 * The reported MIME type is checked before the extension, because it comes
 * from the browser's own sniffing and the extension comes from whoever last
 * renamed the file. Anything unrecognised — a HEIC, a TIFF, a BMP — becomes
 * JPEG, which is the only sensible answer: those formats cannot be written from
 * a canvas at all, so "keep" is not on offer for them.
 */
export function formatOfFile(file: File): ImageFormat {
  const type = file.type.toLowerCase();
  if (type === "image/png") return "png";
  if (type === "image/webp") return "webp";
  if (type === "image/avif") return "avif";
  if (type === "image/jpeg" || type === "image/jpg") return "jpeg";

  const name = file.name.toLowerCase();
  if (name.endsWith(".png")) return "png";
  if (name.endsWith(".webp")) return "webp";
  if (name.endsWith(".avif")) return "avif";
  return "jpeg";
}

export interface SizePreset {
  label: string;
  width: number;
  height: number;
  note: string;
}

export const SIZE_PRESETS: SizePreset[] = [
  { label: "Full HD", width: 1920, height: 1080, note: "A desktop wallpaper or a full-width hero image." },
  { label: "Web large", width: 1600, height: 1600, note: "Large enough for a full-width photo on a retina screen." },
  { label: "Web content", width: 1200, height: 1200, note: "The usual maximum for an image inside an article." },
  { label: "Thumbnail", width: 400, height: 400, note: "A card or a list thumbnail." },
  { label: "Avatar", width: 256, height: 256, note: "A profile picture at twice its display size." },
  { label: "Open Graph", width: 1200, height: 630, note: "The link preview size for social platforms." },
];

/** Descriptive note per format, for the reference table and the picker. */
export const FORMAT_NOTES: Record<ImageFormat, string> = {
  jpeg:
    "Lossy, universal, and no transparency. Best for photographs, where its artefacts hide in the detail. Every device made in the last thirty years opens it.",
  png:
    "Lossless with transparency. Best for screenshots, logos and line art, where a lossy format smears the edges. Large for photographs.",
  webp:
    "Typically 25–35% smaller than JPEG at the same visible quality, with transparency and a lossless mode. Supported by every current browser.",
  avif:
    "Usually 20–30% smaller again than WebP, and much better at low bit rates. Encoding is slow and is not available in every browser, which the tool detects rather than assumes.",
};
