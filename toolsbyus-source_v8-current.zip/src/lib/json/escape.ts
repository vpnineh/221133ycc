import { parseJson } from "./parser";
import type { JsonValue, ParseResult } from "./types";

/**
 * Turning a JSON document into a JSON *string literal*, and back.
 *
 * This is the operation behind two recurring, unglamorous jobs: embedding a
 * payload inside another payload (a fixture inside a config, a body inside a
 * webhook definition, a request inside a test) and reading one back out of a
 * log line where it arrived already escaped. Both are done by hand constantly
 * and both are easy to get subtly wrong, because the escaping is nested —
 * `\"` inside the outer string is a `"` in the inner document, and a `\\n` is a
 * literal backslash-n rather than a newline.
 */

export interface EscapeOptions {
  /** Wrap the result in the outer quote characters. */
  includeQuotes: boolean;
  /** Escape every non-ASCII codepoint as \\uXXXX. */
  escapeUnicode: boolean;
  /** Escape forward slashes as \\/ — legal, and required by some log shippers. */
  escapeSlashes: boolean;
}

export const DEFAULT_ESCAPE_OPTIONS: EscapeOptions = {
  includeQuotes: true,
  escapeUnicode: false,
  escapeSlashes: false,
};

/**
 * Escapes text so it is a valid JSON string body.
 *
 * Written as a character scan rather than a chain of `.replace()` calls,
 * because chained replaces have an ordering hazard that is easy to miss: escape
 * the backslashes after the quotes and the backslash you just introduced for a
 * quote gets escaped a second time, producing `\\"` where `\"` was meant.
 * Scanning once cannot make that mistake.
 */
export function escapeJsonString(
  input: string,
  options: EscapeOptions = DEFAULT_ESCAPE_OPTIONS
): string {
  let out = options.includeQuotes ? '"' : "";

  for (const char of input) {
    const code = char.codePointAt(0)!;

    switch (char) {
      case '"':
        out += '\\"';
        continue;
      case "\\":
        out += "\\\\";
        continue;
      case "\n":
        out += "\\n";
        continue;
      case "\r":
        out += "\\r";
        continue;
      case "\t":
        out += "\\t";
        continue;
      case "\b":
        out += "\\b";
        continue;
      case "\f":
        out += "\\f";
        continue;
      case "/":
        out += options.escapeSlashes ? "\\/" : "/";
        continue;
    }

    // RFC 8259 requires every control character below U+0020 to be escaped.
    if (code < 0x20) {
      out += `\\u${code.toString(16).padStart(4, "0")}`;
      continue;
    }

    if (options.escapeUnicode && code > 0x7e) {
      if (code > 0xffff) {
        // Outside the BMP, \\u takes a surrogate pair. Emitting the codepoint
        // as a single \\u escape silently truncates emoji and CJK extensions.
        const adjusted = code - 0x10000;
        const high = 0xd800 + (adjusted >> 10);
        const low = 0xdc00 + (adjusted & 0x3ff);
        out += `\\u${high.toString(16).padStart(4, "0")}\\u${low.toString(16).padStart(4, "0")}`;
      } else {
        out += `\\u${code.toString(16).padStart(4, "0")}`;
      }
      continue;
    }

    out += char;
  }

  if (options.includeQuotes) out += '"';
  return out;
}

export interface UnescapeResult {
  text: string;
  /** Whether the input arrived wrapped in quotes that were removed. */
  hadQuotes: boolean;
  warnings: string[];
}

/**
 * Reverses the escaping, tolerantly.
 *
 * Deliberately more forgiving than a JSON parser: the input is usually a
 * fragment copied out of a log line or a stack trace, so it may have lost its
 * surrounding quotes, may be truncated, and may contain a stray backslash that
 * a strict parser would reject outright. An unknown escape is passed through
 * with a warning rather than failing the whole operation, because a partially
 * recovered document is far more use than an error message.
 */
export function unescapeJsonString(input: string): UnescapeResult {
  const warnings: string[] = [];
  let text = input.trim();
  let hadQuotes = false;

  if (text.length >= 2 && text.startsWith('"') && text.endsWith('"')) {
    text = text.slice(1, -1);
    hadQuotes = true;
  }

  let out = "";
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char !== "\\") {
      out += char;
      continue;
    }

    const next = text[i + 1];
    i++;

    switch (next) {
      case '"':
        out += '"';
        break;
      case "\\":
        out += "\\";
        break;
      case "/":
        out += "/";
        break;
      case "n":
        out += "\n";
        break;
      case "r":
        out += "\r";
        break;
      case "t":
        out += "\t";
        break;
      case "b":
        out += "\b";
        break;
      case "f":
        out += "\f";
        break;
      case "u": {
        const hex = text.slice(i + 1, i + 5);
        if (!/^[0-9a-fA-F]{4}$/.test(hex)) {
          warnings.push(`Incomplete \\u escape at position ${i - 1}; kept literally.`);
          out += "\\u";
          break;
        }
        const code = parseInt(hex, 16);
        i += 4;

        // A high surrogate must be followed by its low half; recombining them
        // is what keeps astral characters — emoji, rarer CJK — intact.
        if (code >= 0xd800 && code <= 0xdbff) {
          const pair = text.slice(i + 1, i + 7);
          const pairMatch = /^\\u([0-9a-fA-F]{4})$/.exec(pair);
          if (pairMatch) {
            const low = parseInt(pairMatch[1], 16);
            if (low >= 0xdc00 && low <= 0xdfff) {
              out += String.fromCharCode(code, low);
              i += 6;
              break;
            }
          }
          warnings.push(`Lone high surrogate \\u${hex}; kept as-is.`);
        }
        out += String.fromCharCode(code);
        break;
      }
      case undefined:
        warnings.push("Input ends with a trailing backslash; kept literally.");
        out += "\\";
        break;
      default:
        // Not a JSON escape. A strict parser rejects the document; keeping the
        // backslash and the character is what the author almost certainly meant.
        warnings.push(`Unknown escape \\${next}; both characters kept literally.`);
        out += `\\${next}`;
        break;
    }
  }

  return { text: out, hadQuotes, warnings };
}

/**
 * Escapes a JSON document, after checking it is one.
 *
 * Validating first means the output is a string literal that will parse back
 * into the same document, rather than an escaped version of something broken
 * that fails much later and somewhere less convenient.
 */
export function stringifyJsonDocument(
  input: string,
  options: EscapeOptions = DEFAULT_ESCAPE_OPTIONS
): ParseResult<string> {
  const parsed = parseJson(input);
  if (!parsed.success) return parsed;
  return { success: true, data: escapeJsonString(input, options) };
}

/** Unescapes, then reports whether the recovered text is itself valid JSON. */
export function unescapeToDocument(input: string): UnescapeResult & {
  parsed: ParseResult<JsonValue>;
} {
  const result = unescapeJsonString(input);
  return { ...result, parsed: parseJson(result.text) };
}
