import { parseJson } from "./parser";
import { serializeJson, ExtendedFormatOptions } from "./serializer";

export interface StripCommentsResult {
  stripped: string;
  hadComments: boolean;
  commentCount: number;
}

/**
 * Strips single-line and multi-line comments from JSONC input,
 * correctly respecting comments inside string literals.
 */
export function stripJsonComments(input: string): StripCommentsResult {
  let inString = false;
  let inSingleComment = false;
  let inMultiComment = false;
  let escape = false;
  let output = "";
  let commentCount = 0;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const next = input[i + 1];

    if (inSingleComment) {
      if (ch === "\n") {
        inSingleComment = false;
        output += "\n";
      }
      continue;
    }

    if (inMultiComment) {
      if (ch === "*" && next === "/") {
        inMultiComment = false;
        i++; // skip /
      } else if (ch === "\n") {
        output += "\n";
      }
      continue;
    }

    if (inString) {
      output += ch;
      if (escape) {
        escape = false;
      } else if (ch === "\\") {
        escape = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
      output += ch;
      continue;
    }

    if (ch === "/" && next === "/") {
      inSingleComment = true;
      commentCount++;
      i++; // skip second /
      continue;
    }

    if (ch === "/" && next === "*") {
      inMultiComment = true;
      commentCount++;
      i++; // skip *
      continue;
    }

    output += ch;
  }

  return {
    stripped: output,
    hadComments: commentCount > 0,
    commentCount,
  };
}

export interface FormatResult {
  success: boolean;
  formatted?: string;
  error?: string;
  line?: number;
  column?: number;
  caretSnippet?: string;
  hadComments?: boolean;
}

export function formatJson(
  input: string,
  options: ExtendedFormatOptions = { indent: 2 }
): FormatResult {
  const commentCheck = stripJsonComments(input);
  const parseRes = parseJson(commentCheck.stripped);

  if (!parseRes.success) {
    return {
      success: false,
      error: parseRes.error.message,
      line: parseRes.error.line,
      column: parseRes.error.column,
      caretSnippet: parseRes.error.caretSnippet,
      hadComments: commentCheck.hadComments,
    };
  }

  const formatted = serializeJson(parseRes.data, options);
  return {
    success: true,
    formatted,
    hadComments: commentCheck.hadComments,
  };
}
