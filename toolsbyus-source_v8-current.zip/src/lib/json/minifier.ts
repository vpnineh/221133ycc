import { JsonValue, MinifyResult } from "./types";
import { parseJson } from "./parser";
import { stripJsonComments } from "./formatter";

export interface KeyShorteningSuggestion {
  originalKey: string;
  count: number;
  currentBytes: number;
  potentialSavedBytes: number;
}

/**
 * Measure the real gzip size using the browser's native CompressionStream.
 *
 * Resolves to null where the API is unavailable (older Safari, Node without
 * the web streams global), leaving the caller to fall back to the estimate.
 */
export async function measureGzipSize(content: string): Promise<number | null> {
  const CS = (globalThis as { CompressionStream?: typeof CompressionStream }).CompressionStream;
  if (typeof CS !== "function") return null;

  try {
    const encoded = new TextEncoder().encode(content);
    const stream = new Blob([encoded as BlobPart]).stream().pipeThrough(new CS("gzip"));
    const compressed = await new Response(stream).arrayBuffer();
    return compressed.byteLength;
  } catch {
    return null;
  }
}

/**
 * Heuristic gzip size, used only when CompressionStream is unavailable.
 *
 * This is a Shannon-entropy approximation adjusted by a trigram repetition
 * ratio — a rough proxy for what DEFLATE's LZ77 stage would find, not a real
 * compression run. Treat the number as indicative; `measureGzipSize` returns
 * the exact figure wherever the browser supports it.
 */
export function estimateGzipSize(content: string): number {
  const bytes = new TextEncoder().encode(content);
  if (bytes.length === 0) return 0;
  // Count unigram frequencies
  const freq: Record<number, number> = {};
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    freq[b] = (freq[b] || 0) + 1;
  }

  // Shannon entropy
  let entropy = 0;
  const len = bytes.length;
  for (const count of Object.values(freq)) {
    const p = count / len;
    entropy -= p * Math.log2(p);
  }

  // Repetition factor (sliding window 3-gram match count)
  let repeatHits = 0;
  const seenTrigrams = new Set<number>();
  for (let i = 0; i < len - 3; i += 2) {
    const tri = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
    if (seenTrigrams.has(tri)) {
      repeatHits++;
    } else {
      seenTrigrams.add(tri);
    }
  }

  const repetitionRatio = repeatHits / Math.max(1, len / 2);
  const compressedRatio = Math.max(0.12, Math.min(0.9, (entropy / 8) * (1 - repetitionRatio * 0.45)));
  // Add standard 18-byte gzip header + CRC/ISIZE footer
  return Math.round(len * compressedRatio) + 18;
}

export function minifyJson(input: string): {
  success: boolean;
  result?: MinifyResult;
  keySuggestions?: KeyShorteningSuggestion[];
  error?: string;
  line?: number;
  column?: number;
  caretSnippet?: string;
} {
  const commentCheck = stripJsonComments(input);
  const parseRes = parseJson(commentCheck.stripped);

  if (!parseRes.success) {
    return {
      success: false,
      error: parseRes.error.message,
      line: parseRes.error.line,
      column: parseRes.error.column,
      caretSnippet: parseRes.error.caretSnippet,
    };
  }

  // Collect key frequencies iteratively
  const keyFrequency: Record<string, number> = {};
  const stack: JsonValue[] = [parseRes.data];

  while (stack.length > 0) {
    const curr = stack.pop()!;
    if (curr && typeof curr === "object") {
      if (Array.isArray(curr)) {
        for (let i = curr.length - 1; i >= 0; i--) {
          stack.push(curr[i]);
        }
      } else {
        const keys = Object.keys(curr);
        for (let i = 0; i < keys.length; i++) {
          const k = keys[i];
          keyFrequency[k] = (keyFrequency[k] || 0) + 1;
          stack.push(curr[k]);
        }
      }
    }
  }

  // Generate key shortening suggestions
  const keySuggestions: KeyShorteningSuggestion[] = Object.entries(keyFrequency)
    .filter(([k, count]) => k.length > 3 && count > 1)
    .map(([k, count]) => {
      const currentBytes = k.length * count;
      const shortenedLen = Math.min(2, k.length);
      const potentialSavedBytes = (k.length - shortenedLen) * count;
      return {
        originalKey: k,
        count,
        currentBytes,
        potentialSavedBytes,
      };
    })
    .sort((a, b) => b.potentialSavedBytes - a.potentialSavedBytes);

  const minified = JSON.stringify(parseRes.data);
  const originalBytes = new TextEncoder().encode(input).length;
  const minifiedBytes = new TextEncoder().encode(minified).length;
  const reductionPercent = originalBytes > 0
    ? Math.max(0, parseFloat((((originalBytes - minifiedBytes) / originalBytes) * 100).toFixed(2)))
    : 0;
  const estimatedGzipBytes = estimateGzipSize(minified);

  return {
    success: true,
    result: {
      minified,
      originalBytes,
      minifiedBytes,
      reductionPercent,
      estimatedGzipBytes,
      keyFrequency,
    },
    keySuggestions,
  };
}
