import { JsonValue, JsonObject, JsonArray, ParseResult, ParseError, MalformedErrorType } from "./types";
import { safeSet } from "../safe-object";

interface StackFrame {
  type: "object" | "array";
  container: JsonObject | JsonArray;
  key?: string;
  stage: "START" | "KEY_OR_CLOSE" | "COLON" | "VALUE" | "COMMA_OR_CLOSE";
  openLine: number;
  openCol: number;
  seenKeys?: Set<string>;
}

export function createCaretSnippet(input: string, line: number, column: number): string {
  const lines = input.split(/\r?\n/);
  const targetLineIdx = line - 1;
  if (targetLineIdx < 0 || targetLineIdx >= lines.length) {
    return "";
  }
  const rawLine = lines[targetLineIdx];
  const maxLen = 80;
  let startChar = 0;
  let endChar = rawLine.length;
  let pointerCol = column - 1;

  if (rawLine.length > maxLen) {
    startChar = Math.max(0, column - 1 - Math.floor(maxLen / 2));
    endChar = Math.min(rawLine.length, startChar + maxLen);
    pointerCol = column - 1 - startChar;
  }

  const snippet = rawLine.slice(startChar, endChar);
  const pointerIndent = " ".repeat(Math.max(0, pointerCol));
  return `${snippet}\n${pointerIndent}^`;
}

function makeError(
  message: string,
  errorType: MalformedErrorType,
  line: number,
  column: number,
  input: string
): ParseError {
  return {
    message,
    errorType,
    line,
    column,
    caretSnippet: createCaretSnippet(input, line, column),
  };
}

export function parseJson(input: string): ParseResult<JsonValue> {
  const len = input.length;
  if (len === 0) {
    return {
      success: false,
      error: makeError("Empty JSON input (truncated document)", "TRUNCATED_DOCUMENT", 1, 1, input),
    };
  }

  // 1. Check for BOM at byte 0
  if (input.charCodeAt(0) === 0xfeff) {
    return {
      success: false,
      error: makeError(
        "Byte Order Mark (BOM) detected at start of file. RFC 8259 forbids BOM in JSON.",
        "BOM",
        1,
        1,
        input
      ),
    };
  }

  let pos = 0;
  let line = 1;
  let col = 1;
  const warnings: string[] = [];

  function advance() {
    const ch = input[pos];
    if (ch === "\n") {
      line++;
      col = 1;
    } else {
      col++;
    }
    pos++;
  }

  function skipWhitespace() {
    while (pos < len) {
      const ch = input[pos];
      if (ch === " " || ch === "\t" || ch === "\r" || ch === "\n") {
        advance();
      } else {
        break;
      }
    }
  }

  // Check smart quotes anywhere in input helper
  const smartQuoteRegex = /[\u201C\u201D\u2018\u2019]/;

  let rootResult: JsonValue | undefined;
  let hasRoot = false;
  const stack: StackFrame[] = [];

  skipWhitespace();
  if (pos >= len) {
    return {
      success: false,
      error: makeError("Unexpected end of JSON input (truncated document)", "TRUNCATED_DOCUMENT", line, col, input),
    };
  }

  while (pos < len) {
    skipWhitespace();
    if (pos >= len) break;

    const curChar = input[pos];
    const curLine = line;
    const curCol = col;

    // RFC 8259 §2: a JSON text is exactly one value. Reaching a new token with
    // the root already complete means trailing content — reject it here rather
    // than parsing and silently discarding the second document.
    if (hasRoot && stack.length === 0) {
      return {
        success: false,
        error: makeError(
          `Unexpected extra content after the JSON root value, starting at '${curChar}'. A JSON document must contain exactly one top-level value.`,
          "SYNTAX_ERROR",
          curLine,
          curCol,
          input
        ),
      };
    }

    // Check smart quotes
    if (smartQuoteRegex.test(curChar)) {
      return {
        success: false,
        error: makeError(
          "Smart quotes detected. RFC 8259 requires standard ASCII straight quotes (\").",
          "SMART_QUOTES",
          curLine,
          curCol,
          input
        ),
      };
    }

    // Check single quotes
    if (curChar === "'") {
      return {
        success: false,
        error: makeError(
          "Single quotes are not allowed in JSON. Use double quotes (\").",
          "SINGLE_QUOTES",
          curLine,
          curCol,
          input
        ),
      };
    }

    // Top frame on stack
    const top = stack.length > 0 ? stack[stack.length - 1] : null;

    if (top) {
      // Inside Object or Array
      if (top.type === "object") {
        if (top.stage === "KEY_OR_CLOSE") {
          if (curChar === "}") {
            advance();
            popStack();
            continue;
          }
          // Expect key
          if (curChar === ",") {
            return {
              success: false,
              error: makeError("Unexpected leading comma in object.", "SYNTAX_ERROR", curLine, curCol, input),
            };
          }
          if (curChar !== '"') {
            // Check if unquoted key
            const idMatch = input.slice(pos).match(/^([a-zA-Z0-9_$]+)/);
            if (idMatch) {
              return {
                success: false,
                error: makeError(
                  `Unquoted object key '${idMatch[1]}'. Object keys must be double-quoted strings.`,
                  "UNQUOTED_KEY",
                  curLine,
                  curCol,
                  input
                ),
              };
            }
            if (curChar === "]") {
              return {
                success: false,
                error: makeError(
                  "Mismatched bracket: expected '}' for object, got ']'.",
                  "MISMATCHED_BRACKET",
                  curLine,
                  curCol,
                  input
                ),
              };
            }
            return {
              success: false,
              error: makeError(
                `Expected double-quoted string key in object, found '${curChar}'.`,
                "SYNTAX_ERROR",
                curLine,
                curCol,
                input
              ),
            };
          }
          // Parse string key
          const keyRes = parseStringToken();
          if (!keyRes.success) return keyRes;
          top.key = keyRes.value;
          if (top.seenKeys?.has(top.key)) {
            warnings.push(`Duplicate key '${top.key}' found at line ${curLine}, col ${curCol}.`);
          } else {
            top.seenKeys?.add(top.key);
          }
          top.stage = "COLON";
          continue;
        } else if (top.stage === "COLON") {
          if (curChar !== ":") {
            return {
              success: false,
              error: makeError(
                `Expected ':' after key in object, found '${curChar}'.`,
                "SYNTAX_ERROR",
                curLine,
                curCol,
                input
              ),
            };
          }
          advance();
          top.stage = "VALUE";
          continue;
        } else if (top.stage === "COMMA_OR_CLOSE") {
          if (curChar === "}") {
            advance();
            popStack();
            continue;
          }
          if (curChar === ",") {
            advance();
            skipWhitespace();
            // Check trailing comma
            if (pos < len && input[pos] === "}") {
              return {
                success: false,
                error: makeError(
                  "Trailing comma is not permitted in RFC 8259 JSON.",
                  "TRAILING_COMMA",
                  curLine,
                  curCol,
                  input
                ),
              };
            }
            top.stage = "KEY_OR_CLOSE";
            continue;
          }
          if (curChar === '"' || /[a-zA-Z0-9_$]/.test(curChar)) {
            return {
              success: false,
              error: makeError(
                "Missing comma between object key-value pairs.",
                "MISSING_COMMA",
                curLine,
                curCol,
                input
              ),
            };
          }
          if (curChar === "]") {
            return {
              success: false,
              error: makeError(
                "Mismatched bracket: expected '}' for object, got ']'.",
                "MISMATCHED_BRACKET",
                curLine,
                curCol,
                input
              ),
            };
          }
          return {
            success: false,
            error: makeError(
              `Expected ',' or '}' in object, found '${curChar}'.`,
              "SYNTAX_ERROR",
              curLine,
              curCol,
              input
            ),
          };
        }
      } else {
        // Array
        if (top.stage === "START") {
          if (curChar === "]") {
            advance();
            popStack();
            continue;
          }
          top.stage = "VALUE";
        } else if (top.stage === "COMMA_OR_CLOSE") {
          if (curChar === "]") {
            advance();
            popStack();
            continue;
          }
          if (curChar === ",") {
            advance();
            skipWhitespace();
            // Check trailing comma
            if (pos < len && input[pos] === "]") {
              return {
                success: false,
                error: makeError(
                  "Trailing comma is not permitted in RFC 8259 JSON.",
                  "TRAILING_COMMA",
                  curLine,
                  curCol,
                  input
                ),
              };
            }
            top.stage = "VALUE";
            continue;
          }
          if (curChar === "}") {
            return {
              success: false,
              error: makeError(
                "Mismatched bracket: expected ']' for array, got '}'.",
                "MISMATCHED_BRACKET",
                curLine,
                curCol,
                input
              ),
            };
          }
          return {
            success: false,
            error: makeError(
              "Missing comma between array elements.",
              "MISSING_COMMA",
              curLine,
              curCol,
              input
            ),
          };
        }
      }
    }

    // Now expecting a value (either root, object value, or array element)
    if (curChar === "{") {
      advance();
      const newObj: JsonObject = {};
      stack.push({
        type: "object",
        container: newObj,
        stage: "KEY_OR_CLOSE",
        openLine: curLine,
        openCol: curCol,
        seenKeys: new Set<string>(),
      });
      continue;
    }

    if (curChar === "[") {
      advance();
      const newArr: JsonArray = [];
      stack.push({
        type: "array",
        container: newArr,
        stage: "START",
        openLine: curLine,
        openCol: curCol,
      });
      continue;
    }

    // Parse primitive values
    let val: JsonValue;
    if (curChar === '"') {
      const strRes = parseStringToken();
      if (!strRes.success) return strRes;
      val = strRes.value;
    } else if (curChar === "t" && input.startsWith("true", pos)) {
      pos += 4;
      col += 4;
      val = true;
    } else if (curChar === "f" && input.startsWith("false", pos)) {
      pos += 5;
      col += 5;
      val = false;
    } else if (curChar === "n" && input.startsWith("null", pos)) {
      pos += 4;
      col += 4;
      val = null;
    } else if (curChar === "N" && input.startsWith("NaN", pos)) {
      return {
        success: false,
        error: makeError(
          "Invalid number: 'NaN' is rejected by RFC 8259 JSON.",
          "NAN_INFINITY_REJECTED",
          curLine,
          curCol,
          input
        ),
      };
    } else if (curChar === "I" && input.startsWith("Infinity", pos)) {
      return {
        success: false,
        error: makeError(
          "Invalid number: 'Infinity' is rejected by RFC 8259 JSON.",
          "NAN_INFINITY_REJECTED",
          curLine,
          curCol,
          input
        ),
      };
    } else if (curChar === "-" && input.startsWith("-Infinity", pos)) {
      return {
        success: false,
        error: makeError(
          "Invalid number: '-Infinity' is rejected by RFC 8259 JSON.",
          "NAN_INFINITY_REJECTED",
          curLine,
          curCol,
          input
        ),
      };
    } else if (curChar === "-" || (curChar >= "0" && curChar <= "9")) {
      const numRes = parseNumberToken();
      if (!numRes.success) return numRes;
      val = numRes.value;
    } else {
      return {
        success: false,
        error: makeError(
          `Unexpected token '${curChar}'. Valid JSON values are string, number, object, array, boolean, or null.`,
          "SYNTAX_ERROR",
          curLine,
          curCol,
          input
        ),
      };
    }

    // Value parsed! Connect it to container or root
    attachValue(val);
  }

  // Helper: attach a parsed value (primitive or completed compound) to parent frame or root
  function attachValue(val: JsonValue) {
    if (stack.length === 0) {
      // A second top-level value is rejected at the top of the parse loop
      // before it is ever consumed, so reaching here twice is not possible.
      if (hasRoot) return;
      rootResult = val;
      hasRoot = true;
      return;
    }

    const parent = stack[stack.length - 1];
    if (parent.type === "object") {
      if (parent.key === undefined) {
        throw new Error("Internal parser error: object value parsed without key");
      }
      // defineProperty, not bracket assignment: a literal "__proto__" key must
      // become an own property (as JSON.parse does) instead of re-pointing the
      // object's prototype and vanishing from the parsed result.
      safeSet(parent.container as unknown as Record<string, unknown>, parent.key, val as unknown);
      parent.key = undefined;
      parent.stage = "COMMA_OR_CLOSE";
    } else {
      (parent.container as JsonArray).push(val);
      parent.stage = "COMMA_OR_CLOSE";
    }
  }

  function popStack() {
    const popped = stack.pop()!;
    attachValue(popped.container);
  }

  // After loop, check if stack is still open
  if (stack.length > 0) {
    const unclosed = stack[stack.length - 1];
    const expected = unclosed.type === "object" ? "}" : "]";
    return {
      success: false,
      error: makeError(
        `Unexpected end of JSON input: missing closing '${expected}' for ${unclosed.type} opened at line ${unclosed.openLine}, col ${unclosed.openCol}.`,
        "TRUNCATED_DOCUMENT",
        line,
        col,
        input
      ),
    };
  }

  // Check if extra tokens exist after root
  skipWhitespace();
  if (pos < len) {
    return {
      success: false,
      error: makeError(
        `Unexpected extra content after JSON root at character '${input[pos]}'.`,
        "SYNTAX_ERROR",
        line,
        col,
        input
      ),
    };
  }

  if (!hasRoot) {
    return {
      success: false,
      error: makeError("Empty JSON input (truncated document)", "TRUNCATED_DOCUMENT", 1, 1, input),
    };
  }

  return {
    success: true,
    data: rootResult as JsonValue,
    warnings: warnings.length > 0 ? warnings : undefined,
  };

  // Sub-parser: String
  function parseStringToken(): { success: true; value: string } | { success: false; error: ParseError } {
    const strLine = line;
    const strCol = col;
    advance(); // skip opening quote '"'
    let str = "";

    while (pos < len) {
      const ch = input[pos];
      if (ch === '"') {
        advance();
        return { success: true, value: str };
      }
      if (ch === "\\") {
        advance();
        if (pos >= len) {
          return {
            success: false,
            error: makeError("Unclosed escape sequence at end of string.", "UNCLOSED_STRING", line, col, input),
          };
        }
        const esc = input[pos];
        advance();
        switch (esc) {
          case '"': str += '"'; break;
          case "\\": str += "\\"; break;
          case "/": str += "/"; break;
          case "b": str += "\b"; break;
          case "f": str += "\f"; break;
          case "n": str += "\n"; break;
          case "r": str += "\r"; break;
          case "t": str += "\t"; break;
          case "u": {
            if (pos + 4 > len) {
              return {
                success: false,
                error: makeError("Incomplete unicode escape \\uXXXX in string.", "SYNTAX_ERROR", line, col, input),
              };
            }
            const hex = input.slice(pos, pos + 4);
            if (!/^[0-9a-fA-F]{4}$/.test(hex)) {
              return {
                success: false,
                error: makeError(`Invalid unicode escape sequence '\\u${hex}'.`, "SYNTAX_ERROR", line, col, input),
              };
            }
            str += String.fromCharCode(parseInt(hex, 16));
            pos += 4;
            col += 4;
            break;
          }
          default:
            return {
              success: false,
              error: makeError(`Invalid escape sequence '\\${esc}'.`, "SYNTAX_ERROR", line, col, input),
            };
        }
      } else if (ch === "\n" || ch === "\r") {
        return {
          success: false,
          error: makeError("Unclosed string: unescaped line break in string literal.", "UNCLOSED_STRING", line, col, input),
        };
      } else {
        str += ch;
        advance();
      }
    }

    return {
      success: false,
      error: makeError("Unclosed string: expected closing quote '\"'.", "UNCLOSED_STRING", strLine, strCol, input),
    };
  }

  // Sub-parser: Number (Strict RFC 8259)
  function parseNumberToken(): { success: true; value: number } | { success: false; error: ParseError } {
    const numLine = line;
    const numCol = col;
    const startPos = pos;

    if (input[pos] === "-") {
      advance();
    }

    if (pos >= len) {
      return {
        success: false,
        error: makeError("Invalid number: minus sign with no digits.", "INVALID_NUMBER", numLine, numCol, input),
      };
    }

    if (input[pos] === "0") {
      advance();
      if (pos < len && input[pos] >= "0" && input[pos] <= "9") {
        return {
          success: false,
          error: makeError("Invalid number: leading zeros are forbidden in JSON.", "INVALID_NUMBER", numLine, numCol, input),
        };
      }
    } else if (input[pos] >= "1" && input[pos] <= "9") {
      while (pos < len && input[pos] >= "0" && input[pos] <= "9") {
        advance();
      }
    } else {
      return {
        success: false,
        error: makeError(`Invalid number at character '${input[pos]}'.`, "INVALID_NUMBER", numLine, numCol, input),
      };
    }

    // Fraction
    if (pos < len && input[pos] === ".") {
      advance();
      if (pos >= len || !(input[pos] >= "0" && input[pos] <= "9")) {
        return {
          success: false,
          error: makeError("Invalid number: decimal point must be followed by at least one digit.", "INVALID_NUMBER", numLine, numCol, input),
        };
      }
      while (pos < len && input[pos] >= "0" && input[pos] <= "9") {
        advance();
      }
    }

    // Exponent
    if (pos < len && (input[pos] === "e" || input[pos] === "E")) {
      advance();
      if (pos < len && (input[pos] === "+" || input[pos] === "-")) {
        advance();
      }
      if (pos >= len || !(input[pos] >= "0" && input[pos] <= "9")) {
        return {
          success: false,
          error: makeError("Invalid number: exponent must be followed by digits.", "INVALID_NUMBER", numLine, numCol, input),
        };
      }
      while (pos < len && input[pos] >= "0" && input[pos] <= "9") {
        advance();
      }
    }

    const numStr = input.slice(startPos, pos);
    const num = Number(numStr);
    if (!Number.isFinite(num)) {
      return {
        success: false,
        error: makeError("Number overflow/infinity is forbidden in RFC 8259 JSON.", "NAN_INFINITY_REJECTED", numLine, numCol, input),
      };
    }

    return { success: true, value: num };
  }
}
