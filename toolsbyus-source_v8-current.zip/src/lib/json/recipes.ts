/**
 * How to pretty-print JSON in each language, and what each one gets wrong.
 *
 * This page exists because "json pretty print" is searched by two different
 * people. One wants a box to paste into; the other is at a terminal or in an
 * editor and wants the line of code for their language. Every site answers the
 * first and none answer the second, so `/json-pretty-print` answers both — and
 * that is also what keeps it from being a third copy of `/json-formatter` and
 * `/json-beautifier`, which would be three pages competing for one result.
 *
 * The `gotcha` on each entry is the part worth writing down. Every one of these
 * APIs has a default that surprises somebody: Python escapes non-ASCII, Go
 * escapes angle brackets, PHP escapes slashes, and PowerShell silently
 * truncates anything nested more than two levels deep.
 */

export interface PrettyPrintRecipe {
  id: string;
  language: string;
  /** Syntax hint for the code pane's label. */
  note: string;
  code: string;
  /** The default nobody expects, stated plainly. */
  gotcha: string;
}

export const PRETTY_PRINT_RECIPES: PrettyPrintRecipe[] = [
  {
    id: "javascript",
    language: "JavaScript",
    note: "Built in. No dependency, in the browser and in Node.",
    code: `const pretty = JSON.stringify(value, null, 2);

// From a string, rather than an object:
const pretty2 = JSON.stringify(JSON.parse(text), null, 2);

// Tabs instead of spaces:
const tabbed = JSON.stringify(value, null, "\\t");`,
    gotcha:
      "The second argument is the replacer, not the indent. JSON.stringify(value, 2) compiles, runs, and returns the same minified string it always did — it is the most common JSON mistake in JavaScript. Note also what stringify silently drops: undefined values, functions and symbols disappear from objects and become null inside arrays, a Map or Set serialises as {}, and a BigInt throws a TypeError rather than being converted.",
  },
  {
    id: "python",
    language: "Python",
    note: "Standard library, no install.",
    code: `import json

pretty = json.dumps(obj, indent=2)

# Keep non-ASCII readable, and sort keys:
pretty = json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True)

# From a string:
pretty = json.dumps(json.loads(text), indent=2)`,
    gotcha:
      "ensure_ascii defaults to True, so every non-ASCII character is escaped: \"café\" comes out as \"caf\\u00e9\". It is valid JSON and it is unreadable. Pass ensure_ascii=False to keep UTF-8 — and remember to open the output file with encoding=\"utf-8\" when you do, or Windows will fail on the write instead.",
  },
  {
    id: "jq",
    language: "jq",
    note: "Command line. Pretty-printing is the default.",
    code: `jq . file.json

# Sort keys, which makes two files diffable:
jq -S . file.json

# Four-space indent, or tabs:
jq --indent 4 . file.json
jq --tab . file.json

# Back to one line:
jq -c . file.json`,
    gotcha:
      "jq parses numbers as IEEE doubles. Up to jq 1.6 that meant a 64-bit integer ID such as 12345678901234567890 came back changed, silently — the single most dangerous thing jq does to a payload. jq 1.7 preserves the original literal for numbers it has not modified, so check `jq --version` before trusting it with identifiers.",
  },
  {
    id: "shell",
    language: "Command line (no jq)",
    note: "Python's json.tool, present on almost every machine.",
    code: `python3 -m json.tool file.json

# Indent, sorting and UTF-8:
python3 -m json.tool --indent 2 --sort-keys file.json
python3 -m json.tool --no-ensure-ascii file.json

# From a pipe:
curl -s https://api.example.com/thing | python3 -m json.tool`,
    gotcha:
      "json.tool rewrites the file in place if you give it two arguments, and the second one is the output path — `python3 -m json.tool a.json a.json` works, but `python3 -m json.tool a.json b.json` overwrites b.json without asking. --no-ensure-ascii arrived in Python 3.9; on anything older you get escaped Unicode with no way to turn it off from the command line.",
  },
  {
    id: "go",
    language: "Go",
    note: "encoding/json, standard library.",
    code: `// From a value:
out, err := json.MarshalIndent(v, "", "  ")

// From bytes already in hand — preserves the original exactly:
var buf bytes.Buffer
err := json.Indent(&buf, data, "", "  ")

// Without HTML escaping:
enc := json.NewEncoder(w)
enc.SetEscapeHTML(false)
enc.SetIndent("", "  ")
err := enc.Encode(v)`,
    gotcha:
      "MarshalIndent escapes <, > and & as \\u003c, \\u003e and \\u0026 — a legacy of making JSON safe to embed in a <script> tag. It is valid and it mangles any payload containing HTML or a query string. Use an Encoder with SetEscapeHTML(false) to stop it. And prefer json.Indent when you already have bytes: MarshalIndent round-trips through Go types, so it reorders map keys alphabetically and drops any field your struct does not declare.",
  },
  {
    id: "java",
    language: "Java",
    note: "Jackson, the de facto standard.",
    code: `ObjectMapper mapper = new ObjectMapper();

String pretty = mapper
    .writerWithDefaultPrettyPrinter()
    .writeValueAsString(obj);

// From a string, without a target class:
String pretty2 = mapper
    .writerWithDefaultPrettyPrinter()
    .writeValueAsString(mapper.readTree(text));`,
    gotcha:
      "Jackson's DefaultPrettyPrinter indents objects but writes array elements on one line, which is not what anyone means by pretty-printed. Fix it with a printer whose array indenter is set: new DefaultPrettyPrinter().withArrayIndenter(DefaultIndenter.SYSTEM_LINEFEED_INSTANCE). It also uses two spaces for objects and cannot be talked out of it without a custom DefaultIndenter.",
  },
  {
    id: "csharp",
    language: "C#",
    note: "System.Text.Json, built into .NET Core 3.0 and later.",
    code: `var options = new JsonSerializerOptions { WriteIndented = true };
string pretty = JsonSerializer.Serialize(obj, options);

// From a string:
using var doc = JsonDocument.Parse(text);
string pretty2 = JsonSerializer.Serialize(doc, options);

// Without the aggressive escaping:
var relaxed = new JsonSerializerOptions {
    WriteIndented = true,
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
};`,
    gotcha:
      "System.Text.Json escapes far more than the specification requires — +, <, >, & and every non-ASCII character — because its default encoder assumes the output might be dropped into HTML. \"café\" becomes \"caf\\u00E9\". UnsafeRelaxedJsonEscaping has an alarming name and is the correct choice whenever the output is not being embedded in a web page.",
  },
  {
    id: "php",
    language: "PHP",
    note: "json_encode, built in since 5.2.",
    code: `$pretty = json_encode($data, JSON_PRETTY_PRINT);

// What you almost always actually want:
$pretty = json_encode(
    $data,
    JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);

// From a string:
$pretty = json_encode(json_decode($text), JSON_PRETTY_PRINT);`,
    gotcha:
      "PHP escapes forward slashes by default, so a URL comes out as \"https:\\/\\/example.com\" — valid JSON, and it looks broken to everyone who reads it. It escapes non-ASCII too. JSON_UNESCAPED_SLASHES and JSON_UNESCAPED_UNICODE fix both, and there is almost no reason not to pass them. The indent is four spaces and is not configurable.",
  },
  {
    id: "ruby",
    language: "Ruby",
    note: "Standard library, one require away.",
    code: `require "json"

pretty = JSON.pretty_generate(obj)

# From a string:
pretty = JSON.pretty_generate(JSON.parse(text))

# Custom indent:
pretty = JSON.generate(obj, indent: "    ", object_nl: "\\n", array_nl: "\\n")`,
    gotcha:
      "obj.to_json is compact and JSON.pretty_generate is not the same method — reaching for to_json and then wondering where the indentation went is the usual detour. pretty_generate also raises on NaN and Infinity unless you pass allow_nan: true, which matters more than it sounds when the data came from a float calculation.",
  },
  {
    id: "rust",
    language: "Rust",
    note: "serde_json, the standard choice.",
    code: `let pretty = serde_json::to_string_pretty(&value)?;

// From a string, without a target type:
let value: serde_json::Value = serde_json::from_str(text)?;
let pretty = serde_json::to_string_pretty(&value)?;

// A different indent:
let formatter = serde_json::ser::PrettyFormatter::with_indent(b"    ");
let mut buf = Vec::new();
let mut ser = serde_json::Serializer::with_formatter(&mut buf, formatter);
value.serialize(&mut ser)?;`,
    gotcha:
      "serde_json::Value stores objects in a BTreeMap by default, so keys come out alphabetically sorted and the original order is gone. If round-tripping a document unchanged matters — a config file, a lockfile, anything a human will diff — enable the preserve_order feature, which swaps in an IndexMap.",
  },
  {
    id: "powershell",
    language: "PowerShell",
    note: "Built in since 3.0.",
    code: `Get-Content file.json | ConvertFrom-Json | ConvertTo-Json -Depth 100

# In place:
(Get-Content file.json -Raw | ConvertFrom-Json |
  ConvertTo-Json -Depth 100) | Set-Content file.json

# From a request:
Invoke-RestMethod https://api.example.com/thing |
  ConvertTo-Json -Depth 100`,
    gotcha:
      "ConvertTo-Json defaults to -Depth 2 and silently truncates everything below it — deeper objects are replaced with their type name as a string, and nothing warns you. It is the worst default in this entire list, because the output is still valid JSON and still looks plausible. Always pass -Depth explicitly.",
  },
];
