import { parseJson } from "./parser";
import type { JsonValue } from "./types";

/**
 * Repairs the malformed-JSON patterns the parser already classifies.
 *
 * The validator is precise about *why* a document is invalid — trailing comma,
 * single quotes, unquoted key, smart quotes, BOM, Python/JS literals. Telling a
 * developer exactly what is wrong and then making them fix it by hand wastes the
 * diagnosis, so this turns each classification into a mechanical correction.
 *
 * ## Why this is a tokenizer and not a series of regexes
 *
 * Every repair is context-dependent in the same way: a comma inside `"a, b"` is
 * data, the identical character after the last array element is a syntax error.
 * `//` inside `'https://x.dev'` is part of a URL, the same characters outside a
 * string start a comment. No amount of regex distinguishes those, and a fixer
 * that guesses corrupts payloads.
 *
 * Nor can it be a sequence of independent scanning passes: stripping comments
 * needs to know where strings are, and normalizing single-quoted strings needs
 * to know where comments are. That is circular, so the input is tokenized
 * **once** into a loose superset of JSON — strings in any quote style, comments,
 * punctuation, words, whitespace — and every repair is then a decision about
 * tokens, where the context is unambiguous by construction.
 *
 * The repaired text is finally fed back through the real parser: success is only
 * reported when the parser agrees, never because the output merely looks better.
 */

export type RepairAction =
  | "BOM_REMOVED"
  | "SMART_QUOTES_REPLACED"
  | "SINGLE_QUOTES_CONVERTED"
  | "TRAILING_COMMAS_REMOVED"
  | "UNQUOTED_KEYS_QUOTED"
  | "COMMENTS_STRIPPED"
  | "PYTHON_LITERALS_CONVERTED"
  | "MISSING_COMMAS_INSERTED";

export interface RepairChange {
  action: RepairAction;
  /** How many separate places this change was applied. */
  count: number;
  /** One-line explanation shown alongside the result. */
  description: string;
}

export interface RepairResult {
  /** True only when the repaired text parses as valid JSON. */
  success: boolean;
  repaired: string;
  changes: RepairChange[];
  /** Parsed value, present only on success. */
  data?: JsonValue;
  /** Why the document still does not parse, when repair was not enough. */
  remainingError?: string;
}

const DESCRIPTIONS: Record<RepairAction, string> = {
  BOM_REMOVED: "Removed the byte order mark, which RFC 8259 forbids at the start of a document.",
  SMART_QUOTES_REPLACED: "Replaced typographic quotes with straight double quotes.",
  SINGLE_QUOTES_CONVERTED: "Converted single-quoted strings to double-quoted.",
  TRAILING_COMMAS_REMOVED: "Removed commas before a closing brace or bracket.",
  UNQUOTED_KEYS_QUOTED: "Wrapped bare object keys in double quotes.",
  COMMENTS_STRIPPED: "Stripped // and /* */ comments, which are valid in JSONC but not JSON.",
  PYTHON_LITERALS_CONVERTED: "Converted True, False, None, undefined and NaN to JSON literals.",
  MISSING_COMMAS_INSERTED: "Inserted missing commas between values.",
};

const SMART_OPEN = "“‘„‚"; // “ ‘ „ ‚
const SMART_CLOSE = "”’"; // ” ’

const LITERALS: Record<string, string> = {
  True: "true",
  False: "false",
  None: "null",
  undefined: "null",
  NaN: "null",
  Infinity: "null",
  "-Infinity": "null",
};

type Token =
  | { kind: "string"; value: string; quote: '"' | "'" | "smart" }
  | { kind: "punct"; value: "{" | "}" | "[" | "]" | ":" | "," }
  | { kind: "word"; value: string }
  | { kind: "space"; value: string }
  | { kind: "comment"; value: string }
  | { kind: "other"; value: string };

/**
 * Split the input into a loose JSON superset.
 *
 * Deliberately permissive: it accepts things JSON does not, because the whole
 * point is to read a broken document well enough to describe what is wrong with
 * it. Unterminated constructs run to end-of-input rather than throwing.
 */
function tokenizeLoose(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  const readDelimited = (close: (c: string) => boolean, quote: '"' | "'" | "smart") => {
    let value = "";
    while (i < input.length) {
      const c = input[i];
      if (c === "\\") {
        const next = input[i + 1];
        // Keep escapes intact, except \' which is only meaningful inside a
        // single-quoted string and becomes a bare apostrophe in JSON.
        if (next === "'") value += "'";
        else if (next !== undefined) value += "\\" + next;
        i += 2;
        continue;
      }
      if (close(c)) {
        i++;
        return { kind: "string" as const, value, quote };
      }
      value += c;
      i++;
    }
    return { kind: "string" as const, value, quote };
  };

  while (i < input.length) {
    const c = input[i];

    if (c === " " || c === "\t" || c === "\n" || c === "\r") {
      let value = "";
      while (i < input.length && /[ \t\n\r]/.test(input[i])) value += input[i++];
      tokens.push({ kind: "space", value });
      continue;
    }

    if (c === '"') {
      i++;
      tokens.push(readDelimited((x) => x === '"', '"'));
      continue;
    }
    if (c === "'") {
      i++;
      tokens.push(readDelimited((x) => x === "'", "'"));
      continue;
    }
    if (SMART_OPEN.includes(c)) {
      i++;
      tokens.push(readDelimited((x) => SMART_CLOSE.includes(x), "smart"));
      continue;
    }

    if (c === "/" && input[i + 1] === "/") {
      let value = "";
      while (i < input.length && input[i] !== "\n") value += input[i++];
      tokens.push({ kind: "comment", value });
      continue;
    }
    if (c === "/" && input[i + 1] === "*") {
      let value = "";
      while (i < input.length && !(input[i] === "*" && input[i + 1] === "/")) value += input[i++];
      i = Math.min(i + 2, input.length);
      tokens.push({ kind: "comment", value });
      continue;
    }

    if ("{}[]:,".includes(c)) {
      tokens.push({ kind: "punct", value: c as "{" });
      i++;
      continue;
    }

    // A "word" is any run of characters that could be a number, a literal or a
    // bare identifier — resolved later, where key position is known.
    if (/[A-Za-z0-9_$+.\-]/.test(c)) {
      let value = "";
      while (i < input.length && /[A-Za-z0-9_$+.\-]/.test(input[i])) value += input[i++];
      tokens.push({ kind: "word", value });
      continue;
    }

    tokens.push({ kind: "other", value: c });
    i++;
  }

  return tokens;
}

/** Serialize a string value as a valid JSON string. */
function toJsonString(value: string): string {
  // The token already carries decoded content with escapes preserved, so only
  // the delimiter and any raw double quotes need handling.
  let out = '"';
  for (let i = 0; i < value.length; i++) {
    const c = value[i];
    if (c === "\\") {
      out += c + (value[i + 1] ?? "");
      i++;
    } else if (c === '"') {
      out += '\\"';
    } else if (c === "\n") {
      out += "\\n";
    } else if (c === "\r") {
      out += "\\r";
    } else if (c === "\t") {
      out += "\\t";
    } else {
      out += c;
    }
  }
  return out + '"';
}

/** Index of the next token that is not whitespace or a comment. */
function nextSignificant(tokens: Token[], from: number): Token | undefined {
  for (let i = from; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.kind !== "space" && t.kind !== "comment") return t;
  }
  return undefined;
}

export function repairJson(input: string): RepairResult {
  // An already-valid document is returned byte-identical. Reformatting a good
  // payload would be a surprising thing for a "repair" action to do.
  const initial = parseJson(input);
  if (initial.success) {
    return { success: true, repaired: input, changes: [], data: initial.data };
  }

  const counts = new Map<RepairAction, number>();
  const bump = (action: RepairAction) => counts.set(action, (counts.get(action) ?? 0) + 1);

  let source = input;
  if (source.charCodeAt(0) === 0xfeff) {
    source = source.slice(1);
    bump("BOM_REMOVED");
  }

  const tokens = tokenizeLoose(source);
  const out: string[] = [];

  // Container stack and key position, so an identifier can be told from a value
  // and a comma can be told from a separator.
  const stack: ("object" | "array")[] = [];
  let expectKey = false;
  // The last emitted significant token, for missing-comma detection.
  let lastSignificant: "value-end" | "open" | "comma" | "colon" | null = null;
  // Set when a comment was just removed, so the following newline can be eaten.
  let droppedCommentBefore = false;

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];

    if (token.kind === "space") {
      // A dropped `// comment` leaves the newline before it and the newline
      // after it, i.e. a blank line. Absorb one of them so the repaired
      // document does not gain a gap for every comment removed. This has to
      // happen here rather than as a regex over the output: whitespace inside a
      // string is content, and the output no longer distinguishes the two.
      if (droppedCommentBefore && token.value.startsWith("\n")) {
        out.push(token.value.slice(1));
      } else {
        out.push(token.value);
      }
      droppedCommentBefore = false;
      continue;
    }

    if (token.kind === "comment") {
      bump("COMMENTS_STRIPPED");
      droppedCommentBefore = true;
      continue;
    }

    droppedCommentBefore = false;

    // Insert a separator when two values sit next to each other.
    const startsValue =
      token.kind === "string" ||
      token.kind === "word" ||
      (token.kind === "punct" && (token.value === "{" || token.value === "["));
    if (startsValue && lastSignificant === "value-end" && stack.length > 0) {
      // Splice the comma before any whitespace already emitted, so it lands
      // directly after the previous value.
      let insertAt = out.length;
      while (insertAt > 0 && /^[ \t\n\r]*$/.test(out[insertAt - 1])) insertAt--;
      out.splice(insertAt, 0, ",");
      bump("MISSING_COMMAS_INSERTED");
      lastSignificant = "comma";
      if (stack[stack.length - 1] === "object") expectKey = true;
    }

    if (token.kind === "string") {
      if (token.quote === "'") bump("SINGLE_QUOTES_CONVERTED");
      else if (token.quote === "smart") bump("SMART_QUOTES_REPLACED");
      out.push(toJsonString(token.value));
      expectKey = false;
      lastSignificant = "value-end";
      continue;
    }

    if (token.kind === "punct") {
      switch (token.value) {
        case "{":
          stack.push("object");
          expectKey = true;
          lastSignificant = "open";
          break;
        case "[":
          stack.push("array");
          expectKey = false;
          lastSignificant = "open";
          break;
        case "}":
        case "]":
          stack.pop();
          expectKey = false;
          lastSignificant = "value-end";
          break;
        case ":":
          expectKey = false;
          lastSignificant = "colon";
          break;
        case ",": {
          // Trailing comma: the next thing that matters closes the container.
          const next = nextSignificant(tokens, i + 1);
          if (next && next.kind === "punct" && (next.value === "}" || next.value === "]")) {
            bump("TRAILING_COMMAS_REMOVED");
            continue;
          }
          expectKey = stack[stack.length - 1] === "object";
          lastSignificant = "comma";
          break;
        }
      }
      out.push(token.value);
      continue;
    }

    if (token.kind === "word") {
      // In key position a bare word is an unquoted key.
      const next = nextSignificant(tokens, i + 1);
      const isKey = expectKey && next && next.kind === "punct" && next.value === ":";

      if (isKey) {
        out.push(toJsonString(token.value));
        bump("UNQUOTED_KEYS_QUOTED");
        expectKey = false;
        lastSignificant = "value-end";
        continue;
      }

      if (Object.prototype.hasOwnProperty.call(LITERALS, token.value)) {
        out.push(LITERALS[token.value]);
        bump("PYTHON_LITERALS_CONVERTED");
        lastSignificant = "value-end";
        continue;
      }

      out.push(token.value);
      lastSignificant = "value-end";
      continue;
    }

    out.push(token.value);
  }

  const repaired = out.join("");
  const changes: RepairChange[] = [...counts.entries()].map(([action, count]) => ({
    action,
    count,
    description: DESCRIPTIONS[action],
  }));

  const verified = parseJson(repaired);
  if (verified.success) {
    return { success: true, repaired, changes, data: verified.data };
  }

  // Something was changed but the document is still broken. Say so rather than
  // handing back output that looks repaired.
  return { success: false, repaired, changes, remainingError: verified.error.message };
}
