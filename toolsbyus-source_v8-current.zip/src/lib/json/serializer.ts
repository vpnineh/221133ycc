import { JsonValue, FormatOptions } from "./types";

export type KeySortOption = boolean | "none" | "alphabetical" | "natural" | "reverse";

export interface ExtendedFormatOptions extends Omit<FormatOptions, "sortKeys"> {
  sortKeys?: KeySortOption;
  unescapeUnicode?: boolean;
}

function escapeString(str: string, escapeUnicode?: boolean): string {
  let res = '"';
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    const code = str.charCodeAt(i);
    switch (ch) {
      case '"': res += '\\"'; break;
      case "\\": res += "\\\\"; break;
      case "\b": res += "\\b"; break;
      case "\f": res += "\\f"; break;
      case "\n": res += "\\n"; break;
      case "\r": res += "\\r"; break;
      case "\t": res += "\\t"; break;
      default:
        if (code < 0x20) {
          res += "\\u" + code.toString(16).padStart(4, "0");
        } else if (escapeUnicode && code > 0x7f) {
          res += "\\u" + code.toString(16).padStart(4, "0");
        } else {
          res += ch;
        }
    }
  }
  res += '"';
  return res;
}

export function unescapeUnicodeString(input: string): string {
  return input.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => {
    return String.fromCharCode(parseInt(hex, 16));
  });
}

export function serializeJson(
  value: JsonValue,
  options: ExtendedFormatOptions = { indent: 2 }
): string {
  const indentStr =
    options.indent === "tab"
      ? "\t"
      : " ".repeat(typeof options.indent === "number" ? options.indent : 2);
  const sortOption = options.sortKeys;
  const escapeUnicode = !!options.escapeUnicode;

  function stringify(val: JsonValue, depth: number): string {
    if (val === null) return "null";
    if (typeof val === "boolean") return val ? "true" : "false";
    if (typeof val === "number") {
      if (!Number.isFinite(val)) return "null";
      return String(val);
    }
    if (typeof val === "string") {
      return escapeString(val, escapeUnicode);
    }

    const currentIndent = indentStr.repeat(depth);
    const nextIndent = indentStr.repeat(depth + 1);

    if (Array.isArray(val)) {
      if (val.length === 0) return "[]";
      const items = val.map((item) => stringify(item, depth + 1));
      if (indentStr === "") {
        return `[${items.join(",")}]`;
      }
      return `[\n${items.map((it) => nextIndent + it).join(",\n")}\n${currentIndent}]`;
    }

    // Object
    const keys = Object.keys(val);
    if (keys.length === 0) return "{}";

    if (sortOption === true || sortOption === "alphabetical") {
      keys.sort();
    } else if (sortOption === "natural") {
      keys.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
    } else if (sortOption === "reverse") {
      keys.sort().reverse();
    }

    const entries = keys.map((k) => {
      const keyStr = escapeString(k, escapeUnicode);
      const valStr = stringify(val[k], depth + 1);
      if (indentStr === "") {
        return `${keyStr}:${valStr}`;
      }
      return `${nextIndent}${keyStr}: ${valStr}`;
    });

    if (indentStr === "") {
      return `{${entries.join(",")}}`;
    }
    return `{\n${entries.join(",\n")}\n${currentIndent}}`;
  }

  let result = stringify(value, 0);
  if (options.unescapeUnicode) {
    result = unescapeUnicodeString(result);
  }
  return result;
}
