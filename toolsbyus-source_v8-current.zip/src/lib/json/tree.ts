import type { JsonValue } from "./types";

/**
 * Flattens a JSON document into a list of rows for a virtualized tree.
 *
 * A recursive React tree renders one component per node, which is fine for the
 * 40-node documents in a tutorial and falls over on the 50,000-node API
 * response someone actually needs to read: every expand re-renders the subtree,
 * scrolling is janky, and the browser holds tens of thousands of DOM elements
 * for the handful on screen.
 *
 * Flattening moves the tree into an array, so the view can render only the rows
 * in the viewport — the same approach the diff list uses. Collapsing becomes a
 * question of which rows to skip rather than which components to unmount, and
 * the whole thing stays a single pass over the document.
 *
 * The traversal is iterative for the reason everything else here is: a
 * recursive one overflows the call stack on deeply nested input, which is
 * exactly the input someone brings to a viewer when nothing else will open it.
 */

export type JsonNodeType = "object" | "array" | "string" | "number" | "boolean" | "null";

export interface TreeRow {
  /** Stable identity: the JSON Pointer to this node. */
  id: string;
  /** Key within the parent, or the array index. Empty at the root. */
  key: string;
  depth: number;
  type: JsonNodeType;
  /** Rendered scalar value; undefined for containers. */
  display?: string;
  /** Child count, for containers. */
  size?: number;
  isContainer: boolean;
  /** Index of the row after this node's entire subtree. */
  endIndex: number;
}

export function typeOf(value: JsonValue): JsonNodeType {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  const t = typeof value;
  if (t === "object") return "object";
  if (t === "number") return "number";
  if (t === "boolean") return "boolean";
  return "string";
}

/** RFC 6901 escaping: `~` becomes `~0` and `/` becomes `~1`. */
export function pointerSegment(key: string): string {
  return key.replace(/~/g, "~0").replace(/\//g, "~1");
}

function renderScalar(value: JsonValue): string {
  if (typeof value === "string") return JSON.stringify(value);
  return String(value);
}

/**
 * Produces every row in document order, with each container recording where its
 * subtree ends so collapsing is a skip rather than a re-walk.
 */
export function flattenTree(root: JsonValue, rootLabel = "root"): TreeRow[] {
  const rows: TreeRow[] = [];

  // An explicit stack of work items. `emit` marks the point at which a
  // container's row is written; `close` fixes up its endIndex afterwards.
  type Frame =
    | { kind: "emit"; key: string; value: JsonValue; depth: number; pointer: string }
    | { kind: "close"; rowIndex: number };

  const stack: Frame[] = [
    { kind: "emit", key: rootLabel, value: root, depth: 0, pointer: "" },
  ];

  while (stack.length > 0) {
    const frame = stack.pop()!;

    if (frame.kind === "close") {
      rows[frame.rowIndex].endIndex = rows.length;
      continue;
    }

    const type = typeOf(frame.value);
    const isContainer = type === "object" || type === "array";
    const rowIndex = rows.length;

    if (!isContainer) {
      rows.push({
        id: frame.pointer || "/",
        key: frame.key,
        depth: frame.depth,
        type,
        display: renderScalar(frame.value),
        isContainer: false,
        endIndex: rowIndex + 1,
      });
      continue;
    }

    const entries: Array<[string, JsonValue]> = Array.isArray(frame.value)
      ? frame.value.map((child, index) => [String(index), child])
      : Object.entries(frame.value as Record<string, JsonValue>);

    rows.push({
      id: frame.pointer || "/",
      key: frame.key,
      depth: frame.depth,
      type,
      size: entries.length,
      isContainer: true,
      // Provisional; corrected by the matching close frame.
      endIndex: rowIndex + 1,
    });

    stack.push({ kind: "close", rowIndex });
    // Reverse so the stack yields children in document order.
    for (let i = entries.length - 1; i >= 0; i--) {
      const [key, child] = entries[i];
      stack.push({
        kind: "emit",
        key,
        value: child,
        depth: frame.depth + 1,
        pointer: `${frame.pointer}/${pointerSegment(key)}`,
      });
    }
  }

  return rows;
}

/**
 * The rows actually visible given a set of collapsed containers.
 *
 * Skipping by `endIndex` means a collapsed subtree costs one comparison
 * regardless of how many nodes it contains, so collapsing the root of a large
 * document is instant rather than proportional to its size.
 */
export function visibleRows(rows: TreeRow[], collapsed: ReadonlySet<string>): TreeRow[] {
  const out: TreeRow[] = [];
  let i = 0;
  while (i < rows.length) {
    const row = rows[i];
    out.push(row);
    i = row.isContainer && collapsed.has(row.id) ? row.endIndex : i + 1;
  }
  return out;
}

export interface TreeStats {
  nodes: number;
  objects: number;
  arrays: number;
  strings: number;
  numbers: number;
  booleans: number;
  nulls: number;
  maxDepth: number;
  /** Distinct object keys across the whole document. */
  uniqueKeys: number;
}

export function summarise(rows: TreeRow[]): TreeStats {
  const stats: TreeStats = {
    nodes: rows.length,
    objects: 0,
    arrays: 0,
    strings: 0,
    numbers: 0,
    booleans: 0,
    nulls: 0,
    maxDepth: 0,
    uniqueKeys: 0,
  };
  const keys = new Set<string>();

  for (const row of rows) {
    if (row.depth > stats.maxDepth) stats.maxDepth = row.depth;
    switch (row.type) {
      case "object":
        stats.objects++;
        break;
      case "array":
        stats.arrays++;
        break;
      case "string":
        stats.strings++;
        break;
      case "number":
        stats.numbers++;
        break;
      case "boolean":
        stats.booleans++;
        break;
      case "null":
        stats.nulls++;
        break;
    }
    // Array indices are not keys, and counting them would report a 10,000-item
    // array as 10,000 distinct keys.
    if (row.depth > 0 && !/^\d+$/.test(row.key)) keys.add(row.key);
  }

  stats.uniqueKeys = keys.size;
  return stats;
}

/** Row ids of every container, for expand-all / collapse-all. */
export function containerIds(rows: TreeRow[], maxDepth = Infinity): string[] {
  return rows.filter((row) => row.isContainer && row.depth < maxDepth).map((row) => row.id);
}

/**
 * Rows matching a query, plus every ancestor needed to reach them.
 *
 * Returning matches alone would show them detached from their context, which
 * for a JSON tree is most of the information — a value is meaningless without
 * the path that led to it.
 */
export function searchRows(rows: TreeRow[], query: string): Set<string> {
  const needle = query.trim().toLowerCase();
  if (!needle) return new Set();

  const keep = new Set<string>();
  // A stack of the ancestors currently open, so a match can mark its whole path.
  const ancestors: TreeRow[] = [];

  for (const row of rows) {
    while (ancestors.length > 0 && ancestors[ancestors.length - 1].depth >= row.depth) {
      ancestors.pop();
    }

    const hit =
      row.key.toLowerCase().includes(needle) ||
      (row.display !== undefined && row.display.toLowerCase().includes(needle));

    if (hit) {
      keep.add(row.id);
      for (const ancestor of ancestors) keep.add(ancestor.id);
    }

    if (row.isContainer) ancestors.push(row);
  }

  return keep;
}
