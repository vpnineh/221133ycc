export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonArray;
export type JsonObject = { [key: string]: JsonValue };
export type JsonArray = JsonValue[];

export type MalformedErrorType =
  | "BOM"
  | "SMART_QUOTES"
  | "SINGLE_QUOTES"
  | "UNQUOTED_KEY"
  | "TRAILING_COMMA"
  | "MISSING_COMMA"
  | "MISMATCHED_BRACKET"
  | "UNCLOSED_STRING"
  | "INVALID_NUMBER"
  | "NAN_INFINITY_REJECTED"
  | "TRUNCATED_DOCUMENT"
  | "SYNTAX_ERROR";

export interface ParseError {
  message: string;
  line: number;
  column: number;
  caretSnippet: string;
  errorType: MalformedErrorType;
}

export type ParseResult<T = JsonValue> =
  | { success: true; data: T; warnings?: string[] }
  | { success: false; error: ParseError };

export interface FormatOptions {
  indent: number | "tab";
  sortKeys?: boolean;
  preserveComments?: boolean;
  escapeUnicode?: boolean;
  bracketStyle?: "standard" | "expanded" | "compact";
}

export interface MinifyResult {
  minified: string;
  originalBytes: number;
  minifiedBytes: number;
  reductionPercent: number;
  estimatedGzipBytes: number;
  keyFrequency: Record<string, number>;
}
