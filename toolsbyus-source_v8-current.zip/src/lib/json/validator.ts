import { ParseError } from "./types";
import { parseJson } from "./parser";

export interface ValidationDetails {
  isValid: boolean;
  error?: ParseError;
  explanation?: string;
  recommendation?: string;
  stats?: {
    byteCount: number;
    charCount: number;
    lineCount: number;
    objectCount: number;
    arrayCount: number;
    keyCount: number;
  };
}

export function validateJson(input: string): ValidationDetails {
  const parseRes = parseJson(input);

  if (!parseRes.success) {
    const err = parseRes.error;
    let explanation = "";
    let recommendation = "";

    switch (err.errorType) {
      case "BOM":
        explanation = "The document begins with a Byte Order Mark (0xFEFF), which violates RFC 8259.";
        recommendation = "Strip the UTF-8 BOM bytes before parsing or save the file as UTF-8 without BOM.";
        break;
      case "SMART_QUOTES":
        explanation = "Smart/curly quotes (“ ” ‘ ’) were detected, likely pasted from a rich-text word processor.";
        recommendation = "Replace all curly quotes with standard ASCII straight double quotes (\").";
        break;
      case "SINGLE_QUOTES":
        explanation = "Single quotes (') were used to delimit strings or keys, which is valid JavaScript/Python syntax but forbidden in JSON.";
        recommendation = "Replace single quotes with double quotes (\").";
        break;
      case "UNQUOTED_KEY":
        explanation = "An unquoted identifier was encountered as an object property name.";
        recommendation = "Wrap all object property names in double quotes, e.g. \"key\": value.";
        break;
      case "TRAILING_COMMA":
        explanation = "A trailing comma was found preceding a closing bracket (} or ]).";
        recommendation = "Remove the trailing comma before the closing delimiter.";
        break;
      case "MISSING_COMMA":
        explanation = "Elements or key-value pairs are adjacent without a separating comma.";
        recommendation = "Insert a comma (,) between consecutive items or key-value pairs.";
        break;
      case "MISMATCHED_BRACKET":
        explanation = "A closing delimiter does not match its corresponding opening delimiter (e.g. { closed by ] or [ closed by }).";
        recommendation = "Ensure curly braces { } match objects and square brackets [ ] match arrays.";
        break;
      case "NAN_INFINITY_REJECTED":
        explanation = "NaN or Infinity was encountered. JSON numbers only permit finite decimal values.";
        recommendation = "Represent null or special numeric cases as null, or encode them as string literals.";
        break;
      case "TRUNCATED_DOCUMENT":
        explanation = "The document ended prematurely while an object, array, or string was still open.";
        recommendation = "Verify the document was not truncated during transfer, and ensure all open brackets and quotes are closed.";
        break;
      default:
        explanation = err.message;
        recommendation = "Review syntax around the indicated line and column.";
        break;
    }

    return {
      isValid: false,
      error: err,
      explanation,
      recommendation,
    };
  }

  // Calculate payload statistics iteratively
  let objectCount = 0;
  let arrayCount = 0;
  let keyCount = 0;
  const stack = [parseRes.data];

  while (stack.length > 0) {
    const curr = stack.pop();
    if (curr && typeof curr === "object") {
      if (Array.isArray(curr)) {
        arrayCount++;
        for (let i = curr.length - 1; i >= 0; i--) {
          stack.push(curr[i]);
        }
      } else {
        objectCount++;
        const keys = Object.keys(curr);
        keyCount += keys.length;
        for (let i = 0; i < keys.length; i++) {
          stack.push(curr[keys[i]]);
        }
      }
    }
  }

  return {
    isValid: true,
    stats: {
      byteCount: new TextEncoder().encode(input).length,
      charCount: input.length,
      lineCount: input.split(/\r?\n/).length,
      objectCount,
      arrayCount,
      keyCount,
    },
  };
}
