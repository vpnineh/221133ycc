import { decodeBase64 } from "../base64";
import { parseJson } from "../json/parser";
import type { JsonObject, JsonValue } from "../json/types";
import { safeGet } from "../safe-object";

/**
 * JSON Web Token inspection, to RFC 7519.
 *
 * This decodes and explains. It does not verify, and that distinction is the
 * whole point: verifying a signature requires the issuer's key, and the only
 * way a web page could obtain one is by sending your token somewhere. A tool
 * that offered verification here would be quietly undoing the guarantee that
 * makes it safe to paste a live credential into it in the first place.
 *
 * What it can do without the key is read the claims, decode the timestamps
 * into something a human can act on, and point out the specific structural
 * problems that cause real incidents — an `alg` of `none`, an empty signature,
 * a token that expired four hours ago, one that is not valid yet because the
 * issuing server's clock is ahead.
 */

export type JwtAlgorithmFamily = "HMAC" | "RSA" | "RSA-PSS" | "ECDSA" | "EdDSA" | "none" | "unknown";

export interface JwtClaim {
  name: string;
  value: JsonValue;
  /** What the claim means, for the registered ones. */
  description?: string;
  /** Human rendering of a NumericDate claim. */
  decoded?: string;
  registered: boolean;
}

export interface JwtAdvisory {
  severity: "error" | "warning" | "info";
  message: string;
}

export interface JwtSegments {
  header: string;
  payload: string;
  signature: string;
}

export interface JwtDecoded {
  ok: true;
  segments: JwtSegments;
  header: JsonObject;
  payload: JsonObject;
  headerJson: string;
  payloadJson: string;
  algorithm: string;
  algorithmFamily: JwtAlgorithmFamily;
  claims: JwtClaim[];
  advisories: JwtAdvisory[];
  /** Milliseconds until expiry; negative when already expired. */
  expiresInMs?: number;
}

export interface JwtFailure {
  ok: false;
  reason: string;
  /** Which segment failed, when that is known. */
  segment?: "structure" | "header" | "payload";
}

export type JwtResult = JwtDecoded | JwtFailure;

/**
 * The registered claims from RFC 7519 §4.1, plus the handful from OpenID
 * Connect that turn up in practically every real token.
 */
const REGISTERED_CLAIMS: Record<string, string> = {
  iss: "Issuer — who created and signed this token.",
  sub: "Subject — who the token is about, usually a user ID.",
  aud: "Audience — the recipient the token is intended for. A service must reject a token whose audience is not itself.",
  exp: "Expiration time — the token must be rejected at or after this instant.",
  nbf: "Not before — the token must be rejected before this instant.",
  iat: "Issued at — when the token was created.",
  jti: "JWT ID — a unique identifier, used to prevent replay.",
  // OpenID Connect
  azp: "Authorized party — the client the token was issued to.",
  nonce: "Nonce — binds the token to a specific authentication request.",
  auth_time: "Authentication time — when the user actually authenticated.",
  acr: "Authentication context class reference.",
  amr: "Authentication methods references — how the user proved identity.",
  scope: "Scope — the permissions granted.",
  email: "Email address of the subject.",
  email_verified: "Whether the issuer has verified the email address.",
  name: "Display name of the subject.",
  preferred_username: "Username chosen by the subject.",
};

/** Claims whose value is a NumericDate: seconds since the Unix epoch. */
const DATE_CLAIMS = new Set(["exp", "nbf", "iat", "auth_time", "updated_at"]);

export function classifyAlgorithm(alg: string): JwtAlgorithmFamily {
  const upper = alg.toUpperCase();
  if (upper === "NONE") return "none";
  if (/^HS(256|384|512)$/.test(upper)) return "HMAC";
  if (/^RS(256|384|512)$/.test(upper)) return "RSA";
  if (/^PS(256|384|512)$/.test(upper)) return "RSA-PSS";
  if (/^ES(256|256K|384|512)$/.test(upper)) return "ECDSA";
  if (upper === "EDDSA") return "EdDSA";
  return "unknown";
}

function formatDate(seconds: number): string {
  const date = new Date(seconds * 1000);
  if (Number.isNaN(date.getTime())) return "invalid date";
  return date.toISOString().replace("T", " ").replace(/\.\d+Z$/, " UTC");
}

/** "in 3 minutes" / "4 hours ago", for the timestamps that decide acceptance. */
function relativeTime(deltaMs: number): string {
  const abs = Math.abs(deltaMs);
  const units: Array<[number, string]> = [
    [1000, "second"],
    [60_000, "minute"],
    [3_600_000, "hour"],
    [86_400_000, "day"],
  ];
  let value = abs / 1000;
  let unit = "second";
  for (const [ms, name] of units) {
    if (abs >= ms) {
      value = abs / ms;
      unit = name;
    }
  }
  const rounded = value < 10 ? Math.round(value * 10) / 10 : Math.round(value);
  const plural = rounded === 1 ? "" : "s";
  return deltaMs >= 0 ? `in ${rounded} ${unit}${plural}` : `${rounded} ${unit}${plural} ago`;
}

function decodeSegment(segment: string): { json: string } | { error: string } {
  // JWT segments are base64url without padding (RFC 7515 §2). The shared
  // decoder handles both alphabets and tolerates the missing padding.
  const decoded = decodeBase64(segment, "utf-8");
  if (decoded.error) return { error: decoded.error };
  return { json: decoded.text };
}

export function decodeJwt(input: string, now: number = Date.now()): JwtResult {
  const trimmed = input.trim().replace(/^Bearer\s+/i, "");

  if (!trimmed) return { ok: false, reason: "No token supplied.", segment: "structure" };

  const parts = trimmed.split(".");
  if (parts.length !== 3) {
    return {
      ok: false,
      segment: "structure",
      reason:
        parts.length === 5
          ? "This looks like a JWE (five segments), which is encrypted rather than merely encoded. Its payload cannot be read without the decryption key."
          : `A JWT has three dot-separated segments; this has ${parts.length}. Check for a truncated copy-paste, or a stray quote or newline.`,
    };
  }

  const headerDecoded = decodeSegment(parts[0]);
  if ("error" in headerDecoded) {
    return { ok: false, segment: "header", reason: `Header is not valid base64url: ${headerDecoded.error}` };
  }
  const payloadDecoded = decodeSegment(parts[1]);
  if ("error" in payloadDecoded) {
    return { ok: false, segment: "payload", reason: `Payload is not valid base64url: ${payloadDecoded.error}` };
  }

  const headerParsed = parseJson(headerDecoded.json);
  if (!headerParsed.success) {
    return { ok: false, segment: "header", reason: `Header decoded, but is not valid JSON: ${headerParsed.error.message}` };
  }
  const payloadParsed = parseJson(payloadDecoded.json);
  if (!payloadParsed.success) {
    return { ok: false, segment: "payload", reason: `Payload decoded, but is not valid JSON: ${payloadParsed.error.message}` };
  }

  if (typeof headerParsed.data !== "object" || headerParsed.data === null || Array.isArray(headerParsed.data)) {
    return { ok: false, segment: "header", reason: "The header is valid JSON but is not an object." };
  }
  if (typeof payloadParsed.data !== "object" || payloadParsed.data === null || Array.isArray(payloadParsed.data)) {
    return { ok: false, segment: "payload", reason: "The payload is valid JSON but is not an object." };
  }

  const header = headerParsed.data as JsonObject;
  const payload = payloadParsed.data as JsonObject;

  const algValue = safeGet(header, "alg");
  const algorithm = typeof algValue === "string" ? algValue : "";
  const algorithmFamily = classifyAlgorithm(algorithm);

  const advisories: JwtAdvisory[] = [];

  if (!algorithm) {
    advisories.push({
      severity: "warning",
      message: 'The header has no "alg" member. RFC 7515 requires it, and a verifier has no way to know how to check the signature.',
    });
  } else if (algorithmFamily === "none") {
    advisories.push({
      severity: "error",
      message:
        'The algorithm is "none": this token is unsigned and anyone can forge one. A library that honours alg:none from the token itself is the classic JWT vulnerability — never accept this as proof of identity.',
    });
  } else if (algorithmFamily === "unknown") {
    advisories.push({
      severity: "warning",
      message: `"${algorithm}" is not a JOSE-registered algorithm. Verify it is what the issuer intends before trusting the token.`,
    });
  }

  if (parts[2] === "") {
    advisories.push({
      severity: "error",
      message: "The signature segment is empty, so the token carries no integrity protection at all.",
    });
  }

  let expiresInMs: number | undefined;
  const exp = safeGet(payload, "exp");
  if (typeof exp === "number") {
    expiresInMs = exp * 1000 - now;
    if (expiresInMs < 0) {
      advisories.push({
        severity: "error",
        message: `Expired ${relativeTime(expiresInMs)}, at ${formatDate(exp)}. A correct verifier rejects this token.`,
      });
    } else if (expiresInMs < 5 * 60_000) {
      advisories.push({
        severity: "warning",
        message: `Expires ${relativeTime(expiresInMs)}, at ${formatDate(exp)}.`,
      });
    }
  } else if (exp !== undefined) {
    advisories.push({
      severity: "warning",
      message: '"exp" is present but is not a number. RFC 7519 defines it as a NumericDate — seconds since the epoch, not a string.',
    });
  } else {
    advisories.push({
      severity: "warning",
      message: 'No "exp" claim: this token does not expire on its own and can only be stopped by revocation.',
    });
  }

  const nbf = safeGet(payload, "nbf");
  if (typeof nbf === "number" && nbf * 1000 > now) {
    advisories.push({
      severity: "warning",
      message: `Not valid until ${formatDate(nbf)} (${relativeTime(nbf * 1000 - now)}). If that is unexpected, the issuing server's clock is probably ahead.`,
    });
  }

  const iat = safeGet(payload, "iat");
  if (typeof iat === "number" && iat * 1000 > now + 60_000) {
    advisories.push({
      severity: "warning",
      message: `Issued at ${formatDate(iat)}, which is in the future. Clock skew between the issuer and this machine.`,
    });
  }

  if (safeGet(payload, "aud") === undefined) {
    advisories.push({
      severity: "info",
      message: 'No "aud" claim. Without an audience, a token issued for one service can be replayed against another that trusts the same issuer.',
    });
  }

  const claims: JwtClaim[] = Object.keys(payload).map((name) => {
    const value = payload[name];
    const claim: JwtClaim = {
      name,
      value,
      registered: name in REGISTERED_CLAIMS,
      description: REGISTERED_CLAIMS[name],
    };
    if (DATE_CLAIMS.has(name) && typeof value === "number") {
      const delta = value * 1000 - now;
      claim.decoded = `${formatDate(value)} (${relativeTime(delta)})`;
    }
    return claim;
  });

  return {
    ok: true,
    segments: { header: parts[0], payload: parts[1], signature: parts[2] },
    header,
    payload,
    headerJson: headerDecoded.json,
    payloadJson: payloadDecoded.json,
    algorithm,
    algorithmFamily,
    claims,
    advisories,
    expiresInMs,
  };
}

/** Cheap shape test, for deciding whether to even try. */
export function looksLikeJwt(input: string): boolean {
  const trimmed = input.trim().replace(/^Bearer\s+/i, "");
  return /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$/.test(trimmed);
}
