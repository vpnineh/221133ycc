/**
 * Input-size ceilings for tools that process synchronously on the main thread.
 *
 * Only the JSON diff runs in a Web Worker. Every other tool parses and formats
 * inside a `useMemo` during render, so an oversized paste freezes the tab with
 * no feedback — the browser cannot even paint a spinner. These ceilings turn
 * that into an explicit, honest message.
 *
 * The reference table on each tool page documents this limit, so the constant
 * and the copy must agree.
 */

/**
 * Main-thread tools: format, minify, validate, edit, infer schema, text diff.
 *
 * Measured, not guessed. With the document held in a controlled <textarea>, the
 * round-trip from input event to rendered result is roughly 2.5s at 6 MB and
 * 16s at 20 MB — the cost is React re-rendering the textarea, not the parser.
 * 8 MB is the largest input this shape of UI handles without feeling broken.
 *
 * (The pages previously documented a 50 MB ceiling that no code enforced and
 * the browser could not deliver; a 60 MB paste simply froze the tab.)
 */
export const MAIN_THREAD_MAX_BYTES = 8 * 1024 * 1024;

/**
 * Combined ceiling for the two documents handed to the diff worker. Much higher
 * because parsing and diffing happen off the main thread.
 */
export const WORKER_MAX_BYTES = 100 * 1024 * 1024;

/** Past this size the UI warns that an operation may block briefly. */
export const MAIN_THREAD_WARN_BYTES = 2 * 1024 * 1024;

/** Exact UTF-8 byte length. Allocates a copy, so avoid it in hot paths. */
export function byteLength(input: string): number {
  return new TextEncoder().encode(input).length;
}

/**
 * UTF-8 byte length without allocating a copy of the input.
 *
 * `byteLength` encodes the whole string, which on a multi-megabyte document
 * runs on every keystroke and allocates a fresh buffer each time — the size
 * guard itself becomes the thing that makes the page slow. Counting code points
 * is a single pass with no allocation.
 */
export function fastByteLength(input: string): number {
  let bytes = 0;
  for (let i = 0; i < input.length; i++) {
    const code = input.charCodeAt(i);
    if (code < 0x80) bytes += 1;
    else if (code < 0x800) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff) {
      // High surrogate: a 4-byte astral character. Consume the low surrogate too.
      bytes += 4;
      i++;
    } else bytes += 3;
  }
  return bytes;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export interface SizeCheck {
  /** True when the input is too large to process without freezing the tab. */
  exceeded: boolean;
  /** True when the input is large enough that the operation may visibly block. */
  slow: boolean;
  bytes: number;
  message: string | null;
}

export function checkMainThreadSize(
  input: string,
  limitBytes: number = MAIN_THREAD_MAX_BYTES
): SizeCheck {
  const bytes = fastByteLength(input);

  if (bytes > limitBytes) {
    return {
      exceeded: true,
      slow: false,
      bytes,
      message:
        `Input is ${formatBytes(bytes)}, above this tool's ${formatBytes(limitBytes)} ceiling. ` +
        `Processing was stopped rather than freezing the tab. Split the document, or use ` +
        `JSON Diff, which streams work to a Web Worker.`,
    };
  }

  if (bytes > MAIN_THREAD_WARN_BYTES) {
    return {
      exceeded: false,
      slow: true,
      bytes,
      message: `Large input (${formatBytes(bytes)}) — this runs on the main thread and may pause the page briefly.`,
    };
  }

  return { exceeded: false, slow: false, bytes, message: null };
}
