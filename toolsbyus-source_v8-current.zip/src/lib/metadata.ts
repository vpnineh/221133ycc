import type { Metadata } from "next";
import { SITE_NAME, absoluteUrl } from "./site";

interface ToolMetadataInput {
  /** Route path, e.g. "/json-diff". */
  path: string;
  /** Page title without the brand suffix; the layout template appends it. */
  title: string;
  description: string;
  /** Optional social-card title, when the SERP title reads awkwardly as a card. */
  socialTitle?: string;
}

/**
 * Build per-page metadata.
 *
 * Next.js *replaces* rather than merges the `openGraph` and `twitter` objects
 * when a page declares its own, so a page that set only a title and URL silently
 * dropped the layout's og:image — every tool page was sharing without a card
 * image. Routing every page through this helper keeps the image, the canonical
 * and the site name attached, and keeps the origin in one place.
 */
export function buildToolMetadata({
  path,
  title,
  description,
  socialTitle,
}: ToolMetadataInput): Metadata {
  const url = absoluteUrl(path);
  const cardTitle = socialTitle ?? title;
  const image = {
    url: absoluteUrl("/og-image.png"),
    width: 1200,
    height: 630,
    alt: `${cardTitle} — ${SITE_NAME}`,
    type: "image/png",
  };

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title: `${cardTitle} | ${SITE_NAME}`,
      description,
      url,
      siteName: SITE_NAME,
      type: "website",
      locale: "en_US",
      images: [image],
    },
    twitter: {
      card: "summary_large_image",
      title: `${cardTitle} | ${SITE_NAME}`,
      description,
      images: [image.url],
    },
  };
}
