/**
 * Base conversion built on BigInt rather than `parseInt`.
 *
 * `parseInt("9007199254740993", 10)` returns 9007199254740992. The digits are
 * silently wrong, and nothing in the API says so. Anyone converting a base is
 * usually looking at an identifier, a bitmask or a hash, which is exactly the
 * material that exceeds 2^53 and exactly the material where a changed digit
 * matters. So integers go through BigInt end to end and are never round-tripped
 * through a double.
 *
 * Fractions are a separate path: BigInt has no fractional part, so the fraction
 * is converted digit by digit by repeated multiplication, which terminates when
 * the remainder does or at a digit budget when it does not — one third is 0.333…
 * in base 10 and exactly 0.1 in base 3.
 */

const DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz";

export interface ParsedNumber {
  /** Integer magnitude. */
  integer: bigint;
  /** Fraction digits in the source base, most significant first. */
  fraction: number[];
  negative: boolean;
}

export type ParseOutcome = { ok: true; value: ParsedNumber } | { ok: false; error: string };

/** Fraction digits emitted before giving up on a non-terminating expansion. */
export const MAX_FRACTION_DIGITS = 40;

export function digitValue(char: string): number {
  const index = DIGITS.indexOf(char.toLowerCase());
  return index;
}

export function parseInBase(input: string, base: number): ParseOutcome {
  if (base < 2 || base > 36) return { ok: false, error: "Base must be between 2 and 36." };

  // Underscores and spaces as digit separators: 1010_1010 and 1010 1010 are how
  // people actually write a byte, and rejecting them is pointless pedantry.
  const cleaned = input.trim().replace(/[_\s]/g, "");
  if (cleaned === "") return { ok: false, error: "Nothing to convert." };

  const negative = cleaned.startsWith("-");
  const body = negative || cleaned.startsWith("+") ? cleaned.slice(1) : cleaned;

  // A prefix that contradicts the chosen base is a mistake worth naming rather
  // than silently treating 0x as two digits.
  const prefixed = /^0([bBoOxX])(.*)$/.exec(body);
  let digits = body;
  if (prefixed) {
    const implied = { b: 2, o: 8, x: 16 }[prefixed[1].toLowerCase() as "b" | "o" | "x"];
    if (implied !== base) {
      return {
        ok: false,
        error: `The input starts with 0${prefixed[1]}, which means base ${implied}, but base ${base} is selected.`,
      };
    }
    digits = prefixed[2];
  }

  const [intPart, fracPart = "", ...rest] = digits.split(".");
  if (rest.length > 0) return { ok: false, error: "More than one decimal point." };
  if (intPart === "" && fracPart === "") return { ok: false, error: "Nothing to convert." };

  let integer = 0n;
  const bigBase = BigInt(base);
  for (const char of intPart) {
    const value = digitValue(char);
    if (value === -1 || value >= base) {
      return { ok: false, error: `"${char}" is not a digit in base ${base}.` };
    }
    integer = integer * bigBase + BigInt(value);
  }

  const fraction: number[] = [];
  for (const char of fracPart) {
    const value = digitValue(char);
    if (value === -1 || value >= base) {
      return { ok: false, error: `"${char}" is not a digit in base ${base}.` };
    }
    fraction.push(value);
  }

  return { ok: true, value: { integer, fraction, negative } };
}

export interface FormatOptions {
  /** Group digits: every 4 in binary, every 3 in decimal, every 2 in hex. */
  grouping: boolean;
  uppercase: boolean;
  /** Prefix binary, octal and hex with 0b, 0o and 0x. */
  prefix: boolean;
}

export const FORMAT_DEFAULTS: FormatOptions = {
  grouping: false,
  uppercase: false,
  prefix: false,
};

export function formatInBase(
  value: ParsedNumber,
  fromBase: number,
  toBase: number,
  options: FormatOptions
): string {
  const bigTo = BigInt(toBase);

  let digits = "";
  let remaining = value.integer;
  if (remaining === 0n) digits = "0";
  while (remaining > 0n) {
    digits = DIGITS[Number(remaining % bigTo)] + digits;
    remaining /= bigTo;
  }

  let out = options.grouping ? group(digits, toBase) : digits;

  if (value.fraction.length > 0) {
    out += `.${convertFraction(value.fraction, fromBase, toBase)}`;
  }
  if (options.prefix) {
    const prefix = { 2: "0b", 8: "0o", 16: "0x" }[toBase];
    if (prefix) out = prefix + out;
  }
  if (options.uppercase) out = out.toUpperCase().replace(/^0([BOX])/, (_m, p) => `0${p.toLowerCase()}`);

  return value.negative ? `-${out}` : out;
}

/**
 * Converts a fraction between bases by repeated multiplication.
 *
 * Each step multiplies the fractional digits by the target base and takes the
 * carry as the next output digit. All arithmetic stays in the source base on
 * integers, so nothing passes through a float and 0.1 in base 3 comes out
 * exactly, rather than as 0.3333333333333333.
 */
function convertFraction(fraction: number[], fromBase: number, toBase: number): string {
  let digits = [...fraction];
  let out = "";

  for (let step = 0; step < MAX_FRACTION_DIGITS && digits.some((d) => d !== 0); step++) {
    let carry = 0;
    for (let i = digits.length - 1; i >= 0; i--) {
      const product = digits[i] * toBase + carry;
      digits[i] = product % fromBase;
      carry = Math.floor(product / fromBase);
    }
    out += DIGITS[carry];
    // Trailing zeros contribute nothing and grow the array without bound.
    while (digits.length > 0 && digits[digits.length - 1] === 0) digits = digits.slice(0, -1);
  }

  return out === "" ? "0" : out;
}

function group(digits: string, base: number): string {
  const size = base === 2 ? 4 : base === 16 ? 2 : base === 8 ? 3 : 3;
  const separator = base === 10 ? "," : " ";
  const parts: string[] = [];
  for (let end = digits.length; end > 0; end -= size) {
    parts.unshift(digits.slice(Math.max(0, end - size), end));
  }
  return parts.join(separator);
}

/* -------------------------------------------------------------------------- */
/* Machine representations                                                    */
/* -------------------------------------------------------------------------- */

export interface IntegerFacts {
  bitLength: number;
  /** Fits in 8, 16, 32 or 64 bits, signed and unsigned. */
  fits: Array<{ type: string; ok: boolean }>;
  /** Two's complement representation at the smallest width that holds it. */
  twosComplement?: { width: number; hex: string; binary: string };
  /** Set bit positions, for a value used as a bitmask. */
  setBits: number[];
}

const WIDTHS = [8, 16, 32, 64] as const;

export function describeInteger(value: bigint): IntegerFacts {
  const magnitude = value < 0n ? -value : value;
  const bitLength = magnitude === 0n ? 0 : magnitude.toString(2).length;

  const fits: Array<{ type: string; ok: boolean }> = [];
  for (const width of WIDTHS) {
    const unsignedMax = (1n << BigInt(width)) - 1n;
    const signedMax = (1n << BigInt(width - 1)) - 1n;
    const signedMin = -(1n << BigInt(width - 1));
    fits.push({ type: `int${width}`, ok: value >= signedMin && value <= signedMax });
    fits.push({ type: `uint${width}`, ok: value >= 0n && value <= unsignedMax });
  }

  let twosComplement: IntegerFacts["twosComplement"];
  const width = WIDTHS.find((candidate) => {
    const signedMax = (1n << BigInt(candidate - 1)) - 1n;
    const signedMin = -(1n << BigInt(candidate - 1));
    return value >= signedMin && value <= signedMax;
  });
  if (width) {
    // Two's complement of a negative number is what a debugger shows, and the
    // reason -1 reads as ffffffff rather than as -1.
    const encoded = value < 0n ? (1n << BigInt(width)) + value : value;
    twosComplement = {
      width,
      hex: encoded.toString(16).padStart(width / 4, "0"),
      binary: encoded.toString(2).padStart(width, "0"),
    };
  }

  const setBits: number[] = [];
  if (value > 0n) {
    const binary = value.toString(2);
    for (let i = 0; i < binary.length; i++) {
      if (binary[binary.length - 1 - i] === "1") setBits.push(i);
    }
  }

  return { bitLength, fits, twosComplement, setBits };
}

export const COMMON_BASES = [
  { base: 2, name: "Binary" },
  { base: 8, name: "Octal" },
  { base: 10, name: "Decimal" },
  { base: 16, name: "Hexadecimal" },
  { base: 36, name: "Base 36" },
];
