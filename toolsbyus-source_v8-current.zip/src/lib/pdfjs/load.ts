/**
 * Loading pdf.js, which needs more care than a plain dynamic import.
 *
 * pdf.js splits itself in two: a thin API on the calling thread and a worker
 * that does the parsing. That is already the right architecture — the expensive
 * part is off the main thread without us arranging it — so the tools here call
 * it directly rather than wrapping it in a second worker, which would mean a
 * nested worker and, on the rendering side, no canvas to draw on.
 *
 * The worker file has to be located explicitly. `new URL(..., import.meta.url)`
 * is the form bundlers recognise as an asset reference, so the worker is emitted
 * alongside the build and served from the same origin — which matters because
 * `connect-src 'self'` would block it from anywhere else, and because a CDN
 * reference is exactly the third-party dependency this site does not have.
 */

type PdfJs = typeof import("pdfjs-dist");

let cached: Promise<PdfJs> | null = null;

export function loadPdfJs(): Promise<PdfJs> {
  // One load per session. The library is a megabyte of JavaScript; fetching it
  // again for the second document would be a visible pause for nothing.
  cached ??= (async () => {
    const pdfjs = await import("pdfjs-dist");
    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
      "pdfjs-dist/build/pdf.worker.min.mjs",
      import.meta.url
    ).toString();
    return pdfjs;
  })();

  return cached;
}

/** Ceiling for a render, in device pixels per PDF point. */
export const MAX_RENDER_SCALE = 4;

/**
 * A render scale from a target DPI.
 *
 * PDF units are points — 1/72 inch — so the scale factor for a given DPI is
 * simply DPI/72. At 72 the output matches the page's nominal size, at 150 it is
 * readable when printed, and at 300 it is print quality and four times the
 * pixels of 150.
 */
export function scaleForDpi(dpi: number): number {
  return Math.min(MAX_RENDER_SCALE, Math.max(0.25, dpi / 72));
}

export interface RenderedPage {
  index: number;
  blob: Blob;
  width: number;
  height: number;
}

/**
 * Turns a canvas into a blob, waiting for the encode.
 *
 * `toBlob` is asynchronous and its callback receives null when encoding fails —
 * which happens on a canvas larger than the browser's maximum, silently, and is
 * the usual cause of a page-to-image tool producing nothing at high DPI.
 */
export function canvasToBlob(
  canvas: HTMLCanvasElement,
  type: string,
  quality: number
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else
          reject(
            new Error(
              "The browser could not encode that page — the canvas is probably larger than its maximum. Try a lower DPI."
            )
          );
      },
      type,
      quality
    );
  });
}
