/**
 * QR code generation, implemented from ISO/IEC 18004.
 *
 * Written out rather than pulled from a package for the reason the whole site
 * exists: a QR generator that calls a server sends it whatever you encoded, and
 * what people encode is Wi-Fi passwords, TOTP secrets, payment strings and
 * private URLs. Every "free online QR generator" with a tracking redirect is
 * that problem in commercial form.
 *
 * Four parts, in order of how much of the work they are:
 *
 * 1. Mode selection and bit encoding. Numeric packs three digits into ten bits,
 *    alphanumeric packs two characters into eleven, and byte mode is eight bits
 *    each. Choosing the narrowest mode the data allows is what keeps a URL in a
 *    small symbol.
 * 2. Reed–Solomon error correction over GF(256). This is the reason a QR code
 *    still scans with a coffee ring on it, and it is most of this file.
 * 3. Module placement: finder patterns, timing, alignment, format information,
 *    then the data in a zigzag up and down the remaining space.
 * 4. Masking. Eight patterns are applied in turn and scored by four penalty
 *    rules; the lowest-scoring one is kept, because large blank areas and
 *    finder-like runs in the data confuse scanners.
 */

export type ErrorCorrection = "L" | "M" | "Q" | "H";

export interface QrOptions {
  errorCorrection: ErrorCorrection;
  /** Quiet zone in modules. The spec requires 4; scanners need it. */
  margin: number;
  /** Pixels per module in the rendered output. */
  scale: number;
}

export const QR_DEFAULTS: QrOptions = {
  errorCorrection: "M",
  margin: 4,
  scale: 8,
};

export interface QrMatrix {
  size: number;
  /** Row-major; true is a dark module. */
  modules: boolean[][];
  version: number;
  errorCorrection: ErrorCorrection;
  mode: "numeric" | "alphanumeric" | "byte";
  /** Bytes the payload occupied, for the tool's status line. */
  dataBytes: number;
}

/* -------------------------------------------------------------------------- */
/* Galois field arithmetic                                                    */
/* -------------------------------------------------------------------------- */

/**
 * GF(256) with the QR primitive polynomial 0x11D.
 *
 * Multiplication in the field becomes addition of logarithms, so the tables are
 * built once and every later multiply is two lookups and an add.
 */
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);

for (let i = 0, x = 1; i < 255; i++) {
  EXP[i] = x;
  LOG[x] = i;
  x <<= 1;
  if (x & 0x100) x ^= 0x11d;
}
for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];

function gfMultiply(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return EXP[LOG[a] + LOG[b]];
}

/** The generator polynomial for `degree` error-correction codewords. */
function generatorPolynomial(degree: number): Uint8Array {
  let poly = new Uint8Array([1]);
  for (let i = 0; i < degree; i++) {
    const next = new Uint8Array(poly.length + 1);
    for (let j = 0; j < poly.length; j++) {
      next[j] ^= poly[j];
      next[j + 1] ^= gfMultiply(poly[j], EXP[i]);
    }
    poly = next;
  }
  return poly;
}

/** Polynomial long division; the remainder is the error-correction block. */
function reedSolomon(data: Uint8Array, degree: number): Uint8Array {
  const generator = generatorPolynomial(degree);
  const remainder = new Uint8Array(degree);

  for (const byte of data) {
    const factor = byte ^ remainder[0];
    remainder.copyWithin(0, 1);
    remainder[degree - 1] = 0;
    for (let i = 0; i < degree; i++) {
      remainder[i] ^= gfMultiply(generator[i + 1], factor);
    }
  }

  return remainder;
}

/* -------------------------------------------------------------------------- */
/* Capacity tables                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Per version and level: total error-correction codewords, block counts.
 *
 * From the tables in ISO/IEC 18004 section 7.5. Versions 1 to 20 are enough for
 * anything a person pastes into a browser: version 20 at level L holds 858
 * bytes, and a QR code that dense is already at the limit of what a phone camera
 * resolves.
 */
const EC_TABLE: Record<ErrorCorrection, Array<[number, number, number]>> = {
  // [ec codewords per block, group 1 blocks, group 2 blocks]
  L: [
    [7, 1, 0], [10, 1, 0], [15, 1, 0], [20, 1, 0], [26, 1, 0], [18, 2, 0], [20, 2, 0],
    [24, 2, 0], [30, 2, 0], [18, 2, 2], [20, 4, 0], [24, 2, 2], [26, 4, 0], [30, 3, 1],
    [22, 5, 1], [24, 5, 1], [28, 1, 5], [30, 5, 1], [28, 3, 4], [28, 3, 5],
  ],
  M: [
    [10, 1, 0], [16, 1, 0], [26, 1, 0], [18, 2, 0], [24, 2, 0], [16, 4, 0], [18, 4, 0],
    [22, 2, 2], [22, 3, 2], [26, 4, 1], [30, 1, 4], [22, 6, 2], [22, 8, 1], [24, 4, 5],
    [24, 5, 5], [28, 7, 3], [28, 10, 1], [26, 9, 4], [26, 3, 11], [26, 3, 13],
  ],
  Q: [
    [13, 1, 0], [22, 1, 0], [18, 2, 0], [26, 2, 0], [18, 2, 2], [24, 4, 0], [18, 2, 4],
    [22, 4, 2], [20, 4, 4], [24, 6, 2], [28, 4, 4], [26, 4, 6], [24, 8, 4], [20, 11, 5],
    [30, 5, 7], [24, 15, 2], [28, 1, 15], [28, 17, 1], [26, 17, 4], [30, 15, 5],
  ],
  H: [
    [17, 1, 0], [28, 1, 0], [22, 2, 0], [16, 4, 0], [22, 2, 2], [28, 4, 0], [26, 4, 1],
    [26, 4, 2], [24, 4, 4], [28, 6, 2], [24, 3, 8], [28, 7, 4], [22, 12, 4], [24, 11, 5],
    [24, 11, 7], [30, 3, 13], [28, 2, 17], [28, 2, 19], [26, 9, 16], [28, 15, 10],
  ],
};

/** Total codewords in the symbol, by version. Section 7.4.10. */
const TOTAL_CODEWORDS = [
  26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085,
];

/** Alignment pattern centre coordinates, by version. */
const ALIGNMENT_POSITIONS: number[][] = [
  [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46],
  [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70],
  [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90],
];

const ALPHANUMERIC = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";

export type QrError = { error: string };

function chooseMode(text: string): "numeric" | "alphanumeric" | "byte" {
  if (/^\d*$/.test(text)) return "numeric";
  if ([...text].every((char) => ALPHANUMERIC.includes(char))) return "alphanumeric";
  return "byte";
}

/** Bits the character-count indicator occupies, which grows with version. */
function countBits(mode: string, version: number): number {
  if (version <= 9) return mode === "numeric" ? 10 : mode === "alphanumeric" ? 9 : 8;
  if (version <= 26) return mode === "numeric" ? 12 : mode === "alphanumeric" ? 11 : 16;
  return mode === "numeric" ? 14 : mode === "alphanumeric" ? 13 : 16;
}

class BitBuffer {
  private bits: number[] = [];

  put(value: number, length: number): void {
    for (let i = length - 1; i >= 0; i--) this.bits.push((value >>> i) & 1);
  }

  get length(): number {
    return this.bits.length;
  }

  padToByte(): void {
    while (this.bits.length % 8 !== 0) this.bits.push(0);
  }

  toBytes(): Uint8Array {
    const bytes = new Uint8Array(this.bits.length / 8);
    for (let i = 0; i < bytes.length; i++) {
      let byte = 0;
      for (let bit = 0; bit < 8; bit++) byte = (byte << 1) | this.bits[i * 8 + bit];
      bytes[i] = byte;
    }
    return bytes;
  }
}

function encodeData(text: string, mode: string, version: number): BitBuffer {
  const buffer = new BitBuffer();
  const modeIndicator = mode === "numeric" ? 1 : mode === "alphanumeric" ? 2 : 4;
  buffer.put(modeIndicator, 4);

  const bytes = new TextEncoder().encode(text);
  const count = mode === "byte" ? bytes.length : text.length;
  buffer.put(count, countBits(mode, version));

  if (mode === "numeric") {
    // Three digits in ten bits, which is why a numeric QR holds so much more.
    for (let i = 0; i < text.length; i += 3) {
      const group = text.slice(i, i + 3);
      buffer.put(Number(group), group.length === 3 ? 10 : group.length === 2 ? 7 : 4);
    }
  } else if (mode === "alphanumeric") {
    // Two characters in eleven bits.
    for (let i = 0; i < text.length; i += 2) {
      if (i + 1 < text.length) {
        buffer.put(
          ALPHANUMERIC.indexOf(text[i]) * 45 + ALPHANUMERIC.indexOf(text[i + 1]),
          11
        );
      } else {
        buffer.put(ALPHANUMERIC.indexOf(text[i]), 6);
      }
    }
  } else {
    // Byte mode is UTF-8 here, which is what every modern scanner assumes even
    // though the spec nominally says ISO-8859-1.
    for (const byte of bytes) buffer.put(byte, 8);
  }

  return buffer;
}

function capacityBits(version: number, level: ErrorCorrection): number {
  const [ecPerBlock, group1, group2] = EC_TABLE[level][version - 1];
  const blocks = group1 + group2;
  return (TOTAL_CODEWORDS[version - 1] - ecPerBlock * blocks) * 8;
}

/** Interleaves data and error-correction blocks, per section 7.6. */
function buildCodewords(data: Uint8Array, version: number, level: ErrorCorrection): Uint8Array {
  const [ecPerBlock, group1Count, group2Count] = EC_TABLE[level][version - 1];
  const totalBlocks = group1Count + group2Count;
  const totalData = TOTAL_CODEWORDS[version - 1] - ecPerBlock * totalBlocks;
  const group1Size = Math.floor(totalData / totalBlocks);

  const dataBlocks: Uint8Array[] = [];
  const ecBlocks: Uint8Array[] = [];
  let offset = 0;

  for (let i = 0; i < totalBlocks; i++) {
    const size = i < group1Count ? group1Size : group1Size + 1;
    const block = data.slice(offset, offset + size);
    offset += size;
    dataBlocks.push(block);
    ecBlocks.push(reedSolomon(block, ecPerBlock));
  }

  // Interleaving is what makes a burst of damage hit one codeword in each block
  // rather than destroying one block entirely — which is the whole point, since
  // Reed–Solomon corrects a bounded number of errors *per block*.
  const out: number[] = [];
  const maxDataLength = Math.max(...dataBlocks.map((block) => block.length));
  for (let i = 0; i < maxDataLength; i++) {
    for (const block of dataBlocks) if (i < block.length) out.push(block[i]);
  }
  for (let i = 0; i < ecPerBlock; i++) {
    for (const block of ecBlocks) out.push(block[i]);
  }

  return Uint8Array.from(out);
}

/* -------------------------------------------------------------------------- */
/* Module placement                                                           */
/* -------------------------------------------------------------------------- */

/**
 * The symbol under construction.
 *
 * `isFunction` is a separate grid rather than a null sentinel in `modules`
 * because the distinction is needed twice and means different things each time:
 * data placement skips function modules, and masking must not flip them. A
 * single grid cannot answer "is this a function module?" once a false data bit
 * has been written into it.
 */
interface Symbol_ {
  size: number;
  modules: boolean[][];
  isFunction: boolean[][];
}

function createSymbol(size: number): Symbol_ {
  return {
    size,
    modules: Array.from({ length: size }, () => Array.from({ length: size }, () => false)),
    isFunction: Array.from({ length: size }, () => Array.from({ length: size }, () => false)),
  };
}

function setFunction(symbol: Symbol_, row: number, col: number, dark: boolean): void {
  if (row < 0 || row >= symbol.size || col < 0 || col >= symbol.size) return;
  symbol.modules[row][col] = dark;
  symbol.isFunction[row][col] = true;
}

function placeFunctionPatterns(symbol: Symbol_, version: number): void {
  const { size } = symbol;

  // A finder is a 7x7 pattern plus a one-module light separator around it.
  const setFinder = (row: number, col: number) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const onBorder = r === 0 || r === 6 || c === 0 || c === 6;
        const inCentre = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        const inside = r >= 0 && r <= 6 && c >= 0 && c <= 6;
        setFunction(symbol, row + r, col + c, inside && (onBorder || inCentre));
      }
    }
  };

  setFinder(0, 0);
  setFinder(0, size - 7);
  setFinder(size - 7, 0);

  // Timing patterns: the alternating row and column a scanner uses to work out
  // the module pitch across the symbol.
  for (let i = 8; i < size - 8; i++) {
    setFunction(symbol, 6, i, i % 2 === 0);
    setFunction(symbol, i, 6, i % 2 === 0);
  }

  // Alignment patterns, everywhere except where a finder already is.
  const positions = ALIGNMENT_POSITIONS[version - 1];
  for (const row of positions) {
    for (const col of positions) {
      const nearFinder =
        (row <= 8 && col <= 8) || (row <= 8 && col >= size - 9) || (row >= size - 9 && col <= 8);
      if (nearFinder) continue;
      for (let r = -2; r <= 2; r++) {
        for (let c = -2; c <= 2; c++) {
          setFunction(symbol, row + r, col + c, Math.max(Math.abs(r), Math.abs(c)) !== 1);
        }
      }
    }
  }

  // The dark module, which is always set and always in this one place.
  setFunction(symbol, size - 8, 8, true);

  // Format information areas are reserved now and filled per mask later.
  // Index 6 is skipped in both directions: row 8 column 6 and row 6 column 8
  // belong to the timing patterns, which is why the format bits are 15 long
  // across what looks like 16 cells.
  for (let i = 0; i < 9; i++) {
    if (i !== 6) {
      setFunction(symbol, 8, i, false);
      setFunction(symbol, i, 8, false);
    }
  }
  for (let i = 0; i < 8; i++) {
    setFunction(symbol, 8, size - 1 - i, false);
    setFunction(symbol, size - 1 - i, 8, false);
  }
  // The dark module sits inside the range the loop above just cleared.
  setFunction(symbol, size - 8, 8, true);

  if (version >= 7) {
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < 3; j++) {
        setFunction(symbol, i, size - 11 + j, false);
        setFunction(symbol, size - 11 + j, i, false);
      }
    }
  }
}

/** Places the data bits in the zigzag the spec specifies. */
function placeData(symbol: Symbol_, codewords: Uint8Array): void {
  const { size } = symbol;
  let bitIndex = 0;
  let upward = true;

  for (let right = size - 1; right >= 1; right -= 2) {
    // Column 6 is the vertical timing pattern, so the pairs shift left past it.
    if (right === 6) right = 5;

    for (let vertical = 0; vertical < size; vertical++) {
      const row = upward ? size - 1 - vertical : vertical;
      for (let c = 0; c < 2; c++) {
        const col = right - c;
        if (symbol.isFunction[row][col]) continue;

        const byte = codewords[bitIndex >>> 3];
        // Remainder bits past the codewords are zero, which the spec allows.
        const bit = byte === undefined ? 0 : (byte >>> (7 - (bitIndex & 7))) & 1;
        symbol.modules[row][col] = bit === 1;
        bitIndex++;
      }
    }
    upward = !upward;
  }
}

const MASKS: Array<(row: number, col: number) => boolean> = [
  (r, c) => (r + c) % 2 === 0,
  (r) => r % 2 === 0,
  (_r, c) => c % 3 === 0,
  (r, c) => (r + c) % 3 === 0,
  (r, c) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0,
  (r, c) => ((r * c) % 2) + ((r * c) % 3) === 0,
  (r, c) => (((r * c) % 2) + ((r * c) % 3)) % 2 === 0,
  (r, c) => (((r + c) % 2) + ((r * c) % 3)) % 2 === 0,
];

/**
 * Scores a masked symbol by the four penalty rules in section 7.8.3.
 *
 * Masking exists because data that happens to produce a large blank area, or a
 * run that looks like a finder pattern, is hard for a scanner to lock onto. All
 * eight masks are tried and the least-penalised wins.
 */
function penalty(modules: boolean[][], size: number): number {
  let score = 0;

  // Rule 1: runs of five or more same-coloured modules in a row or column.
  for (let i = 0; i < size; i++) {
    for (const horizontal of [true, false]) {
      let run = 1;
      for (let j = 1; j < size; j++) {
        const current = horizontal ? modules[i][j] : modules[j][i];
        const previous = horizontal ? modules[i][j - 1] : modules[j - 1][i];
        if (current === previous) {
          run++;
        } else {
          if (run >= 5) score += run - 2;
          run = 1;
        }
      }
      if (run >= 5) score += run - 2;
    }
  }

  // Rule 2: 2x2 blocks of one colour.
  for (let r = 0; r < size - 1; r++) {
    for (let c = 0; c < size - 1; c++) {
      const value = modules[r][c];
      if (modules[r][c + 1] === value && modules[r + 1][c] === value && modules[r + 1][c + 1] === value) {
        score += 3;
      }
    }
  }

  // Rule 3: a 1:1:3:1:1 run, which looks like a finder pattern to a scanner.
  const pattern = [true, false, true, true, true, false, true];
  for (let i = 0; i < size; i++) {
    for (let j = 0; j <= size - 7; j++) {
      for (const horizontal of [true, false]) {
        const matches = pattern.every((expected, k) =>
          horizontal ? modules[i][j + k] === expected : modules[j + k][i] === expected
        );
        if (!matches) continue;
        const before = horizontal
          ? modules[i].slice(Math.max(0, j - 4), j)
          : modules.slice(Math.max(0, j - 4), j).map((row) => row[i]);
        const after = horizontal
          ? modules[i].slice(j + 7, j + 11)
          : modules.slice(j + 7, j + 11).map((row) => row[i]);
        if (before.length === 4 && before.every((v) => !v)) score += 40;
        if (after.length === 4 && after.every((v) => !v)) score += 40;
      }
    }
  }

  // Rule 4: deviation from a 50/50 light-dark balance.
  let dark = 0;
  for (const row of modules) for (const cell of row) if (cell) dark++;
  const percent = (dark * 100) / (size * size);
  score += Math.floor(Math.abs(percent - 50) / 5) * 10;

  return score;
}

const FORMAT_BITS: Record<ErrorCorrection, number> = { L: 1, M: 0, Q: 3, H: 2 };

/** BCH(15,5) format information with the spec's fixed mask applied. */
function formatInformation(level: ErrorCorrection, mask: number): number {
  const data = (FORMAT_BITS[level] << 3) | mask;
  let value = data << 10;
  for (let i = 4; i >= 0; i--) {
    if ((value >>> (i + 10)) & 1) value ^= 0x537 << i;
  }
  return ((data << 10) | value) ^ 0x5412;
}

/** BCH(18,6) version information, present from version 7. */
function versionInformation(version: number): number {
  let value = version << 12;
  for (let i = 5; i >= 0; i--) {
    if ((value >>> (i + 12)) & 1) value ^= 0x1f25 << i;
  }
  return (version << 12) | value;
}

function placeFormatInformation(
  modules: boolean[][],
  size: number,
  level: ErrorCorrection,
  mask: number,
  version: number
): void {
  const bits = formatInformation(level, mask);

  for (let i = 0; i < 15; i++) {
    const bit = ((bits >>> i) & 1) === 1;
    if (i < 6) modules[i][8] = bit;
    else if (i < 8) modules[i + 1][8] = bit;
    else if (i === 8) modules[8][7] = bit;
    else modules[8][14 - i] = bit;

    if (i < 8) modules[8][size - 1 - i] = bit;
    else modules[size - 15 + i][8] = bit;
  }

  if (version >= 7) {
    const versionBits = versionInformation(version);
    for (let i = 0; i < 18; i++) {
      const bit = ((versionBits >>> i) & 1) === 1;
      modules[Math.floor(i / 3)][size - 11 + (i % 3)] = bit;
      modules[size - 11 + (i % 3)][Math.floor(i / 3)] = bit;
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Public API                                                                 */
/* -------------------------------------------------------------------------- */

export function generateQr(text: string, options: QrOptions): QrMatrix | QrError {
  if (text === "") return { error: "Nothing to encode." };

  const mode = chooseMode(text);
  const bytes = new TextEncoder().encode(text);

  // Pick the smallest version that holds the payload at this level.
  let version = 0;
  for (let candidate = 1; candidate <= 20; candidate++) {
    const encoded = encodeData(text, mode, candidate);
    if (encoded.length + 4 <= capacityBits(candidate, options.errorCorrection)) {
      version = candidate;
      break;
    }
  }
  if (version === 0) {
    return {
      error: `Too much data: ${bytes.length.toLocaleString("en-GB")} bytes will not fit in a version 20 symbol at level ${options.errorCorrection}. Use a lower error-correction level, or shorten the payload — a QR code denser than this stops scanning reliably anyway.`,
    };
  }

  const buffer = encodeData(text, mode, version);
  const capacity = capacityBits(version, options.errorCorrection);

  // Terminator, then pad to a byte, then the alternating pad bytes the spec
  // specifies rather than zeros.
  buffer.put(0, Math.min(4, capacity - buffer.length));
  buffer.padToByte();
  const dataBytes = buffer.toBytes();
  const needed = capacity / 8;
  const padded = new Uint8Array(needed);
  padded.set(dataBytes.slice(0, needed));
  for (let i = dataBytes.length; i < needed; i++) {
    padded[i] = (i - dataBytes.length) % 2 === 0 ? 0xec : 0x11;
  }

  const codewords = buildCodewords(padded, version, options.errorCorrection);
  const size = version * 4 + 17;

  const symbol = createSymbol(size);
  placeFunctionPatterns(symbol, version);
  placeData(symbol, codewords);

  // Try every mask and keep the least-penalised, which is what the spec says
  // and what makes the difference between a symbol that scans first time and
  // one that needs three attempts under a supermarket light.
  let best: boolean[][] | null = null;
  let bestScore = Infinity;

  for (let mask = 0; mask < 8; mask++) {
    const candidate = symbol.modules.map((row, r) =>
      // Function modules are never masked.
      row.map((value, c) => (symbol.isFunction[r][c] ? value : value !== MASKS[mask](r, c)))
    );
    placeFormatInformation(candidate, size, options.errorCorrection, mask, version);
    const score = penalty(candidate, size);
    if (score < bestScore) {
      bestScore = score;
      best = candidate;
    }
  }

  return {
    size,
    modules: best!,
    version,
    errorCorrection: options.errorCorrection,
    mode,
    dataBytes: bytes.length,
  };
}

/** Renders the matrix as an SVG string. */
export function qrToSvg(matrix: QrMatrix, options: QrOptions, dark = "#000", light = "#fff"): string {
  const { size, modules } = matrix;
  const total = size + options.margin * 2;

  // One path for every dark module rather than one rect each: a version 10
  // symbol has 3,600 modules, and 3,600 elements is a slow, huge file.
  const parts: string[] = [];
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (modules[r][c]) parts.push(`M${c + options.margin} ${r + options.margin}h1v1h-1z`);
    }
  }

  return [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${total} ${total}" width="${total * options.scale}" height="${total * options.scale}" shape-rendering="crispEdges">`,
    `<rect width="${total}" height="${total}" fill="${light}"/>`,
    `<path fill="${dark}" d="${parts.join("")}"/>`,
    `</svg>`,
  ].join("");
}

/* -------------------------------------------------------------------------- */
/* Payload builders                                                           */
/* -------------------------------------------------------------------------- */

/** Escapes the four characters that are structural in a Wi-Fi payload. */
function escapeWifi(value: string): string {
  return value.replace(/([\\;,:"])/g, "\\$1");
}

export interface WifiPayload {
  ssid: string;
  password: string;
  security: "WPA" | "WEP" | "nopass";
  hidden: boolean;
}

export function wifiString(payload: WifiPayload): string {
  const parts = [
    `T:${payload.security}`,
    `S:${escapeWifi(payload.ssid)}`,
    payload.security === "nopass" ? "" : `P:${escapeWifi(payload.password)}`,
    payload.hidden ? "H:true" : "",
  ].filter(Boolean);
  return `WIFI:${parts.join(";")};;`;
}

export interface VCardPayload {
  name: string;
  organisation: string;
  title: string;
  phone: string;
  email: string;
  url: string;
}

export function vCardString(payload: VCardPayload): string {
  // vCard 3.0 rather than 4.0: it is what phone contact apps actually import.
  const lines = ["BEGIN:VCARD", "VERSION:3.0", `FN:${payload.name}`, `N:${payload.name};;;;`];
  if (payload.organisation) lines.push(`ORG:${payload.organisation}`);
  if (payload.title) lines.push(`TITLE:${payload.title}`);
  if (payload.phone) lines.push(`TEL;TYPE=CELL:${payload.phone}`);
  if (payload.email) lines.push(`EMAIL:${payload.email}`);
  if (payload.url) lines.push(`URL:${payload.url}`);
  lines.push("END:VCARD");
  return lines.join("\n");
}

export const EC_DESCRIPTIONS: Record<ErrorCorrection, string> = {
  L: "About 7% of the symbol can be damaged and still read. Smallest code for the same data.",
  M: "About 15% recoverable. The usual default, and the right one for a screen or a clean print.",
  Q: "About 25% recoverable. Worth it for a sticker, a label, or anything that will be handled.",
  H: "About 30% recoverable. Needed if a logo is overlaid, and for print that will be outdoors.",
};
