/**
 * Regular expression testing, and the reason it needs a worker.
 *
 * JavaScript's regex engine is a backtracking engine with no execution limit. A
 * pattern like `(a+)+b` against `aaaaaaaaaaaaaaaaaaaaaaaaaaaaa!` explores every
 * way of splitting the a-run between the two quantifiers, which is exponential:
 * 30 characters is about a billion paths and the tab locks up with no error, no
 * stack trace and no way to stop it. This is catastrophic backtracking, and it
 * is the mechanism behind the ReDoS class of denial-of-service vulnerabilities —
 * including the 2019 Cloudflare outage, which was one regex in one WAF rule.
 *
 * There is no way to interrupt a running regex on the main thread. The only
 * real defence in a browser is to run it somewhere terminable, so matching
 * happens in a Web Worker that is killed if it does not answer in time.
 *
 * This module holds the parts that are safe to run anywhere: building the
 * pattern, static analysis for the shapes that backtrack, and formatting
 * results. The execution itself lives in the worker.
 */

export interface RegexFlags {
  global: boolean;
  ignoreCase: boolean;
  multiline: boolean;
  dotAll: boolean;
  unicode: boolean;
  sticky: boolean;
}

export const FLAG_DEFAULTS: RegexFlags = {
  global: true,
  ignoreCase: false,
  multiline: false,
  dotAll: false,
  unicode: false,
  sticky: false,
};

export function flagsToString(flags: RegexFlags): string {
  return (
    (flags.global ? "g" : "") +
    (flags.ignoreCase ? "i" : "") +
    (flags.multiline ? "m" : "") +
    (flags.dotAll ? "s" : "") +
    (flags.unicode ? "u" : "") +
    (flags.sticky ? "y" : "")
  );
}

export interface MatchResult {
  /** Index in the subject string. */
  index: number;
  match: string;
  /** Capture groups, 1-based, with undefined for a group that did not participate. */
  groups: Array<string | undefined>;
  /** Named capture groups. */
  named: Record<string, string | undefined>;
}

export type RegexOutcome =
  | { status: "ok"; matches: MatchResult[]; elapsedMs: number; truncated: boolean }
  | { status: "invalid"; error: string }
  | { status: "timeout"; ms: number };

/** Matches returned before the result is truncated. */
export const MAX_MATCHES = 5000;

/** Validates a pattern without running it against anything. */
export function compile(pattern: string, flags: RegexFlags): { regex: RegExp } | { error: string } {
  try {
    return { regex: new RegExp(pattern, flagsToString(flags)) };
  } catch (error) {
    return { error: (error as Error).message };
  }
}

/* -------------------------------------------------------------------------- */
/* Static analysis                                                            */
/* -------------------------------------------------------------------------- */

export interface RiskFinding {
  severity: "high" | "medium" | "info";
  title: string;
  detail: string;
}

/**
 * Looks for the shapes that backtrack catastrophically.
 *
 * Deliberately conservative and deliberately not a proof. Deciding whether an
 * arbitrary regex has exponential worst-case behaviour is a real analysis
 * problem, and a tool that claimed a pattern was safe would be making a promise
 * it cannot keep. What it can do is name the two shapes responsible for almost
 * every real incident, so a person who has one knows to look.
 */
export function analyseRisk(pattern: string): RiskFinding[] {
  const findings: RiskFinding[] = [];

  // Nested quantifiers: (a+)+ or (a*)* — the classic exponential shape.
  if (/\((?:[^()\\]|\\.)*[+*]\s*\)\s*[+*]/.test(pattern)) {
    findings.push({
      severity: "high",
      title: "Nested quantifier",
      detail:
        "A quantified group whose contents are also quantified, such as (a+)+. The engine tries every way of dividing the input between the two, which is exponential in the input length. This is the shape behind most ReDoS reports.",
    });
  }

  // Alternation of overlapping branches under a quantifier: (a|a)* or (\d|\w)+
  if (/\((?:[^()|\\]|\\.)+\|(?:[^()|\\]|\\.)+\)\s*[+*]/.test(pattern)) {
    findings.push({
      severity: "medium",
      title: "Quantified alternation",
      detail:
        "A quantified group containing alternatives, such as (a|ab)+. If the branches can match the same text the engine has several equally valid paths through every position, and backtracking explores all of them.",
    });
  }

  // Adjacent quantifiers over overlapping character classes: \s*\s* or .*.*
  if (/(\\[dws]|\[[^\]]*\]|\.)\s*[+*][?]?\s*\1\s*[+*]/.test(pattern)) {
    findings.push({
      severity: "medium",
      title: "Adjacent overlapping quantifiers",
      detail:
        "Two quantifiers in a row over the same characters, such as .*.* or \\s*\\s*. Every split of the matched run is a distinct path for the engine to try on failure.",
    });
  }

  if (/\.\*\.\*|\.\+\.\+/.test(pattern)) {
    findings.push({
      severity: "medium",
      title: "Repeated .*",
      detail:
        "Two unbounded wildcards. Almost always a mistake — one .* already matches everything the second would — and it makes failure quadratic at best.",
    });
  }

  // A pattern anchored at neither end scans from every position.
  if (!/^[\^]/.test(pattern) && !pattern.startsWith("\\b") && pattern.length > 20) {
    findings.push({
      severity: "info",
      title: "Not anchored",
      detail:
        "The pattern can start at any position, so a failing match is retried from every character. Anchoring with ^ or \\b is usually both faster and more precise.",
    });
  }

  if (/\\[dws]\{\d+,\}/.test(pattern) || /\{\d{3,},?\d*\}/.test(pattern)) {
    findings.push({
      severity: "info",
      title: "Large repetition count",
      detail:
        "A high or open-ended {n,m} multiplies the search space. Bound it to what the data actually contains.",
    });
  }

  return findings;
}

/* -------------------------------------------------------------------------- */
/* Explanation                                                                */
/* -------------------------------------------------------------------------- */

export interface PatternPart {
  token: string;
  meaning: string;
}

const EXPLANATIONS: Array<[RegExp, string]> = [
  [/^\\d/, "any digit, 0 to 9"],
  [/^\\D/, "any character that is not a digit"],
  [/^\\w/, "any word character: a letter, a digit or an underscore"],
  [/^\\W/, "any character that is not a word character"],
  [/^\\s/, "any whitespace: space, tab, newline, and several more"],
  [/^\\S/, "any character that is not whitespace"],
  [/^\\b/, "a word boundary — a position, not a character"],
  [/^\\B/, "a position that is not a word boundary"],
  [/^\\n/, "a newline"],
  [/^\\t/, "a tab"],
  [/^\\\\/, "a literal backslash"],
  [/^\\\./, "a literal full stop"],
  [/^\(\?:/, "a group that does not capture"],
  [/^\(\?=/, "a lookahead: what follows must match, and is not consumed"],
  [/^\(\?!/, "a negative lookahead: what follows must not match"],
  [/^\(\?<=/, "a lookbehind: what precedes must match"],
  [/^\(\?<!/, "a negative lookbehind: what precedes must not match"],
  [/^\(\?<[A-Za-z_][A-Za-z0-9_]*>/, "a named capture group"],
  [/^\(/, "the start of a capture group"],
  [/^\)/, "the end of a group"],
  [/^\[\^/, "a character class matching anything *except* the characters listed"],
  [/^\[/, "a character class: any one of the characters listed"],
  [/^\]/, "the end of a character class"],
  [/^\{\d+,\d+\}/, "a bounded repetition"],
  [/^\{\d+,\}/, "at least this many, with no upper limit"],
  [/^\{\d+\}/, "exactly this many"],
  [/^\*\?/, "zero or more, matching as few as possible"],
  [/^\+\?/, "one or more, matching as few as possible"],
  [/^\?\?/, "optional, preferring absent"],
  [/^\*/, "zero or more, matching as many as possible"],
  [/^\+/, "one or more, matching as many as possible"],
  [/^\?/, "optional: zero or one"],
  [/^\^/, "the start of the string, or of a line with the m flag"],
  [/^\$/, "the end of the string, or of a line with the m flag"],
  [/^\./, "any character except a newline, unless the s flag is set"],
  [/^\|/, "either the pattern before this or the pattern after it"],
];

/** Breaks a pattern into its tokens with a plain-language note for each. */
export function explainPattern(pattern: string): PatternPart[] {
  const parts: PatternPart[] = [];
  let i = 0;

  while (i < pattern.length) {
    const rest = pattern.slice(i);
    const found = EXPLANATIONS.find(([test]) => test.test(rest));
    if (found) {
      const match = found[0].exec(rest)!;
      parts.push({ token: match[0], meaning: found[1] });
      i += match[0].length;
      continue;
    }

    // A run of literal characters reads better as one entry than as one per
    // character.
    let end = i;
    while (end < pattern.length && !EXPLANATIONS.some(([test]) => test.test(pattern.slice(end)))) {
      end++;
    }
    const literal = pattern.slice(i, Math.max(end, i + 1));
    parts.push({ token: literal, meaning: `the literal text "${literal}"` });
    i += literal.length;
  }

  return parts;
}

/** Applies a replacement, which has its own escape rules people trip over. */
export function applyReplacement(
  pattern: string,
  flags: RegexFlags,
  subject: string,
  replacement: string
): { output: string } | { error: string } {
  const compiled = compile(pattern, flags);
  if ("error" in compiled) return compiled;
  try {
    return { output: subject.replace(compiled.regex, replacement) };
  } catch (error) {
    return { error: (error as Error).message };
  }
}

export const REGEX_EXAMPLES = [
  {
    label: "Email (pragmatic)",
    pattern: "[^@\\s]+@[^@\\s]+\\.[A-Za-z]{2,}",
    note: "Deliberately loose. The RFC 5322 grammar for an address is several hundred characters long and still cannot tell you whether the mailbox exists; sending a confirmation is the only real validation.",
  },
  {
    label: "URL",
    pattern: "https?://[^\\s/$.?#][^\\s]*",
    note: "Good enough for finding URLs in text. For validating one, use the URL constructor, which implements the actual WHATWG algorithm.",
  },
  {
    label: "IPv4",
    pattern: "\\b(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\b",
    note: "Range-checked per octet, so 999.1.1.1 does not match.",
  },
  {
    label: "ISO date",
    pattern: "\\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\\d|3[01])",
    note: "Matches the shape, not the validity: 2026-02-31 passes.",
  },
  {
    label: "UUID",
    pattern: "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
    note: "Any version. Add a version digit to the third group to narrow it.",
  },
  {
    label: "Hex colour",
    pattern: "#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\\b",
    note: "Three, four, six and eight digit forms, the last two carrying alpha.",
  },
  {
    label: "Catastrophic backtracking",
    pattern: "(a+)+$",
    note: "A demonstration, not a useful pattern. Run it against a long run of a characters ending in anything else and watch the timeout fire.",
  },
];
