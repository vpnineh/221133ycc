/**
 * Guards against prototype-pollution when building or mutating objects from
 * untrusted JSON input.
 *
 * Every tool on this site feeds attacker-controllable text (a pasted payload, a
 * pasted RFC 6902 patch) into code that writes object keys. Plain `obj[key] = v`
 * is unsafe there: assigning to `__proto__` mutates the prototype instead of
 * creating an own property, and walking a pointer through `constructor` ->
 * `prototype` reaches `Object.prototype` itself.
 */

/** Keys that must never be traversed or assigned through bracket notation. */
export const FORBIDDEN_KEYS = new Set(["__proto__", "constructor", "prototype"]);

export function isForbiddenKey(key: string | number): boolean {
  return typeof key === "string" && FORBIDDEN_KEYS.has(key);
}

/**
 * Assign an own, enumerable property without ever invoking a setter or
 * re-pointing the prototype. `defineProperty` is what makes `__proto__` land as
 * a real own key, matching `JSON.parse` semantics.
 */
export function safeSet(target: Record<string, unknown>, key: string, value: unknown): void {
  Object.defineProperty(target, key, {
    value,
    writable: true,
    enumerable: true,
    configurable: true,
  });
}

/** Own-property test that ignores anything inherited from the prototype chain. */
export function hasOwn(target: unknown, key: string): boolean {
  return (
    target !== null &&
    typeof target === "object" &&
    Object.prototype.hasOwnProperty.call(target, key)
  );
}

/** Read an own property only; inherited members read as `undefined`. */
export function safeGet(target: unknown, key: string): unknown {
  return hasOwn(target, key) ? (target as Record<string, unknown>)[key] : undefined;
}
