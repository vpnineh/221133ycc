import { JsonValue, JsonObject } from "../json/types";
import { safeSet } from "../safe-object";

export interface SchemaInferOptions {
  inferRequired?: boolean;
  typeWidening?: boolean;
  enumThreshold?: number; // distinct count threshold, e.g. 5
  detectFormats?: boolean;
}

export interface JsonSchemaNode {
  $schema?: string;
  type?: string | string[];
  properties?: Record<string, JsonSchemaNode>;
  required?: string[];
  items?: JsonSchemaNode;
  enum?: any[];
  format?: string;
  anyOf?: JsonSchemaNode[];
}

const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const TIME_REGEX = /^\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/;
const DATE_TIME_REGEX = /^\d{4}-\d{2}-\d{2}[Tt ]\d{2}:\d{2}:\d{2}(\.\d+)?([Zz]|[+-]\d{2}:\d{2})?$/;
const UUID_REGEX = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const URI_REGEX = /^[a-zA-Z][a-zA-Z0-9+.-]*:[^\s]+$/;
const IPV4_REGEX = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
const HOSTNAME_REGEX = /^(?=.{1,253}$)([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

/**
 * Per-format predicates, so validation can check the format a schema actually
 * names instead of asking "what does this string look like?" — the latter
 * false-flags any value whose shape matches an earlier entry in the list.
 */
export const FORMAT_VALIDATORS: Record<string, (s: string) => boolean> = {
  uuid: (s) => UUID_REGEX.test(s),
  email: (s) => EMAIL_REGEX.test(s),
  date: (s) => DATE_REGEX.test(s) && !Number.isNaN(Date.parse(s)),
  time: (s) => TIME_REGEX.test(s),
  "date-time": (s) => DATE_TIME_REGEX.test(s) && !Number.isNaN(Date.parse(s)),
  uri: (s) => URI_REGEX.test(s),
  ipv4: (s) => IPV4_REGEX.test(s),
  hostname: (s) => HOSTNAME_REGEX.test(s),
};

/** Order matters: most specific shape first. */
const FORMAT_DETECTION_ORDER = ["uuid", "email", "date-time", "date", "time", "ipv4", "uri"];

export function detectFormat(str: string): string | undefined {
  for (const name of FORMAT_DETECTION_ORDER) {
    if (FORMAT_VALIDATORS[name](str)) return name;
  }
  return undefined;
}

/** Check a string against one named format. Unknown formats are annotations only. */
export function matchesFormat(value: string, format: string): boolean {
  const validator = FORMAT_VALIDATORS[format];
  return validator ? validator(value) : true;
}

export function inferSchemaFromSamples(
  samples: JsonValue[],
  options: SchemaInferOptions = {}
): JsonSchemaNode {
  if (samples.length === 0) {
    return { $schema: "https://json-schema.org/draft/2020-12/schema" };
  }

  const inferRequired = options.inferRequired ?? true;
  const typeWidening = options.typeWidening ?? true;
  const enumThreshold = options.enumThreshold ?? 4;
  const detectFormats = options.detectFormats ?? true;

  function inferNode(values: JsonValue[]): JsonSchemaNode {
    const validValues = values.filter((v) => v !== undefined);
    if (validValues.length === 0) return {};

    const types = new Set<string>();
    for (const v of validValues) {
      if (v === null) types.add("null");
      else if (Array.isArray(v)) types.add("array");
      else if (typeof v === "object") types.add("object");
      else if (typeof v === "number") types.add(Number.isInteger(v) ? "integer" : "number");
      else types.add(typeof v);
    }

    // Type widening. A union used to end inference here, so `[{"a":1}, null]`
    // produced a bare {"type":["object","null"]} with the object's properties
    // thrown away. Instead, widen the type but keep inferring the structural
    // half of the union from the values that actually carry structure.
    if (types.size > 1 && typeWidening) {
      const typeList = Array.from(types).sort();
      const structuralTypes = typeList.filter((t) => t === "object" || t === "array");
      const structural = validValues.filter((v) => v !== null && typeof v === "object");

      // Only recurse when the union has exactly one structural arm; a mixed
      // object|array union has no single shape to describe, and recursing on
      // the same value set would not terminate.
      if (structuralTypes.length === 1 && structural.length > 0) {
        const structuralNode = inferNode(structural);
        const widened: JsonSchemaNode = { type: typeList };
        if (structuralNode.properties) widened.properties = structuralNode.properties;
        if (structuralNode.required) widened.required = structuralNode.required;
        if (structuralNode.items) widened.items = structuralNode.items;
        return widened;
      }

      return { type: typeList };
    }

    const dominantType = Array.from(types)[0] || "object";

    // String format and enum check
    if (dominantType === "string") {
      const strings = validValues as string[];
      const uniqueStrings = Array.from(new Set(strings));

      if (uniqueStrings.length <= enumThreshold && strings.length >= enumThreshold) {
        return { type: "string", enum: uniqueStrings };
      }

      const node: JsonSchemaNode = { type: "string" };
      if (detectFormats && strings.length > 0) {
        const fmt = detectFormat(strings[0]);
        if (fmt && strings.every((s) => detectFormat(s) === fmt)) {
          node.format = fmt;
        }
      }
      return node;
    }

    // Number
    if (dominantType === "number" || dominantType === "integer") {
      const numbers = validValues as number[];
      const uniqueNums = Array.from(new Set(numbers));
      if (uniqueNums.length <= enumThreshold && numbers.length >= enumThreshold) {
        return { type: dominantType, enum: uniqueNums };
      }
      return { type: dominantType };
    }

    // Boolean or Null
    if (dominantType === "boolean" || dominantType === "null") {
      return { type: dominantType };
    }

    // Array
    if (dominantType === "array") {
      const allElements: JsonValue[] = [];
      for (const v of validValues) {
        if (Array.isArray(v)) {
          allElements.push(...v);
        }
      }
      return {
        type: "array",
        items: inferNode(allElements),
      };
    }

    // Object
    if (dominantType === "object") {
      const allObjects = validValues.filter((v) => v && typeof v === "object" && !Array.isArray(v)) as JsonObject[];
      // Maps, not object literals: a payload key of "__proto__" or "constructor"
      // would otherwise read back an inherited member and crash on `.push`.
      const keyOccurrences = new Map<string, number>();
      const keyValues = new Map<string, JsonValue[]>();

      for (const obj of allObjects) {
        for (const k of Object.keys(obj)) {
          keyOccurrences.set(k, (keyOccurrences.get(k) || 0) + 1);
          let bucket = keyValues.get(k);
          if (!bucket) {
            bucket = [];
            keyValues.set(k, bucket);
          }
          bucket.push(obj[k]);
        }
      }

      const properties: Record<string, JsonSchemaNode> = {};
      const required: string[] = [];

      for (const k of Array.from(keyOccurrences.keys()).sort()) {
        safeSet(properties, k, inferNode(keyValues.get(k)!));
        if (inferRequired && keyOccurrences.get(k) === allObjects.length) {
          required.push(k);
        }
      }

      const node: JsonSchemaNode = {
        type: "object",
        properties,
      };

      if (required.length > 0) {
        node.required = required;
      }

      return node;
    }

    return { type: dominantType };
  }

  const root = inferNode(samples);
  root.$schema = "https://json-schema.org/draft/2020-12/schema";
  return root;
}
