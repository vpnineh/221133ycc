import { JsonValue, JsonObject } from "../json/types";
import { JsonSchemaNode, matchesFormat } from "./infer";
import { toJsonPointer, areValuesEqual } from "../diff/semantic-diff";
import { hasOwn } from "../safe-object";

export interface ValidationError {
  path: string;
  message: string;
  keyword: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

/** Cap on reported errors, so a wildly mismatched document cannot lock the tab. */
const MAX_ERRORS = 500;

interface Frame {
  // Deliberately `any`: this walks arbitrary decoded JSON and narrows at
  // runtime with jsonTypeOf/matchesType before touching anything.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value: any;
  node: JsonSchemaNode;
  path: (string | number)[];
}

function jsonTypeOf(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}

function matchesType(value: unknown, t: string): boolean {
  switch (t) {
    case "null":
      return value === null;
    case "array":
      return Array.isArray(value);
    case "object":
      return value !== null && typeof value === "object" && !Array.isArray(value);
    case "string":
      return typeof value === "string";
    case "boolean":
      return typeof value === "boolean";
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "number":
      return typeof value === "number" && Number.isFinite(value);
    default:
      return false;
  }
}

/**
 * Validate a JSON document against an inferred or user-supplied schema.
 *
 * Traversal is an explicit worklist rather than recursion: the site advertises
 * deeply-nested payload support, and a recursive validator would blow the stack
 * on exactly the documents the diff engine handles fine.
 */
export function validateAgainstSchema(
  data: JsonValue,
  schema: JsonSchemaNode
): ValidationResult {
  const errors: ValidationError[] = [];
  const stack: Frame[] = [{ value: data, node: schema, path: [] }];

  const report = (path: (string | number)[], keyword: string, message: string) => {
    if (errors.length < MAX_ERRORS) {
      errors.push({ path: toJsonPointer(path) || "/", keyword, message });
    }
  };

  while (stack.length > 0 && errors.length < MAX_ERRORS) {
    const { value, node, path } = stack.pop()!;
    if (!node || typeof node !== "object") continue;

    // JSON Schema keywords beyond the typed subset arrive as arbitrary values.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const anyNode = node as JsonSchemaNode & Record<string, any>;

    // --- Combinators -------------------------------------------------------
    if (Array.isArray(anyNode.allOf)) {
      for (const sub of anyNode.allOf) stack.push({ value, node: sub, path });
    }
    if (Array.isArray(anyNode.anyOf)) {
      const ok = anyNode.anyOf.some(
        (sub: JsonSchemaNode) => validateAgainstSchema(value, sub).valid
      );
      if (!ok) report(path, "anyOf", "Value does not match any of the allowed schemas (anyOf)");
    }
    if (Array.isArray(anyNode.oneOf)) {
      const matches = anyNode.oneOf.filter(
        (sub: JsonSchemaNode) => validateAgainstSchema(value, sub).valid
      ).length;
      if (matches !== 1) {
        report(path, "oneOf", `Value must match exactly one schema (oneOf); it matched ${matches}`);
      }
    }
    if (anyNode.not && validateAgainstSchema(value, anyNode.not).valid) {
      report(path, "not", "Value matches a schema it must not match (not)");
    }

    // --- const / enum ------------------------------------------------------
    if (hasOwn(anyNode, "const") && !areValuesEqual(value, anyNode.const)) {
      report(path, "const", `Value must equal ${JSON.stringify(anyNode.const)}`);
    }
    if (Array.isArray(node.enum)) {
      // Deep equality, not Array.includes: JSON Schema enums may list objects.
      const inEnum = node.enum.some((candidate) => areValuesEqual(value, candidate));
      if (!inEnum) {
        report(
          path,
          "enum",
          `Value ${JSON.stringify(value)} is not one of ${JSON.stringify(node.enum)}`
        );
      }
    }

    // --- type --------------------------------------------------------------
    if (node.type) {
      const allowedTypes = Array.isArray(node.type) ? node.type : [node.type];
      if (!allowedTypes.some((t) => matchesType(value, t))) {
        report(
          path,
          "type",
          `Expected type '${allowedTypes.join(" | ")}', found '${jsonTypeOf(value)}'`
        );
        // Further keywords assume the type matched; skip them for this node.
        continue;
      }
    }

    // --- string ------------------------------------------------------------
    if (typeof value === "string") {
      if (node.format && !matchesFormat(value, node.format)) {
        report(path, "format", `String does not match format '${node.format}'`);
      }
      if (typeof anyNode.minLength === "number" && [...value].length < anyNode.minLength) {
        report(path, "minLength", `String is shorter than minLength ${anyNode.minLength}`);
      }
      if (typeof anyNode.maxLength === "number" && [...value].length > anyNode.maxLength) {
        report(path, "maxLength", `String is longer than maxLength ${anyNode.maxLength}`);
      }
      if (typeof anyNode.pattern === "string") {
        let re: RegExp | null = null;
        try {
          re = new RegExp(anyNode.pattern, "u");
        } catch {
          try {
            re = new RegExp(anyNode.pattern);
          } catch {
            report(path, "pattern", `Schema pattern '${anyNode.pattern}' is not a valid regex`);
          }
        }
        if (re && !re.test(value)) {
          report(path, "pattern", `String does not match pattern '${anyNode.pattern}'`);
        }
      }
    }

    // --- number ------------------------------------------------------------
    if (typeof value === "number") {
      if (typeof anyNode.minimum === "number" && value < anyNode.minimum) {
        report(path, "minimum", `Value ${value} is below minimum ${anyNode.minimum}`);
      }
      if (typeof anyNode.maximum === "number" && value > anyNode.maximum) {
        report(path, "maximum", `Value ${value} is above maximum ${anyNode.maximum}`);
      }
      if (typeof anyNode.exclusiveMinimum === "number" && value <= anyNode.exclusiveMinimum) {
        report(
          path,
          "exclusiveMinimum",
          `Value ${value} must be greater than ${anyNode.exclusiveMinimum}`
        );
      }
      if (typeof anyNode.exclusiveMaximum === "number" && value >= anyNode.exclusiveMaximum) {
        report(
          path,
          "exclusiveMaximum",
          `Value ${value} must be less than ${anyNode.exclusiveMaximum}`
        );
      }
      if (typeof anyNode.multipleOf === "number" && anyNode.multipleOf > 0) {
        const quotient = value / anyNode.multipleOf;
        // Tolerance keeps binary floats (0.1 * 3) from producing false errors.
        if (Math.abs(quotient - Math.round(quotient)) > 1e-9) {
          report(path, "multipleOf", `Value ${value} is not a multiple of ${anyNode.multipleOf}`);
        }
      }
    }

    // --- object ------------------------------------------------------------
    if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      const obj = value as JsonObject;
      const ownKeys = Object.keys(obj);

      if (node.required) {
        for (const reqKey of node.required) {
          // hasOwn, not `in`: `"toString" in obj` is true for every object and
          // used to make a schema requiring "toString" pass on any input.
          if (!hasOwn(obj, reqKey)) {
            report(path, "required", `Missing required property '${reqKey}'`);
          }
        }
      }

      if (typeof anyNode.minProperties === "number" && ownKeys.length < anyNode.minProperties) {
        report(path, "minProperties", `Object has fewer than ${anyNode.minProperties} properties`);
      }
      if (typeof anyNode.maxProperties === "number" && ownKeys.length > anyNode.maxProperties) {
        report(path, "maxProperties", `Object has more than ${anyNode.maxProperties} properties`);
      }

      const patternProperties: Record<string, JsonSchemaNode> = anyNode.patternProperties || {};
      const patternEntries = Object.keys(patternProperties).map((p) => {
        try {
          return { re: new RegExp(p), sub: patternProperties[p] };
        } catch {
          return null;
        }
      });

      for (const propKey of ownKeys) {
        let matched = false;

        if (node.properties && hasOwn(node.properties, propKey)) {
          matched = true;
          stack.push({
            value: obj[propKey],
            node: node.properties[propKey],
            path: [...path, propKey],
          });
        }

        for (const entry of patternEntries) {
          if (entry && entry.re.test(propKey)) {
            matched = true;
            stack.push({ value: obj[propKey], node: entry.sub, path: [...path, propKey] });
          }
        }

        if (!matched && anyNode.additionalProperties !== undefined) {
          if (anyNode.additionalProperties === false) {
            report(
              [...path, propKey],
              "additionalProperties",
              `Property '${propKey}' is not allowed (additionalProperties: false)`
            );
          } else if (typeof anyNode.additionalProperties === "object") {
            stack.push({
              value: obj[propKey],
              node: anyNode.additionalProperties,
              path: [...path, propKey],
            });
          }
        }
      }

      if (anyNode.dependentRequired && typeof anyNode.dependentRequired === "object") {
        for (const trigger of Object.keys(anyNode.dependentRequired)) {
          if (!hasOwn(obj, trigger)) continue;
          for (const dep of anyNode.dependentRequired[trigger] as string[]) {
            if (!hasOwn(obj, dep)) {
              report(
                path,
                "dependentRequired",
                `Property '${dep}' is required when '${trigger}' is present`
              );
            }
          }
        }
      }
    }

    // --- array -------------------------------------------------------------
    if (Array.isArray(value)) {
      if (typeof anyNode.minItems === "number" && value.length < anyNode.minItems) {
        report(path, "minItems", `Array has fewer than ${anyNode.minItems} items`);
      }
      if (typeof anyNode.maxItems === "number" && value.length > anyNode.maxItems) {
        report(path, "maxItems", `Array has more than ${anyNode.maxItems} items`);
      }
      if (anyNode.uniqueItems === true) {
        for (let i = 0; i < value.length && errors.length < MAX_ERRORS; i++) {
          for (let j = i + 1; j < value.length; j++) {
            if (areValuesEqual(value[i], value[j])) {
              report(path, "uniqueItems", `Array items at index ${i} and ${j} are duplicates`);
              i = value.length;
              break;
            }
          }
        }
      }

      const prefixItems: JsonSchemaNode[] = Array.isArray(anyNode.prefixItems)
        ? anyNode.prefixItems
        : [];

      for (let i = 0; i < value.length; i++) {
        if (i < prefixItems.length) {
          stack.push({ value: value[i], node: prefixItems[i], path: [...path, i] });
        } else if (node.items) {
          stack.push({ value: value[i], node: node.items, path: [...path, i] });
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
