/**
 * Single source of truth for the canonical origin and brand strings.
 *
 * Origin was previously hard-coded in a dozen files, which is how the sitemap,
 * the canonical tags and the JSON-LD drifted apart. Set NEXT_PUBLIC_SITE_URL to
 * point a preview deployment at its own origin.
 */

const RAW_SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://toolsbyus.com";

/** Canonical origin with no trailing slash. */
export const SITE_URL = RAW_SITE_URL.replace(/\/+$/, "");

export const SITE_NAME = "ToolsByUs";
export const SITE_DOMAIN = "toolsbyus.com";

/** Build an absolute URL from a site-root-relative path. */
export function absoluteUrl(pathname: string): string {
  if (!pathname || pathname === "/") return `${SITE_URL}/`;
  return `${SITE_URL}${pathname.startsWith("/") ? pathname : `/${pathname}`}`;
}

/** The site's one-line positioning. Used in metadata, llms.txt and the hero. */
export const SITE_TAGLINE = "Tools that never upload your file.";

/**
 * Fallback review date, used only by pages that do not carry their own.
 *
 * Per-tool dates live on the catalogue entry (`Tool.lastReviewed`) so JSON-LD
 * `dateModified` is honest: stamping fifty pages with one date tells search
 * engines the whole site changed on a day when one paragraph did.
 */
export const CONTENT_LAST_REVIEWED = "2026-09-11";

/** First publication date, emitted as `datePublished` in the page JSON-LD. */
export const CONTENT_FIRST_PUBLISHED = "2026-09-09";
