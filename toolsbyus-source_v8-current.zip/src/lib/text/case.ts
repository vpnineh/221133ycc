/**
 * Case conversion, which is a tokenising problem rather than a string problem.
 *
 * Every convention is the same word list rendered differently, so the work is
 * splitting the input into words correctly — and that is where converters
 * differ. `XMLHttpRequest` is three words, not one and not eight. `user_id2`
 * ends with a word boundary a naive splitter misses. `İstanbul` lowercases to a
 * different string in Turkish than in English, which is the famous Turkish-I
 * problem and the reason this uses locale-independent casing by default.
 */

export type CaseStyle =
  | "camel"
  | "pascal"
  | "snake"
  | "constant"
  | "kebab"
  | "train"
  | "dot"
  | "path"
  | "sentence"
  | "title"
  | "lower"
  | "upper"
  | "alternating"
  | "inverse";

export interface CaseOptions {
  style: CaseStyle;
  /** Use the browser's locale rules, which changes i/I in Turkish and Azeri. */
  localeAware: boolean;
  /** Keep an all-caps run intact: ID stays ID rather than becoming Id. */
  preserveAcronyms: boolean;
}

export const CASE_DEFAULTS: CaseOptions = {
  style: "camel",
  localeAware: false,
  preserveAcronyms: false,
};

/**
 * Splits an identifier of any convention into words.
 *
 * Three boundaries, in order of how often they are missed:
 * a lower-to-upper transition (`userName`), an acronym followed by a word
 * (`XMLHttp` -> `XML Http`), and a letter-to-digit transition (`user2` ->
 * `user 2`). Separators — space, underscore, hyphen, dot, slash — are all
 * treated alike, which is what lets the converter accept any input convention.
 */
export function splitWords(input: string): string[] {
  return input
    .replace(/([\p{Ll}\p{N}])(\p{Lu})/gu, "$1 $2")
    .replace(/(\p{Lu}+)(\p{Lu}\p{Ll})/gu, "$1 $2")
    .replace(/(\p{L})(\p{N})/gu, "$1 $2")
    .replace(/(\p{N})(\p{L})/gu, "$1 $2")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

function lower(word: string, options: CaseOptions): string {
  // Locale-aware lowercasing turns I into ı in Turkish, which breaks every
  // identifier and every case-insensitive comparison against ASCII. It is the
  // right answer for prose and the wrong one for code, so it is opt-in.
  return options.localeAware ? word.toLocaleLowerCase() : word.toLowerCase();
}

function upper(word: string, options: CaseOptions): string {
  return options.localeAware ? word.toLocaleUpperCase() : word.toUpperCase();
}

function capitalise(word: string, options: CaseOptions): string {
  if (options.preserveAcronyms && isAcronym(word)) return word;
  const first = options.localeAware
    ? word.charAt(0).toLocaleUpperCase()
    : word.charAt(0).toUpperCase();
  return first + lower(word.slice(1), options);
}

function isAcronym(word: string): boolean {
  return word.length > 1 && word === word.toUpperCase() && /\p{L}/u.test(word);
}

/** Words that stay lowercase inside a title, unless first or last. */
const MINOR_WORDS = new Set([
  "a", "an", "and", "as", "at", "but", "by", "for", "if", "in", "nor", "of", "on", "or", "per",
  "so", "the", "to", "up", "via", "vs", "with", "yet",
]);

export function convertCase(input: string, options: CaseOptions): string {
  // The whole-string styles operate on the text, not on its words: lowercasing
  // a sentence must not destroy its punctuation and spacing.
  switch (options.style) {
    case "lower":
      return lower(input, options);
    case "upper":
      return upper(input, options);
    case "alternating":
      return [...input]
        .map((char, index) => (index % 2 === 0 ? lower(char, options) : upper(char, options)))
        .join("");
    case "inverse":
      return [...input]
        .map((char) =>
          char === lower(char, options) ? upper(char, options) : lower(char, options)
        )
        .join("");
    default:
      break;
  }

  // Sentence and title case are prose styles: they keep the original
  // punctuation and only change capitalisation, so a sentence stays a sentence.
  if (options.style === "sentence") return toSentenceCase(input, options);
  if (options.style === "title") return toTitleCase(input, options);

  const words = splitWords(input);
  if (words.length === 0) return "";

  switch (options.style) {
    case "camel":
      return words
        .map((word, index) => (index === 0 ? lower(word, options) : capitalise(word, options)))
        .join("");
    case "pascal":
      return words.map((word) => capitalise(word, options)).join("");
    case "snake":
      return words.map((word) => lower(word, options)).join("_");
    case "constant":
      return words.map((word) => upper(word, options)).join("_");
    case "kebab":
      return words.map((word) => lower(word, options)).join("-");
    case "train":
      return words.map((word) => capitalise(word, options)).join("-");
    case "dot":
      return words.map((word) => lower(word, options)).join(".");
    case "path":
      return words.map((word) => lower(word, options)).join("/");
    default:
      return input;
  }
}

function toSentenceCase(input: string, options: CaseOptions): string {
  // Capitalise the first letter of each sentence and leave everything else,
  // so acronyms and proper nouns already in the text survive.
  let seenLetter = false;
  let capitaliseNext = true;
  let out = "";

  for (const char of input) {
    if (/[.!?]/.test(char)) {
      capitaliseNext = true;
      out += char;
      continue;
    }
    if (/\p{L}/u.test(char)) {
      if (capitaliseNext) {
        out += options.localeAware ? char.toLocaleUpperCase() : char.toUpperCase();
        capitaliseNext = false;
      } else {
        out += seenLetter ? char : lower(char, options);
      }
      seenLetter = true;
      continue;
    }
    out += char;
  }
  return out;
}

function toTitleCase(input: string, options: CaseOptions): string {
  const tokens = input.split(/(\s+)/);
  const lastWordIndex = tokens.reduce(
    (last, token, index) => (token.trim() ? index : last),
    0
  );

  return tokens
    .map((token, index) => {
      if (!token.trim()) return token;
      const bare = token.toLowerCase();
      const isEdge = index === 0 || index === lastWordIndex;
      if (!isEdge && MINOR_WORDS.has(bare.replace(/[^\p{L}]/gu, ""))) return bare;
      return capitalise(token, options);
    })
    .join("");
}

/** Descriptions for the tool's reference list. */
export const CASE_EXAMPLES: Array<{ style: CaseStyle; label: string; example: string }> = [
  { style: "camel", label: "camelCase", example: "userFirstName" },
  { style: "pascal", label: "PascalCase", example: "UserFirstName" },
  { style: "snake", label: "snake_case", example: "user_first_name" },
  { style: "constant", label: "CONSTANT_CASE", example: "USER_FIRST_NAME" },
  { style: "kebab", label: "kebab-case", example: "user-first-name" },
  { style: "train", label: "Train-Case", example: "User-First-Name" },
  { style: "dot", label: "dot.case", example: "user.first.name" },
  { style: "path", label: "path/case", example: "user/first/name" },
  { style: "sentence", label: "Sentence case", example: "User first name" },
  { style: "title", label: "Title Case", example: "User First Name" },
  { style: "lower", label: "lowercase", example: "user first name" },
  { style: "upper", label: "UPPERCASE", example: "USER FIRST NAME" },
  { style: "alternating", label: "aLtErNaTiNg", example: "uSeR fIrSt nAmE" },
  { style: "inverse", label: "iNVERSE", example: "uSER fIRST nAME" },
];
