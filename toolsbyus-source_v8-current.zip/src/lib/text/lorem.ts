/**
 * Placeholder text.
 *
 * Two things a generator should get right and most do not.
 *
 * The first is that the classical lorem ipsum passage is real Latin — a
 * corrupted extract from Cicero's *De finibus bonorum et malorum*, written in
 * 45 BC — so the word list here is the genuine vocabulary rather than invented
 * syllables. That matters because the point of placeholder text is to have the
 * right texture: word lengths and letter frequencies close enough to real prose
 * that a layout looks like it will.
 *
 * The second is that Latin has the wrong texture for many jobs. It is
 * ASCII-only, which means a layout filled with it never encounters an accent, a
 * combining mark, an emoji, a right-to-left run, or a word too long to wrap —
 * and all of those break real layouts. So there is a Unicode stress mode whose
 * whole purpose is to fail early.
 */

export type LoremFlavour = "classic" | "english" | "unicode" | "hipster";
export type LoremUnit = "paragraphs" | "sentences" | "words" | "list";

export interface LoremOptions {
  flavour: LoremFlavour;
  unit: LoremUnit;
  count: number;
  /** Begin with the canonical "Lorem ipsum dolor sit amet" opening. */
  startWithLorem: boolean;
  /** Wrap each paragraph in <p>, or each list item in <li>. */
  html: boolean;
  /** Average words per sentence; sentences vary around it. */
  sentenceLength: number;
}

export const LOREM_DEFAULTS: LoremOptions = {
  flavour: "classic",
  unit: "paragraphs",
  count: 3,
  startWithLorem: true,
  html: false,
  sentenceLength: 12,
};

const CLASSIC = `a ac accusantium ad adipisci alias aliquam aliquid amet animi aperiam architecto
asperiores aspernatur assumenda at atque aut autem beatae blanditiis commodi consectetur consequatur
consequuntur corporis corrupti culpa cum cupiditate debitis delectus deleniti deserunt dicta
dignissimos distinctio dolor dolore dolorem doloremque dolores doloribus dolorum ducimus ea eaque
earum eius eligendi enim eos error esse est et eum eveniet ex excepturi exercitationem expedita
explicabo facere facilis fuga fugiat fugit harum hic id illo illum impedit in incidunt inventore
ipsa ipsam ipsum iste itaque iure iusto labore laboriosam laborum laudantium libero magnam magni
maiores maxime minima minus modi molestiae molestias mollitia nam natus necessitatibus nemo neque
nesciunt nihil nisi nobis non nostrum nulla numquam occaecati odio odit officia officiis omnis
optio pariatur perferendis perspiciatis placeat porro possimus praesentium provident quae quaerat
quam quas quasi qui quia quibusdam quidem quis quisquam quo quod ratione recusandae reiciendis
rem repellat repellendus reprehenderit repudiandae rerum saepe sapiente sed sequi similique sint
sit soluta sunt suscipit tempora tempore temporibus tenetur totam ullam unde ut vel velit veniam
veritatis vero vitae voluptas voluptate voluptatem voluptates voluptatibus voluptatum`
  .split(/\s+/)
  .filter(Boolean);

const ENGLISH = `about above account across action activity actually address after again against age
agency agent ago agree ahead allow almost alone along already also although always among amount
analysis animal another answer anyone appear apply approach area argue around arrive article ask
assume attack attention author available avoid away baby back bad bag ball bank base beat beautiful
because become before begin behavior behind believe benefit best better between beyond big bill
billion bit black blood blue board body book born both box boy break bring brother budget build
business call camera campaign cancer candidate capital card care career carry case catch cause cell
center central century certain chair challenge chance change character charge check child choice
choose church citizen city civil claim class clear close coach cold collection college color come
commercial common community company compare computer concern condition conference consider consumer
contain continue control cost country couple course cover create crime cultural culture current
customer data daughter deal death debate decade decide decision deep defense degree democratic
describe design despite detail determine develop difference different difficult dinner direction
discover discuss disease doctor door draw dream drive drop during early east easy economic economy
edge education effect effort eight either election employee energy enjoy enough enter entire
environment especially establish even evening event ever every evidence exactly example executive
exist expect experience expert explain face fact factor fail fall family far fast father fear
federal feel field fight figure fill film final financial find fine finger finish fire firm first
fish five floor focus follow food foot force foreign forget form former forward four free friend
front full fund future game garden general generation get girl give glass global goal good
government great green ground group grow growth guess gun guy hair half hand hang happen happy hard
head health hear heart heat heavy help herself high himself history hit hold home hope hospital hot
hotel hour house however huge human hundred husband idea identify image imagine impact important
improve include increase indeed indicate individual industry information inside instead institution
interest interview into investment involve issue item itself job join keep key kid kill kind
kitchen knowledge land language large last late later laugh law lawyer lead leader learn least
leave left legal less letter level life light like likely line list listen little live local long
look lose loss love machine magazine main maintain major majority make manage management manager
many market marriage material matter maybe mean measure media medical meet meeting member memory
mention message method middle might military million mind minute miss mission model modern moment
money month more morning most mother move movement movie much music must myself name nation
national natural nature near nearly necessary need network never news newspaper next nice night
none north note nothing notice number occur offer office officer official often oil once only open
operation opportunity option order organization other others outside over owner page pain painting
paper parent part participant particular particularly partner party pass past patient pattern peace
people perform performance perhaps period person personal phone physical pick picture piece place
plan plant play player point police policy political politics poor popular population position
positive possible power practice prepare present president pressure pretty prevent price private
probably problem process produce product production professional professor program project property
protect prove provide public pull purpose push quality question quickly quite race radio raise
range rate rather reach read ready real reality realize really reason receive recent recognize
record reduce reflect region relate relationship religious remain remember remove report represent
require research resource respond response responsibility rest result return reveal rich right rise
risk road rock role room rule safe same save scene school science scientist score sea season seat
second section security seek seem sell send senior sense series serious serve service seven several
shake share shoot short shot should shoulder show side sign significant similar simple simply since
sing single sister site situation size skill skin small smile social society soldier some somebody
someone something sometimes son song soon sort sound source south space speak special specific
speech spend sport spring staff stage stand standard star start state statement station stay step
still stock stop store story strategy street strong structure student study stuff style subject
success successful such suddenly suffer suggest summer support sure surface system table take talk
task teach teacher team technology television tell tend term test than thank that their them theory
there these they thing think third this those though thought thousand threat three through
throughout throw thus time today together tonight total tough toward town trade traditional
training travel treat treatment tree trial trip trouble true truth turn type under understand unit
until upon usually value various very victim view violence visit voice vote wait walk wall want war
watch water weapon wear week weight well west western what whatever when where whether which while
white whole whom whose wide wife will wind window wish within without woman wonder word work worker
world worry would write writer wrong yard yeah year yes yet young your yourself`
  .split(/\s+/)
  .filter(Boolean);

const HIPSTER = `artisan authentic banjo bespoke bicycle biodiesel bitters brunch cardigan chambray
chartreuse chillwave cliche coffee cold-pressed copper cornhole craft cronut crucifix deep-v
denim disrupt distillery diy dreamcatcher ennui etsy everyday fanny-pack fingerstache fixie
flannel food-truck forage freegan gastropub gentrify gluten-free godard hashtag heirloom hella
hexagon humblebrag iphone jean-shorts kale kickstarter kinfolk kitsch knausgaard kogi kombucha
letterpress lo-fi locavore lomo lumbersexual man-bun marfa meditation meggings messenger-bag
microdosing mixtape mlkshk mustache narwhal neutra next-level normcore occupy offal organic
paleo photo-booth pickled pinterest pitchfork plaid poke polaroid pop-up portland pour-over
put-a-bird-on-it quinoa raclette ramps raw-denim readymade retro roof-party salvia sartorial
schlitz selfies selvage semiotics shabby-chic shoreditch single-origin skateboard slow-carb
small-batch snackwave sriracha stumptown subway-tile succulents sustainable swag synth tattooed
taxidermy thundercats tilde tofu tote-bag truffaut tumblr twee typewriter umami unicorn vape
vegan venmo vhs vice vinegar vinyl viral waistcoat wayfarers whatever williamsburg wolf
woke xoxo yolo yuccie`
  .split(/\s+/)
  .filter(Boolean);

/**
 * Text chosen to break a layout that only ever saw ASCII.
 *
 * Each entry exercises something different: combining marks that make a line
 * taller than its neighbours, a right-to-left run that reorders around
 * punctuation, CJK that does not break on spaces, an emoji with a skin-tone
 * modifier that must not be split, a long unbroken word that overflows a
 * container, and characters that look like other characters.
 */
const UNICODE = [
  "Ünïcödé", "français", "Ελληνικά", "Кириллица", "עברית", "العربية", "日本語のテキスト",
  "한국어", "ไทย", "Zalgo̸͎̅", "é́́", "👨‍👩‍👧‍👦", "🧑🏽‍💻", "🇳🇴",
  "Supercalifragilisticexpialidocious", "Donaudampfschifffahrtsgesellschaft",
  "‮reversed‬", "ﬁligree", "Ⅻ", "①②③", "µ", "①", "𝔘𝔫𝔦𝔠𝔬𝔡𝔢", "ｆｕｌｌｗｉｄｔｈ",
  "a­b", "no break", "𠜎𠜱𠝹", "ß", "İstanbul", "ǅ",
];

function wordsFor(flavour: LoremFlavour): string[] {
  switch (flavour) {
    case "english":
      return ENGLISH;
    case "hipster":
      return HIPSTER;
    case "unicode":
      return UNICODE;
    default:
      return CLASSIC;
  }
}

/**
 * A small deterministic generator, seeded so the same options give the same
 * text.
 *
 * `Math.random` would re-roll the whole block on every keystroke, which makes it
 * impossible to tweak one option and see what changed. This is mulberry32 —
 * thirty-two bits of state, good enough for placeholder text and reproducible,
 * which is the property that matters here.
 */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const OPENING = "Lorem ipsum dolor sit amet, consectetur adipiscing elit";

export function generateLorem(options: LoremOptions, seed = 1): string {
  const random = mulberry32(seed);
  const vocabulary = wordsFor(options.flavour);
  const count = Math.max(1, Math.min(options.count, 500));

  const pickWord = () => vocabulary[Math.floor(random() * vocabulary.length)];

  const makeSentence = (first: boolean): string => {
    // Length varies around the requested average, so paragraphs do not read as
    // a column of identical-length lines.
    const target = Math.max(
      3,
      Math.round(options.sentenceLength + (random() - 0.5) * options.sentenceLength)
    );
    const words: string[] = [];

    if (first && options.startWithLorem && options.flavour === "classic") {
      words.push(OPENING);
    }
    while (words.join(" ").split(" ").length < target) {
      words.push(pickWord());
      // An occasional comma, placed where a clause would plausibly end.
      if (words.length > 3 && random() < 0.12) words[words.length - 1] += ",";
    }

    const sentence = words.join(" ").replace(/,$/, "");
    const capitalised = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    const terminator = random() < 0.06 ? "?" : random() < 0.04 ? "!" : ".";
    return capitalised + terminator;
  };

  if (options.unit === "words") {
    const words = [];
    if (options.startWithLorem && options.flavour === "classic") {
      words.push(...OPENING.replace(",", "").split(" "));
    }
    while (words.length < count) words.push(pickWord());
    return words.slice(0, count).join(" ");
  }

  if (options.unit === "sentences") {
    return Array.from({ length: count }, (_unused, index) => makeSentence(index === 0)).join(" ");
  }

  if (options.unit === "list") {
    const items = Array.from({ length: count }, () => {
      const length = 2 + Math.floor(random() * 5);
      const words = Array.from({ length }, pickWord).join(" ");
      return words.charAt(0).toUpperCase() + words.slice(1);
    });
    return options.html
      ? `<ul>\n${items.map((item) => `  <li>${item}</li>`).join("\n")}\n</ul>`
      : items.map((item) => `- ${item}`).join("\n");
  }

  const paragraphs = Array.from({ length: count }, (_unused, index) => {
    const sentences = 3 + Math.floor(random() * 4);
    return Array.from({ length: sentences }, (_s, sentenceIndex) =>
      makeSentence(index === 0 && sentenceIndex === 0)
    ).join(" ");
  });

  return options.html
    ? paragraphs.map((text) => `<p>${text}</p>`).join("\n")
    : paragraphs.join("\n\n");
}

export function countStats(text: string): { words: number; characters: number; bytes: number } {
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  return {
    words,
    // Code points rather than UTF-16 units: an emoji is one character to a
    // reader and two to `String.length`.
    characters: [...text].length,
    bytes: new TextEncoder().encode(text).length,
  };
}
