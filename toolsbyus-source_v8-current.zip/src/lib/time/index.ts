/**
 * Timestamp conversion.
 *
 * The hard part is not the arithmetic; it is working out what the number in
 * front of you actually is. A Unix timestamp has no units attached, so the same
 * integer is a moment in 1970, 2026 or 55,000 CE depending on whether it counts
 * seconds, milliseconds or microseconds — and the failure mode is a date that
 * looks plausible but is wrong by a factor of a thousand.
 *
 * Magnitude is a reliable discriminator for any date in the era anyone cares
 * about, so the unit is detected and, importantly, reported rather than assumed.
 */

export type TimeUnit = "seconds" | "milliseconds" | "microseconds" | "nanoseconds";

export interface DetectedTimestamp {
  unit: TimeUnit;
  milliseconds: number;
  /** How the unit was chosen, so the guess is auditable. */
  reason: string;
}

/**
 * Detects the unit of a bare number by magnitude.
 *
 * The boundaries are chosen so every date from 1973 to 5138 resolves correctly
 * in seconds, and correspondingly for the larger units. Below 10^10 in
 * milliseconds would be 1970, which is almost never what a modern timestamp
 * means — and saying so is more useful than silently picking one.
 */
export function detectUnit(value: number): DetectedTimestamp {
  const magnitude = Math.abs(value);

  if (magnitude >= 1e17) {
    return {
      unit: "nanoseconds",
      milliseconds: value / 1e6,
      reason: "17 or more digits: nanoseconds, as emitted by Go and by Prometheus.",
    };
  }
  if (magnitude >= 1e14) {
    return {
      unit: "microseconds",
      milliseconds: value / 1e3,
      reason: "14 to 16 digits: microseconds, as used by Python's time.time_ns and by Postgres.",
    };
  }
  if (magnitude >= 1e11) {
    return {
      unit: "milliseconds",
      milliseconds: value,
      reason: "11 to 13 digits: milliseconds, which is what JavaScript's Date.now returns.",
    };
  }
  return {
    unit: "seconds",
    milliseconds: value * 1000,
    reason: "10 digits or fewer: seconds, which is the classic Unix epoch unit.",
  };
}

export interface ParsedInstant {
  date: Date;
  detected?: DetectedTimestamp;
  /** What the input was recognised as. */
  kind: "unix" | "iso" | "rfc2822" | "now" | "relative";
}

export type InstantResult = { ok: true; value: ParsedInstant } | { ok: false; error: string };

const RELATIVE_RE = /^([-+]?\d+(?:\.\d+)?)\s*(second|minute|hour|day|week|month|year)s?(\s+ago)?$/i;

const RELATIVE_MS: Record<string, number> = {
  second: 1000,
  minute: 60_000,
  hour: 3_600_000,
  day: 86_400_000,
  week: 604_800_000,
  // Approximations, and labelled as such wherever they are shown: a month is
  // not a fixed length and neither is a year.
  month: 2_629_746_000,
  year: 31_556_952_000,
};

export function parseInstant(input: string, now = Date.now()): InstantResult {
  const trimmed = input.trim();
  if (trimmed === "") return { ok: false, error: "Nothing to convert." };

  if (/^now$/i.test(trimmed)) {
    return { ok: true, value: { date: new Date(now), kind: "now" } };
  }

  const relative = RELATIVE_RE.exec(trimmed);
  if (relative) {
    const amount = Number(relative[1]) * (relative[3] ? -1 : 1);
    const unit = relative[2].toLowerCase();
    return {
      ok: true,
      value: { date: new Date(now + amount * RELATIVE_MS[unit]), kind: "relative" },
    };
  }

  // A bare number, with underscores and separators tolerated.
  if (/^[-+]?\d+(?:[.,]\d+)?$/.test(trimmed.replace(/[_\s]/g, ""))) {
    const numeric = Number(trimmed.replace(/[_\s]/g, "").replace(",", "."));
    const detected = detectUnit(numeric);
    const date = new Date(detected.milliseconds);
    if (Number.isNaN(date.getTime())) {
      return { ok: false, error: "That number is outside the range JavaScript's Date can hold." };
    }
    return { ok: true, value: { date, detected, kind: "unix" } };
  }

  const parsed = new Date(trimmed);
  if (!Number.isNaN(parsed.getTime())) {
    const kind = /^\d{4}-\d{2}-\d{2}/.test(trimmed) ? "iso" : "rfc2822";
    return { ok: true, value: { date: parsed, kind } };
  }

  return {
    ok: false,
    error:
      "Not recognised. Try a Unix timestamp, an ISO 8601 date (2026-09-11T08:00:00Z), an RFC 2822 date, `now`, or something like `3 days ago`.",
  };
}

export interface Representation {
  label: string;
  value: string;
  note?: string;
}

/** Every useful spelling of one instant, in one list. */
export function representations(date: Date, timeZone: string, now: Date): Representation[] {
  const ms = date.getTime();

  return [
    { label: "Unix seconds", value: String(Math.floor(ms / 1000)) },
    { label: "Unix milliseconds", value: String(ms) },
    { label: "Unix microseconds", value: String(ms * 1000) },
    { label: "ISO 8601 (UTC)", value: date.toISOString() },
    {
      label: "ISO 8601 (local)",
      value: isoInZone(date, timeZone),
      note: `In ${timeZone}`,
    },
    { label: "RFC 2822", value: date.toUTCString() },
    {
      label: "Human",
      value: humanReadable(date, timeZone),
    },
    {
      label: "Relative",
      value: relativeTo(date, now),
      note: "From now",
    },
    {
      label: "Day of year",
      value: String(dayOfYear(date)),
      note: `Week ${isoWeek(date)} by ISO 8601`,
    },
  ];
}

/**
 * A readable date, assembled from parts rather than from an ICU pattern.
 *
 * `dateStyle: "full"` looks like the obvious answer and is a portability trap:
 * the pattern behind it lives in the ICU data of whatever is running the code,
 * and those differ. Node 22 renders `Thursday 11 September 2025`; Chromium
 * renders `Thursday, 11 September 2025`. On a statically exported site the
 * server output is frozen at build time, so that one comma was a hydration
 * mismatch on every visit — React discarded the tree and re-rendered it, which
 * is invisible except as a console error and a wasted render.
 *
 * Requesting individual components and joining them here removes the pattern
 * from the equation. The component *values* — month and weekday names, the
 * zone abbreviation — are stable across ICU versions for English; only the
 * punctuation between them was ever in doubt.
 */
function humanReadable(date: Date, timeZone: string): string {
  const parts = formatParts(date, timeZone, {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZoneName: "short",
  });

  const get = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((part) => part.type === type)?.value ?? "";

  const clock = `${get("hour")}:${get("minute")}:${get("second")}`;
  const zone = get("timeZoneName");
  return `${get("weekday")}, ${get("day")} ${get("month")} ${get("year")} at ${clock}${
    zone ? ` ${zone}` : ""
  }`;
}

function formatParts(
  date: Date,
  timeZone: string,
  options: Intl.DateTimeFormatOptions
): Intl.DateTimeFormatPart[] {
  try {
    return new Intl.DateTimeFormat("en-GB", { ...options, timeZone }).formatToParts(date);
  } catch {
    return new Intl.DateTimeFormat("en-GB", options).formatToParts(date);
  }
}

/**
 * ISO 8601 in a named zone, with the correct offset for that date.
 *
 * `toISOString` is always UTC and `toLocaleString` produces a formatted string
 * rather than ISO, so this reassembles the parts. Reading the offset from
 * `Intl` rather than computing it is what makes the result correct across a
 * daylight-saving boundary — the offset for a zone is a property of the instant,
 * not of the zone.
 */
export function isoInZone(date: Date, timeZone: string): string {
  try {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
      timeZoneName: "longOffset",
    }).formatToParts(date);

    const get = (type: Intl.DateTimeFormatPartTypes) =>
      parts.find((part) => part.type === type)?.value ?? "";

    const offsetPart = get("timeZoneName").replace("GMT", "") || "+00:00";
    const offset = offsetPart === "" ? "Z" : offsetPart;
    // Intl renders midnight as 24 in some locales' hour cycles.
    const hour = get("hour") === "24" ? "00" : get("hour");
    return `${get("year")}-${get("month")}-${get("day")}T${hour}:${get("minute")}:${get("second")}${offset}`;
  } catch {
    return date.toISOString();
  }
}

export function relativeTo(date: Date, reference: Date): string {
  const deltaMs = date.getTime() - reference.getTime();
  const absolute = Math.abs(deltaMs);
  const formatter = new Intl.RelativeTimeFormat("en-GB", { numeric: "auto" });

  const units: Array<[Intl.RelativeTimeFormatUnit, number]> = [
    ["year", RELATIVE_MS.year],
    ["month", RELATIVE_MS.month],
    ["week", RELATIVE_MS.week],
    ["day", RELATIVE_MS.day],
    ["hour", RELATIVE_MS.hour],
    ["minute", RELATIVE_MS.minute],
    ["second", RELATIVE_MS.second],
  ];

  for (const [unit, size] of units) {
    if (absolute >= size || unit === "second") {
      return formatter.format(Math.round(deltaMs / size), unit);
    }
  }
  return "now";
}

export function dayOfYear(date: Date): number {
  const start = Date.UTC(date.getUTCFullYear(), 0, 1);
  return Math.floor((date.getTime() - start) / RELATIVE_MS.day) + 1;
}

/**
 * ISO 8601 week number.
 *
 * Weeks start on Monday and week 1 is the one containing the first Thursday of
 * the year, so 1 January can be in week 52 of the previous year. Getting this
 * wrong is why some dashboards show a week 53 that nobody else has.
 */
export function isoWeek(date: Date): number {
  const target = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = target.getUTCDay() || 7;
  target.setUTCDate(target.getUTCDate() + 4 - day);
  const yearStart = Date.UTC(target.getUTCFullYear(), 0, 1);
  return Math.ceil(((target.getTime() - yearStart) / RELATIVE_MS.day + 1) / 7);
}

/** A short list of zones people actually convert between. */
export const COMMON_ZONES = [
  "UTC",
  "Europe/London",
  "Europe/Berlin",
  "Europe/Moscow",
  "Asia/Tehran",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Asia/Shanghai",
  "Asia/Tokyo",
  "Australia/Sydney",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Sao_Paulo",
];

export function localZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

/** Dates that break things, offered as one-click test inputs. */
export const NOTABLE_INSTANTS = [
  { label: "Unix epoch", value: "0", note: "1970-01-01T00:00:00Z" },
  {
    label: "Year 2038",
    value: "2147483647",
    note: "The last second a signed 32-bit time_t can hold. Still live in embedded systems and old file formats.",
  },
  {
    label: "Y2K",
    value: "946684800",
    note: "2000-01-01T00:00:00Z",
  },
  {
    label: "Leap second 2016",
    value: "1483228799",
    note: "The last leap second added. Unix time has no way to represent one, so it repeats a second instead.",
  },
  {
    label: "Leap day",
    value: "2024-02-29T12:00:00Z",
    note: "The date that breaks any code doing date arithmetic by adding 365.",
  },
];
