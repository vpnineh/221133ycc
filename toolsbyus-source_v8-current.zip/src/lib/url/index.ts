/**
 * URL encoding, which is three different encodings that people call one thing.
 *
 * RFC 3986 percent-encoding is what `encodeURIComponent` does, minus four
 * characters it leaves alone that the RFC reserves: `!`, `'`, `(`, `)` and `*`.
 * Those matter when a signature is computed over the encoded form, which is why
 * every AWS and OAuth signing library ships its own encoder.
 *
 * `application/x-www-form-urlencoded` is not the same thing. It encodes a space
 * as `+` rather than `%20`, and a literal `+` therefore has to be encoded as
 * `%2B`. Decoding a form body with `decodeURIComponent` leaves `+` in place, so
 * "a + b" silently becomes "a   b" — a bug that shows up in search queries and
 * nowhere else, which is why it survives so long.
 *
 * Finally the URL itself: each component has its own set of legal characters,
 * so a path may contain `/` and a query value may not contain `&`.
 */

export type UrlMode = "component" | "uri" | "form" | "base64url";

export interface EncodeOptions {
  mode: UrlMode;
  /** Also encode !'()* which encodeURIComponent leaves alone. */
  strictRfc3986: boolean;
  /** Encode every character, including unreserved ones. */
  encodeEverything: boolean;
}

export const URL_DEFAULTS: EncodeOptions = {
  mode: "component",
  strictRfc3986: false,
  encodeEverything: false,
};

/** The five characters encodeURIComponent leaves alone that RFC 3986 reserves. */
const RFC3986_EXTRA = /[!'()*]/g;

export function encodeUrl(input: string, options: EncodeOptions): string {
  if (options.encodeEverything) {
    return [...new TextEncoder().encode(input)]
      .map((byte) => `%${byte.toString(16).toUpperCase().padStart(2, "0")}`)
      .join("");
  }

  switch (options.mode) {
    case "uri": {
      // Keeps the characters that structure a URL: : / ? # [ ] @ ! $ & ' ( ) * + , ; =
      const encoded = encodeURI(input);
      return options.strictRfc3986 ? encoded.replace(RFC3986_EXTRA, percentByte) : encoded;
    }
    case "form": {
      // A space is +, and a literal + is %2B, or the two are indistinguishable
      // after a round trip.
      const encoded = encodeURIComponent(input)
        .replace(RFC3986_EXTRA, percentByte)
        .replace(/%20/g, "+");
      return encoded;
    }
    case "base64url":
      return toBase64Url(input);
    default: {
      const encoded = encodeURIComponent(input);
      return options.strictRfc3986 ? encoded.replace(RFC3986_EXTRA, percentByte) : encoded;
    }
  }
}

function percentByte(char: string): string {
  return `%${char.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")}`;
}

export interface DecodeResult {
  value: string;
  error?: string;
  /** Notes about what the input implied, e.g. a + that may or may not be a space. */
  notes: string[];
}

export function decodeUrl(input: string, mode: UrlMode): DecodeResult {
  const notes: string[] = [];

  try {
    if (mode === "base64url") return { value: fromBase64Url(input), notes };

    let working = input;
    if (mode === "form") {
      // Decode + to space *before* percent-decoding, so a literal + written as
      // %2B survives: decoding first would turn it into a plus and then this
      // pass would turn that into a space.
      working = working.replace(/\+/g, " ");
    } else if (input.includes("+")) {
      notes.push(
        "The input contains +. In a form-encoded body that means a space; in a URL path or fragment it is a literal plus. Switch to form mode if this came from a query string or a POST body."
      );
    }

    const value = mode === "uri" ? decodeURI(working) : decodeURIComponent(working);
    if (/%(?![0-9a-fA-F]{2})/.test(input)) {
      notes.push("A % that is not followed by two hex digits was left as a literal percent sign.");
    }
    return { value, notes };
  } catch {
    // decodeURIComponent throws URIError on a malformed sequence rather than
    // saying which one, so the offending sequence is located here.
    const bad = /%[0-9a-fA-F]?(?![0-9a-fA-F])/.exec(input) ?? /%[^]{0,2}/.exec(input);
    return {
      value: "",
      error: bad
        ? `Malformed percent-encoding at position ${bad.index}: "${bad[0]}" is not a complete %XX sequence.`
        : "Malformed percent-encoding: a % escape is incomplete or names an invalid UTF-8 byte sequence.",
      notes,
    };
  }
}

/* -------------------------------------------------------------------------- */
/* base64url                                                                  */
/* -------------------------------------------------------------------------- */

/** Base64url per RFC 4648 section 5: - and _ instead of + and /, no padding. */
export function toBase64Url(input: string): string {
  const bytes = new TextEncoder().encode(input);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function fromBase64Url(input: string): string {
  const padded = input.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(padded + "=".repeat((4 - (padded.length % 4)) % 4));
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

/* -------------------------------------------------------------------------- */
/* URL inspection                                                             */
/* -------------------------------------------------------------------------- */

export interface UrlParts {
  protocol: string;
  username: string;
  password: string;
  hostname: string;
  port: string;
  pathname: string;
  search: string;
  hash: string;
  /** Query parameters in order, decoded, duplicates preserved. */
  params: Array<{ key: string; value: string }>;
}

/**
 * Splits a URL into its parts using the browser's own parser.
 *
 * Deliberately not a regular expression. URL parsing has enough edge cases —
 * userinfo, IPv6 literals, default ports, percent-encoded hosts — that the WHATWG
 * algorithm in the platform is both more correct and less code than any pattern
 * anyone would write.
 */
export function inspectUrl(input: string): { url: UrlParts } | { error: string } {
  try {
    const url = new URL(input.trim());
    const params: Array<{ key: string; value: string }> = [];
    // searchParams preserves order and duplicates, which a plain object would
    // silently collapse — and duplicate query keys are meaningful in many APIs.
    url.searchParams.forEach((value, key) => params.push({ key, value }));

    return {
      url: {
        protocol: url.protocol,
        username: url.username,
        password: url.password,
        hostname: url.hostname,
        port: url.port,
        pathname: url.pathname,
        search: url.search,
        hash: url.hash,
        params,
      },
    };
  } catch {
    return {
      error:
        "Not a valid absolute URL. A scheme is required — https://example.com/path rather than example.com/path.",
    };
  }
}

/** Percent-decodes every value in a query string, for reading a long one. */
export function decodeQueryString(search: string): Array<{ key: string; value: string }> {
  const trimmed = search.startsWith("?") ? search.slice(1) : search;
  if (!trimmed) return [];
  return trimmed.split("&").map((pair) => {
    const index = pair.indexOf("=");
    const rawKey = index === -1 ? pair : pair.slice(0, index);
    const rawValue = index === -1 ? "" : pair.slice(index + 1);
    return {
      key: decodeUrl(rawKey, "form").value,
      value: decodeUrl(rawValue, "form").value,
    };
  });
}

/** Counts how many times the input has been encoded, up to a sane ceiling. */
export function detectEncodingDepth(input: string): number {
  let current = input;
  let depth = 0;
  // Double-encoding is a real and confusing bug: %2520 is a space that went
  // through an encoder twice, and it reads as "%20" to a human.
  while (depth < 10 && /%[0-9a-fA-F]{2}/.test(current)) {
    const next = decodeUrl(current, "component");
    if (next.error || next.value === current) break;
    current = next.value;
    depth++;
  }
  return depth;
}
