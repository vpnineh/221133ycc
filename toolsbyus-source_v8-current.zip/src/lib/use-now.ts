"use client";

import { useSyncExternalStore } from "react";

/**
 * The current time, read the way React wants a mutable external value read.
 *
 * The obvious implementation — `useState(Date.now())` plus an interval in an
 * effect — renders a different value on the server than in the browser, which is
 * a hydration mismatch, and calls `setState` synchronously inside an effect,
 * which costs a second render on every mount.
 *
 * `useSyncExternalStore` is built for exactly this, with two traps.
 * `subscribe` must be a stable function: an inline arrow is a new function on
 * every render, so React unsubscribes and resubscribes each time, and if
 * `subscribe` also notifies, that is an infinite loop. And `getSnapshot` must
 * return a cached value rather than calling `Date.now()`, or React sees a new
 * value on every read and never settles. Both are module-level here.
 */

const listeners = new Set<() => void>();
let timer: ReturnType<typeof setInterval> | null = null;

/** Cached: `getSnapshot` must return the same value until something changes. */
let current = 0;

/** Zero, not a real time: the server must not render a moment the client will disagree with. */
const SERVER_SNAPSHOT = 0;

function notify(): void {
  for (const listener of listeners) listener();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);

  if (timer === null) {
    // Seeded here rather than notified: React re-reads the snapshot after
    // subscribing and schedules its own update if it changed, so calling the
    // listener synchronously would only add a render.
    current = Date.now();
    timer = setInterval(() => {
      current = Date.now();
      notify();
    }, 1000);
  }

  return () => {
    listeners.delete(listener);
    if (listeners.size === 0 && timer !== null) {
      clearInterval(timer);
      timer = null;
    }
  };
}

function getSnapshot(): number {
  return current;
}

function getServerSnapshot(): number {
  return SERVER_SNAPSHOT;
}

/**
 * Milliseconds since the epoch, quantised to `granularityMs`.
 *
 * One interval serves every caller; the granularity only affects which ticks
 * produce a different value, so a component that needs minute precision does
 * not re-run its work sixty times a minute. Returns 0 on the server and on the
 * first render, which callers check for.
 */
export function useNow(granularityMs = 1000): number {
  const now = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  if (now === SERVER_SNAPSHOT) return SERVER_SNAPSHOT;
  return Math.floor(now / granularityMs) * granularityMs;
}
