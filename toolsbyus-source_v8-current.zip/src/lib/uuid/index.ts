/**
 * RFC 4122 & RFC 9562 compliant UUID generation and inspection.
 */

export type UuidVersion = "v4" | "v7" | "v1";

export interface UuidFormatOptions {
  uppercase?: boolean;
  hyphens?: boolean;
  quotes?: boolean;
  braces?: boolean;
  separator?: "newline" | "comma" | "json";
}

export interface UuidInspection {
  isValid: boolean;
  normalized?: string;
  version?: number;
  versionName?: string;
  variant?: string;
  timestamp?: Date;
  timestampIso?: string;
  details?: string;
  randomBits?: number;
}

/**
 * Generate UUID v4 using crypto.randomUUID or fallback crypto.getRandomValues
 */
export function generateUuidV4(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40; // Version 4
  bytes[8] = (bytes[8] & 0x3f) | 0x80; // Variant RFC 4122
  return bytesToUuid(bytes);
}

// State for monotonic v7 sequence in rapid generation loops
let lastV7Timestamp = 0;
let v7Sequence = 0;

/**
 * Generate UUID v7 (RFC 9562) - 48-bit Unix timestamp ms + 12-bit sub-ms/counter + 62-bit random.
 */
export function generateUuidV7(timestampMs = Date.now()): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);

  // Handle timestamp monotonicity if generated rapidly within the same millisecond
  if (timestampMs > lastV7Timestamp) {
    lastV7Timestamp = timestampMs;
    v7Sequence = ((bytes[6] & 0x0f) << 8) | bytes[7]; // seed random 12-bit
  } else {
    v7Sequence = (v7Sequence + 1) & 0x0fff;
    timestampMs = lastV7Timestamp;
  }

  // 48-bit timestamp in milliseconds
  bytes[0] = Math.floor(timestampMs / 0x10000000000) & 0xff;
  bytes[1] = Math.floor(timestampMs / 0x100000000) & 0xff;
  bytes[2] = Math.floor(timestampMs / 0x1000000) & 0xff;
  bytes[3] = Math.floor(timestampMs / 0x10000) & 0xff;
  bytes[4] = Math.floor(timestampMs / 0x100) & 0xff;
  bytes[5] = timestampMs & 0xff;

  // 4-bit version 7 + top 4 bits of 12-bit sequence
  bytes[6] = 0x70 | ((v7Sequence >> 8) & 0x0f);
  bytes[7] = v7Sequence & 0xff;

  // Variant RFC 4122 (10xxxxxx)
  bytes[8] = (bytes[8] & 0x3f) | 0x80;

  return bytesToUuid(bytes);
}

let v1ClockSeq = Math.floor(Math.random() * 0x3fff);
let v1Node: Uint8Array | null = null;

/**
 * Generate UUID v1 (RFC 4122) - 60-bit 100ns timestamp since Gregorian epoch (15 Oct 1582).
 */
export function generateUuidV1(): string {
  if (!v1Node) {
    v1Node = new Uint8Array(6);
    crypto.getRandomValues(v1Node);
    v1Node[0] |= 0x01; // multicast bit set
  }

  // 100ns intervals since 1582-10-15T00:00:00Z
  const GREGORIAN_OFFSET = 122192928000000000n;
  const now100ns = BigInt(Date.now()) * 10000n + GREGORIAN_OFFSET;

  const timeLow = Number(now100ns & 0xffffffffn);
  const timeMid = Number((now100ns >> 32n) & 0xffffn);
  const timeHi = Number((now100ns >> 48n) & 0x0fffn);

  v1ClockSeq = (v1ClockSeq + 1) & 0x3fff;

  const bytes = new Uint8Array(16);
  bytes[0] = (timeLow >>> 24) & 0xff;
  bytes[1] = (timeLow >>> 16) & 0xff;
  bytes[2] = (timeLow >>> 8) & 0xff;
  bytes[3] = timeLow & 0xff;

  bytes[4] = (timeMid >>> 8) & 0xff;
  bytes[5] = timeMid & 0xff;

  bytes[6] = 0x10 | ((timeHi >>> 8) & 0x0f); // version 1 + top 4 bits of timeHi
  bytes[7] = timeHi & 0xff; // low 8 bits of timeHi

  bytes[8] = 0x80 | ((v1ClockSeq >>> 8) & 0x3f); // variant
  bytes[9] = v1ClockSeq & 0xff;

  bytes.set(v1Node, 10);

  return bytesToUuid(bytes);
}

export function bytesToUuid(bytes: Uint8Array): string {
  const hex: string[] = [];
  for (let i = 0; i < 16; i++) {
    hex.push(bytes[i].toString(16).padStart(2, "0"));
  }
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex
    .slice(6, 8)
    .join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10, 16).join("")}`;
}

export function formatUuid(uuid: string, options: UuidFormatOptions): string {
  let result = uuid.toLowerCase();
  if (options.hyphens === false) {
    result = result.replace(/-/g, "");
  }
  if (options.uppercase) {
    result = result.toUpperCase();
  }
  if (options.braces) {
    result = `{${result}}`;
  }
  if (options.quotes) {
    result = `"${result}"`;
  }
  return result;
}

export function generateBatch(
  version: UuidVersion,
  count: number,
  options: UuidFormatOptions
): string {
  const safeCount = Math.min(Math.max(1, count), 5000);
  const generator =
    version === "v7"
      ? generateUuidV7
      : version === "v1"
      ? generateUuidV1
      : generateUuidV4;

  const uuids: string[] = [];
  for (let i = 0; i < safeCount; i++) {
    uuids.push(formatUuid(generator(), options));
  }

  if (options.separator === "json") {
    // Return formatted JSON array
    const rawUuids = uuids.map((u) => u.replace(/^"/, "").replace(/"$/, ""));
    return JSON.stringify(rawUuids, null, 2);
  }
  if (options.separator === "comma") {
    return uuids.join(", ");
  }
  return uuids.join("\n");
}

export function inspectUuid(input: string): UuidInspection {
  const clean = input.trim().replace(/^[{<]/, "").replace(/[}>]$/, "");
  const unhyphenated = clean.replace(/-/g, "").toLowerCase();

  if (!/^[0-9a-f]{32}$/.test(unhyphenated)) {
    return { isValid: false, details: "Input is not a 32-hex character UUID" };
  }

  const normalized = `${unhyphenated.slice(0, 8)}-${unhyphenated.slice(
    8,
    12
  )}-${unhyphenated.slice(12, 16)}-${unhyphenated.slice(
    16,
    20
  )}-${unhyphenated.slice(20, 32)}`;

  const versionNibble = parseInt(unhyphenated[12], 16);
  const variantNibble = parseInt(unhyphenated[16], 16);

  let variant = "Unknown";
  if ((variantNibble & 0x8) === 0x0) {
    variant = "NCS backward compatible";
  } else if ((variantNibble & 0xc) === 0x8) {
    variant = "RFC 4122 / RFC 9562";
  } else if ((variantNibble & 0xe) === 0xc) {
    variant = "Microsoft Corporation GUID";
  } else {
    variant = "Reserved for future definition";
  }

  const versionNames: Record<number, string> = {
    1: "Version 1 (Gregorian timestamp & MAC)",
    2: "Version 2 (DCE Security)",
    3: "Version 3 (MD5 namespace hash)",
    4: "Version 4 (Cryptographically random)",
    5: "Version 5 (SHA-1 namespace hash)",
    6: "Version 6 (Reordered Gregorian time)",
    7: "Version 7 (Unix Epoch millisecond time-ordered)",
    8: "Version 8 (Custom experimental)",
  };

  let timestamp: Date | undefined;
  let timestampIso: string | undefined;

  if (versionNibble === 7) {
    const timeMsHex = unhyphenated.slice(0, 12);
    const ms = parseInt(timeMsHex, 16);
    if (!isNaN(ms)) {
      timestamp = new Date(ms);
      timestampIso = timestamp.toISOString();
    }
  } else if (versionNibble === 1) {
    const timeLow = unhyphenated.slice(0, 8);
    const timeMid = unhyphenated.slice(8, 12);
    const timeHi = unhyphenated.slice(13, 16);
    const fullTimeHex = timeHi + timeMid + timeLow;
    try {
      const intervals100ns = BigInt(`0x${fullTimeHex}`);
      const GREGORIAN_OFFSET = 122192928000000000n;
      if (intervals100ns >= GREGORIAN_OFFSET) {
        const unixMs = Number((intervals100ns - GREGORIAN_OFFSET) / 10000n);
        timestamp = new Date(unixMs);
        timestampIso = timestamp.toISOString();
      }
    } catch {
      // BigInt parse failure
    }
  }

  const randomBits = versionNibble === 4 ? 122 : versionNibble === 7 ? 62 : 0;

  return {
    isValid: true,
    normalized,
    version: versionNibble,
    versionName: versionNames[versionNibble] || `Version ${versionNibble}`,
    variant,
    timestamp,
    timestampIso,
    randomBits,
  };
}
