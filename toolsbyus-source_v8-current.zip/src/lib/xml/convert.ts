import type { JsonValue, JsonObject } from "../json/types";
import { isForbiddenKey, safeSet } from "../safe-object";
import { parseAttributes, tokenizeXml, type XmlResult, type XmlToken } from "./index";

/**
 * XML to JSON, and back.
 *
 * There is no canonical mapping between the two, and pretending otherwise is
 * how converters produce output that is technically a translation and
 * practically unusable. The mismatches are real:
 *
 * - XML has attributes; JSON has one kind of member.
 * - XML has no arrays. `<item/><item/>` is two elements; `<item/>` is one. A
 *   converter cannot tell a single-element list from a scalar without a schema,
 *   which is why a response with one result breaks code written against a
 *   response with two.
 * - XML text is always text. `<count>3</count>` is the string "3" unless
 *   something decides otherwise.
 * - XML has ordering and mixed content; JSON objects have neither.
 *
 * Every one of those is exposed as a documented option rather than decided
 * silently, and the `forceArray` list exists specifically because the
 * one-element problem cannot be solved by inference at all.
 */

export interface XmlToJsonOptions {
  /** Prefix for attribute members. Empty merges them with child elements. */
  attributePrefix: string;
  /** Member name holding an element's text when it also has attributes. */
  textKey: string;
  /** Convert "3", "true" and "null" to their JSON types. */
  parseValues: boolean;
  /** Element names that must always be arrays, even with one occurrence. */
  forceArray: string[];
  /** Drop namespace prefixes from element and attribute names. */
  stripNamespaces: boolean;
  /** Keep comments as members named `#comment`. */
  keepComments: boolean;
  /** Collapse an element with only text and no attributes to a bare string. */
  collapseText: boolean;
}

export const XML_TO_JSON_DEFAULTS: XmlToJsonOptions = {
  attributePrefix: "@",
  textKey: "#text",
  parseValues: false,
  forceArray: [],
  stripNamespaces: false,
  keepComments: false,
  collapseText: true,
};

interface Frame {
  name: string;
  /** Members collected so far, before collapsing. */
  members: Map<string, JsonValue[]>;
  text: string[];
}

const NUMBER_RE = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][-+]?[0-9]+)?$/;

/** Resolves a text node to a typed value, when value parsing is on. */
export function coerceText(text: string): JsonValue {
  const trimmed = text.trim();
  if (trimmed === "true") return true;
  if (trimmed === "false") return false;
  if (trimmed === "null") return null;
  // A leading zero is significant in a part number or a postcode, and the JSON
  // grammar forbids it anyway, so "007" stays a string.
  if (NUMBER_RE.test(trimmed)) {
    const parsed = Number(trimmed);
    if (Number.isSafeInteger(parsed) || !Number.isInteger(parsed)) return parsed;
  }
  return text;
}

const ENTITIES: Record<string, string> = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'",
};

/** Decodes the five predefined entities plus numeric character references. */
export function decodeEntities(text: string): string {
  return text.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (match, body: string) => {
    if (body.startsWith("#x") || body.startsWith("#X")) {
      const code = parseInt(body.slice(2), 16);
      return Number.isFinite(code) ? safeFromCodePoint(code, match) : match;
    }
    if (body.startsWith("#")) {
      const code = parseInt(body.slice(1), 10);
      return Number.isFinite(code) ? safeFromCodePoint(code, match) : match;
    }
    // An undeclared entity is left verbatim. Replacing it with nothing would
    // silently delete content; XML itself says a document using one without a
    // DTD is not well-formed, and the tokenizer already reports that.
    return ENTITIES[body] ?? match;
  });
}

function safeFromCodePoint(code: number, fallback: string): string {
  if (code < 0 || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return fallback;
  return String.fromCodePoint(code);
}

function localName(name: string, strip: boolean): string {
  if (!strip) return name;
  const colon = name.indexOf(":");
  return colon === -1 ? name : name.slice(colon + 1);
}

export function xmlToJson(input: string, options: XmlToJsonOptions): XmlResult<JsonValue> {
  const tokenized = tokenizeXml(input);
  if (!tokenized.ok) return tokenized;

  const forced = new Set(options.forceArray.map((name) => name.trim()).filter(Boolean));
  const root: Frame = { name: "#document", members: new Map(), text: [] };
  // Explicit stack rather than recursion: an XML document nested 50,000 deep is
  // a 300 KB file, which is not an exotic input.
  const stack: Frame[] = [root];

  for (const token of tokenized.value) {
    const top = stack[stack.length - 1];

    switch (token.kind) {
      case "open":
      case "selfClosing": {
        const name = localName(token.name ?? "", options.stripNamespaces);
        const frame: Frame = { name, members: new Map(), text: [] };
        applyAttributes(frame, token, options);
        if (token.kind === "selfClosing") {
          addMember(top, name, collapse(frame, options, forced));
        } else {
          stack.push(frame);
        }
        break;
      }
      case "close": {
        const name = localName(token.name ?? "", options.stripNamespaces);
        // The tokenizer is a scanner, not a validator, so balance is checked
        // here. Without it `<a><b></a>` converts to plausible-looking JSON and
        // the person pasting truncated XML never learns it was truncated.
        if (stack.length <= 1) {
          return {
            ok: false,
            error: {
              message: `Closing tag </${name}> has no matching opening tag.`,
              line: token.line,
              column: token.column,
            },
          };
        }
        const frame = stack.pop()!;
        if (frame.name !== name) {
          return {
            ok: false,
            error: {
              message: `Mismatched tags: <${frame.name}> is closed by </${name}>.`,
              line: token.line,
              column: token.column,
            },
          };
        }
        const parent = stack[stack.length - 1];
        addMember(parent, frame.name, collapse(frame, options, forced));
        break;
      }
      case "text": {
        const value = token.value ?? token.raw;
        if (value.trim() !== "") top.text.push(decodeEntities(value));
        break;
      }
      case "cdata": {
        // CDATA is literal by definition: entities inside it are not entities.
        top.text.push(token.value ?? "");
        break;
      }
      case "comment": {
        if (options.keepComments) addMember(top, "#comment", token.value ?? "");
        break;
      }
      default:
        // Declarations, processing instructions and the doctype carry no data
        // that survives translation into JSON.
        break;
    }
  }

  if (stack.length > 1) {
    const unclosed = stack.slice(1).map((frame) => `<${frame.name}>`);
    return {
      ok: false,
      error: {
        message: `Unclosed element${unclosed.length === 1 ? "" : "s"}: ${unclosed.join(", ")}.`,
        line: 1,
        column: 1,
      },
    };
  }

  const document = collapse(root, options, forced);
  return { ok: true, value: document, warnings: tokenized.warnings };
}

function applyAttributes(frame: Frame, token: XmlToken, options: XmlToJsonOptions): void {
  for (const attribute of parseAttributes(token.raw)) {
    const name = localName(attribute.name, options.stripNamespaces);
    // xmlns declarations describe the document, not the data.
    if (options.stripNamespaces && (name === "xmlns" || attribute.name.startsWith("xmlns:"))) {
      continue;
    }
    const decoded = decodeEntities(attribute.value);
    const value = options.parseValues ? coerceText(decoded) : decoded;
    addMember(frame, `${options.attributePrefix}${name}`, value);
  }
}

function addMember(frame: Frame, key: string, value: JsonValue): void {
  const existing = frame.members.get(key);
  if (existing) existing.push(value);
  else frame.members.set(key, [value]);
}

/**
 * Turns a frame into its JSON value.
 *
 * Repeated members become an array; a single member stays scalar unless its
 * name is in the forced list. That asymmetry is the single biggest source of
 * bugs in XML-derived JSON, and the only honest fix is for the caller to say
 * which names are collections.
 */
function collapse(
  frame: Frame,
  options: XmlToJsonOptions,
  forced: ReadonlySet<string>
): JsonValue {
  const text = frame.text.join("").trim();

  if (frame.members.size === 0) {
    // An empty element is null rather than "": `<a/>` and `<a></a>` are the
    // same thing in XML, and neither of them carries a value.
    if (text === "") return null;
    if (!options.collapseText && frame.name !== "#document") {
      const object: JsonObject = {};
      object[options.textKey] = options.parseValues ? coerceText(text) : text;
      return object;
    }
    return options.parseValues ? coerceText(text) : text;
  }

  const object: JsonObject = {};
  for (const [key, values] of frame.members) {
    const bare = key.startsWith(options.attributePrefix) && options.attributePrefix
      ? key.slice(options.attributePrefix.length)
      : key;
    const asArray = values.length > 1 || forced.has(bare) || forced.has(key);
    const value: JsonValue = asArray ? values : values[0];
    if (isForbiddenKey(key)) safeSet(object as Record<string, unknown>, key, value);
    else object[key] = value;
  }

  if (text !== "") {
    // Mixed content: the element has children *and* text, so the text has to go
    // somewhere named. This is the case JSON simply cannot represent faithfully,
    // because the text's position relative to the children is lost.
    const value = options.parseValues ? coerceText(text) : text;
    if (isForbiddenKey(options.textKey)) {
      safeSet(object as Record<string, unknown>, options.textKey, value);
    } else {
      object[options.textKey] = value;
    }
  }

  return object;
}

/* -------------------------------------------------------------------------- */
/* JSON to XML                                                                */
/* -------------------------------------------------------------------------- */

export interface JsonToXmlOptions {
  /** Name of the wrapping element. */
  rootName: string;
  /** Members with this prefix become attributes. */
  attributePrefix: string;
  /** Member holding an element's text content. */
  textKey: string;
  /** Spaces per level; 0 emits one line. */
  indent: number;
  /** Emit the `<?xml … ?>` declaration. */
  declaration: boolean;
  /** Element name for array items when the array is the value of a member. */
  itemName: string;
  /** Write `<a/>` rather than `<a></a>` for an empty value. */
  selfCloseEmpty: boolean;
}

export const JSON_TO_XML_DEFAULTS: JsonToXmlOptions = {
  rootName: "root",
  attributePrefix: "@",
  textKey: "#text",
  indent: 2,
  declaration: true,
  itemName: "item",
  selfCloseEmpty: true,
};

/** XML 1.0 Name production, restricted to the characters that matter here. */
const XML_NAME_RE = /^[A-Za-z_][A-Za-z0-9._-]*$/;

/**
 * Makes a JSON key usable as an element name.
 *
 * JSON keys can be anything, including `` and `2024`, and XML names cannot.
 * Substituting an underscore is lossy, so the original is preserved in a
 * `name` attribute rather than thrown away.
 */
export function toElementName(key: string): { name: string; original?: string } {
  if (XML_NAME_RE.test(key)) return { name: key };
  const cleaned = key.replace(/[^A-Za-z0-9._-]/g, "_");
  const name = /^[A-Za-z_]/.test(cleaned) ? cleaned : `_${cleaned}`;
  return { name: name || "_", original: key };
}

export function escapeXmlText(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export function escapeXmlAttribute(text: string): string {
  return escapeXmlText(text).replace(/"/g, "&quot;").replace(/\n/g, "&#10;");
}

export function jsonToXml(value: JsonValue, options: JsonToXmlOptions): string {
  const lines: string[] = [];
  if (options.declaration) lines.push('<?xml version="1.0" encoding="UTF-8"?>');

  if (Array.isArray(value)) {
    // An XML document has exactly one root element. Writing an array's items at
    // the top level would produce as many roots as items, which no parser will
    // accept — so the array is wrapped and its items take the item name.
    const { name } = toElementName(options.rootName);
    if (value.length === 0) {
      lines.push(options.selfCloseEmpty ? `<${name}/>` : `<${name}></${name}>`);
    } else {
      lines.push(`<${name}>`);
      for (const item of value) writeElement(options.itemName, item, 1, lines, options);
      lines.push(`</${name}>`);
    }
  } else {
    writeElement(options.rootName, value, 0, lines, options);
  }

  return `${lines.join(options.indent > 0 ? "\n" : "")}\n`;
}

function pad(level: number, options: JsonToXmlOptions): string {
  return options.indent > 0 ? " ".repeat(level * options.indent) : "";
}

function writeElement(
  rawName: string,
  value: JsonValue,
  level: number,
  lines: string[],
  options: JsonToXmlOptions
): void {
  const { name, original } = toElementName(rawName);
  const indent = pad(level, options);

  if (Array.isArray(value)) {
    // An array member repeats its own element name, which is how XML expresses
    // a list — there is no container element unless the JSON had one.
    for (const item of value) writeElement(rawName, item, level, lines, options);
    return;
  }

  const attributes: string[] = [];
  if (original) attributes.push(`name="${escapeXmlAttribute(original)}"`);

  if (value === null) {
    lines.push(
      options.selfCloseEmpty
        ? `${indent}<${name}${attrString(attributes)}/>`
        : `${indent}<${name}${attrString(attributes)}></${name}>`
    );
    return;
  }

  if (typeof value !== "object") {
    const text = escapeXmlText(String(value));
    lines.push(`${indent}<${name}${attrString(attributes)}>${text}</${name}>`);
    return;
  }

  const object = value as JsonObject;
  const children: Array<[string, JsonValue]> = [];
  let text: string | null = null;

  for (const [key, child] of Object.entries(object)) {
    if (options.attributePrefix && key.startsWith(options.attributePrefix)) {
      const attributeName = toElementName(key.slice(options.attributePrefix.length)).name;
      attributes.push(`${attributeName}="${escapeXmlAttribute(stringifyScalar(child))}"`);
      continue;
    }
    if (key === options.textKey) {
      text = stringifyScalar(child);
      continue;
    }
    children.push([key, child]);
  }

  const open = `${indent}<${name}${attrString(attributes)}`;

  if (children.length === 0 && text === null) {
    lines.push(options.selfCloseEmpty ? `${open}/>` : `${open}></${name}>`);
    return;
  }

  if (children.length === 0 && text !== null) {
    lines.push(`${open}>${escapeXmlText(text)}</${name}>`);
    return;
  }

  lines.push(`${open}>`);
  if (text !== null) lines.push(`${pad(level + 1, options)}${escapeXmlText(text)}`);
  for (const [key, child] of children) writeElement(key, child, level + 1, lines, options);
  lines.push(`${indent}</${name}>`);
}

function attrString(attributes: string[]): string {
  return attributes.length > 0 ? ` ${attributes.join(" ")}` : "";
}

function stringifyScalar(value: JsonValue): string {
  if (value === null) return "";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}
