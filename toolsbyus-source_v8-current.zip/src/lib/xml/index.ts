/**
 * A hand-written XML tokenizer and formatter.
 *
 * No regex pipeline. The reason is the same one that forced the JSON repair
 * engine to be rewritten as a single tokenizer: the passes are circular.
 * Recognising a comment needs to know whether you are inside a CDATA section;
 * recognising CDATA needs to know whether you are inside a comment; deciding
 * whether `<` opens a tag needs to know whether you are inside an attribute
 * value. Any ordering of independent scans gets one of those wrong, and the
 * failure is silent corruption of the document rather than an error.
 *
 * So the input is scanned exactly once into a token stream, and everything
 * downstream — formatting, minifying, conversion — is a fold over that stream.
 *
 * This is deliberately not a validating parser. It does not resolve entities,
 * apply a DTD, or check namespace bindings. It reads well-formedness far enough
 * to re-indent a document faithfully and to report where a document stops being
 * well-formed, which is what a formatter is for.
 */

export type XmlTokenKind =
  | "declaration" // <?xml … ?>
  | "processing" // <?target … ?>
  | "doctype" // <!DOCTYPE … >
  | "comment" // <!-- … -->
  | "cdata" // <![CDATA[ … ]]>
  | "open" // <tag attr="v">
  | "close" // </tag>
  | "selfClosing" // <tag />
  | "text";

export interface XmlToken {
  kind: XmlTokenKind;
  /** Verbatim source text of the token. */
  raw: string;
  /** Element name, for open/close/self-closing tokens. */
  name?: string;
  /** Text content, for text/comment/cdata tokens. */
  value?: string;
  line: number;
  column: number;
}

export interface XmlError {
  message: string;
  line: number;
  column: number;
}

export type XmlResult<T> = { ok: true; value: T; warnings: string[] } | { ok: false; error: XmlError };

const NAME_START = /[A-Za-z_:]/;
const NAME_CHAR = /[-A-Za-z0-9_.:]/;

/**
 * Scans the whole document into tokens.
 *
 * Positions are tracked as the scan proceeds rather than recomputed, so an
 * error can point at a line and column without a second pass over the input.
 */
export function tokenizeXml(input: string): XmlResult<XmlToken[]> {
  const tokens: XmlToken[] = [];
  let i = 0;
  let line = 1;
  let column = 1;

  // A BOM before the declaration is legal and must not become text content.
  if (input.charCodeAt(0) === 0xfeff) i = 1;

  const advance = (count: number) => {
    for (let k = 0; k < count; k++) {
      if (input[i + k] === "\n") {
        line++;
        column = 1;
      } else {
        column++;
      }
    }
    i += count;
  };

  const fail = (message: string): XmlResult<XmlToken[]> => ({
    ok: false,
    error: { message, line, column },
  });

  while (i < input.length) {
    const startLine = line;
    const startColumn = column;

    if (input[i] !== "<") {
      // Text run: everything up to the next tag.
      const next = input.indexOf("<", i);
      const end = next === -1 ? input.length : next;
      const raw = input.slice(i, end);
      tokens.push({ kind: "text", raw, value: raw, line: startLine, column: startColumn });
      advance(end - i);
      continue;
    }

    // --- Comment ---------------------------------------------------------
    if (input.startsWith("<!--", i)) {
      const end = input.indexOf("-->", i + 4);
      if (end === -1) return fail("Unterminated comment: no matching -->");
      const raw = input.slice(i, end + 3);
      tokens.push({
        kind: "comment",
        raw,
        value: input.slice(i + 4, end),
        line: startLine,
        column: startColumn,
      });
      advance(raw.length);
      continue;
    }

    // --- CDATA -----------------------------------------------------------
    if (input.startsWith("<![CDATA[", i)) {
      const end = input.indexOf("]]>", i + 9);
      if (end === -1) return fail("Unterminated CDATA section: no matching ]]>");
      const raw = input.slice(i, end + 3);
      tokens.push({
        kind: "cdata",
        raw,
        value: input.slice(i + 9, end),
        line: startLine,
        column: startColumn,
      });
      advance(raw.length);
      continue;
    }

    // --- DOCTYPE ---------------------------------------------------------
    if (/^<!doctype/i.test(input.slice(i, i + 9))) {
      // An internal subset is bracketed and may itself contain '>', so the
      // scan tracks bracket depth rather than taking the first '>'.
      let depth = 0;
      let k = i;
      for (; k < input.length; k++) {
        const ch = input[k];
        if (ch === "[") depth++;
        else if (ch === "]") depth--;
        else if (ch === ">" && depth === 0) break;
      }
      if (k >= input.length) return fail("Unterminated DOCTYPE declaration");
      const raw = input.slice(i, k + 1);
      tokens.push({ kind: "doctype", raw, line: startLine, column: startColumn });
      advance(raw.length);
      continue;
    }

    // --- Declaration / processing instruction -----------------------------
    if (input.startsWith("<?", i)) {
      const end = input.indexOf("?>", i + 2);
      if (end === -1) return fail("Unterminated processing instruction: no matching ?>");
      const raw = input.slice(i, end + 2);
      const isDeclaration = /^<\?xml[\s?]/i.test(raw);
      tokens.push({
        kind: isDeclaration ? "declaration" : "processing",
        raw,
        line: startLine,
        column: startColumn,
      });
      advance(raw.length);
      continue;
    }

    // --- Closing tag ------------------------------------------------------
    if (input.startsWith("</", i)) {
      const end = input.indexOf(">", i + 2);
      if (end === -1) return fail("Unterminated closing tag: no matching >");
      const raw = input.slice(i, end + 1);
      const name = raw.slice(2, -1).trim();
      if (!name || !NAME_START.test(name[0])) return fail(`Invalid closing tag name: ${raw}`);
      tokens.push({ kind: "close", raw, name, line: startLine, column: startColumn });
      advance(raw.length);
      continue;
    }

    // --- Opening or self-closing tag --------------------------------------
    {
      if (i + 1 >= input.length || !NAME_START.test(input[i + 1])) {
        // A bare '<' that does not begin a tag. XML forbids it, but it turns up
        // constantly in hand-written files, so it is carried through as text
        // rather than aborting a format the user can see should succeed.
        tokens.push({ kind: "text", raw: "<", value: "<", line: startLine, column: startColumn });
        advance(1);
        continue;
      }

      let k = i + 1;
      while (k < input.length && NAME_CHAR.test(input[k])) k++;
      const name = input.slice(i + 1, k);

      // Walk to the tag's '>', respecting quoted attribute values — an
      // attribute may legally contain '>' and taking the first one is the
      // classic way a naive formatter mangles a document.
      let quote: string | null = null;
      for (; k < input.length; k++) {
        const ch = input[k];
        if (quote) {
          if (ch === quote) quote = null;
        } else if (ch === '"' || ch === "'") {
          quote = ch;
        } else if (ch === ">") {
          break;
        }
      }
      if (k >= input.length) return fail(`Unterminated tag <${name}: no matching >`);

      const raw = input.slice(i, k + 1);
      const selfClosing = /\/\s*>$/.test(raw);
      tokens.push({
        kind: selfClosing ? "selfClosing" : "open",
        raw,
        name,
        line: startLine,
        column: startColumn,
      });
      advance(raw.length);
    }
  }

  return { ok: true, value: tokens, warnings: [] };
}

export interface XmlFormatOptions {
  /** Spaces per level, or a literal tab. */
  indent: number | "tab";
  /** Remove comments from the output. */
  stripComments: boolean;
  /** Collapse runs of whitespace inside text nodes. */
  collapseWhitespace: boolean;
  /** Put every attribute on its own line once a tag has more than this many. */
  attributeWrapThreshold: number;
}

export const DEFAULT_XML_FORMAT: XmlFormatOptions = {
  indent: 2,
  stripComments: false,
  collapseWhitespace: true,
  attributeWrapThreshold: 0,
};

/** Pulls `name="value"` pairs out of a tag's raw text, quotes respected. */
export function parseAttributes(raw: string): Array<{ name: string; value: string; quote: string }> {
  const out: Array<{ name: string; value: string; quote: string }> = [];
  // Skip past '<' and the element name.
  let i = 1;
  while (i < raw.length && NAME_CHAR.test(raw[i])) i++;

  while (i < raw.length) {
    while (i < raw.length && /\s/.test(raw[i])) i++;
    if (i >= raw.length || raw[i] === ">" || raw[i] === "/") break;

    const nameStart = i;
    while (i < raw.length && NAME_CHAR.test(raw[i])) i++;
    const name = raw.slice(nameStart, i);
    if (!name) {
      i++;
      continue;
    }

    while (i < raw.length && /\s/.test(raw[i])) i++;
    if (raw[i] !== "=") {
      // A valueless attribute — invalid XML, ubiquitous in HTML.
      out.push({ name, value: "", quote: "" });
      continue;
    }
    i++;
    while (i < raw.length && /\s/.test(raw[i])) i++;

    const quote = raw[i] === '"' || raw[i] === "'" ? raw[i] : "";
    if (quote) {
      i++;
      const valueStart = i;
      while (i < raw.length && raw[i] !== quote) i++;
      out.push({ name, value: raw.slice(valueStart, i), quote });
      i++;
    } else {
      const valueStart = i;
      while (i < raw.length && !/[\s>/]/.test(raw[i])) i++;
      out.push({ name, value: raw.slice(valueStart, i), quote: "" });
    }
  }

  return out;
}

function renderTag(token: XmlToken, options: XmlFormatOptions, pad: string): string {
  const attributes = parseAttributes(token.raw);
  const close = token.kind === "selfClosing" ? " />" : ">";

  if (attributes.length === 0) return `<${token.name}${close}`;

  const inline = attributes
    .map((a) => (a.quote || a.value ? ` ${a.name}="${a.value}"` : ` ${a.name}`))
    .join("");

  const threshold = options.attributeWrapThreshold;
  if (threshold > 0 && attributes.length > threshold) {
    const unit = options.indent === "tab" ? "\t" : " ".repeat(options.indent);
    const attributePad = pad + unit;
    const lines = attributes.map((a) => `${attributePad}${a.name}="${a.value}"`).join("\n");
    return `<${token.name}\n${lines}\n${pad}${close.trimStart()}`;
  }

  return `<${token.name}${inline}${close}`;
}

export interface XmlFormatResult {
  formatted: string;
  elementCount: number;
  maxDepth: number;
}

/**
 * Re-indents a document from its token stream.
 *
 * An element whose only child is text is kept on one line — `<name>Ada</name>`
 * rather than three lines — because exploding every leaf is what makes
 * machine-formatted XML so much harder to read than the hand-written kind.
 */
export function formatXml(
  input: string,
  options: XmlFormatOptions = DEFAULT_XML_FORMAT
): XmlResult<XmlFormatResult> {
  const scan = tokenizeXml(input);
  if (!scan.ok) return scan;

  const tokens = scan.value;
  const unit = options.indent === "tab" ? "\t" : " ".repeat(options.indent);
  const out: string[] = [];
  const warnings: string[] = [];
  const openStack: string[] = [];
  let depth = 0;
  let maxDepth = 0;
  let elementCount = 0;

  const push = (text: string) => out.push(`${unit.repeat(depth)}${text}`);

  for (let index = 0; index < tokens.length; index++) {
    const token = tokens[index];

    switch (token.kind) {
      case "text": {
        const text = options.collapseWhitespace ? token.value!.replace(/\s+/g, " ").trim() : token.value!;
        if (text) push(text);
        break;
      }

      case "comment":
        if (!options.stripComments) push(token.raw);
        break;

      case "declaration":
      case "processing":
      case "doctype":
        push(token.raw);
        break;

      case "cdata":
        push(token.raw);
        break;

      case "selfClosing":
        elementCount++;
        push(renderTag(token, options, unit.repeat(depth)));
        break;

      case "open": {
        elementCount++;
        openStack.push(token.name!);

        // Collapse <tag>text</tag> onto one line.
        const next = tokens[index + 1];
        const afterNext = tokens[index + 2];
        if (
          next?.kind === "text" &&
          afterNext?.kind === "close" &&
          afterNext.name === token.name
        ) {
          const text = options.collapseWhitespace
            ? next.value!.replace(/\s+/g, " ").trim()
            : next.value!;
          push(`${renderTag(token, options, unit.repeat(depth))}${text}</${token.name}>`);
          openStack.pop();
          index += 2;
          break;
        }
        // An element with no children at all.
        if (next?.kind === "close" && next.name === token.name) {
          push(`${renderTag(token, options, unit.repeat(depth))}</${token.name}>`);
          openStack.pop();
          index += 1;
          break;
        }

        push(renderTag(token, options, unit.repeat(depth)));
        depth++;
        maxDepth = Math.max(maxDepth, depth);
        break;
      }

      case "close": {
        const expected = openStack.pop();
        if (expected !== token.name) {
          // Report rather than silently reshaping the tree: a formatter that
          // quietly "fixes" mismatched tags produces a document that looks
          // right and is not the one you had.
          return {
            ok: false,
            error: {
              message: expected
                ? `Mismatched closing tag </${token.name}>: expected </${expected}>`
                : `Unexpected closing tag </${token.name}> with no matching opening tag`,
              line: token.line,
              column: token.column,
            },
          };
        }
        depth = Math.max(0, depth - 1);
        push(`</${token.name}>`);
        break;
      }
    }
  }

  if (openStack.length > 0) {
    return {
      ok: false,
      error: {
        message: `Unclosed element${openStack.length > 1 ? "s" : ""}: ${openStack
          .map((n) => `<${n}>`)
          .join(", ")}`,
        line: 0,
        column: 0,
      },
    };
  }

  return {
    ok: true,
    value: { formatted: out.join("\n"), elementCount, maxDepth },
    warnings,
  };
}

/** Strips formatting whitespace between tags without touching text content. */
export function minifyXml(input: string): XmlResult<string> {
  const scan = tokenizeXml(input);
  if (!scan.ok) return scan;

  const out: string[] = [];
  for (const token of scan.value) {
    if (token.kind === "text") {
      // Whitespace *between* elements is formatting; whitespace inside a text
      // node that has real content is data.
      const trimmed = token.value!.trim();
      if (trimmed) out.push(token.value!.replace(/\s+/g, " "));
      continue;
    }
    out.push(token.raw);
  }
  return { ok: true, value: out.join(""), warnings: [] };
}
