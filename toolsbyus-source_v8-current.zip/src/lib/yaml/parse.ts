import type { JsonValue, JsonObject } from "../json/types";
import { isForbiddenKey, safeSet } from "../safe-object";
import {
  resolvePlainScalar,
  unescapeDoubleQuoted,
  unescapeSingleQuoted,
  type ResolvedScalar,
} from "./scalar";

/**
 * A YAML 1.2 parser for the block and flow constructs that appear in real
 * configuration files.
 *
 * Two limits are deliberate rather than incidental.
 *
 * The first is the alias budget. YAML aliases can reference an anchor any number
 * of times, so ten nested anchors each referencing the previous one twice expand
 * to 1,024 nodes, twenty expand to a million, and thirty exhaust the heap. This
 * is the "billion laughs" attack, and it is a denial of service against anything
 * that parses untrusted YAML — it took down production systems before parsers
 * started counting. Expansion is capped, and the cap is reported rather than
 * hidden.
 *
 * The second is depth. A block sequence can nest without any extra indentation
 * (`- - - x`), so nesting is not bounded by line width and a recursive parser can
 * be made to overflow its stack by a short input.
 */

export interface YamlError {
  message: string;
  line: number;
  column: number;
}

export interface YamlWarning {
  message: string;
  line: number;
}

export type YamlParseResult =
  | { success: true; documents: JsonValue[]; warnings: YamlWarning[] }
  | { success: false; error: YamlError };

/** Nodes materialised by alias expansion before the parser gives up. */
const ALIAS_BUDGET = 100_000;
/** Nesting levels before the parser gives up. */
const MAX_DEPTH = 400;

interface Line {
  /** Number of leading spaces. */
  indent: number;
  /** The line with indentation and any trailing comment removed. */
  text: string;
  /**
   * The line as written, indentation included and comments intact. Inside a
   * block scalar a `#` is content — a shell script or a Dockerfile is mostly
   * comments — so the stripped text cannot be used there.
   */
  raw: string;
  /** 1-based, for error messages. */
  number: number;
  /** True for a line that is blank or only a comment. */
  blank: boolean;
}

class YamlSyntaxError extends Error {
  constructor(
    message: string,
    readonly line: number,
    readonly column: number
  ) {
    super(message);
  }
}

/**
 * Strips a trailing comment, respecting quotes.
 *
 * `#` only starts a comment at the start of a line or after whitespace, so
 * `url: http://x/#frag` keeps its fragment — a detail that quietly corrupts URLs
 * in parsers that split on `#` unconditionally.
 */
function stripComment(raw: string): string {
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < raw.length; i++) {
    const char = raw[i];
    if (quote === '"') {
      if (char === "\\") i++;
      else if (char === '"') quote = null;
    } else if (quote === "'") {
      if (char === "'" && raw[i + 1] === "'") i++;
      else if (char === "'") quote = null;
    } else if (char === '"' || char === "'") {
      quote = char;
    } else if (char === "#" && (i === 0 || /\s/.test(raw[i - 1]))) {
      return raw.slice(0, i);
    }
  }
  return raw;
}

function scanLines(source: string): Line[] {
  const rows = source.replace(/\r\n?/g, "\n").split("\n");
  return rows.map((raw, index) => {
    // Tabs cannot be used for indentation in YAML. Rather than silently
    // accepting them and mis-nesting, they are rejected at the point of use.
    const indent = raw.length - raw.replace(/^[ \t]+/, "").length;
    const stripped = stripComment(raw).replace(/\s+$/, "");
    const text = stripped.slice(indent);
    return { indent, text, raw, number: index + 1, blank: text.trim() === "" };
  });
}

interface ParserState {
  lines: Line[];
  index: number;
  anchors: Map<string, JsonValue>;
  warnings: YamlWarning[];
  aliasBudget: number;
}

export function parseYaml(source: string): YamlParseResult {
  const state: ParserState = {
    lines: scanLines(source),
    index: 0,
    anchors: new Map(),
    warnings: [],
    aliasBudget: ALIAS_BUDGET,
  };

  try {
    const documents: JsonValue[] = [];

    skipBlank(state);
    // A leading %YAML or %TAG directive is accepted and ignored: honouring
    // %YAML 1.1 would mean two resolution tables, and the page says which one
    // is used rather than switching silently.
    while (current(state)?.text.startsWith("%")) {
      const line = current(state)!;
      if (/^%YAML\s+1\.1/.test(line.text)) {
        state.warnings.push({
          message:
            "%YAML 1.1 directive found. This parser applies the 1.2 core schema, so `no`, `yes`, `on` and `off` stay strings.",
          line: line.number,
        });
      }
      state.index++;
      skipBlank(state);
    }

    while (state.index < state.lines.length) {
      skipBlank(state);
      if (state.index >= state.lines.length) break;

      const line = current(state)!;
      if (line.text === "---" || line.text.startsWith("--- ")) {
        state.index++;
        const inline = line.text.slice(3).trim();
        if (inline) {
          documents.push(parseInlineDocument(state, inline, line));
          continue;
        }
      } else if (line.text === "...") {
        state.index++;
        continue;
      }

      skipBlank(state);
      if (state.index >= state.lines.length) break;
      if (current(state)!.text === "---" || current(state)!.text === "...") continue;

      documents.push(parseNode(state, current(state)!.indent, 0));
    }

    if (documents.length === 0) documents.push(null);
    return { success: true, documents, warnings: state.warnings };
  } catch (error) {
    if (error instanceof YamlSyntaxError) {
      return {
        success: false,
        error: { message: error.message, line: error.line, column: error.column },
      };
    }
    return {
      success: false,
      error: { message: (error as Error).message, line: 1, column: 1 },
    };
  }
}

function parseInlineDocument(state: ParserState, inline: string, line: Line): JsonValue {
  const { value, rest } = parseFlowOrScalar(state, inline, line);
  if (rest.trim()) {
    throw new YamlSyntaxError(`Unexpected content after value: ${rest.trim()}`, line.number, 1);
  }
  return value;
}

function current(state: ParserState): Line | undefined {
  return state.lines[state.index];
}

function skipBlank(state: ParserState): void {
  while (state.index < state.lines.length && state.lines[state.index].blank) state.index++;
}

/* -------------------------------------------------------------------------- */
/* Nodes                                                                      */
/* -------------------------------------------------------------------------- */

function guardDepth(state: ParserState, depth: number): void {
  if (depth <= MAX_DEPTH) return;
  const line = current(state);
  throw new YamlSyntaxError(
    `Nesting deeper than ${MAX_DEPTH} levels. A document this deep is either generated by accident or generated on purpose, and neither produces usable output.`,
    line?.number ?? 1,
    1
  );
}

function parseNode(state: ParserState, indent: number, depth: number): JsonValue {
  guardDepth(state, depth);

  skipBlank(state);
  const line = current(state);
  if (!line || line.indent < indent) return null;

  if (line.text.startsWith("? ")) {
    throw new YamlSyntaxError(
      "Explicit keys (`? `) are not supported. They have no JSON equivalent, because a JSON key must be a string.",
      line.number,
      1
    );
  }

  if (line.text.startsWith("- ") || line.text === "-") {
    return parseBlockSequence(state, line.indent, depth);
  }
  if (isMappingStart(line.text)) {
    return parseBlockMapping(state, line.indent, depth);
  }

  // A scalar, a flow collection, or an anchored/aliased node on one line.
  state.index++;
  const { value, rest } = parseFlowOrScalar(state, line.text, line);
  if (rest.trim()) {
    throw new YamlSyntaxError(`Unexpected content after value: ${rest.trim()}`, line.number, 1);
  }
  return value;
}

/**
 * Detects `key:` at the start of a line.
 *
 * A colon only ends a key when followed by a space or the end of the line, so
 * `time: 12:30:00` has one key and `http://x` is not a mapping. Quoted keys are
 * scanned for their closing quote first.
 */
function mappingColonAt(text: string): number {
  let quote: '"' | "'" | null = null;
  let flowDepth = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quote === '"') {
      if (char === "\\") i++;
      else if (char === '"') quote = null;
      continue;
    }
    if (quote === "'") {
      if (char === "'" && text[i + 1] === "'") i++;
      else if (char === "'") quote = null;
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }
    if (char === "[" || char === "{") flowDepth++;
    else if (char === "]" || char === "}") flowDepth--;
    else if (char === ":" && flowDepth === 0) {
      const next = text[i + 1];
      if (next === undefined || next === " ") return i;
    }
  }
  return -1;
}

function isMappingStart(text: string): boolean {
  if (text.startsWith("{") || text.startsWith("[")) return false;
  return mappingColonAt(text) !== -1;
}

function parseBlockSequence(state: ParserState, indent: number, depth: number): JsonValue[] {
  // Checked here as well as in parseNode: a compact nested sequence (`- - - x`)
  // recurses straight back into this function, so a check only at the node
  // level lets a short one-line input overflow the stack.
  guardDepth(state, depth);
  const items: JsonValue[] = [];

  for (;;) {
    skipBlank(state);
    const line = current(state);
    if (!line || line.indent !== indent) break;
    if (!line.text.startsWith("- ") && line.text !== "-") break;

    const rest = line.text === "-" ? "" : line.text.slice(2).trim();
    // The item's own content starts after the dash, so a nested block inside it
    // is indented relative to that column, not to the dash.
    const itemIndent = indent + 2;

    if (rest === "") {
      state.index++;
      skipBlank(state);
      const next = current(state);
      items.push(next && next.indent > indent ? parseNode(state, next.indent, depth + 1) : null);
      continue;
    }

    if (rest.startsWith("- ") || rest === "-") {
      // A compact nested sequence: `- - a`. The inner sequence starts at the
      // inner dash, which is why nesting here costs no indentation at all.
      const rewritten: Line = { ...line, indent: itemIndent, text: rest };
      state.lines[state.index] = rewritten;
      items.push(parseBlockSequence(state, itemIndent, depth + 1));
      continue;
    }

    if (isMappingStart(rest)) {
      // A compact mapping: `- name: x` followed by more keys at the same column.
      const rewritten: Line = { ...line, indent: itemIndent, text: rest };
      state.lines[state.index] = rewritten;
      items.push(parseBlockMapping(state, itemIndent, depth + 1));
      continue;
    }

    state.index++;
    const parsed = parseValueForKey(state, rest, line, itemIndent, depth + 1);
    items.push(parsed);
  }

  return items;
}

function parseBlockMapping(state: ParserState, indent: number, depth: number): JsonObject {
  guardDepth(state, depth);
  const map: JsonObject = {};
  const seen = new Set<string>();

  for (;;) {
    skipBlank(state);
    const line = current(state);
    if (!line || line.indent !== indent) break;
    if (line.text.startsWith("- ")) break;

    const colon = mappingColonAt(line.text);
    if (colon === -1) break;

    if (line.text.includes("\t") && /^\t/.test(line.text)) {
      throw new YamlSyntaxError(
        "Tab used for indentation. YAML forbids tabs in indentation; use spaces.",
        line.number,
        1
      );
    }

    const keyToken = line.text.slice(0, colon).trim();
    const key = readKey(keyToken, line);
    const rest = line.text.slice(colon + 1).trim();

    // A key resolves like any other scalar, which is why a GitHub Actions
    // workflow loaded by a YAML 1.1 reader has a key of boolean `true` rather
    // than `on`. This parser keeps it a string; the warning says that the same
    // file means something else elsewhere.
    if (!isQuoted(keyToken)) {
      const keyAmbiguity = resolvePlainScalar(keyToken).ambiguity;
      if (keyAmbiguity) {
        state.warnings.push({ message: `Key ${keyToken}: ${keyAmbiguity}`, line: line.number });
      }
    }

    state.index++;
    const value = parseValueForKey(state, rest, line, indent, depth + 1);

    if (seen.has(key)) {
      state.warnings.push({
        message: `Duplicate key "${key}". YAML says this is an error; the later value is kept, which is what JSON.parse does.`,
        line: line.number,
      });
    }
    seen.add(key);

    // A key called __proto__ or constructor must land as an own property, not
    // as a prototype mutation. YAML from a config file is no more trustworthy
    // than JSON from a request body.
    if (isForbiddenKey(key)) {
      safeSet(map as Record<string, unknown>, key, value);
    } else {
      map[key] = value;
    }
  }

  return map;
}

function isQuoted(token: string): boolean {
  return (
    token.length > 1 &&
    ((token.startsWith('"') && token.endsWith('"')) ||
      (token.startsWith("'") && token.endsWith("'")))
  );
}

function readKey(token: string, line: Line): string {
  if (token.startsWith("? ")) {
    throw new YamlSyntaxError(
      "Explicit keys (`? `) are not supported. They have no JSON equivalent, because a JSON key must be a string.",
      line.number,
      1
    );
  }
  if (token === "<<") {
    throw new YamlSyntaxError(
      "Merge keys (`<<`) are not supported. Expand the merge by hand, or use the anchor's value directly.",
      line.number,
      1
    );
  }
  if (token.startsWith('"') && token.endsWith('"') && token.length > 1) {
    return unescapeDoubleQuoted(token.slice(1, -1));
  }
  if (token.startsWith("'") && token.endsWith("'") && token.length > 1) {
    return unescapeSingleQuoted(token.slice(1, -1));
  }
  // A non-string key — `1: x`, `true: y` — becomes its JSON string form,
  // because JSON object keys are strings and nothing else.
  return token;
}

/**
 * Parses the value that follows `key:` or `- `, which may be on the same line,
 * on the following lines as a block, or a block scalar header.
 */
function parseValueForKey(
  state: ParserState,
  rest: string,
  line: Line,
  indent: number,
  depth: number
): JsonValue {
  const { anchor, tag, body } = readProperties(rest);

  if (body.startsWith("|") || body.startsWith(">")) {
    const value = parseBlockScalar(state, body, indent);
    if (anchor) state.anchors.set(anchor, value);
    return value;
  }

  if (body === "") {
    // The value is a block on the following lines, or nothing.
    skipBlank(state);
    const next = current(state);
    let value: JsonValue = null;
    if (next && next.indent > indent) {
      value = parseNode(state, next.indent, depth);
    } else if (next && next.indent === indent && (next.text.startsWith("- ") || next.text === "-")) {
      // A block sequence may sit at its key's own indentation. Requiring it to
      // be indented rejects a form that is both legal and extremely common —
      // it is what almost every hand-written Kubernetes manifest looks like.
      value = parseBlockSequence(state, indent, depth);
    }
    if (anchor) state.anchors.set(anchor, value);
    return value;
  }

  const { value, rest: trailing } = parseFlowOrScalar(state, body, line, tag);
  if (trailing.trim()) {
    throw new YamlSyntaxError(`Unexpected content after value: ${trailing.trim()}`, line.number, 1);
  }
  if (anchor) state.anchors.set(anchor, value);
  return value;
}

/** Reads a leading `&anchor` and/or `!tag` off a value. */
function readProperties(text: string): { anchor?: string; tag?: string; body: string } {
  let anchor: string | undefined;
  let tag: string | undefined;
  let body = text;

  for (;;) {
    const anchorMatch = /^&([^\s[\]{},]+)\s*/.exec(body);
    if (anchorMatch) {
      anchor = anchorMatch[1];
      body = body.slice(anchorMatch[0].length);
      continue;
    }
    const tagMatch = /^(!<[^>]*>|![^\s[\]{},]*)\s*/.exec(body);
    if (tagMatch) {
      tag = tagMatch[1];
      body = body.slice(tagMatch[0].length);
      continue;
    }
    break;
  }

  return { anchor, tag, body };
}

/* -------------------------------------------------------------------------- */
/* Block scalars                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Parses a `|` literal or `>` folded block scalar.
 *
 * The chomping indicator is the part people get wrong. `|` keeps exactly one
 * trailing newline, `|-` strips all of them, and `|+` keeps every one — which
 * matters when the block is a PEM key or a shell script whose last line must be
 * terminated.
 */
function parseBlockScalar(state: ParserState, header: string, parentIndent: number): string {
  const folded = header.startsWith(">");
  const chomp = header.includes("-") ? "strip" : header.includes("+") ? "keep" : "clip";
  const explicitIndent = /[1-9]/.exec(header.replace(/^[|>]/, ""));

  const raw: string[] = [];
  let blockIndent = explicitIndent ? parentIndent + Number(explicitIndent[0]) : -1;

  while (state.index < state.lines.length) {
    const line = state.lines[state.index];
    // Blankness is judged on the raw line, not the comment-stripped one:
    // comments are not recognised inside a block scalar, so `#!/bin/sh` is a
    // shebang and treating it as an empty line eats the first line of every
    // script anyone pastes.
    const isBlank = line.raw.trim() === "";

    if (!isBlank && line.indent <= parentIndent) break;

    if (blockIndent === -1 && !isBlank) {
      // The block's indentation is set by its first non-empty line.
      blockIndent = line.indent;
    }

    if (isBlank) {
      raw.push("");
    } else {
      if (line.indent < blockIndent) break;
      // Read from the original line: a `#` inside a block scalar is content,
      // not a comment, so the comment-stripped text would truncate a shell
      // script at its shebang.
      raw.push(line.raw.slice(blockIndent).replace(/\s+$/, ""));
    }
    state.index++;
  }

  // Trailing blank lines are handled by the chomping indicator, so they are
  // separated from the body first.
  let end = raw.length;
  while (end > 0 && raw[end - 1] === "") end--;
  const body = raw.slice(0, end);
  const trailingBlanks = raw.length - end;

  let text: string;
  if (folded) {
    // Folding joins consecutive non-empty lines with a space; a blank line
    // becomes a newline; a more-indented line keeps its own break.
    const parts: string[] = [];
    for (let i = 0; i < body.length; i++) {
      const lineText = body[i];
      if (lineText === "") {
        parts.push("\n");
        continue;
      }
      const previous = body[i - 1];
      const moreIndented = /^\s/.test(lineText) || /^\s/.test(previous ?? "");
      if (i > 0 && previous !== "" && !moreIndented) parts.push(" ");
      else if (i > 0 && previous !== "" && moreIndented) parts.push("\n");
      parts.push(lineText);
    }
    text = parts.join("");
  } else {
    text = body.join("\n");
  }

  if (chomp === "strip") return text;
  if (chomp === "keep") return `${text}\n${"\n".repeat(trailingBlanks)}`.replace(/\n$/, "\n");
  return body.length === 0 ? "" : `${text}\n`;
}

/* -------------------------------------------------------------------------- */
/* Flow collections and single-line scalars                                   */
/* -------------------------------------------------------------------------- */

interface FlowResult {
  value: JsonValue;
  rest: string;
}

function parseFlowOrScalar(
  state: ParserState,
  text: string,
  line: Line,
  tag?: string
): FlowResult {
  const trimmed = text.trim();

  const alias = /^\*([^\s[\]{},]+)\s*$/.exec(trimmed);
  if (alias) return { value: resolveAlias(state, alias[1], line), rest: "" };

  const { anchor, tag: innerTag, body } = readProperties(trimmed);
  const effectiveTag = tag ?? innerTag;

  if (body.startsWith("[") || body.startsWith("{")) {
    const result = parseFlow(state, body, line);
    if (anchor) state.anchors.set(anchor, result.value);
    return result;
  }

  const value = readScalar(state, body, line, effectiveTag);
  if (anchor) state.anchors.set(anchor, value);
  return { value, rest: "" };
}

function resolveAlias(state: ParserState, name: string, line: Line): JsonValue {
  if (!state.anchors.has(name)) {
    throw new YamlSyntaxError(`Alias *${name} refers to an anchor that has not been defined.`, line.number, 1);
  }
  const anchored = state.anchors.get(name)!;
  // Aliases are expanded, not shared, so the JSON output is a tree — and each
  // expansion is charged against the budget that stops the billion-laughs
  // attack turning a 200-byte file into gigabytes of objects.
  return cloneWithBudget(state, anchored, line);
}

function cloneWithBudget(state: ParserState, value: JsonValue, line: Line): JsonValue {
  if (value === null || typeof value !== "object") {
    if (--state.aliasBudget < 0) throw aliasBomb(line);
    return value;
  }

  // Iterative, so a deep anchored structure does not overflow the stack during
  // expansion after surviving the parse.
  const root: JsonValue = Array.isArray(value) ? [] : {};
  const stack: Array<{ from: JsonValue; to: JsonValue }> = [{ from: value, to: root }];

  while (stack.length > 0) {
    const { from, to } = stack.pop()!;
    if (--state.aliasBudget < 0) throw aliasBomb(line);

    if (Array.isArray(from)) {
      const target = to as JsonValue[];
      for (const item of from) {
        if (item !== null && typeof item === "object") {
          const child: JsonValue = Array.isArray(item) ? [] : {};
          target.push(child);
          stack.push({ from: item, to: child });
        } else {
          if (--state.aliasBudget < 0) throw aliasBomb(line);
          target.push(item);
        }
      }
    } else {
      const target = to as JsonObject;
      for (const [key, item] of Object.entries(from as JsonObject)) {
        if (item !== null && typeof item === "object") {
          const child: JsonValue = Array.isArray(item) ? [] : {};
          safeSet(target as Record<string, unknown>, key, child);
          stack.push({ from: item, to: child });
        } else {
          if (--state.aliasBudget < 0) throw aliasBomb(line);
          safeSet(target as Record<string, unknown>, key, item);
        }
      }
    }
  }

  return root;
}

function aliasBomb(line: Line): YamlSyntaxError {
  return new YamlSyntaxError(
    `Alias expansion exceeded ${ALIAS_BUDGET.toLocaleString("en-GB")} nodes. Nested aliases multiply, so a few lines can expand to gigabytes — the "billion laughs" attack. Expansion stopped rather than exhausting memory.`,
    line.number,
    1
  );
}

/** Parses a `[...]` or `{...}` flow collection, which may span lines. */
function parseFlow(state: ParserState, text: string, line: Line): FlowResult {
  // A flow collection can continue across lines, so the remaining lines are
  // joined until the brackets balance.
  let buffer = text;
  let depth = flowDepth(buffer);
  let scanIndex = state.index;

  while (depth > 0 && scanIndex < state.lines.length) {
    const next = state.lines[scanIndex];
    scanIndex++;
    if (next.blank) continue;
    buffer += ` ${next.text}`;
    depth = flowDepth(buffer);
  }
  state.index = scanIndex;

  if (depth !== 0) {
    throw new YamlSyntaxError("Unclosed flow collection: the brackets do not balance.", line.number, 1);
  }

  const cursor = { text: buffer, pos: 0 };
  const value = readFlowNode(state, cursor, line, 0);
  skipSpaces(cursor);
  return { value, rest: cursor.text.slice(cursor.pos) };
}

function flowDepth(text: string): number {
  let depth = 0;
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quote === '"') {
      if (char === "\\") i++;
      else if (char === '"') quote = null;
    } else if (quote === "'") {
      if (char === "'" && text[i + 1] === "'") i++;
      else if (char === "'") quote = null;
    } else if (char === '"' || char === "'") quote = char;
    else if (char === "[" || char === "{") depth++;
    else if (char === "]" || char === "}") depth--;
  }
  return depth;
}

interface Cursor {
  text: string;
  pos: number;
}

function skipSpaces(cursor: Cursor): void {
  while (cursor.pos < cursor.text.length && /\s/.test(cursor.text[cursor.pos])) cursor.pos++;
}

function readFlowNode(state: ParserState, cursor: Cursor, line: Line, depth: number): JsonValue {
  if (depth > MAX_DEPTH) {
    throw new YamlSyntaxError(`Flow collection nested deeper than ${MAX_DEPTH} levels.`, line.number, 1);
  }
  skipSpaces(cursor);
  const char = cursor.text[cursor.pos];

  if (char === "[") {
    cursor.pos++;
    const items: JsonValue[] = [];
    for (;;) {
      skipSpaces(cursor);
      if (cursor.text[cursor.pos] === "]") {
        cursor.pos++;
        break;
      }
      if (cursor.pos >= cursor.text.length) {
        throw new YamlSyntaxError("Unclosed flow sequence.", line.number, 1);
      }
      items.push(readFlowNode(state, cursor, line, depth + 1));
      skipSpaces(cursor);
      if (cursor.text[cursor.pos] === ",") cursor.pos++;
    }
    return items;
  }

  if (char === "{") {
    cursor.pos++;
    const map: JsonObject = {};
    for (;;) {
      skipSpaces(cursor);
      if (cursor.text[cursor.pos] === "}") {
        cursor.pos++;
        break;
      }
      if (cursor.pos >= cursor.text.length) {
        throw new YamlSyntaxError("Unclosed flow mapping.", line.number, 1);
      }
      const key = readFlowToken(cursor, ":,}");
      skipSpaces(cursor);
      let value: JsonValue = null;
      if (cursor.text[cursor.pos] === ":") {
        cursor.pos++;
        skipSpaces(cursor);
        if (cursor.text[cursor.pos] !== "," && cursor.text[cursor.pos] !== "}") {
          value = readFlowNode(state, cursor, line, depth + 1);
        }
      }
      const name = scalarKeyName(key);
      safeSet(map as Record<string, unknown>, name, value);
      skipSpaces(cursor);
      if (cursor.text[cursor.pos] === ",") cursor.pos++;
    }
    return map;
  }

  const token = readFlowToken(cursor, ",]}");
  const alias = /^\*([^\s[\]{},]+)$/.exec(token.trim());
  if (alias) return resolveAlias(state, alias[1], line);
  return readScalar(state, token.trim(), line);
}

/** Reads one token up to an unquoted terminator. */
function readFlowToken(cursor: Cursor, terminators: string): string {
  skipSpaces(cursor);
  const start = cursor.pos;
  let quote: '"' | "'" | null = null;

  while (cursor.pos < cursor.text.length) {
    const char = cursor.text[cursor.pos];
    if (quote === '"') {
      if (char === "\\") cursor.pos++;
      else if (char === '"') quote = null;
    } else if (quote === "'") {
      if (char === "'" && cursor.text[cursor.pos + 1] === "'") cursor.pos++;
      else if (char === "'") quote = null;
    } else if (char === '"' || char === "'") {
      quote = char;
    } else if (terminators.includes(char)) {
      break;
    }
    cursor.pos++;
  }

  return cursor.text.slice(start, cursor.pos);
}

function scalarKeyName(token: string): string {
  const trimmed = token.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') && trimmed.length > 1) {
    return unescapeDoubleQuoted(trimmed.slice(1, -1));
  }
  if (trimmed.startsWith("'") && trimmed.endsWith("'") && trimmed.length > 1) {
    return unescapeSingleQuoted(trimmed.slice(1, -1));
  }
  return trimmed;
}

function readScalar(state: ParserState, token: string, line: Line, tag?: string): JsonValue {
  if (token.startsWith('"')) {
    const end = token.lastIndexOf('"');
    if (end <= 0) throw new YamlSyntaxError("Unterminated double-quoted string.", line.number, 1);
    return unescapeDoubleQuoted(token.slice(1, end));
  }
  if (token.startsWith("'")) {
    const end = token.lastIndexOf("'");
    if (end <= 0) throw new YamlSyntaxError("Unterminated single-quoted string.", line.number, 1);
    return unescapeSingleQuoted(token.slice(1, end));
  }

  // An explicit !!str is the documented way to stop resolution, so it is
  // honoured even though other tags are only tolerated.
  if (tag === "!!str" || tag === "!str") return token;

  const resolved: ResolvedScalar = resolvePlainScalar(token);
  if (resolved.ambiguity) {
    state.warnings.push({ message: `${token}: ${resolved.ambiguity}`, line: line.number });
  }
  return resolved.value;
}
