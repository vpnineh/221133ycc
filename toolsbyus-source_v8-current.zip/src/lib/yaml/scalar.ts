import type { JsonValue } from "../json/types";

/**
 * Scalar resolution: turning an unquoted YAML token into a typed value.
 *
 * This is where YAML's reputation comes from, and almost all of it traces to one
 * decision made in YAML 1.1 and reversed in 1.2.
 *
 * YAML 1.1 resolved `y`, `yes`, `on`, `n`, `no` and `off` as booleans. So a list
 * of ISO country codes containing `NO` parsed Norway as `false` — the "Norway
 * problem", which is funny until it is your deployment config. 1.1 also read
 * `12:30` as the sexagesimal integer 750, and `0640` as octal.
 *
 * YAML 1.2 core schema, which this implements, resolves only `true` and `false`
 * as booleans, has no sexagesimal, and requires `0o` for octal. Most software in
 * the wild is still on 1.1 — PyYAML's default loader, Ruby's Psych — so the same
 * file genuinely means different things in different places. The resolution
 * table on this page says exactly which rules are applied here, because a
 * converter that silently picks one and does not say is worse than either.
 */

/** YAML 1.2 core schema, section 10.2.1.1 — null. */
const NULL_RE = /^(?:~|null|Null|NULL|)$/;
/** 10.2.1.2 — boolean. Note what is absent: yes, no, on, off, y, n. */
const BOOL_TRUE_RE = /^(?:true|True|TRUE)$/;
const BOOL_FALSE_RE = /^(?:false|False|FALSE)$/;
/** 10.2.1.3 — integer, in decimal, octal with an explicit 0o, and hex. */
const INT_DEC_RE = /^[-+]?[0-9]+$/;
const INT_OCT_RE = /^0o[0-7]+$/;
const INT_HEX_RE = /^0x[0-9a-fA-F]+$/;
/** 10.2.1.4 — float, including the infinities and NaN. */
const FLOAT_RE = /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)(?:[eE][-+]?[0-9]+)?$/;
const INF_RE = /^[-+]?\.(?:inf|Inf|INF)$/;
const NAN_RE = /^\.(?:nan|NaN|NAN)$/;

export interface ResolvedScalar {
  value: JsonValue;
  /** What the resolver decided, for the tool's type column. */
  kind: "null" | "boolean" | "integer" | "float" | "string";
  /**
   * Set when the value would resolve differently under YAML 1.1, so the tool can
   * warn. These are the cases that cause real incidents.
   */
  ambiguity?: string;
}

/** Tokens YAML 1.1 read as booleans and 1.2 does not. */
const YAML_11_BOOLEANS = new Set([
  "y", "Y", "yes", "Yes", "YES", "n", "N", "no", "No", "NO",
  "on", "On", "ON", "off", "Off", "OFF",
]);

/** `1:30` and friends: sexagesimal in 1.1, a plain string in 1.2. */
const SEXAGESIMAL_RE = /^[-+]?[0-9]+(?::[0-5]?[0-9])+$/;

/**
 * Resolves a plain (unquoted) scalar under the YAML 1.2 core schema.
 *
 * Quoted scalars never reach here: quoting is how YAML says "this is a string",
 * and honouring that is the entire fix for the Norway problem.
 */
export function resolvePlainScalar(token: string): ResolvedScalar {
  const raw = token;

  if (NULL_RE.test(raw)) return { value: null, kind: "null" };
  if (BOOL_TRUE_RE.test(raw)) return { value: true, kind: "boolean" };
  if (BOOL_FALSE_RE.test(raw)) return { value: false, kind: "boolean" };

  if (INT_DEC_RE.test(raw)) {
    const parsed = Number(raw);
    // A leading zero is significant to a human — a zip code, a phone number, a
    // part number — and insignificant to the grammar. 1.2 says this is the
    // integer 12; 1.1 says it is octal 10. Neither preserves the zero, so the
    // value is reported with the discrepancy attached rather than silently.
    const leadingZero = /^[-+]?0[0-9]/.test(raw);
    if (!Number.isSafeInteger(parsed)) {
      // Beyond 2^53 the double cannot hold the digits, and emitting a JSON
      // number that differs from the input is worse than emitting a string.
      return {
        value: raw,
        kind: "string",
        ambiguity: "Integer beyond 2^53; kept as a string so no digits are lost.",
      };
    }
    return {
      value: parsed,
      kind: "integer",
      ambiguity: leadingZero
        ? `Leading zero. YAML 1.2 reads this as ${parsed}; YAML 1.1 reads it as octal. Quote it to keep the zero.`
        : undefined,
    };
  }

  if (INT_OCT_RE.test(raw)) return { value: parseInt(raw.slice(2), 8), kind: "integer" };
  if (INT_HEX_RE.test(raw)) return { value: parseInt(raw.slice(2), 16), kind: "integer" };

  if (INF_RE.test(raw) || NAN_RE.test(raw)) {
    // JSON has no Infinity or NaN. Emitting one produces a document that
    // JSON.parse rejects, so the token is kept as a string and flagged.
    return {
      value: raw,
      kind: "string",
      ambiguity: "JSON has no Infinity or NaN, so this stays a string.",
    };
  }

  if (FLOAT_RE.test(raw)) return { value: Number(raw), kind: "float" };

  if (YAML_11_BOOLEANS.has(raw)) {
    return {
      value: raw,
      kind: "string",
      ambiguity: `YAML 1.1 reads "${raw}" as a boolean; 1.2 reads it as a string. This is the Norway problem — quote it either way.`,
    };
  }

  if (SEXAGESIMAL_RE.test(raw)) {
    return {
      value: raw,
      kind: "string",
      ambiguity: `YAML 1.1 reads "${raw}" as a sexagesimal number; 1.2 reads it as a string.`,
    };
  }

  return { value: raw, kind: "string" };
}

/* -------------------------------------------------------------------------- */
/* Quoted scalars                                                             */
/* -------------------------------------------------------------------------- */

const ESCAPES: Record<string, string> = {
  "0": "\0", a: "\x07", b: "\b", t: "\t", "\t": "\t", n: "\n", v: "\v", f: "\f",
  r: "\r", e: "\x1b", " ": " ", '"': '"', "/": "/", "\\": "\\",
  // NEL, NBSP, LINE SEPARATOR and PARAGRAPH SEPARATOR: YAML has a larger
  // escape set than JSON, and these four are the ones nothing else carries.
  N: "\u0085", _: "\u00a0", L: "\u2028", P: "\u2029",
};

/**
 * Unescapes a double-quoted scalar.
 *
 * YAML's double-quoted style has the largest escape set of any scalar style —
 * larger than JSON's — including `\x41`, `A` and `\U0001F600`, plus the
 * escaped line break that joins two lines with no space between them.
 */
export function unescapeDoubleQuoted(body: string): string {
  let out = "";
  for (let i = 0; i < body.length; i++) {
    const char = body[i];
    if (char !== "\\") {
      out += char;
      continue;
    }
    const next = body[++i];
    if (next === undefined) break;

    if (next === "x" || next === "u" || next === "U") {
      const width = next === "x" ? 2 : next === "u" ? 4 : 8;
      const hex = body.slice(i + 1, i + 1 + width);
      if (hex.length === width && /^[0-9a-fA-F]+$/.test(hex)) {
        out += String.fromCodePoint(parseInt(hex, 16));
        i += width;
        continue;
      }
      // A malformed escape is kept verbatim rather than dropped; losing a
      // character silently is worse than showing the backslash.
      out += `\\${next}`;
      continue;
    }

    if (next === "\n") {
      // An escaped line break joins the lines with nothing between them.
      while (body[i + 1] === " " || body[i + 1] === "\t") i++;
      continue;
    }

    out += ESCAPES[next] ?? `\\${next}`;
  }
  return out;
}

/** Single-quoted scalars have exactly one escape: `''` for a literal quote. */
export function unescapeSingleQuoted(body: string): string {
  return body.replace(/''/g, "'");
}

/* -------------------------------------------------------------------------- */
/* Emitting                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Decides whether a string can be written plain, or has to be quoted.
 *
 * The test is the reverse of resolution: a string must be quoted if writing it
 * bare would resolve back as something other than that string. That is what
 * makes the round trip lossless, and it is why a correct emitter quotes `no`,
 * `12:30`, `007` and `null` even though nothing about those looks like it needs
 * quoting.
 */
export function needsQuoting(value: string): boolean {
  if (value === "") return true;
  // Anything that resolves to a non-string would come back as that non-string.
  if (resolvePlainScalar(value).kind !== "string") return true;
  // 1.1 readers are still common, so a token they would type differently is
  // quoted here too: the output should mean the same thing everywhere.
  if (YAML_11_BOOLEANS.has(value) || SEXAGESIMAL_RE.test(value)) return true;
  // Indicators that change the structure if they appear unquoted.
  if (/^[-?:,[\]{}#&*!|>'"%@`]/.test(value)) return true;
  if (/: |:$| #/.test(value)) return true;
  if (/^\s|\s$/.test(value)) return true;
  // Control characters and line breaks cannot appear in a plain scalar.
  if (/[\u0000-\u001f\u007f]/.test(value)) return true;
  return false;
}

/** Writes a string as a double-quoted scalar with the minimum escaping. */
export function quoteDouble(value: string): string {
  let out = '"';
  for (const char of value) {
    const code = char.codePointAt(0)!;
    if (char === '"') out += '\\"';
    else if (char === "\\") out += "\\\\";
    else if (char === "\n") out += "\\n";
    else if (char === "\t") out += "\\t";
    else if (char === "\r") out += "\\r";
    else if (code < 0x20 || code === 0x7f) out += `\\x${code.toString(16).padStart(2, "0")}`;
    else out += char;
  }
  return `${out}"`;
}
