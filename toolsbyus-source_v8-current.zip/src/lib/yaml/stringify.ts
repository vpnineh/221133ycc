import type { JsonValue, JsonObject } from "../json/types";
import { needsQuoting, quoteDouble } from "./scalar";

/**
 * JSON to YAML.
 *
 * The one rule that matters: a string must come back as the same string. YAML
 * resolves unquoted tokens, so writing the string `"no"` bare produces a
 * document that a YAML 1.1 reader loads as `false`, and writing `"007"` bare
 * produces the number 7. The emitter therefore quotes anything that would
 * resolve to something other than itself — which is why the output has quotes in
 * places that look unnecessary until you try the round trip.
 */

export interface YamlStringifyOptions {
  /** Spaces per level. YAML forbids tabs in indentation, so this is a count. */
  indent: number;
  /** Indent block sequences under their key, as many hand-written files do. */
  indentSequences: boolean;
  /** Write strings containing newlines as `|` block scalars. */
  blockLiterals: boolean;
  /** Emit the `---` document start marker. */
  documentStart: boolean;
  /** Write empty objects and arrays as `{}` and `[]` rather than nothing. */
  explicitEmpty: boolean;
  /** Sort mapping keys alphabetically. */
  sortKeys: boolean;
}

export const YAML_DEFAULTS: YamlStringifyOptions = {
  indent: 2,
  indentSequences: false,
  blockLiterals: true,
  documentStart: false,
  explicitEmpty: true,
  sortKeys: false,
};

export function stringifyYaml(value: JsonValue, options: YamlStringifyOptions): string {
  const lines: string[] = [];
  if (options.documentStart) lines.push("---");

  if (value === null || typeof value !== "object") {
    lines.push(scalar(value, options));
    return `${lines.join("\n")}\n`;
  }

  emit(value, 0, lines, options);
  return `${lines.join("\n")}\n`;
}

function emit(
  value: JsonValue,
  level: number,
  lines: string[],
  options: YamlStringifyOptions
): void {
  const pad = " ".repeat(level * options.indent);

  if (Array.isArray(value)) {
    if (value.length === 0) {
      if (options.explicitEmpty) lines.push(`${pad}[]`);
      return;
    }
    for (const item of value) {
      if (item !== null && typeof item === "object" && !isEmptyContainer(item)) {
        // The dash and the first key share a line, which is what makes a YAML
        // list of objects readable rather than a column of lonely dashes.
        const nested: string[] = [];
        emit(item, level + 1, nested, options);
        const inner = " ".repeat((level + 1) * options.indent);
        lines.push(`${pad}- ${nested[0].slice(inner.length)}`);
        for (let i = 1; i < nested.length; i++) lines.push(nested[i]);
      } else {
        lines.push(`${pad}- ${scalar(item, options)}`);
      }
    }
    return;
  }

  const object = value as JsonObject;
  const keys = options.sortKeys ? Object.keys(object).sort() : Object.keys(object);
  if (keys.length === 0) {
    if (options.explicitEmpty) lines.push(`${pad}{}`);
    return;
  }

  for (const key of keys) {
    const child = object[key];
    const name = needsQuoting(key) ? quoteDouble(key) : key;

    if (child !== null && typeof child === "object" && !isEmptyContainer(child)) {
      lines.push(`${pad}${name}:`);
      // A block sequence may sit at the parent's indentation or one level in.
      // Both are valid YAML; files written by hand usually do the former and
      // files written by libraries usually do the latter.
      const childLevel = Array.isArray(child) && !options.indentSequences ? level : level + 1;
      emit(child, childLevel, lines, options);
      continue;
    }

    if (typeof child === "string" && options.blockLiterals && child.includes("\n")) {
      // A block literal keeps line breaks readable, which is the whole reason
      // people put certificates and scripts in YAML rather than JSON.
      const chomp = child.endsWith("\n") ? "" : "-";
      lines.push(`${pad}${name}: |${chomp}`);
      const body = child.replace(/\n$/, "").split("\n");
      const inner = " ".repeat((level + 1) * options.indent);
      for (const row of body) lines.push(row === "" ? "" : `${inner}${row}`);
      continue;
    }

    lines.push(`${pad}${name}: ${scalar(child, options)}`);
  }
}

function isEmptyContainer(value: JsonValue): boolean {
  if (Array.isArray(value)) return value.length === 0;
  if (value !== null && typeof value === "object") return Object.keys(value).length === 0;
  return false;
}

function scalar(value: JsonValue, options: YamlStringifyOptions): string {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "number") {
    // JSON cannot hold these, but a JS value reaching here might.
    if (!Number.isFinite(value)) return value > 0 ? ".inf" : Number.isNaN(value) ? ".nan" : "-.inf";
    return String(value);
  }
  if (typeof value === "string") return needsQuoting(value) ? quoteDouble(value) : value;

  // An empty container appearing where a scalar was expected.
  if (Array.isArray(value)) return options.explicitEmpty ? "[]" : "";
  return options.explicitEmpty ? "{}" : "";
}
