/**
 * Types for libheif-js's pre-bundled WebAssembly build.
 *
 * The package ships a `.d.ts` for the raw Emscripten exports — a thousand
 * `_heif_*` pointers — but nothing for the two small JavaScript classes that
 * are the actual API, and nothing at all for the `libheif-bundle.mjs` entry
 * point this site imports. Declaring the four methods used here is both smaller
 * and more honest than an `any`, which would silently swallow a rename on the
 * next upgrade.
 */
declare module "libheif-js/libheif-wasm/libheif-bundle.mjs" {
  interface HeifImage {
    get_width(): number;
    get_height(): number;
    is_primary(): boolean;
    has_alpha_channel(): boolean;
    /** Fills `target.data` with RGBA, then calls back with it, or with null. */
    display(target: ImageData, done: (result: ImageData | null) => void): void;
    /** Releases the handle in the WebAssembly heap. */
    free(): void;
  }

  interface HeifDecoder {
    /** Returns every top-level image; an empty array means the parse failed. */
    decode(bytes: Uint8Array): HeifImage[];
  }

  interface LibheifModule {
    HeifDecoder: new () => HeifDecoder;
  }

  /** Emscripten factory, pre-bound to the inlined WebAssembly binary. */
  const factory: () => LibheifModule | Promise<LibheifModule>;
  export default factory;
}
