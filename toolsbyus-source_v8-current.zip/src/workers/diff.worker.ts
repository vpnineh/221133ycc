import { parseJson } from "../lib/json/parser";
import { computeSemanticDiff } from "../lib/diff/semantic-diff";
import { DiffOptions, SemanticDiffResult } from "../lib/diff/types";
import { WORKER_MAX_BYTES } from "../lib/limits";

export interface WorkerDiffRequest {
  type: "START_DIFF";
  leftRaw: string;
  rightRaw: string;
  options: DiffOptions;
}

export type WorkerDiffResponse =
  | { type: "PROGRESS"; phase: "PARSING_LEFT" | "PARSING_RIGHT" | "COMPUTING_DIFF"; bytesProcessed: number; totalBytes: number }
  | { type: "SUCCESS"; result: SemanticDiffResult; durationMs: number }
  | { type: "LIMIT_EXCEEDED"; message: string; payloadSizeMb: number; ceilingMb: number }
  | { type: "ERROR"; message: string; line?: number; column?: number; caretSnippet?: string };

/*
 * The ceiling is imported rather than repeated.
 *
 * It was declared here *and* in `lib/limits.ts`, with the same value and no
 * link between them — two places to change and one of them silently wrong the
 * first time somebody changed the other. `limits.ts` is where every other size
 * ceiling on the site lives, so it owns this one too.
 *
 * It applies to the two documents *combined*, which is what the page copy and
 * llms.txt both say: 60 MB against 60 MB is refused even though neither side
 * exceeds 100 MB on its own.
 */
const MEMORY_CEILING_BYTES = WORKER_MAX_BYTES;

self.onmessage = (e: MessageEvent<WorkerDiffRequest>) => {
  try {
    handleDiff(e.data);
  } catch (err) {
    // Never let the worker die silently: an uncaught throw here would leave the
    // page waiting on a message that is never coming.
    self.postMessage({
      type: "ERROR",
      message: `Diff worker failed: ${(err as Error)?.message ?? String(err)}`,
    } as WorkerDiffResponse);
  }
};

function handleDiff(request: WorkerDiffRequest) {
  const { type, leftRaw, rightRaw, options } = request;
  if (type !== "START_DIFF") return;

  const startMs = Date.now();
  const leftBytes = new TextEncoder().encode(leftRaw).length;
  const rightBytes = new TextEncoder().encode(rightRaw).length;
  const totalBytes = leftBytes + rightBytes;

  // Explicit memory ceiling check
  if (totalBytes > MEMORY_CEILING_BYTES) {
    const totalMb = parseFloat((totalBytes / (1024 * 1024)).toFixed(1));
    const ceilingMb = MEMORY_CEILING_BYTES / (1024 * 1024);
    const resp: WorkerDiffResponse = {
      type: "LIMIT_EXCEEDED",
      message: `Payload size (${totalMb} MB) exceeds the in-browser safety ceiling of ${ceilingMb} MB. Processing was safely halted to prevent tab memory exhaustion.`,
      payloadSizeMb: totalMb,
      ceilingMb,
    };
    self.postMessage(resp);
    return;
  }

  // Phase 1: Parse Left
  self.postMessage({
    type: "PROGRESS",
    phase: "PARSING_LEFT",
    bytesProcessed: 0,
    totalBytes,
  } as WorkerDiffResponse);

  const parseL = parseJson(leftRaw);
  if (!parseL.success) {
    self.postMessage({
      type: "ERROR",
      message: `Left document syntax error: ${parseL.error.message}`,
      line: parseL.error.line,
      column: parseL.error.column,
      caretSnippet: parseL.error.caretSnippet,
    } as WorkerDiffResponse);
    return;
  }

  // Phase 2: Parse Right
  self.postMessage({
    type: "PROGRESS",
    phase: "PARSING_RIGHT",
    bytesProcessed: leftBytes,
    totalBytes,
  } as WorkerDiffResponse);

  const parseR = parseJson(rightRaw);
  if (!parseR.success) {
    self.postMessage({
      type: "ERROR",
      message: `Right document syntax error: ${parseR.error.message}`,
      line: parseR.error.line,
      column: parseR.error.column,
      caretSnippet: parseR.error.caretSnippet,
    } as WorkerDiffResponse);
    return;
  }

  // Phase 3: Diff
  self.postMessage({
    type: "PROGRESS",
    phase: "COMPUTING_DIFF",
    bytesProcessed: totalBytes,
    totalBytes,
  } as WorkerDiffResponse);

  const diffResult = computeSemanticDiff(parseL.data, parseR.data, options);
  const durationMs = Date.now() - startMs;

  self.postMessage({
    type: "SUCCESS",
    result: diffResult,
    durationMs,
  } as WorkerDiffResponse);
}
