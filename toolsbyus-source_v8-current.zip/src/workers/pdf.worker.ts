/**
 * Structural PDF operations, off the main thread.
 *
 * A 40 MB PDF parsed and re-serialised on the main thread freezes the tab for
 * several seconds with no way to paint a spinner — the browser cannot render
 * while JavaScript is running. So every operation happens here and reports
 * determinate progress back.
 *
 * `pdf-lib` is imported dynamically inside the handler rather than at the top of
 * the file, so the library is fetched the first time someone actually uses a PDF
 * tool and never by someone who only visits the JSON pages.
 */

export type PdfOperation =
  | { type: "merge"; files: ArrayBuffer[]; names: string[]; name?: string }
  | { type: "split"; file: ArrayBuffer; groups: number[][]; names?: string[] }
  | { type: "rotate"; file: ArrayBuffer; pages: number[]; degrees: number; name?: string }
  | { type: "reorder"; file: ArrayBuffer; order: number[]; name?: string }
  | {
      type: "watermark";
      file: ArrayBuffer;
      name?: string;
      text: string;
      opacity: number;
      fontSize: number;
      rotation: number;
      colour: [number, number, number];
    }
  | { type: "unlock"; file: ArrayBuffer; password: string; name?: string }
  | { type: "imagesToPdf"; images: Array<{ bytes: ArrayBuffer; type: string; name: string }>; pageSize: string; margin: number; fit: string; name?: string }
  | { type: "compress"; file: ArrayBuffer; name: string; stripMetadata: boolean }
  | {
      type: "rasterToPdf";
      images: Array<{ bytes: ArrayBuffer; type: string }>;
      /** Page box in PDF points, one per image, so the paper size is preserved. */
      sizes: Array<[number, number]>;
      name: string;
    }
  | { type: "inspect"; file: ArrayBuffer };

export interface PdfPageInfo {
  index: number;
  width: number;
  height: number;
  rotation: number;
}

export interface PdfInfo {
  pageCount: number;
  pages: PdfPageInfo[];
  title?: string;
  author?: string;
  producer?: string;
  encrypted: boolean;
}

export type PdfWorkerResponse =
  | { type: "PROGRESS"; done: number; total: number; label: string }
  | { type: "RESULT"; files: Array<{ bytes: ArrayBuffer; name: string }> }
  | { type: "INFO"; info: PdfInfo }
  | { type: "ERROR"; message: string };

const post = (message: PdfWorkerResponse, transfer?: Transferable[]) => {
  // Buffers are transferred rather than copied: a 40 MB result copied across
  // the boundary costs another 40 MB and a visible pause.
  (self as unknown as Worker).postMessage(message, transfer ?? []);
};

/** Standard page sizes in PDF points, which are 1/72 inch. */
const PAGE_SIZES: Record<string, [number, number]> = {
  a4: [595.28, 841.89],
  letter: [612, 792],
  legal: [612, 1008],
  a3: [841.89, 1190.55],
  a5: [419.53, 595.28],
};

self.onmessage = async (event: MessageEvent<PdfOperation>) => {
  try {
    await handle(event.data);
  } catch (error) {
    post({ type: "ERROR", message: describeError(error) });
  }
};

/**
 * Turns pdf-lib's exceptions into something a person can act on.
 *
 * The library's own messages are accurate and unhelpful: "Failed to parse PDF
 * document" tells a user nothing about whether the file is encrypted, truncated
 * or simply not a PDF.
 */
function describeError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);

  if (/encrypted/i.test(message)) {
    return "This PDF is encrypted. If you know the password, use the PDF unlocker first; if you do not, nothing here can open it — and any site that claims otherwise is either lying or uploading your file to a cracking service.";
  }
  if (/No PDF header|Invalid PDF|Failed to parse/i.test(message)) {
    return "That file is not a readable PDF. It may be truncated, or it may be something else with a .pdf extension — check that it opens in a PDF reader first.";
  }
  if (/out of memory|Array buffer allocation/i.test(message)) {
    return "The document is too large to process in this tab's memory. Try splitting it into smaller pieces first.";
  }
  return message;
}

async function handle(operation: PdfOperation): Promise<void> {
  const { PDFDocument, degrees, rgb, StandardFonts } = await import("pdf-lib");

  switch (operation.type) {
    case "inspect": {
      const document_ = await loadDocument(PDFDocument, operation.file);
      const pages = document_.getPages().map((page: PdfPage, index: number) => {
        const size = page.getSize();
        return {
          index,
          width: Math.round(size.width),
          height: Math.round(size.height),
          rotation: page.getRotation().angle,
        };
      });
      post({
        type: "INFO",
        info: {
          pageCount: pages.length,
          pages,
          title: document_.getTitle() || undefined,
          author: document_.getAuthor() || undefined,
          producer: document_.getProducer() || undefined,
          encrypted: false,
        },
      });
      return;
    }

    case "merge": {
      const merged = await PDFDocument.create();
      for (const [index, buffer] of operation.files.entries()) {
        post({
          type: "PROGRESS",
          done: index,
          total: operation.files.length,
          label: operation.names[index] ?? `file ${index + 1}`,
        });
        const source = await loadDocument(PDFDocument, buffer);
        // copyPages rewrites the object graph into the destination document's
        // numbering. Appending raw page objects instead produces a file that
        // some readers open and others reject.
        const copied = await merged.copyPages(source, source.getPageIndices());
        for (const page of copied) merged.addPage(page);
      }
      await emit(merged, operation.name ?? "merged.pdf");
      return;
    }

    case "split": {
      const source = await loadDocument(PDFDocument, operation.file);
      const results: Array<{ bytes: ArrayBuffer; name: string }> = [];

      for (const [index, group] of operation.groups.entries()) {
        post({
          type: "PROGRESS",
          done: index,
          total: operation.groups.length,
          label: `part ${index + 1}`,
        });
        const target = await PDFDocument.create();
        const copied = await target.copyPages(source, group);
        for (const page of copied) target.addPage(page);
        const bytes = await target.save();
        results.push({
          bytes: toArrayBuffer(bytes),
          name: operation.names?.[index] ?? `part-${index + 1}.pdf`,
        });
      }

      post({ type: "RESULT", files: results }, results.map((file) => file.bytes));
      return;
    }

    case "rotate": {
      const document_ = await loadDocument(PDFDocument, operation.file);
      const selected = new Set(operation.pages);
      for (const [index, page] of document_.getPages().entries()) {
        if (!selected.has(index)) continue;
        // Rotation is cumulative and normalised: a page already at 270 rotated
        // by 180 is at 90, not 450, and some readers reject the latter.
        const current = page.getRotation().angle;
        page.setRotation(degrees(((current + operation.degrees) % 360 + 360) % 360));
      }
      await emit(document_, operation.name ?? "rotated.pdf");
      return;
    }

    case "reorder": {
      // Also how pages are deleted. `removePage` takes a page out of the page
      // tree and leaves its content stream in the file as an unreferenced
      // object, recoverable by any text extractor — the same class of mistake
      // as redacting with a black rectangle. Copying the survivors into a new
      // document is the only way the removed content is genuinely absent.
      const source = await loadDocument(PDFDocument, operation.file);
      const target = await PDFDocument.create();
      const copied = await target.copyPages(source, operation.order);
      for (const page of copied) target.addPage(page);
      await emit(target, operation.name ?? "reordered.pdf");
      return;
    }

    case "watermark": {
      const document_ = await loadDocument(PDFDocument, operation.file);
      const font = await document_.embedFont(StandardFonts.HelveticaBold);
      const pages = document_.getPages();

      for (const [index, page] of pages.entries()) {
        if (index % 10 === 0) {
          post({ type: "PROGRESS", done: index, total: pages.length, label: "stamping" });
        }
        const { width, height } = page.getSize();
        const textWidth = font.widthOfTextAtSize(operation.text, operation.fontSize);
        const radians = (operation.rotation * Math.PI) / 180;

        // Centre the rotated text on the page: the draw origin is the baseline
        // start, so half the rotated extent is subtracted from the centre.
        page.drawText(operation.text, {
          x: width / 2 - (textWidth / 2) * Math.cos(radians),
          y: height / 2 - (textWidth / 2) * Math.sin(radians),
          size: operation.fontSize,
          font,
          color: rgb(...operation.colour),
          opacity: operation.opacity,
          rotate: degrees(operation.rotation),
        });
      }

      await emit(document_, operation.name ?? "watermarked.pdf");
      return;
    }

    case "unlock": {
      // pdf-lib can open an encrypted document when ignoreEncryption is set and
      // the encryption is owner-password only; a user-password document cannot
      // be read without the password, and there is no trick that changes that.
      const document_ = await PDFDocument.load(operation.file, {
        ignoreEncryption: true,
        password: operation.password,
      } as Parameters<typeof PDFDocument.load>[1]);
      // Saving produces an unencrypted copy, because pdf-lib writes no
      // encryption dictionary of its own.
      await emit(document_, operation.name ?? "unlocked.pdf");
      return;
    }

    case "imagesToPdf": {
      const document_ = await PDFDocument.create();
      const [pageWidth, pageHeight] = PAGE_SIZES[operation.pageSize] ?? PAGE_SIZES.a4;

      for (const [index, image] of operation.images.entries()) {
        post({
          type: "PROGRESS",
          done: index,
          total: operation.images.length,
          label: image.name,
        });

        const embedded = /png/i.test(image.type)
          ? await document_.embedPng(image.bytes)
          : await document_.embedJpg(image.bytes);

        if (operation.fit === "image") {
          // One page per image, sized to the image: no letterboxing, no crop.
          const page = document_.addPage([embedded.width, embedded.height]);
          page.drawImage(embedded, { x: 0, y: 0, width: embedded.width, height: embedded.height });
          continue;
        }

        const page = document_.addPage([pageWidth, pageHeight]);
        const available = {
          width: pageWidth - operation.margin * 2,
          height: pageHeight - operation.margin * 2,
        };
        // Contain rather than cover: cropping someone's photograph to fill a
        // page is a decision they did not ask for.
        const scale = Math.min(available.width / embedded.width, available.height / embedded.height);
        const width = embedded.width * scale;
        const height = embedded.height * scale;

        page.drawImage(embedded, {
          x: (pageWidth - width) / 2,
          y: (pageHeight - height) / 2,
          width,
          height,
        });
      }

      await emit(document_, operation.name ?? "images.pdf");
      return;
    }

    /**
     * Lossless rebuild.
     *
     * Nothing is re-encoded and no image is touched, so the text layer,
     * bookmarks and vector art come out exactly as they went in. The saving
     * comes from two places, both structural.
     *
     * Copying every page into a fresh document walks the object graph from the
     * page tree and brings across only what is reachable. A PDF that has been
     * edited and saved repeatedly accumulates whole previous revisions —
     * incremental saves append rather than rewrite — plus orphaned fonts and
     * images from deleted pages. None of that is reachable, so none of it is
     * copied.
     *
     * Saving with object streams then packs the small non-stream objects — the
     * dictionaries describing every page, font and annotation — into compressed
     * streams instead of writing each as plain text.
     *
     * On a file that was already written this way the saving is near zero, and
     * the tool says so rather than pretending. On a scan, it is near zero too:
     * the bytes are in the images, which this deliberately does not touch.
     */
    case "compress": {
      const source = await loadDocument(PDFDocument, operation.file);
      const rebuilt = await PDFDocument.create();

      const pageCount = source.getPageCount();
      const indices = Array.from({ length: pageCount }, (_unused, index) => index);

      post({ type: "PROGRESS", done: 0, total: pageCount, label: "reading page tree" });
      const copied = await rebuilt.copyPages(source, indices);
      for (const [index, page] of copied.entries()) {
        rebuilt.addPage(page);
        if (index % 25 === 0) {
          post({ type: "PROGRESS", done: index, total: pageCount, label: `page ${index + 1}` });
        }
      }

      if (!operation.stripMetadata) {
        // Carried over deliberately rather than by default: a rebuild starts
        // from an empty document, so keeping these is the extra step.
        const title = source.getTitle();
        const author = source.getAuthor();
        const subject = source.getSubject();
        if (title) rebuilt.setTitle(title);
        if (author) rebuilt.setAuthor(author);
        if (subject) rebuilt.setSubject(subject);
      }

      await emit(rebuilt, operation.name);
      return;
    }

    /**
     * Rebuild from rendered page images.
     *
     * The page box is passed in points rather than derived from the image, so
     * a page rendered at 150 DPI — 1240 × 1754 pixels for A4 — is placed on a
     * 595 × 842 point page and prints at its original size. Sizing the page
     * from the pixel count instead would produce a seventeen-inch-wide sheet,
     * which is the standard way this conversion goes wrong.
     */
    case "rasterToPdf": {
      const document_ = await PDFDocument.create();

      for (const [index, image] of operation.images.entries()) {
        post({
          type: "PROGRESS",
          done: index,
          total: operation.images.length,
          label: `page ${index + 1}`,
        });

        const embedded = /png/i.test(image.type)
          ? await document_.embedPng(image.bytes)
          : await document_.embedJpg(image.bytes);

        const [width, height] = operation.sizes[index] ?? [embedded.width, embedded.height];
        const page = document_.addPage([width, height]);
        page.drawImage(embedded, { x: 0, y: 0, width, height });
      }

      await emit(document_, operation.name);
      return;
    }
  }

  async function emit(document_: PdfDocument, name: string): Promise<void> {
    const bytes = await document_.save();
    const buffer = toArrayBuffer(bytes);
    post({ type: "RESULT", files: [{ bytes: buffer, name }] }, [buffer]);
  }
}

type PdfDocumentClass = (typeof import("pdf-lib"))["PDFDocument"];
type PdfPage = ReturnType<PdfDocument["getPages"]>[number];
/**
 * `InstanceType` cannot be used here: pdf-lib's PDFDocument has a private
 * constructor, so the class type does not satisfy the constructor constraint.
 * The return type of its own factory is the same thing and is public.
 */
type PdfDocument = Awaited<ReturnType<PdfDocumentClass["create"]>>;

async function loadDocument(
  PDFDocument: PdfDocumentClass,
  buffer: ArrayBuffer
): Promise<PdfDocument> {
  return PDFDocument.load(buffer, { ignoreEncryption: false });
}

/**
 * A standalone ArrayBuffer, so it can be transferred.
 *
 * `save()` returns a Uint8Array that may be a view onto a larger buffer; posting
 * `view.buffer` would transfer more than the result and, worse, detach memory
 * the library still holds.
 */
function toArrayBuffer(view: Uint8Array): ArrayBuffer {
  const copy = new ArrayBuffer(view.byteLength);
  new Uint8Array(copy).set(view);
  return copy;
}
