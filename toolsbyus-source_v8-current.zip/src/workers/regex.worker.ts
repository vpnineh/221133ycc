import { MAX_MATCHES, type MatchResult } from "../lib/regex";

/**
 * Runs a regular expression somewhere it can be killed.
 *
 * JavaScript offers no way to interrupt a regex once it starts: no timeout
 * option, no abort signal, no yield point. A pattern that backtracks
 * catastrophically will hold its thread until it finishes, which for
 * `(a+)+$` against forty characters is longer than the heat death of the tab.
 *
 * So the pattern runs here, and the page terminates this worker if it has not
 * answered in time. Termination is the only mechanism that actually works, and
 * it is why the tool is built around a worker rather than a `setTimeout`.
 */

export interface RegexWorkerRequest {
  type: "RUN";
  pattern: string;
  flags: string;
  subject: string;
}

export type RegexWorkerResponse =
  | { type: "SUCCESS"; matches: MatchResult[]; elapsedMs: number; truncated: boolean }
  | { type: "INVALID"; error: string };

self.onmessage = (event: MessageEvent<RegexWorkerRequest>) => {
  const { pattern, flags, subject } = event.data;

  let regex: RegExp;
  try {
    regex = new RegExp(pattern, flags);
  } catch (error) {
    self.postMessage({ type: "INVALID", error: (error as Error).message } as RegexWorkerResponse);
    return;
  }

  const started = Date.now();
  const matches: MatchResult[] = [];
  let truncated = false;

  try {
    if (!regex.global && !regex.sticky) {
      const found = regex.exec(subject);
      if (found) matches.push(toResult(found));
    } else {
      regex.lastIndex = 0;
      let found: RegExpExecArray | null;
      while ((found = regex.exec(subject)) !== null) {
        matches.push(toResult(found));

        // A zero-length match does not advance lastIndex, so `(?:)` or `a*`
        // against an empty run loops forever. Every correct global-match loop
        // has this nudge in it.
        if (found[0] === "") regex.lastIndex++;

        if (matches.length >= MAX_MATCHES) {
          truncated = true;
          break;
        }
      }
    }
  } catch (error) {
    self.postMessage({ type: "INVALID", error: (error as Error).message } as RegexWorkerResponse);
    return;
  }

  self.postMessage({
    type: "SUCCESS",
    matches,
    elapsedMs: Date.now() - started,
    truncated,
  } as RegexWorkerResponse);
};

function toResult(found: RegExpExecArray): MatchResult {
  return {
    index: found.index,
    match: found[0],
    groups: found.slice(1),
    named: { ...(found.groups ?? {}) },
  };
}
