import { DiffOptions, SemanticDiffResult } from "../lib/diff/types";
import { WorkerDiffRequest, WorkerDiffResponse } from "./diff.worker";
import { parseJson } from "../lib/json/parser";
import { computeSemanticDiff } from "../lib/diff/semantic-diff";

export interface DiffClientHandlers {
  onProgress?: (phase: string, bytesProcessed: number, totalBytes: number) => void;
  onSuccess: (result: SemanticDiffResult, durationMs: number) => void;
  onError: (error: { message: string; line?: number; column?: number; caretSnippet?: string }) => void;
  onLimitExceeded?: (info: { message: string; payloadSizeMb: number; ceilingMb: number }) => void;
}

/** A diff that has not reported back by now is treated as failed, not pending. */
const WORKER_TIMEOUT_MS = 120_000;

export class DiffWorkerClient {
  private worker: Worker | null = null;
  private isProcessing = false;
  /** Bumped per run so a late reply from a superseded run is ignored. */
  private runId = 0;
  private timeoutId: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    // Instantiated lazily on client-side
  }

  private initWorker() {
    if (typeof window === "undefined" || this.worker) return;
    try {
      this.worker = new Worker(new URL("./diff.worker.ts", import.meta.url), {
        type: "module",
      });
    } catch {
      // Worker failed to initialize (e.g. strict CSP or SSR), fallback available
      this.worker = null;
    }
  }

  private clearTimer() {
    if (this.timeoutId !== null) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
  }

  /** Run the diff on the main thread. Used when no worker is available. */
  private runInline(
    leftRaw: string,
    rightRaw: string,
    options: DiffOptions,
    handlers: DiffClientHandlers
  ) {
    setTimeout(() => {
      try {
        const parseL = parseJson(leftRaw);
        if (!parseL.success) {
          handlers.onError({
            message: `Left document syntax error: ${parseL.error.message}`,
            line: parseL.error.line,
            column: parseL.error.column,
            caretSnippet: parseL.error.caretSnippet,
          });
          return;
        }

        const parseR = parseJson(rightRaw);
        if (!parseR.success) {
          handlers.onError({
            message: `Right document syntax error: ${parseR.error.message}`,
            line: parseR.error.line,
            column: parseR.error.column,
            caretSnippet: parseR.error.caretSnippet,
          });
          return;
        }

        const t0 = Date.now();
        const result = computeSemanticDiff(parseL.data, parseR.data, options);
        handlers.onSuccess(result, Date.now() - t0);
      } catch (err) {
        handlers.onError({ message: (err as Error)?.message || "Diff calculation error" });
      }
    }, 0);
  }

  public runDiff(
    leftRaw: string,
    rightRaw: string,
    options: DiffOptions,
    handlers: DiffClientHandlers
  ) {
    this.initWorker();

    // A newer run supersedes any in-flight one; stale replies are dropped below.
    const currentRun = ++this.runId;
    this.clearTimer();

    if (!this.worker) {
      this.runInline(leftRaw, rightRaw, options, handlers);
      return;
    }

    const isStale = () => currentRun !== this.runId;

    const settle = () => {
      this.isProcessing = false;
      this.clearTimer();
    };

    this.worker.onmessage = (e: MessageEvent<WorkerDiffResponse>) => {
      if (isStale()) return;
      const data = e.data;
      if (data.type === "PROGRESS") {
        handlers.onProgress?.(data.phase, data.bytesProcessed, data.totalBytes);
      } else if (data.type === "SUCCESS") {
        settle();
        handlers.onSuccess(data.result, data.durationMs);
      } else if (data.type === "LIMIT_EXCEEDED") {
        settle();
        handlers.onLimitExceeded?.({
          message: data.message,
          payloadSizeMb: data.payloadSizeMb,
          ceilingMb: data.ceilingMb,
        });
      } else if (data.type === "ERROR") {
        settle();
        handlers.onError({
          message: data.message,
          line: data.line,
          column: data.column,
          caretSnippet: data.caretSnippet,
        });
      }
    };

    // A module worker blocked by CSP, or one that dies mid-run (out of memory),
    // fails asynchronously — the constructor's try/catch never sees it. Without
    // these the UI would sit on "processing" forever.
    this.worker.onerror = (event: ErrorEvent) => {
      if (isStale()) return;
      event.preventDefault?.();
      settle();
      // Retry on the main thread so a blocked worker degrades instead of failing.
      this.worker?.terminate();
      this.worker = null;
      this.runInline(leftRaw, rightRaw, options, handlers);
    };

    this.worker.onmessageerror = () => {
      if (isStale()) return;
      settle();
      handlers.onError({
        message: "The diff worker returned a result that could not be deserialized.",
      });
    };

    this.timeoutId = setTimeout(() => {
      if (isStale()) return;
      settle();
      this.worker?.terminate();
      this.worker = null;
      handlers.onError({
        message: `Diff timed out after ${Math.round(
          WORKER_TIMEOUT_MS / 1000
        )}s and was cancelled. Try smaller documents, or switch array matching to "index".`,
      });
    }, WORKER_TIMEOUT_MS);

    const req: WorkerDiffRequest = {
      type: "START_DIFF",
      leftRaw,
      rightRaw,
      options,
    };

    this.isProcessing = true;
    this.worker.postMessage(req);
  }

  /** True while a diff is in flight. */
  public get busy(): boolean {
    return this.isProcessing;
  }

  public terminate() {
    this.clearTimer();
    this.runId++;
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    this.isProcessing = false;
  }
}
