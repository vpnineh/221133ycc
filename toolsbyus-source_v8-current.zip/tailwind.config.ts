import type { Config } from "tailwindcss";
import plugin from "tailwindcss/plugin";

/**
 * Every colour resolves to a CSS variable defined for both themes in
 * globals.css. Nothing here is a literal hex, so a theme is a token swap rather
 * than a second set of `dark:` classes to keep in sync — which is how borders
 * and muted labels quietly go invisible in one mode.
 */
const config: Config = {
  darkMode: "class",
  /**
   * Utilities this design system does not use, blocked at the source.
   *
   * Tailwind's extractor is a regex over source files, not a parser, so any
   * string that looks like a class name generates one. The CSS formatter's
   * sample payload contains `@supports (backdrop-filter: blur(2px))` — a
   * realistic thing to format — and that alone shipped the `.backdrop-filter`
   * utility to every visitor. The site bans backdrop-filter outright for
   * compositor cost, and an end-to-end test greps the built stylesheet for it,
   * so a demo string was failing a real guardrail for a real reason.
   */
  blocklist: ["backdrop-filter"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        // Both variables are injected by next/font in the root layout: Geist on
        // --font-sans, Geist Mono on --font-mono. The names after each variable
        // are what renders during the swap and if the webfont never arrives.
        sans: [
          "var(--font-sans)",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "sans-serif",
        ],
        mono: [
          "var(--font-mono)",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Consolas",
          "Liberation Mono",
          "monospace",
        ],
      },
      colors: {
        background: {
          DEFAULT: "var(--bg)",
          subtle: "var(--bg-subtle)",
        },
        scrim: "var(--scrim)",
        foreground: {
          DEFAULT: "var(--text)",
          muted: "var(--text-muted)",
          subtle: "var(--text-subtle)",
        },
        surface: {
          DEFAULT: "var(--surface)",
          elevated: "var(--surface-2)",
        },
        border: {
          DEFAULT: "var(--border)",
          strong: "var(--border-strong)",
        },
        // Text/icon/border accent — theme-aware so it clears 4.5:1 in both.
        accent: {
          DEFAULT: "var(--accent)",
          hover: "var(--accent-hover)",
          soft: "var(--accent-soft)",
          line: "var(--accent-line)",
          // Fill + its foreground. Kept apart from the text accent because a
          // colour readable *as* text is rarely the right colour to fill with.
          solid: "var(--accent-solid)",
          on: "var(--on-accent)",
        },
        danger: {
          DEFAULT: "var(--danger)",
          soft: "var(--danger-soft)",
        },
        warn: {
          DEFAULT: "var(--warn)",
          soft: "var(--warn-soft)",
        },
        add: {
          DEFAULT: "var(--add)",
          soft: "var(--add-soft)",
        },
        del: {
          DEFAULT: "var(--del)",
          soft: "var(--del-soft)",
        },
        mod: {
          DEFAULT: "var(--mod)",
          soft: "var(--mod-soft)",
        },
        move: {
          DEFAULT: "var(--move)",
          soft: "var(--move-soft)",
        },
        type: {
          DEFAULT: "var(--type)",
          soft: "var(--type-soft)",
        },
      },
      borderRadius: {
        sm: "var(--radius-sm)",
        DEFAULT: "var(--radius)",
        md: "var(--radius)",
        lg: "var(--radius-lg)",
        xl: "var(--radius-xl)",
        pill: "var(--radius-pill)",
      },
      boxShadow: {
        // One shadow, and only for a layer that genuinely floats above the
        // page: a menu, the command palette. Everything else is separated by a
        // step in surface tone, which is cheaper to paint and does not leave a
        // grey halo under every card — the look this design deliberately drops.
        pop: "0 12px 32px -12px rgba(0, 0, 0, 0.28), 0 2px 6px -2px rgba(0, 0, 0, 0.12)",
      },
      transitionDuration: {
        DEFAULT: "150ms",
      },
      fontSize: {
        // A dense 8-step scale. The previous build mixed 10px, 11px, 12px and
        // 13px arbitrarily; these are the only sizes the UI now uses.
        "2xs": ["0.6875rem", { lineHeight: "1rem" }],
      },
    },
  },
  plugins: [
    // Target the input device rather than the viewport. Screen width is a poor
    // proxy for "finger": a 26px control is fine under a mouse and awkward
    // under a thumb, on a phone or a touchscreen laptop alike.
    plugin(({ addVariant }) => {
      addVariant("pointer-coarse", "@media (pointer: coarse)");
      addVariant("pointer-fine", "@media (pointer: fine)");
    }),
  ],
};

export default config;
