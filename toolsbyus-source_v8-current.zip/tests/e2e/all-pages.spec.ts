import { test, expect } from "./fixtures";
import {
  activeCategories,
  publishedTools,
  INFO_PAGES,
} from "../../src/lib/tools.data.mjs";

/**
 * Every route the catalogue claims exists, checked against the real export.
 *
 * The list used to be typed out here, which meant a new tool was only covered
 * if somebody remembered to add it — exactly the duplication the catalogue
 * refactor removed everywhere else. Deriving it means a tool added with
 * `published: true` is smoke-tested the moment it lands, and a tool whose page
 * is missing fails here rather than as a 404 in the sitemap.
 */
const ROUTES: Array<{ path: string; h1?: string; titlePattern: RegExp }> = [
  { path: "/", titlePattern: /ToolsByUs/i },
  ...activeCategories().map((category) => ({
    path: category.hub,
    h1: category.title,
    titlePattern: new RegExp(category.title.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"),
  })),
  ...publishedTools().map((tool) => ({
    path: tool.href,
    h1: tool.title,
    titlePattern: new RegExp(tool.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"),
  })),
  ...INFO_PAGES.map((page) => ({
    path: page.href,
    titlePattern: new RegExp(page.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"),
  })),
];

test.describe("Every catalogue route renders", () => {
  for (const route of ROUTES) {
    test(`${route.path} has a 200, a title, one H1 and valid JSON-LD`, async ({ page }) => {
      const response = await page.goto(route.path);
      expect(response?.status()).toBe(200);

      await expect(page).toHaveTitle(route.titlePattern);

      // Exactly one H1: more than one is an outline defect that search engines
      // and screen readers both have to guess their way through.
      const h1 = page.locator("h1");
      await expect(h1).toHaveCount(1);
      await expect(h1).toBeVisible();
      if (route.h1) await expect(h1).toHaveText(route.h1);

      const jsonLd = page.locator('script[type="application/ld+json"]');
      expect(await jsonLd.count()).toBeGreaterThan(0);
      const text = await jsonLd.first().textContent();
      expect(text).toBeTruthy();
      expect(() => JSON.parse(text!)).not.toThrow();
    });
  }

  test("the catalogue and the sitemap agree with what is actually served", async ({ request }) => {
    const xml = await (await request.get("/sitemap.xml")).text();
    const paths = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map(
      (m) => new URL(m[1]).pathname.replace(/\/$/, "") || "/"
    );

    expect(paths.length).toBe(ROUTES.length);

    // Every advertised URL must actually resolve. A sitemap listing a 404 is
    // worse than no sitemap on a new domain: it spends crawl budget proving the
    // site is unreliable.
    for (const path of paths) {
      const response = await request.get(path);
      expect(response.status(), `${path} is in the sitemap but returns ${response.status()}`).toBe(
        200
      );
    }
  });
});

/**
 * SERP metadata, checked at the length a search engine actually renders.
 *
 * These are the two defects that do not show up anywhere else in this suite:
 * a title is perfectly valid at 21 characters and perfectly useless against ten
 * competitors with the same words in it, and a 205-character description is
 * valid too — Google simply cuts it mid-sentence and picks its own snippet.
 * Both are invisible to a typecheck, a unit test and a human reading the page.
 */
test.describe("SERP metadata stays within useful bounds", () => {
  // Google renders roughly 580px, which is about 60 characters at the width of
  // typical title text. The lower bound is not a rule anyone publishes — it is
  // the point below which a title is just the tool's name and carries no reason
  // to click it rather than the result above.
  const TITLE_MIN = 38;
  const TITLE_MAX = 62;
  const DESCRIPTION_MAX = 165;

  for (const route of ROUTES) {
    test(`${route.path} has a title and description of usable length`, async ({ page }) => {
      await page.goto(route.path);

      const title = await page.title();
      expect(title.length, `title is ${title.length} chars: "${title}"`).toBeGreaterThanOrEqual(
        TITLE_MIN
      );
      expect(title.length, `title is ${title.length} chars: "${title}"`).toBeLessThanOrEqual(
        TITLE_MAX
      );

      const description = await page
        .locator('meta[name="description"]')
        .getAttribute("content");
      expect(description, `${route.path} has no meta description`).toBeTruthy();
      expect(
        description!.length,
        `description is ${description!.length} chars on ${route.path}`
      ).toBeLessThanOrEqual(DESCRIPTION_MAX);
      expect(description!.length).toBeGreaterThan(70);
    });
  }

  test("no two pages share a title", async ({ request }) => {
    const titles = new Map<string, string[]>();
    for (const route of ROUTES) {
      const html = await (await request.get(route.path)).text();
      const title = /<title>([^<]*)<\/title>/.exec(html)?.[1] ?? "";
      titles.set(title, [...(titles.get(title) ?? []), route.path]);
    }
    const duplicates = [...titles.entries()].filter(([, paths]) => paths.length > 1);
    expect(duplicates, `duplicate titles: ${JSON.stringify(duplicates)}`).toEqual([]);
  });
});

/**
 * The freshness date a machine reads must match the one the catalogue holds.
 *
 * This is the defect that prompted the test. `ToolShell` defaulted its review
 * date to a hard-coded constant, and ten pages never passed the prop — so the
 * flagship page's JSON-LD advertised `dateModified: 2026-09-09` while its
 * catalogue entry, the sitemap and the visible stamp all said the 11th. A
 * source that contradicts itself about its own freshness is exactly what an AI
 * engine is looking for when it decides how much to trust a citation.
 */
test.describe("dateModified and lastmod come from the catalogue", () => {
  for (const tool of publishedTools()) {
    test(`${tool.href} reports its catalogue review date`, async ({ page, request }) => {
      await page.goto(tool.href);

      // Three pages predate ToolShell and emit an array of separate JSON-LD
      // blocks rather than one @graph, so both shapes have to be flattened —
      // otherwise the test reports "no dateModified" for a page that has one.
      const graphs = await page.locator('script[type="application/ld+json"]').allTextContents();
      const dates = graphs
        .flatMap((text) => {
          const parsed = JSON.parse(text);
          const nodes = Array.isArray(parsed) ? parsed : (parsed["@graph"] ?? [parsed]);
          return nodes as Array<{ dateModified?: string }>;
        })
        .map((node) => node.dateModified)
        .filter(Boolean);

      expect(dates.length, `${tool.href} emits no dateModified`).toBeGreaterThan(0);
      for (const date of dates) {
        expect(date, `${tool.href} JSON-LD says ${date}, catalogue says ${tool.lastReviewed}`).toBe(
          tool.lastReviewed
        );
      }

      // And the visible stamp agrees with the machine-readable one.
      await expect(page.locator(`time[datetime="${tool.lastReviewed}"]`).first()).toBeVisible();

      // As does the sitemap, which used to carry the build date on every URL.
      const xml = await (await request.get("/sitemap.xml")).text();
      const entry = new RegExp(
        `<loc>[^<]*${tool.href}</loc>\\s*<lastmod>([^<]+)</lastmod>`
      ).exec(xml);
      expect(entry?.[1], `${tool.href} sitemap lastmod`).toBe(tool.lastReviewed);
    });
  }
});
