import { test, expect, type Page } from "./fixtures";

/**
 * Functional smoke tests for the converters and generators.
 *
 * The all-pages suite proves each route serves a 200 with a title and valid
 * JSON-LD. That is not the same as the tool working: a client component that
 * throws on mount still renders its server HTML, so a page can be green in that
 * suite and useless in a browser. These tests type into each tool and assert on
 * what comes out.
 */

/** Replaces the first editor's content and waits for the derived pane. */
async function typeInto(page: Page, text: string): Promise<void> {
  const input = page.locator("textarea").first();
  await input.fill(text);
}

/** The read-only output editor is the second textarea on every converter. */
async function outputOf(page: Page): Promise<string> {
  const output = page.locator("textarea").nth(1);
  // Two different things can leave this empty, and only one of them is time.
  //
  // The generation is debounced, so a bare read can land before the first run.
  // That is what the poll is for. But `fill()` can also land *before React has
  // hydrated*, and then the value sits in the DOM while React's own state stays
  // empty — no debounce will ever fire and no timeout is long enough. Raising
  // the budget only made that failure slower.
  //
  // So: give it four seconds, and if nothing has appeared, type it again. By
  // then the page is certainly hydrated and the second fill reaches React. A
  // test that fails on the schedule rather than on the behaviour is worse than
  // no test.
  const settled = await output
    .inputValue()
    .then((value) =>
      value
        ? true
        : expect
            .poll(() => output.inputValue(), { timeout: 4_000 })
            .not.toBe("")
            .then(() => true)
            .catch(() => false)
    );

  if (!settled) {
    const input = page.locator("textarea").first();
    await input.fill(await input.inputValue());
    await expect.poll(() => output.inputValue(), { timeout: 10_000 }).not.toBe("");
  }

  return output.inputValue();
}

/**
 * The tool itself, excluding the prose below it.
 *
 * Necessary rather than tidy: the explanatory copy on these pages discusses the
 * same strings the tool emits — "Mismatched tags", "verified" — so an unscoped
 * text query matches the article as well as the result and fails on strict mode.
 */
function toolRegion(page: Page, keyword: string) {
  return page.getByRole("region", { name: `${keyword} tool` });
}

test.describe("Code generators", () => {
  const cases = [
    { path: "/json-to-typescript", expect: [/interface Root/, /name: string;/, /age\?: number;/] },
    { path: "/json-to-go", expect: [/type Root struct/, /`json:"name"`/, /\*int/] },
    { path: "/json-to-python", expect: [/@dataclass/, /class Root:/, /name: str/] },
    { path: "/json-to-csharp", expect: [/public class Root/, /JsonPropertyName\("name"\)/, /int\? Age/] },
    { path: "/json-to-java", expect: [/public record Root/, /@JsonProperty\("name"\)/, /Integer age/] },
  ];

  for (const testCase of cases) {
    test(`${testCase.path} generates code with optionality inferred across records`, async ({
      page,
    }) => {
      await page.goto(testCase.path);
      // Two records, one of which lacks `age`: the field must come out optional.
      await typeInto(page, '[{"name":"Ada"},{"name":"Grace","age":45}]');

      const output = await outputOf(page);
      for (const pattern of testCase.expect) expect(output).toMatch(pattern);
    });
  }

  test("the root type name is editable and reaches the output", async ({ page }) => {
    await page.goto("/json-to-typescript");
    await page.getByLabel("Root type").fill("Payload");
    expect(await outputOf(page)).toMatch(/interface Payload/);
  });
});

test.describe("YAML converters", () => {
  test("YAML to JSON keeps Norway a country and flags the ambiguity", async ({ page }) => {
    await page.goto("/yaml-to-json");
    await typeInto(page, "codes:\n  - NO\n  - SE\n");

    expect(JSON.parse(await outputOf(page))).toEqual({ codes: ["NO", "SE"] });
    await expect(page.getByText(/1\.1 reads "NO" as a boolean/)).toBeVisible();
  });

  test("YAML to JSON reports a syntax error with its line", async ({ page }) => {
    await page.goto("/yaml-to-json");
    await typeInto(page, "a: *missing\n");
    await expect(page.getByText(/has not been defined/)).toBeVisible();
  });

  test("JSON to YAML quotes what would otherwise resolve, and verifies the trip", async ({
    page,
  }) => {
    await page.goto("/json-to-yaml");
    await typeInto(page, '{"a":"no","b":"007","c":"hello"}');

    const output = await outputOf(page);
    expect(output).toContain('a: "no"');
    expect(output).toContain('b: "007"');
    expect(output).toContain("c: hello");
    // The tool checks its own claim on the user's document and reports it.
    await expect(toolRegion(page, "JSON to YAML").getByText("verified")).toBeVisible();
  });
});

test.describe("XML converters", () => {
  test("XML to JSON prefixes attributes and honours the force-array list", async ({ page }) => {
    await page.goto("/xml-to-json");
    await page.getByLabel("Force array").fill("");
    await typeInto(page, '<order id="1"><line sku="A">Widget</line></order>');

    // One <line> with nothing forced: a scalar, which is the trap.
    const single = JSON.parse(await outputOf(page));
    expect(single).toEqual({
      order: { "@id": "1", line: { "@sku": "A", "#text": "Widget" } },
    });

    await page.getByLabel("Force array").fill("line");
    const forced = JSON.parse(await outputOf(page));
    expect(Array.isArray((forced.order as Record<string, unknown>).line)).toBe(true);
  });

  test("XML to JSON rejects mismatched tags rather than guessing", async ({ page }) => {
    await page.goto("/xml-to-json");
    await typeInto(page, "<a><b></a>");
    await expect(toolRegion(page, "XML to JSON").getByText(/Mismatched tags/)).toBeVisible();
  });

  test("JSON to XML writes attributes and repeats array element names", async ({ page }) => {
    await page.goto("/json-to-xml");
    await typeInto(page, '{"@id":"1","line":["a","b"]}');

    const output = await outputOf(page);
    expect(output).toContain('id="1"');
    expect(output).toContain("<line>a</line>");
    expect(output).toContain("<line>b</line>");
  });

  test("JSON to XML reports a key it had to repair", async ({ page }) => {
    await page.goto("/json-to-xml");
    await typeInto(page, '{"2024 total":1}');

    await expect(page.getByText(/could not be used as an XML element name/)).toBeVisible();
    expect(await outputOf(page)).toContain('name="2024 total"');
  });

  test("the XML viewer renders a tree and counts the document", async ({ page }) => {
    await page.goto("/xml-viewer");
    await expect(page.getByRole("tree")).toBeVisible();
    await expect(page.getByText(/\d+ elements · \d+ attributes · depth \d+/)).toBeVisible();
  });
});

test.describe("JSON Pretty Print", () => {
  test("indents a minified document and follows the indent setting", async ({ page }) => {
    await page.goto("/json-pretty-print");
    const region = page.getByRole("region", { name: "JSON Pretty Print tool" });

    const input = region.locator("textarea").first();
    await input.fill('{"a":1,"b":[2,3]}');

    const output = region.locator("textarea").nth(1);
    await expect(output).toHaveValue('{\n  "a": 1,\n  "b": [\n    2,\n    3\n  ]\n}');

    await region.getByRole("group", { name: "Indent" }).getByText("Tab").click();
    await expect(output).toHaveValue(/\n\t"a": 1/);
  });

  test("sorting keys is off until asked for", async ({ page }) => {
    await page.goto("/json-pretty-print");
    const region = page.getByRole("region", { name: "JSON Pretty Print tool" });

    await region.locator("textarea").first().fill('{"z":1,"a":2}');
    const output = region.locator("textarea").nth(1);
    await expect(output).toHaveValue(/"z": 1[\s\S]*"a": 2/);

    await region.getByLabel("Sort keys").check();
    await expect(output).toHaveValue(/"a": 2[\s\S]*"z": 1/);
  });

  test("shows the recipe and the gotcha for the chosen language", async ({ page }) => {
    await page.goto("/json-pretty-print");
    const region = page.getByRole("region", { name: "JSON Pretty Print tool" });

    // JavaScript is the default, and its warning is about the argument order.
    await expect(region.getByText(/second argument is the replacer/)).toBeVisible();

    await region.getByRole("group", { name: "Language" }).getByText("PowerShell").click();
    await expect(region.getByText(/-Depth 2 and silently truncates/)).toBeVisible();

    const recipe = region.locator("textarea").last();
    await expect(recipe).toHaveValue(/ConvertTo-Json -Depth 100/);
  });

  test("names the line and column when the document does not parse", async ({ page }) => {
    await page.goto("/json-pretty-print");
    const region = page.getByRole("region", { name: "JSON Pretty Print tool" });

    await region.locator("textarea").first().fill('{"a": 1,}');
    await expect(region.getByText(/line 1/i).first()).toBeVisible();
  });
});
