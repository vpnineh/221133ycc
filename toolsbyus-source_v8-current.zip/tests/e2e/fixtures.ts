import { test as base, expect, type Page } from "@playwright/test";

/**
 * A `page` fixture that refuses to interact with an un-hydrated React root.
 *
 * The export ships complete static HTML, so the element a test wants exists the
 * instant `goto` resolves — but React attaches its root event listeners only at
 * hydration. A native `fill()` or `click()` that lands before that moment is
 * silently swallowed: the DOM shows the new value while the component's state
 * still holds the default document, and the tool then faithfully computes the
 * wrong thing. That produced the last intermittent batch of failures — only
 * under CI-like load, and only in the first test to touch each page.
 *
 * Wrapping `goto` (rather than remembering a wait in every test) makes the wait
 * unconditional: any spec — including ones not written yet — gets it for free.
 * React stamps the elements it renders with a `__reactFiber$…` own property,
 * which is the cheapest reliable signal that the root is live.
 *
 * Checking ONE element is not enough, and the mistake is not hypothetical: the
 * header search box hydrates with the app shell while a tool's own subtree can
 * still be waiting on its page chunk. A probe on the shell passes ~100ms after
 * `goto`, the test fills the tool's textarea, and React later claims that
 * server-rendered node with its own state — the typed text is gone and the
 * output shows the default document. So the gate is *every* interactive element
 * in the server HTML carrying a fiber stamp: hydration is a single pass per
 * subtree, and a fully stamped page has no node left for React to reset.
 *
 * The wait swallows its own timeout rather than failing the test: a page with
 * no React root at all must still be navigable (an empty NodeList is vacuously
 * complete), and a genuinely broken hydration surfaces as the assertion failure
 * the test was written to produce, not as a fixture error.
 */
async function waitForReactRoot(page: Page): Promise<void> {
  const t0 = Date.now();
  await page
    .waitForFunction(
      () => {
        const els = Array.from(
          document.querySelectorAll("textarea, input, select, button")
        );
        return els.every((el) =>
          Object.keys(el).some((k) => k.startsWith("__reactFiber"))
        );
      },
      undefined,
      { timeout: 20000 }
    )
    .catch(() => {
      // No React root on this page, or hydration genuinely broken: let the
      // test's own assertions decide, exactly as they would have before.
    });
  if (process.env.DEBUG_HYDRATION) {
    console.log(`[hydration] ${page.url()} waited ${Date.now() - t0}ms`);
  }
}

export const test = base.extend({
  page: async ({ page }, use) => {
    const originalGoto = page.goto.bind(page);
    page.goto = async (...args: Parameters<Page["goto"]>) => {
      const response = await originalGoto(...args);
      await waitForReactRoot(page);
      return response;
    };
    await use(page);
  },
});

export { expect };
export type { Page } from "@playwright/test";
