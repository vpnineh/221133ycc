import { test, expect, type Page } from "./fixtures";

/**
 * End-to-end coverage for defects found in the pre-launch audit. Each of these
 * only reproduces against the real static export served with its production
 * headers, which is why they live here rather than in the unit suite.
 */

const TOOL_ROUTES = [
  "/",
  "/json-diff",
  "/diff-checker",
  "/json-formatter",
  "/json-beautifier",
  "/json-minifier",
  "/json-validator",
  "/json-schema-generator",
  "/json-editor",
  "/base64-decode",
  "/uuid-generator",
  "/about",
  "/privacy",
  "/terms",
];

/** Collect console errors, uncaught exceptions and CSP refusals for a page. */
function watchForErrors(page: Page): string[] {
  const problems: string[] = [];
  page.on("console", (message) => {
    const text = message.text();
    if (message.type() === "error" && !/favicon/i.test(text)) problems.push(text);
    else if (/Content Security Policy|Refused to/i.test(text)) problems.push(text);
  });
  page.on("pageerror", (error) => problems.push(`Uncaught: ${error.message}`));
  return problems;
}

/**
 * Wait until React actually owns the DOM.
 *
 * The export ships full static HTML, so a textarea or a header button exists
 * the instant `goto` resolves — but React attaches its root event listeners at
 * hydration, and a native fill or click that lands before that moment is
 * silently dropped: the element shows the new value while the app's state
 * never changes, and the test then waits for a panel that will never render.
 * That was the last intermittent failure in this suite, and only under load —
 * the exact conditions CI runs in. React stamps every element it renders with
 * a `__reactFiber$…` own property, which is the cheapest reliable signal that
 * listeners are live; waiting for it costs nothing when hydration is already
 * done and removes the race when it is not.
 */
async function waitForHydration(page: Page, selector: string): Promise<void> {
  await page.waitForFunction(
    (sel) => {
      const el = document.querySelector(sel);
      return !!el && Object.keys(el).some((k) => k.startsWith("__reactFiber"));
    },
    selector,
    { timeout: 15000 }
  );
}

test.describe("Content-Security-Policy", () => {
  test("every page loads and hydrates with no CSP violation or console error", async ({ page }) => {
    for (const route of TOOL_ROUTES) {
      const problems = watchForErrors(page);
      await page.goto(route, { waitUntil: "networkidle" });
      expect(problems, `${route} reported: ${problems.join(" | ")}`).toEqual([]);
    }
  });

  test("the policy is served and does not fall back to unsafe-inline", async ({ request }) => {
    const response = await request.get("/json-diff");
    const csp = response.headers()["content-security-policy"];

    expect(csp, "Content-Security-Policy header is missing").toBeTruthy();
    // A hash allowlist is only meaningful while script-src omits unsafe-inline.
    // style-src keeps it deliberately: Next injects inline <style> on export,
    // and style injection is not a script-execution vector.
    const scriptSrc = csp.split(";").find((d) => d.trim().startsWith("script-src")) ?? "";
    expect(scriptSrc).not.toContain("'unsafe-inline'");
    expect(scriptSrc).toMatch(/'sha256-/);
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("object-src 'none'");
    // The privacy guarantee: the browser itself blocks outbound requests.
    expect(csp).toContain("connect-src 'self'");
  });

  test("the CSP is scoped per page and stays under undici's 16 KB header limit", async ({ request }) => {
    // The first policy hashed every inline script across the whole export into
    // one global header. At 625 hashes it measured 34 KB on the wire — past the
    // 16 KB single-header limit undici (Node's fetch, Playwright's health check,
    // most uptime monitors) enforces, so this suite could not even start its own
    // server. Each page now carries only its own hashes; if a single global blob
    // ever comes back, the request below fails outright and these assertions
    // name the cause.
    const home = (await request.get("/")).headers()["content-security-policy"] ?? "";
    const diff = (await request.get("/json-diff")).headers()["content-security-policy"] ?? "";

    expect(home.length, "homepage served no CSP").toBeGreaterThan(0);
    expect(diff.length, "json-diff served no CSP").toBeGreaterThan(0);
    expect(home.length, `home CSP is ${home.length} bytes`).toBeLessThan(16 * 1024);
    expect(diff.length, `json-diff CSP is ${diff.length} bytes`).toBeLessThan(16 * 1024);

    // Per-page scoping: two pages must not carry one identical global list.
    expect(home).not.toBe(diff);
  });

  test("hardening headers are present", async ({ request }) => {
    const headers = (await request.get("/")).headers();
    expect(headers["x-content-type-options"]).toBe("nosniff");
    expect(headers["x-frame-options"]).toBe("DENY");
    expect(headers["referrer-policy"]).toBe("strict-origin-when-cross-origin");
    expect(headers["strict-transport-security"]).toContain("max-age=");
  });
});

test.describe("Hydration", () => {
  test("the UUID generator hydrates without a server/client mismatch", async ({ page }) => {
    // Generating the initial batch during render produced different UUIDs on the
    // server and the client (React #418) and baked one fixed batch into the HTML.
    const problems = watchForErrors(page);
    await page.goto("/uuid-generator", { waitUntil: "networkidle" });
    await waitForHydration(page, "pre");

    expect(problems.filter((p) => /Minified React error|hydrat/i.test(p))).toEqual([]);

    const output = (await page.locator("pre").first().textContent()) ?? "";
    const uuids = output.trim().split("\n").filter(Boolean);
    expect(uuids.length).toBe(10);
    expect(uuids[0]).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);

    // Fresh values per visit: the batch must not be a build-time constant.
    const staticHtml = await (await page.request.get("/uuid-generator")).text();
    expect(staticHtml).not.toContain(uuids[0]);
  });
});

test.describe("Crawlable content", () => {
  test("every FAQ answer is in the served HTML, not gated behind JavaScript", async ({ request }) => {
    // Answers used to render only for the one expanded item, so crawlers that do
    // not execute JS — most AI crawlers — saw a page of unanswered questions.
    const html = await (await request.get("/json-diff")).text();
    const withoutJsonLd = html.replace(
      /<script[^>]*application\/ld\+json[^>]*>[\s\S]*?<\/script>/g,
      ""
    );

    const detailsBlocks = withoutJsonLd.match(/<details/g) ?? [];
    expect(detailsBlocks.length).toBeGreaterThanOrEqual(4);

    // Each <details> must carry its answer paragraph in the markup.
    // `<p[^>]*>` rather than `<p>`: the assertion is that the answer markup is
    // present in the served HTML, which a class attribute on the paragraph does
    // not change.
    const answerParagraphs = withoutJsonLd.match(/<\/summary>\s*<div[^>]*>\s*<p[^>]*>/g) ?? [];
    expect(answerParagraphs.length).toBe(detailsBlocks.length);
  });

  test("the 404 page is noindex and renders one header and footer", async ({ page, request }) => {
    const response = await request.get("/this-route-does-not-exist");
    expect(response.status()).toBe(404);

    const html = await response.text();
    expect(html).toMatch(/<meta name="robots" content="noindex/);
    // The 404 used to render its own Header and Footer inside the root layout,
    // duplicating both landmarks.
    expect((html.match(/<header/g) ?? []).length).toBe(1);
    expect((html.match(/<footer/g) ?? []).length).toBe(1);

    await page.goto("/this-route-does-not-exist");
    await expect(page.locator("h1")).toHaveText("Page Not Found");
  });

  test("each page carries a unique canonical, title and social image", async ({ request }) => {
    const seen = new Map<string, string>();

    for (const route of TOOL_ROUTES) {
      const html = await (await request.get(route)).text();

      const canonical = html.match(/<link rel="canonical" href="([^"]+)"/)?.[1];
      const title = html.match(/<title>([^<]*)<\/title>/)?.[1];

      expect(canonical, `${route} has no canonical`).toBeTruthy();
      expect(title, `${route} has no title`).toBeTruthy();
      expect(html, `${route} has no og:image`).toContain('property="og:image"');

      expect(
        seen.has(canonical!),
        `${route} shares a canonical with ${seen.get(canonical!)}`
      ).toBe(false);
      seen.set(canonical!, route);

      // Exactly one viewport tag: the layout used to add one on top of Next's.
      expect((html.match(/name="viewport"/g) ?? []).length).toBe(1);
    }
  });
});

test.describe("Keyboard accessibility", () => {
  test("the tools menu opens without a pointer", async ({ page }) => {
    // The dropdown was CSS :hover only, so it was unreachable by keyboard.
    await page.goto("/");
    await page.locator("#tools-menu-trigger").focus();
    await expect(page.locator("#tools-menu-trigger")).toHaveAttribute("aria-expanded", "false");

    await page.keyboard.press("Enter");
    await expect(page.locator("#tools-menu")).toBeVisible();
    await expect(page.locator("#tools-menu-trigger")).toHaveAttribute("aria-expanded", "true");

    await page.keyboard.press("Escape");
    await expect(page.locator("#tools-menu")).toBeHidden();
  });

  test("a skip link is the first focusable element", async ({ page }) => {
    await page.goto("/");
    await page.keyboard.press("Tab");
    const focused = page.locator(":focus");
    await expect(focused).toHaveText(/skip to main content/i);
    await expect(focused).toHaveAttribute("href", "#main-content");
  });
});

test.describe("Tool behaviour under production headers", () => {
  test("the JSON diff computes a result with the worker under CSP", async ({ page }) => {
    const problems = watchForErrors(page);
    await page.goto("/json-diff", { waitUntil: "networkidle" });
    await waitForHydration(page, "textarea");

    const panes = page.locator("textarea");
    await panes.nth(0).fill('{"a": 1, "b": {"c": 2}}');
    await panes.nth(1).fill('{"b": {"c": 3}, "a": 1}');

    // worker-src must permit the module worker, or this never resolves.
    await expect(page.getByText(/\/b\/c|Replace|Changed/i).first()).toBeVisible({ timeout: 15000 });
    expect(problems).toEqual([]);
  });
});

test.describe("Developer UX", () => {
  test("the command palette opens, searches and navigates by keyboard", async ({ page }) => {
    await page.goto("/");

    await page.keyboard.press("Control+k");
    const dialog = page.getByRole("dialog", { name: "Command palette" });
    await expect(dialog).toBeVisible();

    // Fuzzy, not prefix: "schm" has to reach "JSON Schema Generator".
    await page.keyboard.type("schm");
    await expect(page.locator('[role="option"]').first()).toContainText("JSON Schema Generator");

    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/\/json-schema-generator$/);
    await expect(dialog).toBeHidden();
  });

  test("the palette is reachable without knowing the shortcut", async ({ page }) => {
    // Two affordances, because the two kinds of page need different ones. The
    // homepage puts a search field in the hero and drops the header button, so
    // the corner is not carrying a duplicate of what is 200px below it; every
    // other page has no hero, so the button in the corner is the only way in.
    await page.goto("/");
    await waitForHydration(page, 'button[aria-label^="Search"]');
    await page.getByRole("button", { name: /Search \d+ tools/ }).click();
    await expect(page.getByRole("dialog", { name: "Command palette" })).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(page.getByRole("dialog")).toHaveCount(0);

    await page.goto("/merge-pdf");
    await waitForHydration(page, 'button[aria-label^="Search"]');
    await page.getByRole("button", { name: /Search tools/ }).click();
    await expect(page.getByRole("dialog", { name: "Command palette" })).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(page.getByRole("dialog")).toHaveCount(0);
  });

  test("malformed JSON can be repaired in one click", async ({ page }) => {
    await page.goto("/json-validator");
    await waitForHydration(page, "textarea");

    await page.locator("textarea").first().fill(
      "{\n  // config\n  name: 'gateway',\n  active: True,\n  tags: ['a', 'b',],\n}"
    );

    await expect(page.getByText(/issues can be fixed automatically/)).toBeVisible();

    // The change list is shown before anything is modified: silently rewriting
    // someone's payload is not acceptable in a debugging tool.
    await page.getByRole("button", { name: "Preview changes" }).click();
    await expect(page.getByText(/Wrapped bare object keys/)).toBeVisible();

    await page.getByRole("button", { name: "Fix it" }).click();
    await expect(page.getByText("Valid RFC 8259 JSON Document")).toBeVisible();

    const repaired = await page.locator("textarea").first().inputValue();
    expect(JSON.parse(repaired)).toEqual({
      name: "gateway",
      active: true,
      tags: ["a", "b"],
    });
  });
});

test.describe("Mobile ergonomics", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test("every editor control is reachable and meets the 44px touch target", async ({ page }) => {
    await page.goto("/json-diff", { waitUntil: "networkidle" });

    const measurements = await page.evaluate(() => {
      const labels = ["Wrap", "Format", "Open", "Clear", "Copy"];
      return [...document.querySelectorAll("button")]
        .filter((b) => labels.includes((b.textContent || "").trim()))
        .map((b) => {
          const rect = b.getBoundingClientRect();
          let clipped = false;
          let el = b.parentElement;
          while (el && el !== document.body) {
            const style = getComputedStyle(el);
            const box = el.getBoundingClientRect();
            if (style.overflow !== "visible" && (rect.right > box.right + 1 || rect.left < box.left - 1)) {
              clipped = true;
            }
            el = el.parentElement;
          }
          return { height: rect.height, clipped, offscreen: rect.right > window.innerWidth };
        });
    });

    expect(measurements.length).toBeGreaterThan(0);
    // "Copy" used to sit entirely off the right edge of a 390px screen.
    expect(measurements.filter((m) => m.clipped || m.offscreen)).toEqual([]);
    expect(measurements.filter((m) => m.height < 44)).toEqual([]);
  });

  test("no page scrolls horizontally", async ({ page }) => {
    for (const route of ["/", "/json-diff", "/json-validator", "/uuid-generator"]) {
      await page.goto(route, { waitUntil: "networkidle" });
      const overflows = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1
      );
      expect(overflows, `${route} scrolls horizontally`).toBe(false);
    }
  });
});

test.describe("GEO structure", () => {
  test("tool pages use question-form headings and a clean outline", async ({ request }) => {
    const routes = [
      "/json-diff",
      "/json-validator",
      "/json-minifier",
      "/json-schema-generator",
      "/uuid-generator",
      "/base64-decode",
      "/json-formatter",
    ];

    for (const route of routes) {
      const html = await (await request.get(route)).text();

      // Exactly one H1, and no skipped heading levels anywhere.
      expect((html.match(/<h1[\s>]/g) ?? []).length, `${route} H1 count`).toBe(1);

      const levels = [...html.matchAll(/<h([1-6])[\s>]/g)].map((m) => Number(m[1]));
      for (let i = 1; i < levels.length; i++) {
        expect(
          levels[i] - levels[i - 1],
          `${route} jumps from h${levels[i - 1]} to h${levels[i]}`
        ).toBeLessThanOrEqual(1);
      }

      // AI answer engines match headings against queries, which are questions.
      const headings = [...html.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/g)].map((m) =>
        m[1].replace(/<[^>]+>/g, " ").trim()
      );
      expect(headings.some((h) => h.includes("?")), `${route} has no question heading`).toBe(true);

      // The decorative "#" is a pseudo-element, so it must not be in the text.
      expect(headings.some((h) => h.startsWith("#")), `${route} leaks a literal #`).toBe(false);

      expect(html, `${route} lacks datePublished`).toContain("datePublished");
    }
  });
});

test.describe("Visual design system", () => {
  test("the header nav never breaks a label across two lines", async ({ page }) => {
    // The reported bug: at common laptop widths the nav was crowded until
    // "JSON Diff" rendered as "JSON" over "Diff". A wrapped label is detectable
    // as a rendered height taller than one line box.
    for (const width of [768, 1024, 1180, 1280, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto("/json-diff", { waitUntil: "domcontentloaded" });

      const wrapped = await page.evaluate(() => {
        const nav = document.querySelector('nav[aria-label="Primary"]');
        if (!nav) return ["no primary nav"];
        return [...nav.querySelectorAll("a, button")]
          .filter((el) => (el.textContent || "").trim().length > 0)
          .filter((el) => {
            const style = getComputedStyle(el);
            const lineHeight = parseFloat(style.lineHeight) || 20;
            const padding = parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
            return el.getBoundingClientRect().height > lineHeight + padding + 4;
          })
          .map((el) => (el.textContent || "").trim());
      });

      expect(wrapped, `nav labels wrap at ${width}px`).toEqual([]);
    }
  });

  test("the privacy guarantee is stated once per view, not twice", async ({ page }) => {
    // The header chip and the in-page badge are complementary: the chip appears
    // from `lg` up, the in-page badge below it. Both visible at once is the
    // duplication this redesign removed — in the old build the same sentence
    // appeared in the header and again ten pixels below it in the hero.
    for (const route of ["/", "/json-diff", "/about", "/uuid-generator"]) {
    for (const width of [390, 768, 1024, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(route, { waitUntil: "domcontentloaded" });

      const badges = await page
        .locator('a[href="/privacy"]')
        .evaluateAll((els) =>
          els
            .filter((el) =>
              // Three wordings, one claim. The tool pages carry the chip, and
              // the homepage states it outright in the strip below the tools —
              // both are links to /privacy, because a claim you cannot go and
              // check is a slogan.
              /Local-only|never leaves your browser|stay in your browser/.test(el.textContent || "")
            )
            .filter((el) => {
              const rect = el.getBoundingClientRect();
              return rect.width > 0 && rect.height > 0;
            })
            .map((el) => (el.textContent || "").trim())
        );

      // One is required (the guarantee is the product), two is the bug.
      expect(
        badges,
        `${route} at ${width}px renders ${badges.length} privacy badges`
      ).toHaveLength(1);
    }
    }
  });

  test("the shipped CSS uses no backdrop-filter and no keyframe animation", async ({ request }) => {
    // Both were explicitly ruled out: backdrop-filter re-blurs a live snapshot
    // of the page on every frame, and running animation keeps the compositor
    // awake on a page people leave open all day.
    const html = await (await request.get("/")).text();
    const hrefs = [...html.matchAll(/href="(\/_next\/static\/[^"]+\.css)"/g)].map((m) => m[1]);
    expect(hrefs.length).toBeGreaterThan(0);

    for (const href of hrefs) {
      const css = await (await request.get(href)).text();
      expect(css, `${href} uses backdrop-filter`).not.toMatch(/backdrop-filter\s*:/);
      expect(css, `${href} defines @keyframes`).not.toMatch(/@keyframes/);
      expect(css, `${href} runs an animation`).not.toMatch(/[^-]animation\s*:\s*(?!none)/);
    }
  });

  test("fonts are same-origin, so the zero-third-party claim still holds", async ({ page }) => {
    const external: string[] = [];
    page.on("request", (req) => {
      const url = new URL(req.url());
      if (url.host !== "127.0.0.1:3030" && url.host !== "localhost:3030") external.push(req.url());
    });

    await page.goto("/", { waitUntil: "networkidle" });

    expect(external, `page reached third-party hosts: ${external.join(", ")}`).toEqual([]);

    const faces = await page.evaluate(() =>
      [...document.fonts].map((f) => ({ family: f.family, status: f.status }))
    );
    expect(faces.some((f) => f.family.includes("Geist Mono"))).toBe(true);
    expect(faces.some((f) => f.family.includes("Geist") && !f.family.includes("Mono"))).toBe(
      true
    );
  });

  test("breadcrumbs name Home exactly once", async ({ page }) => {
    for (const route of ["/privacy", "/about", "/terms", "/uuid-generator", "/json-diff"]) {
      await page.goto(route, { waitUntil: "domcontentloaded" });
      const crumbs = await page
        .locator('nav[aria-label="Breadcrumb"] li')
        .allTextContents();
      const homes = crumbs.filter((c) => c.replace(/\W/g, "") === "Home");
      expect(homes.length, `${route} renders ${homes.length} Home crumbs`).toBe(1);
    }
  });

  test("the editor gutter numbers stay aligned with their lines", async ({ page }) => {
    await page.goto("/json-validator", { waitUntil: "networkidle" });

    const drift = await page.evaluate(() => {
      const textarea = document.querySelector("textarea") as HTMLTextAreaElement | null;
      if (!textarea) return null;
      const gutter = textarea.previousElementSibling as HTMLElement | null;
      if (!gutter) return null;

      const first = gutter.querySelector("div");
      if (!first) return null;

      // Line 1's number must sit on the same baseline row as line 1 of the text.
      const gutterTop = first.getBoundingClientRect().top;
      const textTop =
        textarea.getBoundingClientRect().top + parseFloat(getComputedStyle(textarea).paddingTop);
      return Math.abs(gutterTop - textTop);
    });

    expect(drift, "no gutter rendered").not.toBeNull();
    expect(drift as number, "gutter is misaligned with the text").toBeLessThanOrEqual(1);
  });
});
