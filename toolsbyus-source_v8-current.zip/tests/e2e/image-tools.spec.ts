import { test, expect, type Page } from "./fixtures";
import type { Download } from "@playwright/test";
import zlib from "node:zlib";
import { readFile } from "node:fs/promises";

/**
 * End-to-end tests for the image tools, against real images.
 *
 * Nothing here can be unit-tested: the whole pipeline is the browser's own
 * decode, canvas and encode, so a test with a stubbed canvas would be testing
 * the stub. These drive a real Chromium, and — where the claim is about the
 * pixels rather than the bytes — read the result back into a canvas in the page
 * and sample it. That is what catches the two failures this kind of tool
 * actually has: a transparent PNG converted to JPEG coming out black, and a
 * downscale that produces the wrong dimensions.
 *
 * Fixtures are generated rather than checked in, so the expected width, height
 * and colour of every pixel is known exactly.
 */

/* -------------------------------------------------------------------------- */
/* A minimal PNG encoder                                                      */
/* -------------------------------------------------------------------------- */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(bytes: Buffer): number {
  let c = 0xffffffff;
  for (const byte of bytes) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type: string, data: Buffer): Buffer {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, "ascii"), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([length, body, crc]);
}

/**
 * Builds an RGBA PNG from a pixel function.
 *
 * Hand-rolled because the alternative is a dependency in the test suite for
 * something the standard library already has: PNG is a signature, three chunks
 * and a zlib stream, and `zlib.deflateSync` is the only hard part.
 */
function makePng(
  width: number,
  height: number,
  pixel: (x: number, y: number) => [number, number, number, number]
): Buffer {
  const raw = Buffer.alloc(height * (1 + width * 4));
  let offset = 0;
  for (let y = 0; y < height; y++) {
    raw[offset++] = 0; // filter: none
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = pixel(x, y);
      raw[offset++] = r;
      raw[offset++] = g;
      raw[offset++] = b;
      raw[offset++] = a;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type: RGBA
  // 10..12 are compression, filter and interlace, all zero.

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw)),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

/** An opaque photograph-ish image: a gradient, which compresses like a photo. */
const gradient = (width: number, height: number) =>
  makePng(width, height, (x, y) => [
    Math.floor((x / width) * 255),
    Math.floor((y / height) * 255),
    128,
    255,
  ]);

/** A fully transparent image, for the "converted to JPEG came out black" case. */
const transparent = (width: number, height: number) =>
  makePng(width, height, () => [0, 0, 0, 0]);

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function tool(page: Page, keyword: string) {
  return page.getByRole("region", { name: `${keyword} tool` });
}

/** Decodes a downloaded image in the page and reports size and a sampled pixel. */
async function inspect(page: Page, download: Download, x = 1, y = 1) {
  const path = await download.path();
  const base64 = (await readFile(path)).toString("base64");
  const type = download.suggestedFilename().endsWith(".png") ? "image/png" : "image/jpeg";

  // Loaded through an <img> rather than fetch(): the site's own CSP sets
  // connect-src 'self', which blocks fetching a data: URI, while img-src allows
  // one. Running the check under the real policy is the point — a helper that
  // needed the policy relaxed would be testing a page nobody visits.
  return page.evaluate(
    async ([data, mime, sx, sy]) => {
      const image = new Image();
      image.src = `data:${mime};base64,${data}`;
      await image.decode();

      const canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext("2d")!;
      context.drawImage(image, 0, 0);
      const [r, g, b, a] = context.getImageData(sx as number, sy as number, 1, 1).data;
      return { width: canvas.width, height: canvas.height, r, g, b, a };
    },
    [base64, type, x, y] as const
  );
}

/* -------------------------------------------------------------------------- */
/* Compress                                                                   */
/* -------------------------------------------------------------------------- */

test.describe("Compress Image", () => {
  test("reduces a PNG photograph substantially when re-encoded as JPG", async ({ page }) => {
    await page.goto("/compress-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(800, 600) }]);

    const region = tool(page, "Compress Image");
    await region.getByRole("group", { name: "Output format" }).getByText("JPG").click();
    await region.getByRole("button", { name: /Compress 1 image/ }).click();

    // The summary line carries the before/after and a negative percentage.
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    const summary = await region.getByText(/→/).first().innerText();
    expect(summary).toMatch(/−\d+%/);
  });

  test("target size mode lands under the budget, never over", async ({ page }) => {
    await page.goto("/compress-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(1200, 900) }]);

    const region = tool(page, "Compress Image");
    await region.getByRole("group", { name: "Compression mode" }).getByText("Target size").click();
    await region.getByLabel("Under").fill("40");
    await region.getByRole("group", { name: "Output format" }).getByText("JPG").click();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Compress 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 30_000 });
    await region.getByRole("button", { name: "save" }).click();

    const download = await downloadPromise;
    const bytes = (await readFile(await download.path())).length;
    expect(bytes).toBeLessThanOrEqual(40 * 1024);
    // And not absurdly under: a search that gave up at the floor would be a
    // pass here too, and a useless one.
    expect(bytes).toBeGreaterThan(2 * 1024);
  });

  test("warns rather than silently doing nothing when a PNG meets a quality slider", async ({
    page,
  }) => {
    await page.goto("/compress-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "shot.png", mimeType: "image/png", buffer: gradient(200, 200) }]);

    await expect(
      tool(page, "Compress Image").getByText(/quality setting does nothing to a PNG/)
    ).toBeVisible();
  });
});

/* -------------------------------------------------------------------------- */
/* Resize                                                                     */
/* -------------------------------------------------------------------------- */

test.describe("Resize Image", () => {
  test("fits inside a box, keeping the aspect ratio", async ({ page }) => {
    await page.goto("/resize-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "wide.png", mimeType: "image/png", buffer: gradient(800, 600) }]);

    const region = tool(page, "Resize Image");
    await region.getByLabel("Width", { exact: true }).fill("400");
    await region.getByLabel("Height", { exact: true }).fill("400");

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Resize 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    await region.getByRole("button", { name: "save" }).click();

    // 4:3 fitted into a square box is 400 x 300, not 400 x 400.
    const result = await inspect(page, await downloadPromise);
    expect(result.width).toBe(400);
    expect(result.height).toBe(300);
  });

  test("does not enlarge unless asked", async ({ page }) => {
    await page.goto("/resize-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "small.png", mimeType: "image/png", buffer: gradient(100, 100) }]);

    const region = tool(page, "Resize Image");
    await region.getByLabel("Width", { exact: true }).fill("2000");
    await region.getByLabel("Height", { exact: true }).fill("2000");

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Resize 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    await region.getByRole("button", { name: "save" }).click();

    const result = await inspect(page, await downloadPromise);
    expect(result.width).toBe(100);
    expect(result.height).toBe(100);
  });

  test("a large reduction keeps the image recognisable rather than aliasing it away", async ({
    page,
  }) => {
    await page.goto("/resize-image");
    // A 2000px gradient down to 100px exercises the stepped path: a one-shot
    // drawImage here is where a naive implementation loses the gradient.
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "big.png", mimeType: "image/png", buffer: gradient(2000, 2000) }]);

    const region = tool(page, "Resize Image");
    await region.getByLabel("Width", { exact: true }).fill("100");
    await region.getByLabel("Height", { exact: true }).fill("100");
    await region.getByRole("group", { name: "Output format" }).getByText("PNG").click();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Resize 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 30_000 });
    await region.getByRole("button", { name: "save" }).click();

    const download = await downloadPromise;
    const near = await inspect(page, download, 5, 5);
    const far = await inspect(page, download, 94, 94);
    expect(near.width).toBe(100);
    // The gradient runs dark to light across both axes; if the downscale had
    // collapsed it, these two samples would be indistinguishable.
    expect(far.r).toBeGreaterThan(near.r + 100);
    expect(far.g).toBeGreaterThan(near.g + 100);
  });
});

/* -------------------------------------------------------------------------- */
/* Convert                                                                    */
/* -------------------------------------------------------------------------- */

test.describe("Convert Image", () => {
  // The bug this exists for: a transparent PNG encoded as JPEG on an unpainted
  // canvas comes out black, which is the single most common failure in browser
  // image conversion.
  test("a transparent PNG converted to JPG comes out white, not black", async ({ page }) => {
    await page.goto("/convert-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "logo.png", mimeType: "image/png", buffer: transparent(120, 120) }]);

    const region = tool(page, "Convert Image");
    await region.getByRole("group", { name: "Target format" }).getByText("JPG").click();
    await expect(region.getByText(/JPG has no alpha channel/)).toBeVisible();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Convert 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    await region.getByRole("button", { name: "save" }).click();

    const result = await inspect(page, await downloadPromise, 60, 60);
    expect(result.r).toBeGreaterThan(240);
    expect(result.g).toBeGreaterThan(240);
    expect(result.b).toBeGreaterThan(240);
  });

  test("honours the chosen background colour rather than forcing white", async ({ page }) => {
    await page.goto("/convert-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "logo.png", mimeType: "image/png", buffer: transparent(120, 120) }]);

    const region = tool(page, "Convert Image");
    await region.getByRole("group", { name: "Target format" }).getByText("JPG").click();
    await region.getByLabel("Background colour hex value").fill("#000000");

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Convert 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    await region.getByRole("button", { name: "save" }).click();

    const result = await inspect(page, await downloadPromise, 60, 60);
    expect(result.r).toBeLessThan(20);
    expect(result.b).toBeLessThan(20);
  });

  test("PNG output keeps the alpha channel", async ({ page }) => {
    await page.goto("/convert-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "logo.png", mimeType: "image/png", buffer: transparent(120, 120) }]);

    const region = tool(page, "Convert Image");
    await region.getByRole("group", { name: "Target format" }).getByText("PNG").click();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Convert 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });
    await region.getByRole("button", { name: "save" }).click();

    const result = await inspect(page, await downloadPromise, 60, 60);
    expect(result.a).toBe(0);
  });

  test("converts a batch in one pass", async ({ page }) => {
    await page.goto("/convert-image");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "a.png", mimeType: "image/png", buffer: gradient(200, 150) },
      { name: "b.png", mimeType: "image/png", buffer: gradient(300, 200) },
      { name: "c.png", mimeType: "image/png", buffer: gradient(120, 120) },
    ]);

    const region = tool(page, "Convert Image");
    await region.getByRole("button", { name: /Convert 3 images/ }).click();
    await expect(region.getByText(/3 images in/)).toBeVisible({ timeout: 30_000 });
    await expect(region.getByRole("button", { name: "save" })).toHaveCount(3);
  });
});

/* -------------------------------------------------------------------------- */
/* Crop                                                                       */
/* -------------------------------------------------------------------------- */

test.describe("Crop Image", () => {
  test("crops to exactly the typed rectangle", async ({ page }) => {
    await page.goto("/crop-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(600, 400) }]);

    const region = tool(page, "Crop Image");
    await expect(region.getByText("source 600 × 400")).toBeVisible({ timeout: 20_000 });

    await region.getByLabel("X", { exact: true }).fill("100");
    await region.getByLabel("Y", { exact: true }).fill("50");
    await region.getByLabel("W", { exact: true }).fill("200");
    await region.getByLabel("H", { exact: true }).fill("150");
    await region.getByRole("group", { name: "Output format" }).getByText("PNG").click();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Crop", exact: true }).click();
    await region.getByRole("button", { name: "Download" }).click();

    const result = await inspect(page, await downloadPromise);
    expect(result.width).toBe(200);
    expect(result.height).toBe(150);
  });

  test("a locked ratio produces a square region", async ({ page }) => {
    await page.goto("/crop-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(600, 400) }]);

    const region = tool(page, "Crop Image");
    await expect(region.getByText("source 600 × 400")).toBeVisible({ timeout: 20_000 });
    await region.getByRole("group", { name: "Aspect ratio" }).getByRole("button", { name: "1:1", exact: true }).click();

    // The largest square that fits a 600 x 400 image is 400 x 400.
    await expect(region.getByLabel("W", { exact: true })).toHaveValue("400");
    await expect(region.getByLabel("H", { exact: true })).toHaveValue("400");
  });

  test("takes the crop from the right place in the image", async ({ page }) => {
    await page.goto("/crop-image");
    // Left half red, right half blue: a crop from the right must be blue.
    const halves = makePng(400, 200, (x) => (x < 200 ? [255, 0, 0, 255] : [0, 0, 255, 255]));
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "halves.png", mimeType: "image/png", buffer: halves }]);

    const region = tool(page, "Crop Image");
    await expect(region.getByText("source 400 × 200")).toBeVisible({ timeout: 20_000 });

    await region.getByRole("group", { name: "Aspect ratio" }).getByRole("button", { name: "Free", exact: true }).click();
    await region.getByLabel("X", { exact: true }).fill("250");
    await region.getByLabel("Y", { exact: true }).fill("50");
    await region.getByLabel("W", { exact: true }).fill("100");
    await region.getByLabel("H", { exact: true }).fill("100");
    await region.getByRole("group", { name: "Output format" }).getByText("PNG").click();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Crop", exact: true }).click();
    await region.getByRole("button", { name: "Download" }).click();

    const result = await inspect(page, await downloadPromise, 50, 50);
    expect(result.b).toBeGreaterThan(200);
    expect(result.r).toBeLessThan(60);
  });
});

/* -------------------------------------------------------------------------- */
/* Base64                                                                     */
/* -------------------------------------------------------------------------- */

test.describe("Image to Base64", () => {
  test("produces a data URI that decodes back to the same image", async ({ page }) => {
    await page.goto("/image-to-base64");
    const source = gradient(64, 48);
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "icon.png", mimeType: "image/png", buffer: source }]);

    const region = tool(page, "Image to Base64");
    const uri = await region.locator("textarea").inputValue();
    expect(uri.startsWith("data:image/png;base64,")).toBe(true);

    // Round-trip: the payload must be the bytes that went in.
    expect(Buffer.from(uri.slice(uri.indexOf(",") + 1), "base64").equals(source)).toBe(true);
  });

  test("reports the 33% cost rather than hiding it", async ({ page }) => {
    await page.goto("/image-to-base64");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "icon.png", mimeType: "image/png", buffer: gradient(64, 48) }]);

    await expect(tool(page, "Image to Base64").getByText(/\(\+3[0-9]%\)/)).toBeVisible();
  });

  test("warns when the asset is too large to be worth inlining", async ({ page }) => {
    await page.goto("/image-to-base64");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "big.png", mimeType: "image/png", buffer: gradient(600, 600) }]);

    await expect(
      tool(page, "Image to Base64").getByText(/large for an inlined asset/)
    ).toBeVisible();
  });

  test("switches to a CSS rule that contains the URI", async ({ page }) => {
    await page.goto("/image-to-base64");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "icon.png", mimeType: "image/png", buffer: gradient(32, 32) }]);

    const region = tool(page, "Image to Base64");
    await region.getByRole("group", { name: "Output format" }).getByText("CSS").click();
    const css = await region.locator("textarea").inputValue();
    expect(css).toContain("background-image");
    expect(css).toContain('url("data:image/png;base64,');
  });
});

/* -------------------------------------------------------------------------- */
/* The privacy claim                                                          */
/* -------------------------------------------------------------------------- */

test.describe("no upload", () => {
  test("converting an image sends no request carrying a body", async ({ page }) => {
    const bodies: string[] = [];
    page.on("request", (request) => {
      if (request.postData()) bodies.push(`${request.method()} ${request.url()}`);
    });

    await page.goto("/convert-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(400, 300) }]);

    const region = tool(page, "Convert Image");
    await region.getByRole("button", { name: /Convert 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });

    expect(bodies).toEqual([]);
  });

  test("the HEIC decoder is not loaded by a tool that does not need it", async ({ page }) => {
    const requests: string[] = [];
    page.on("request", (request) => requests.push(request.url()));

    await page.goto("/compress-image");
    await page
      .locator('input[type="file"]')
      .setInputFiles([{ name: "photo.png", mimeType: "image/png", buffer: gradient(400, 300) }]);

    const region = tool(page, "Compress Image");
    await region.getByRole("button", { name: /Compress 1 image/ }).click();
    await expect(region.getByText(/1 image in/)).toBeVisible({ timeout: 20_000 });

    // Two megabytes nobody asked for is the cost this guards against. The chunk
    // is identified by size rather than by name, which is content-hashed.
    const heavy = await Promise.all(
      requests
        .filter((url) => url.endsWith(".js"))
        .map(async (url) => {
          const response = await page.request.get(url).catch(() => null);
          return response ? (await response.body()).length : 0;
        })
    );
    expect(Math.max(0, ...heavy)).toBeLessThan(900_000);
  });
});
