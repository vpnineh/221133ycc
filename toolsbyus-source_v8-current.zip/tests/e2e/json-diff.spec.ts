import { test, expect } from "./fixtures";

test.describe("JSON Diff Flagship Tool E2E", () => {
  test("renders correctly, matches H1, parses JSON-LD, and navigates diff", async ({ page }) => {
    // 1. Grant clipboard permissions
    await page.context().grantPermissions(["clipboard-read", "clipboard-write"]);

    await page.goto("/json-diff");

    // 2. Exact H1 match
    const h1 = page.locator("h1");
    await expect(h1).toHaveText("JSON Diff");

    // 3. Persistent Privacy Badge
    // Several links point at /privacy (the header nav item, the footer, the
    // badge), so this targets the badge by its own text rather than by position.
    const badge = page.locator('a[href="/privacy"]', { hasText: /Local-only|never leaves/ });
    await expect(badge.first()).toBeVisible();

    // 4. JSON-LD validation
    const jsonLdScript = page.locator('script[type="application/ld+json"]');
    await expect(jsonLdScript).toBeAttached();
    const jsonLdText = await jsonLdScript.textContent();
    expect(jsonLdText).toBeTruthy();
    const parsedSchema = JSON.parse(jsonLdText!);
    expect(parsedSchema["@graph"]).toBeDefined();
    const webApp = parsedSchema["@graph"].find((node: any) => node["@type"] === "WebApplication");
    expect(webApp).toBeDefined();
    expect(webApp.name).toBe("JSON Diff");

    // 5. Virtualized diff rendering
    const diffRegion = page.getByRole("region", { name: "Virtualized semantic diff viewer" });
    await expect(diffRegion).toBeVisible();

    // 6. Change counters
    await expect(page.getByText(/\d+ added/).first()).toBeVisible();
    await expect(page.getByText(/\d+ removed/).first()).toBeVisible();

    // 7. Keyboard navigation
    await page.keyboard.press("Alt+ArrowDown");
    // Verify selection or active row
    await page.keyboard.press("Alt+ArrowUp");

    // 8. Patch Export & Clipboard
    const exportBtn = page.getByRole("button", { name: "Export Patch (RFC 6902)" });
    await exportBtn.click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    const copyBtn = page.getByRole("button", { name: "Copy Patch & Close" });
    await copyBtn.click();
    await expect(dialog).toBeHidden();

    // 9. Ad placement
    //
    // Ads are opt-in via NEXT_PUBLIC_ADSENSE_ID and off by default, because the
    // site's stated guarantee is zero third-party requests. With them off the
    // slot renders nothing at all — an empty "Advertisement" box on a page that
    // will never show one is just noise. With them on, it must reserve its
    // height up front so filling it does not shift the layout (CLS).
    const adSlotA = page.locator("#ad-slot-a-json-diff");
    if (process.env.NEXT_PUBLIC_ADSENSE_ID) {
      await expect(adSlotA).toBeVisible();
      const boxA = await adSlotA.boundingBox();
      expect(boxA?.height).toBeGreaterThanOrEqual(100);
    } else {
      await expect(adSlotA).toHaveCount(0);
    }
  });
});
