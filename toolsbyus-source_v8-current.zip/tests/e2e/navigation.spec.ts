import { test, expect } from "./fixtures";
import { publishedTools, activeCategories } from "../../src/lib/tools.data.mjs";

/**
 * The directory page, the header, and the back-to-top control.
 *
 * The thing worth asserting about `/all-tools` is not that the filter works —
 * it is that the full catalogue is in the *served HTML* before any JavaScript
 * runs. A filter built by rendering matches from state would look identical in
 * a browser and show a crawler an empty page.
 */

const ACTIVE = activeCategories();
const TOOLS = publishedTools();

test.describe("All tools directory", () => {
  test("ships every tool in the static HTML", async ({ request }) => {
    const html = await (await request.get("/all-tools")).text();

    for (const tool of TOOLS) {
      expect(html, `${tool.href} missing from /all-tools HTML`).toContain(`href="${tool.href}"`);
      expect(html, `${tool.href} has no description on /all-tools`).toContain(tool.description);
    }
  });

  test("filters by text without losing the count of what exists", async ({ page }) => {
    await page.goto("/all-tools");

    // Scoped to the directory grid: the header menu and the footer link the
    // same hrefs on every page, so an unscoped selector matches three nodes.
    const grid = page.getByRole("main");
    const cards = grid.locator("section ul li a");
    await expect(page.getByText(`${TOOLS.length} tools, all running in your browser`)).toBeVisible();

    await page.getByLabel("Filter tools").fill("heic");
    await expect(page.getByText(/of \d+ tools match/)).toBeVisible();
    await expect(grid.locator("li:not([hidden]) a[href='/heic-to-jpg']")).toBeVisible();
    // A section whose tools all filter out unmounts entirely, so the card is
    // gone rather than merely hidden. Either way it must not be reachable.
    await expect(grid.locator("li:not([hidden]) a[href='/merge-pdf']")).toHaveCount(0);

    // Word order must not matter: "pdf split" and "split pdf" are the same ask.
    await page.getByLabel("Filter tools").fill("pdf split");
    await expect(grid.locator("li:not([hidden]) a[href='/split-pdf']")).toBeVisible();

    await page.getByLabel("Clear filter").click();
    await expect(cards.first()).toBeVisible();
  });

  test("filters by category", async ({ page }) => {
    await page.goto("/all-tools");
    await page
      .getByRole("group", { name: "Filter by category" })
      .getByRole("button", { name: /^Image/ })
      .click();

    const grid = page.getByRole("main");
    await expect(grid.locator("li:not([hidden]) a[href='/compress-image']")).toBeVisible();
    // A section whose tools all filter out unmounts entirely, so the card is
    // gone rather than merely hidden. Either way it must not be reachable.
    await expect(grid.locator("li:not([hidden]) a[href='/merge-pdf']")).toHaveCount(0);
  });

  test("says so plainly when nothing matches", async ({ page }) => {
    await page.goto("/all-tools");
    await page.getByLabel("Filter tools").fill("qwertyuiop");
    await expect(page.getByText(/Nothing matches/)).toBeVisible();
  });
});

test.describe("Header", () => {
  test("links every category hub and the full directory", async ({ request }) => {
    const html = await (await request.get("/json-diff")).text();

    for (const category of ACTIVE) {
      expect(html, `${category.hub} missing from the header`).toContain(`href="${category.hub}"`);
    }
    expect(html).toContain('href="/all-tools"');
  });

  test("the tools menu opens, closes on Escape, and returns focus", async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto("/");

    // Exercise keyboard disclosure independently of the pointer hover delay.
    const trigger = page.getByRole("button", { name: /All tools/ });
    await trigger.focus();
    await page.keyboard.press("Enter");
    await expect(page.locator("#tools-menu")).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(page.locator("#tools-menu")).toBeHidden();
    await expect(trigger).toBeFocused();
  });
});

test.describe("Back to top", () => {
  test("stays out of the way until the page is worth returning from", async ({ page }) => {
    await page.goto("/merge-pdf");

    // Located by title rather than by role: while hidden the control is
    // aria-hidden, which is correct and makes it invisible to getByRole.
    const button = page.locator('button[title="Back to top"]');
    // Present in the DOM but not interactive or reachable by keyboard.
    await expect(button).toHaveAttribute("tabindex", "-1");
    await expect(button).toHaveCSS("opacity", "0");

    await page.evaluate(() => window.scrollTo(0, 2000));
    await expect(button).toHaveCSS("opacity", "1");
    await expect(button).toHaveAttribute("tabindex", "0");
  });

  test("reports reading progress and returns to the top", async ({ page }) => {
    await page.goto("/merge-pdf");

    await page.evaluate(() =>
      window.scrollTo(0, document.documentElement.scrollHeight - window.innerHeight)
    );
    const button = page.getByRole("button", { name: /Back to top/ });
    await expect(button).toHaveAccessibleName(/100% read/);

    await button.click();
    await expect.poll(() => page.evaluate(() => window.scrollY)).toBeLessThan(50);
  });

  test("is a 44px target, which is the point of it on a phone", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto("/merge-pdf");
    await page.evaluate(() => window.scrollTo(0, 2000));

    const box = await page.getByRole("button", { name: /Back to top/ }).boundingBox();
    expect(box!.width).toBeGreaterThanOrEqual(44);
    expect(box!.height).toBeGreaterThanOrEqual(44);
  });
});
