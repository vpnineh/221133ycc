import { test, expect } from "./fixtures";

test.describe("Privacy & Zero-Network Gate", () => {
  test("HARD GATE: zero network requests occur after page load while documents are loaded and diffed", async ({
    page,
  }) => {
    let documentLoaded = false;
    const interceptedExternalRequests: string[] = [];

    // Intercept every network request
    await page.route("**", (route) => {
      const request = route.request();
      const url = request.url();

      if (documentLoaded) {
        // 1. Strict Payload Leak Assertion: No request URL or POST body may ever contain payload data
        const postData = request.postData() || "";
        if (url.includes("PRIVATE_PAYLOAD") || postData.includes("PRIVATE_PAYLOAD")) {
          throw new Error(`CRITICAL PRIVACY BREACH: Payload data leaked over network: ${url}`);
        }

        // 2. Disallow all non-static requests (no telemetry, no APIs, no analytics, no external hosts)
        const isStaticAsset =
          url.startsWith("data:") ||
          url.startsWith("blob:") ||
          url.includes("/_next/") ||
          url.includes("_rsc=") ||
          url.endsWith(".js") ||
          url.endsWith(".css") ||
          url.endsWith(".svg") ||
          url.endsWith(".ico");

        if (!isStaticAsset) {
          interceptedExternalRequests.push(`${request.method()} ${url}`);
        }
      }
      route.continue();
    });

    // 1. Navigate to /json-diff
    await page.goto("/json-diff");
    await page.waitForLoadState("networkidle");

    // 2. Mark document loaded - from now on, zero external requests are permitted
    documentLoaded = true;

    // 3. Type / paste new payload into left and right inputs
    const leftTextarea = page.locator('textarea[placeholder*="base JSON"]');
    const rightTextarea = page.locator('textarea[placeholder*="modified JSON"]');

    await leftTextarea.fill(JSON.stringify({ secretUserKey: "PRIVATE_PAYLOAD_12345", balance: 999999 }));
    await rightTextarea.fill(JSON.stringify({ secretUserKey: "PRIVATE_PAYLOAD_12345", balance: 1000000 }));

    // 4. Trigger diff options and interactions
    await page.waitForTimeout(500);

    // 5. Open export patch dialog
    const exportBtn = page.getByRole("button", { name: "Export Patch (RFC 6902)" });
    await exportBtn.click();
    await expect(page.getByRole("dialog")).toBeVisible();

    // 6. Close modal
    const closeBtn = page.getByRole("button", { name: "Close dialog" });
    await closeBtn.click();

    // 7. Verify zero network requests were attempted
    expect(interceptedExternalRequests).toEqual([]);
  });
});
