import { test, expect } from "./fixtures";
import { activeCategories, toolsInCategory } from "../../src/lib/tools.data.mjs";

// Browser regression scenarios for the redesigned shared UI.
// These use synthetic File drops; OS-level drag and drop also needs a manual check.
test("a PDF dropped on the footer is added exactly once", async ({ page }) => {
  await page.goto("/merge-pdf");
  const transfer = await page.evaluateHandle(() => {
    const data = new DataTransfer();
    data.items.add(new File(["%PDF-1.7\n"], "footer-drop.pdf", { type: "application/pdf" }));
    return data;
  });
  await page.locator("footer").dispatchEvent("drop", { dataTransfer: transfer });
  await expect(page.getByRole("main").getByText("footer-drop.pdf", { exact: true })).toHaveCount(1);
  await expect(page).toHaveURL(/\/merge-pdf$/);
  await transfer.dispose();
});

test("a whole-page drop uses the focused JSON input without changing the other pane", async ({ page }) => {
  await page.goto("/json-diff");
  const inputs = page.getByRole("main").locator("textarea:not([readonly])");
  await expect(inputs).toHaveCount(2);
  await inputs.nth(0).fill('{"left":1}');
  await inputs.nth(1).focus();
  const transfer = await page.evaluateHandle(() => {
    const data = new DataTransfer();
    data.items.add(new File(['{"right":2}'], "right.json", { type: "application/json" }));
    return data;
  });
  await page.locator("footer").dispatchEvent("drop", { dataTransfer: transfer });
  await expect(inputs.nth(1)).toHaveValue('{"right":2}');
  await expect(inputs.nth(0)).toHaveValue('{"left":1}');
  await transfer.dispose();
});

test("active category, hover and Escape work together", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/compress-image");
  const trigger = page.locator("#trigger-image");
  await expect(trigger).toHaveAttribute("data-active", "true");
  await trigger.hover();
  const panel = page.locator("#menu-image");
  await expect(panel).toBeVisible();
  await trigger.click();
  await expect(panel).toBeVisible();
  await expect(panel.locator('[href="/compress-image"]')).toHaveAttribute("aria-current", "page");
  await page.keyboard.press("Escape");
  await expect(panel).toBeHidden();
  await expect(trigger).toBeFocused();
});

test("every homepage tab exposes all tools in its category", async ({ page }) => {
  await page.goto("/");
  for (const category of activeCategories()) {
    await page.locator(`#tab-${category.id}`).click();
    const panel = page.locator(`#panel-${category.id}`);
    await expect(panel).toBeVisible();
    for (const tool of toolsInCategory(category.id)) {
      await expect(panel.locator(`a[href="${tool.href}"]`)).toBeVisible();
    }
  }
});

test("navigation stays usable at 320px including search and active category", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 740 });
  await page.goto("/compress-image");
  await page.getByRole("button", { name: "Open navigation menu" }).click();
  const nav = page.locator("#mobile-navigation");
  await expect(nav.getByRole("button", { name: /^Search \d+ tools$/ })).toBeVisible();
  await expect(nav.locator('[href="/compress-image"]')).toHaveAttribute("aria-current", "page");
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(321);
  await page.keyboard.press("Escape");
  await expect(nav).toHaveCount(0);
});
