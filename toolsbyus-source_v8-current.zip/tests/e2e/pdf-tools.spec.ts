import { test, expect, type Page } from "./fixtures";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

/**
 * End-to-end tests for the PDF tools, against real PDFs.
 *
 * These are the tests that matter most on this site. A JSON tool that is subtly
 * wrong produces output the user can see; a PDF tool that is subtly wrong
 * produces a file that opens fine in one reader and not in another, or silently
 * loses a page. So the fixtures are generated here, driven through the real UI,
 * and the downloaded result is parsed back and checked page by page.
 */

/** Builds a PDF with numbered pages, so a page can be identified after a merge. */
async function makePdf(pageCount: number, prefix: string): Promise<Buffer> {
  const document_ = await PDFDocument.create();
  const font = await document_.embedFont(StandardFonts.Helvetica);

  for (let index = 0; index < pageCount; index++) {
    const page = document_.addPage([300, 400]);
    page.drawText(`${prefix}-${index + 1}`, {
      x: 40,
      y: 340,
      size: 24,
      font,
      color: rgb(0, 0, 0),
    });
  }

  return Buffer.from(await document_.save());
}

function tool(page: Page, keyword: string) {
  return page.getByRole("region", { name: `${keyword} tool` });
}

test.describe("Merge PDF", () => {
  test("merges two documents into one with every page, in order", async ({ page }) => {
    await page.goto("/merge-pdf");

    const first = await makePdf(2, "A");
    const second = await makePdf(3, "B");

    await page.locator('input[type="file"]').setInputFiles([
      { name: "first.pdf", mimeType: "application/pdf", buffer: first },
      { name: "second.pdf", mimeType: "application/pdf", buffer: second },
    ]);

    const region = tool(page, "Merge PDF");
    await expect(region.getByText(/^2 files · /)).toBeVisible();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Merge 2 files/ }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });
    await region.getByRole("button", { name: "Download" }).click();

    const download = await downloadPromise;
    // The default stem is derived from the first input, not a generic
    // "merged": two files dropped as first.pdf and second.pdf come back as
    // first-merged.pdf, which is what makes the download findable later.
    expect(download.suggestedFilename()).toBe("first-merged.pdf");

    // Parse the result back rather than trusting the byte count: a merge that
    // produced a structurally invalid file would still download.
    const path = await download.path();
    const { readFile } = await import("node:fs/promises");
    const merged = await PDFDocument.load(await readFile(path));
    expect(merged.getPageCount()).toBe(5);
  });

  test("respects the order the user sets rather than the order dropped", async ({ page }) => {
    await page.goto("/merge-pdf");

    await page.locator('input[type="file"]').setInputFiles([
      { name: "first.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "A") },
      { name: "second.pdf", mimeType: "application/pdf", buffer: await makePdf(4, "B") },
    ]);

    const region = tool(page, "Merge PDF");
    // Move the four-page file to the top; the merged size proves the order took.
    await region.getByRole("button", { name: "Move second.pdf up" }).click();

    const names = await region.locator("li span[title]").allTextContents();
    expect(names[0]).toBe("second.pdf");
  });

  test("rejects a file that is not a PDF, naming it", async ({ page }) => {
    await page.goto("/merge-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "notes.txt", mimeType: "text/plain", buffer: Buffer.from("hello") },
    ]);
    await expect(tool(page, "Merge PDF").getByText(/notes\.txt: not a/)).toBeVisible();
  });

  test("explains a corrupt PDF instead of failing silently", async ({ page }) => {
    await page.goto("/merge-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "a.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "A") },
      { name: "broken.pdf", mimeType: "application/pdf", buffer: Buffer.from("not a pdf at all") },
    ]);

    const region = tool(page, "Merge PDF");
    await region.getByRole("button", { name: /Merge 2 files/ }).click();
    await expect(region.getByText(/not a readable PDF/)).toBeVisible({ timeout: 15_000 });
  });

  test("uploads nothing: no request carries the document", async ({ page }) => {
    // The site's entire competitive claim, asserted rather than described.
    await page.goto("/merge-pdf", { waitUntil: "networkidle" });

    const requests: string[] = [];
    page.on("request", (request) => {
      if (request.method() === "POST" || request.postData()) requests.push(request.url());
    });

    await page.locator('input[type="file"]').setInputFiles([
      { name: "a.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "A") },
      { name: "b.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "B") },
    ]);

    const region = tool(page, "Merge PDF");
    await region.getByRole("button", { name: /Merge 2 files/ }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    expect(requests).toEqual([]);
  });
});

test.describe("PDF to JPG", () => {
  test("renders every page to an image with the right pixel dimensions", async ({ page }) => {
    await page.goto("/pdf-to-jpg");

    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(3, "P") },
    ]);

    const region = tool(page, "PDF to JPG");
    await region.getByRole("button", { name: "Convert to images" }).click();

    // pdf.js loads its own worker on first use; give it room.
    await expect(region.getByText(/^3 images · /)).toBeVisible({ timeout: 30_000 });
    await expect(region.getByRole("img", { name: "Page 1" })).toBeVisible();
    await expect(region.getByRole("img", { name: "Page 3" })).toBeVisible();

    // The fixture pages are 300 x 400 pt, so at 150 DPI (scale 150/72) that is
    // 625 x 833 device pixels. A wrong scale factor is otherwise invisible.
    const width = await region.getByRole("img", { name: "Page 1" }).getAttribute("width");
    expect(Number(width)).toBe(Math.floor(300 * (150 / 72)));
  });

  test("honours a page range", async ({ page }) => {
    await page.goto("/pdf-to-jpg");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(5, "P") },
    ]);

    const region = tool(page, "PDF to JPG");
    await region.getByLabel("Pages").fill("2-3");
    await region.getByRole("button", { name: "Convert to images" }).click();

    await expect(region.getByText(/^2 images · /)).toBeVisible({ timeout: 30_000 });
    await expect(region.getByRole("img", { name: "Page 2" })).toBeVisible();
  });

  test("renders a white page rather than a black one for JPEG", async ({ page }) => {
    // The classic failure: a transparent canvas encoded as JPEG comes out black.
    await page.goto("/pdf-to-jpg");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "P") },
    ]);

    const region = tool(page, "PDF to JPG");
    await region.getByRole("button", { name: "Convert to images" }).click();
    await expect(region.getByText(/^1 image · /)).toBeVisible({ timeout: 30_000 });

    const brightness = await region.getByRole("img", { name: "Page 1" }).evaluate(
      async (element) => {
        const image = element as HTMLImageElement;
        await image.decode();
        const canvas = document.createElement("canvas");
        canvas.width = 20;
        canvas.height = 20;
        const context = canvas.getContext("2d")!;
        // Sample the top-left corner, which the fixture leaves blank.
        context.drawImage(image, 0, 0, 20, 20, 0, 0, 20, 20);
        const { data } = context.getImageData(0, 0, 20, 20);
        let sum = 0;
        for (let i = 0; i < data.length; i += 4) sum += data[i];
        return sum / (data.length / 4);
      }
    );

    expect(brightness).toBeGreaterThan(200);
  });
});

test.describe("Page operations", () => {
  /** Downloads the current result and parses it back as a PDF. */
  async function downloadAndParse(page: Page, region: ReturnType<typeof tool>) {
    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Download" }).first().click();
    const download = await downloadPromise;
    const { readFile } = await import("node:fs/promises");
    return {
      document: await PDFDocument.load(await readFile(await download.path())),
      name: download.suggestedFilename(),
    };
  }

  test("split extracts the requested range into one file", async ({ page }) => {
    await page.goto("/split-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(10, "P") },
    ]);

    const region = tool(page, "Split PDF");
    await region.getByLabel("Pages").fill("2-4, 9");
    await region.getByRole("button", { name: "Extract pages" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const { document } = await downloadAndParse(page, region);
    expect(document.getPageCount()).toBe(4);
  });

  test("split into every page produces one file per page", async ({ page }) => {
    await page.goto("/split-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(4, "P") },
    ]);

    const region = tool(page, "Split PDF");
    await region.getByRole("button", { name: "Every page" }).click();
    await region.getByRole("button", { name: "Split into 4 files" }).click();
    // Anchored on the result line rather than on `/4 files/`, which also matches
    // the button that was just pressed — the button stays on screen, so the
    // looser pattern resolved to two elements as soon as the result appeared
    // and failed strict mode on whichever run happened to be slow enough.
    await expect(region.getByText(/Done in .* · 4 files/)).toBeVisible({ timeout: 15_000 });
  });

  test("rotate writes the rotation into the document", async ({ page }) => {
    await page.goto("/rotate-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(2, "P") },
    ]);

    const region = tool(page, "Rotate PDF");
    await region.getByRole("button", { name: "90°", exact: true }).click();
    await region.getByRole("button", { name: "Rotate 90°" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const { document } = await downloadAndParse(page, region);
    // The point of the tool: a reader's view rotation would not be in the file.
    expect(document.getPage(0).getRotation().angle).toBe(90);
    expect(document.getPage(1).getRotation().angle).toBe(90);
  });

  test("delete removes the listed pages", async ({ page }) => {
    await page.goto("/delete-pdf-pages");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(6, "P") },
    ]);

    const region = tool(page, "Delete PDF Pages");
    await region.getByLabel("Pages").fill("2, 4-5");
    await expect(region.getByText("3 of 6 pages remain")).toBeVisible();

    await region.getByRole("button", { name: "Remove pages" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const { document, name } = await downloadAndParse(page, region);
    expect(name).toBe("doc-trimmed.pdf");
    expect(document.getPageCount()).toBe(3);
  });

  test("delete refuses to remove every page", async ({ page }) => {
    await page.goto("/delete-pdf-pages");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(3, "P") },
    ]);

    const region = tool(page, "Delete PDF Pages");
    await region.getByLabel("Pages").fill("1-3");
    await expect(region.getByText(/would leave no pages at all/)).toBeVisible();
  });

  test("reorder interleaves a two-pass duplex scan", async ({ page }) => {
    await page.goto("/reorder-pdf-pages");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "scan.pdf", mimeType: "application/pdf", buffer: await makePdf(6, "P") },
    ]);

    const region = tool(page, "Reorder PDF Pages");
    await region.getByRole("button", { name: "Interleave scan" }).click();
    // Fronts 1,2,3 then backs 6,5,4 interleave to 1,6,2,5,3,4.
    await expect(region.getByLabel("New order")).toHaveValue("1, 6, 2, 5, 3, 4");

    await region.getByRole("button", { name: "Reorder pages" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });
    const { document } = await downloadAndParse(page, region);
    expect(document.getPageCount()).toBe(6);
  });

  test("watermark stamps every page without inflating the file", async ({ page }) => {
    await page.goto("/watermark-pdf");
    const source = await makePdf(4, "P");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: source },
    ]);

    const region = tool(page, "Watermark PDF");
    await region.getByRole("button", { name: "Stamp 4 pages" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const { document } = await downloadAndParse(page, region);
    expect(document.getPageCount()).toBe(4);
    // Text rather than an image: a few dozen bytes per page, not hundreds of KB.
    const bytes = (await document.save()).byteLength;
    expect(bytes).toBeLessThan(source.byteLength + 20_000);
  });
});

test.describe("JPG to PDF", () => {
  /** A tiny PNG, built in the browser-independent way. */
  function pngFixture(): Buffer {
    // 1x1 red pixel, the smallest valid PNG.
    return Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
      "base64"
    );
  }

  test("builds a PDF with one page per image", async ({ page }) => {
    await page.goto("/jpg-to-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "one.png", mimeType: "image/png", buffer: pngFixture() },
      { name: "two.png", mimeType: "image/png", buffer: pngFixture() },
    ]);

    const region = tool(page, "JPG to PDF");
    await region.getByRole("button", { name: "Make a 2-page PDF" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Download" }).click();
    const download = await downloadPromise;
    const { readFile } = await import("node:fs/promises");
    const built = await PDFDocument.load(await readFile(await download.path()));
    expect(built.getPageCount()).toBe(2);
    // A4 by default, in points.
    expect(Math.round(built.getPage(0).getSize().width)).toBe(595);
  });

  test("page-per-image sizes each page to its image", async ({ page }) => {
    await page.goto("/jpg-to-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "one.png", mimeType: "image/png", buffer: pngFixture() },
    ]);

    const region = tool(page, "JPG to PDF");
    await region.getByRole("button", { name: "Page per image" }).click();
    await region.getByRole("button", { name: "Make a 1-page PDF" }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Download" }).click();
    const download = await downloadPromise;
    const { readFile } = await import("node:fs/promises");
    const built = await PDFDocument.load(await readFile(await download.path()));
    expect(Math.round(built.getPage(0).getSize().width)).toBe(1);
  });
});

test.describe("PDF to Text", () => {
  test("extracts the text layer exactly", async ({ page }) => {
    await page.goto("/pdf-to-text");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "doc.pdf", mimeType: "application/pdf", buffer: await makePdf(2, "HELLO") },
    ]);

    const region = tool(page, "PDF to Text");
    await region.getByRole("button", { name: "Extract text" }).click();

    const output = page.locator("textarea").first();
    await expect(output).toHaveValue(/HELLO-1/, { timeout: 30_000 });
    await expect(output).toHaveValue(/--- page 2 ---/);
  });

  test("reports pages with no text rather than returning silence", async ({ page }) => {
    // A page with no text at all stands in for a scan, which is the case that
    // makes people think the tool is broken.
    const blank = await PDFDocument.create();
    blank.addPage([200, 200]);

    await page.goto("/pdf-to-text");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "scan.pdf", mimeType: "application/pdf", buffer: Buffer.from(await blank.save()) },
    ]);

    const region = tool(page, "PDF to Text");
    await region.getByRole("button", { name: "Extract text" }).click();
    await expect(region.getByText(/produced no text/)).toBeVisible({ timeout: 30_000 });
    await expect(region.getByText(/those pages are scans/)).toBeVisible();
  });
});

test.describe("Compress PDF", () => {
  test("the lossless rebuild keeps every page and stays a valid PDF", async ({ page }) => {
    await page.goto("/compress-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "report.pdf", mimeType: "application/pdf", buffer: await makePdf(6, "R") },
    ]);

    const region = tool(page, "Compress PDF");
    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Compress", exact: true }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 30_000 });
    await region.getByRole("button", { name: "Download" }).click();

    const download = await downloadPromise;
    expect(download.suggestedFilename()).toBe("report-compressed.pdf");

    const { readFile } = await import("node:fs/promises");
    const result = await PDFDocument.load(await readFile(await download.path()));
    expect(result.getPageCount()).toBe(6);
    // A rebuild that silently resized pages would be a different bug with the
    // same page count, so the geometry is checked too.
    expect(Math.round(result.getPage(0).getSize().width)).toBe(300);
    expect(Math.round(result.getPage(0).getSize().height)).toBe(400);
  });

  test("says so honestly when a file is already efficient", async ({ page }) => {
    await page.goto("/compress-pdf");
    // pdf-lib already writes object streams, so its own output is the case
    // where the lossless pass has nothing left to remove.
    await page.locator('input[type="file"]').setInputFiles([
      { name: "tidy.pdf", mimeType: "application/pdf", buffer: await makePdf(2, "T") },
    ]);

    const region = tool(page, "Compress PDF");
    await region.getByRole("button", { name: "Compress", exact: true }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 30_000 });
    await expect(region.getByText(/already efficiently written/)).toBeVisible();
  });

  test("rasterising keeps the page size in points rather than in pixels", async ({ page }) => {
    await page.goto("/compress-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "scan.pdf", mimeType: "application/pdf", buffer: await makePdf(3, "S") },
    ]);

    const region = tool(page, "Compress PDF");
    await region.getByRole("group", { name: "Compression mode" }).getByText("Rasterise").click();
    await expect(region.getByText(/replaces every page with a picture/)).toBeVisible();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: "Compress", exact: true }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 60_000 });
    await region.getByRole("button", { name: "Download" }).click();

    const { readFile } = await import("node:fs/promises");
    const bytes = await readFile(await (await downloadPromise).path());
    const result = await PDFDocument.load(bytes);

    expect(result.getPageCount()).toBe(3);
    // At 120 DPI a 300 x 400 point page renders to 500 x 667 pixels. Sizing the
    // rebuilt page from the pixel count instead of the point box is the standard
    // way this conversion goes wrong, and it would show up here as 500 x 667.
    expect(Math.round(result.getPage(0).getSize().width)).toBe(300);
    expect(Math.round(result.getPage(0).getSize().height)).toBe(400);

    // And the page really is an image now, not the original text.
    expect(bytes.includes(Buffer.from("/Image"))).toBe(true);
  });
});

test.describe("Output naming", () => {
  test("a typed name reaches the downloaded file", async ({ page }) => {
    await page.goto("/merge-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "first.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "A") },
      { name: "second.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "B") },
    ]);

    const region = tool(page, "Merge PDF");
    await region.getByRole("button", { name: /Output name/ }).click();
    await region.getByLabel("Output filename").fill("invoice 2026-03");

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Merge 2 files/ }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });
    await region.getByRole("button", { name: "Download" }).click();

    expect((await downloadPromise).suggestedFilename()).toBe("invoice 2026-03.pdf");
  });

  test("a name with a path in it is sanitised, and the page says so", async ({ page }) => {
    await page.goto("/merge-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "a.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "A") },
      { name: "b.pdf", mimeType: "application/pdf", buffer: await makePdf(1, "B") },
    ]);

    const region = tool(page, "Merge PDF");
    await region.getByRole("button", { name: /Output name/ }).click();
    await region.getByLabel("Output filename").fill("../../etc/passwd");

    // `../../etc/passwd` becomes `..-..-etc-passwd` once the separators go, and
    // the leading dots are then stripped so the result cannot be a hidden file.
    // The preview shows that before anything is downloaded.
    await expect(region.getByText("-..-etc-passwd.pdf").first()).toBeVisible();

    const downloadPromise = page.waitForEvent("download");
    await region.getByRole("button", { name: /Merge 2 files/ }).click();
    await expect(region.getByRole("button", { name: "Download" })).toBeVisible({ timeout: 15_000 });
    await region.getByRole("button", { name: "Download" }).click();

    const name = (await downloadPromise).suggestedFilename();
    expect(name).not.toContain("/");
    expect(name).toBe("-..-etc-passwd.pdf");
  });

  test("defaults to a name derived from the input, not a generic one", async ({ page }) => {
    await page.goto("/rotate-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "contract.pdf", mimeType: "application/pdf", buffer: await makePdf(2, "C") },
    ]);

    const region = tool(page, "Rotate PDF");
    await expect(region.getByText("contract-rotated.pdf").first()).toBeVisible({ timeout: 15_000 });
  });

  test("a batch pattern names each part distinctly", async ({ page }) => {
    await page.goto("/split-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "book.pdf", mimeType: "application/pdf", buffer: await makePdf(3, "P") },
    ]);

    const region = tool(page, "Split PDF");
    await region.getByRole("group", { name: "Mode" }).getByText("Every page").click();
    await region.getByRole("button", { name: /Output names/ }).click();
    await region.getByLabel("Output filename pattern").fill("chapter-{n}");

    await region.getByRole("button", { name: /Split into/ }).click();
    await expect(region.getByText("chapter-1.pdf")).toBeVisible({ timeout: 20_000 });
    await expect(region.getByText("chapter-2.pdf")).toBeVisible();
    await expect(region.getByText("chapter-3.pdf")).toBeVisible();
  });

  test("warns when a batch pattern would name every file the same", async ({ page }) => {
    await page.goto("/split-pdf");
    await page.locator('input[type="file"]').setInputFiles([
      { name: "book.pdf", mimeType: "application/pdf", buffer: await makePdf(3, "P") },
    ]);

    const region = tool(page, "Split PDF");
    await region.getByRole("button", { name: /Output names/ }).click();
    await region.getByLabel("Output filename pattern").fill("everything");
    await expect(region.getByText(/Every file would get the same name/)).toBeVisible();
  });
});
