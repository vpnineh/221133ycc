import { test, expect, type Page } from "./fixtures";
import { publishedTools, activeCategories, INFO_PAGES } from "../../src/lib/tools.data.mjs";

/**
 * Horizontal overflow, checked at every width on every route.
 *
 * "Responsive" is usually verified by looking at two or three pages in a device
 * emulator, which finds the layouts that collapse and misses the ones that are
 * six pixels too wide — and six pixels too wide is what a reader actually feels:
 * the page drifts sideways under a thumb, the sticky header detaches from the
 * left edge, and nothing looks obviously broken in a screenshot.
 *
 * So this asserts the only thing that is unambiguous. The document must not
 * scroll horizontally, and no element may be wider than the viewport — with one
 * carve-out, for the containers that are *deliberately* scrollable: a wide table
 * of options, a code block, a row of filter chips. Those are marked in the
 * markup with `overflow-x: auto`, and an element inside one of them is doing
 * what it was told to.
 *
 * 320px is included because it is the narrowest width still in real use (an
 * iPhone SE in display-zoom mode reports 320), and because almost nothing is
 * ever tested there.
 */

const WIDTHS = [320, 360, 390, 414, 768, 1024, 1280, 1440];

/** One page per category, plus the pages with the densest chrome. */
const ROUTES = [
  "/",
  "/all-tools",
  "/json-diff",
  "/json-pretty-print",
  "/merge-pdf",
  "/compress-image",
  "/crop-image",
  "/regex-tester",
  "/qr-code-generator",
  "/pdf-tools",
  "/about",
  "/privacy",
  ...activeCategories().map((category: { hub: string }) => category.hub),
  // `/pdf-tools` is both a hub and listed above for its density; dedupe so the
  // matrix does not declare the same test twice.
].filter((route, index, all) => all.indexOf(route) === index);

interface Overflow {
  tag: string;
  cls: string;
  right: number;
}

async function overflowing(page: Page, width: number): Promise<Overflow[]> {
  return page.evaluate((viewport) => {
    const scrollable = (node: Element): boolean => {
      for (let current: Element | null = node; current; current = current.parentElement) {
        const style = getComputedStyle(current);
        if (style.overflowX === "auto" || style.overflowX === "scroll") return true;
      }
      return false;
    };

    const found: Array<{ tag: string; cls: string; right: number }> = [];
    for (const node of Array.from(document.body.querySelectorAll("*"))) {
      const style = getComputedStyle(node);
      // A fixed or absolutely positioned element that is deliberately parked
      // off-screen (a closed drawer, a screen-reader-only label) is not overflow.
      if (style.position === "fixed" || style.visibility === "hidden") continue;
      if (node.closest("[hidden]")) continue;

      const rect = node.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      // One pixel of slack: sub-pixel layout rounds either way at some widths.
      if (rect.right <= viewport + 1) continue;
      if (scrollable(node)) continue;

      found.push({
        tag: node.tagName.toLowerCase(),
        cls: (node.getAttribute("class") ?? "").slice(0, 120),
        right: Math.round(rect.right),
      });
    }
    return found;
  }, width);
}

for (const width of WIDTHS) {
  test.describe(`at ${width}px`, () => {
    for (const route of ROUTES) {
      test(`${route} does not scroll sideways`, async ({ page }) => {
        await page.setViewportSize({ width, height: 900 });
        await page.goto(route);

        const documentWidth = await page.evaluate(
          () => document.documentElement.scrollWidth
        );
        expect(
          documentWidth,
          `${route} at ${width}px scrolls horizontally (${documentWidth}px of content)`
        ).toBeLessThanOrEqual(width + 1);

        const culprits = await overflowing(page, width);
        expect(
          culprits,
          `${route} at ${width}px has elements past the viewport:\n${JSON.stringify(
            culprits,
            null,
            2
          )}`
        ).toEqual([]);
      });
    }
  });
}

test.describe("touch targets", () => {
  test("every control in the header is at least 44px under a coarse pointer", async ({
    browser,
  }) => {
    // `hasTouch` is what flips the `pointer-coarse` variant the design system
    // sizes against, so testing a narrow viewport alone would prove nothing.
    const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
      hasTouch: true,
    });
    const page = await context.newPage();
    await page.goto("/merge-pdf");

    // `body > header` and not `header`: a tool page's own <header> is a
    // legitimate second one, holding the breadcrumb and the H1, and it is
    // not what this test is about. Scoping by descent keeps the assertion
    // aimed at the site bar whatever the page inside does.
    const controls = page.locator("body > header button, body > header a");
    const count = await controls.count();
    expect(count).toBeGreaterThan(2);

    for (let index = 0; index < count; index++) {
      const control = controls.nth(index);
      if (!(await control.isVisible())) continue;
      const box = await control.boundingBox();
      if (!box) continue;
      const label = (await control.getAttribute("aria-label")) ?? (await control.innerText());
      // The wordmark is a text link in a 56px bar, not a tap target to hit
      // precisely; everything that performs an action has to be reachable.
      if (label.trim() === "ToolsByUs") continue;
      expect(box.height, `"${label.trim()}" is ${box.height}px tall`).toBeGreaterThanOrEqual(40);
    }

    await context.close();
  });
});

test.describe("the whole catalogue at phone width", () => {
  // Cheaper than adding every route to the matrix above, and still catches a
  // tool page whose controls do not wrap.
  for (const tool of publishedTools()) {
    test(`${tool.href} fits a 360px phone`, async ({ page }) => {
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(tool.href);

      const documentWidth = await page.evaluate(() => document.documentElement.scrollWidth);
      expect(documentWidth, `${tool.href} scrolls sideways at 360px`).toBeLessThanOrEqual(361);
    });
  }

  for (const info of INFO_PAGES) {
    test(`${info.href} fits a 360px phone`, async ({ page }) => {
      await page.setViewportSize({ width: 360, height: 800 });
      await page.goto(info.href);

      const documentWidth = await page.evaluate(() => document.documentElement.scrollWidth);
      expect(documentWidth, `${info.href} scrolls sideways at 360px`).toBeLessThanOrEqual(361);
    });
  }
});
