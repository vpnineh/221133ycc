import { test, expect, type Page } from "./fixtures";
import { publishedTools } from "../../src/lib/tools.data.mjs";

/**
 * A health check across every tool, rather than deep coverage of a few.
 *
 * The per-tool suites assert that each engine is correct. This one asserts the
 * things that are true of *all* of them and therefore nobody remembers to check
 * on any of them: that the page hydrates without throwing, that the tool region
 * actually contains controls, that a tool with an output offers a way to take
 * it, and that no request carries a payload.
 *
 * A React error boundary or a hydration mismatch is invisible in a screenshot —
 * the server-rendered markup is still there, it simply stops responding. That
 * is exactly how the `useNow` infinite-loop bug shipped, and why a console
 * check across the whole catalogue earns its runtime.
 */

interface ToolEntry {
  href: string;
  name: string;
}

const TOOLS: ToolEntry[] = publishedTools();

/** Console messages that are noise rather than a defect. */
function isIgnorable(text: string): boolean {
  return (
    // Chromium logs this for any favicon it cannot find in a headless run.
    /favicon/i.test(text) ||
    // The static server sends no-cache; the browser complains about nothing.
    /net::ERR_ABORTED/.test(text)
  );
}

async function collectErrors(page: Page): Promise<string[]> {
  const errors: string[] = [];
  page.on("console", (message) => {
    if (message.type() === "error" && !isIgnorable(message.text())) errors.push(message.text());
  });
  page.on("pageerror", (error) => errors.push(String(error)));
  return errors;
}

for (const tool of TOOLS) {
  test.describe(tool.name, () => {
    test(`${tool.href} hydrates and offers working controls`, async ({ page }) => {
      const errors = await collectErrors(page);
      await page.goto(tool.href);

      // The region ToolShell labels, which every tool page has.
      const region = page.getByRole("region", { name: new RegExp(`${escape(tool.name)} tool`, "i") });
      const hasRegion = (await region.count()) > 0;
      const surface = hasRegion ? region : page.getByRole("main");

      // A tool with no interactive control is a page pretending to be a tool.
      const controls = surface.locator(
        "input, textarea, select, button, [contenteditable='true']"
      );
      expect(await controls.count(), `${tool.href} renders no controls`).toBeGreaterThan(0);

      // Hydration: a React client component that threw leaves its markup in
      // place and stops responding, so the only reliable signal is the console.
      await page.waitForTimeout(400);
      expect(errors, `${tool.href} logged: ${errors.join(" | ")}`).toEqual([]);
    });
  });
}

test.describe("across the catalogue", () => {
  test("no tool page issues a request carrying a body on load", async ({ page }) => {
    const bodies: string[] = [];
    page.on("request", (request) => {
      if (request.postData()) bodies.push(`${request.method()} ${request.url()}`);
    });

    for (const tool of TOOLS.slice(0, 12)) {
      await page.goto(tool.href);
    }
    expect(bodies).toEqual([]);
  });

  test("every tool page reaches the catalogue and the directory", async ({ request }) => {
    // One sample is enough: the header is shared. This is a guard against a
    // future layout change dropping the nav from a route group.
    for (const tool of TOOLS.slice(0, 5)) {
      const html = await (await request.get(tool.href)).text();
      expect(html, `${tool.href} has no link to the directory`).toContain('href="/all-tools"');
    }
  });
});

function escape(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
