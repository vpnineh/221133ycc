import { test, expect, type Page } from "./fixtures";

/**
 * Functional smoke tests for the Phase A utilities.
 *
 * The all-pages suite proves each route serves a 200 with a title and valid
 * JSON-LD; that a client component mounted and produced the right output is a
 * different question, and it is the one a user cares about.
 */

function tool(page: Page, keyword: string) {
  return page.getByRole("region", { name: `${keyword} tool` });
}

test.describe("URL encoder", () => {
  test("encodes a component and tells + apart from a space", async ({ page }) => {
    await page.goto("/url-encode-decode");
    const input = page.locator("textarea").first();
    const output = page.locator("textarea").nth(1);

    await input.fill("a + b");
    expect(await output.inputValue()).toBe("a%20%2B%20b");

    // Form mode: a space is +, and a literal + must become %2B or the two are
    // indistinguishable after a round trip.
    await page.getByRole("button", { name: "Form", exact: true }).click();
    expect(await output.inputValue()).toBe("a+%2B+b");
  });

  test("counts double-encoding", async ({ page }) => {
    await page.goto("/url-encode-decode");
    await page.getByRole("button", { name: "Decode" }).click();
    await page.locator("textarea").first().fill("a%2520b");
    await expect(
      tool(page, "URL Encoder and Decoder").getByText("encoded 2 times", { exact: true })
    ).toBeVisible();
  });

  test("breaks a URL into components", async ({ page }) => {
    await page.goto("/url-encode-decode");
    await page.locator("textarea").first().fill("https://example.com:8443/a?x=1&x=2#f");
    const region = tool(page, "URL Encoder and Decoder");
    await expect(region.getByRole("cell", { name: "example.com", exact: true })).toBeVisible();
    await expect(region.getByRole("cell", { name: "8443", exact: true })).toBeVisible();
  });
});

test.describe("Hash generator", () => {
  test("computes the canonical SHA-256 and MD5 of abc", async ({ page }) => {
    await page.goto("/hash-generator");
    await page.locator("textarea").first().fill("abc");

    const region = tool(page, "Hash Generator");
    await expect(
      region.getByText("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    ).toBeVisible();
    await expect(region.getByText("900150983cd24fb0d6963f7d28e17f72")).toBeVisible();
  });

  test("labels MD5 and SHA-1 as broken", async ({ page }) => {
    await page.goto("/hash-generator");
    const region = tool(page, "Hash Generator");
    // Two rows, both marked broken — the most important thing the page says.
    await expect(region.getByRole("cell", { name: "broken", exact: true })).toHaveCount(2);
  });
});

test.describe("Timestamp converter", () => {
  test("resolves the epoch and reports the unit it inferred", async ({ page }) => {
    await page.goto("/timestamp-converter");
    await page.getByLabel("Timestamp or date").fill("0");

    const region = tool(page, "Unix Timestamp Converter");
    await expect(region.getByText("1970-01-01T00:00:00.000Z")).toBeVisible();
    await expect(region.getByText(/Read as .*seconds/)).toBeVisible();
  });

  test("resolves the 2038 boundary", async ({ page }) => {
    await page.goto("/timestamp-converter");
    await page.getByLabel("Timestamp or date").fill("2147483647");
    await expect(
      tool(page, "Unix Timestamp Converter").getByText("2038-01-19T03:14:07.000Z")
    ).toBeVisible();
  });
});

test.describe("Number base converter", () => {
  test("converts 255 across the common bases", async ({ page }) => {
    await page.goto("/number-base-converter");
    await page.getByLabel("Value").fill("255");

    const region = tool(page, "Number Base Converter");
    await expect(region.getByRole("cell", { name: "1111 1111" })).toBeVisible();
    await expect(region.getByRole("cell", { name: "377", exact: true })).toBeVisible();
    await expect(region.getByRole("cell", { name: "ff", exact: true })).toBeVisible();
  });

  test("keeps every digit past 2^53, where parseInt loses one", async ({ page }) => {
    await page.goto("/number-base-converter");
    await page.getByLabel("Value").fill("9007199254740993");
    await page.getByLabel("Group digits").uncheck();
    await expect(
      tool(page, "Number Base Converter").getByRole("cell", { name: "9007199254740993" })
    ).toBeVisible();
  });
});

test.describe("Cron expression", () => {
  test("explains a weekday schedule and lists its next runs", async ({ page }) => {
    await page.goto("/cron-expression");
    await page.getByRole("textbox", { name: "Expression" }).fill("0 9 * * 1-5");

    const region = tool(page, "Cron Expression Parser");
    await expect(region.getByText(/At 09:00/)).toBeVisible();
    await expect(region.getByText(/Monday, Tuesday/)).toBeVisible();
  });

  test("warns about the day-field OR, which is the whole point", async ({ page }) => {
    await page.goto("/cron-expression");
    await page.getByRole("textbox", { name: "Expression" }).fill("0 0 13 * 5");
    await expect(
      tool(page, "Cron Expression Parser").getByText(/Cron cannot express the intersection/)
    ).toBeVisible();
  });

  test("reports a schedule that can never fire", async ({ page }) => {
    await page.goto("/cron-expression");
    await page.getByRole("textbox", { name: "Expression" }).fill("0 0 31 2 *");
    await expect(
      tool(page, "Cron Expression Parser").getByText(/never fires in the next five years/)
    ).toBeVisible();
  });
});

test.describe("Regex tester", () => {
  test("matches and shows capture groups", async ({ page }) => {
    await page.goto("/regex-tester");
    await page.getByLabel("Pattern").fill("(\\w+)@(\\w+\\.\\w+)");
    await page.locator("textarea").first().fill("ada@example.com and grace@example.org");

    const region = tool(page, "Regex Tester");
    // Substring matching resolves to two nodes — the input textarea holds the
    // same string the highlight span does — so match the highlights exactly.
    await expect(region.getByText("ada@example.com", { exact: true })).toBeVisible();
    await expect(region.getByText("grace@example.org", { exact: true })).toBeVisible();
  });

  test("terminates a catastrophically backtracking pattern instead of hanging", async ({
    page,
  }) => {
    // The whole reason the tool uses a worker: this pattern cannot be
    // interrupted, so the thread running it has to be destroyed.
    await page.goto("/regex-tester");
    await page.getByLabel("Pattern").fill("(a+)+$");
    await page.locator("textarea").first().fill(`${"a".repeat(40)}!`);

    const region = tool(page, "Regex Tester");
    await expect(region.getByText(/Terminated after/)).toBeVisible({ timeout: 10_000 });
    // The page is still responsive, which is the point.
    await expect(page.getByLabel("Pattern")).toBeEditable();
  });

  test("flags a nested quantifier before it is even run", async ({ page }) => {
    await page.goto("/regex-tester");
    await page.getByLabel("Pattern").fill("(a+)+$");
    await expect(tool(page, "Regex Tester").getByText("Nested quantifier")).toBeVisible();
  });

  test("breaks the pattern down token by token", async ({ page }) => {
    await page.goto("/regex-tester");
    await page.getByLabel("Pattern").fill("^\\d{3}$");
    const region = tool(page, "Regex Tester");
    await expect(region.getByRole("cell", { name: "any digit, 0 to 9" })).toBeVisible();
  });
});

test.describe("Formatters", () => {
  test("SQL formatter does not break a keyword inside a string", async ({ page }) => {
    await page.goto("/sql-formatter");
    await page.locator("textarea").first().fill("select a, 'FROM cache' as s from t");
    const output = await page.locator("textarea").nth(1).inputValue();
    expect(output).toContain("'FROM cache'");
    expect(output).toMatch(/^SELECT$/m);
  });

  test("CSS formatter keeps a brace inside a string", async ({ page }) => {
    await page.goto("/css-formatter");
    await page.locator("textarea").first().fill('a{content:"}";color:red}');
    const output = await page.locator("textarea").nth(1).inputValue();
    expect(output).toContain('content: "}"');
    expect(output).toContain("color: red;");
  });

  test("HTML formatter does not indent after a void element", async ({ page }) => {
    await page.goto("/html-formatter");
    await page.locator("textarea").first().fill("<div><hr><p>x</p></div>");
    expect(await page.locator("textarea").nth(1).inputValue()).toBe(
      "<div>\n  <hr>\n  <p>\n    x\n  </p>\n</div>\n"
    );
  });

  test("HTML formatter reports a missing alt attribute", async ({ page }) => {
    await page.goto("/html-formatter");
    await page.locator("textarea").first().fill('<img src="a.png">');
    await expect(
      tool(page, "HTML Formatter and Minifier").getByText(/no alt attribute/)
    ).toBeVisible();
  });
});

test.describe("Case converter", () => {
  test("splits an acronym correctly across every style", async ({ page }) => {
    await page.goto("/case-converter");
    await page.locator("textarea").first().fill("XMLHttpRequest");

    const region = tool(page, "Case Converter");
    await expect(region.getByText("xml_http_request", { exact: true })).toBeVisible();
    await expect(region.getByText("xmlHttpRequest", { exact: true })).toBeVisible();
    await expect(region.getByText("XML_HTTP_REQUEST", { exact: true })).toBeVisible();
  });
});

test.describe("Lorem ipsum", () => {
  test("generates the requested number of paragraphs, deterministically", async ({ page }) => {
    await page.goto("/lorem-ipsum");
    await page.getByLabel("Count").fill("2");

    const output = page.locator("textarea").first();
    const first = await output.inputValue();
    expect(first.startsWith("Lorem ipsum dolor sit amet")).toBe(true);
    expect(first.split("\n\n")).toHaveLength(2);

    // Reroll changes it; the same seed would not.
    await page.getByRole("button", { name: "Reroll" }).click();
    expect(await output.inputValue()).not.toBe(first);
  });

  test("the Unicode mode produces non-ASCII, which is its entire job", async ({ page }) => {
    await page.goto("/lorem-ipsum");
    await page.getByRole("button", { name: "Unicode" }).click();
    const output = await page.locator("textarea").first().inputValue();
    expect(/[^\u0000-\u007f]/.test(output)).toBe(true);
  });
});

test.describe("QR code generator", () => {
  test("renders a symbol and reports its version and mode", async ({ page }) => {
    await page.goto("/qr-code-generator");
    const region = tool(page, "QR Code Generator");
    await expect(region.locator("svg").first()).toBeVisible();
    await expect(region.getByText("byte", { exact: true })).toBeVisible();
  });

  test("uses a bigger symbol at a higher error-correction level", async ({ page }) => {
    await page.goto("/qr-code-generator");
    const region = tool(page, "QR Code Generator");
    const versionCell = region.locator("dd").first();
    const low = await versionCell.textContent();

    await page.getByRole("button", { name: "H", exact: true }).click();
    const high = await versionCell.textContent();
    expect(high).not.toBe(low);
  });

  test("builds a Wi-Fi payload and warns what a printed code exposes", async ({ page }) => {
    await page.goto("/qr-code-generator");
    await page.getByRole("button", { name: "Wi-Fi" }).click();
    await page.getByLabel("Network name (SSID)").fill("MyNet");
    await page.getByLabel("Password", { exact: true }).fill("hunter2");

    const region = tool(page, "QR Code Generator");
    await expect(region.getByText("WIFI:T:WPA;S:MyNet;P:hunter2;;")).toBeVisible();
    await expect(region.getByText(/anyone who photographs the code can read/)).toBeVisible();
  });
});
