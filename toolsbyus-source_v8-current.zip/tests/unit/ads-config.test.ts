import { describe, it, expect } from "vitest";
import {
  buildAdsConfig,
  normalisePublisherId,
  AD_SCRIPT_HOSTS,
  AD_FRAME_HOSTS,
  AD_CONNECT_HOSTS,
} from "../../src/lib/ads.data.mjs";

/**
 * The AdSense configuration had two independent defects, both silent.
 *
 * 1. `data-ad-slot` received a page slug (`ad-slot-a-json-diff`) where a
 *    numeric ad-unit ID belongs. AdSense answers an unknown unit with an empty
 *    response and no error, so the slots would have stayed blank forever with
 *    nothing in the console to explain it.
 * 2. The runtime wanted `ca-pub-…` while the ads.txt generator wanted `pub-…`
 *    and stripped a leading `ca-`. Whichever form the operator configured, one
 *    of the two was wrong.
 *
 * Both now go through one normaliser, and these cases pin it.
 */
describe("publisher ID normalisation", () => {
  it("accepts the dashboard's ca-pub form", () => {
    expect(normalisePublisherId("ca-pub-1234567890123456")).toEqual({
      publisherId: "pub-1234567890123456",
      clientId: "ca-pub-1234567890123456",
    });
  });

  it("accepts the bare pub form and derives the client ID", () => {
    expect(normalisePublisherId("pub-1234567890123456")).toEqual({
      publisherId: "pub-1234567890123456",
      clientId: "ca-pub-1234567890123456",
    });
  });

  it("tolerates surrounding whitespace, which env files routinely carry", () => {
    expect(normalisePublisherId("  ca-pub-1234567890123456\n")?.publisherId).toBe(
      "pub-1234567890123456"
    );
  });

  it.each([
    ["", "empty"],
    [undefined, "unset"],
    ["pub-123", "too short"],
    ["pub-12345678901234567", "too long"],
    ["ca-pub-abcdefghijklmnop", "not digits"],
    ["1234567890123456", "no prefix"],
    ["ca-ca-pub-1234567890123456", "doubled prefix"],
  ])("rejects %s (%s)", (value: string | undefined, _why: string) => {
    expect(normalisePublisherId(value)).toBeNull();
  });
});

describe("ads configuration", () => {
  it("is disabled with no publisher ID", () => {
    const config = buildAdsConfig({});
    expect(config.enabled).toBe(false);
    expect(config.clientId).toBeNull();
    expect(config.publisherId).toBeNull();
    expect(config.units).toEqual({ top: null, mid: null });
  });

  it("stays disabled for a malformed publisher ID rather than half-enabling", () => {
    // A typo must not widen the CSP: a policy that trusts Google's ad origins
    // while serving no ads is strictly worse than the locked-down default.
    const config = buildAdsConfig({ NEXT_PUBLIC_ADSENSE_ID: "ca-pub-oops" });
    expect(config.enabled).toBe(false);
  });

  it("exposes both ID forms once configured", () => {
    const config = buildAdsConfig({
      NEXT_PUBLIC_ADSENSE_ID: "ca-pub-1234567890123456",
      NEXT_PUBLIC_AD_UNIT_TOP: "1234567890",
      NEXT_PUBLIC_AD_UNIT_MID: "0987654321",
    });
    expect(config.enabled).toBe(true);
    expect(config.clientId).toBe("ca-pub-1234567890123456");
    expect(config.publisherId).toBe("pub-1234567890123456");
    expect(config.units).toEqual({ top: "1234567890", mid: "0987654321" });
    expect(config.misconfigured).toBe(false);
  });

  it("rejects a slug in an ad-unit slot — the original bug", () => {
    const config = buildAdsConfig({
      NEXT_PUBLIC_ADSENSE_ID: "ca-pub-1234567890123456",
      NEXT_PUBLIC_AD_UNIT_TOP: "ad-slot-a-json-diff",
    });
    expect(config.units.top).toBeNull();
    expect(config.misconfigured).toBe(true);
  });

  it("flags a publisher ID with no ad units, which serves nothing", () => {
    const config = buildAdsConfig({ NEXT_PUBLIC_ADSENSE_ID: "pub-1234567890123456" });
    expect(config.enabled).toBe(true);
    expect(config.misconfigured).toBe(true);
  });
});

describe("CSP host lists", () => {
  it("includes the consent platform, without which the EEA sees no ads at all", () => {
    // Google requires a certified CMP for EEA/UK traffic. Funding Choices is
    // Google's own, and it is loaded and framed from this host.
    expect(AD_SCRIPT_HOSTS).toContain("https://fundingchoicesmessages.google.com");
    expect(AD_FRAME_HOSTS).toContain("https://fundingchoicesmessages.google.com");
  });

  it("includes the invalid-traffic endpoints AdSense itself requires", () => {
    expect(AD_SCRIPT_HOSTS).toContain("https://ep1.adtrafficquality.google");
    expect(AD_SCRIPT_HOSTS).toContain("https://ep2.adtrafficquality.google");
  });

  it("lists only https origins, with no paths and no wildcards", () => {
    for (const host of [...AD_SCRIPT_HOSTS, ...AD_FRAME_HOSTS, ...AD_CONNECT_HOSTS]) {
      expect(host, `${host} is not a bare https origin`).toMatch(/^https:\/\/[a-z0-9.-]+$/);
    }
  });
});
