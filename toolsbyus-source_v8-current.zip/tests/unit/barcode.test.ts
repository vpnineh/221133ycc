import { describe, it, expect } from "vitest";
import {
  BarcodeError,
  checkDigit,
  encodeBarcode,
  encodeCode39,
  encodeCode128,
  encodeItf14,
  printedWidthMm,
  renderSvg,
  SYMBOLOGIES,
} from "../../src/lib/barcode";

/**
 * A barcode fails silently in two directions, and both are tested here.
 *
 * A wrong check digit produces a symbol that scans perfectly and reports a
 * different number — the dangerous failure, because nothing looks wrong. A
 * missing quiet zone or inter-character gap produces a symbol that never scans
 * at all, which at least announces itself, but only against real hardware.
 */

describe("check digit", () => {
  /*
   * Real numbers with published check digits. Each of these is on a physical
   * product, which is the only way to be sure the weighting is anchored to the
   * right end — an implementation that weights from the left passes on
   * even-length input and fails on odd.
   */
  it("matches the published digit for EAN-13, UPC-A and EAN-8", () => {
    expect(checkDigit("978020137962")).toBe(4); // ISBN 978-0-201-37962-4
    expect(checkDigit("03600029145")).toBe(2); // UPC-A 036000291452
    expect(checkDigit("9638507")).toBe(4); // EAN-8 96385074
    expect(checkDigit("590123412345")).toBe(7);
  });

  it("returns 0 when the sum already lands on a multiple of ten", () => {
    // 0000000000000 sums to zero, and (10 - 0) % 10 is 0, not 10.
    expect(checkDigit("0000000000000")).toBe(0);
  });
});

describe("EAN-13", () => {
  const encoded = encodeBarcode("978020137962", "ean13");

  it("is 95 modules, which is what the standard fixes it at", () => {
    expect(encoded.modules).toHaveLength(95);
  });

  it("appends the check digit it calculated", () => {
    expect(encoded.text).toBe("9780201379624");
  });

  it("opens, splits and closes with the guard patterns", () => {
    expect(encoded.modules.slice(0, 3)).toEqual([1, 0, 1]);
    expect(encoded.modules.slice(45, 50)).toEqual([0, 1, 0, 1, 0]);
    expect(encoded.modules.slice(92)).toEqual([1, 0, 1]);
  });

  it("marks the guards so they can be drawn taller", () => {
    // Three at each end plus five in the middle.
    expect(encoded.guards).toHaveLength(11);
  });

  it("accepts a number that already carries its check digit", () => {
    expect(encodeBarcode("9780201379624", "ean13").modules).toEqual(encoded.modules);
  });

  /*
   * The dangerous case. A mistyped check digit would otherwise produce a
   * symbol that scans cleanly as a different product.
   */
  it("refuses a check digit that does not match, and says what it should be", () => {
    expect(() => encodeBarcode("9780201379620", "ean13")).toThrow(/checks to 4/);
  });

  it("refuses the wrong number of digits", () => {
    expect(() => encodeBarcode("12345", "ean13")).toThrow(BarcodeError);
    expect(() => encodeBarcode("12345", "ean13")).toThrow(/12 or 13 digits/);
  });

  it("ignores spaces and hyphens, because that is how ISBNs are written", () => {
    expect(encodeBarcode("978-0-201-37962", "ean13").text).toBe("9780201379624");
  });

  /*
   * The thirteenth digit has no bars of its own: it is carried entirely by
   * which pattern set each left-hand digit uses. Two numbers differing only in
   * the first digit must therefore differ in the left half and match in the
   * right.
   */
  it("encodes the leading digit as parity rather than as bars", () => {
    const zero = encodeBarcode("000000000000", "ean13");
    const one = encodeBarcode("100000000000", "ean13");
    expect(zero.modules.slice(3, 45)).not.toEqual(one.modules.slice(3, 45));
  });
});

describe("UPC-A", () => {
  const encoded = encodeBarcode("03600029145", "upca");

  it("carries the published check digit", () => {
    expect(encoded.text).toBe("036000291452");
  });

  /*
   * UPC-A is an EAN-13 with a leading zero. Encoding it that way rather than
   * with a second table is not a shortcut — it is the reason a UPC scans in
   * Europe.
   */
  it("is the same 95 modules as the equivalent EAN-13", () => {
    expect(encoded.modules).toEqual(encodeBarcode("003600029145", "ean13").modules);
  });

  it("groups the human-readable line the way a package prints it", () => {
    expect(encoded.display).toBe("0 36000 29145 2");
  });
});

describe("EAN-8", () => {
  const encoded = encodeBarcode("9638507", "ean8");

  it("is 67 modules", () => {
    expect(encoded.modules).toHaveLength(67);
  });

  it("carries the published check digit", () => {
    expect(encoded.text).toBe("96385074");
  });
});

describe("Code 128", () => {
  it("starts in set C and packs digit pairs when the value is all digits", () => {
    const encoded = encodeCode128("0123456789");
    // Start C, five pairs, checksum, stop: six 11-module symbols plus the
    // 13-module stop.
    expect(encoded.modules).toHaveLength(6 * 11 + 11 + 13);
  });

  it("starts in set B for text", () => {
    const encoded = encodeCode128("AB");
    // Start B, two characters, checksum, stop.
    expect(encoded.modules).toHaveLength(4 * 11 + 13);
  });

  /*
   * Set C is the whole reason to use Code 128 for a numeric value: it halves
   * the width, which on a 100mm label is the difference between fitting and
   * not.
   */
  it("is much narrower for a long number than the same length of letters", () => {
    const digits = encodeCode128("12345678901234567890");
    const letters = encodeCode128("ABCDEFGHIJKLMNOPQRST");
    expect(digits.modules.length).toBeLessThan(letters.modules.length * 0.62);
  });

  it("ends with the 13-module stop pattern", () => {
    const encoded = encodeCode128("TEST");
    expect(encoded.modules.slice(-13)).toEqual([1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1]);
  });

  it("handles an odd-length digit run by switching back to set B", () => {
    // The trailing 9 has no pair, so it cannot stay in set C.
    expect(() => encodeCode128("123456789")).not.toThrow();
    expect(encodeCode128("123456789").text).toBe("123456789");
  });

  it("takes the full printable ASCII range", () => {
    const value = " !\"#$%&'()*+,-./0123456789:;<=>?@ABC[\\]^_`abc{|}~";
    expect(() => encodeCode128(value)).not.toThrow();
  });

  it("refuses a control character instead of silently encoding something else", () => {
    expect(() => encodeCode128("a\tb")).toThrow(/printable ASCII/);
    expect(() => encodeCode128("café")).toThrow(/printable ASCII/);
  });

  it("refuses an empty value", () => {
    expect(() => encodeCode128("")).toThrow(BarcodeError);
  });
});

describe("Code 39", () => {
  it("wraps the value in the start and stop character", () => {
    expect(encodeCode39("A").display).toBe("*A*");
  });

  /*
   * The classic Code 39 bug: omit the one-module gap between characters and the
   * symbol looks perfect and scans as nothing.
   */
  it("puts a one-module space between every character", () => {
    const encoded = encodeCode39("AB");
    // Four characters at 12 modules each (* A B *), plus three gaps.
    expect(encoded.modules).toHaveLength(4 * 12 + 3);
  });

  it("upper-cases rather than refusing, because both encode identically", () => {
    expect(encodeCode39("abc").modules).toEqual(encodeCode39("ABC").modules);
    expect(encodeCode39("abc").text).toBe("ABC");
  });

  it("refuses a character outside the 43-symbol set", () => {
    expect(() => encodeCode39("A@B")).toThrow(/A–Z, 0–9/);
  });

  it("refuses the start character in the data, which would truncate the symbol", () => {
    expect(() => encodeCode39("A*B")).toThrow(/start and stop/);
  });
});

describe("ITF-14", () => {
  const encoded = encodeItf14("1234567890123");

  it("is 135 modules at the 3:1 wide-to-narrow ratio", () => {
    expect(encoded.modules).toHaveLength(135);
  });

  it("opens with the four-module start and closes with the stop", () => {
    expect(encoded.modules.slice(0, 4)).toEqual([1, 0, 1, 0]);
    expect(encoded.modules.slice(-5)).toEqual([1, 1, 1, 0, 1]);
  });

  it("appends the check digit", () => {
    expect(encoded.text).toHaveLength(14);
    expect(encoded.text.slice(0, 13)).toBe("1234567890123");
  });

  it("refuses a mismatched check digit", () => {
    const wrong = `1234567890123${(Number(encoded.text[13]) + 1) % 10}`;
    expect(() => encodeItf14(wrong)).toThrow(/check digit does not match/);
  });
});

describe("rendering", () => {
  const encoded = encodeBarcode("978020137962", "ean13");

  it("produces an SVG wide enough for the quiet zone on both sides", () => {
    const svg = renderSvg(encoded, { moduleWidth: 2 });
    const width = Number(/width="([\d.]+)"/.exec(svg)![1]);
    expect(width).toBe((95 + 11 * 2) * 2);
  });

  /*
   * A scanner's edge detector looks for exactly the kind of hairline seam that
   * appears between adjacent <rect>s at some zoom levels, so runs are merged.
   */
  it("merges adjacent bars into one rectangle", () => {
    const svg = renderSvg(encodeCode128("AAAA"));
    const rects = svg.match(/<rect/g)!.length;
    // One for the background, and far fewer than one per dark module.
    const darkModules = encodeCode128("AAAA").modules.filter((m) => m === 1).length;
    expect(rects).toBeLessThan(darkModules);
  });

  it("labels the symbol for a screen reader", () => {
    expect(renderSvg(encoded)).toContain('role="img"');
    expect(renderSvg(encoded)).toContain("9780201379624");
  });

  it("escapes the value rather than letting it close the element", () => {
    const svg = renderSvg(encodeCode128("a<b>&c"));
    expect(svg).not.toMatch(/<b>/);
    expect(svg).toContain("&lt;b&gt;");
  });

  it("omits the human-readable line when asked", () => {
    expect(renderSvg(encoded, { showText: false })).not.toContain("<text");
  });

  /*
   * The number that decides whether the symbol fits on the label, and whether
   * it is above the minimum X the standard sets for the substrate.
   */
  it("reports the printed width in millimetres", () => {
    expect(printedWidthMm(encoded, 0.33)).toBeCloseTo((95 + 22) * 0.33, 5);
  });
});

describe("the catalogue of symbologies", () => {
  it("lists a quiet zone for every one, because a symbol without it never scans", () => {
    for (const symbology of SYMBOLOGIES) {
      expect(symbology.quietZone, symbology.id).toBeGreaterThanOrEqual(7);
    }
  });

  it("can encode a valid value for every symbology it advertises", () => {
    const samples: Record<string, string> = {
      code128: "SHIP-4471",
      ean13: "978020137962",
      ean8: "9638507",
      upca: "03600029145",
      code39: "ABC-123",
      itf14: "1234567890123",
    };
    for (const symbology of SYMBOLOGIES) {
      const value = samples[symbology.id];
      expect(value, `no sample for ${symbology.id}`).toBeDefined();
      expect(() => encodeBarcode(value, symbology.id), symbology.id).not.toThrow();
    }
  });
});
