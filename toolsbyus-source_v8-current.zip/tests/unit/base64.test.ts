import { describe, it, expect } from "vitest";
import { encodeBase64, decodeBase64, inspectJwt, toUrlSafe } from "../../src/lib/base64";

describe("Base64 Encoder & Decoder", () => {
  it("handles standard and URL-safe base64 encoding/decoding", () => {
    const raw = "hello?query=test&value=123+456";
    const std = encodeBase64(raw, "standard", "utf-8");
    const urlSafe = encodeBase64(raw, "url-safe", "utf-8");

    expect(urlSafe).not.toContain("+");
    expect(urlSafe).not.toContain("/");
    expect(urlSafe).not.toContain("=");

    const decodedStd = decodeBase64(std, "utf-8");
    expect(decodedStd.text).toBe(raw);

    const decodedUrl = decodeBase64(urlSafe, "utf-8");
    expect(decodedUrl.text).toBe(raw);
  });

  it("handles UTF-8 multibyte characters and emojis cleanly", () => {
    const multiByte = "Hello 世界 🚀 Antigravity 2026";
    const encoded = encodeBase64(multiByte, "standard", "utf-8");
    const decoded = decodeBase64(encoded, "utf-8");
    expect(decoded.text).toBe(multiByte);
  });

  it("handles padding edge cases (lengths % 4)", () => {
    const inputs = ["a", "ab", "abc", "abcd"];
    for (const inp of inputs) {
      const enc = encodeBase64(inp, "standard");
      const dec = decodeBase64(enc);
      expect(dec.text).toBe(inp);

      const urlEnc = encodeBase64(inp, "url-safe");
      const urlDec = decodeBase64(urlEnc);
      expect(urlDec.text).toBe(inp);
    }
  });

  it("auto-detects and decodes JWT header and payload", () => {
    const headerObj = { alg: "HS256", typ: "JWT" };
    const payloadObj = { sub: "user_12345", name: "Alice Developer", iat: 1700000000 };

    const part1 = toUrlSafe(btoa(JSON.stringify(headerObj)));
    const part2 = toUrlSafe(btoa(JSON.stringify(payloadObj)));
    const part3 = "fake_signature_hash_bytes";
    const jwtString = `${part1}.${part2}.${part3}`;

    const inspection = inspectJwt(jwtString);
    expect(inspection.isJwt).toBe(true);
    expect(inspection.header.alg).toBe("HS256");
    expect(inspection.payload.sub).toBe("user_12345");
  });
});
