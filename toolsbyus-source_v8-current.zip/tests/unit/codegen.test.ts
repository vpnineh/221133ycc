import { describe, it, expect } from "vitest";
import {
  detectFormat,
  extractNamedTypes,
  inferType,
  merge,
  pascalCase,
  camelCase,
  snakeCase,
  safeName,
  safeTypeName,
  GO_KEYWORDS,
  PYTHON_KEYWORDS,
  CSHARP_KEYWORDS,
  JAVA_KEYWORDS,
  signature,
  singular,
  words,
  generate,
  goName,
  TYPESCRIPT_DEFAULTS,
  GO_DEFAULTS,
  PYTHON_DEFAULTS,
  CSHARP_DEFAULTS,
  JAVA_DEFAULTS,
  type TypeNode,
} from "../../src/lib/codegen";
import type { JsonValue } from "../../src/lib/json/types";

const ts = (value: JsonValue, name = "Root", options = TYPESCRIPT_DEFAULTS) =>
  generate(value, name, { target: "typescript", options }).code;
const go = (value: JsonValue, name = "Root", options = GO_DEFAULTS) =>
  generate(value, name, { target: "go", options }).code;
const py = (value: JsonValue, name = "Root", options = PYTHON_DEFAULTS) =>
  generate(value, name, { target: "python", options }).code;
const cs = (value: JsonValue, name = "Root", options = CSHARP_DEFAULTS) =>
  generate(value, name, { target: "csharp", options }).code;
const java = (value: JsonValue, name = "Root", options = JAVA_DEFAULTS) =>
  generate(value, name, { target: "java", options }).code;

describe("inference", () => {
  it("separates integers from floats", () => {
    expect(inferType(3).kind).toBe("integer");
    expect(inferType(3.5).kind).toBe("number");
  });

  it("flags an integer a 32-bit type cannot hold", () => {
    // Truncating a snowflake ID to int32 is a production-only bug.
    expect(inferType(9_007_199_254_740_991).wide).toBe(true);
    expect(inferType(42).wide).toBe(false);
  });

  it("detects string formats", () => {
    expect(detectFormat("3f2504e0-4f89-11d3-9a0c-0305e82c3301")).toBe("uuid");
    expect(detectFormat("2026-09-11T08:00:00Z")).toBe("date-time");
    expect(detectFormat("2026-09-11")).toBe("date");
    expect(detectFormat("ada@example.com")).toBe("email");
    expect(detectFormat("https://example.com/x")).toBe("uri");
    expect(detectFormat("hello")).toBeUndefined();
  });

  it("skips prototype-polluting keys", () => {
    const type = inferType(JSON.parse('{"a":1,"__proto__":{"x":1},"constructor":2}'));
    expect((type.fields ?? []).map((f) => f.key)).toEqual(["a"]);
  });

  it("stops at a depth ceiling instead of overflowing", () => {
    let deep: JsonValue = "leaf";
    for (let i = 0; i < 5_000; i++) deep = { n: deep };
    expect(() => inferType(deep)).not.toThrow();
  });

  it("types an empty array as an array of anything", () => {
    const type = inferType([]);
    expect(type.kind).toBe("array");
    expect(type.items?.kind).toBe("any");
  });
});

describe("merging", () => {
  it("makes a field optional when one sample lacks it", () => {
    // The test that separates a real converter from one that types the array
    // off its first element and loses every other key.
    const type = inferType([{ a: 1 }, { a: 1, b: 2 }]);
    const fields = type.items?.fields ?? [];
    expect(fields.map((f) => [f.key, f.optional])).toEqual([
      ["a", false],
      ["b", true],
    ]);
  });

  it("keeps a key seen only in a later record", () => {
    const type = inferType([{ a: 1 }, { b: 2 }]);
    expect((type.items?.fields ?? []).map((f) => f.key).sort()).toEqual(["a", "b"]);
  });

  it("widens integer and float to float", () => {
    expect(merge({ kind: "integer" }, { kind: "number" })).toEqual({ kind: "number" });
  });

  it("keeps wide when either side is wide", () => {
    expect(merge({ kind: "integer" }, { kind: "integer", wide: true }).wide).toBe(true);
  });

  it("turns null alongside a value into nullable, not a union", () => {
    const type = inferType([{ a: 1 }, { a: null }]);
    const field = (type.items?.fields ?? [])[0];
    expect(field.type.kind).toBe("integer");
    expect(field.type.nullable).toBe(true);
  });

  it("keeps a genuinely mixed type as a union", () => {
    const type = inferType([1, "x"]);
    expect(type.items?.kind).toBe("union");
    expect((type.items?.members ?? []).map((m) => m.kind).sort()).toEqual(["integer", "string"]);
  });

  it("flattens nested unions", () => {
    const type = inferType([1, "x", true]);
    expect(type.items?.members).toHaveLength(3);
    expect((type.items?.members ?? []).every((m) => m.kind !== "union")).toBe(true);
  });

  it("drops a format the samples disagree on", () => {
    const type = inferType(["ada@example.com", "hello"]);
    expect(type.items?.format).toBeUndefined();
  });

  it("merges element types across a heterogeneous array", () => {
    const type = inferType([{ a: 1 }, { a: 2.5 }]);
    expect((type.items?.fields ?? [])[0].type.kind).toBe("number");
  });

  it("treats any as the identity", () => {
    expect(merge({ kind: "any" }, { kind: "string" })).toEqual({ kind: "string" });
    expect(merge({ kind: "string" }, { kind: "any" })).toEqual({ kind: "string" });
  });
});

describe("signature and deduplication", () => {
  it("gives identical shapes the same signature regardless of key order", () => {
    const a = inferType({ x: 1, y: "s" });
    const b = inferType({ y: "s", x: 1 });
    expect(signature(a)).toBe(signature(b));
  });

  it("distinguishes a nullable field from a non-nullable one", () => {
    const a: TypeNode = { kind: "string" };
    const b: TypeNode = { kind: "string", nullable: true };
    expect(signature(a)).not.toBe(signature(b));
  });

  it("generates one type for fifty identical nested objects", () => {
    // Without deduplication this is Address, Address2 … Address50.
    const doc = {
      people: Array.from({ length: 50 }, (_, i) => ({
        name: `p${i}`,
        address: { city: "London", postcode: "E1" },
      })),
    };
    const result = generate(doc as JsonValue, "Root", {
      target: "typescript",
      options: TYPESCRIPT_DEFAULTS,
    });
    expect(result.names.filter((n) => n.startsWith("Address"))).toEqual(["Address"]);
  });

  it("does not merge two shapes that differ", () => {
    const doc = { a: { x: 1 }, b: { y: 1 } };
    const result = generate(doc as JsonValue, "Root", {
      target: "typescript",
      options: TYPESCRIPT_DEFAULTS,
    });
    expect(result.names).toHaveLength(3);
  });

  it("declares a nested type before the type that uses it", () => {
    const doc = { user: { address: { city: "London" } } };
    const code = ts(doc as JsonValue);
    expect(code.indexOf("interface Address")).toBeLessThan(code.indexOf("interface User"));
  });
});

describe("naming", () => {
  it("splits identifiers of any convention", () => {
    expect(words("user_name")).toEqual(["user", "name"]);
    expect(words("userName")).toEqual(["user", "Name"]);
    expect(words("user-name")).toEqual(["user", "name"]);
    expect(words("HTTPServer")).toEqual(["HTTP", "Server"]);
  });

  it("converts cases", () => {
    expect(pascalCase("user_name")).toBe("UserName");
    expect(camelCase("user_name")).toBe("userName");
    expect(snakeCase("userName")).toBe("user_name");
  });

  it("prefixes a name that would start with a digit", () => {
    expect(pascalCase("2fa")).toBe("N2fa");
    expect(snakeCase("2fa")).toBe("n_2fa");
  });

  it("escapes only the target's own keywords, matched exactly", () => {
    // A union keyword set would rename `ref` in Go, Python and Java to protect
    // C#, and `type` everywhere to protect Go. Both are common JSON keys.
    expect(safeName("class", PYTHON_KEYWORDS)).toBe("class_");
    expect(safeName("ref", PYTHON_KEYWORDS)).toBe("ref");
    expect(safeName("ref", CSHARP_KEYWORDS)).toBe("ref_");
    expect(safeName("Ref", CSHARP_KEYWORDS)).toBe("Ref");
    expect(safeName("type", GO_KEYWORDS)).toBe("type_");
    expect(safeName("Type", GO_KEYWORDS)).toBe("Type");
    expect(safeName("city", JAVA_KEYWORDS)).toBe("city");
  });

  it("renames a generated type that would shadow a built-in", () => {
    expect(safeTypeName("String")).toBe("StringType");
    expect(safeTypeName("Address")).toBe("Address");
  });

  it("singularises array names in the common cases", () => {
    expect(singular("users")).toBe("user");
    expect(singular("categories")).toBe("category");
    expect(singular("boxes")).toBe("box");
    expect(singular("status")).toBe("status");
    expect(singular("address")).toBe("address");
  });

  it("names an array-of-object field in the singular", () => {
    const result = generate({ users: [{ id: 1 }] } as JsonValue, "Root", {
      target: "typescript",
      options: TYPESCRIPT_DEFAULTS,
    });
    expect(result.names).toContain("User");
  });

  it("disambiguates a colliding name rather than overwriting", () => {
    const doc = { user: { a: 1 }, other: { user: { b: 2 } } };
    const result = generate(doc as JsonValue, "Root", {
      target: "typescript",
      options: TYPESCRIPT_DEFAULTS,
    });
    expect(new Set(result.names).size).toBe(result.names.length);
    expect(result.names).toContain("User2");
  });
});

describe("TypeScript output", () => {
  it("emits an interface with the original keys", () => {
    expect(ts({ user_id: 1, name: "Ada" } as JsonValue)).toContain("export interface Root {");
    expect(ts({ user_id: 1 } as JsonValue)).toContain("user_id: number;");
  });

  it("marks optional fields with ?", () => {
    expect(ts([{ a: 1 }, { a: 1, b: 2 }] as JsonValue)).toContain("b?: number;");
  });

  it("renders nullable as a union with null", () => {
    expect(ts([{ a: 1 }, { a: null }] as JsonValue)).toContain("a: number | null;");
  });

  it("quotes a key that is not a valid identifier", () => {
    expect(ts({ "content-type": "x" } as JsonValue)).toContain('"content-type": string;');
  });

  it("parenthesises a union inside an array", () => {
    // `string | number[]` would mean something different.
    expect(ts({ mixed: [1, "x"] } as JsonValue)).toContain("mixed: (number | string)[];");
  });

  it("renames to camelCase on request and records the JSON key", () => {
    const code = ts({ user_id: 1 } as JsonValue, "Root", {
      ...TYPESCRIPT_DEFAULTS,
      camelCaseKeys: true,
    });
    expect(code).toContain("userId: number; // JSON key: user_id");
  });

  it("emits type aliases when asked", () => {
    const code = ts({ a: 1 } as JsonValue, "Root", {
      ...TYPESCRIPT_DEFAULTS,
      useInterfaces: false,
    });
    expect(code).toContain("export type Root = {");
    expect(code.trimEnd().endsWith("};")).toBe(true);
  });

  it("reports an array root as an array of the singular type", () => {
    const result = generate([{ id: 1 }] as JsonValue, "User", {
      target: "typescript",
      options: TYPESCRIPT_DEFAULTS,
    });
    expect(result.rootExpression).toBe("User[]");
  });
});

describe("Go output", () => {
  it("exports every field and tags it with the JSON key", () => {
    const code = go({ user_id: 1 } as JsonValue);
    // An unexported field is silently dropped by encoding/json.
    expect(code).toMatch(/UserID\s+int\s+`json:"user_id"`/);
  });

  it("capitalises initialisms the way Go's style guide does", () => {
    expect(goName("api_url")).toBe("APIURL");
    expect(goName("user_id")).toBe("UserID");
    expect(goName("city")).toBe("City");
  });

  it("points at optional fields so absent differs from the zero value", () => {
    const code = go([{ a: 1 }, { a: 1, b: "x" }] as JsonValue);
    expect(code).toMatch(/B\s+\*string\s+`json:"b,omitempty"`/);
  });

  it("does not point at a slice, which is already nilable", () => {
    const code = go([{ a: 1 }, { a: 1, b: ["x"] }] as JsonValue);
    expect(code).toContain("[]string");
    expect(code).not.toContain("*[]string");
  });

  it("picks int64 for a value int cannot hold", () => {
    expect(go({ id: 9_007_199_254_740_991 } as JsonValue)).toContain("int64");
  });

  it("emits interface{} for a union, not a fictional sum type", () => {
    expect(go({ mixed: [1, "x"] } as JsonValue)).toContain("[]interface{}");
  });

  it("aligns struct columns so gofmt produces no diff", () => {
    const code = go({ a: 1, longer_name: "x" } as JsonValue);
    const lines = code.split("\n").filter((l) => l.startsWith("\t"));
    const tagColumns = lines.map((l) => l.indexOf("`json:"));
    expect(new Set(tagColumns).size).toBe(1);
  });

  it("uses the requested package name", () => {
    expect(go({ a: 1 } as JsonValue, "Root", { ...GO_DEFAULTS, packageName: "models" })).toContain(
      "package models"
    );
  });
});

describe("Python output", () => {
  it("emits a dataclass with snake_case fields", () => {
    const code = py({ userId: 1 } as JsonValue);
    expect(code).toContain("from dataclasses import dataclass");
    expect(code).toContain("@dataclass");
    expect(code).toContain("user_id: int  # JSON key: userId");
  });

  it("puts required fields before defaulted ones", () => {
    // A dataclass field without a default cannot follow one with a default;
    // getting this wrong raises TypeError at import time.
    const code = py([{ a: 1 }, { a: 1, b: 2 }, { b: 2, c: 3 }] as JsonValue);
    const body = code.slice(code.indexOf("class "));
    expect(body.indexOf("a: int")).toBeLessThan(body.indexOf("= None"));
  });

  it("emits Optional for nullable values", () => {
    const code = py([{ a: 1 }, { a: null }] as JsonValue);
    expect(code).toContain("Optional[int]");
    expect(code).toContain("from typing import");
  });

  it("emits modern unions on request", () => {
    const code = py([{ a: 1 }, { a: null }] as JsonValue, "Root", {
      ...PYTHON_DEFAULTS,
      modernOptional: true,
    });
    expect(code).toContain("int | None");
    expect(code).not.toContain("Optional[");
  });

  it("emits a TypedDict with NotRequired for optional keys", () => {
    const code = py([{ a: 1 }, { a: 1, b: 2 }] as JsonValue, "Root", {
      ...PYTHON_DEFAULTS,
      style: "typeddict",
    });
    expect(code).toContain("class Root(TypedDict):");
    expect(code).toContain("b: NotRequired[int]");
    expect(code).toContain("from typing_extensions import NotRequired, TypedDict");
  });

  it("emits pydantic models with aliases for renamed keys", () => {
    const code = py({ userId: 1 } as JsonValue, "Root", {
      ...PYTHON_DEFAULTS,
      style: "pydantic",
    });
    expect(code).toContain("from pydantic import BaseModel, Field");
    expect(code).toContain('user_id: int = Field(..., alias="userId")');
  });

  it("quotes a forward reference to a class", () => {
    const code = py({ user: { id: 1 } } as JsonValue);
    expect(code).toContain('user: "User"');
  });
});

describe("C# output", () => {
  it("emits PascalCase properties with JsonPropertyName", () => {
    const code = cs({ user_id: 1 } as JsonValue);
    expect(code).toContain('[JsonPropertyName("user_id")]');
    expect(code).toContain("public int UserId { get; set; }");
  });

  it("initialises non-nullable reference members so CS8618 does not fire", () => {
    expect(cs({ name: "Ada" } as JsonValue)).toContain(
      "public string Name { get; set; } = null!;"
    );
  });

  it("marks optional members nullable", () => {
    const code = cs([{ a: 1 }, { a: 1, b: 2 }] as JsonValue);
    expect(code).toContain("public int? B { get; set; }");
  });

  it("switches to Newtonsoft on request", () => {
    const code = cs({ a: 1 } as JsonValue, "Root", {
      ...CSHARP_DEFAULTS,
      systemTextJson: false,
    });
    expect(code).toContain("using Newtonsoft.Json;");
    expect(code).toContain('[JsonProperty("a")]');
  });

  it("wraps in a namespace when one is given", () => {
    expect(cs({ a: 1 } as JsonValue)).toContain("namespace Generated");
    expect(cs({ a: 1 } as JsonValue, "Root", { ...CSHARP_DEFAULTS, namespaceName: "" })).not.toContain(
      "namespace"
    );
  });

  it("emits records on request", () => {
    expect(cs({ a: 1 } as JsonValue, "Root", { ...CSHARP_DEFAULTS, style: "record" })).toContain(
      "public record Root"
    );
  });

  it("uses long for a wide integer", () => {
    expect(cs({ id: 9_007_199_254_740_991 } as JsonValue)).toContain("public long Id");
  });
});

describe("Java output", () => {
  it("emits a record with Jackson annotations", () => {
    const code = java({ user_id: 1 } as JsonValue);
    expect(code).toContain("public record Root(");
    expect(code).toContain('@JsonProperty("user_id") int userId');
  });

  it("boxes an optional primitive so absent is not zero", () => {
    // `int b` would deserialize a missing key to 0, which is indistinguishable
    // from a real zero.
    const code = java([{ a: 1 }, { a: 1, b: 2 }] as JsonValue);
    expect(code).toContain("Integer b");
  });

  it("boxes list elements, which cannot be primitives", () => {
    expect(java({ ids: [1, 2] } as JsonValue)).toContain("List<Integer>");
  });

  it("emits a POJO with getters and setters on request", () => {
    const code = java({ user_id: 1 } as JsonValue, "Root", { ...JAVA_DEFAULTS, style: "pojo" });
    expect(code).toContain("public class Root {");
    expect(code).toContain("private int userId;");
    expect(code).toContain("public int getUserId() {");
    expect(code).toContain("public void setUserId(int userId) {");
  });

  it("imports only what it uses", () => {
    expect(java({ a: 1 } as JsonValue)).not.toContain("import java.util.List;");
    expect(java({ a: [1] } as JsonValue)).toContain("import java.util.List;");
  });

  it("adds a package declaration when one is given", () => {
    expect(java({ a: 1 } as JsonValue, "Root", { ...JAVA_DEFAULTS, packageName: "com.x" })).toContain(
      "package com.x;"
    );
  });
});

describe("cross-target agreement", () => {
  const doc: JsonValue = [
    { id: 1, name: "Ada", tags: ["a"], meta: { ok: true } },
    { id: 2, name: "Grace", tags: [], meta: { ok: false }, note: null, score: 9.5 },
  ] as JsonValue;

  it("all five agree on which fields are optional", () => {
    // note and score appear in one record only.
    expect(ts(doc, "User")).toContain("score?: number;");
    expect(go(doc, "User")).toContain("*float64");
    expect(py(doc, "User")).toContain("= None");
    expect(cs(doc, "User")).toContain("public double? Score");
    expect(java(doc, "User")).toContain("Double score");
  });

  it("every target produces a non-empty file for the same document", () => {
    for (const code of [ts(doc, "User"), go(doc, "User"), py(doc, "User"), cs(doc, "User"), java(doc, "User")]) {
      expect(code.length).toBeGreaterThan(40);
      expect(code).toContain("User");
    }
  });

  it("handles a scalar root without crashing", () => {
    for (const emit of [ts, go, py, cs, java]) {
      expect(() => emit(42 as JsonValue)).not.toThrow();
    }
  });

  it("names the root type from the given name", () => {
    expect(ts({ a: 1 } as JsonValue, "Payload")).toContain("interface Payload");
    expect(go({ a: 1 } as JsonValue, "Payload")).toContain("type Payload struct");
    expect(py({ a: 1 } as JsonValue, "Payload")).toContain("class Payload");
    expect(cs({ a: 1 } as JsonValue, "Payload")).toContain("class Payload");
    expect(java({ a: 1 } as JsonValue, "Payload")).toContain("record Payload");
  });

  it("escapes a key that is a keyword in the target, and only there", () => {
    const doc2 = { class: 1, type: "x", ref: "y" } as JsonValue;
    // `ref` is a C# keyword and nothing else; `class` is a keyword in three of
    // the five. A shared keyword set would mangle all of them everywhere.
    expect(go(doc2)).toContain("Class");
    expect(go(doc2)).toContain("Ref ");
    expect(py(doc2)).toContain("class_");
    expect(py(doc2)).toContain("ref: str");
    expect(cs(doc2)).toContain("public string Ref { get; set; }");
    const pojo = java(doc2, "Root", { ...JAVA_DEFAULTS, style: "pojo" });
    expect(pojo).toContain("class_");
    expect(pojo).toContain("private String ref;");
  });

  it("types a field that was only ever null as unknown and nullable", () => {
    const doc2 = { deleted_at: null } as JsonValue;
    expect(ts(doc2)).toContain("deleted_at: unknown; // only null in the sample");
    expect(py(doc2)).toContain("Optional[Any]");
    expect(cs(doc2)).toContain("public object? DeletedAt { get; set; }");
    expect(java(doc2)).toContain("Object deletedAt");
  });

  it("warns that a multi-type Java file needs splitting", () => {
    expect(java({ a: { b: 1 } } as JsonValue)).toContain("one public type per file");
    expect(java({ a: 1 } as JsonValue)).not.toContain("one public type per file");
  });
});

describe("named type extraction", () => {
  it("returns the root first", () => {
    const root = inferType({ inner: { a: 1 } } as JsonValue);
    const types = extractNamedTypes(root, "Root");
    expect(types[0].name).toBe("Root");
  });

  it("returns nothing for a document with no objects", () => {
    expect(extractNamedTypes(inferType([1, 2, 3] as JsonValue), "Root")).toEqual([]);
  });

  it("walks into union members", () => {
    const root = inferType({ items: [{ a: 1 }, "x"] } as JsonValue);
    const types = extractNamedTypes(root, "Root");
    expect(types.map((t) => t.name)).toContain("Item");
  });
});
