import { describe, it, expect } from "vitest";
import {
  apcaLc,
  buildScale,
  clampToSrgbGamut,
  composite,
  contrastRatio,
  extractPalette,
  format,
  harmonyOf,
  isInSrgbGamut,
  mix,
  namedFor,
  oklchToRgb,
  parseColor,
  rgbToHsl,
  rgbToHsv,
  rgbToOklch,
  simulateCvd,
  toCmyk,
  toHex,
  wcagVerdict,
  type Rgb,
} from "../../src/lib/color";

const rgb = (r: number, g: number, b: number, a = 1): Rgb => ({ r, g, b, a });

const WHITE = rgb(255, 255, 255);
const BLACK = rgb(0, 0, 0);
const RED = rgb(255, 0, 0);

/** Round-trips lose a fraction of a unit to floating point; 8-bit output does not. */
const hexOf = (color: Rgb) => toHex(color);

describe("parseColor", () => {
  it("reads hex in every length CSS allows", () => {
    expect(parseColor("#fff")).toEqual(rgb(255, 255, 255));
    expect(parseColor("#ffffff")).toEqual(rgb(255, 255, 255));
    expect(parseColor("#ff0000")).toEqual(rgb(255, 0, 0));
    // 4- and 8-digit forms carry alpha.
    expect(parseColor("#0000")).toEqual(rgb(0, 0, 0, 0));
    expect(parseColor("#ff000080")?.a).toBeCloseTo(128 / 255, 5);
  });

  it("reads hex without the hash, because that is how it arrives from a spreadsheet", () => {
    expect(parseColor("ff8800")).toEqual(rgb(255, 136, 0));
    expect(parseColor("  A0B1C2  ")).toEqual(rgb(160, 177, 194));
  });

  /*
   * A colour tool that turns a typo into black is worse than one that refuses
   * the input: the person gets a swatch, believes it, and ships it.
   */
  it("refuses a hex length that cannot be a colour", () => {
    for (const bad of ["#ff", "#fffff", "#fffffff", "#12345"]) {
      expect(parseColor(bad), bad).toBeNull();
    }
  });

  it("reads both the comma and the space syntax, including the slash for alpha", () => {
    expect(parseColor("rgb(255, 0, 0)")).toEqual(rgb(255, 0, 0));
    expect(parseColor("rgb(255 0 0)")).toEqual(rgb(255, 0, 0));
    expect(parseColor("rgba(255, 0, 0, 0.5)")?.a).toBeCloseTo(0.5, 5);
    expect(parseColor("rgb(255 0 0 / 50%)")?.a).toBeCloseTo(0.5, 5);
  });

  it("reads percentages in rgb(), which resolve against 255 not 100", () => {
    expect(parseColor("rgb(100% 0% 0%)")).toEqual(rgb(255, 0, 0));
  });

  it("reads hsl, hsv and oklch", () => {
    expect(hexOf(parseColor("hsl(0 100% 50%)")!)).toBe("#ff0000");
    expect(hexOf(parseColor("hsl(120, 100%, 50%)")!)).toBe("#00ff00");
    expect(hexOf(parseColor("hsb(240 100% 100%)")!)).toBe("#0000ff");
    expect(hexOf(parseColor("oklch(1 0 0)")!)).toBe("#ffffff");
  });

  it("reads the CSS colour names and `transparent`", () => {
    expect(parseColor("rebeccapurple")).toEqual(rgb(102, 51, 153));
    expect(parseColor("TEAL")).toEqual(rgb(0, 128, 128));
    expect(parseColor("transparent")).toEqual(rgb(0, 0, 0, 0));
  });

  it("returns null rather than guessing", () => {
    for (const bad of ["", "   ", "notacolour", "rgb(1,2)", "oklch()", "hsl(a b c)"]) {
      expect(parseColor(bad), bad).toBeNull();
    }
  });
});

describe("HSL and HSV", () => {
  it("round-trips the primaries", () => {
    for (const color of [RED, rgb(0, 255, 0), rgb(0, 0, 255), rgb(18, 52, 86)]) {
      const back = parseColor(`hsl(${rgbToHsl(color).h} ${rgbToHsl(color).s}% ${rgbToHsl(color).l}%)`)!;
      expect(hexOf(back), hexOf(color)).toBe(hexOf(color));
    }
  });

  it("reports no hue for a neutral instead of an arbitrary one", () => {
    expect(rgbToHsl(rgb(128, 128, 128)).s).toBe(0);
    expect(rgbToHsv(rgb(128, 128, 128)).s).toBe(0);
  });

  it("gives white and black the lightness they have", () => {
    expect(rgbToHsl(WHITE).l).toBe(100);
    expect(rgbToHsl(BLACK).l).toBe(0);
    expect(rgbToHsv(WHITE).v).toBe(100);
  });
});

describe("OKLCh", () => {
  /*
   * Ottosson's published values for the sRGB primaries. These are the numbers
   * that catch a transposed matrix row — every wrong variant still produces
   * plausible-looking colours, and only the reference values disagree.
   */
  it("matches the reference values for the sRGB primaries", () => {
    const white = rgbToOklch(WHITE);
    expect(white.l).toBeCloseTo(1, 3);
    expect(white.c).toBeCloseTo(0, 3);

    const red = rgbToOklch(RED);
    expect(red.l).toBeCloseTo(0.6279, 3);
    expect(red.c).toBeCloseTo(0.2577, 3);
    expect(red.h).toBeCloseTo(29.23, 1);

    const green = rgbToOklch(rgb(0, 255, 0));
    expect(green.l).toBeCloseTo(0.8664, 3);
    expect(green.h).toBeCloseTo(142.5, 1);

    const blue = rgbToOklch(rgb(0, 0, 255));
    expect(blue.l).toBeCloseTo(0.452, 3);
    expect(blue.h).toBeCloseTo(264.05, 1);
  });

  it("round-trips every channel of a sampled cube within a unit", () => {
    for (let r = 0; r <= 255; r += 51) {
      for (let g = 0; g <= 255; g += 51) {
        for (let b = 0; b <= 255; b += 51) {
          const start = rgb(r, g, b);
          const back = oklchToRgb(rgbToOklch(start));
          expect(Math.abs(back.r - r), `${r},${g},${b} r`).toBeLessThan(1);
          expect(Math.abs(back.g - g), `${r},${g},${b} g`).toBeLessThan(1);
          expect(Math.abs(back.b - b), `${r},${g},${b} b`).toBeLessThan(1);
        }
      }
    }
  });

  // Atan2 of two near-zero numbers is noise, and letting it through makes a
  // grey ramp wander across the hue wheel.
  it("reports hue 0 for a neutral rather than floating-point noise", () => {
    expect(rgbToOklch(rgb(128, 128, 128)).h).toBe(0);
    expect(rgbToOklch(BLACK).h).toBe(0);
  });
});

describe("gamut", () => {
  it("knows that a vivid OKLCh coordinate has no sRGB pixel", () => {
    expect(isInSrgbGamut({ l: 0.7, c: 0.3, h: 140, a: 1 })).toBe(false);
    expect(isInSrgbGamut({ l: 0.6279, c: 0.2577, h: 29.23, a: 1 })).toBe(true);
  });

  /*
   * Without this, two different inputs clip to the same swatch and a ramp
   * silently flattens at exactly the end a designer is looking at.
   */
  it("clamps chroma until the colour is real, keeping lightness and hue", () => {
    const wanted = { l: 0.7, c: 0.35, h: 140, a: 1 };
    const clamped = clampToSrgbGamut(wanted);
    expect(clamped.l).toBe(wanted.l);
    expect(clamped.h).toBe(wanted.h);
    expect(clamped.c).toBeLessThan(wanted.c);
    expect(isInSrgbGamut(clamped)).toBe(true);
  });

  it("leaves an in-gamut colour untouched", () => {
    const inside = { l: 0.5, c: 0.05, h: 200, a: 1 };
    expect(clampToSrgbGamut(inside)).toEqual(inside);
  });
});

describe("formatting", () => {
  it("prints each format the way CSS accepts it", () => {
    const color = rgb(255, 136, 0);
    expect(format(color, "hex")).toBe("#ff8800");
    expect(format(color, "rgb")).toBe("rgb(255 136 0)");
    expect(format(color, "hsl")).toBe("hsl(32 100% 50%)");
    expect(format(color, "oklch")).toMatch(/^oklch\(0\.7\d+ 0\.1\d+ \d+/);
  });

  it("adds the alpha channel only when there is one", () => {
    expect(toHex(rgb(255, 0, 0, 1))).toBe("#ff0000");
    expect(toHex(rgb(255, 0, 0, 0.5))).toBe("#ff000080");
    expect(toHex(rgb(255, 0, 0, 1), { alpha: "always" })).toBe("#ff0000ff");
  });

  it("names a colour when CSS has a word for it", () => {
    expect(namedFor(rgb(102, 51, 153))).toBe("rebeccapurple");
    expect(namedFor(rgb(1, 2, 3))).toBeNull();
  });
});

describe("CMYK", () => {
  it("converts the primaries the way the naive formula does", () => {
    expect(toCmyk(RED)).toEqual({ c: 0, m: 100, y: 100, k: 0 });
    expect(toCmyk(WHITE)).toEqual({ c: 0, m: 0, y: 0, k: 0 });
    expect(toCmyk(BLACK)).toEqual({ c: 0, m: 0, y: 0, k: 100 });
  });
});

describe("contrast", () => {
  it("gives the two extremes the ratios the spec defines", () => {
    expect(contrastRatio(WHITE, BLACK)).toBeCloseTo(21, 5);
    expect(contrastRatio(WHITE, WHITE)).toBeCloseTo(1, 5);
  });

  it("is symmetric, because a ratio has no direction", () => {
    const a = rgb(30, 90, 200);
    const b = rgb(240, 240, 200);
    expect(contrastRatio(a, b)).toBeCloseTo(contrastRatio(b, a), 10);
  });

  /*
   * The single most common "why does your checker disagree with DevTools" bug:
   * a translucent foreground has no ratio of its own until it is composited.
   */
  it("composites a translucent foreground before measuring it", () => {
    const half = rgb(0, 0, 0, 0.5);
    const overWhite = contrastRatio(half, WHITE);
    const solidGrey = contrastRatio(composite(half, WHITE), WHITE);
    expect(overWhite).toBeCloseTo(solidGrey, 10);
    expect(overWhite).toBeLessThan(contrastRatio(BLACK, WHITE));
  });

  it("applies the WCAG thresholds at the right boundaries", () => {
    // #767676 on white is the canonical "just passes AA" grey.
    const verdict = wcagVerdict(rgb(0x76, 0x76, 0x76), WHITE);
    expect(verdict.ratio).toBeGreaterThanOrEqual(4.5);
    expect(verdict.normalAA).toBe(true);
    expect(verdict.normalAAA).toBe(false);
    expect(verdict.largeAA).toBe(true);

    // One step lighter and it fails.
    expect(wcagVerdict(rgb(0x77, 0x77, 0x77), WHITE).normalAA).toBe(false);
  });
});

describe("APCA", () => {
  /*
   * APCA is polarity aware: black on white and white on black are different
   * problems and get different numbers, where WCAG 2.x reports 21:1 for both.
   */
  it("reports the published Lc for the two extremes, with sign", () => {
    expect(apcaLc(BLACK, WHITE)).toBeCloseTo(106, 0);
    expect(apcaLc(WHITE, BLACK)).toBeCloseTo(-107.9, 0);
  });

  it("returns zero when there is nothing to measure", () => {
    expect(apcaLc(WHITE, WHITE)).toBe(0);
    expect(Math.abs(apcaLc(rgb(200, 200, 200), rgb(205, 205, 205)))).toBeLessThan(10);
  });
});

describe("scales", () => {
  const scale = buildScale(rgb(0, 105, 111));

  it("produces the eleven steps a design system expects", () => {
    expect(scale.map((stop) => stop.step)).toEqual([
      50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950,
    ]);
  });

  it("runs light to dark without ever going back up", () => {
    const lightness = scale.map((stop) => rgbToOklch(stop.color).l);
    for (let index = 1; index < lightness.length; index++) {
      expect(lightness[index], `step ${scale[index].step}`).toBeLessThan(lightness[index - 1]);
    }
  });

  it("keeps the hue of the colour it was built from", () => {
    const baseHue = rgbToOklch(rgb(0, 105, 111)).h;
    for (const stop of scale) {
      const { c, h } = rgbToOklch(stop.color);
      // Near-neutral ends have no meaningful hue to compare.
      if (c < 0.02) continue;
      expect(Math.abs(h - baseHue), `step ${stop.step}`).toBeLessThan(6);
    }
  });

  it("marks exactly one stop as the one the input landed on", () => {
    expect(scale.filter((stop) => stop.isBase)).toHaveLength(1);
  });

  // A ramp whose most saturated steps silently clip is the failure this guards.
  it("produces only colours sRGB can actually show", () => {
    for (const stop of buildScale(rgb(0, 200, 80))) {
      expect(isInSrgbGamut(rgbToOklch(stop.color)), `step ${stop.step}`).toBe(true);
    }
  });
});

describe("harmony", () => {
  it("returns the number of hues each scheme is named for", () => {
    expect(harmonyOf(RED, "complementary")).toHaveLength(2);
    expect(harmonyOf(RED, "analogous")).toHaveLength(3);
    expect(harmonyOf(RED, "triadic")).toHaveLength(3);
    expect(harmonyOf(RED, "tetradic")).toHaveLength(4);
    expect(harmonyOf(RED, "split-complementary")).toHaveLength(3);
    expect(harmonyOf(RED, "monochromatic")).toHaveLength(5);
  });

  it("puts the complement on the opposite side of the wheel", () => {
    const [base, complement] = harmonyOf(rgb(0, 105, 111), "complementary");
    const difference = Math.abs(rgbToOklch(base).h - rgbToOklch(complement).h);
    expect(Math.min(difference, 360 - difference)).toBeCloseTo(180, 0);
  });

  /*
   * Rotating hue in HSL is what produces a "triad" where the yellow blinds you
   * and the blue disappears. Rotating in OKLCh holds perceived lightness.
   */
  it("holds lightness across a rotation, which HSL does not", () => {
    const colors = harmonyOf(rgb(200, 60, 60), "triadic");
    const lightness = colors.map((color) => rgbToOklch(color).l);
    const spread = Math.max(...lightness) - Math.min(...lightness);
    expect(spread).toBeLessThan(0.02);
  });
});

describe("mix", () => {
  it("returns the endpoints untouched", () => {
    expect(hexOf(mix(RED, rgb(0, 0, 255), 0))).toBe("#ff0000");
    expect(hexOf(mix(RED, rgb(0, 0, 255), 1))).toBe("#0000ff");
  });

  /*
   * The sRGB midpoint of blue and yellow is a muddy grey. The OKLab midpoint is
   * the green a person expects, and staying chromatic is the whole reason to
   * interpolate in a perceptual space.
   */
  it("does not pass through grey on the way between two hues", () => {
    const middle = mix(rgb(0, 0, 255), rgb(255, 255, 0), 0.5);
    expect(rgbToOklch(middle).c).toBeGreaterThan(0.05);
  });

  it("clamps an amount outside 0–1 instead of extrapolating", () => {
    expect(hexOf(mix(RED, rgb(0, 0, 255), -1))).toBe("#ff0000");
    expect(hexOf(mix(RED, rgb(0, 0, 255), 2))).toBe("#0000ff");
  });
});

describe("colour vision deficiency", () => {
  it("collapses red and green towards each other for a deuteranope", () => {
    const red = simulateCvd(RED, "deuteranopia");
    const green = simulateCvd(rgb(0, 255, 0), "deuteranopia");
    const before = Math.abs(rgbToOklch(RED).h - rgbToOklch(rgb(0, 255, 0)).h);
    const after = Math.abs(rgbToOklch(red).h - rgbToOklch(green).h);
    expect(after).toBeLessThan(before);
  });

  // A simulation that tints greys is applying its matrix to gamma-encoded
  // values instead of linear ones — the commonest way to get this wrong, and
  // invisible unless you look at a neutral.
  it("leaves a neutral neutral, for every type", () => {
    for (const type of ["protanopia", "deuteranopia", "tritanopia", "achromatopsia"] as const) {
      const grey = simulateCvd(rgb(128, 128, 128), type);
      expect(rgbToOklch(grey).c, type).toBeLessThan(0.02);
    }
  });

  it("removes all chroma under achromatopsia", () => {
    const flat = simulateCvd(rgb(200, 40, 90), "achromatopsia");
    expect(flat.r).toBeCloseTo(flat.g, 5);
    expect(flat.g).toBeCloseTo(flat.b, 5);
  });

  it("keeps alpha", () => {
    expect(simulateCvd(rgb(200, 40, 90, 0.3), "protanopia").a).toBe(0.3);
  });
});

describe("palette extraction", () => {
  /** Four solid quadrants, so the right answer is knowable. */
  const quadrants = (): Uint8ClampedArray => {
    const size = 40;
    const pixels = new Uint8ClampedArray(size * size * 4);
    const colors = [
      [255, 0, 0],
      [0, 255, 0],
      [0, 0, 255],
      [255, 255, 0],
    ];
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const quadrant = (y < size / 2 ? 0 : 2) + (x < size / 2 ? 0 : 1);
        const offset = (y * size + x) * 4;
        pixels[offset] = colors[quadrant][0];
        pixels[offset + 1] = colors[quadrant][1];
        pixels[offset + 2] = colors[quadrant][2];
        pixels[offset + 3] = 255;
      }
    }
    return pixels;
  };

  it("finds the four colours actually in the image", () => {
    const palette = extractPalette(quadrants(), 4);
    expect(palette).toHaveLength(4);
    const found = new Set(palette.map((swatch) => hexOf(swatch.color)));
    expect(found).toEqual(new Set(["#ff0000", "#00ff00", "#0000ff", "#ffff00"]));
  });

  it("reports shares that sum to one", () => {
    const total = extractPalette(quadrants(), 4).reduce((sum, s) => sum + s.share, 0);
    expect(total).toBeCloseTo(1, 6);
  });

  /*
   * A palette that changes between two openings of the same image cannot be
   * cited in a handover document, so the seeding is deterministic rather than
   * the usual probabilistic k-means++.
   */
  it("returns the same palette every time for the same pixels", () => {
    const first = extractPalette(quadrants(), 4).map((s) => hexOf(s.color));
    const second = extractPalette(quadrants(), 4).map((s) => hexOf(s.color));
    expect(second).toEqual(first);
  });

  it("skips fully transparent pixels rather than averaging them towards black", () => {
    const pixels = new Uint8ClampedArray(8 * 4);
    for (let index = 0; index < 4; index++) {
      pixels[index * 4] = 255;
      pixels[index * 4 + 3] = 255; // opaque red
    }
    // The remaining four are transparent black.
    const palette = extractPalette(pixels, 2);
    expect(palette.every((swatch) => swatch.color.r === 255)).toBe(true);
  });

  it("returns nothing for an empty image instead of throwing", () => {
    expect(extractPalette(new Uint8ClampedArray(0), 5)).toEqual([]);
  });
});
