import { describe, it, expect } from "vitest";
import { parseCron, nextRuns, frequencySummary, ALIASES } from "../../src/lib/cron";

const parse = (expression: string) => {
  const result = parseCron(expression);
  if (!result.ok) throw new Error(result.error);
  return result.value;
};

const runs = (expression: string, from: string, count = 5) =>
  nextRuns(parse(expression), new Date(from), count).map((date) => date.toISOString());

describe("parsing", () => {
  it("reads the five standard fields", () => {
    const parsed = parse("5 4 * * *");
    expect(parsed.fields.map((f) => f.name)).toEqual([
      "minute",
      "hour",
      "day of month",
      "month",
      "day of week",
    ]);
    expect(parsed.fields[0].values).toEqual([5]);
    expect(parsed.fields[1].values).toEqual([4]);
  });

  it("reads six fields as seconds-first", () => {
    const parsed = parse("30 5 4 * * *");
    expect(parsed.hasSeconds).toBe(true);
    expect(parsed.fields[0].values).toEqual([30]);
  });

  it("reads seven fields as Quartz with a year", () => {
    const parsed = parse("0 0 0 1 1 * 2027");
    expect(parsed.hasYear).toBe(true);
    expect(parsed.fields[6].values).toEqual([2027]);
  });

  it("expands a step", () => {
    expect(parse("*/15 * * * *").fields[0].values).toEqual([0, 15, 30, 45]);
  });

  it("expands a range", () => {
    expect(parse("0 9-12 * * *").fields[1].values).toEqual([9, 10, 11, 12]);
  });

  it("expands a range with a step", () => {
    expect(parse("0 0-20/5 * * *").fields[1].values).toEqual([0, 5, 10, 15, 20]);
  });

  it("expands a list", () => {
    expect(parse("0 0,6,12,18 * * *").fields[1].values).toEqual([0, 6, 12, 18]);
  });

  it("expands a value with a step as value-to-max", () => {
    expect(parse("0 5/6 * * *").fields[1].values).toEqual([5, 11, 17, 23]);
  });

  it("accepts month and day names", () => {
    expect(parse("0 0 * JAN-MAR MON,FRI").fields[3].values).toEqual([1, 2, 3]);
    expect(parse("0 0 * JAN-MAR MON,FRI").fields[4].values).toEqual([1, 5]);
  });

  it("treats both 0 and 7 as Sunday", () => {
    // Every implementation accepts both and no documentation mentions it in the
    // same place as anything else.
    expect(parse("0 0 * * 7").fields[4].values).toEqual([0]);
    expect(parse("0 0 * * 0,7").fields[4].values).toEqual([0]);
  });

  it("accepts a wrapping range", () => {
    // 22-2 for late-night hours, FRI-MON for a weekend window.
    expect(parse("0 22-2 * * *").fields[1].values).toEqual([0, 1, 2, 22, 23]);
    expect(parse("0 0 * * FRI-MON").fields[4].values).toEqual([0, 1, 5, 6]);
  });

  it("accepts ? as a wildcard, which Quartz uses", () => {
    expect(parse("0 0 ? * MON").fields[2].wildcard).toBe(true);
  });

  it("expands the named shorthands", () => {
    for (const [alias, expression] of Object.entries(ALIASES)) {
      const viaAlias = parse(alias);
      const direct = parse(expression);
      expect(viaAlias.fields.map((f) => f.values)).toEqual(direct.fields.map((f) => f.values));
    }
  });

  it("explains @reboot rather than failing obscurely", () => {
    const result = parseCron("@reboot");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/runs once when the daemon starts/);
  });
});

describe("rejection", () => {
  it("rejects the wrong number of fields", () => {
    const result = parseCron("* * *");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/found 3/);
  });

  it("rejects an out-of-range value, naming the field", () => {
    const result = parseCron("0 25 * * *");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/hour/);
  });

  it("rejects a nonsense token", () => {
    expect(parseCron("0 0 * * FUNDAY").ok).toBe(false);
  });

  it("rejects a step of zero", () => {
    expect(parseCron("*/0 * * * *").ok).toBe(false);
  });
});

describe("description", () => {
  it("describes a daily schedule", () => {
    expect(parse("0 3 * * *").description).toMatch(/At 03:00/);
  });

  it("describes a step", () => {
    expect(parse("*/5 * * * *").description).toMatch(/Every 5 minutes/);
  });

  it("describes weekdays by name", () => {
    expect(parse("0 9 * * 1-5").description).toMatch(/Monday, Tuesday, Wednesday, Thursday and Friday/);
  });

  it("states the day-field OR explicitly, because it catches everyone", () => {
    // `0 0 13 * 5` is the 13th OR any Friday — not Friday the 13th.
    const text = parse("0 0 13 * 5").description;
    expect(text).toMatch(/OR/);
    expect(text).toMatch(/ORs these two fields/);
  });

  it("says the times are UTC", () => {
    expect(parse("0 0 * * *").description).toMatch(/UTC/);
  });
});

describe("next runs", () => {
  it("computes the next daily runs", () => {
    expect(runs("0 3 * * *", "2026-09-11T04:00:00Z", 3)).toEqual([
      "2026-09-12T03:00:00.000Z",
      "2026-09-13T03:00:00.000Z",
      "2026-09-14T03:00:00.000Z",
    ]);
  });

  it("never returns the starting instant itself", () => {
    expect(runs("0 3 * * *", "2026-09-11T03:00:00Z", 1)).toEqual(["2026-09-12T03:00:00.000Z"]);
  });

  it("computes a step within the hour", () => {
    expect(runs("*/15 * * * *", "2026-09-11T10:07:00Z", 3)).toEqual([
      "2026-09-11T10:15:00.000Z",
      "2026-09-11T10:30:00.000Z",
      "2026-09-11T10:45:00.000Z",
    ]);
  });

  it("respects a weekday restriction", () => {
    // 2026-09-11 is a Friday, so the next weekday 09:00 is Monday the 14th.
    expect(runs("0 9 * * 1-5", "2026-09-11T10:00:00Z", 2)).toEqual([
      "2026-09-14T09:00:00.000Z",
      "2026-09-15T09:00:00.000Z",
    ]);
  });

  it("ORs the two day fields rather than intersecting them", () => {
    // The 13th or any Friday. September 2026: the 11th is a Friday, so the 13th
    // and the 18th both fire.
    const fired = runs("0 0 13 * 5", "2026-09-11T01:00:00Z", 4);
    expect(fired).toEqual([
      "2026-09-13T00:00:00.000Z",
      "2026-09-18T00:00:00.000Z",
      "2026-09-25T00:00:00.000Z",
      "2026-10-02T00:00:00.000Z",
    ]);
  });

  it("restricts to a single day when only one field is set", () => {
    expect(runs("0 0 13 * *", "2026-09-14T00:00:00Z", 2)).toEqual([
      "2026-10-13T00:00:00.000Z",
      "2026-11-13T00:00:00.000Z",
    ]);
  });

  it("finds 29 February only in a leap year", () => {
    expect(runs("0 0 29 2 *", "2026-01-01T00:00:00Z", 1)).toEqual(["2028-02-29T00:00:00.000Z"]);
  });

  it("returns nothing for a schedule that can never fire, without hanging", () => {
    // 31 February. A minute-by-minute scan would take millions of iterations to
    // give up; skipping by the largest ruled-out unit proves it in a few hundred.
    const started = performance.now();
    expect(runs("0 0 31 2 *", "2026-01-01T00:00:00Z", 1)).toEqual([]);
    expect(performance.now() - started).toBeLessThan(500);
  });

  it("handles a seconds field", () => {
    expect(runs("30 * * * * *", "2026-09-11T10:00:00Z", 2)).toEqual([
      "2026-09-11T10:00:30.000Z",
      "2026-09-11T10:01:30.000Z",
    ]);
  });

  it("respects a year restriction", () => {
    expect(runs("0 0 0 1 1 * 2028", "2026-01-01T00:00:00Z", 2)).toEqual([
      "2028-01-01T00:00:00.000Z",
    ]);
  });

  it("crosses a month and a year boundary", () => {
    expect(runs("0 0 1 1 *", "2026-06-01T00:00:00Z", 2)).toEqual([
      "2027-01-01T00:00:00.000Z",
      "2028-01-01T00:00:00.000Z",
    ]);
  });

  it("computes an every-minute schedule without stalling", () => {
    expect(runs("* * * * *", "2026-09-11T10:00:30Z", 2)).toEqual([
      "2026-09-11T10:01:00.000Z",
      "2026-09-11T10:02:00.000Z",
    ]);
  });
});

describe("frequency", () => {
  it("summarises the average gap", () => {
    expect(frequencySummary(nextRuns(parse("*/5 * * * *"), new Date("2026-09-11T00:00:00Z"), 10)))
      .toMatch(/every 5 minutes/);
    expect(frequencySummary(nextRuns(parse("0 3 * * *"), new Date("2026-09-11T00:00:00Z"), 10)))
      .toMatch(/every 1 day/);
  });

  it("says so when there are too few runs to average", () => {
    expect(frequencySummary([])).toMatch(/Fewer than two/);
  });
});
