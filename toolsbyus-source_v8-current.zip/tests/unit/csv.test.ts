import { describe, it, expect } from "vitest";
import {
  csvToJson,
  jsonToCsv,
  parseCsvGrid,
  sniffDelimiter,
  flattenRecord,
  expandRow,
  inferCellType,
  decodePath,
  encodePath,
  DEFAULT_PARSE_OPTIONS,
  DEFAULT_SERIALIZE_OPTIONS,
} from "../../src/lib/csv";

const parse = (input: string, over: Partial<typeof DEFAULT_PARSE_OPTIONS> = {}) =>
  csvToJson(input, { ...DEFAULT_PARSE_OPTIONS, ...over });

const serialize = (value: Parameters<typeof jsonToCsv>[0], over: Partial<typeof DEFAULT_SERIALIZE_OPTIONS> = {}) =>
  jsonToCsv(value, { ...DEFAULT_SERIALIZE_OPTIONS, ...over });

describe("grid parsing", () => {
  it("handles quoted fields containing the delimiter", () => {
    const result = parseCsvGrid('a,"b,c",d', ",", true);
    expect(result.success && result.data[0]).toEqual(["a", "b,c", "d"]);
  });

  it("handles escaped quotes", () => {
    const result = parseCsvGrid('"he said ""hi""",x', ",", true);
    expect(result.success && result.data[0]).toEqual(['he said "hi"', "x"]);
  });

  it("handles a newline inside a quoted field", () => {
    const result = parseCsvGrid('name,note\n"a","line one\nline two"', ",", true);
    expect(result.success && result.data).toEqual([
      ["name", "note"],
      ["a", "line one\nline two"],
    ]);
  });

  it("handles CRLF line endings", () => {
    const result = parseCsvGrid("a,b\r\nc,d\r\n", ",", true);
    expect(result.success && result.data).toEqual([
      ["a", "b"],
      ["c", "d"],
    ]);
  });

  it("preserves an empty trailing field", () => {
    const result = parseCsvGrid("a,b,", ",", true);
    expect(result.success && result.data[0]).toEqual(["a", "b", ""]);
  });

  it("strips a UTF-8 BOM so the first column name is matchable", () => {
    const result = parseCsvGrid("﻿id,name\n1,a", ",", true);
    expect(result.success && result.data[0][0]).toBe("id");
  });

  it("reports an unterminated quote rather than truncating", () => {
    const result = parseCsvGrid('a,"unclosed', ",", true);
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.message).toMatch(/Unterminated quoted field/);
  });

  it("keeps a quoted empty string distinct from a missing final row", () => {
    const result = parseCsvGrid('a,""', ",", true);
    expect(result.success && result.data).toEqual([["a", ""]]);
  });
});

describe("delimiter sniffing", () => {
  it("finds semicolons", () => expect(sniffDelimiter("a;b;c\n1;2;3")).toBe(";"));
  it("finds tabs", () => expect(sniffDelimiter("a\tb\tc")).toBe("\t"));
  it("defaults to comma", () => expect(sniffDelimiter("single")).toBe(","));

  it("ignores delimiters inside quotes", () => {
    // The header has one real comma and three semicolons inside a quoted field.
    // Counting naively picks the semicolon and splits the file wrongly.
    expect(sniffDelimiter('name,"a;b;c;d"')).toBe(",");
  });
});

describe("type inference", () => {
  it("trims before matching, since exporters pad numeric columns", () => {
    expect(inferCellType("  42  ")).toBe(42);
  });

  it("keeps an integer too large for a double as text", () => {
    // Past 2^53 the conversion drops digits, which is data loss rather than a
    // change of representation — a Twitter-style snowflake ID, for instance.
    expect(inferCellType("9007199254740993")).toBe("9007199254740993");
  });

  it.each([
    ["42", 42],
    ["-3.5", -3.5],
    ["1e3", 1000],
    ["true", true],
    ["false", false],
    ["null", null],
    ["", ""],
  ])("reads %s as its JSON type", (raw, expected) => {
    expect(inferCellType(raw)).toEqual(expected);
  });

  it.each([
    ["007", "a zip code keeps its leading zeros"],
    ["+1", "a phone prefix is not a number"],
    ["0x10", "hex is not JSON number syntax"],
    ["1,5", "a European decimal is not a number here"],
    ["1e", "an incomplete exponent stays text"],
  ])("leaves %s as a string (%s)", (raw) => {
    expect(typeof inferCellType(raw)).toBe("string");
  });
});

describe("path encoding", () => {
  it("distinguishes an object key from an array index", () => {
    expect(encodePath([{ key: "a", isIndex: false }, { key: "0", isIndex: true }])).toBe("a[0]");
    expect(encodePath([{ key: "a", isIndex: false }, { key: "0", isIndex: false }])).toBe("a.0");
  });

  it("round-trips", () => {
    for (const path of ["a", "a.b", "a[0]", "a[0].b", "a.b[2].c", "items[10][3]"]) {
      expect(encodePath(decodePath(path))).toBe(path);
    }
  });
});

describe("flattening", () => {
  it("flattens nested objects to dotted paths", () => {
    const map = flattenRecord(
      { id: 1, address: { city: "Berlin", geo: { lat: 52.5 } } },
      DEFAULT_SERIALIZE_OPTIONS
    );
    expect(Object.fromEntries(map)).toEqual({
      id: "1",
      "address.city": "Berlin",
      "address.geo.lat": "52.5",
    });
  });

  it("explodes arrays into indexed columns by default", () => {
    const map = flattenRecord({ tags: ["a", "b"] }, DEFAULT_SERIALIZE_OPTIONS);
    expect(Object.fromEntries(map)).toEqual({ "tags[0]": "a", "tags[1]": "b" });
  });

  it("joins scalar arrays into one cell when asked", () => {
    const map = flattenRecord(
      { tags: ["a", "b"] },
      { ...DEFAULT_SERIALIZE_OPTIONS, arrayMode: "join", arrayJoin: "|" }
    );
    expect(Object.fromEntries(map)).toEqual({ tags: "a|b" });
  });

  it("explodes an array of objects even in join mode, since joining would lose it", () => {
    const map = flattenRecord(
      { items: [{ sku: "x" }] },
      { ...DEFAULT_SERIALIZE_OPTIONS, arrayMode: "join", arrayJoin: "|" }
    );
    expect(Object.fromEntries(map)).toEqual({ "items[0].sku": "x" });
  });

  it("keeps column order stable and source-ordered", () => {
    const map = flattenRecord({ z: 1, a: 2, m: { b: 3, a: 4 } }, DEFAULT_SERIALIZE_OPTIONS);
    expect([...map.keys()]).toEqual(["z", "a", "m.b", "m.a"]);
  });

  it("does not overflow the stack on a deeply nested document", () => {
    // The flattener is iterative for the same reason the JSON parser is: a
    // recursive one dies on exactly the input a debugging tool is handed.
    let deep: Record<string, unknown> = { leaf: 1 };
    for (let i = 0; i < 10_000; i++) deep = { n: deep };
    const map = flattenRecord(deep as never, DEFAULT_SERIALIZE_OPTIONS);
    expect(map.size).toBe(1);
    expect([...map.keys()][0].split(".").length).toBe(10_001);
  });
});

describe("JSON to CSV", () => {
  it("unions columns across records rather than trusting the first", () => {
    // The commonest way a converter loses data: read the header off record one
    // and drop every field that only later records carry.
    const result = serialize([{ a: 1 }, { a: 2, b: 3 }]);
    expect(result.columns).toEqual(["a", "b"]);
    expect(result.csv).toBe("a,b\n1,\n2,3");
  });

  it("quotes only where the grammar requires it", () => {
    const result = serialize([{ plain: "x", comma: "a,b", quote: 'say "hi"', nl: "a\nb" }]);
    const [, row] = result.csv.split("\n");
    expect(row).toBe('x,"a,b","say ""hi""","a');
  });

  it("quotes a field with significant whitespace", () => {
    const result = serialize([{ padded: " x " }]);
    expect(result.csv.split("\n")[1]).toBe('" x "');
  });

  it("accepts the {data:[…]} envelope most APIs return", () => {
    const result = serialize({ data: [{ id: 1 }, { id: 2 }], meta: { page: 1 } } as never);
    expect(result.rowCount).toBe(2);
    expect(result.warnings[0]).toMatch(/"data" array/);
  });

  it("renders null as an empty cell, not the text 'null'", () => {
    const result = serialize([{ a: null }]);
    expect(result.csv.split("\n")[1]).toBe("");
  });
});

describe("CSV to JSON", () => {
  it("reads a header row into keys", () => {
    const result = parse("id,name\n1,Ada");
    expect(result.success && result.data.records).toEqual([{ id: 1, name: "Ada" }]);
  });

  it("rebuilds nested structure from dotted and bracketed columns", () => {
    const result = parse("id,address.city,tags[0],tags[1]\n1,Berlin,a,b");
    expect(result.success && result.data.records).toEqual([
      { id: 1, address: { city: "Berlin" }, tags: ["a", "b"] },
    ]);
  });

  it("synthesises column names when there is no header", () => {
    const result = parse("1,2\n3,4", { hasHeader: false });
    expect(result.success && result.data.records[0]).toEqual({ column1: 1, column2: 2 });
  });

  it("warns about ragged rows instead of failing, and omits the missing field", () => {
    const result = parse("a,b,c\n1,2");
    expect(result.success && result.data.records[0]).toEqual({ a: 1, b: 2 });
    expect(result.success && result.data.warnings[0]).toMatch(/did not have 3 fields/);
  });

  it("keeps empty cells as empty strings when omitEmpty is off", () => {
    const result = parse("a,b,c\n1,2", { omitEmpty: false });
    expect(result.success && result.data.records[0]).toEqual({ a: 1, b: 2, c: "" });
  });

  it("warns about duplicate column names", () => {
    const result = parse("a,a\n1,2");
    expect(result.success && result.data.warnings[0]).toMatch(/Duplicate column/);
  });
});

describe("round trip", () => {
  it("returns the original document through CSV and back", () => {
    const original = [
      { id: 1, name: "Ada", address: { city: "London", zip: "E1" }, tags: ["a", "b"], active: true },
      { id: 2, name: "Grace", address: { city: "Arlington", zip: "VA-1" }, tags: ["c"], active: false },
    ];
    const csv = serialize(original as never).csv;
    const back = parse(csv);
    expect(back.success && back.data.records).toEqual(original);
  });

  it("cannot round-trip a numeric-looking string, and that is inherent to CSV", () => {
    // A CSV cell carries no type. "22201" is a zip code to a human and a number
    // to a parser, and nothing in the file distinguishes them. The honest
    // response is to make inference switchable and say so, not to pretend.
    const csv = serialize([{ zip: "22201" }] as never).csv;
    expect(parse(csv).success && (parse(csv) as { data: { records: unknown[] } }).data.records).toEqual([
      { zip: 22201 },
    ]);
    const asText = parse(csv, { inferTypes: false });
    expect(asText.success && asText.data.records).toEqual([{ zip: "22201" }]);
  });

  it("keeps a short array short rather than padding it to the widest record", () => {
    const original = [{ tags: ["a", "b"] }, { tags: ["c"] }];
    const csv = serialize(original as never).csv;
    const back = parse(csv);
    expect(back.success && back.data.records).toEqual(original);
  });

  it("survives a value containing the delimiter, a quote and a newline", () => {
    const original = [{ note: 'a,b "c"\nd' }];
    const csv = serialize(original as never).csv;
    const back = parse(csv);
    expect(back.success && back.data.records).toEqual(original);
  });
});

describe("prototype pollution", () => {
  it("ignores a __proto__ path in a column header", () => {
    // A CSV header is user-controlled text that is used to index an object,
    // which is exactly the shape of a pollution payload.
    const result = parse("a.__proto__.polluted\nyes");
    expect(result.success).toBe(true);
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
    expect(Object.prototype).not.toHaveProperty("polluted");
  });

  it("ignores a bare constructor column", () => {
    const result = parse("constructor.prototype.x\n1");
    expect(result.success).toBe(true);
    expect(({} as Record<string, unknown>).x).toBeUndefined();
  });

  it("guards expandRow directly", () => {
    const out = expandRow([["__proto__.leak", "1"]]);
    expect(Object.prototype).not.toHaveProperty("leak");
    expect(Object.keys(out)).toEqual([]);
  });
});
