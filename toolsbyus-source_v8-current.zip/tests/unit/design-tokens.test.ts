import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

/**
 * The colour system is only a system if the numbers hold. These tests read the
 * real token values out of globals.css and check the contrast arithmetic, so a
 * future palette tweak that drops a label under 4.5:1 fails here rather than in
 * somebody's eyes.
 *
 * The previous build's `text-emerald-600 dark:text-emerald-400` pairs passed by
 * accident and its `text-brand-500` links failed in light mode at 2.1:1; both
 * were invisible to every test in the suite.
 */

const CSS = readFileSync(resolve(__dirname, "../../src/app/globals.css"), "utf8");

/** Pulls one block's `--name: value;` declarations. */
function tokensIn(selector: string): Record<string, string> {
  const start = CSS.indexOf(selector);
  if (start === -1) throw new Error(`no ${selector} block in globals.css`);
  const open = CSS.indexOf("{", start);
  let depth = 0;
  let end = open;
  for (let i = open; i < CSS.length; i++) {
    if (CSS[i] === "{") depth++;
    else if (CSS[i] === "}") {
      depth--;
      if (depth === 0) {
        end = i;
        break;
      }
    }
  }
  const body = CSS.slice(open, end);
  const out: Record<string, string> = {};
  for (const m of body.matchAll(/(--[a-z0-9-]+)\s*:\s*([^;]+);/g)) {
    out[m[1]] = m[2].trim();
  }
  return out;
}

const light = tokensIn("  :root {");
const dark = tokensIn("  .dark {");

function srgbToLinear(channel: number): number {
  const c = channel / 255;
  return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}

function luminance(hex: string): number {
  const value = hex.trim().replace("#", "");
  const full =
    value.length === 3
      ? value
          .split("")
          .map((c) => c + c)
          .join("")
      : value;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return 0.2126 * srgbToLinear(r) + 0.7152 * srgbToLinear(g) + 0.0722 * srgbToLinear(b);
}

function contrast(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

/** Text tokens that must clear WCAG AA for normal-size text. */
const TEXT_ON_PAGE = ["--text", "--text-muted", "--text-subtle", "--accent"];
/** Diff and status hues, which also carry running text. */
const SEMANTIC = ["--add", "--del", "--mod", "--move", "--type", "--danger", "--warn"];

describe("colour tokens", () => {
  for (const [themeName, theme] of [
    ["light", light],
    ["dark", dark],
  ] as const) {
    describe(themeName, () => {
      for (const token of [...TEXT_ON_PAGE, ...SEMANTIC]) {
        it(`${token} clears 4.5:1 on --bg`, () => {
          const ratio = contrast(theme[token], theme["--bg"]);
          expect(ratio, `${token} on --bg was ${ratio.toFixed(2)}:1`).toBeGreaterThanOrEqual(4.5);
        });

        it(`${token} clears 4.5:1 on --surface-2`, () => {
          // Panel headers, toolbars and table heads all sit on --surface-2, so
          // a token readable only against the page background is not enough.
          const ratio = contrast(theme[token], theme["--surface-2"]);
          expect(ratio, `${token} on --surface-2 was ${ratio.toFixed(2)}:1`).toBeGreaterThanOrEqual(4.5);
        });
      }

      it("--on-accent is readable on --accent-solid", () => {
        const ratio = contrast(theme["--on-accent"], theme["--accent-solid"]);
        expect(ratio, `filled-button text was ${ratio.toFixed(2)}:1`).toBeGreaterThanOrEqual(4.5);
      });

      it("--border is distinguishable from the surfaces it separates", () => {
        // Non-text contrast (WCAG 1.4.11) is 3:1 for controls, but a hairline
        // divider is decorative; it only has to be visible at all. A border
        // that matches its background is the classic one-theme-only bug.
        expect(contrast(theme["--border"], theme["--surface"])).toBeGreaterThan(1.1);
        expect(contrast(theme["--border-strong"], theme["--surface"])).toBeGreaterThan(1.5);
      });
    });
  }

  it("defines every token in both themes", () => {
    // Colour tokens only: --font-sans and the radii are theme-independent by
    // design and are deliberately declared once.
    const lightKeys = Object.keys(light).filter(
      (k) => !k.startsWith("--radius") && k !== "--font-sans"
    );
    const darkKeys = Object.keys(dark);
    const missing = lightKeys.filter((k) => !darkKeys.includes(k));
    expect(missing, `tokens defined only in light mode: ${missing.join(", ")}`).toEqual([]);
  });

  it("keeps the diff hues distinguishable from one another", () => {
    // Colour is never the only signal — each row also carries a glyph and a
    // word — but the five hues still have to read as five hues.
    for (const theme of [light, dark]) {
      const hues = ["--add", "--del", "--mod", "--move", "--type"].map((t) => theme[t]);
      for (let i = 0; i < hues.length; i++) {
        for (let j = i + 1; j < hues.length; j++) {
          expect(hues[i]).not.toBe(hues[j]);
        }
      }
    }
  });
});
