import { describe, it, expect } from "vitest";
import { computeSemanticDiff, areValuesEqual } from "../../src/lib/diff/semantic-diff";
import { createJsonPatch, applyJsonPatch } from "../../src/lib/diff/patch-rfc6902";
import { createJsonMergePatch, applyJsonMergePatch } from "../../src/lib/diff/merge-patch-rfc7386";
import { computeThreeWayDiff } from "../../src/lib/diff/three-way-diff";
import { computeTextDiff } from "../../src/lib/diff/text-diff";

describe("Semantic Diff Engine", () => {
  it("treats key order and whitespace as invariant (equal)", () => {
    const a = { b: 2, a: 1, nested: { y: 20, x: 10 } };
    const b = { a: 1, b: 2, nested: { x: 10, y: 20 } };
    const res = computeSemanticDiff(a, b);
    expect(res.summary.total).toBe(0);
    expect(areValuesEqual(a, b)).toBe(true);
  });

  it("distinguishes null present from key absent", () => {
    const withNull = { key: null };
    const absent = {};
    const res = computeSemanticDiff(withNull, absent);
    expect(res.summary.removed).toBe(1);

    const res2 = computeSemanticDiff(absent, withNull);
    expect(res2.summary.added).toBe(1);
  });

  it("detects distinct TYPE_CHANGE instead of delete+add", () => {
    const a = { count: "42", flag: true };
    const b = { count: 42, flag: "true" };
    const res = computeSemanticDiff(a, b);
    expect(res.summary.typeChanged).toBe(2);
    expect(res.summary.added).toBe(0);
    expect(res.summary.removed).toBe(0);
  });

  it("matches arrays by user-selected key", () => {
    const left = [
      { id: "usr_1", name: "Alice", role: "admin" },
      { id: "usr_2", name: "Bob", role: "user" },
    ];
    // Reordered and updated in right
    const right = [
      { id: "usr_2", name: "Bob", role: "editor" },
      { id: "usr_1", name: "Alice", role: "admin" },
      { id: "usr_3", name: "Charlie", role: "user" },
    ];

    const res = computeSemanticDiff(left, right, {
      arrayMatchMode: "key",
      arrayKey: "id",
    });

    expect(res.summary.added).toBe(1); // usr_3 added
    expect(res.summary.removed).toBe(0);
    expect(res.summary.changed).toBe(1); // usr_2 role changed from user to editor
  });

  it("matches arrays by structural similarity", () => {
    const left = [
      { title: "Report A", pages: 10, author: "Alice" },
      { title: "Report B", pages: 25, author: "Bob" },
    ];
    const right = [
      { title: "Report B (Updated)", pages: 26, author: "Bob" },
      { title: "Report A", pages: 10, author: "Alice" },
    ];

    const res = computeSemanticDiff(left, right, {
      arrayMatchMode: "similarity",
    });

    // Should match Report B to Report B (Updated) rather than doing full delete+add
    expect(res.summary.removed).toBe(0);
    expect(res.summary.added).toBe(0);
    expect(res.summary.changed).toBeGreaterThan(0);
  });

  it("detects and labels subtree moves", () => {
    const left = {
      pending: { task1: { id: 101, title: "Do work" } },
      completed: {},
    };
    const right = {
      pending: {},
      completed: { task1: { id: 101, title: "Do work" } },
    };

    const res = computeSemanticDiff(left, right);
    expect(res.summary.moved).toBe(1);
  });

  it("traverses 10,000-level nesting without stack overflow", () => {
    let deepL: any = { leaf: 1 };
    let deepR: any = { leaf: 2 };
    for (let i = 0; i < 10000; i++) {
      deepL = { next: deepL };
      deepR = { next: deepR };
    }
    const res = computeSemanticDiff(deepL, deepR);
    expect(res.summary.changed).toBe(1);
  });
});

describe("RFC 6902 JSON Patch & Round-trip", () => {
  it("satisfies exact roundtrip: apply(diff(a, b), a) deepEquals b across rich corpus", () => {
    const testCases: [any, any][] = [
      // 1. Primitive changes
      [{ a: 1, b: "hello" }, { a: 2, b: "world" }],
      // 2. Additions and deletions
      [{ x: 10 }, { x: 10, y: [1, 2, 3], z: { nested: true } }],
      [{ a: 1, b: 2, c: 3 }, { a: 1 }],
      // 3. Array operations
      [[1, 2, 3, 4], [1, 99, 3]],
      [[], [{ id: 1, tag: "new" }]],
      [[{ id: 1 }, { id: 2 }], []],
      // 4. Nulls, booleans, and empty containers
      [{ emptyObj: {}, emptyArr: [], isNull: null }, { emptyObj: { filled: true }, emptyArr: [1], isNull: "notNull" }],
      // 5. Unicode and special characters
      [{ emoji: "🚀", path: "a/b~c" }, { emoji: "✨", path: "a~0b/c" }],
      // 6. Deeply nested objects
      [
        { l1: { l2: { l3: { val: "old", keep: true } } } },
        { l1: { l2: { l3: { val: "new", keep: true, added: 42 } } } },
      ],
    ];

    for (const [source, target] of testCases) {
      const patch = createJsonPatch(source, target);
      const applied = applyJsonPatch(source, patch);
      expect(areValuesEqual(applied, target)).toBe(true);
    }
  });
});

describe("RFC 7386 JSON Merge Patch", () => {
  it("generates and applies JSON merge patch", () => {
    const source = { title: "Hello", author: { name: "Bob" }, deleteMe: "remove" };
    const target = { title: "Hello World", author: { name: "Alice" } };

    const patch = createJsonMergePatch(source, target);
    expect(patch).toEqual({
      title: "Hello World",
      author: { name: "Alice" },
      deleteMe: null,
    });

    const applied = applyJsonMergePatch(source, patch);
    expect(applied).toEqual(target);
  });
});

describe("Three-Way Diff & Merge", () => {
  it("cleanly merges non-overlapping changes from left and right", () => {
    const base = { title: "Original", count: 10, author: "Alice" };
    const left = { title: "Updated Title", count: 10, author: "Alice" }; // changed title
    const right = { title: "Original", count: 20, author: "Alice" };    // changed count

    const res = computeThreeWayDiff(base, left, right);
    expect(res.hasConflicts).toBe(false);
    expect(res.merged).toEqual({
      title: "Updated Title",
      count: 20,
      author: "Alice",
    });
  });

  it("marks conflicts when both branches alter the same field differently", () => {
    const base = { count: 10 };
    const left = { count: 20 };
    const right = { count: 30 };

    const res = computeThreeWayDiff(base, left, right);
    expect(res.hasConflicts).toBe(true);
    expect(res.conflicts.length).toBe(1);
    expect(res.conflicts[0].path).toBe("/count");
  });
});

describe("Text Diff (Myers Algorithm)", () => {
  it("computes line diff and generates unified diff patch", () => {
    const oldText = "line 1\nline 2\nline 3";
    const newText = "line 1\nline 2 modified\nline 3\nline 4";

    const diff = computeTextDiff(oldText, newText);
    expect(diff.lines.length).toBeGreaterThan(0);
    expect(diff.unifiedPatch).toContain("--- a/original");
    expect(diff.unifiedPatch).toContain("+++ b/modified");
    expect(diff.summary.addedLines).toBeGreaterThan(0);
  });
});
