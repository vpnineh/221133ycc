import { describe, it, expect } from "vitest";
import {
  escapeJsonString,
  unescapeJsonString,
  stringifyJsonDocument,
  unescapeToDocument,
  DEFAULT_ESCAPE_OPTIONS,
} from "../../src/lib/json/escape";

const esc = (input: string, over: Partial<typeof DEFAULT_ESCAPE_OPTIONS> = {}) =>
  escapeJsonString(input, { ...DEFAULT_ESCAPE_OPTIONS, ...over });

describe("escaping", () => {
  it("escapes quotes and backslashes in the right order", () => {
    // The ordering hazard the character scan exists to avoid: escaping
    // backslashes after quotes double-escapes the backslash just introduced.
    expect(esc('a"b\\c', { includeQuotes: false })).toBe('a\\"b\\\\c');
  });

  it("escapes the whitespace controls by name", () => {
    expect(esc("\n\r\t\b\f", { includeQuotes: false })).toBe("\\n\\r\\t\\b\\f");
  });

  it("escapes other control characters as \\u", () => {
    expect(esc("\u0000\u001f", { includeQuotes: false })).toBe("\\u0000\\u001f");
  });

  it("leaves non-ASCII alone by default", () => {
    expect(esc("héllo — 日本", { includeQuotes: false })).toBe("héllo — 日本");
  });

  it("escapes non-ASCII on request", () => {
    expect(esc("é", { includeQuotes: false, escapeUnicode: true })).toBe("\\u00e9");
  });

  it("emits a surrogate pair for an astral codepoint", () => {
    // A single \\u escape cannot represent U+1F600; emitting one truncates
    // every emoji in the document.
    expect(esc("😀", { includeQuotes: false, escapeUnicode: true })).toBe("\\ud83d\\ude00");
  });

  it("escapes slashes only when asked", () => {
    expect(esc("a/b", { includeQuotes: false })).toBe("a/b");
    expect(esc("a/b", { includeQuotes: false, escapeSlashes: true })).toBe("a\\/b");
  });

  it("wraps in quotes by default", () => {
    expect(esc("x")).toBe('"x"');
  });
});

describe("unescaping", () => {
  it("reverses the named escapes", () => {
    expect(unescapeJsonString('"a\\nb\\tc"').text).toBe("a\nb\tc");
  });

  it("strips surrounding quotes and says it did", () => {
    const result = unescapeJsonString('"x"');
    expect(result.text).toBe("x");
    expect(result.hadQuotes).toBe(true);
  });

  it("works on a fragment that lost its quotes, as log lines do", () => {
    const result = unescapeJsonString('{\\"a\\":1}');
    expect(result.text).toBe('{"a":1}');
    expect(result.hadQuotes).toBe(false);
  });

  it("decodes \\u escapes", () => {
    expect(unescapeJsonString("\\u00e9").text).toBe("é");
  });

  it("recombines a surrogate pair into one character", () => {
    expect(unescapeJsonString("\\ud83d\\ude00").text).toBe("😀");
  });

  it("warns about a lone high surrogate rather than dropping it", () => {
    const result = unescapeJsonString("\\ud83d");
    expect(result.warnings[0]).toMatch(/Lone high surrogate/);
  });

  it("keeps an unknown escape and warns, rather than failing the whole input", () => {
    // The input is usually a fragment out of a stack trace. A partially
    // recovered document beats an error message.
    const result = unescapeJsonString("a\\qb");
    expect(result.text).toBe("a\\qb");
    expect(result.warnings[0]).toMatch(/Unknown escape/);
  });

  it("handles a trailing backslash", () => {
    const result = unescapeJsonString("a\\");
    expect(result.text).toBe("a\\");
    expect(result.warnings[0]).toMatch(/trailing backslash/);
  });

  it("handles an incomplete \\u escape", () => {
    const result = unescapeJsonString("\\u00");
    expect(result.warnings[0]).toMatch(/Incomplete/);
  });
});

describe("round trip", () => {
  it("returns the original text", () => {
    for (const original of [
      '{"a":1}',
      'quotes " and \\ backslashes',
      "newline\nand\ttab",
      "unicode é 日本 😀",
      "",
      "\u0000control",
    ]) {
      expect(unescapeJsonString(escapeJsonString(original)).text).toBe(original);
    }
  });

  it("round-trips through the unicode-escaped form too", () => {
    const original = "é 日本 😀";
    const escaped = escapeJsonString(original, { ...DEFAULT_ESCAPE_OPTIONS, escapeUnicode: true });
    expect(unescapeJsonString(escaped).text).toBe(original);
  });

  it("produces a literal that JSON.parse reads back as the original", () => {
    const original = '{"nested":"say \\"hi\\"","path":"C:\\\\tmp"}';
    const literal = escapeJsonString(original);
    expect(JSON.parse(literal)).toBe(original);
  });
});

describe("document helpers", () => {
  it("refuses to escape something that is not JSON", () => {
    const result = stringifyJsonDocument("{not json}");
    expect(result.success).toBe(false);
  });

  it("escapes a valid document", () => {
    const result = stringifyJsonDocument('{"a":1}');
    expect(result.success && result.data).toBe('"{\\"a\\":1}"');
  });

  it("reports whether the unescaped text parses", () => {
    expect(unescapeToDocument('"{\\"a\\":1}"').parsed.success).toBe(true);
    expect(unescapeToDocument('"{broken"').parsed.success).toBe(false);
  });
});
