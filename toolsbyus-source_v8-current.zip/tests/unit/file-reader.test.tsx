// @vitest-environment happy-dom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { useFileReader } from "../../src/components/tools/useFileReader";
import { MAX_FILE_BYTES } from "../../src/lib/files";

Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });
class ControlledReader {
  static instances: ControlledReader[] = [];
  readyState = 0;
  result: string | null = null;
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  abort = vi.fn(() => { this.readyState = 2; });
  readAsText = vi.fn(() => { this.readyState = 1; });
  readAsDataURL = vi.fn(() => { this.readyState = 1; });
  constructor() { ControlledReader.instances.push(this); }
  finish(value: string) { this.result = value; this.readyState = 2; this.onload?.(); }
}
let host: HTMLDivElement, root: Root;
let api: ReturnType<typeof useFileReader>;
function Input({ receive, mode = "text" }: { receive: (s: string) => void; mode?: "text" | "dataURL" }) {
  const reader = useFileReader(receive, mode);
  React.useEffect(() => { api = reader; });
  return <p role="alert">{reader.fileError}</p>;
}
const file = () => new File(["value"], "input.txt");
beforeEach(() => {
  ControlledReader.instances = [];
  vi.stubGlobal("FileReader", ControlledReader);
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
});
afterEach(() => { act(() => root.unmount()); host.remove(); vi.unstubAllGlobals(); });
it("a slower previous read cannot replace the most recently selected file", () => {
  const receive = vi.fn(); act(() => root.render(<Input receive={receive} />));
  act(() => api.readFile(file())); const first = ControlledReader.instances[0];
  act(() => api.readFile(file())); const second = ControlledReader.instances[1];
  expect(first.abort).toHaveBeenCalledOnce();
  act(() => second.finish("new")); act(() => first.finish("old"));
  expect(receive.mock.calls).toEqual([["new"]]);
});
it("cancel on manual edits prevents a pending file replacing typed text", () => {
  const receive = vi.fn(); act(() => root.render(<Input receive={receive} />));
  act(() => api.readFile(file())); act(() => api.cancelRead());
  act(() => ControlledReader.instances[0].finish("late")); expect(receive).not.toHaveBeenCalled();
});
it("unmount aborts reads and ignores delayed callbacks", () => {
  const receive = vi.fn(); act(() => root.render(<Input receive={receive} />));
  act(() => api.readFile(file())); act(() => root.render(null));
  const reader = ControlledReader.instances[0]; expect(reader.abort).toHaveBeenCalledOnce();
  act(() => reader.finish("late")); expect(receive).not.toHaveBeenCalled();
});
it("an oversized replacement rejects without allocating another reader", () => {
  const receive = vi.fn(); act(() => root.render(<Input receive={receive} />));
  act(() => api.readFile(file()));
  const large = file(); Object.defineProperty(large, "size", { value: MAX_FILE_BYTES + 1 });
  act(() => api.readFile(large)); expect(host.textContent).toContain("100 MB");
  expect(ControlledReader.instances).toHaveLength(1);
  act(() => ControlledReader.instances[0].finish("old")); expect(receive).not.toHaveBeenCalled();
});
it("reports read errors and clears the error on a new selection", () => {
  act(() => root.render(<Input receive={vi.fn()} />)); act(() => api.readFile(file()));
  act(() => ControlledReader.instances[0].onerror?.()); expect(host.textContent).toContain("could not be read");
  act(() => api.readFile(file())); expect(host.textContent).toBe("");
  act(() => ControlledReader.instances[0].onerror?.()); expect(host.textContent).toBe("");
});
it("data URL input delivers its complete binary-safe result", () => {
  const receive = vi.fn(); act(() => root.render(<Input receive={receive} mode="dataURL" />));
  act(() => api.readFile(file())); const reader = ControlledReader.instances[0];
  expect(reader.readAsDataURL).toHaveBeenCalledOnce(); expect(reader.readAsText).not.toHaveBeenCalled();
  act(() => reader.finish("data:application/octet-stream;base64,AP8="));
  expect(receive).toHaveBeenCalledWith("data:application/octet-stream;base64,AP8=");
});
it("uses the latest callback without restarting the pending read", () => {
  const first = vi.fn(), latest = vi.fn(); act(() => root.render(<Input receive={first} />));
  act(() => api.readFile(file())); act(() => root.render(<Input receive={latest} />));
  act(() => ControlledReader.instances[0].finish("value"));
  expect(first).not.toHaveBeenCalled(); expect(latest).toHaveBeenCalledWith("value");
});
