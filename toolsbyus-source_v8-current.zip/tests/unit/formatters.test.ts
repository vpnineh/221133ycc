import { describe, it, expect } from "vitest";
import { formatSql, minifySql, tokenizeSql, SQL_DEFAULTS } from "../../src/lib/format/sql";
import {
  formatCss,
  minifyCss,
  analyseCss,
  tokenizeCss,
  CSS_DEFAULTS,
} from "../../src/lib/format/css";
import {
  formatHtml,
  minifyHtml,
  analyseHtml,
  tokenizeHtml,
  parseHtmlAttributes,
  HTML_DEFAULTS,
} from "../../src/lib/format/html";

describe("SQL tokenising", () => {
  it("does not treat a keyword inside a string as a keyword", () => {
    // The failure every regex-based formatter has.
    const tokens = tokenizeSql("SELECT 'FROM me' AS x", "standard").filter(
      (t) => t.kind !== "whitespace"
    );
    expect(tokens.map((t) => t.kind)).toEqual(["keyword", "string", "keyword", "identifier"]);
  });

  it("handles a doubled quote inside a string", () => {
    const tokens = tokenizeSql("SELECT 'it''s'", "standard").filter((t) => t.kind === "string");
    expect(tokens[0].value).toBe("'it''s'");
  });

  it("nests block comments, which SQL allows and C does not", () => {
    const tokens = tokenizeSql("/* a /* b */ c */ SELECT 1", "standard").filter(
      (t) => t.kind === "comment"
    );
    expect(tokens[0].value).toBe("/* a /* b */ c */");
  });

  it("reads dialect-specific identifier quotes", () => {
    expect(tokenizeSql("SELECT `x`", "mysql").find((t) => t.kind === "quotedIdentifier")?.value).toBe(
      "`x`"
    );
    expect(tokenizeSql("SELECT [x]", "tsql").find((t) => t.kind === "quotedIdentifier")?.value).toBe(
      "[x]"
    );
  });

  it("reads a Postgres dollar-quoted string", () => {
    const tokens = tokenizeSql("SELECT $tag$ anything ' here $tag$", "postgres");
    expect(tokens.find((t) => t.kind === "string")?.value).toBe("$tag$ anything ' here $tag$");
  });

  it("recognises bind parameters in every spelling", () => {
    const kinds = tokenizeSql("SELECT $1, ?, :name, @id", "postgres")
      .filter((t) => t.kind === "parameter")
      .map((t) => t.value);
    expect(kinds).toEqual(["$1", "?", ":name", "@id"]);
  });

  it("keeps <= as one token", () => {
    expect(
      tokenizeSql("a <= b", "standard").filter((t) => t.kind === "operator").map((t) => t.value)
    ).toEqual(["<="]);
  });
});

describe("SQL formatting", () => {
  it("puts each clause on its own line", () => {
    const out = formatSql("select a from t where b = 1 order by a", SQL_DEFAULTS);
    expect(out.split("\n").map((l) => l.trim())).toEqual([
      "SELECT",
      "a",
      "FROM t",
      "WHERE b = 1",
      "ORDER BY a",
    ]);
  });

  it("uppercases keywords but not identifiers", () => {
    expect(formatSql("select myColumn from myTable", SQL_DEFAULTS)).toContain("myColumn");
    expect(formatSql("select myColumn from myTable", SQL_DEFAULTS)).toContain("SELECT");
  });

  it("leaves identifiers inside a string alone", () => {
    expect(formatSql("SELECT 'select from where'", SQL_DEFAULTS)).toContain(
      "'select from where'"
    );
  });

  it("does not change the quoting of a quoted identifier", () => {
    // "user" and user are different objects on a case-sensitive database.
    expect(formatSql('SELECT "User" FROM "Table"', SQL_DEFAULTS)).toContain('"User"');
  });

  it("puts each column on its own line", () => {
    const out = formatSql("select a, b, c from t", SQL_DEFAULTS);
    expect(out.split("\n").filter((l) => /^\s+[abc],?$/.test(l))).toHaveLength(3);
  });

  it("supports leading commas", () => {
    const out = formatSql("select a, b from t", { ...SQL_DEFAULTS, leadingCommas: true });
    expect(out).toMatch(/^\s+, b$/m);
  });

  it("indents joins", () => {
    const out = formatSql("select a from t inner join u on t.id = u.id", SQL_DEFAULTS);
    expect(out).toMatch(/INNER JOIN u ON t\.id = u\.id/);
  });

  it("puts AND on its own line inside WHERE but not inside parentheses", () => {
    const out = formatSql("select a from t where x = 1 and (y = 2 and z = 3)", SQL_DEFAULTS);
    expect(out).toMatch(/^\s+AND \(y = 2 AND z = 3\)$/m);
  });

  it("does not put a space before a function's parenthesis", () => {
    expect(formatSql("select count(*) from t", SQL_DEFAULTS)).toContain("count(*)");
  });

  it("keeps a line comment on its own line", () => {
    const out = formatSql("-- a note\nselect 1", SQL_DEFAULTS);
    expect(out.split("\n")[0]).toBe("-- a note");
  });

  it("separates statements", () => {
    const out = formatSql("select 1; select 2;", SQL_DEFAULTS);
    expect(out).toContain(";");
    expect(out.split(/\n\s*\n/)).toHaveLength(2);
  });

  it("is idempotent", () => {
    // Formatting formatted output must not change it, or every save churns the
    // diff.
    const once = formatSql("select a, b from t where c = 1", SQL_DEFAULTS);
    expect(formatSql(once, SQL_DEFAULTS)).toBe(once);
  });
});

describe("SQL minifying", () => {
  it("collapses to one line, keeping only the spaces that separate words", () => {
    expect(minifySql("SELECT a,\n  b\nFROM t", "standard")).toBe("SELECT a,b FROM t");
  });

  it("turns a line comment into a block comment", () => {
    // On one line, a -- comment would comment out the rest of the query.
    const out = minifySql("SELECT 1 -- note\n, 2", "standard");
    expect(out).toContain("/*note*/");
    expect(out).not.toContain("--");
  });

  it("preserves whitespace inside a string", () => {
    expect(minifySql("SELECT '  spaced  '", "standard")).toContain("'  spaced  '");
  });
});

describe("CSS", () => {
  it("formats a rule", () => {
    expect(formatCss("a{color:red;background:blue}", CSS_DEFAULTS)).toBe(
      "a {\n  color: red;\n  background: blue;\n}\n"
    );
  });

  it("puts each selector in a list on its own line", () => {
    expect(formatCss("a,b{color:red}", CSS_DEFAULTS)).toContain("a,\nb {");
  });

  it("does not split a comma inside :is()", () => {
    // Splitting on a bare comma breaks :is(a, b) and nth-child(2n, 3).
    expect(formatCss(":is(a, b) span{color:red}", CSS_DEFAULTS)).toContain(":is(a, b) span {");
  });

  it("does not split on a colon inside a url", () => {
    const out = formatCss("a{background:url(https://x.dev/i.png)}", CSS_DEFAULTS);
    expect(out).toContain("background: url(https://x.dev/i.png);");
  });

  it("does not treat a brace inside a string as structure", () => {
    const out = formatCss('a{content:"}"}', CSS_DEFAULTS);
    expect(out).toContain('content: "}"');
  });

  it("does not treat a brace inside a comment as structure", () => {
    expect(tokenizeCss("/* } */ a{color:red}").filter((t) => t.kind === "block-open")).toHaveLength(
      1
    );
  });

  it("indents nested at-rules", () => {
    const out = formatCss("@media (min-width:40em){a{color:red}}", CSS_DEFAULTS);
    expect(out).toBe("@media (min-width:40em) {\n  a {\n    color: red;\n  }\n}\n");
  });

  it("handles a declaration with no trailing semicolon", () => {
    expect(formatCss("a{color:red}", CSS_DEFAULTS)).toContain("color: red;");
  });

  it("strips comments on request", () => {
    expect(formatCss("/* note */a{color:red}", { ...CSS_DEFAULTS, keepComments: false })).not.toContain(
      "note"
    );
  });

  it("is idempotent", () => {
    const once = formatCss("a,b{color:red;margin:0}", CSS_DEFAULTS);
    expect(formatCss(once, CSS_DEFAULTS)).toBe(once);
  });

  it("minifies and reports the saving", () => {
    const result = minifyCss("a {\n  color: red;\n  margin: 0;\n}\n");
    expect(result.output).toBe("a{color:red;margin:0}");
    expect(result.savedPercent).toBeGreaterThan(30);
  });

  it("keeps a licence comment when minifying", () => {
    // Stripping /*! … */ may actually breach the licence it carries.
    expect(minifyCss("/*! (c) someone */a{color:red}").output).toContain("(c) someone");
    expect(minifyCss("/* internal */a{color:red}").output).not.toContain("internal");
  });

  it("counts what is in a stylesheet", () => {
    const stats = analyseCss("@media print{a,b{color:red;--x:1}}");
    expect(stats).toMatchObject({
      atRules: 1,
      rules: 1,
      selectors: 2,
      declarations: 2,
      customProperties: 1,
      maxNesting: 2,
    });
  });
});

describe("HTML", () => {
  it("does not indent after a void element", () => {
    // Treating <hr> as opening a scope pushes the whole document one level
    // right and never recovers.
    const out = formatHtml("<div><hr><p>x</p></div>", HTML_DEFAULTS);
    expect(out).toBe("<div>\n  <hr>\n  <p>\n    x\n  </p>\n</div>\n");
  });

  it("keeps an inline void element in the text flow", () => {
    // <br> is inline: putting it on its own line would be safe here and is not
    // in general, so it stays where the author put it.
    expect(formatHtml("<p>a<br>b</p>", HTML_DEFAULTS)).toBe("<p>\n  a<br>b\n</p>\n");
  });

  it("recognises every void element", () => {
    const out = formatHtml("<div><img src=a><hr><input></div>", HTML_DEFAULTS);
    expect(out.split("\n").filter((l) => l.startsWith("  ")).length).toBe(3);
  });

  it("does not parse markup inside a script", () => {
    // A < inside a script is a less-than sign, not a tag.
    const tokens = tokenizeHtml("<script>if (a < b) {}</script>");
    expect(tokens.find((t) => t.kind === "raw")?.content).toBe("if (a < b) {}");
  });

  it("preserves the contents of pre exactly", () => {
    const source = "<pre>  keep\n    this  </pre>";
    expect(formatHtml(source, HTML_DEFAULTS)).toContain("  keep\n    this");
  });

  it("keeps whitespace between inline elements", () => {
    // <b>a</b> <i>b</i> and <b>a</b><i>b</i> render differently.
    const out = formatHtml("<p><b>a</b> <i>b</i></p>", HTML_DEFAULTS);
    expect(out).toContain("<b>a</b> <i>b</i>");
  });

  it("tolerates an omitted closing tag", () => {
    const out = formatHtml("<ul><li>a<li>b</ul>", HTML_DEFAULTS);
    expect(out.split("\n").filter((l) => l.includes("<li>"))).toHaveLength(2);
    expect(out).toContain("</ul>");
  });

  it("does not end a tag at a > inside an attribute value", () => {
    const tokens = tokenizeHtml('<a title="a > b">x</a>');
    expect(tokens[0].raw).toBe('<a title="a > b">');
  });

  it("parses attributes in every quoting style", () => {
    expect(parseHtmlAttributes('<a href="x" target=\'y\' rel=z disabled>')).toEqual([
      { name: "href", value: "x", quote: '"' },
      { name: "target", value: "y", quote: "'" },
      { name: "rel", value: "z", quote: "" },
      { name: "disabled", quote: "" },
    ]);
  });

  it("wraps a tag with many attributes", () => {
    const out = formatHtml(
      '<input type="text" name="a" id="b" class="c" required>',
      HTML_DEFAULTS
    );
    expect(out.split("\n").length).toBeGreaterThan(3);
  });

  it("keeps the doctype", () => {
    expect(formatHtml("<!DOCTYPE html><html></html>", HTML_DEFAULTS)).toMatch(/^<!DOCTYPE html>/);
  });

  it("is idempotent", () => {
    const once = formatHtml("<div><p>a</p><br><ul><li>x</li></ul></div>", HTML_DEFAULTS);
    expect(formatHtml(once, HTML_DEFAULTS)).toBe(once);
  });

  it("reports accessibility and inline-asset counts", () => {
    const stats = analyseHtml('<img src=a><img src=b alt=x><div style="color:red"></div><script>1</script>');
    expect(stats).toMatchObject({ missingAlt: 1, inlineStyles: 1, inlineScripts: 1 });
  });

  it("names an unclosed element", () => {
    expect(analyseHtml("<div><span></div>").unclosed).toContain("span");
  });

  it("minifies without joining inline elements", () => {
    expect(minifyHtml("<p>  a  </p>\n<p>b</p>")).toBe("<p> a </p><p>b</p>");
    expect(minifyHtml("<b>a</b>\n<i>b</i>")).toBe("<b>a</b> <i>b</i>");
  });

  it("keeps a conditional comment, which is markup to old IE", () => {
    expect(minifyHtml("<!--[if IE]>x<![endif]-->")).toContain("[if IE]");
    expect(minifyHtml("<!-- ordinary -->")).toBe("");
  });

  it("does not collapse whitespace inside a pre when minifying", () => {
    expect(minifyHtml("<pre>a   b</pre>")).toContain("a   b");
  });
});
