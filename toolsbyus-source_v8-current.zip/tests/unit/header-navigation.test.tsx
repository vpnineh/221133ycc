// @vitest-environment happy-dom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
const state = vi.hoisted(() => ({ pathname: "/compress-image" }));
vi.mock("next/navigation", () => ({ usePathname: () => state.pathname }));
vi.mock("next/link", () => ({ default: ({ prefetch: _prefetch, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement> & { prefetch?: boolean }) => { void _prefetch; return <a {...props} />; } }));
vi.mock("../../src/components/common/ThemeToggle", () => ({ ThemeToggle: () => <button>Theme</button> }));
import { Header } from "../../src/components/common/Header";
Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });
let host: HTMLDivElement, root: Root;
const get = (id: string) => host.querySelector<HTMLElement>(`#${id}`)!;
const key = (target: HTMLElement, name: string) => act(() => target.dispatchEvent(new KeyboardEvent("keydown", { key: name, bubbles: true })));
const click = (target: HTMLElement) => act(() => target.click());
beforeEach(() => { vi.useFakeTimers(); state.pathname = "/compress-image"; host = document.createElement("div"); document.body.append(host); root = createRoot(host); act(() => root.render(<Header />)); });
afterEach(() => { act(() => root.unmount()); host.remove(); vi.useRealTimers(); });
it("marks both Image and its active child", () => {
  expect(get("trigger-image").getAttribute("data-active")).toBe("true");
  expect(get("trigger-image").getAttribute("aria-current")).toBe("true");
  expect(get("menu-image").querySelector('[href="/compress-image"]')?.getAttribute("aria-current")).toBe("page");
  expect(get("trigger-pdf").getAttribute("data-active")).toBeNull();
});
it("click toggles the disclosure and Escape restores trigger focus", () => {
  const trigger = get("trigger-image"); click(trigger); expect(get("menu-image").hidden).toBe(false);
  click(trigger); expect(get("menu-image").hidden).toBe(true);
  click(trigger); key(trigger, "Escape"); expect(get("menu-image").hidden).toBe(true); expect(document.activeElement).toBe(trigger);
});
it("ArrowDown opens the menu at its first link", () => {
  key(get("trigger-image"), "ArrowDown"); expect(get("menu-image").hidden).toBe(false);
  expect(document.activeElement).toBe(get("menu-image").querySelector("a"));
});
it("pointer and keyboard focus outside the navigation close the menu", () => {
  click(get("trigger-image")); act(() => document.body.dispatchEvent(new Event("pointerdown", { bubbles: true })));
  expect(get("menu-image").hidden).toBe(true); click(get("trigger-image"));
  const button = document.createElement("button"); document.body.append(button); act(() => button.focus());
  expect(get("menu-image").hidden).toBe(true); button.remove();
});
it("a first click on the hovered menu pins it open", () => {
  const trigger = get("trigger-image");
  const event = new Event("pointerover", { bubbles: true }); Object.defineProperty(event, "pointerType", { value: "mouse" });
  act(() => { trigger.dispatchEvent(event); vi.advanceTimersByTime(130); });
  expect(get("menu-image").hidden).toBe(false); click(trigger); expect(get("menu-image").hidden).toBe(false);
  click(trigger); expect(get("menu-image").hidden).toBe(true);
});
it("changing route closes a menu and updates the active parent", () => {
  click(get("trigger-image")); state.pathname = "/merge-pdf"; act(() => root.render(<Header />));
  expect(get("menu-image").hidden).toBe(true); expect(get("trigger-pdf").getAttribute("data-active")).toBe("true");
});
it("a pending hover timer cannot reopen the old menu after navigation", () => {
  const event = new Event("pointerover", { bubbles: true }); Object.defineProperty(event, "pointerType", { value: "mouse" });
  act(() => get("trigger-image").dispatchEvent(event));
  state.pathname = "/merge-pdf"; act(() => root.render(<Header />));
  act(() => vi.advanceTimersByTime(200));
  expect(get("menu-image").hidden).toBe(true);
});
it("mobile Escape closes navigation and returns focus", () => {
  const trigger = host.querySelector<HTMLElement>('[aria-controls="mobile-navigation"]')!;
  click(trigger); expect(host.querySelector("#mobile-navigation")).not.toBeNull();
  key(trigger, "Escape"); expect(host.querySelector("#mobile-navigation")).toBeNull(); expect(document.activeElement).toBe(trigger);
});
