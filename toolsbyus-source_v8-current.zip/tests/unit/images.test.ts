import { describe, it, expect } from "vitest";
import { looksLikeHeic, MAX_HEIC_PIXELS } from "../../src/lib/images/heic";
import { fitWithin, formatOfFile, FORMAT_EXTENSION, FORMAT_MIME, SIZE_PRESETS } from "../../src/lib/images";
import { applyDrag, centredRect } from "../../src/components/tools/CropCanvas";
import { render } from "../../src/app/image-to-base64/ImageToBase64Client";

/**
 * Unit coverage for the image tools' pure logic.
 *
 * What is deliberately not here: anything that touches a canvas. Encoding,
 * decoding and the stepped downscale all need a real browser image pipeline,
 * and a fake one would test the fake. Those paths are covered in
 * `tests/e2e/image-tools.spec.ts`, which drives a real Chromium and reads the
 * pixels back out of the result.
 *
 * HEIC decoding is a third case: it needs a real HEIC file, and no HEIC encoder
 * exists in this build environment to produce a fixture with. The container
 * sniffing below is testable without one — an `ftyp` box is a header, not an
 * image — and it is also where the interesting mistakes are, since the decision
 * to load a two-megabyte decoder hangs on it. See AUDIT.md.
 */

/** Builds an ISO base media `ftyp` box: size, "ftyp", major brand, then the rest. */
function ftyp(major: string, compatible: string[] = []): Uint8Array {
  const size = 16 + compatible.length * 4;
  const bytes = new Uint8Array(size + 8);
  new DataView(bytes.buffer).setUint32(0, size);
  const write = (text: string, at: number) => {
    for (let index = 0; index < 4; index++) bytes[at + index] = text.charCodeAt(index);
  };
  write("ftyp", 4);
  write(major, 8);
  // Minor version occupies 12..16.
  compatible.forEach((brand, index) => write(brand, 16 + index * 4));
  return bytes;
}

describe("looksLikeHeic", () => {
  it("accepts what an iPhone writes", () => {
    expect(looksLikeHeic(ftyp("heic", ["mif1", "miaf", "MiHB"]))).toBe(true);
  });

  it("accepts the generic HEIF brand a Google Photos export uses", () => {
    expect(looksLikeHeic(ftyp("mif1", ["heic"]))).toBe(true);
  });

  it("finds a HEIC brand that appears only in the compatible list", () => {
    expect(looksLikeHeic(ftyp("miaf", ["msf1", "heix"]))).toBe(true);
  });

  it("accepts every brand in the HEVC family", () => {
    for (const brand of ["heic", "heix", "heim", "heis", "hevc", "hevx", "hevm", "hevs"]) {
      expect(looksLikeHeic(ftyp(brand)), brand).toBe(true);
    }
  });

  // AVIF is the same container. Browsers decode it natively, so treating a
  // failed AVIF as a HEIC would download libheif for nothing and then blame the
  // wrong format in the error message.
  it("rejects AVIF, which shares the container", () => {
    expect(looksLikeHeic(ftyp("avif", ["mif1", "miaf"]))).toBe(false);
    expect(looksLikeHeic(ftyp("avis", ["avif"]))).toBe(false);
  });

  it("rejects a JPEG", () => {
    const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0, 1]);
    expect(looksLikeHeic(jpeg)).toBe(false);
  });

  it("rejects a PNG", () => {
    const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13]);
    expect(looksLikeHeic(png)).toBe(false);
  });

  it("rejects an MP4, which is ISOBMFF but not an image", () => {
    expect(looksLikeHeic(ftyp("isom", ["iso2", "avc1", "mp41"]))).toBe(false);
  });

  it("rejects a buffer too short to hold a brand", () => {
    expect(looksLikeHeic(new Uint8Array([0, 0, 0, 24, 0x66, 0x74, 0x79, 0x70]))).toBe(false);
    expect(looksLikeHeic(new Uint8Array(0))).toBe(false);
  });

  // A truncated read must not make the scan walk past the end of the buffer.
  it("does not read past the end when the box claims to be longer than the data", () => {
    const bytes = ftyp("mif1", ["heic"]).slice(0, 18);
    new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).setUint32(0, 4096);
    expect(() => looksLikeHeic(bytes)).not.toThrow();
  });

  it("keeps a pixel ceiling low enough that the RGBA buffer is not absurd", () => {
    // 50 MP x 4 bytes is 200 MB, which is already the outer edge of sane.
    expect(MAX_HEIC_PIXELS * 4).toBeLessThanOrEqual(220 * 1024 * 1024);
  });
});

describe("fitWithin", () => {
  it("fits a landscape image into a square box by its width", () => {
    expect(fitWithin({ width: 4000, height: 3000 }, { width: 1600, height: 1600 })).toEqual({
      width: 1600,
      height: 1200,
    });
  });

  it("fits a portrait image into a square box by its height", () => {
    expect(fitWithin({ width: 3000, height: 4000 }, { width: 1600, height: 1600 })).toEqual({
      width: 1200,
      height: 1600,
    });
  });

  it("takes a width-only box", () => {
    expect(fitWithin({ width: 4032, height: 3024 }, { width: 1008 })).toEqual({
      width: 1008,
      height: 756,
    });
  });

  // The whole point of the cap: a tool that silently enlarges hands back
  // something larger and blurrier than the input.
  it("never enlarges", () => {
    expect(fitWithin({ width: 400, height: 300 }, { width: 2000, height: 2000 })).toEqual({
      width: 400,
      height: 300,
    });
  });

  it("never returns a zero dimension for an extreme panorama", () => {
    const result = fitWithin({ width: 10000, height: 12 }, { width: 100 });
    expect(result.width).toBe(100);
    expect(result.height).toBeGreaterThanOrEqual(1);
  });

  it("preserves the aspect ratio to within a rounded pixel", () => {
    const source = { width: 4032, height: 3024 };
    const fitted = fitWithin(source, { width: 1000, height: 1000 });
    expect(Math.abs(fitted.width / fitted.height - source.width / source.height)).toBeLessThan(0.01);
  });
});

describe("formatOfFile", () => {
  const fake = (name: string, type: string) => ({ name, type }) as File;

  it("prefers the reported MIME type", () => {
    expect(formatOfFile(fake("photo.txt", "image/png"))).toBe("png");
    expect(formatOfFile(fake("photo.png", "image/jpeg"))).toBe("jpeg");
  });

  it("falls back to the extension when the type is empty", () => {
    expect(formatOfFile(fake("shot.webp", ""))).toBe("webp");
    expect(formatOfFile(fake("shot.AVIF", ""))).toBe("avif");
  });

  // Nothing on a canvas can write HEIC or TIFF, so "keep the format" has to
  // resolve to something the encoder can actually produce.
  it("resolves an unwritable format to JPEG", () => {
    expect(formatOfFile(fake("IMG_1.HEIC", "image/heic"))).toBe("jpeg");
    expect(formatOfFile(fake("scan.tiff", "image/tiff"))).toBe("jpeg");
  });

  it("agrees with the extension and MIME tables for every format", () => {
    for (const [format, extension] of Object.entries(FORMAT_EXTENSION)) {
      expect(formatOfFile(fake(`x.${extension}`, ""))).toBe(format);
      expect(FORMAT_MIME[format as keyof typeof FORMAT_MIME]).toMatch(/^image\//);
    }
  });
});

describe("SIZE_PRESETS", () => {
  it("has a note and a sane size on every entry", () => {
    for (const preset of SIZE_PRESETS) {
      expect(preset.note.length).toBeGreaterThan(10);
      expect(preset.width).toBeGreaterThan(0);
      expect(preset.height).toBeGreaterThan(0);
      expect(preset.width).toBeLessThanOrEqual(4096);
    }
  });
});

describe("centredRect", () => {
  it("centres a free rectangle", () => {
    const rect = centredRect(1000, 800, null);
    expect(rect.x + rect.width / 2).toBeCloseTo(500);
    expect(rect.y + rect.height / 2).toBeCloseTo(400);
  });

  it("fills the width when the ratio is wider than the image", () => {
    const rect = centredRect(1000, 1000, 16 / 9);
    expect(rect.width).toBe(1000);
    expect(rect.height).toBeCloseTo(562.5);
    expect(rect.y).toBeCloseTo((1000 - 562.5) / 2);
  });

  it("fills the height when the ratio is taller than the image", () => {
    const rect = centredRect(1000, 400, 1);
    expect(rect.height).toBe(400);
    expect(rect.width).toBe(400);
    expect(rect.x).toBe(300);
  });

  it("never produces a rectangle outside the image", () => {
    for (const aspect of [null, 1, 4 / 3, 16 / 9, 1.91]) {
      const rect = centredRect(1234, 567, aspect);
      expect(rect.x).toBeGreaterThanOrEqual(0);
      expect(rect.y).toBeGreaterThanOrEqual(0);
      expect(rect.x + rect.width).toBeLessThanOrEqual(1234.001);
      expect(rect.y + rect.height).toBeLessThanOrEqual(567.001);
    }
  });
});

describe("applyDrag", () => {
  const origin = { x: 100, y: 100, width: 400, height: 300 };

  it("moves the rectangle without changing its size", () => {
    const moved = applyDrag({ handle: "move", origin }, 50, -30, 1000, 800, null);
    expect(moved).toEqual({ x: 150, y: 70, width: 400, height: 300 });
  });

  it("clamps a move to the image rather than letting it leave", () => {
    const moved = applyDrag({ handle: "move", origin }, 10_000, 10_000, 1000, 800, null);
    expect(moved.x).toBe(600);
    expect(moved.y).toBe(500);
    expect(moved.width).toBe(400);
  });

  it("resizes from the south-east corner, keeping the north-west anchored", () => {
    const resized = applyDrag({ handle: "se", origin }, 100, 50, 1000, 800, null);
    expect(resized.x).toBe(100);
    expect(resized.y).toBe(100);
    expect(resized.width).toBe(500);
    expect(resized.height).toBe(350);
  });

  it("resizes from the north-west corner, keeping the south-east anchored", () => {
    const resized = applyDrag({ handle: "nw", origin }, -50, -50, 1000, 800, null);
    expect(resized.x).toBe(50);
    expect(resized.y).toBe(50);
    expect(resized.x + resized.width).toBe(500);
    expect(resized.y + resized.height).toBe(400);
  });

  it("holds a locked ratio while dragging", () => {
    const resized = applyDrag({ handle: "se", origin }, 200, 0, 2000, 2000, 1);
    expect(resized.width).toBeCloseTo(resized.height);
  });

  // The ordering bug this guards against: clamp first and the ratio breaks;
  // enforce the ratio only once and hitting an edge leaves it broken anyway.
  it("keeps the ratio intact when the drag runs into an edge", () => {
    const resized = applyDrag({ handle: "se", origin }, 5000, 5000, 1000, 800, 16 / 9);
    expect(resized.x + resized.width).toBeLessThanOrEqual(1000.001);
    expect(resized.y + resized.height).toBeLessThanOrEqual(800.001);
    expect(resized.width / resized.height).toBeCloseTo(16 / 9, 3);
  });

  it("refuses to collapse below a usable minimum", () => {
    const resized = applyDrag({ handle: "se", origin }, -10_000, -10_000, 1000, 800, null);
    expect(resized.width).toBeGreaterThanOrEqual(16);
    expect(resized.height).toBeGreaterThanOrEqual(16);
  });

  it("never leaves the image on any handle", () => {
    for (const handle of ["nw", "ne", "sw", "se"] as const) {
      for (const [dx, dy] of [
        [900, 900],
        [-900, -900],
        [900, -900],
        [-900, 900],
      ]) {
        const rect = applyDrag({ handle, origin }, dx, dy, 1000, 800, null);
        expect(rect.x, `${handle} ${dx},${dy}`).toBeGreaterThanOrEqual(-0.001);
        expect(rect.y).toBeGreaterThanOrEqual(-0.001);
        expect(rect.x + rect.width).toBeLessThanOrEqual(1000.001);
        expect(rect.y + rect.height).toBeLessThanOrEqual(800.001);
      }
    }
  });
});

describe("data URI snippets", () => {
  const uri = "data:image/png;base64,iVBORw0KGgo=";

  it("returns the URI alone by default", () => {
    expect(render("uri", uri, "iVBORw0KGgo=", "icon.png")).toBe(uri);
  });

  it("returns the base64 without the prefix when asked", () => {
    expect(render("raw", uri, "iVBORw0KGgo=", "icon.png")).toBe("iVBORw0KGgo=");
  });

  it("produces CSS that contains the URI inside url()", () => {
    const css = render("css", uri, "", "icon.png");
    expect(css).toContain(`url("${uri}")`);
    expect(css).toContain("background-image");
  });

  it("produces an img element with an alt attribute to fill in", () => {
    const html = render("html", uri, "", "icon.png");
    expect(html).toContain(`src="${uri}"`);
    expect(html).toContain('alt=""');
  });

  it("produces JSON that parses back to the same URI", () => {
    const parsed = JSON.parse(render("json", uri, "", "icon.png"));
    expect(parsed.dataUri).toBe(uri);
    expect(parsed.name).toBe("icon.png");
  });

  it("produces Markdown image syntax", () => {
    expect(render("markdown", uri, "", "icon.png")).toBe(`![icon.png](${uri})`);
  });
});
