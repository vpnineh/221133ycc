import { describe, it, expect } from "vitest";
import { parseJson } from "../../src/lib/json/parser";
import { formatJson, stripJsonComments } from "../../src/lib/json/formatter";
import { minifyJson } from "../../src/lib/json/minifier";
import { PRETTY_PRINT_RECIPES } from "../../src/lib/json/recipes";

describe("JSON Core Parser & Validator", () => {
  it("parses valid JSON with diverse types", () => {
    const raw = '{"name": "Alice", "age": 30, "admin": false, "tags": ["a", "b"], "meta": null}';
    const res = parseJson(raw);
    expect(res.success).toBe(true);
    if (res.success) {
      expect(res.data).toEqual({
        name: "Alice",
        age: 30,
        admin: false,
        tags: ["a", "b"],
        meta: null,
      });
    }
  });

  it("detects and rejects Byte Order Mark (BOM) at line 1, col 1", () => {
    const bomInput = "\uFEFF{\"a\": 1}";
    const res = parseJson(bomInput);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("BOM");
      expect(res.error.line).toBe(1);
      expect(res.error.column).toBe(1);
      expect(res.error.message).toContain("BOM");
    }
  });

  it("detects and rejects smart quotes with caret pointing at character", () => {
    const smartQuotes = '{\n  “title”: "Hello"\n}';
    const res = parseJson(smartQuotes);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("SMART_QUOTES");
      expect(res.error.line).toBe(2);
      expect(res.error.column).toBe(3);
      expect(res.error.caretSnippet).toContain("^");
    }
  });

  it("detects and rejects single quotes with line and column", () => {
    const singleQuotes = '{\n  \'user\': "Bob"\n}';
    const res = parseJson(singleQuotes);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("SINGLE_QUOTES");
      expect(res.error.line).toBe(2);
      expect(res.error.column).toBe(3);
    }
  });

  it("detects and rejects unquoted keys", () => {
    const unquoted = '{\n  username: "alice"\n}';
    const res = parseJson(unquoted);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("UNQUOTED_KEY");
      expect(res.error.line).toBe(2);
      expect(res.error.message).toContain("username");
    }
  });

  it("detects and rejects trailing commas in objects and arrays", () => {
    const trailingObj = '{\n  "a": 1,\n  "b": 2,\n}';
    const resObj = parseJson(trailingObj);
    expect(resObj.success).toBe(false);
    if (!resObj.success) {
      expect(resObj.error.errorType).toBe("TRAILING_COMMA");
    }

    const trailingArr = '[\n  1,\n  2,\n]';
    const resArr = parseJson(trailingArr);
    expect(resArr.success).toBe(false);
    if (!resArr.success) {
      expect(resArr.error.errorType).toBe("TRAILING_COMMA");
    }
  });

  it("detects and rejects missing commas", () => {
    const missingComma = '{\n  "a": 1\n  "b": 2\n}';
    const res = parseJson(missingComma);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("MISSING_COMMA");
    }
  });

  it("detects and rejects mismatched brackets", () => {
    const mismatched = '{\n  "arr": [1, 2, 3}\n}';
    const res = parseJson(mismatched);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("MISMATCHED_BRACKET");
    }
  });

  it("detects and rejects truncated documents", () => {
    const truncated = '{"user": {"name": "Charlie"';
    const res = parseJson(truncated);
    expect(res.success).toBe(false);
    if (!res.success) {
      expect(res.error.errorType).toBe("TRUNCATED_DOCUMENT");
    }
  });

  it("detects and rejects NaN and Infinity", () => {
    const nanInput = '{"val": NaN}';
    const resNan = parseJson(nanInput);
    expect(resNan.success).toBe(false);
    if (!resNan.success) {
      expect(resNan.error.errorType).toBe("NAN_INFINITY_REJECTED");
    }

    const infInput = '{"val": Infinity}';
    const resInf = parseJson(infInput);
    expect(resInf.success).toBe(false);
    if (!resInf.success) {
      expect(resInf.error.errorType).toBe("NAN_INFINITY_REJECTED");
    }
  });

  it("handles duplicate keys with warnings rather than crashing", () => {
    const duplicate = '{"key": 1, "key": 2}';
    const res = parseJson(duplicate);
    expect(res.success).toBe(true);
    if (res.success) {
      expect(res.warnings).toBeDefined();
      expect(res.warnings![0]).toContain("Duplicate key 'key'");
    }
  });

  it("parses 10,000-level deep nesting without call stack overflow", () => {
    const depth = 10000;
    const deepJson = "[".repeat(depth) + "42" + "]".repeat(depth);
    const res = parseJson(deepJson);
    expect(res.success).toBe(true);
  });
});

describe("JSON Formatter & Minifier", () => {
  it("strips comments from JSONC input", () => {
    const jsonc = `
    // This is a configuration file
    {
      /* Multi-line
         comment */
      "endpoint": "https://api.example.com", // trailing comment
      "active": true
    }
    `;
    const check = stripJsonComments(jsonc);
    expect(check.hadComments).toBe(true);
    expect(check.commentCount).toBe(3);

    const fmt = formatJson(jsonc, { indent: 2, sortKeys: true });
    expect(fmt.success).toBe(true);
    expect(fmt.hadComments).toBe(true);
    expect(fmt.formatted).toContain('"active": true');
  });

  it("minifies JSON and generates key shortening report and gzip estimation", () => {
    const sample = JSON.stringify({
      transactionIdentification: "TX12345",
      transactionTimestamp: "2026-09-09T00:00:00Z",
      transactionStatus: "COMPLETED",
      items: [
        { transactionIdentification: "TX12345", transactionStatus: "COMPLETED" },
        { transactionIdentification: "TX12345", transactionStatus: "COMPLETED" },
      ],
    }, null, 2);

    const min = minifyJson(sample);
    expect(min.success).toBe(true);
    expect(min.result).toBeDefined();
    expect(min.result!.reductionPercent).toBeGreaterThan(0);
    expect(min.result!.estimatedGzipBytes).toBeGreaterThan(0);
    expect(min.keySuggestions).toBeDefined();
    expect(min.keySuggestions!.length).toBeGreaterThan(0);
    expect(min.keySuggestions![0].originalKey).toBe("transactionIdentification");
  });
});

describe("pretty-print recipes", () => {
  it("gives every language a distinct entry with real content", () => {
    const ids = PRETTY_PRINT_RECIPES.map((entry) => entry.id);
    expect(new Set(ids).size).toBe(ids.length);

    const languages = PRETTY_PRINT_RECIPES.map((entry) => entry.language);
    expect(new Set(languages).size).toBe(languages.length);

    for (const entry of PRETTY_PRINT_RECIPES) {
      expect(entry.code.length, `${entry.id} code`).toBeGreaterThan(30);
      // The gotcha is the reason this page is not a third copy of the
      // formatter. A short one means it was not written.
      expect(entry.gotcha.length, `${entry.id} gotcha`).toBeGreaterThan(120);
      expect(entry.note.length, `${entry.id} note`).toBeGreaterThan(10);
    }
  });

  it("covers the languages the page claims to cover", () => {
    const ids = new Set(PRETTY_PRINT_RECIPES.map((entry) => entry.id));
    for (const expected of [
      "javascript",
      "python",
      "jq",
      "shell",
      "go",
      "java",
      "csharp",
      "php",
      "ruby",
      "rust",
      "powershell",
    ]) {
      expect(ids, `missing recipe: ${expected}`).toContain(expected);
    }
  });

  /*
   * The JavaScript recipe's warning is a claim about the language, so it is
   * checked against the language rather than taken on trust. If a future
   * engine ever made the second argument an indent, the page would be wrong
   * and this would say so.
   */
  it("is right that JSON.stringify(value, 2) does nothing", () => {
    const value = { b: 1, a: [1, 2] };
    // @ts-expect-error — deliberately the wrong call, which is the point.
    expect(JSON.stringify(value, 2)).toBe(JSON.stringify(value));
    expect(JSON.stringify(value, null, 2)).toContain("\n  ");
  });

  it("is right that stringify drops undefined and nulls it inside arrays", () => {
    expect(JSON.stringify({ a: undefined, b: 1 })).toBe('{"b":1}');
    expect(JSON.stringify([undefined, 1])).toBe("[null,1]");
    expect(JSON.stringify(new Map([["a", 1]]))).toBe("{}");
  });
});
