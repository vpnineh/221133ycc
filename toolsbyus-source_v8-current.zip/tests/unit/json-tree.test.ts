import { describe, it, expect } from "vitest";
import {
  flattenTree,
  visibleRows,
  summarise,
  containerIds,
  searchRows,
  typeOf,
  pointerSegment,
} from "../../src/lib/json/tree";

const doc = {
  id: 1,
  user: { name: "Ada", tags: ["a", "b"] },
  active: true,
  meta: null,
};

describe("flattening", () => {
  it("emits rows in document order with depths", () => {
    const rows = flattenTree(doc as never);
    expect(rows.map((r) => `${"  ".repeat(r.depth)}${r.key}`)).toEqual([
      "root",
      "  id",
      "  user",
      "    name",
      "    tags",
      "      0",
      "      1",
      "  active",
      "  meta",
    ]);
  });

  it("addresses each row with an RFC 6901 pointer", () => {
    const rows = flattenTree(doc as never);
    expect(rows.map((r) => r.id)).toEqual([
      "/",
      "/id",
      "/user",
      "/user/name",
      "/user/tags",
      "/user/tags/0",
      "/user/tags/1",
      "/active",
      "/meta",
    ]);
  });

  it("escapes ~ and / in keys, per RFC 6901", () => {
    const rows = flattenTree({ "a/b": 1, "c~d": 2 } as never);
    expect(rows.map((r) => r.id)).toEqual(["/", "/a~1b", "/c~0d"]);
  });

  it("records where each container's subtree ends", () => {
    const rows = flattenTree(doc as never);
    const user = rows.find((r) => r.key === "user")!;
    // user spans rows 2..6 inclusive, so its subtree ends at 7.
    expect(user.endIndex).toBe(7);
    expect(rows[0].endIndex).toBe(rows.length);
  });

  it("renders strings quoted and other scalars bare", () => {
    const rows = flattenTree({ s: "x", n: 1, b: false, z: null } as never);
    expect(rows.slice(1).map((r) => r.display)).toEqual(['"x"', "1", "false", "null"]);
  });

  it("counts container children", () => {
    const rows = flattenTree(doc as never);
    expect(rows.find((r) => r.key === "tags")!.size).toBe(2);
    expect(rows[0].size).toBe(4);
  });

  it("handles empty containers", () => {
    const rows = flattenTree({ a: {}, b: [] } as never);
    expect(rows.map((r) => r.size)).toEqual([2, 0, 0]);
  });

  it("handles a scalar root", () => {
    const rows = flattenTree(42 as never);
    expect(rows).toHaveLength(1);
    expect(rows[0].display).toBe("42");
  });

  it("does not overflow the stack on a deeply nested document", () => {
    // The case a viewer exists for: the document nothing else will open.
    let deep: unknown = "leaf";
    for (let i = 0; i < 20_000; i++) deep = { n: deep };
    const rows = flattenTree(deep as never);
    expect(rows).toHaveLength(20_001);
    expect(rows[rows.length - 1].display).toBe('"leaf"');
  });
});

describe("collapsing", () => {
  it("skips a collapsed subtree in one step", () => {
    const rows = flattenTree(doc as never);
    const visible = visibleRows(rows, new Set(["/user"]));
    expect(visible.map((r) => r.key)).toEqual(["root", "id", "user", "active", "meta"]);
  });

  it("collapsing the root leaves one row regardless of size", () => {
    const rows = flattenTree(doc as never);
    expect(visibleRows(rows, new Set(["/"]))).toHaveLength(1);
  });

  it("is cheap on a large document", () => {
    // Skipping by endIndex means a collapsed subtree costs one comparison, not
    // one per hidden node.
    const big = { items: Array.from({ length: 50_000 }, (_, i) => ({ i })) };
    const rows = flattenTree(big as never);
    const start = performance.now();
    const visible = visibleRows(rows, new Set(["/items"]));
    expect(visible).toHaveLength(2);
    expect(performance.now() - start).toBeLessThan(50);
  });
});

describe("summary", () => {
  it("counts each type and the depth", () => {
    const stats = summarise(flattenTree(doc as never));
    expect(stats).toMatchObject({
      objects: 2,
      arrays: 1,
      strings: 3,
      numbers: 1,
      booleans: 1,
      nulls: 1,
      maxDepth: 3,
    });
  });

  it("does not count array indices as keys", () => {
    // A 10,000-item array would otherwise report 10,000 distinct keys.
    const stats = summarise(flattenTree({ items: ["a", "b", "c"] } as never));
    expect(stats.uniqueKeys).toBe(1);
  });
});

describe("search", () => {
  it("keeps matches and every ancestor that leads to them", () => {
    // A matched value is meaningless without the path above it.
    const keep = searchRows(flattenTree(doc as never), "Ada");
    expect([...keep].sort()).toEqual(["/", "/user", "/user/name"]);
  });

  it("matches keys as well as values", () => {
    const keep = searchRows(flattenTree(doc as never), "active");
    expect(keep.has("/active")).toBe(true);
  });

  it("is case-insensitive and returns nothing for an empty query", () => {
    expect(searchRows(flattenTree(doc as never), "ADA").has("/user/name")).toBe(true);
    expect(searchRows(flattenTree(doc as never), "  ").size).toBe(0);
  });
});

describe("helpers", () => {
  it("classifies values", () => {
    expect(typeOf(null)).toBe("null");
    expect(typeOf([])).toBe("array");
    expect(typeOf({})).toBe("object");
    expect(typeOf(1)).toBe("number");
    expect(typeOf("x")).toBe("string");
    expect(typeOf(true)).toBe("boolean");
  });

  it("escapes pointer segments", () => {
    expect(pointerSegment("a/b~c")).toBe("a~1b~0c");
  });

  it("lists the containers to expand for a given depth", () => {
    // The parameter is the depth to expand *to*, so a limit of 1 expands only
    // the root and leaves its children collapsed.
    const rows = flattenTree(doc as never);
    expect(containerIds(rows, 1)).toEqual(["/"]);
    expect(containerIds(rows, 2)).toEqual(["/", "/user"]);
    expect(containerIds(rows)).toEqual(["/", "/user", "/user/tags"]);
  });
});
