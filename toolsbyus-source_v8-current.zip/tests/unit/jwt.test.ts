import { describe, it, expect } from "vitest";
import { decodeJwt, classifyAlgorithm, looksLikeJwt } from "../../src/lib/jwt";

/** Builds a token from parts, base64url-encoded without padding, as RFC 7515 requires. */
function makeToken(header: object, payload: object, signature = "sig"): string {
  const b64 = (value: object) =>
    Buffer.from(JSON.stringify(value))
      .toString("base64")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");
  return `${b64(header)}.${b64(payload)}.${signature}`;
}

const NOW = Date.UTC(2026, 0, 1, 12, 0, 0);
const seconds = (ms: number) => Math.floor(ms / 1000);

describe("algorithm classification", () => {
  it.each([
    ["HS256", "HMAC"],
    ["RS512", "RSA"],
    ["PS384", "RSA-PSS"],
    ["ES256K", "ECDSA"],
    ["EdDSA", "EdDSA"],
    ["none", "none"],
    ["NONE", "none"],
    ["HS999", "unknown"],
  ])("reads %s as %s", (alg, family) => {
    expect(classifyAlgorithm(alg)).toBe(family);
  });
});

describe("structure", () => {
  it("decodes a well-formed token", () => {
    const token = makeToken({ alg: "HS256", typ: "JWT" }, { sub: "123", exp: seconds(NOW) + 3600 });
    const result = decodeJwt(token, NOW);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.algorithm).toBe("HS256");
      expect(result.payload.sub).toBe("123");
    }
  });

  it("strips a Bearer prefix, which is how tokens are usually copied", () => {
    const token = makeToken({ alg: "HS256" }, { sub: "x" });
    expect(decodeJwt(`Bearer ${token}`, NOW).ok).toBe(true);
  });

  it("recognises a JWE and says why it cannot be read", () => {
    const result = decodeJwt("a.b.c.d.e", NOW);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toMatch(/JWE \(five segments\)/);
  });

  it("reports the wrong segment count rather than a generic failure", () => {
    const result = decodeJwt("a.b", NOW);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toMatch(/three dot-separated segments; this has 2/);
  });

  it("names the segment that failed to decode", () => {
    const result = decodeJwt("!!!.eyJhIjoxfQ.sig", NOW);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.segment).toBe("header");
  });

  it("distinguishes decoded-but-not-JSON from not-decodable", () => {
    const notJson = Buffer.from("hello").toString("base64url");
    const result = decodeJwt(`${notJson}.${notJson}.sig`, NOW);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toMatch(/decoded, but is not valid JSON/);
  });

  it("rejects a header that is valid JSON but not an object", () => {
    const arr = Buffer.from("[1,2]").toString("base64url");
    const result = decodeJwt(`${arr}.${arr}.sig`, NOW);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toMatch(/not an object/);
  });

  it("accepts segments with no base64 padding", () => {
    // JWT segments are unpadded base64url; a decoder that demands padding
    // rejects most real tokens.
    const token = makeToken({ alg: "HS256" }, { a: 1 });
    expect(token).not.toContain("=");
    expect(decodeJwt(token, NOW).ok).toBe(true);
  });
});

describe("advisories", () => {
  const advisoriesFor = (header: object, payload: object, sig = "sig") => {
    const result = decodeJwt(makeToken(header, payload, sig), NOW);
    if (!result.ok) throw new Error(result.reason);
    return result.advisories;
  };

  it("flags alg:none as an error, not a curiosity", () => {
    const messages = advisoriesFor({ alg: "none" }, { sub: "x", exp: seconds(NOW) + 60 });
    const error = messages.find((a) => a.severity === "error");
    expect(error?.message).toMatch(/unsigned and anyone can forge/);
  });

  it("flags an empty signature segment", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { exp: seconds(NOW) + 60 }, "");
    expect(messages.some((a) => a.message.includes("signature segment is empty"))).toBe(true);
  });

  it("reports expiry in the past with a relative time", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { exp: seconds(NOW) - 4 * 3600 });
    const error = messages.find((a) => a.severity === "error");
    expect(error?.message).toMatch(/Expired 4 hours ago/);
  });

  it("warns when expiry is imminent", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { exp: seconds(NOW) + 60 });
    expect(messages.some((a) => a.message.match(/Expires in 1 minute/))).toBe(true);
  });

  it("warns when there is no exp at all", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { sub: "x" });
    expect(messages.some((a) => a.message.includes("does not expire on its own"))).toBe(true);
  });

  it("warns when exp is a string rather than a NumericDate", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { exp: "2026-01-01" });
    expect(messages.some((a) => a.message.includes("not a number"))).toBe(true);
  });

  it("explains a not-yet-valid token as probable clock skew", () => {
    const messages = advisoriesFor(
      { alg: "HS256" },
      { nbf: seconds(NOW) + 600, exp: seconds(NOW) + 3600 }
    );
    expect(messages.some((a) => a.message.includes("clock is probably ahead"))).toBe(true);
  });

  it("notes a missing audience as a replay risk", () => {
    const messages = advisoriesFor({ alg: "HS256" }, { sub: "x", exp: seconds(NOW) + 60 });
    expect(messages.some((a) => a.message.includes("replayed against another"))).toBe(true);
  });

  it("stays quiet about a healthy token", () => {
    const messages = advisoriesFor(
      { alg: "RS256", typ: "JWT" },
      { sub: "x", aud: "api", exp: seconds(NOW) + 3600, iat: seconds(NOW) }
    );
    expect(messages).toEqual([]);
  });
});

describe("claims", () => {
  it("describes registered claims and decodes their dates", () => {
    const result = decodeJwt(
      makeToken({ alg: "HS256" }, { sub: "u1", aud: "api", exp: seconds(NOW) + 3600 }),
      NOW
    );
    if (!result.ok) throw new Error(result.reason);

    const sub = result.claims.find((c) => c.name === "sub")!;
    expect(sub.registered).toBe(true);
    expect(sub.description).toMatch(/Subject/);

    const exp = result.claims.find((c) => c.name === "exp")!;
    expect(exp.decoded).toMatch(/2026-01-01 13:00:00 UTC \(in 1 hour\)/);
  });

  it("marks unregistered claims as custom", () => {
    const result = decodeJwt(makeToken({ alg: "HS256" }, { tenant_id: "acme" }), NOW);
    if (!result.ok) throw new Error(result.reason);
    const claim = result.claims.find((c) => c.name === "tenant_id")!;
    expect(claim.registered).toBe(false);
    expect(claim.description).toBeUndefined();
  });

  it("does not treat an inherited property as a claim", () => {
    // safeGet is used throughout so a payload cannot reach Object.prototype.
    const result = decodeJwt(makeToken({ alg: "HS256" }, { a: 1 }), NOW);
    if (!result.ok) throw new Error(result.reason);
    expect(result.claims.map((c) => c.name)).toEqual(["a"]);
  });
});

describe("shape test", () => {
  it.each([
    ["eyJ.eyJ.sig", true],
    ["eyJ.eyJ.", true],
    ["Bearer eyJ.eyJ.sig", true],
    ["not a token", false],
    ["a.b", false],
    ["a.b.c.d", false],
  ])("%s -> %s", (input, expected) => {
    expect(looksLikeJwt(input)).toBe(expected);
  });
});
