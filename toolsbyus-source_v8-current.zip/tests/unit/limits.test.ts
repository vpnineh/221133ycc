import { describe, it, expect } from "vitest";
import {
  byteLength,
  fastByteLength,
  checkMainThreadSize,
  formatBytes,
  MAIN_THREAD_MAX_BYTES,
  MAIN_THREAD_WARN_BYTES,
} from "../../src/lib/limits";

describe("fastByteLength", () => {
  it("agrees with TextEncoder across the UTF-8 ranges", () => {
    const samples = [
      "",
      "plain ascii",
      "café", // 2-byte
      "日本語のテキスト", // 3-byte
      "😀🎉🚀", // 4-byte, surrogate pairs
      "سلام دنیا", // RTL, 2-byte
      'mixed: a—é—日—😀 {"k":"v"}',
      "\n\t\r ",
    ];

    for (const sample of samples) {
      expect(fastByteLength(sample), JSON.stringify(sample)).toBe(byteLength(sample));
    }
  });

  it("does not allocate a copy of the input", () => {
    // A megabyte string measured many times should stay cheap; TextEncoder
    // would allocate a fresh buffer on each call.
    const big = "x".repeat(1_000_000);
    const started = performance.now();
    for (let i = 0; i < 20; i++) fastByteLength(big);
    expect(performance.now() - started).toBeLessThan(2000);
  });
});

describe("checkMainThreadSize", () => {
  it("passes ordinary input with no message", () => {
    const result = checkMainThreadSize('{"a":1}');
    expect(result.exceeded).toBe(false);
    expect(result.slow).toBe(false);
    expect(result.message).toBeNull();
  });

  it("cautions between the warn threshold and the ceiling", () => {
    const result = checkMainThreadSize("x".repeat(MAIN_THREAD_WARN_BYTES + 1024));
    expect(result.exceeded).toBe(false);
    expect(result.slow).toBe(true);
    expect(result.message).toMatch(/main thread/i);
  });

  it("refuses input above the ceiling and names both sizes", () => {
    const result = checkMainThreadSize("x".repeat(MAIN_THREAD_MAX_BYTES + 1024));
    expect(result.exceeded).toBe(true);
    expect(result.message).toContain(formatBytes(MAIN_THREAD_MAX_BYTES));
    // The message must point somewhere useful rather than just saying no.
    expect(result.message).toMatch(/JSON Diff|Web Worker/i);
  });

  it("measures bytes, not code units, so multi-byte input is not undercounted", () => {
    // Half the ceiling in 4-byte characters is over the ceiling in bytes.
    const astral = "😀".repeat(MAIN_THREAD_MAX_BYTES / 4 + 100);
    expect(checkMainThreadSize(astral).exceeded).toBe(true);
  });

  it("honours an explicit limit", () => {
    expect(checkMainThreadSize("x".repeat(200), 100).exceeded).toBe(true);
    expect(checkMainThreadSize("x".repeat(50), 100).exceeded).toBe(false);
  });
});

describe("formatBytes", () => {
  it("scales the unit to the magnitude", () => {
    expect(formatBytes(512)).toBe("512 B");
    expect(formatBytes(2048)).toBe("2.0 KB");
    expect(formatBytes(5 * 1024 * 1024)).toBe("5.0 MB");
  });
});
