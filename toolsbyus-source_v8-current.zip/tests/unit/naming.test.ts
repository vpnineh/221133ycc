import { describe, it, expect } from "vitest";
import {
  applyPattern,
  collidesInBatch,
  MAX_STEM_LENGTH,
  sanitiseFilename,
  stemOf,
  withStem,
} from "../../src/lib/files/naming";

/**
 * Filenames the user types, made safe to write.
 *
 * The interesting cases are all hostile or accidental rather than malicious:
 * a colon typed into a name, a path pasted from a terminal, a Windows device
 * name that happens to be a sensible abbreviation. Each of them fails in a
 * different and unhelpful way if it reaches a download attribute unchanged.
 */

describe("sanitiseFilename", () => {
  it("removes path separators on both conventions", () => {
    expect(sanitiseFilename("../../etc/passwd")).not.toContain("/");
    expect(sanitiseFilename("C:\\Users\\me\\report")).not.toContain("\\");
    expect(sanitiseFilename("C:\\Users\\me\\report")).not.toContain(":");
  });

  it("removes the characters Windows reserves inside a name", () => {
    for (const character of ['*', "?", '"', "<", ">", "|", ":"]) {
      expect(sanitiseFilename(`a${character}b`), character).toBe("a-b");
    }
  });

  // A NUL truncates a C string, so a name containing one can be written to a
  // path shorter than the one that was checked.
  it("removes control characters", () => {
    expect(sanitiseFilename("file\u0000name")).toBe("filename");
    expect(sanitiseFilename("tab\u0009name")).toBe("tab name");
  });

  // `report\u202egpj.exe` renders as `report exe.jpg` in a file listing.
  it("removes bidirectional overrides, which let a name render as something else", () => {
    expect(sanitiseFilename("photo\u202egpj.exe")).toBe("photogpj.exe");
    expect(sanitiseFilename("a\u2066b\u2069c")).toBe("abc");
  });

  it("refuses to produce a hidden file", () => {
    expect(sanitiseFilename(".hidden")).toBe("hidden");
    expect(sanitiseFilename("...x")).toBe("x");
  });

  // Windows silently drops these, so a name ending in one does not round-trip.
  it("trims trailing dots and spaces", () => {
    expect(sanitiseFilename("report...")).toBe("report");
    expect(sanitiseFilename("report   ")).toBe("report");
  });

  it("escapes DOS device names, extension or not", () => {
    expect(sanitiseFilename("con")).toBe("con-file");
    expect(sanitiseFilename("CON")).toBe("CON-file");
    expect(sanitiseFilename("con.pdf")).toBe("con.pdf-file");
    expect(sanitiseFilename("lpt1")).toBe("lpt1-file");
    // Not reserved: only the exact device names are.
    expect(sanitiseFilename("console")).toBe("console");
    expect(sanitiseFilename("contract")).toBe("contract");
  });

  it("caps the length with room for an extension and a browser's (1) suffix", () => {
    expect(sanitiseFilename("a".repeat(400)).length).toBe(MAX_STEM_LENGTH);
  });

  it("never returns an empty string", () => {
    expect(sanitiseFilename("")).toBe("output");
    expect(sanitiseFilename("   ")).toBe("output");
    expect(sanitiseFilename(" . ")).toBe("output");
    expect(sanitiseFilename("///")).not.toBe("");
    expect(sanitiseFilename("", "merged")).toBe("merged");
  });

  it("leaves ordinary names, including non-ASCII ones, alone", () => {
    expect(sanitiseFilename("naïve café")).toBe("naïve café");
    expect(sanitiseFilename("報告書-2026")).toBe("報告書-2026");
    expect(sanitiseFilename("invoice_2026-03 (final)")).toBe("invoice_2026-03 (final)");
  });

  it("normalises so two spellings of the same name are one filename", () => {
    // "é" as one codepoint and as e + combining acute.
    expect(sanitiseFilename("caf\u00e9")).toBe(sanitiseFilename("cafe\u0301"));
  });
});

describe("withStem", () => {
  it("joins without doubling the dot", () => {
    expect(withStem("report", "pdf")).toBe("report.pdf");
    expect(withStem("report", ".pdf")).toBe("report.pdf");
  });

  it("sanitises the stem on the way through", () => {
    expect(withStem("a/b", "pdf")).toBe("a-b.pdf");
  });

  it("takes the caller's fallback for an empty stem", () => {
    expect(withStem("", "pdf", "merged")).toBe("merged.pdf");
  });
});

describe("stemOf", () => {
  it("keeps dots inside the name", () => {
    expect(stemOf("archive.tar.gz")).toBe("archive.tar");
    expect(stemOf("report.pdf")).toBe("report");
    expect(stemOf("noextension")).toBe("noextension");
    expect(stemOf(".gitignore")).toBe(".gitignore");
  });
});

describe("applyPattern", () => {
  it("substitutes every supported token", () => {
    expect(
      applyPattern(
        "{name}-{n}-{page}-{width}x{height}-{date}",
        { name: "photo", n: 2, page: 5, width: 800, height: 600, date: "2026-09-12" },
        "jpg"
      )
    ).toBe("photo-2-5-800x600-2026-09-12.jpg");
  });

  /*
   * A token the tool does not provide is left as written rather than replaced
   * with "undefined". A mistyped token then shows up in the page's own preview
   * as `photo-{widht}.jpg`, which is a typo anyone can see, instead of
   * `photo-undefined.jpg`, which looks like a bug in the site.
   */
  it("leaves an unknown value as literal text rather than inventing one", () => {
    expect(applyPattern("{name}-{page}", { name: "doc" }, "pdf")).toBe("doc-{page}.pdf");
    expect(applyPattern("{name}-{nope}", { name: "doc" }, "pdf")).toBe("doc-{nope}.pdf");
  });

  it("sanitises after substitution, because the values come from dropped files", () => {
    // `../evil` becomes `..-evil`, whose leading dots are then stripped so the
    // result cannot be a hidden file.
    expect(applyPattern("{name}-x", { name: "../evil" }, "pdf")).toBe("-evil-x.pdf");
  });

  it("survives a pattern with no tokens at all", () => {
    expect(applyPattern("final", {}, "pdf")).toBe("final.pdf");
  });
});

describe("collidesInBatch", () => {
  it("spots a pattern that would name every file the same", () => {
    expect(collidesInBatch("export")).toBe(true);
    expect(collidesInBatch("{date}-export")).toBe(true);
    expect(collidesInBatch("{width}x{height}")).toBe(true);
  });

  it("accepts anything that varies per file", () => {
    expect(collidesInBatch("{name}")).toBe(false);
    expect(collidesInBatch("page-{n}")).toBe(false);
    expect(collidesInBatch("scan-{page}")).toBe(false);
  });
});
