// @vitest-environment happy-dom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
import { usePageFileDrop } from "../../src/components/tools/usePageFileDrop";
import { FileDropZone } from "../../src/components/tools/FileDropZone";
import { TOOL_SCENES } from "../../src/lib/tool-scenes";
import { TOOLS } from "../../src/lib/tools";

Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });
let host: HTMLDivElement;
let root: Root;
function Pane({ id, onFiles, disabled = false, enabled = true }: { id: string; onFiles: (files: FileList) => void; disabled?: boolean; enabled?: boolean }) {
  const { ref, dragging } = usePageFileDrop(onFiles, { disabled, enabled });
  return <div ref={ref} data-pane={id} data-dragging={dragging}><input aria-label={id} /></div>;
}
function drag(type: string, target: EventTarget = document.body, files: File[] = [new File(["sample"], "sample.txt", { type: "text/plain" })], types = ["Files"]) {
  const event = new Event(type, { bubbles: true, cancelable: true });
  Object.defineProperty(event, "dataTransfer", { value: { types, files, dropEffect: "none" } });
  act(() => { target.dispatchEvent(event); });
  return event;
}
beforeEach(() => {
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
  // This environment does not calculate layout; actual visibility still needs browser QA.
  vi.spyOn(HTMLElement.prototype, "getClientRects").mockReturnValue([{}] as unknown as DOMRectList);
});
afterEach(() => { act(() => root.unmount()); host.remove(); vi.restoreAllMocks(); });

describe("Page-wide file drops", () => {
  it("receives a footer drop once and prevents browser navigation", () => {
    const receive = vi.fn(); act(() => root.render(<Pane id="input" onFiles={receive} />));
    const footer = document.createElement("footer"); document.body.append(footer);
    expect(drag("drop", footer).defaultPrevented).toBe(true);
    expect(receive).toHaveBeenCalledTimes(1); footer.remove();
  });
  it("uses the first input, then the focused pane, with local target priority", () => {
    const left = vi.fn(), right = vi.fn();
    act(() => root.render(<><Pane id="left" onFiles={left} /><Pane id="right" onFiles={right} /></>));
    drag("drop"); expect(left).toHaveBeenCalledTimes(1); expect(right).not.toHaveBeenCalled();
    act(() => host.querySelector<HTMLInputElement>('[aria-label="right"]')!.focus());
    drag("drop"); expect(right).toHaveBeenCalledTimes(1);
    drag("drop", host.querySelector('[data-pane="left"]')!); expect(left).toHaveBeenCalledTimes(2);
  });
  it("does not write to a read-only pane", () => {
    const receive = vi.fn(), output = vi.fn();
    act(() => root.render(<><Pane id="output" onFiles={output} enabled={false} /><Pane id="input" onFiles={receive} /></>));
    drag("drop", host.querySelector('[data-pane="output"]')!);
    expect(output).not.toHaveBeenCalled(); expect(receive).toHaveBeenCalledTimes(1);
  });
  it("prevents navigation while busy and reads the latest handler after rerender", () => {
    const old = vi.fn(), latest = vi.fn();
    act(() => root.render(<Pane id="input" onFiles={old} disabled />));
    expect(drag("drop").defaultPrevented).toBe(true); expect(old).not.toHaveBeenCalled();
    act(() => root.render(<Pane id="input" onFiles={latest} />));
    drag("drop"); expect(latest).toHaveBeenCalledTimes(1); expect(old).not.toHaveBeenCalled();
  });
  it("leaves text and URL drags alone", () => {
    const receive = vi.fn(); act(() => root.render(<Pane id="input" onFiles={receive} />));
    expect(drag("dragover", document.body, [], ["text/plain"]).defaultPrevented).toBe(false);
    expect(drag("drop", document.body, [], ["text/uri-list"]).defaultPrevented).toBe(false);
    expect(receive).not.toHaveBeenCalled();
  });
  it("clears highlighting on Escape, drop and window blur", () => {
    act(() => root.render(<Pane id="input" onFiles={vi.fn()} />));
    const active = () => host.querySelector('[data-pane]')!.getAttribute("data-dragging");
    drag("dragenter"); expect(active()).toBe("true");
    act(() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" }))); expect(active()).toBe("false");
    drag("dragenter"); act(() => window.dispatchEvent(new Event("blur"))); expect(active()).toBe("false");
    drag("dragenter"); drag("drop"); expect(active()).toBe("false");
  });
  it("removes the global handler after the tool unmounts", () => {
    const receive = vi.fn(); act(() => root.render(<Pane id="input" onFiles={receive} />));
    act(() => root.render(<p>Another page</p>));
    expect(drag("drop").defaultPrevented).toBe(false); expect(receive).not.toHaveBeenCalled();
  });
  it("keeps the overlay when entering a child with a null related target", () => {
    act(() => root.render(<Pane id="input" onFiles={vi.fn()} />));
    const pane = host.querySelector('[data-pane]')!;
    drag("dragenter"); drag("dragenter", pane);
    drag("dragleave");
    expect(pane.getAttribute("data-dragging")).toBe("true");
    drag("dragleave"); expect(pane.getAttribute("data-dragging")).toBe("false");
  });
  it("keeps PDF validation and avoids duplicate local/global acceptance", () => {
    const receive = vi.fn();
    act(() => root.render(<FileDropZone accept={[".pdf"]} files={[]} onChange={receive} multiple />));
    drag("drop", document.body); expect(receive).not.toHaveBeenCalled();
    expect(host.textContent).toMatch(/not.*accepted|not.*supported|pdf/i);
    drag("drop", host.querySelector("button")!, [new File(["%PDF-1.7"], "sample.pdf", { type: "application/pdf" })]);
    expect(receive).toHaveBeenCalledTimes(1); expect(receive.mock.calls[0][0]).toHaveLength(1);
  });
});

it("has an explicit relevant scene for every published tool", () => {
  expect(Object.keys(TOOL_SCENES).sort()).toEqual(TOOLS.map(t => t.href.slice(1)).sort());
});
