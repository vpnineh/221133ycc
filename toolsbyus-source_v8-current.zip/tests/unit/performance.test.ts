import { describe, it, expect } from "vitest";
import { computeSemanticDiff } from "../../src/lib/diff/semantic-diff";

describe("Performance CI Budget", () => {
  it("diffs a synthetic 10 MB JSON document within CI time budget", () => {
    // Generate ~10MB synthetic payload (approx 40,000 record objects)
    const recordsCount = 35000;
    const itemsLeft: any[] = [];
    const itemsRight: any[] = [];

    for (let i = 0; i < recordsCount; i++) {
      itemsLeft.push({
        id: `rec_${i}`,
        index: i,
        status: i % 2 === 0 ? "active" : "pending",
        tags: ["alpha", "beta", `tag_${i % 10}`],
        metrics: { score: i * 1.5, rating: 4 },
        description: `This is synthetic test record number ${i} for performance benchmarking.`,
      });

      // Modify every 10th record in right
      if (i % 10 === 0) {
        itemsRight.push({
          id: `rec_${i}`,
          index: i,
          status: "updated",
          tags: ["alpha", "beta", `tag_${i % 10}`, "extra"],
          metrics: { score: i * 2.0, rating: 5 },
          description: `This is synthetic test record number ${i} for performance benchmarking. UPDATED.`,
        });
      } else {
        itemsRight.push({
          id: `rec_${i}`,
          index: i,
          status: i % 2 === 0 ? "active" : "pending",
          tags: ["alpha", "beta", `tag_${i % 10}`],
          metrics: { score: i * 1.5, rating: 4 },
          description: `This is synthetic test record number ${i} for performance benchmarking.`,
        });
      }
    }

    const payloadLeft = { dataset: "benchmark", items: itemsLeft };
    const payloadRight = { dataset: "benchmark", items: itemsRight };

    const startTime = Date.now();
    const result = computeSemanticDiff(payloadLeft, payloadRight);
    const durationMs = Date.now() - startTime;

    expect(result.summary.total).toBeGreaterThan(0);
    // CI budget: under 60,000 ms
    expect(durationMs).toBeLessThan(60000);
  });
});
