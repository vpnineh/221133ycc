import { describe, it, expect } from "vitest";
import { findConfusionPair, layoutPlate, PLATES } from "../../src/lib/color/plates";
import { simulateCvd, toHex, rgbToOklch } from "../../src/lib/color";

describe("confusion pairs", () => {
  for (const type of ["protanopia", "deuteranopia", "tritanopia"] as const) {
    it(`finds a pair that ${type} cannot separate`, () => {
      const pair = findConfusionPair(type);
      const seenFigure = simulateCvd(pair.figure, type);
      const seenGround = simulateCvd(pair.ground, type);
      // Far apart to normal vision...
      expect(
        Math.sqrt(pair.separation),
        `${toHex(pair.figure)} vs ${toHex(pair.ground)} is too subtle to read`
      ).toBeGreaterThan(0.12);
      // ...and on top of each other under the deficiency.
      expect(
        Math.sqrt(pair.residual),
        `${toHex(seenFigure)} vs ${toHex(seenGround)} is still separable`
      ).toBeLessThanOrEqual(0.02);
    });
    /*
     * Some lightness offset is allowed — protanopia darkens long wavelengths,
     * and suppressing that entirely returns a figure nobody can see. It has to
     * stay small enough that the plate is not readable by brightness alone.
     */
    it(`keeps the ${type} pair close enough in lightness to need colour`, () => {
      const pair = findConfusionPair(type);
      const difference = Math.abs(rgbToOklch(pair.figure).l - rgbToOklch(pair.ground).l);
      expect(difference).toBeLessThanOrEqual(0.05);
    });
  }
});

describe("plate layout", () => {
  it("produces non-overlapping dots inside the circle", () => {
    const dots = layoutPlate(320, (x) => x > 0.4 && x < 0.6, 42, { attempts: 2000 });
    expect(dots.length).toBeGreaterThan(200);
    for (const dot of dots) {
      expect(Math.hypot(dot.x - 160, dot.y - 160)).toBeLessThanOrEqual(160 - dot.r);
    }
    for (let i = 0; i < dots.length; i++) {
      for (let j = i + 1; j < dots.length; j++) {
        expect(Math.hypot(dots[i].x - dots[j].x, dots[i].y - dots[j].y)).toBeGreaterThanOrEqual(
          dots[i].r + dots[j].r
        );
      }
    }
  });
  it("is deterministic, so everyone takes the same test", () => {
    const a = layoutPlate(320, () => true, 7, { attempts: 500 });
    const b = layoutPlate(320, () => true, 7, { attempts: 500 });
    expect(b).toEqual(a);
  });
  it("marks roughly the right share as figure", () => {
    const dots = layoutPlate(320, (x) => x < 0.5, 9, { attempts: 3000 });
    const share = dots.filter((d) => d.inFigure).length / dots.length;
    expect(share).toBeGreaterThan(0.4);
    expect(share).toBeLessThan(0.6);
  });
  it("opens and closes with a control plate", () => {
    expect(PLATES[0].type).toBeNull();
    expect(PLATES[PLATES.length - 1].type).toBeNull();
  });
});
