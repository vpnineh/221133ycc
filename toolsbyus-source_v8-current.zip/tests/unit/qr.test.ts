import { describe, it, expect } from "vitest";
import {
  generateQr,
  qrToSvg,
  wifiString,
  vCardString,
  QR_DEFAULTS,
  type QrMatrix,
} from "../../src/lib/qr";
import {
  analyseRisk,
  explainPattern,
  compile,
  flagsToString,
  applyReplacement,
  FLAG_DEFAULTS,
} from "../../src/lib/regex";

const build = (text: string, overrides = {}): QrMatrix => {
  const result = generateQr(text, { ...QR_DEFAULTS, ...overrides });
  if ("error" in result) throw new Error(result.error);
  return result;
};

describe("QR encoding", () => {
  it("picks the narrowest mode the data allows", () => {
    // Numeric packs three digits into ten bits; alphanumeric two chars into
    // eleven. Picking the wrong one is what makes a URL need a bigger symbol.
    expect(build("12345").mode).toBe("numeric");
    expect(build("HELLO WORLD").mode).toBe("alphanumeric");
    expect(build("hello world").mode).toBe("byte");
    expect(build("café").mode).toBe("byte");
  });

  it("picks the smallest version that holds the data", () => {
    expect(build("1").version).toBe(1);
    expect(build("x".repeat(200)).version).toBeGreaterThan(6);
    expect(build("x".repeat(200)).version).toBeLessThan(20);
  });

  it("needs a bigger symbol at a higher error-correction level", () => {
    const low = build("x".repeat(100), { errorCorrection: "L" }).version;
    const high = build("x".repeat(100), { errorCorrection: "H" }).version;
    expect(high).toBeGreaterThan(low);
  });

  it("has the right module count for its version", () => {
    // size = version * 4 + 17, which is the whole of the version-to-size rule.
    for (const text of ["1", "x".repeat(50), "x".repeat(200)]) {
      const matrix = build(text);
      expect(matrix.size).toBe(matrix.version * 4 + 17);
      expect(matrix.modules).toHaveLength(matrix.size);
      expect(matrix.modules[0]).toHaveLength(matrix.size);
    }
  });

  it("places all three finder patterns", () => {
    const { modules, size } = build("HELLO");
    const finderAt = (row: number, col: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const onBorder = r === 0 || r === 6 || c === 0 || c === 6;
          const inCentre = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          if (modules[row + r][col + c] !== (onBorder || inCentre)) return false;
        }
      }
      return true;
    };
    expect(finderAt(0, 0)).toBe(true);
    expect(finderAt(0, size - 7)).toBe(true);
    expect(finderAt(size - 7, 0)).toBe(true);
  });

  it("leaves a light separator around each finder", () => {
    const { modules, size } = build("HELLO");
    for (let i = 0; i < 8; i++) {
      expect(modules[7][i]).toBe(false);
      expect(modules[i][7]).toBe(false);
      expect(modules[7][size - 1 - i]).toBe(false);
    }
  });

  it("places the timing patterns", () => {
    const { modules, size } = build("HELLO");
    for (let i = 8; i < size - 8; i++) {
      expect(modules[6][i]).toBe(i % 2 === 0);
      expect(modules[i][6]).toBe(i % 2 === 0);
    }
  });

  it("sets the dark module, which is always set", () => {
    const { modules, size } = build("HELLO");
    expect(modules[size - 8][8]).toBe(true);
  });

  it("encodes the format information so it decodes back to the right level", () => {
    for (const level of ["L", "M", "Q", "H"] as const) {
      const { modules } = build("HELLO", { errorCorrection: level });
      // Read the 15 format bits back out of the copy beside the top-left finder.
      let bits = 0;
      for (let i = 0; i < 15; i++) {
        let bit: boolean;
        if (i < 6) bit = modules[i][8];
        else if (i < 8) bit = modules[i + 1][8];
        else if (i === 8) bit = modules[8][7];
        else bit = modules[8][14 - i];
        if (bit) bits |= 1 << i;
      }
      const unmasked = bits ^ 0x5412;
      const levelBits = (unmasked >>> 13) & 3;
      expect(levelBits).toBe({ M: 0, L: 1, H: 2, Q: 3 }[level]);
    }
  });

  it("writes the same format information in both copies", () => {
    // A damaged corner must not lose the format bits, so they are written twice.
    const { modules, size } = build("HELLO");
    for (let i = 0; i < 8; i++) {
      const first = i < 6 ? modules[i][8] : i < 8 ? modules[i + 1][8] : modules[8][7];
      expect(modules[8][size - 1 - i]).toBe(first);
    }
  });

  it("chooses a mask that keeps the light-dark balance near even", () => {
    const { modules, size } = build("https://toolsbyus.com/qr-code-generator");
    let dark = 0;
    for (const row of modules) for (const cell of row) if (cell) dark++;
    const percent = (dark * 100) / (size * size);
    expect(Math.abs(percent - 50)).toBeLessThan(15);
  });

  it("produces a different symbol for different data", () => {
    const a = build("HELLO").modules.flat().join("");
    const b = build("WORLD").modules.flat().join("");
    expect(a).not.toBe(b);
  });

  it("is deterministic", () => {
    expect(build("HELLO").modules).toEqual(build("HELLO").modules);
  });

  it("declines data that will not fit rather than truncating it", () => {
    const result = generateQr("x".repeat(5000), QR_DEFAULTS);
    expect("error" in result).toBe(true);
    if ("error" in result) expect(result.error).toMatch(/Too much data/);
  });

  it("declines an empty payload", () => {
    expect("error" in generateQr("", QR_DEFAULTS)).toBe(true);
  });

  it("places alignment patterns from version 2", () => {
    const matrix = build("x".repeat(40));
    expect(matrix.version).toBeGreaterThanOrEqual(2);
    // The centre of the bottom-right alignment pattern is dark, and the ring
    // around it is light.
    const centre = matrix.size - 7;
    expect(matrix.modules[centre][centre]).toBe(true);
    expect(matrix.modules[centre - 1][centre]).toBe(false);
  });
});

/**
 * A minimal decoder, written here rather than imported.
 *
 * Every test above checks that the symbol *looks* right — finders in place,
 * timing alternating, format bits decoding. None of them proves a scanner could
 * read it, and a QR generator that produces structurally plausible but
 * unreadable codes is worse than none. So this reads the symbol back the way a
 * scanner does: decode the format information, undo the mask, walk the zigzag,
 * de-interleave the blocks and parse the payload.
 *
 * It ignores error correction entirely — it only needs the data codewords —
 * which is what keeps it short enough to be obviously correct.
 */
function decodeQr(matrix: QrMatrix): string {
  const { modules, size, version } = matrix;

  // 1. Format information, from the copy beside the top-left finder.
  let formatBits = 0;
  for (let i = 0; i < 15; i++) {
    let bit: boolean;
    if (i < 6) bit = modules[i][8];
    else if (i < 8) bit = modules[i + 1][8];
    else if (i === 8) bit = modules[8][7];
    else bit = modules[8][14 - i];
    if (bit) formatBits |= 1 << i;
  }
  const unmasked = formatBits ^ 0x5412;
  const maskId = (unmasked >>> 10) & 7;
  const levelBits = (unmasked >>> 13) & 3;
  const level = (["M", "L", "H", "Q"] as const)[levelBits];

  const masks = [
    (r: number, c: number) => (r + c) % 2 === 0,
    (r: number) => r % 2 === 0,
    (_r: number, c: number) => c % 3 === 0,
    (r: number, c: number) => (r + c) % 3 === 0,
    (r: number, c: number) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0,
    (r: number, c: number) => ((r * c) % 2) + ((r * c) % 3) === 0,
    (r: number, c: number) => (((r * c) % 2) + ((r * c) % 3)) % 2 === 0,
    (r: number, c: number) => (((r + c) % 2) + ((r * c) % 3)) % 2 === 0,
  ];

  // 2. Rebuild the function-module map, so the walk skips exactly what the
  //    encoder skipped.
  const isFunction: boolean[][] = Array.from({ length: size }, () =>
    Array.from({ length: size }, () => false)
  );
  const mark = (r: number, c: number) => {
    if (r >= 0 && r < size && c >= 0 && c < size) isFunction[r][c] = true;
  };
  for (const [row, col] of [
    [0, 0],
    [0, size - 7],
    [size - 7, 0],
  ]) {
    for (let r = -1; r <= 7; r++) for (let c = -1; c <= 7; c++) mark(row + r, col + c);
  }
  for (let i = 0; i < size; i++) {
    mark(6, i);
    mark(i, 6);
  }
  for (let i = 0; i < 9; i++) {
    mark(8, i);
    mark(i, 8);
  }
  for (let i = 0; i < 8; i++) {
    mark(8, size - 1 - i);
    mark(size - 1 - i, 8);
  }
  // From version 7 the symbol carries an 18-bit version block twice, in two
  // 6x3 areas. A decoder that does not skip them reads 36 function modules as
  // data and produces plausible-looking garbage from the fifteenth character on.
  if (version >= 7) {
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < 3; j++) {
        mark(i, size - 11 + j);
        mark(size - 11 + j, i);
      }
    }
  }
  const alignment: number[][] = [
    [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46],
    [6, 28, 50],
  ];
  for (const row of alignment[version - 1] ?? []) {
    for (const col of alignment[version - 1] ?? []) {
      const nearFinder =
        (row <= 8 && col <= 8) || (row <= 8 && col >= size - 9) || (row >= size - 9 && col <= 8);
      if (nearFinder) continue;
      for (let r = -2; r <= 2; r++) for (let c = -2; c <= 2; c++) mark(row + r, col + c);
    }
  }

  // 3. Walk the zigzag, unmasking as it goes.
  const bits: number[] = [];
  let upward = true;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vertical = 0; vertical < size; vertical++) {
      const row = upward ? size - 1 - vertical : vertical;
      for (let c = 0; c < 2; c++) {
        const col = right - c;
        if (isFunction[row][col]) continue;
        const value = modules[row][col] !== masks[maskId](row, col);
        bits.push(value ? 1 : 0);
      }
    }
    upward = !upward;
  }

  const codewords: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    let byte = 0;
    for (let b = 0; b < 8; b++) byte = (byte << 1) | bits[i + b];
    codewords.push(byte);
  }

  // 4. De-interleave. The encoder writes one codeword from each block in turn,
  //    so a burst of damage spreads across blocks rather than destroying one.
  const ecTable: Record<string, Array<[number, number, number]>> = {
    L: [[7, 1, 0], [10, 1, 0], [15, 1, 0], [20, 1, 0], [26, 1, 0], [18, 2, 0], [20, 2, 0], [24, 2, 0], [30, 2, 0], [18, 2, 2]],
    M: [[10, 1, 0], [16, 1, 0], [26, 1, 0], [18, 2, 0], [24, 2, 0], [16, 4, 0], [18, 4, 0], [22, 2, 2], [22, 3, 2], [26, 4, 1]],
    Q: [[13, 1, 0], [22, 1, 0], [18, 2, 0], [26, 2, 0], [18, 2, 2], [24, 4, 0], [18, 2, 4], [22, 4, 2], [20, 4, 4], [24, 6, 2]],
    H: [[17, 1, 0], [28, 1, 0], [22, 2, 0], [16, 4, 0], [22, 2, 2], [28, 4, 0], [26, 4, 1], [26, 4, 2], [24, 4, 4], [28, 6, 2]],
  };
  const totals = [26, 44, 70, 100, 134, 172, 196, 242, 292, 346];
  const [ecPerBlock, group1, group2] = ecTable[level][version - 1];
  const blockCount = group1 + group2;
  const dataTotal = totals[version - 1] - ecPerBlock * blockCount;
  const group1Size = Math.floor(dataTotal / blockCount);

  const blocks: number[][] = Array.from({ length: blockCount }, () => []);
  let read = 0;
  const maxLength = group2 > 0 ? group1Size + 1 : group1Size;
  for (let i = 0; i < maxLength; i++) {
    for (let b = 0; b < blockCount; b++) {
      const blockSize = b < group1 ? group1Size : group1Size + 1;
      if (i < blockSize) blocks[b].push(codewords[read++]);
    }
  }
  const data = blocks.flat();

  // 5. Parse the payload out of the reassembled data codewords.
  const dataBits: number[] = [];
  for (const byte of data) for (let b = 7; b >= 0; b--) dataBits.push((byte >>> b) & 1);

  let cursor = 0;
  const take = (count: number) => {
    let value = 0;
    for (let i = 0; i < count; i++) value = (value << 1) | dataBits[cursor++];
    return value;
  };

  const mode = take(4);
  const alphanumeric = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";

  if (mode === 1) {
    const count = take(version <= 9 ? 10 : 12);
    let out = "";
    let remaining = count;
    while (remaining >= 3) {
      out += String(take(10)).padStart(3, "0");
      remaining -= 3;
    }
    if (remaining === 2) out += String(take(7)).padStart(2, "0");
    else if (remaining === 1) out += String(take(4));
    return out;
  }

  if (mode === 2) {
    const count = take(version <= 9 ? 9 : 11);
    let out = "";
    let remaining = count;
    while (remaining >= 2) {
      const pair = take(11);
      out += alphanumeric[Math.floor(pair / 45)] + alphanumeric[pair % 45];
      remaining -= 2;
    }
    if (remaining === 1) out += alphanumeric[take(6)];
    return out;
  }

  if (mode === 4) {
    const count = take(version <= 9 ? 8 : 16);
    const bytes = new Uint8Array(count);
    for (let i = 0; i < count; i++) bytes[i] = take(8);
    return new TextDecoder().decode(bytes);
  }

  throw new Error(`Unsupported mode ${mode}`);
}

describe("QR round trip", () => {
  const payloads = [
    "01234567",
    "HELLO WORLD",
    "https://toolsbyus.com",
    "hello world",
    "café ☕",
    "12345678901234567890",
    "WIFI:T:WPA;S:MyNet;P:hunter2;;",
    "x".repeat(60),
    "A",
    "1",
  ];

  for (const payload of payloads) {
    it(`decodes back to ${JSON.stringify(payload.slice(0, 24))}`, () => {
      expect(decodeQr(build(payload))).toBe(payload);
    });
  }

  it("round-trips at every error-correction level", () => {
    for (const level of ["L", "M", "Q", "H"] as const) {
      expect(decodeQr(build("https://toolsbyus.com/qr", { errorCorrection: level }))).toBe(
        "https://toolsbyus.com/qr"
      );
    }
  });

  it("round-trips across several versions", () => {
    for (const length of [5, 20, 60, 120, 200]) {
      const payload = "A".repeat(length);
      expect(decodeQr(build(payload))).toBe(payload);
    }
  });
});

describe("QR rendering", () => {
  it("renders one path rather than thousands of rects", () => {
    // A version 10 symbol has 3,600 modules; one element each is a slow, huge
    // file.
    const svg = qrToSvg(build("HELLO"), QR_DEFAULTS);
    expect(svg.match(/<path/g)).toHaveLength(1);
    expect(svg).not.toContain("<rect x");
  });

  it("includes the quiet zone in the viewBox", () => {
    const matrix = build("HELLO");
    const svg = qrToSvg(matrix, QR_DEFAULTS);
    const total = matrix.size + QR_DEFAULTS.margin * 2;
    expect(svg).toContain(`viewBox="0 0 ${total} ${total}"`);
  });

  it("renders crisp edges rather than antialiasing the modules", () => {
    expect(qrToSvg(build("HELLO"), QR_DEFAULTS)).toContain('shape-rendering="crispEdges"');
  });
});

describe("QR payload builders", () => {
  it("builds a Wi-Fi payload", () => {
    expect(
      wifiString({ ssid: "MyNet", password: "hunter2", security: "WPA", hidden: false })
    ).toBe("WIFI:T:WPA;S:MyNet;P:hunter2;;");
  });

  it("escapes the characters that are structural in a Wi-Fi payload", () => {
    // An SSID containing a semicolon would otherwise end the field.
    expect(wifiString({ ssid: "a;b", password: 'c"d', security: "WPA", hidden: false })).toBe(
      'WIFI:T:WPA;S:a\\;b;P:c\\"d;;'
    );
  });

  it("omits the password for an open network", () => {
    const payload = wifiString({ ssid: "Open", password: "x", security: "nopass", hidden: false });
    expect(payload).not.toContain("P:");
  });

  it("builds a vCard that contact apps import", () => {
    const card = vCardString({
      name: "Ada Lovelace",
      organisation: "Analytical Engines",
      title: "Programmer",
      phone: "+441234567890",
      email: "ada@example.com",
      url: "https://example.com",
    });
    expect(card.startsWith("BEGIN:VCARD\nVERSION:3.0")).toBe(true);
    expect(card).toContain("FN:Ada Lovelace");
    expect(card.endsWith("END:VCARD")).toBe(true);
  });

  it("omits empty vCard fields rather than emitting blank ones", () => {
    const card = vCardString({ name: "A", organisation: "", title: "", phone: "", email: "", url: "" });
    expect(card).not.toContain("ORG:");
    expect(card.split("\n")).toHaveLength(5);
  });
});

describe("regex analysis", () => {
  it("flags a nested quantifier, the classic ReDoS shape", () => {
    const findings = analyseRisk("(a+)+$");
    expect(findings.some((f) => f.severity === "high")).toBe(true);
    expect(findings[0].title).toBe("Nested quantifier");
  });

  it("flags a quantified alternation", () => {
    expect(analyseRisk("(a|ab)+").some((f) => f.title === "Quantified alternation")).toBe(true);
  });

  it("flags two wildcards in a row", () => {
    expect(analyseRisk(".*.*x").some((f) => f.title === "Repeated .*")).toBe(true);
  });

  it("does not flag an ordinary pattern as dangerous", () => {
    const findings = analyseRisk("^\\d{4}-\\d{2}-\\d{2}$");
    expect(findings.filter((f) => f.severity !== "info")).toHaveLength(0);
  });

  it("notes an unanchored long pattern", () => {
    expect(
      analyseRisk("somethinglongandunanchored[a-z]+").some((f) => f.title === "Not anchored")
    ).toBe(true);
  });

  it("compiles a valid pattern and reports an invalid one", () => {
    expect("regex" in compile("\\d+", FLAG_DEFAULTS)).toBe(true);
    const bad = compile("(unclosed", FLAG_DEFAULTS);
    expect("error" in bad).toBe(true);
  });

  it("assembles the flag string in the canonical order", () => {
    expect(
      flagsToString({ ...FLAG_DEFAULTS, ignoreCase: true, multiline: true, unicode: true })
    ).toBe("gimu");
  });
});

describe("regex explanation", () => {
  it("names each token", () => {
    const parts = explainPattern("^\\d{3}-\\w+$");
    expect(parts.map((p) => p.token)).toEqual(["^", "\\d", "{3}", "-", "\\w", "+", "$"]);
    expect(parts[1].meaning).toMatch(/digit/);
  });

  it("groups a run of literal characters into one entry", () => {
    const parts = explainPattern("hello\\d");
    expect(parts[0].token).toBe("hello");
  });

  it("distinguishes lazy from greedy quantifiers", () => {
    expect(explainPattern("a+?").find((p) => p.token === "+?")?.meaning).toMatch(/as few/);
    expect(explainPattern("a+").find((p) => p.token === "+")?.meaning).toMatch(/as many/);
  });

  it("names the four lookaround forms", () => {
    for (const [token, word] of [
      ["(?=", "lookahead"],
      ["(?!", "negative lookahead"],
      ["(?<=", "lookbehind"],
      ["(?<!", "negative lookbehind"],
    ] as const) {
      expect(explainPattern(`${token}x)`)[0].meaning).toContain(word);
    }
  });

  it("terminates on every pattern it is given", () => {
    for (const pattern of ["", "a", "[[[", "\\", "(((", "***", "\\u{1F600}"]) {
      expect(() => explainPattern(pattern)).not.toThrow();
    }
  });
});

describe("regex replacement", () => {
  it("applies a replacement with group references", () => {
    const result = applyReplacement("(\\w+) (\\w+)", FLAG_DEFAULTS, "hello world", "$2 $1");
    expect("output" in result && result.output).toBe("world hello");
  });

  it("applies a named group reference", () => {
    const result = applyReplacement(
      "(?<year>\\d{4})-(?<month>\\d{2})",
      FLAG_DEFAULTS,
      "2026-09",
      "$<month>/$<year>"
    );
    expect("output" in result && result.output).toBe("09/2026");
  });

  it("reports an invalid pattern rather than throwing", () => {
    expect("error" in applyReplacement("(", FLAG_DEFAULTS, "x", "y")).toBe(true);
  });
});
