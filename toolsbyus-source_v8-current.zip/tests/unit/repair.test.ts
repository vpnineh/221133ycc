import { describe, it, expect } from "vitest";
import { repairJson } from "../../src/lib/json/repair";
import { parseJson } from "../../src/lib/json/parser";

/** Repairs must always produce something the real parser accepts. */
function expectRepairsTo(input: string, expected: unknown) {
  const result = repairJson(input);
  expect(result.success, `repair failed: ${result.remainingError}`).toBe(true);
  expect(JSON.parse(result.repaired)).toEqual(expected);
}

describe("repairJson — the classified error types", () => {
  it("removes a trailing comma in an object and an array", () => {
    expectRepairsTo('{"a": 1, "b": 2,}', { a: 1, b: 2 });
    expectRepairsTo("[1, 2, 3, ]", [1, 2, 3]);
    expectRepairsTo('{"a": [1, 2,], }', { a: [1, 2] });
  });

  it("converts single-quoted strings and keys", () => {
    expectRepairsTo("{'name': 'Alice'}", { name: "Alice" });
    expectRepairsTo("['a', 'b']", ["a", "b"]);
  });

  it("quotes bare object keys", () => {
    expectRepairsTo('{name: "Alice", age: 30}', { name: "Alice", age: 30 });
    expectRepairsTo("{outer: {inner: 1}}", { outer: { inner: 1 } });
  });

  it("replaces typographic quotes", () => {
    expectRepairsTo('{“name”: “Alice”}', { name: "Alice" });
  });

  it("removes a byte order mark", () => {
    expectRepairsTo('﻿{"a": 1}', { a: 1 });
  });

  it("strips JSONC comments", () => {
    expectRepairsTo('{\n  // the name\n  "a": 1\n}', { a: 1 });
    expectRepairsTo('{/* block */ "a": 1}', { a: 1 });
  });

  it("converts Python and JavaScript literals", () => {
    expectRepairsTo('{"a": True, "b": False, "c": None}', { a: true, b: false, c: null });
    expectRepairsTo('{"a": undefined, "b": NaN}', { a: null, b: null });
  });

  it("inserts missing commas between members", () => {
    expectRepairsTo('{"a": "x" "b": "y"}', { a: "x", b: "y" });
  });

  it("repairs several faults at once", () => {
    const broken = `{
      // config
      name: 'payment-gateway',
      active: True,
      retries: 3,
      tags: ['a', 'b',],
    }`;
    expectRepairsTo(broken, {
      name: "payment-gateway",
      active: true,
      retries: 3,
      tags: ["a", "b"],
    });
  });
});

describe("repairJson — must never corrupt string contents", () => {
  it("leaves a comma inside a string alone", () => {
    // The dangerous case: a regex-based fixer cannot tell this comma from a
    // trailing one.
    expectRepairsTo(`{'text': 'a, b, c',}`, { text: "a, b, c" });
  });

  it("leaves comment-like text inside a string alone", () => {
    expectRepairsTo(`{'url': 'https://x.dev//path', 'note': '/* not a comment */',}`, {
      url: "https://x.dev//path",
      note: "/* not a comment */",
    });
  });

  it("leaves braces and colons inside a string alone", () => {
    expectRepairsTo(`{'tpl': '{key: value}',}`, { tpl: "{key: value}" });
  });

  it("preserves typographic quotes used as content inside a valid string", () => {
    const valid = '{"quote": "she said “hello”"}';
    const result = repairJson(valid);
    expect(result.success).toBe(true);
    // Already valid: returned untouched, curly quotes intact.
    expect(result.repaired).toBe(valid);
    expect(result.changes).toEqual([]);
  });

  it("preserves an apostrophe inside a double-quoted string", () => {
    const valid = `{"text": "it's fine"}`;
    expect(repairJson(valid).repaired).toBe(valid);
  });

  it("escapes a double quote when converting a single-quoted string", () => {
    expectRepairsTo(`{'say': 'he said "hi"'}`, { say: 'he said "hi"' });
  });

  it("does not rewrite a key that merely starts with a literal name", () => {
    expectRepairsTo("{Nonexistent: 1, Trueish: 2}", { Nonexistent: 1, Trueish: 2 });
  });

  it("leaves an already-valid document byte-identical", () => {
    const valid = '{\n  "a": [1, 2, {"b": null}],\n  "c": "x"\n}';
    const result = repairJson(valid);
    expect(result.repaired).toBe(valid);
    expect(result.changes).toEqual([]);
  });
});

describe("repairJson — honesty about failure", () => {
  it("reports failure rather than returning plausible-looking output", () => {
    const result = repairJson('{"a": [1, 2');
    expect(result.success).toBe(false);
    expect(result.remainingError).toBeTruthy();
  });

  it("never claims success unless the parser agrees", () => {
    const inputs = [
      '{"a": 1,}',
      "{a: 1}",
      "{'a': 1}",
      "not json at all",
      "{{{{",
      "",
      "[1, 2",
    ];
    for (const input of inputs) {
      const result = repairJson(input);
      const reparsed = parseJson(result.repaired);
      // success must exactly track what the parser thinks of the output.
      expect(result.success, `mismatch for ${JSON.stringify(input)}`).toBe(reparsed.success);
    }
  });

  it("describes every change it made", () => {
    const result = repairJson("{name: 'x', ok: True,}");
    expect(result.success).toBe(true);
    expect(result.changes.length).toBeGreaterThanOrEqual(3);
    for (const change of result.changes) {
      expect(change.count).toBeGreaterThan(0);
      expect(change.description.length).toBeGreaterThan(10);
    }
  });
});

describe("repairJson — property: repair must preserve meaning", () => {
  /** Deterministic pseudo-random generator, so a failure is reproducible. */
  function makeRng(seed: number) {
    let state = seed;
    return () => {
      state = (state * 1103515245 + 12345) & 0x7fffffff;
      return state / 0x7fffffff;
    };
  }

  function randomJson(rnd: () => number, depth = 0): unknown {
    const roll = rnd();
    if (depth > 3 || roll < 0.35) {
      const leaf = rnd();
      if (leaf < 0.2) return null;
      if (leaf < 0.4) return rnd() < 0.5;
      if (leaf < 0.7) return Math.floor(rnd() * 2000) - 1000;
      // Strings deliberately contain the characters that break naive fixers.
      const nasty = [
        "a, b, c",
        "https://x.dev//path",
        "/* not a comment */",
        "{key: value}",
        "it's fine",
        'he said "hi"',
        "trailing,",
        "True",
        "line\nbreak",
        "",
      ];
      return nasty[Math.floor(rnd() * nasty.length)];
    }
    if (roll < 0.7) {
      return Array.from({ length: Math.floor(rnd() * 4) }, () => randomJson(rnd, depth + 1));
    }
    const obj: Record<string, unknown> = {};
    for (let i = 0; i < Math.floor(rnd() * 4); i++) {
      obj[`k${i}`] = randomJson(rnd, depth + 1);
    }
    return obj;
  }

  it("leaves 300 valid documents completely untouched", () => {
    const rnd = makeRng(20260909);
    for (let i = 0; i < 300; i++) {
      const value = randomJson(rnd);
      const text = JSON.stringify(value, null, rnd() < 0.5 ? 2 : 0);
      const result = repairJson(text);
      expect(result.success, `failed on: ${text}`).toBe(true);
      expect(result.repaired, `mutated: ${text}`).toBe(text);
      expect(result.changes).toEqual([]);
    }
  });

  it("recovers the original value from documents broken in known ways", () => {
    const rnd = makeRng(717);
    let checked = 0;

    for (let i = 0; i < 300; i++) {
      const value = randomJson(rnd);
      const text = JSON.stringify(value, null, 2);

      // Introduce a trailing comma before the document's final bracket. That
      // position is unambiguously outside any string, which a regex over the
      // whole document is not — an earlier version of this test corrupted
      // `"{key: value}"` and blamed the engine for faithfully preserving it.
      if (!/^[[{]/.test(text)) continue;
      const broken = text.slice(0, -1) + "," + text.slice(-1);

      const result = repairJson(broken);
      if (!result.success) {
        throw new Error(`repair failed for ${broken}\n${result.remainingError}`);
      }
      // The whole point: the value must survive the round trip unchanged.
      expect(JSON.parse(result.repaired), `value changed for ${broken}`).toEqual(value);
      checked++;
    }

    expect(checked).toBeGreaterThan(50);
  });
});
