import { describe, it, expect } from "vitest";
import { parseJson } from "../../src/lib/json/parser";
import { decodeBase64, encodeBase64, inspectJwt } from "../../src/lib/base64/index";
import { computeSemanticDiff } from "../../src/lib/diff/semantic-diff";

describe("JSON parser strictness", () => {
  it("rejects a second top-level value instead of discarding it", () => {
    const result = parseJson('{"a":1} {"b":2}');
    expect(result.success).toBe(false);
    if (result.success) return;
    expect(result.error.message).toMatch(/exactly one top-level value/i);
  });

  it("rejects trailing content after a primitive root", () => {
    expect(parseJson("1 2").success).toBe(false);
    expect(parseJson('"a" "b"').success).toBe(false);
  });

  it("still accepts a single root surrounded by whitespace", () => {
    const result = parseJson('\n  {"a": 1}  \n');
    expect(result.success).toBe(true);
  });
});

describe("Base64 robustness", () => {
  it("decodes line-wrapped MIME Base64", () => {
    const result = decodeBase64("aGVsbG8g\nd29ybGQ=");
    expect(result.error).toBeUndefined();
    expect(result.text).toBe("hello world");
  });

  it("reports a clear error for characters outside the alphabet", () => {
    const result = decodeBase64("not valid base64!!!");
    expect(result.error).toMatch(/alphabet|multiple of 4/i);
  });

  it("round-trips a large UTF-16LE payload without overflowing the stack", () => {
    const original = "A".repeat(200_000);
    const encoded = encodeBase64(original, "standard", "utf-16le");
    const decoded = decodeBase64(encoded, "utf-16le");
    expect(decoded.error).toBeUndefined();
    expect(decoded.text).toBe(original);
  });

  it("round-trips multi-byte UTF-8 text", () => {
    const original = "سلام — JSON ✅ 你好";
    const decoded = decodeBase64(encodeBase64(original));
    expect(decoded.text).toBe(original);
  });

  it("round-trips URL-safe output", () => {
    const original = "??>>??>>subjects+objects";
    const encoded = encodeBase64(original, "url-safe");
    expect(encoded).not.toMatch(/[+/=]/);
    expect(decodeBase64(encoded).text).toBe(original);
  });

  it("flags an unsigned JWT", () => {
    const header = encodeBase64(JSON.stringify({ alg: "none", typ: "JWT" }), "url-safe");
    const payload = encodeBase64(JSON.stringify({ sub: "1" }), "url-safe");
    const result = inspectJwt(`${header}.${payload}.`);
    expect(result.isJwt).toBe(true);
    expect(result.warnings?.join(" ")).toMatch(/unsigned/i);
  });

  it("flags an expired JWT", () => {
    const header = encodeBase64(JSON.stringify({ alg: "HS256", typ: "JWT" }), "url-safe");
    const payload = encodeBase64(JSON.stringify({ exp: 1 }), "url-safe");
    const result = inspectJwt(`${header}.${payload}.sig`);
    expect(result.isExpired).toBe(true);
  });
});

describe("Diff engine performance guards", () => {
  it("pairs many moved subtrees without a quadratic blow-up", () => {
    // 1,500 identical subtrees relocated from one parent to another. The old
    // pairwise scan deep-compared every removed/added combination.
    const items = Array.from({ length: 1500 }, (_, i) => ({ id: i, payload: { v: i } }));
    const left = { from: items, to: [] as unknown[] };
    const right = { from: [] as unknown[], to: items };

    const started = Date.now();
    const result = computeSemanticDiff(left as never, right as never);
    const elapsed = Date.now() - started;

    expect(result.summary.moved).toBeGreaterThan(0);
    expect(elapsed).toBeLessThan(5000);
  });

  it("scales linearly, not quadratically, with nesting depth", () => {
    // Building each node's path as an array copy and re-serializing the JSON
    // Pointer at every level made this O(depth^2): 8,000 levels took ~4s.
    // Pointers are now appended incrementally, so doubling the depth should
    // roughly double the work, not quadruple it.
    const timeAtDepth = (depth: number) => {
      let left: unknown = { leaf: 1 };
      let right: unknown = { leaf: 2 };
      for (let i = 0; i < depth; i++) {
        left = { child: left };
        right = { child: right };
      }
      const started = performance.now();
      computeSemanticDiff(left as never, right as never);
      return performance.now() - started;
    };

    // Take the fastest of several runs at each depth rather than one sample.
    // Contention only ever *adds* time, so the minimum is the least
    // contaminated measurement — and this suite runs 19 workers in parallel,
    // which made a single shallow sample land near the clock's noise floor and
    // fail the ratio on a machine where nothing was actually slow.
    const bestAtDepth = (depth: number) => {
      let best = Infinity;
      for (let run = 0; run < 7; run++) best = Math.min(best, timeAtDepth(depth));
      return best;
    };

    timeAtDepth(2000); // warm up, so JIT compilation is not charged to the first sample
    const shallow = bestAtDepth(2000);
    const deep = bestAtDepth(8000);

    /*
     * 4x the depth. Linear is ~4x the time; a quadratic implementation costs
     * ~16x, and the threshold sits between them with room for a loaded machine.
     *
     * The ratio is only meaningful while the shallow sample is large enough to
     * measure. This suite runs 27 workers in parallel, and on a contended box
     * `performance.now()` can put a sub-millisecond measurement anywhere —
     * which once failed this test while the implementation was fine. Below a
     * millisecond the ratio is noise, so the assertion falls back to an
     * absolute ceiling that still catches the thing it exists to catch: the
     * quadratic version took several hundred milliseconds at this depth.
     */
    if (shallow >= 1) {
      expect(deep / shallow).toBeLessThan(10);
    } else {
      expect(deep).toBeLessThan(200);
    }
  });

  it("falls back to index matching for arrays too large to score pairwise", () => {
    const big = Array.from({ length: 900 }, (_, i) => ({ id: i }));
    const result = computeSemanticDiff(
      { rows: big } as never,
      { rows: big.map((r) => ({ ...r })) } as never,
      { arrayMatchMode: "similarity" }
    );
    expect(result.summary.total).toBe(0);
  });
});
