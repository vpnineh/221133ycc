import { describe, it, expect } from "vitest";
import { inferSchemaFromSamples } from "../../src/lib/schema/infer";
import { validateAgainstSchema } from "../../src/lib/schema/validate";

describe("JSON Schema Generator & Validator", () => {
  it("infers Draft 2020-12 schema and infers required fields", () => {
    const sample = {
      id: "usr_101",
      email: "user@example.com",
      created: "2026-09-09T00:00:00Z",
      active: true,
      age: 28,
    };

    const schema = inferSchemaFromSamples([sample], {
      inferRequired: true,
      detectFormats: true,
    });

    expect(schema.$schema).toBe("https://json-schema.org/draft/2020-12/schema");
    expect(schema.type).toBe("object");
    expect(schema.required).toContain("id");
    expect(schema.required).toContain("email");
    expect(schema.properties?.email.format).toBe("email");
    expect(schema.properties?.created.format).toBe("date-time");

    // Validates source sample
    const validation = validateAgainstSchema(sample, schema);
    expect(validation.valid).toBe(true);
    expect(validation.errors.length).toBe(0);
  });

  it("performs type widening across diverse samples", () => {
    const sample1 = { score: 100 };
    const sample2 = { score: "pending" };

    const schema = inferSchemaFromSamples([sample1, sample2], {
      typeWidening: true,
    });

    expect(schema.properties?.score.type).toEqual(["integer", "string"]);

    // Both samples validate
    expect(validateAgainstSchema(sample1, schema).valid).toBe(true);
    expect(validateAgainstSchema(sample2, schema).valid).toBe(true);
  });

  it("detects enums at configurable threshold", () => {
    const samples = [
      { status: "active" },
      { status: "active" },
      { status: "pending" },
      { status: "suspended" },
    ];

    const schema = inferSchemaFromSamples(samples, {
      enumThreshold: 3,
    });

    expect(schema.properties?.status.enum).toBeDefined();
    expect(schema.properties?.status.enum).toContain("active");
    expect(schema.properties?.status.enum).toContain("pending");
    expect(schema.properties?.status.enum).toContain("suspended");
  });

  it("detects validation failures when constraints are breached", () => {
    const schema = {
      type: "object",
      required: ["name", "email"],
      properties: {
        name: { type: "string" },
        email: { type: "string", format: "email" },
      },
    };

    const invalidSample = { name: "Bob", email: "not-an-email" };
    const res = validateAgainstSchema(invalidSample, schema);
    expect(res.valid).toBe(false);
    expect(res.errors.some((e) => e.keyword === "format")).toBe(true);

    const missingSample = { name: "Alice" };
    const resMissing = validateAgainstSchema(missingSample, schema);
    expect(resMissing.valid).toBe(false);
    expect(resMissing.errors.some((e) => e.keyword === "required")).toBe(true);
  });
});
