import { describe, it, expect, afterEach } from "vitest";
import { applyJsonPatch, createJsonPatch, parseJsonPointer } from "../../src/lib/diff/patch-rfc6902";
import { inferSchemaFromSamples } from "../../src/lib/schema/infer";
import { validateAgainstSchema } from "../../src/lib/schema/validate";
import { parseJson } from "../../src/lib/json/parser";

/**
 * Regression tests for defects found in the pre-hardening audit. Each case
 * previously either polluted a global prototype, crashed, or accepted input it
 * should have rejected.
 */

const PROBE_KEYS = ["pwned", "pwned2", "polluted"];

afterEach(() => {
  for (const key of PROBE_KEYS) {
    delete (Object.prototype as Record<string, unknown>)[key];
  }
});

describe("Prototype pollution hardening", () => {
  it("rejects a patch that writes through __proto__", () => {
    expect(() =>
      applyJsonPatch({}, [{ op: "add", path: "/__proto__/pwned", value: "yes" } as never])
    ).toThrow(/prototype pollution/i);
    expect(({} as Record<string, unknown>).pwned).toBeUndefined();
  });

  it("rejects a patch that writes through constructor.prototype", () => {
    expect(() =>
      applyJsonPatch({}, [
        { op: "add", path: "/constructor/prototype/pwned2", value: "yes" } as never,
      ])
    ).toThrow(/prototype pollution/i);
    expect(({} as Record<string, unknown>).pwned2).toBeUndefined();
  });

  it("rejects unsafe pointer segments at parse time", () => {
    expect(() => parseJsonPointer("/a/__proto__/b")).toThrow(/prototype pollution/i);
    expect(() => parseJsonPointer("/a/b")).not.toThrow();
  });

  it("treats a literal __proto__ key as an own property, like JSON.parse", () => {
    const source = '{"__proto__": {"x": 1}, "a": 2}';
    const result = parseJson(source);
    expect(result.success).toBe(true);
    if (!result.success) return;

    expect(Object.keys(result.data as object).sort()).toEqual(["__proto__", "a"]);
    // The prototype must be untouched.
    expect(Object.getPrototypeOf(result.data)).toBe(Object.prototype);
  });

  it("infers a schema from a payload containing __proto__ without crashing", () => {
    const sample = JSON.parse('{"__proto__": 1, "constructor": 2, "a": 3}');
    const schema = inferSchemaFromSamples([sample]);
    expect(schema.type).toBe("object");
    expect(Object.keys(schema.properties ?? {}).sort()).toEqual([
      "__proto__",
      "a",
      "constructor",
    ]);
  });

  it("round-trips a patch through a document containing a __proto__ key", () => {
    const before = JSON.parse('{"__proto__": 1, "a": 1}');
    const after = JSON.parse('{"__proto__": 1, "a": 2}');
    const patch = createJsonPatch(before, after);
    expect(applyJsonPatch(before, patch)).toEqual(after);
  });
});

describe("RFC 6902 conformance", () => {
  it("refuses to copy from a path that does not exist", () => {
    expect(() =>
      applyJsonPatch({ a: 1 }, [{ op: "copy", from: "/nope", path: "/b" } as never])
    ).toThrow(/non-existent/i);
  });

  it("refuses to move from a path that does not exist", () => {
    expect(() =>
      applyJsonPatch({ a: 1 }, [{ op: "move", from: "/nope", path: "/b" } as never])
    ).toThrow(/non-existent/i);
  });

  it("refuses to move a container into its own subtree", () => {
    expect(() =>
      applyJsonPatch({ a: { b: {} } }, [{ op: "move", from: "/a", path: "/a/b/c" } as never])
    ).toThrow(/parent of destination/i);
  });

  it("refuses to replace a member that does not exist", () => {
    expect(() =>
      applyJsonPatch({ a: 1 }, [{ op: "replace", path: "/missing", value: 2 } as never])
    ).toThrow(/non-existent/i);
  });

  it("rejects array indices with leading zeros", () => {
    expect(() =>
      applyJsonPatch({ a: [1, 2, 3] }, [{ op: "remove", path: "/a/01" } as never])
    ).toThrow(/Invalid array index/i);
  });

  it("leaves the source document untouched when an operation fails", () => {
    const doc = { a: 1 };
    expect(() =>
      applyJsonPatch(doc, [
        { op: "add", path: "/b", value: 2 } as never,
        { op: "remove", path: "/nope" } as never,
      ])
    ).toThrow();
    expect(doc).toEqual({ a: 1 });
  });
});

describe("Schema validation correctness", () => {
  it("does not satisfy 'required' from the prototype chain", () => {
    const result = validateAgainstSchema({ a: 1 } as never, {
      type: "object",
      required: ["toString"],
    });
    expect(result.valid).toBe(false);
    expect(result.errors[0].keyword).toBe("required");
  });

  it("validates the named format rather than a guessed one", () => {
    expect(
      validateAgainstSchema("2024-01-15" as never, { type: "string", format: "date" }).valid
    ).toBe(true);
    expect(
      validateAgainstSchema("user@example.com" as never, { type: "string", format: "email" }).valid
    ).toBe(true);
    expect(
      validateAgainstSchema("not-a-date" as never, { type: "string", format: "date" }).valid
    ).toBe(false);
  });

  it("compares enum members by value, not identity", () => {
    const schema = { enum: [{ a: 1 }, { b: 2 }] } as never;
    expect(validateAgainstSchema({ a: 1 } as never, schema).valid).toBe(true);
    expect(validateAgainstSchema({ c: 3 } as never, schema).valid).toBe(false);
  });

  it("enforces the numeric and string keywords", () => {
    expect(
      validateAgainstSchema(5 as never, { type: "number", minimum: 10 } as never).valid
    ).toBe(false);
    expect(
      validateAgainstSchema("ab" as never, { type: "string", minLength: 3 } as never).valid
    ).toBe(false);
    expect(
      validateAgainstSchema("abc" as never, { type: "string", pattern: "^a" } as never).valid
    ).toBe(true);
    expect(
      validateAgainstSchema([1, 1] as never, { type: "array", uniqueItems: true } as never).valid
    ).toBe(false);
    expect(
      validateAgainstSchema({ a: 1, b: 2 } as never, {
        type: "object",
        properties: { a: { type: "integer" } },
        additionalProperties: false,
      } as never).valid
    ).toBe(false);
  });

  it("validates a document nested far deeper than the call stack allows", () => {
    let doc: unknown = 1;
    let schema: Record<string, unknown> = { type: "integer" };
    for (let i = 0; i < 20000; i++) {
      doc = { child: doc };
      schema = { type: "object", properties: { child: schema } };
    }
    expect(validateAgainstSchema(doc as never, schema as never).valid).toBe(true);
  });
});

describe("Schema inference quality", () => {
  it("keeps object structure when widening a nullable union", () => {
    const schema = inferSchemaFromSamples([{ a: 1 }, null] as never);
    expect(schema.type).toEqual(["null", "object"]);
    // The structural half of the union must survive the widening.
    expect(schema.properties?.a).toBeDefined();
  });

  it("terminates on a mixed object/array union", () => {
    const schema = inferSchemaFromSamples([{ a: 1 }, [1, 2]] as never);
    expect(schema.type).toEqual(["array", "object"]);
  });

  it("labels a date-only string as 'date', not 'date-time'", () => {
    const schema = inferSchemaFromSamples(["2024-01-15", "2024-02-20"] as never);
    expect(schema.format).toBe("date");
  });
});
