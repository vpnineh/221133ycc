import { describe, it, expect, beforeAll } from "vitest";
import { execFileSync } from "node:child_process";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import {
  CATEGORIES,
  TOOL_GROUPS,
  TOOLS,
  INFO_PAGES,
  activeCategories,
  publishedTools,
  toolsInCategory,
} from "../../src/lib/tools.data.mjs";
import { PAGE_SEO } from "../../src/lib/tools.seo.mjs";

const root = resolve(__dirname, "../..");

/**
 * The catalogue is the single source of truth for the nav, the hubs, the
 * palette, llms.txt and the sitemap. Before it was extracted, the build script
 * kept its own copy of the page list — a duplication that stays correct only by
 * vigilance, and whose failure mode is a sitemap advertising URLs that 404.
 *
 * These tests make the duplication impossible to reintroduce quietly: the
 * generated sitemap is regenerated and counted against the catalogue, and every
 * published entry is checked to have a route on disk.
 */
describe("tool catalogue", () => {
  it("has no duplicate routes", () => {
    const hrefs = TOOLS.map((t) => t.href);
    expect(new Set(hrefs).size, `duplicate href in catalogue: ${hrefs.join(", ")}`).toBe(
      hrefs.length
    );
  });

  it("uses flat slugs", () => {
    // Flat rather than /dev/json-viewer: shorter, what competitors rank with,
    // and no migration if a tool is later recategorised.
    for (const tool of TOOLS) {
      expect(tool.href, `${tool.href} is not a flat slug`).toMatch(/^\/[a-z0-9]+(?:-[a-z0-9]+)*$/);
    }
  });

  it("gives every tool a known category and group", () => {
    const categoryIds = new Set(CATEGORIES.map((c) => c.id));
    for (const tool of TOOLS) {
      expect(categoryIds, `${tool.href} has unknown category ${tool.category}`).toContain(
        tool.category
      );
      expect(TOOL_GROUPS, `${tool.href} has unknown group ${tool.group}`).toContain(tool.group);
    }
  });

  it("gives every tool the fields the crawler files need", () => {
    for (const tool of TOOLS) {
      expect(tool.lastReviewed, `${tool.href} lastReviewed`).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      expect(tool.keywords.length, `${tool.href} has no palette keywords`).toBeGreaterThan(0);
    }
  });

  /*
   * The SEO copy lives in a second file so its prose stays out of the chunk
   * every page loads. A second file can drift from the first, and the failure
   * mode is a sitemap listing a URL that 404s — so the two are held together
   * here, in both directions, rather than by anyone remembering.
   */
  describe("tools.seo.mjs", () => {
    const catalogued = [...TOOLS.map((t) => t.href), ...INFO_PAGES.map((p) => p.href)];

    it("has an entry for every catalogued page", () => {
      for (const href of catalogued) {
        expect(PAGE_SEO[href], `${href} has no entry in tools.seo.mjs`).toBeDefined();
      }
    });

    it("has no entry for a page that no longer exists", () => {
      const known = new Set(catalogued);
      for (const href of Object.keys(PAGE_SEO)) {
        expect(known.has(href), `tools.seo.mjs still lists ${href}, which is not in the catalogue`).toBe(
          true
        );
      }
    });

    it("gives every page a review date the sitemap can use", () => {
      // `<lastmod>` is built from these. A missing one silently falls back to
      // the newest date on the site, which would be a claim the page cannot
      // support — the exact failure the uniform build-day stamp used to be.
      for (const entry of [...TOOLS, ...INFO_PAGES]) {
        expect(
          (entry as { lastReviewed?: string }).lastReviewed,
          `${entry.href} has no lastReviewed`
        ).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      }
    });

    it("gives every entry a usable summary, priority and changefreq", () => {
      for (const [href, entry] of Object.entries(PAGE_SEO)) {
        expect(entry.summary.length, `${href} has no summary for llms.txt`).toBeGreaterThan(30);
        expect(entry.priority, `${href} priority`).toMatch(/^(0\.\d|1\.0)$/);
        expect(entry.changefreq, `${href} changefreq`).toMatch(
          /^(always|hourly|daily|weekly|monthly|yearly|never)$/
        );
      }
    });
  });

  it("writes distinct descriptions, so cards and search results do not repeat", () => {
    const descriptions = TOOLS.map((t) => t.description);
    expect(new Set(descriptions).size).toBe(descriptions.length);
    const summaries = TOOLS.map((t) => PAGE_SEO[t.href].summary);
    expect(new Set(summaries).size).toBe(summaries.length);
  });

  it("has a page on disk for every published tool", () => {
    for (const tool of publishedTools()) {
      const dir = resolve(root, "src/app", tool.href.replace(/^\//, ""));
      expect(existsSync(resolve(dir, "page.tsx")), `${tool.href} has no page.tsx`).toBe(true);
    }
  });

  it("has a hub page on disk for every active category", () => {
    for (const category of activeCategories()) {
      const dir = resolve(root, "src/app", category.hub.replace(/^\//, ""));
      expect(existsSync(resolve(dir, "page.tsx")), `${category.hub} has no page.tsx`).toBe(true);
    }
  });

  it("never leaves a category hub empty", () => {
    for (const category of activeCategories()) {
      expect(toolsInCategory(category.id).length, `${category.hub} is empty`).toBeGreaterThan(0);
    }
  });
});

describe("generated crawler files", () => {
  beforeAll(() => {
    // Regenerate rather than trusting whatever is on disk: the assertion is
    // about what this catalogue produces, not about a stale artefact.
    execFileSync("node", ["scripts/generate-llms-txt.mjs"], { cwd: root, stdio: "pipe" });
  });

  const expectedUrlCount = () =>
    1 /* homepage */ + activeCategories().length + publishedTools().length + INFO_PAGES.length;

  it("lists exactly the catalogue's URLs in sitemap.xml", () => {
    const xml = readFileSync(resolve(root, "public/sitemap.xml"), "utf8");
    const locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1]);

    expect(locs.length, "sitemap URL count does not match the catalogue").toBe(expectedUrlCount());

    const paths = locs.map((url) => new URL(url).pathname.replace(/\/$/, "") || "/");
    for (const tool of publishedTools()) {
      expect(paths, `${tool.href} missing from sitemap`).toContain(tool.href);
    }
    for (const category of activeCategories()) {
      expect(paths, `${category.hub} missing from sitemap`).toContain(category.hub);
    }
    expect(new Set(paths).size, "sitemap contains a duplicate URL").toBe(paths.length);
  });

  it("never lists an unpublished tool", () => {
    const xml = readFileSync(resolve(root, "public/sitemap.xml"), "utf8");
    for (const tool of TOOLS.filter((t) => !t.published)) {
      expect(xml, `unpublished ${tool.href} leaked into the sitemap`).not.toContain(
        `${tool.href}<`
      );
    }
  });

  it("lists the same pages in llms.txt as in the sitemap", () => {
    const llms = readFileSync(resolve(root, "public/llms.txt"), "utf8");
    const listed = [...llms.matchAll(/^- \[[^\]]+\]\(([^)]+)\)/gm)].map((m) => m[1]);
    expect(listed.length).toBe(expectedUrlCount());
  });

  it("keeps the short name a substring of the full title", () => {
    // `name` is the nav label and `title` is the page's H1 and <title>. The
    // e2e suite asserts both against the rendered page, so a catalogue entry
    // whose name does not appear in its own title fails there with a confusing
    // message about a page title. Catching it here names the actual problem.
    for (const tool of TOOLS) {
      expect(
        tool.title.toLowerCase(),
        `${tool.href}: name "${tool.name}" does not appear in title "${tool.title}", so the page <title> will not match the nav label`
      ).toContain(tool.name.toLowerCase());
    }
  });

  it("gives every tool a distinct href, name and title", () => {
    for (const key of ["href", "name", "title"] as const) {
      const values = TOOLS.map((tool) => tool[key]);
      const duplicates = values.filter((value, index) => values.indexOf(value) !== index);
      expect(duplicates, `duplicate ${key} in the catalogue`).toEqual([]);
    }
  });
});
