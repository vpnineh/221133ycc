import { describe, it, expect } from "vitest";
import {
  encodeUrl,
  decodeUrl,
  toBase64Url,
  fromBase64Url,
  inspectUrl,
  decodeQueryString,
  detectEncodingDepth,
  URL_DEFAULTS,
} from "../../src/lib/url";
import { convertCase, splitWords, CASE_DEFAULTS } from "../../src/lib/text/case";
import {
  parseInBase,
  formatInBase,
  describeInteger,
  FORMAT_DEFAULTS,
} from "../../src/lib/numbers/base";
import { md5, crc32, toHex, hashText, hmac, algorithmInfo } from "../../src/lib/hash";
import {
  detectUnit,
  parseInstant,
  isoWeek,
  dayOfYear,
  isoInZone,
  relativeTo,
} from "../../src/lib/time";
import { generateLorem, countStats, mulberry32, LOREM_DEFAULTS } from "../../src/lib/text/lorem";

describe("URL encoding", () => {
  it("percent-encodes a component", () => {
    expect(encodeUrl("a b&c=d", URL_DEFAULTS)).toBe("a%20b%26c%3Dd");
  });

  it("keeps the structural characters in URI mode", () => {
    expect(encodeUrl("https://x.dev/a b?q=1", { ...URL_DEFAULTS, mode: "uri" })).toBe(
      "https://x.dev/a%20b?q=1"
    );
  });

  it("encodes a space as + in form mode, and a literal + as %2B", () => {
    // Get this wrong and "a + b" round-trips to "a   b", which only ever shows
    // up in search queries.
    expect(encodeUrl("a + b", { ...URL_DEFAULTS, mode: "form" })).toBe("a+%2B+b");
    expect(decodeUrl("a+%2B+b", "form").value).toBe("a + b");
  });

  it("does not treat + as a space outside form mode, but says so", () => {
    const result = decodeUrl("a+b", "component");
    expect(result.value).toBe("a+b");
    expect(result.notes.join(" ")).toMatch(/form-encoded/);
  });

  it("encodes the five characters encodeURIComponent leaves alone, on request", () => {
    expect(encodeUrl("!'()*", URL_DEFAULTS)).toBe("!'()*");
    expect(encodeUrl("!'()*", { ...URL_DEFAULTS, strictRfc3986: true })).toBe(
      "%21%27%28%29%2A"
    );
  });

  it("encodes every byte when asked", () => {
    expect(encodeUrl("Az", { ...URL_DEFAULTS, encodeEverything: true })).toBe("%41%7A");
  });

  it("reports a malformed escape with its position instead of throwing", () => {
    const result = decodeUrl("a%zzb", "component");
    expect(result.error).toMatch(/position 1/);
  });

  it("round-trips non-ASCII through UTF-8", () => {
    const text = "café 😀 مرحبا";
    expect(decodeUrl(encodeUrl(text, URL_DEFAULTS), "component").value).toBe(text);
  });

  it("round-trips base64url without padding", () => {
    expect(toBase64Url("ab?")).toBe("YWI_");
    expect(fromBase64Url(toBase64Url("café 😀"))).toBe("café 😀");
  });

  it("splits a URL into parts and keeps duplicate query keys", () => {
    const result = inspectUrl("https://u:p@example.com:8443/a/b?x=1&x=2&y=z#frag");
    expect("url" in result).toBe(true);
    if ("url" in result) {
      expect(result.url).toMatchObject({
        protocol: "https:",
        username: "u",
        hostname: "example.com",
        port: "8443",
        pathname: "/a/b",
        hash: "#frag",
      });
      // A plain object would collapse x=1 and x=2, and duplicate keys are
      // meaningful in plenty of APIs.
      expect(result.url.params).toEqual([
        { key: "x", value: "1" },
        { key: "x", value: "2" },
        { key: "y", value: "z" },
      ]);
    }
  });

  it("rejects a URL without a scheme", () => {
    expect("error" in inspectUrl("example.com/path")).toBe(true);
  });

  it("decodes a query string as form-encoded", () => {
    expect(decodeQueryString("?q=a+b&r=%C3%A9")).toEqual([
      { key: "q", value: "a b" },
      { key: "r", value: "é" },
    ]);
  });

  it("counts how many times the input was encoded", () => {
    // %2520 is a space encoded twice and reads as %20 to a person.
    expect(detectEncodingDepth("a%20b")).toBe(1);
    expect(detectEncodingDepth("a%2520b")).toBe(2);
    expect(detectEncodingDepth("plain")).toBe(0);
  });
});

describe("case conversion", () => {
  it("splits at a lower-to-upper boundary", () => {
    expect(splitWords("userName")).toEqual(["user", "Name"]);
  });

  it("splits an acronym followed by a word", () => {
    // XMLHttpRequest is three words, not one and not eight.
    expect(splitWords("XMLHttpRequest")).toEqual(["XML", "Http", "Request"]);
  });

  it("splits at a letter-to-digit boundary", () => {
    expect(splitWords("user2fa")).toEqual(["user", "2", "fa"]);
  });

  it("treats every separator alike, so any input convention is accepted", () => {
    for (const input of ["user_first_name", "user-first-name", "user.first.name", "user first name"]) {
      expect(splitWords(input)).toEqual(["user", "first", "name"]);
    }
  });

  const styles: Array<[string, string]> = [
    ["camel", "userFirstName"],
    ["pascal", "UserFirstName"],
    ["snake", "user_first_name"],
    ["constant", "USER_FIRST_NAME"],
    ["kebab", "user-first-name"],
    ["train", "User-First-Name"],
    ["dot", "user.first.name"],
    ["path", "user/first/name"],
  ];

  for (const [style, expected] of styles) {
    it(`converts to ${style}`, () => {
      expect(
        convertCase("user_first_name", { ...CASE_DEFAULTS, style: style as never })
      ).toBe(expected);
    });
  }

  it("converts between any two identifier conventions", () => {
    expect(convertCase("XMLHttpRequest", { ...CASE_DEFAULTS, style: "snake" })).toBe(
      "xml_http_request"
    );
    expect(convertCase("API_BASE_URL", { ...CASE_DEFAULTS, style: "camel" })).toBe("apiBaseUrl");
  });

  it("preserves acronyms on request", () => {
    expect(
      convertCase("user_id", { ...CASE_DEFAULTS, style: "pascal", preserveAcronyms: true })
    ).toBe("UserId");
    expect(
      convertCase("user_ID", { ...CASE_DEFAULTS, style: "pascal", preserveAcronyms: true })
    ).toBe("UserID");
  });

  it("keeps punctuation in the prose styles", () => {
    expect(convertCase("hello world. goodbye!", { ...CASE_DEFAULTS, style: "sentence" })).toBe(
      "Hello world. Goodbye!"
    );
  });

  it("leaves minor words lowercase in title case, except at the edges", () => {
    expect(convertCase("the lord of the rings", { ...CASE_DEFAULTS, style: "title" })).toBe(
      "The Lord of the Rings"
    );
  });

  it("does not apply Turkish casing by default", () => {
    // Locale-aware lowercasing turns I into ı, which breaks every ASCII
    // identifier comparison. It has to be opt-in.
    expect(convertCase("ID", { ...CASE_DEFAULTS, style: "lower" })).toBe("id");
  });

  it("handles the whole-string styles", () => {
    expect(convertCase("Hi There", { ...CASE_DEFAULTS, style: "upper" })).toBe("HI THERE");
    expect(convertCase("abcd", { ...CASE_DEFAULTS, style: "alternating" })).toBe("aBcD");
    expect(convertCase("Hello", { ...CASE_DEFAULTS, style: "inverse" })).toBe("hELLO");
  });

  it("returns empty for input with no words", () => {
    expect(convertCase("!!!", { ...CASE_DEFAULTS, style: "camel" })).toBe("");
  });
});

describe("base conversion", () => {
  const convert = (input: string, from: number, to: number, options = FORMAT_DEFAULTS) => {
    const parsed = parseInBase(input, from);
    if (!parsed.ok) throw new Error(parsed.error);
    return formatInBase(parsed.value, from, to, options);
  };

  it("converts between the common bases", () => {
    expect(convert("255", 10, 16)).toBe("ff");
    expect(convert("ff", 16, 2)).toBe("11111111");
    expect(convert("11111111", 2, 8)).toBe("377");
    expect(convert("zz", 36, 10)).toBe("1295");
  });

  it("does not lose digits past 2^53, which parseInt does", () => {
    // parseInt("9007199254740993", 10) is 9007199254740992: silently wrong.
    expect(convert("9007199254740993", 10, 10)).toBe("9007199254740993");
    expect(convert("ffffffffffffffffff", 16, 10)).toBe("4722366482869645213695");
  });

  it("keeps a negative sign", () => {
    expect(convert("-255", 10, 16)).toBe("-ff");
  });

  it("accepts digit separators", () => {
    expect(convert("1010_1010", 2, 16)).toBe("aa");
    expect(convert("1 000", 10, 10)).toBe("1000");
  });

  it("rejects a digit that does not exist in the base", () => {
    const result = parseInBase("129", 8);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/"9" is not a digit in base 8/);
  });

  it("rejects a prefix that contradicts the selected base", () => {
    const result = parseInBase("0x1f", 10);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/means base 16/);
  });

  it("accepts a prefix that agrees with the base", () => {
    expect(convert("0x1f", 16, 10)).toBe("31");
  });

  it("converts a terminating fraction exactly", () => {
    expect(convert("0.5", 10, 2)).toBe("0.1");
    expect(convert("0.1", 2, 10)).toBe("0.5");
    expect(convert("0.25", 10, 16)).toBe("0.4");
  });

  it("converts a fraction that terminates in one base and not the other", () => {
    // 0.1 decimal is 0.0001100110011… in binary. Nothing can fix that; the
    // useful behaviour is a bounded expansion rather than a hang.
    const result = convert("0.1", 10, 2);
    expect(result.startsWith("0.000110011001100")).toBe(true);
    expect(result.length).toBeLessThan(60);
  });

  it("groups digits on request", () => {
    expect(convert("255", 10, 2, { ...FORMAT_DEFAULTS, grouping: true })).toBe("1111 1111");
    expect(convert("1000000", 10, 10, { ...FORMAT_DEFAULTS, grouping: true })).toBe("1,000,000");
  });

  it("adds a prefix on request", () => {
    expect(convert("255", 10, 16, { ...FORMAT_DEFAULTS, prefix: true })).toBe("0xff");
  });

  it("describes what a value fits in", () => {
    const facts = describeInteger(300n);
    expect(facts.bitLength).toBe(9);
    expect(facts.fits.find((f) => f.type === "int8")?.ok).toBe(false);
    expect(facts.fits.find((f) => f.type === "int16")?.ok).toBe(true);
    // 300 = 256 + 32 + 8 + 4
    expect(facts.setBits).toEqual([2, 3, 5, 8]);
  });

  it("shows two's complement, which is why -1 reads as ffffffff", () => {
    const facts = describeInteger(-1n);
    expect(facts.twosComplement).toMatchObject({ width: 8, hex: "ff" });
    expect(describeInteger(-2147483648n).twosComplement).toMatchObject({
      width: 32,
      hex: "80000000",
    });
  });
});

describe("hashing", () => {
  it("computes the RFC 1321 MD5 test vectors", () => {
    const of = (text: string) => toHex(md5(new TextEncoder().encode(text)));
    expect(of("")).toBe("d41d8cd98f00b204e9800998ecf8427e");
    expect(of("a")).toBe("0cc175b9c0f1b6a831c399e269772661");
    expect(of("abc")).toBe("900150983cd24fb0d6963f7d28e17f72");
    expect(of("message digest")).toBe("f96b697d7cb7938d525a2f31aaf161d0");
    expect(of("abcdefghijklmnopqrstuvwxyz")).toBe("c3fcd3d76192e4007dfb496cca67e13b");
    expect(of("12345678901234567890123456789012345678901234567890123456789012345678901234567890")).toBe(
      "57edf4a22be3c955ac49da2e2107b67a"
    );
  });

  it("computes MD5 across a block boundary", () => {
    // 56 to 64 bytes is where the padding needs a second block; an off-by-one
    // here passes every short test vector and fails on real input.
    const of = (text: string) => toHex(md5(new TextEncoder().encode(text)));
    expect(of("a".repeat(55))).toBe("ef1772b6dff9a122358552954ad0df65");
    expect(of("a".repeat(56))).toBe("3b0c8ac703f828b04c6c197006d17218");
    expect(of("a".repeat(64))).toBe("014842d480b571495a4a0363793f7367");
  });

  it("computes the standard CRC32 check value", () => {
    // The IEEE check value for "123456789" — the one every implementation
    // states, so a mismatch means the polynomial or the reflection is wrong.
    expect(crc32(new TextEncoder().encode("123456789")).toString(16)).toBe("cbf43926");
  });

  it("computes SHA-256 for the canonical empty and abc inputs", async () => {
    expect(toHex(await hashText("", "SHA-256"))).toBe(
      "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    );
    expect(toHex(await hashText("abc", "SHA-256"))).toBe(
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    );
  });

  it("hashes UTF-8 bytes, not UTF-16 units", async () => {
    // A hash of café differs between encodings, and the mismatch is a recurring
    // cause of signatures that verify locally and fail in production. The é here
    // must be the two UTF-8 bytes C3 A9, which is what hashing the Latin-1 byte
    // E9 would not produce.
    const utf8 = new Uint8Array([0x63, 0x61, 0x66, 0xc3, 0xa9]);
    const { hashBytes } = await import("../../src/lib/hash");
    expect(toHex(await hashText("café", "SHA-256"))).toBe(toHex(await hashBytes(utf8, "SHA-256")));
    expect(toHex(await hashText("café", "SHA-256"))).not.toBe(
      toHex(await hashText("cafe", "SHA-256"))
    );
  });

  it("computes an RFC 4231 HMAC-SHA-256 test vector", async () => {
    expect(toHex(await hmac("key", "The quick brown fox jumps over the lazy dog", "SHA-256"))).toBe(
      "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"
    );
  });

  it("labels the broken algorithms as broken", () => {
    expect(algorithmInfo("MD5").status).toBe("broken");
    expect(algorithmInfo("SHA-1").status).toBe("broken");
    expect(algorithmInfo("SHA-256").status).toBe("secure");
    expect(algorithmInfo("CRC32").status).toBe("not-a-hash");
  });
});

describe("timestamps", () => {
  it("detects the unit from magnitude", () => {
    expect(detectUnit(1_757_577_600).unit).toBe("seconds");
    expect(detectUnit(1_757_577_600_000).unit).toBe("milliseconds");
    expect(detectUnit(1_757_577_600_000_000).unit).toBe("microseconds");
    expect(detectUnit(1_757_577_600_000_000_000).unit).toBe("nanoseconds");
  });

  it("resolves a seconds timestamp to the right instant", () => {
    const result = parseInstant("0");
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.value.date.toISOString()).toBe("1970-01-01T00:00:00.000Z");
  });

  it("resolves the 2038 boundary", () => {
    const result = parseInstant("2147483647");
    expect(result.ok && result.value.date.toISOString()).toBe("2038-01-19T03:14:07.000Z");
  });

  it("parses ISO 8601 and RFC 2822", () => {
    expect(parseInstant("2026-09-11T08:00:00Z").ok).toBe(true);
    expect(parseInstant("Thu, 11 Sep 2026 08:00:00 GMT").ok).toBe(true);
  });

  it("parses relative expressions against a fixed now", () => {
    const now = Date.UTC(2026, 8, 11, 12, 0, 0);
    const result = parseInstant("3 days ago", now);
    expect(result.ok && result.value.date.toISOString()).toBe("2026-09-08T12:00:00.000Z");
  });

  it("rejects text it does not recognise, with a hint", () => {
    const result = parseInstant("last tuesday-ish");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toMatch(/ISO 8601/);
  });

  it("computes the ISO week, where 1 January can be week 52 of last year", () => {
    expect(isoWeek(new Date("2021-01-01T00:00:00Z"))).toBe(53);
    expect(isoWeek(new Date("2026-01-01T00:00:00Z"))).toBe(1);
    expect(isoWeek(new Date("2026-09-11T00:00:00Z"))).toBe(37);
  });

  it("computes the day of year, leap years included", () => {
    expect(dayOfYear(new Date("2024-12-31T00:00:00Z"))).toBe(366);
    expect(dayOfYear(new Date("2023-12-31T00:00:00Z"))).toBe(365);
  });

  it("renders ISO in a named zone with that date's offset", () => {
    // The offset is a property of the instant, not of the zone: London is +01:00
    // in summer and +00:00 in winter.
    expect(isoInZone(new Date("2026-07-01T12:00:00Z"), "Europe/London")).toBe(
      "2026-07-01T13:00:00+01:00"
    );
    expect(isoInZone(new Date("2026-01-01T12:00:00Z"), "Europe/London")).toBe(
      "2026-01-01T12:00:00+00:00"
    );
  });

  it("renders a relative description", () => {
    const now = new Date("2026-09-11T12:00:00Z");
    expect(relativeTo(new Date("2026-09-08T12:00:00Z"), now)).toMatch(/3 days ago/);
  });
});

describe("placeholder text", () => {
  it("is deterministic for the same seed", () => {
    expect(generateLorem(LOREM_DEFAULTS, 7)).toBe(generateLorem(LOREM_DEFAULTS, 7));
    expect(generateLorem(LOREM_DEFAULTS, 7)).not.toBe(generateLorem(LOREM_DEFAULTS, 8));
  });

  it("starts with the canonical opening when asked", () => {
    expect(generateLorem(LOREM_DEFAULTS, 1).startsWith("Lorem ipsum dolor sit amet")).toBe(true);
    expect(
      generateLorem({ ...LOREM_DEFAULTS, startWithLorem: false }, 1).startsWith("Lorem ipsum")
    ).toBe(false);
  });

  it("produces the requested number of paragraphs", () => {
    const text = generateLorem({ ...LOREM_DEFAULTS, count: 4 }, 1);
    expect(text.split("\n\n")).toHaveLength(4);
  });

  it("produces the exact requested number of words", () => {
    const text = generateLorem({ ...LOREM_DEFAULTS, unit: "words", count: 25 }, 1);
    expect(text.split(/\s+/)).toHaveLength(25);
  });

  it("wraps in HTML on request", () => {
    const text = generateLorem({ ...LOREM_DEFAULTS, count: 2, html: true }, 1);
    expect(text.split("\n").every((line) => line.startsWith("<p>"))).toBe(true);
  });

  it("emits a list", () => {
    const text = generateLorem({ ...LOREM_DEFAULTS, unit: "list", count: 3 }, 1);
    expect(text.split("\n")).toHaveLength(3);
    expect(text.startsWith("- ")).toBe(true);
  });

  it("produces text that stresses a layout in Unicode mode", () => {
    // The point of this mode: Latin placeholder text is ASCII, so a layout
    // filled with it never meets a combining mark, an emoji or a long word.
    const text = generateLorem({ ...LOREM_DEFAULTS, flavour: "unicode", count: 2 }, 3);
    expect(/[^\u0000-\u007f]/.test(text)).toBe(true);
  });

  it("counts code points rather than UTF-16 units", () => {
    // An emoji is one character to a reader and two to String.length.
    expect(countStats("😀").characters).toBe(1);
    expect(countStats("😀").bytes).toBe(4);
    expect(countStats("hello world").words).toBe(2);
  });

  it("has a generator with a usable distribution", () => {
    const random = mulberry32(42);
    const values = Array.from({ length: 2000 }, random);
    expect(Math.min(...values)).toBeGreaterThanOrEqual(0);
    expect(Math.max(...values)).toBeLessThan(1);
    const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
    expect(Math.abs(mean - 0.5)).toBeLessThan(0.05);
  });
});
