import { describe, it, expect } from "vitest";
import {
  generateUuidV4,
  generateUuidV7,
  generateUuidV1,
  generateBatch,
  inspectUuid,
} from "../../src/lib/uuid";

describe("UUID Generation & Inspection", () => {
  it("generates valid UUID v4 compliant with RFC 4122", () => {
    const u = generateUuidV4();
    expect(u).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
    const insp = inspectUuid(u);
    expect(insp.isValid).toBe(true);
    expect(insp.version).toBe(4);
    expect(insp.variant).toBe("RFC 4122 / RFC 9562");
    expect(insp.randomBits).toBe(122);
  });

  it("generates valid UUID v7 compliant with RFC 9562 with correct timestamp", () => {
    const before = Date.now();
    const u = generateUuidV7();
    const after = Date.now();

    expect(u).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
    const insp = inspectUuid(u);
    expect(insp.isValid).toBe(true);
    expect(insp.version).toBe(7);
    expect(insp.timestamp).toBeDefined();
    const ts = insp.timestamp!.getTime();
    expect(ts).toBeGreaterThanOrEqual(before - 10);
    expect(ts).toBeLessThanOrEqual(after + 10);
  });

  it("generates strictly monotonic v7 UUIDs when called in rapid loop", () => {
    const uuids: string[] = [];
    for (let i = 0; i < 100; i++) {
      uuids.push(generateUuidV7());
    }
    for (let i = 1; i < uuids.length; i++) {
      expect(uuids[i] > uuids[i - 1]).toBe(true);
    }
  });

  it("generates valid UUID v1 with Gregorian timestamp", () => {
    const u = generateUuidV1();
    expect(u).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-1[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i);
    const insp = inspectUuid(u);
    expect(insp.isValid).toBe(true);
    expect(insp.version).toBe(1);
    expect(insp.timestamp).toBeDefined();
  });

  it("formats batches with JSON array, uppercase, and no hyphens", () => {
    const jsonOutput = generateBatch("v4", 5, {
      separator: "json",
      uppercase: true,
      hyphens: false,
    });
    const parsed = JSON.parse(jsonOutput);
    expect(Array.isArray(parsed)).toBe(true);
    expect(parsed.length).toBe(5);
    expect(parsed[0]).toMatch(/^[0-9A-F]{32}$/);
  });

  it("correctly inspects foreign UUID formats with braces or uppercase", () => {
    const insp = inspectUuid("{0188b488-b2cd-7fc2-850d-61fae4e1a742}");
    expect(insp.isValid).toBe(true);
    expect(insp.version).toBe(7);
  });

  it("rejects malformed strings in inspector", () => {
    const insp = inspectUuid("not-a-valid-uuid");
    expect(insp.isValid).toBe(false);
  });
});
