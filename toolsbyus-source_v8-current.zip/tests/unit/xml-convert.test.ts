import { describe, it, expect } from "vitest";
import {
  xmlToJson,
  jsonToXml,
  coerceText,
  decodeEntities,
  toElementName,
  escapeXmlText,
  escapeXmlAttribute,
  XML_TO_JSON_DEFAULTS,
  JSON_TO_XML_DEFAULTS,
  type XmlToJsonOptions,
} from "../../src/lib/xml/convert";
import type { JsonValue } from "../../src/lib/json/types";

const toJson = (xml: string, overrides: Partial<XmlToJsonOptions> = {}): JsonValue => {
  const result = xmlToJson(xml, { ...XML_TO_JSON_DEFAULTS, ...overrides });
  if (!result.ok) throw new Error(result.error.message);
  return result.value;
};

const toXml = (value: unknown, overrides = {}) =>
  jsonToXml(value as JsonValue, { ...JSON_TO_XML_DEFAULTS, ...overrides });

describe("XML to JSON", () => {
  it("maps an element with children to an object", () => {
    expect(toJson("<a><b>1</b><c>2</c></a>")).toEqual({ a: { b: "1", c: "2" } });
  });

  it("keeps text as text by default", () => {
    // XML has no types. Turning "3" into 3 is a choice, not a translation, and
    // it is how a zero-padded part number becomes a different part number.
    expect(toJson("<a><n>3</n></a>")).toEqual({ a: { n: "3" } });
  });

  it("coerces values on request", () => {
    expect(toJson("<a><n>3</n><b>true</b><s>x</s></a>", { parseValues: true })).toEqual({
      a: { n: 3, b: true, s: "x" },
    });
  });

  it("keeps a leading zero as a string even when coercing", () => {
    expect(toJson("<a><code>007</code></a>", { parseValues: true })).toEqual({
      a: { code: "007" },
    });
  });

  it("keeps an integer beyond 2^53 as a string", () => {
    expect(toJson("<a><id>9007199254740993</id></a>", { parseValues: true })).toEqual({
      a: { id: "9007199254740993" },
    });
  });

  it("prefixes attributes so they cannot collide with elements", () => {
    expect(toJson('<a id="1"><id>2</id></a>')).toEqual({ a: { "@id": "1", id: "2" } });
  });

  it("uses the text key when an element has both text and attributes", () => {
    expect(toJson('<a lang="en">hello</a>')).toEqual({ a: { "@lang": "en", "#text": "hello" } });
  });

  it("collapses a text-only element to a bare string", () => {
    expect(toJson("<a>hello</a>")).toEqual({ a: "hello" });
  });

  it("keeps the text key when collapsing is off", () => {
    expect(toJson("<a>hello</a>", { collapseText: false })).toEqual({ a: { "#text": "hello" } });
  });

  it("turns repeated elements into an array", () => {
    expect(toJson("<a><i>1</i><i>2</i></a>")).toEqual({ a: { i: ["1", "2"] } });
  });

  it("does not turn a single element into an array, which is the whole problem", () => {
    // This asymmetry is why code written against a two-result response crashes
    // on a one-result response. It cannot be inferred; it has to be declared.
    expect(toJson("<a><i>1</i></a>")).toEqual({ a: { i: "1" } });
    expect(toJson("<a><i>1</i></a>", { forceArray: ["i"] })).toEqual({ a: { i: ["1"] } });
  });

  it("maps an empty element to null, both spellings alike", () => {
    expect(toJson("<a><b/></a>")).toEqual({ a: { b: null } });
    expect(toJson("<a><b></b></a>")).toEqual({ a: { b: null } });
  });

  it("decodes the five predefined entities", () => {
    expect(toJson("<a>&lt;x&gt; &amp; &quot;y&quot; &apos;z&apos;</a>")).toEqual({
      a: `<x> & "y" 'z'`,
    });
  });

  it("decodes numeric character references", () => {
    expect(decodeEntities("&#65;&#x42;&#128512;")).toBe("AB😀");
  });

  it("leaves an undeclared entity verbatim rather than deleting it", () => {
    expect(decodeEntities("&nbsp;x")).toBe("&nbsp;x");
  });

  it("does not decode entities inside CDATA", () => {
    expect(toJson("<a><![CDATA[&lt;not an entity&gt;]]></a>")).toEqual({
      a: "&lt;not an entity&gt;",
    });
  });

  it("drops comments by default and keeps them on request", () => {
    expect(toJson("<a><!-- note --><b>1</b></a>")).toEqual({ a: { b: "1" } });
    const kept = toJson("<a><!-- note --><b>1</b></a>", { keepComments: true }) as {
      a: { "#comment": string };
    };
    expect(kept.a["#comment"].trim()).toBe("note");
  });

  it("strips namespace prefixes on request", () => {
    expect(toJson('<ns:a xmlns:ns="u"><ns:b>1</ns:b></ns:a>')).toEqual({
      "ns:a": { "@xmlns:ns": "u", "ns:b": "1" },
    });
    expect(toJson('<ns:a xmlns:ns="u"><ns:b>1</ns:b></ns:a>', { stripNamespaces: true })).toEqual({
      a: { b: "1" },
    });
  });

  it("keeps mixed content's text under the text key", () => {
    // The position of the text relative to the children is lost. JSON has no
    // way to express it, which is worth knowing before relying on the output.
    expect(toJson("<p>before<b>bold</b></p>")).toEqual({ p: { b: "bold", "#text": "before" } });
  });

  it("does not pollute the prototype through an element named __proto__", () => {
    const parsed = toJson("<a><__proto__><polluted>1</polluted></__proto__></a>") as Record<
      string,
      Record<string, unknown>
    >;
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
    expect(Object.prototype.hasOwnProperty.call(parsed.a, "__proto__")).toBe(true);
  });

  it("survives a deeply nested document without overflowing", () => {
    const depth = 20_000;
    const xml = `${"<n>".repeat(depth)}leaf${"</n>".repeat(depth)}`;
    const result = xmlToJson(xml, XML_TO_JSON_DEFAULTS);
    expect(result.ok).toBe(true);
  });

  it("rejects mismatched tags rather than producing plausible JSON", () => {
    // The failure that matters: truncated or hand-edited XML converting cleanly
    // into JSON that looks right and is missing data.
    const result = xmlToJson("<a><b></a>", XML_TO_JSON_DEFAULTS);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Mismatched tags/);
  });

  it("rejects an unclosed element and names it", () => {
    const result = xmlToJson("<a><b>1</b>", XML_TO_JSON_DEFAULTS);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Unclosed element: <a>/);
  });

  it("rejects a stray closing tag", () => {
    const result = xmlToJson("<a></a></b>", XML_TO_JSON_DEFAULTS);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/no matching opening tag/);
  });
});

describe("JSON to XML", () => {
  it("wraps the document in a root element", () => {
    expect(toXml({ a: 1 }, { declaration: false })).toBe("<root>\n  <a>1</a>\n</root>\n");
  });

  it("emits the declaration by default", () => {
    expect(toXml({ a: 1 }).startsWith('<?xml version="1.0" encoding="UTF-8"?>')).toBe(true);
  });

  it("repeats the element name for an array member", () => {
    expect(toXml({ i: [1, 2] }, { declaration: false })).toBe(
      "<root>\n  <i>1</i>\n  <i>2</i>\n</root>\n"
    );
  });

  it("wraps an array root rather than emitting two root elements", () => {
    // An XML document has exactly one root. Emitting two is not XML at all.
    expect(toXml([1, 2], { declaration: false })).toBe(
      "<root>\n  <item>1</item>\n  <item>2</item>\n</root>\n"
    );
  });

  it("writes prefixed members as attributes", () => {
    expect(toXml({ "@id": "1", name: "x" }, { declaration: false })).toBe(
      '<root id="1">\n  <name>x</name>\n</root>\n'
    );
  });

  it("writes the text key as element content", () => {
    expect(toXml({ "@lang": "en", "#text": "hi" }, { declaration: false })).toBe(
      '<root lang="en">hi</root>\n'
    );
  });

  it("self-closes an empty value", () => {
    expect(toXml({ a: null }, { declaration: false })).toBe("<root>\n  <a/>\n</root>\n");
    expect(toXml({ a: null }, { declaration: false, selfCloseEmpty: false })).toBe(
      "<root>\n  <a></a>\n</root>\n"
    );
  });

  it("escapes the characters that would break the markup", () => {
    expect(escapeXmlText("<a> & </a>")).toBe("&lt;a&gt; &amp; &lt;/a&gt;");
    expect(escapeXmlAttribute('a"b\nc')).toBe("a&quot;b&#10;c");
  });

  it("repairs a key that is not a valid XML name and records the original", () => {
    // JSON keys can be anything; XML names cannot start with a digit or contain
    // a space. Substituting silently would lose the real key.
    expect(toElementName("2024")).toEqual({ name: "_2024", original: "2024" });
    expect(toElementName("a b")).toEqual({ name: "a_b", original: "a b" });
    expect(toElementName("valid-name")).toEqual({ name: "valid-name" });
    expect(toXml({ "a b": 1 }, { declaration: false })).toContain('<a_b name="a b">1</a_b>');
  });

  it("emits one line when the indent is zero", () => {
    expect(toXml({ a: 1, b: 2 }, { declaration: false, indent: 0 })).toBe(
      "<root><a>1</a><b>2</b></root>\n"
    );
  });

  it("uses the requested root name", () => {
    expect(toXml({ a: 1 }, { declaration: false, rootName: "payload" })).toContain("<payload>");
  });
});

describe("round trip", () => {
  it("returns the same JSON after a trip through XML, with coercion on", () => {
    const value = { order: { id: "1041", lines: { line: ["a", "b"] }, note: "x" } };
    const xml = toXml(value, { rootName: "doc" });
    const back = toJson(xml, { forceArray: ["line"] }) as { doc: unknown };
    expect(back.doc).toEqual(value);
  });

  it("keeps attributes across a round trip", () => {
    const value = { item: { "@id": "7", "#text": "hello" } };
    const back = toJson(toXml(value, { rootName: "doc" })) as { doc: unknown };
    expect(back.doc).toEqual(value);
  });

  it("keeps entity-bearing text exact", () => {
    const value = { text: 'a < b & c > d "e" \'f\'' };
    const back = toJson(toXml(value, { rootName: "doc" })) as { doc: unknown };
    expect(back.doc).toEqual(value);
  });
});

describe("coerceText", () => {
  it("maps the three literals", () => {
    expect(coerceText("true")).toBe(true);
    expect(coerceText("false")).toBe(false);
    expect(coerceText("null")).toBeNull();
  });

  it("maps numbers but not number-like strings", () => {
    expect(coerceText("42")).toBe(42);
    expect(coerceText("-1.5e3")).toBe(-1500);
    expect(coerceText("007")).toBe("007");
    expect(coerceText("1,000")).toBe("1,000");
    expect(coerceText("+1")).toBe("+1");
  });
});
