import { describe, it, expect } from "vitest";
import {
  tokenizeXml,
  formatXml,
  minifyXml,
  parseAttributes,
  DEFAULT_XML_FORMAT,
} from "../../src/lib/xml";

const kinds = (input: string) => {
  const result = tokenizeXml(input);
  if (!result.ok) throw new Error(result.error.message);
  return result.value.filter((t) => !(t.kind === "text" && !t.value!.trim())).map((t) => t.kind);
};

const format = (input: string, over: Partial<typeof DEFAULT_XML_FORMAT> = {}) => {
  const result = formatXml(input, { ...DEFAULT_XML_FORMAT, ...over });
  if (!result.ok) throw new Error(result.error.message);
  return result.value.formatted;
};

describe("tokenizer", () => {
  it("separates the declaration from a processing instruction", () => {
    expect(kinds('<?xml version="1.0"?><?php echo 1; ?><a/>')).toEqual([
      "declaration",
      "processing",
      "selfClosing",
    ]);
  });

  it("reads a DOCTYPE with an internal subset containing >", () => {
    // The subset is bracketed and may contain '>', so taking the first one
    // truncates the declaration and turns the rest into text.
    const input = '<!DOCTYPE note [<!ENTITY x "a > b">]><note/>';
    const result = tokenizeXml(input);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value[0].kind).toBe("doctype");
      expect(result.value[0].raw).toBe('<!DOCTYPE note [<!ENTITY x "a > b">]>');
    }
  });

  it("does not see tags inside a comment", () => {
    expect(kinds("<a><!-- <b/> --></a>")).toEqual(["open", "comment", "close"]);
  });

  it("does not see tags or comments inside CDATA", () => {
    // The circularity the single-pass tokenizer exists to resolve: a scan that
    // strips comments first eats the '<!--' here and corrupts the section.
    expect(kinds("<a><![CDATA[ <b/> <!-- x --> ]]></a>")).toEqual(["open", "cdata", "close"]);
  });

  it("does not end a tag at a > inside an attribute value", () => {
    const result = tokenizeXml('<a title="x > y">t</a>');
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.value[0].raw).toBe('<a title="x > y">');
  });

  it("handles single-quoted attributes containing double quotes", () => {
    const result = tokenizeXml("<a title='say \"hi\"'/>");
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.value[0].kind).toBe("selfClosing");
  });

  it("treats a bare < as text rather than aborting", () => {
    // XML forbids it; hand-written files are full of it. The '<' splits the
    // run into three text tokens, and what matters is that the document
    // survives the trip rather than how many tokens it takes.
    const result = tokenizeXml("<a>1 < 2</a>");
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.map((t) => t.raw).join("")).toBe("<a>1 < 2</a>");
    }
  });

  it("reconstructs any document exactly from its tokens", () => {
    // The tokenizer is lossless by construction: every byte lands in exactly
    // one token's `raw`. That is what lets the formatter be a fold over the
    // stream rather than a series of edits to the text.
    for (const input of [
      '<?xml version="1.0" encoding="UTF-8"?>\n<r a="1"><b/><!-- c --><![CDATA[d]]>e</r>',
      "<!DOCTYPE html><html><body>x</body></html>",
      "<a title='x > y'>t</a>",
      "  leading text <a/> trailing  ",
    ]) {
      const result = tokenizeXml(input);
      expect(result.ok).toBe(true);
      if (result.ok) expect(result.value.map((t) => t.raw).join("")).toBe(input);
    }
  });

  it("reports an unterminated comment with a position", () => {
    const result = tokenizeXml("<a><!-- oops</a>");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Unterminated comment/);
  });

  it("reports an unterminated CDATA section", () => {
    const result = tokenizeXml("<a><![CDATA[ oops</a>");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Unterminated CDATA/);
  });

  it("tracks line numbers across a multi-line document", () => {
    const result = tokenizeXml("<a>\n  <b/>\n</a>");
    expect(result.ok).toBe(true);
    if (result.ok) {
      const close = result.value.find((t) => t.kind === "close")!;
      expect(close.line).toBe(3);
    }
  });
});

describe("attributes", () => {
  it("reads quoted values", () => {
    expect(parseAttributes('<a id="1" class="x y">')).toEqual([
      { name: "id", value: "1", quote: '"' },
      { name: "class", value: "x y", quote: '"' },
    ]);
  });

  it("reads a valueless attribute, which is invalid XML and everywhere in HTML", () => {
    expect(parseAttributes("<input disabled>")).toEqual([
      { name: "disabled", value: "", quote: "" },
    ]);
  });

  it("reads an unquoted value", () => {
    expect(parseAttributes("<a id=1>")).toEqual([{ name: "id", value: "1", quote: "" }]);
  });

  it("does not confuse the element name for an attribute", () => {
    expect(parseAttributes("<div>")).toEqual([]);
  });
});

describe("formatting", () => {
  it("indents nested elements", () => {
    expect(format("<a><b><c/></b></a>")).toBe("<a>\n  <b>\n    <c />\n  </b>\n</a>");
  });

  it("keeps a text-only element on one line", () => {
    // Exploding every leaf across three lines is what makes machine-formatted
    // XML harder to read than the hand-written kind.
    expect(format("<root><name>Ada</name></root>")).toBe("<root>\n  <name>Ada</name>\n</root>");
  });

  it("keeps an empty element on one line", () => {
    expect(format("<root><name></name></root>")).toBe("<root>\n  <name></name>\n</root>");
  });

  it("normalises an already-indented document idempotently", () => {
    const once = format("<a>\n\n   <b>x</b>\n</a>");
    expect(format(once)).toBe(once);
  });

  it("honours tab indentation", () => {
    expect(format("<a><b/></a>", { indent: "tab" })).toBe("<a>\n\t<b />\n</a>");
  });

  it("strips comments on request and keeps them otherwise", () => {
    expect(format("<a><!-- note --><b/></a>", { stripComments: true })).toBe("<a>\n  <b />\n</a>");
    expect(format("<a><!-- note --><b/></a>")).toContain("<!-- note -->");
  });

  it("preserves CDATA verbatim", () => {
    expect(format("<a><![CDATA[  keep   me  ]]></a>")).toContain("<![CDATA[  keep   me  ]]>");
  });

  it("wraps attributes past the threshold", () => {
    const out = format('<a one="1" two="2" three="3"/>', { attributeWrapThreshold: 2 });
    expect(out.split("\n").length).toBe(5);
    expect(out).toContain('  one="1"');
  });

  it("rejects a mismatched closing tag instead of silently reshaping the tree", () => {
    const result = formatXml("<a><b></c></a>", DEFAULT_XML_FORMAT);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Mismatched closing tag <\/c>/);
  });

  it("reports unclosed elements by name", () => {
    const result = formatXml("<a><b></a>", DEFAULT_XML_FORMAT);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Mismatched closing tag/);
  });

  it("reports a document that ends mid-tree", () => {
    const result = formatXml("<a><b>", DEFAULT_XML_FORMAT);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error.message).toMatch(/Unclosed elements: <a>, <b>/);
  });

  it("counts elements and depth", () => {
    const result = formatXml("<a><b><c/></b><d/></a>", DEFAULT_XML_FORMAT);
    expect(result.ok && result.value.elementCount).toBe(4);
    expect(result.ok && result.value.maxDepth).toBe(2);
  });

  it("keeps the declaration at the top", () => {
    expect(format('<?xml version="1.0"?><a/>')).toBe('<?xml version="1.0"?>\n<a />');
  });
});

describe("minifying", () => {
  it("drops whitespace between tags", () => {
    expect(minifyXml("<a>\n  <b/>\n</a>")).toEqual({ ok: true, value: "<a><b/></a>", warnings: [] });
  });

  it("keeps text content", () => {
    const result = minifyXml("<a>\n  <b>hello world</b>\n</a>");
    expect(result.ok && result.value).toBe("<a><b>hello world</b></a>");
  });

  it("keeps CDATA exactly", () => {
    const result = minifyXml("<a>\n<![CDATA[  spaced  ]]>\n</a>");
    expect(result.ok && result.value).toBe("<a><![CDATA[  spaced  ]]></a>");
  });
});

describe("robustness", () => {
  it("handles a deeply nested document without overflowing the stack", () => {
    // Tokenizing and formatting are both iterative, for the same reason the
    // JSON parser is.
    const depth = 5000;
    const input = "<a>".repeat(depth) + "</a>".repeat(depth);
    const result = formatXml(input, DEFAULT_XML_FORMAT);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.value.maxDepth).toBe(depth - 1);
  });

  it("handles an empty document", () => {
    expect(formatXml("", DEFAULT_XML_FORMAT)).toEqual({
      ok: true,
      value: { formatted: "", elementCount: 0, maxDepth: 0 },
      warnings: [],
    });
  });
});
