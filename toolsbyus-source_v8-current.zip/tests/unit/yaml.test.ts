import { describe, it, expect } from "vitest";
import {
  parseYaml,
  stringifyYaml,
  resolvePlainScalar,
  needsQuoting,
  unescapeDoubleQuoted,
  unescapeSingleQuoted,
  YAML_DEFAULTS,
} from "../../src/lib/yaml";
import type { JsonValue } from "../../src/lib/json/types";

const load = (source: string): JsonValue => {
  const result = parseYaml(source);
  if (!result.success) throw new Error(`${result.error.message} (line ${result.error.line})`);
  return result.documents[0];
};

const warningsOf = (source: string): string[] => {
  const result = parseYaml(source);
  return result.success ? result.warnings.map((w) => w.message) : [];
};

describe("scalar resolution, YAML 1.2 core schema", () => {
  it("resolves null in all its spellings, including empty", () => {
    for (const token of ["~", "null", "Null", "NULL", ""]) {
      expect(resolvePlainScalar(token).value).toBeNull();
    }
  });

  it("resolves only true and false as booleans", () => {
    expect(resolvePlainScalar("true").value).toBe(true);
    expect(resolvePlainScalar("TRUE").value).toBe(true);
    expect(resolvePlainScalar("False").value).toBe(false);
  });

  it("does not turn Norway into false", () => {
    // The most famous bug in YAML: 1.1 resolved NO as a boolean, so a list of
    // ISO country codes lost Norway.
    const countries = load("codes:\n  - NO\n  - SE\n  - DK\n") as { codes: string[] };
    expect(countries.codes).toEqual(["NO", "SE", "DK"]);
  });

  it("keeps every YAML 1.1 boolean as a string and says so", () => {
    for (const token of ["y", "Y", "yes", "no", "On", "OFF"]) {
      const resolved = resolvePlainScalar(token);
      expect(resolved.value).toBe(token);
      expect(resolved.kind).toBe("string");
      expect(resolved.ambiguity).toMatch(/1\.1/);
    }
  });

  it("resolves decimal, octal and hexadecimal integers", () => {
    expect(resolvePlainScalar("42").value).toBe(42);
    expect(resolvePlainScalar("-7").value).toBe(-7);
    expect(resolvePlainScalar("0o17").value).toBe(15);
    expect(resolvePlainScalar("0x1f").value).toBe(31);
  });

  it("flags a leading zero rather than silently choosing a base", () => {
    // 1.2 says 12; 1.1 says octal 10; the author meant "012".
    const resolved = resolvePlainScalar("012");
    expect(resolved.value).toBe(12);
    expect(resolved.ambiguity).toMatch(/Leading zero/);
  });

  it("keeps an integer beyond 2^53 as a string rather than losing digits", () => {
    const resolved = resolvePlainScalar("9007199254740993");
    expect(resolved.value).toBe("9007199254740993");
    expect(resolved.kind).toBe("string");
  });

  it("resolves floats including exponents", () => {
    expect(resolvePlainScalar("3.14").value).toBe(3.14);
    expect(resolvePlainScalar("-1.0e3").value).toBe(-1000);
    expect(resolvePlainScalar(".5").value).toBe(0.5);
  });

  it("keeps .inf and .nan as strings, because JSON has neither", () => {
    expect(resolvePlainScalar(".inf").value).toBe(".inf");
    expect(resolvePlainScalar(".nan").kind).toBe("string");
  });

  it("does not read 12:30 as a sexagesimal number", () => {
    const resolved = resolvePlainScalar("12:30");
    expect(resolved.value).toBe("12:30");
    expect(resolved.ambiguity).toMatch(/sexagesimal/);
  });

  it("treats a quoted value as a string, always", () => {
    expect(load("a: 'true'\nb: \"42\"\nc: 'null'\n")).toEqual({ a: "true", b: "42", c: "null" });
  });
});

describe("block mappings and sequences", () => {
  it("parses a nested mapping", () => {
    expect(load("server:\n  host: localhost\n  port: 8080\n")).toEqual({
      server: { host: "localhost", port: 8080 },
    });
  });

  it("parses a sequence of scalars", () => {
    expect(load("items:\n  - a\n  - b\n")).toEqual({ items: ["a", "b"] });
  });

  it("parses a sequence at the same indentation as its key", () => {
    // Both forms are legal and both appear in the wild.
    expect(load("items:\n- a\n- b\n")).toEqual({ items: ["a", "b"] });
  });

  it("parses a sequence of mappings with the dash on the first key's line", () => {
    expect(load("users:\n  - name: Ada\n    admin: true\n  - name: Grace\n")).toEqual({
      users: [
        { name: "Ada", admin: true },
        { name: "Grace" },
      ],
    });
  });

  it("parses a nested sequence written compactly", () => {
    // `- - a` nests without any extra indentation, which is why depth cannot be
    // bounded by line width.
    expect(load("grid:\n  - - 1\n    - 2\n  - - 3\n")).toEqual({ grid: [[1, 2], [3]] });
  });

  it("parses an empty value as null", () => {
    expect(load("a:\nb: 1\n")).toEqual({ a: null, b: 1 });
  });

  it("parses a deeply nested document", () => {
    let source = "";
    for (let i = 0; i < 60; i++) source += `${" ".repeat(i * 2)}k${i}:\n`;
    source += `${" ".repeat(60 * 2)}leaf: 1\n`;
    const parsed = load(source) as Record<string, unknown>;
    let cursor: Record<string, unknown> = parsed;
    for (let i = 0; i < 60; i++) cursor = cursor[`k${i}`] as Record<string, unknown>;
    expect(cursor).toEqual({ leaf: 1 });
  });

  it("refuses a document nested past the ceiling instead of overflowing", () => {
    const bomb = `${"- ".repeat(5000)}x`;
    const result = parseYaml(bomb);
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.message).toMatch(/Nesting deeper/);
  });
});

describe("comments", () => {
  it("strips a trailing comment", () => {
    expect(load("a: 1 # the count\n")).toEqual({ a: 1 });
  });

  it("does not strip a # inside a quoted string", () => {
    expect(load('a: "x # y"\n')).toEqual({ a: "x # y" });
  });

  it("does not strip a URL fragment", () => {
    // `#` only starts a comment after whitespace. Splitting on it
    // unconditionally quietly truncates every URL with a fragment.
    expect(load("url: http://example.com/page#section\n")).toEqual({
      url: "http://example.com/page#section",
    });
  });

  it("ignores a whole-line comment", () => {
    expect(load("# header\na: 1\n# footer\n")).toEqual({ a: 1 });
  });
});

describe("flow collections", () => {
  it("parses a flow sequence", () => {
    expect(load("a: [1, 2, 3]\n")).toEqual({ a: [1, 2, 3] });
  });

  it("parses a flow mapping", () => {
    expect(load("a: {x: 1, y: two}\n")).toEqual({ a: { x: 1, y: "two" } });
  });

  it("parses nested flow collections", () => {
    expect(load("a: [{x: 1}, [2, 3]]\n")).toEqual({ a: [{ x: 1 }, [2, 3]] });
  });

  it("parses a flow collection spanning several lines", () => {
    expect(load("a: [\n  1,\n  2\n]\n")).toEqual({ a: [1, 2] });
  });

  it("keeps a comma inside a quoted flow item", () => {
    expect(load('a: ["x,y", z]\n')).toEqual({ a: ["x,y", "z"] });
  });

  it("reports an unclosed flow collection", () => {
    const result = parseYaml("a: [1, 2\n");
    expect(result.success).toBe(false);
  });
});

describe("block scalars", () => {
  it("keeps line breaks in a literal block", () => {
    expect(load("text: |\n  line one\n  line two\n")).toEqual({ text: "line one\nline two\n" });
  });

  it("strips the trailing newline with |-", () => {
    expect(load("text: |-\n  one\n  two\n")).toEqual({ text: "one\ntwo" });
  });

  it("folds a > block into one line", () => {
    expect(load("text: >-\n  one\n  two\n")).toEqual({ text: "one two" });
  });

  it("keeps a blank line as a break inside a folded block", () => {
    expect(load("text: >-\n  one\n\n  two\n")).toEqual({ text: "one\ntwo" });
  });

  it("treats a # inside a block scalar as content, not a comment", () => {
    // A shell script or a Dockerfile in a block scalar is full of them.
    expect(load("script: |-\n  #!/bin/sh\n  echo hi\n")).toEqual({
      script: "#!/bin/sh\necho hi",
    });
  });

  it("preserves relative indentation inside a block", () => {
    expect(load("text: |-\n  a\n    b\n  c\n")).toEqual({ text: "a\n  b\nc" });
  });

  it("survives a PEM block, the reason block scalars exist", () => {
    const pem = load(
      "key: |-\n  -----BEGIN KEY-----\n  AAAA\n  BBBB\n  -----END KEY-----\n"
    ) as { key: string };
    expect(key(pem).split("\n")).toHaveLength(4);
    expect(key(pem).startsWith("-----BEGIN KEY-----")).toBe(true);
  });
});

const key = (value: { key: string }) => value.key;

describe("anchors and aliases", () => {
  it("expands an alias", () => {
    expect(load("a: &base\n  x: 1\nb: *base\n")).toEqual({ a: { x: 1 }, b: { x: 1 } });
  });

  it("expands rather than shares, so the JSON output is a tree", () => {
    const parsed = load("a: &base\n  x: 1\nb: *base\n") as { a: object; b: object };
    expect(parsed.a).not.toBe(parsed.b);
  });

  it("expands a scalar anchor", () => {
    expect(load("a: &n 5\nb: *n\n")).toEqual({ a: 5, b: 5 });
  });

  it("reports an alias to an undefined anchor", () => {
    const result = parseYaml("a: *missing\n");
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.message).toMatch(/has not been defined/);
  });

  it("refuses a billion-laughs expansion instead of exhausting memory", () => {
    // Each level references the previous one twice, so 30 levels is 2^30 nodes.
    let source = "a0: &a0 [x, x]\n";
    for (let i = 1; i <= 30; i++) source += `a${i}: &a${i} [*a${i - 1}, *a${i - 1}]\n`;
    const started = performance.now();
    const result = parseYaml(source);
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.message).toMatch(/billion laughs/);
    // The point of the budget is that it fails fast rather than hanging.
    expect(performance.now() - started).toBeLessThan(3000);
  });
});

describe("documents and directives", () => {
  it("parses several documents separated by ---", () => {
    const result = parseYaml("a: 1\n---\nb: 2\n");
    expect(result.success).toBe(true);
    if (result.success) expect(result.documents).toEqual([{ a: 1 }, { b: 2 }]);
  });

  it("accepts a leading --- on the first document", () => {
    expect(load("---\na: 1\n")).toEqual({ a: 1 });
  });

  it("accepts the ... end marker", () => {
    expect(load("a: 1\n...\n")).toEqual({ a: 1 });
  });

  it("warns that a %YAML 1.1 directive is not honoured", () => {
    expect(warningsOf("%YAML 1.1\n---\na: no\n").join(" ")).toMatch(/1\.2 core schema/);
  });

  it("returns null for an empty document", () => {
    expect(load("")).toBeNull();
    expect(load("# only a comment\n")).toBeNull();
  });
});

describe("safety", () => {
  it("does not pollute the prototype through a __proto__ key", () => {
    const parsed = load("__proto__:\n  polluted: true\na: 1\n") as Record<string, unknown>;
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
    expect(Object.prototype.hasOwnProperty.call(parsed, "__proto__")).toBe(true);
  });

  it("does not pollute through a flow mapping either", () => {
    load('a: {"__proto__": {"polluted": true}}\n');
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
  });

  it("warns about a duplicate key rather than dropping it silently", () => {
    const warnings = warningsOf("a: 1\na: 2\n");
    expect(warnings.join(" ")).toMatch(/Duplicate key/);
    expect(load("a: 1\na: 2\n")).toEqual({ a: 2 });
  });

  it("rejects merge keys instead of half-supporting them", () => {
    const result = parseYaml("base: &b\n  x: 1\nchild:\n  <<: *b\n");
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.message).toMatch(/Merge keys/);
  });

  it("rejects explicit keys, which have no JSON equivalent", () => {
    const result = parseYaml("? [a, b]\n: value\n");
    expect(result.success).toBe(false);
  });
});

describe("quoted scalars", () => {
  it("unescapes the JSON escapes", () => {
    expect(unescapeDoubleQuoted("a\\nb\\tc")).toBe("a\nb\tc");
  });

  it("unescapes hex, 16-bit and 32-bit escapes", () => {
    expect(unescapeDoubleQuoted("\\x41")).toBe("A");
    expect(unescapeDoubleQuoted("\\u00e9")).toBe("é");
    expect(unescapeDoubleQuoted("\\U0001F600")).toBe("😀");
  });

  it("unescapes the four YAML-only escapes", () => {
    expect(unescapeDoubleQuoted("\\N")).toBe("\u0085");
    expect(unescapeDoubleQuoted("\\_")).toBe("\u00a0");
    expect(unescapeDoubleQuoted("\\L")).toBe("\u2028");
    expect(unescapeDoubleQuoted("\\P")).toBe("\u2029");
  });

  it("handles the single-quoted style's one escape", () => {
    expect(unescapeSingleQuoted("it''s")).toBe("it's");
    expect(load("a: 'it''s'\n")).toEqual({ a: "it's" });
  });

  it("keeps a colon inside a quoted value", () => {
    expect(load('a: "http://x"\n')).toEqual({ a: "http://x" });
  });

  it("reads a quoted key", () => {
    expect(load('"a b": 1\n')).toEqual({ "a b": 1 });
  });
});

describe("emitting", () => {
  const dump = (value: unknown, options = YAML_DEFAULTS) =>
    stringifyYaml(value as JsonValue, options);

  it("writes a mapping", () => {
    expect(dump({ a: 1, b: "x" })).toBe("a: 1\nb: x\n");
  });

  it("writes a nested mapping", () => {
    expect(dump({ a: { b: 1 } })).toBe("a:\n  b: 1\n");
  });

  it("writes a sequence of scalars", () => {
    expect(dump({ a: [1, 2] })).toBe("a:\n- 1\n- 2\n");
  });

  it("indents sequences on request", () => {
    expect(dump({ a: [1] }, { ...YAML_DEFAULTS, indentSequences: true })).toBe("a:\n  - 1\n");
  });

  it("puts the first key of an object on the dash's line", () => {
    expect(dump({ a: [{ x: 1, z: 2 }] })).toBe("a:\n- x: 1\n  z: 2\n");
  });

  it("quotes a key that would resolve to something else, the same as a value", () => {
    // `y: 2` loads as {True: 2} in a YAML 1.1 reader. A key is not exempt.
    expect(dump({ y: 2, no: 3, "12": 4 })).toBe('"12": 4\n"y": 2\n"no": 3\n');
  });

  it("quotes a string that would resolve to something else", () => {
    // Without this the round trip loses the string: `no` comes back as false in
    // a 1.1 reader, `007` comes back as 7, `null` comes back as null.
    expect(dump({ a: "no", b: "007", c: "null", d: "true", e: "12:30" })).toBe(
      'a: "no"\nb: "007"\nc: "null"\nd: "true"\ne: "12:30"\n'
    );
  });

  it("quotes a string that would break the structure", () => {
    expect(dump({ a: "- x", b: "k: v", c: "#tag", d: " padded " })).toBe(
      'a: "- x"\nb: "k: v"\nc: "#tag"\nd: " padded "\n'
    );
  });

  it("does not quote an ordinary string", () => {
    expect(dump({ a: "hello world", b: "Oslo" })).toBe("a: hello world\nb: Oslo\n");
  });

  it("writes a multi-line string as a block literal", () => {
    expect(dump({ a: "one\ntwo\n" })).toBe("a: |\n  one\n  two\n");
    expect(dump({ a: "one\ntwo" })).toBe("a: |-\n  one\n  two\n");
  });

  it("writes empty containers explicitly", () => {
    expect(dump({ a: [], b: {} })).toBe("a: []\nb: {}\n");
  });

  it("sorts keys on request", () => {
    expect(dump({ b: 1, a: 2 }, { ...YAML_DEFAULTS, sortKeys: true })).toBe("a: 2\nb: 1\n");
  });

  it("writes a scalar root", () => {
    expect(dump(42)).toBe("42\n");
    expect(dump(null)).toBe("null\n");
  });

  it("emits the document start marker on request", () => {
    expect(dump({ a: 1 }, { ...YAML_DEFAULTS, documentStart: true })).toBe("---\na: 1\n");
  });
});

describe("round trip", () => {
  const documents: JsonValue[] = [
    { name: "Ada", tags: ["a", "b"], nested: { deep: { deeper: true } } },
    { countries: ["NO", "SE"], version: "007", flag: "yes", ratio: 1.5 },
    { list: [{ id: 1 }, { id: 2, note: null }] },
    { text: "line one\nline two\n", empty: [], blank: {} },
    [1, "two", false, null],
    { "key with spaces": 1, "a:b": 2, "#hash": 3 },
    { unicode: "café 😀", quote: 'say "hi"', apostrophe: "it's" },
  ];

  for (const [index, value] of documents.entries()) {
    it(`survives JSON to YAML to JSON, case ${index + 1}`, () => {
      const yaml = stringifyYaml(value, YAML_DEFAULTS);
      const back = parseYaml(yaml);
      expect(back.success).toBe(true);
      if (back.success) expect(back.documents[0]).toEqual(value);
    });
  }

  it("keeps the Norway list intact through a full round trip", () => {
    const value = { codes: ["NO", "ON", "OFF", "Y", "N"] };
    const back = parseYaml(stringifyYaml(value as JsonValue, YAML_DEFAULTS));
    expect(back.success && back.documents[0]).toEqual(value);
  });
});

describe("real-world documents", () => {
  const WORKFLOW = `name: CI
on:
  push:
    branches: [main]
  pull_request:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Test
        run: |
          npm test
          npm run check
        env:
          CI: true
`;

  const COMPOSE = `version: "3.8"
services:
  web:
    image: nginx:1.25
    ports:
      - "8080:80"
    depends_on: [db]
volumes:
  db-data:
`;

  const MANIFEST = `apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
spec:
  replicas: 3
  template:
    spec:
      containers:
        - name: web
          image: nginx:1.25
          ports:
            - containerPort: 80
          resources:
            limits: {cpu: "500m", memory: 128Mi}
`;

  const OPENAPI = `openapi: 3.0.3
paths:
  /orders/{id}:
    get:
      responses:
        "200":
          description: OK
`;

  it("parses a GitHub Actions workflow", () => {
    expect(load(WORKFLOW)).toEqual({
      name: "CI",
      on: { push: { branches: ["main"] }, pull_request: null },
      jobs: {
        build: {
          "runs-on": "ubuntu-latest",
          steps: [
            { uses: "actions/checkout@v4" },
            { name: "Test", run: "npm test\nnpm run check\n", env: { CI: true } },
          ],
        },
      },
    });
  });

  it("keeps the workflow's `on` key a string, and says a 1.1 reader would not", () => {
    // Loaded by PyYAML this key is the boolean True, which is why so many
    // workflow-linting scripts quietly look at the wrong key.
    expect(warningsOf(WORKFLOW).join(" ")).toMatch(/Key on/);
  });

  it("parses a docker-compose file", () => {
    expect(load(COMPOSE)).toEqual({
      version: "3.8",
      services: { web: { image: "nginx:1.25", ports: ["8080:80"], depends_on: ["db"] } },
      volumes: { "db-data": null },
    });
  });

  it("parses a Kubernetes manifest with a flow mapping inside a block", () => {
    expect(load(MANIFEST)).toEqual({
      apiVersion: "apps/v1",
      kind: "Deployment",
      metadata: { name: "web" },
      spec: {
        replicas: 3,
        template: {
          spec: {
            containers: [
              {
                name: "web",
                image: "nginx:1.25",
                ports: [{ containerPort: 80 }],
                resources: { limits: { cpu: "500m", memory: "128Mi" } },
              },
            ],
          },
        },
      },
    });
  });

  it("parses an OpenAPI path template and a numeric-looking quoted key", () => {
    expect(load(OPENAPI)).toEqual({
      openapi: "3.0.3",
      paths: { "/orders/{id}": { get: { responses: { "200": { description: "OK" } } } } },
    });
  });

  it("round-trips all four through YAML and back", () => {
    for (const source of [WORKFLOW, COMPOSE, MANIFEST, OPENAPI]) {
      const value = load(source);
      const back = parseYaml(stringifyYaml(value, YAML_DEFAULTS));
      expect(back.success).toBe(true);
      if (back.success) expect(back.documents[0]).toEqual(value);
    }
  });
});

describe("needsQuoting", () => {
  it("is true for anything that would resolve to a non-string", () => {
    for (const token of ["true", "null", "42", "1.5", "~", "", "0x1f"]) {
      expect(needsQuoting(token)).toBe(true);
    }
  });

  it("is true for tokens a YAML 1.1 reader would type differently", () => {
    for (const token of ["no", "yes", "on", "off", "12:30"]) {
      expect(needsQuoting(token)).toBe(true);
    }
  });

  it("is false for an ordinary string", () => {
    for (const token of ["hello", "Oslo", "a-b-c", "x/y", "v1.2.3-beta"]) {
      expect(needsQuoting(token)).toBe(false);
    }
  });
});
